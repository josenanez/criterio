## Historia · PRY-203 Open Banking · 2026-03-24 a 2026-10-17

**Leí:** 6 documentos entre 2026-03-24 y 2026-10-17 (acta, cronograma v1, cronograma v2, informe de avance, solicitud de cambio CC-01, acta de comité).
**Trimestres sin un solo documento:** 2026-T2 (abril a junio). Entre el acta y el cronograma v2 no hay ningún documento fechado; el siguiente es del 2026-09-23.

**Términos:** vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17); no hizo falta registrarlos de nuevo.

### En una línea
El proyecto nace el 2026-03-24 con cierre el 2026-12-06. El 2026-09-23 el cronograma v2 mueve el piloto al 2027-03-30 (114 días) y ese mismo día el informe de avance declara verde, 60%, sin mencionar el cambio. La solicitud CC-01 que autoriza esos 114 días está fechada el 2026-10-14. Los dos hitos dados por cerrados no tienen acta de recibo y la integración con el core venció el 2026-10-05.

### Las cuatro cifras
| Replanificaciones | Atraso acumulado vs. original | Meses declarando sin sustento | Cambios de gobierno |
|---|---|---|---|
| 1 | 114 días (46.2 %) | No calculable: hay un solo informe declarado (2026-09-23, verde) y no hay serie | 0 documentados |

### Línea de tiempo
| Fecha | Documento | Qué cambió |
|---|---|---|
| 2026-03-24 | 00-gobierno/2026-03-24-acta-constitucion.docx | Aprobación: presupuesto 6.800.000.000 COP, inicio 2026-04-03, cierre 2026-12-06. Patrocinadora Sandra Gil, gerente Óscar Ramírez, Comité de Medios de Pago. Dependencias: "Ninguna declarada". Alcance con marcadores genéricos ("Componente 1, 2, 3"). |
| 2026-03-24 | 10-plan/2026-03-24-cronograma-v1.csv | Línea base de 4 hitos; el último, "Piloto con usuarios internos", al 2026-12-06. El archivo marca como "cerrado" los dos primeros hitos (fechas 2026-06-03 y 2026-08-04), que en la fecha del documento eran futuros. |
| 2026-09-23 | 10-plan/2026-09-23-cronograma-v2.xlsx | Replanificación: piloto de 2026-12-06 a 2027-03-30. Los demás hitos no cambian. "Integración con el core" sigue al 2026-10-05, en curso. |
| 2026-09-23 | 20-seguimiento/2026-09-23-informe-avance.md | Estado declarado verde, avance 60 %. Comprometido 4.287.613.069; ejecutado 2.423.227.705; proyección 6.372.447.197 COP. Dice que la prueba de carga no alcanzó el umbral y se repite. Riesgos: concentración del conocimiento y dependencia del calendario de liberaciones del core. No menciona el cambio de fecha del piloto. |
| 2026-10-14 | 20-seguimiento/2026-10-14-solicitud-cambio-cc-01.md | CC-01, solicitada por Óscar Ramírez: ampliación de alcance, +114 días "sobre la línea base vigente" y +228.000.000 COP. Dice "Autorizada por el comité", sin fecha ni referencia a un acta. |
| 2026-10-17 | 30-reuniones/2026-10-17-comite-semanal.md | Comité con Óscar Ramírez y Sandra Gil. Temas: "Avance" y "Compromisos". No registra CC-01 ni decisión alguna. Un compromiso: Carlos Peña, "Entregar el punto 21", para 2026-11-13. |

### Replanificaciones
| Nº | Fecha | Fecha de cierre nueva | Motivo declarado | Documento que la aprobó |
|---|---|---|---|---|
| 1 | 2026-09-23 (fecha del cronograma v2) | 2027-03-30 | Sin motivo documentado | Ninguno localizado. CC-01 (2026-10-14) menciona +114 días y dice "Autorizada por el comité", pero no cita acta ni fecha de autorización, y es posterior al cronograma que ya muestra el cambio. |

Atraso acumulado contra la línea base original: 114 días (46.2 %). Contra la vigente: 0 días, porque la vigente ya incorpora el movimiento. Hay una ambigüedad que este análisis no resuelve: CC-01 dice que los 114 días son "sobre la línea base vigente", y el cronograma v2 ya los incluye. Si fueran dos movimientos, el atraso sería otro; con los documentos que hay, el cálculo lo trata como uno. El cálculo también marca CC-01 como aprobada sin línea base nueva registrada.

### Gobierno
| Fecha | Qué cambió | Documento |
|---|---|---|
| — | Sin cambios de patrocinador, gerente ni comité en los documentos leídos. Sandra Gil y Óscar Ramírez figuran en el acta (2026-03-24) y en el comité (2026-10-17). | — |

Un cambio que nunca se escribió no aparece aquí. Sobre la autoridad de CC-01 solo se sabe que "el comité" la autorizó, sin más.

### Compromisos que se repitieron
| Doliente | Qué | Veces | Fechas prometidas |
|---|---|---|---|
| — | Ninguno se repitió. Hay un solo compromiso en todo el expediente: Carlos Peña, "Entregar el punto 21", 2026-11-13. | 1 | 2026-11-13 |

El "punto 21" no está definido en ningún documento, y Carlos Peña no figura entre los asistentes de ese comité.

### Desde cuándo lo declarado no se sostiene
- **Primer hito sin evidencia:** "Diseño funcional aprobado", fecha 2026-06-03, marcado cerrado sin acta de recibo (136 días a la fecha de corte). Después, "Ambiente de pruebas certificado", 2026-08-04, también sin acta (74 días).
- **Declaración que quedó sin sustento:** el informe del 2026-09-23 (verde, 60 %). Sus señales sin explicar son los dos hitos sin evidencia, "Integración con el core" vencido hace 12 días (fecha 2026-10-05) y el atraso de 114 días contra la original.
- **Lo que no se puede decir:** desde cuándo se viene declarando verde. Solo hay un informe, así que no hay serie y no se calcula una cifra en meses.
- El 60 % cae dentro del rango que el cronograma admite (50 a 75 %); la diferencia está en que los hitos que lo sostienen no tienen acta.

### Lecciones ancladas a un hecho
1. **Hecho:** el 2026-09-23 el cronograma v2 movió el piloto 114 días y el informe del mismo día declaró verde sin mencionarlo. **Efecto:** quien lee solo el informe no ve el atraso. Este aparece solo en el cronograma, con 46.2 % contra la original.
2. **Hecho:** CC-01 está fechada el 2026-10-14, y el cronograma que ya contiene sus 114 días es del 2026-09-23. **Efecto:** la autorización quedó escrita después del cambio, sin acta de comité que la respalde.
3. **Hecho:** el cronograma v1, fechado 2026-03-24, trae dos hitos futuros en "cerrado". **Efecto:** el archivo se editó después de su fecha o el estado se anotó sin evidencia; en ambos casos la línea base original no es una fotografía de marzo. Esto hay que confirmarlo con quien conserva el archivo.
4. **Hecho:** el acta del 2026-03-24 declara "Ninguna declarada" en dependencias, y el informe del 2026-09-23 cita la dependencia del calendario de liberaciones del core. **Efecto:** "Integración con el core" venció el 2026-10-05 sin que la dependencia estuviera en el acta.

### Qué no se sabe
Por qué se replanificó, quién autorizó el cambio y cuándo, qué pasó entre abril y septiembre (no hay documentos), qué es el "punto 21" y si CC-01 es el mismo movimiento que el cronograma v2 o uno adicional. Esto describe qué quedó escrito y cuándo; no atribuye intención a nadie. El porqué lo contesta una persona.

Siguiente paso posible: llevar esta historia al comité, con la decisión pendiente sobre CC-01 y el acta que la respalde. No lo hago sin que lo pidas.

---
*Rigor:* cifras copiadas de `portafolio.py compute` (as_of 2026-10-17). Lectura de 6 de 6 documentos del proyecto. Sin cifra en meses por falta de serie de informes. Las fechas de los documentos son las del nombre de archivo y su contenido.
