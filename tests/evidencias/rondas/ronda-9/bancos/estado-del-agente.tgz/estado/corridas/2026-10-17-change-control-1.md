# Corrida del 2026-10-17 · change-control

13 proyectos · 44 s · 58 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 14 |
| `commitment_overdue` | 11 |
| `declared_vs_evidence` | 8 |
| `progress_vs_plan` | 7 |
| `milestone_overdue` | 3 |
| `variance_cost` | 3 |
| `commitment_undated` | 3 |
| `vendor_deliverable_late` | 3 |
| `commitment_rescheduled` | 2 |
| `silent` | 2 |
| `variance_time` | 1 |
| `change_without_baseline` | 1 |

Evaluó mover 30 días la salida a producción de PRY-205. Sin solicitante, motivo, autoridad declarada, impacto en costo ni dependencias declaradas: lo dice y no lo inventa. impact no alcanza a ningún proyecto. Lleva el punto a comité 2026-10-24 por defecto.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

Sale de la ficha `estado/records/PRY-205.json` (acta de constitución del 2026-05-29, cronograma v1, contrato CT-172, informe de avance del 2026-10-14, comité del 2026-10-15) y de `portafolio.py impact` al 2026-10-17. Términos vigentes, aceptados por José Francisco Ñáñez el 2026-10-17.

## Solicitud de cambio — PRY-205 Prevención de lavado de activos — 2026-10-17

**Qué se pide:** mover la salida a producción 30 días: del 2027-06-28 al 2027-07-28.
**Quién lo pide:** no consta. La solicitud llegó sin solicitante, y ningún documento de la carpeta la menciona (la ficha no tiene cambios registrados).
**Por qué:** no consta. Tampoco hay motivo escrito. Dos cosas del informe del 2026-10-14 podrían explicarlo, pero son lectura mía, no motivo declarado: la prueba de carga no alcanzó el umbral y se repite, y dos historias quedaron fuera del sprint por dependencia con el core.

### Línea base de la que parte
Una sola: v1, aprobada el 2026-05-29 por el Comité de Transformación Digital, cierre 2027-06-28, 800.000.000 COP (acta de constitución y cronograma v1). Cero replanificaciones, cero cambios aprobados; `changes.unauthorized_days` = 0. Hoy no hay ninguna diferencia sin autorizar.

### Impacto
| Dimensión | Hoy | Con el cambio | Diferencia |
|---|---|---|---|
| Alcance | Componentes 1, 2 y 3 (sin nombre en el acta) | No declarado | No se puede medir: el acta no nombra los componentes. |
| Tiempo | Salida a producción 2027-06-28 | 2027-07-28 | +30 días en ese hito. No está dicho si los otros tres hitos pendientes se mueven. |
| Costo | Aprobado 800.000.000 · proyección 762.502.965 COP | No declarado | No se puede calcular: ningún documento dice cuánto cuesta un mes más. |

**Quién absorbe lo que no está declarado.** La solicitud no declara alcance ni costo. Un mes más no es gratis: alguien lo absorbe en horas del equipo no presupuestadas, en el contrato CT-172 con Núcleo Financiero S.A. o en el 37.497.035 COP que separa la proyección del aprobado. Nadie lo ha dicho. Hasta que se diga, la dimensión de costo queda abierta, no en cero.

**Dos hechos que cambian cómo se lee este pedido:**
- El hito más cercano, "Ambiente de pruebas certificado", vence el 2026-11-09, en 23 días, y la prueba de carga acaba de fallar. Si ese hito se mueve, el 2027-07-28 puede no alcanzar. La solicitud no dice qué supone sobre esos 23 días.
- La brecha entre "Piloto con usuarios internos" (2027-04-12) y "Salida a producción" (2027-06-28) es de 77 días. Eso es distancia entre fechas, no holgura: la ficha no tiene holgura por actividad, así que no sé si un atraso anterior se absorbe ahí.

### Efecto en el portafolio
| Proyecto afectado | Cómo | Gerente |
|---|---|---|
| Ninguno encontrado | `impact` no alcanza a ningún proyecto, directo ni indirecto: 0 que no puedan sostener su fecha, 0 dependencias sin confirmar. | — |

**Esto no significa que no haya efecto.** Significa que ningún documento declara una dependencia hacia o desde PRY-205: el acta dice "Ninguna declarada". Y el propio informe habla de una "dependencia con el core" y de un hito "Integración con el core" (2027-01-25) que nadie escribió como dependencia. Si el core es otro proyecto del portafolio, el cálculo no lo ve. La dependencia está sin declarar; no se la atribuyo a ningún proyecto concreto porque ningún documento lo dice. Cuántos días se movería cada proyecto afectado tampoco se puede decir: eso necesita holgura por actividad.

### Quién decide
**Autoridad requerida:** no determinable. La ficha tiene `identity.authority` en "no encontrado": ni el acta ni otro documento dicen quién puede aprobar un cambio de fecha ni hasta qué umbral. Es el hallazgo de fondo.
**Según:** acta de constitución del 2026-05-29, sin cláusula de autoridad ni de control de cambios.
**Va a comité:** sí, por defecto y no por cláusula. El Comité de Transformación Digital aprobó la línea base y el presupuesto, y mover el cierre modifica lo que aprobó. Próximo comité: 2026-10-24. Es lo más prudente, no lo que un documento exige. Si quien tiene la facultad es otra persona, esa es quien decide.

### Si no se aprueba
El proyecto sigue con cierre el 2027-06-28. El informe lo declara en **verde con 82%**, pero la evidencia no lo sostiene: solo 1 de 5 hitos tiene acta de recibo (Diseño funcional, fecha comprometida 2026-08-24, recibido el 2026-10-08, 45 días después y sin que la fecha vigente se moviera). Se ha ejecutado 156.431.890 de 800.000.000 COP (19,6 %). El licenciamiento del motor (CT-172, 2026-09-22) está pendiente sin evidencia, 25 días después. Hay una prueba de carga fallida, dos historias fuera del sprint, un riesgo de concentración del conocimiento y un compromiso vencido (Laura Vélez, "punto 31", al 2026-10-11, sin evidencia de entrega). Es decir: sin aprobar el cambio, la fecha vigente ya tiene señales de que no se sostiene, y el 30 es el número que alguien trae, no uno que el cronograma respalde.

### Si se aprueba
Línea base 2 — cierre 2027-07-28 · presupuesto: no declarado (si no cambia, 800.000.000 COP) · motivo: pendiente, nadie lo ha escrito.
Desviación acumulada contra la línea base original: **+30 días** en tiempo (1 replanificación) · costo: **sin dato**; no se puede escribir un número.
La v1 no se toca. Desde ahí toda desviación se reporta contra dos referencias. Conviene dejarlo escrito: el hito de diseño funcional ya salió 45 días tarde sin replanificar, y ese atraso no está dentro de los 30 de esta solicitud.

### Lo que falta para poder decidir
1. Quién pide el cambio y el motivo, por escrito.
2. Si los hitos "Ambiente de pruebas", "Integración con el core" y "Piloto" se mueven, y cuánto.
3. Cuánto cuesta un mes más (equipo, contrato CT-172) y quién lo paga.
4. Quién tiene la autoridad para aprobar un cambio de fecha en PRY-205.
5. Si la "dependencia con el core" es de otro proyecto del portafolio, y cuál.

### Después
Puedo preparar el punto para el comité del 2026-10-24, con estas cinco preguntas como decisión pendiente, o registrar la línea base 2 una vez que lo apruebe quien pueda aprobarlo. No registro nada hasta entonces.

### Pie de rigor
Borrador de trabajo, no decisión ni asesoría. Se basa solo en los 6 documentos de la carpeta de PRY-205; no sabe lo que se habló fuera de ellos. Los días de propagación salen de `portafolio.py impact` al 2026-10-17; las demás cifras se copian de los documentos o son resta simple de sus fechas y montos. La verificación de cada cita es suya.
