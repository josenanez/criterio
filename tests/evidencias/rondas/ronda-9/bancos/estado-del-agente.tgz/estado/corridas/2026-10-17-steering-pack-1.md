# Corrida del 2026-10-17 · steering-pack

13 proyectos · 70 s · 58 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 14 |
| `commitment_overdue` | 11 |
| `declared_vs_evidence` | 8 |
| `progress_vs_plan` | 7 |
| `milestone_overdue` | 3 |
| `variance_cost` | 3 |
| `commitment_undated` | 3 |
| `vendor_deliverable_late` | 3 |
| `commitment_rescheduled` | 2 |
| `silent` | 2 |
| `variance_time` | 1 |
| `change_without_baseline` | 1 |

Paquete de 5 decisiones y 6 escalamientos sobre 13 fichas. No dijo: decisiones del comité anterior (no hay registro), quién tiene la facultad (autoridad vacía en las 13 fichas), cláusulas del contrato CT-882 (no leído), efecto combinado de CC-01 de PRY-211 en la proyección (el script no lo calcula).

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

**Fichas cargadas:** 13 fichas (PRY-199 a PRY-211) de `estado/records`, cálculo `compute` con corte 2026-10-17. Términos v1.1 vigentes (aceptados por José Francisco Ñáñez el 2026-10-17). Comité programado según la configuración: 2026-10-24.

# Comité de proyectos — 2026-10-24 (material preparado el 2026-10-17)
5 decisiones · 6 escalamientos sin decisión asociada · 11 de 13 proyectos con hallazgos (58 alertas en total)

## Decisiones del comité anterior
No hay un registro de decisiones de un comité anterior en `estado` (ninguna corrida previa de steering-pack ni decisiones guardadas en las fichas). No se puede cerrar el ciclo anterior y no se inventa. Cuando este comité sesione, se registran las decisiones en las fichas para que el próximo material parta de ahí.

## Decisiones de hoy

### [1] ¿Quién tiene la facultad de aprobar cambios de alcance, tiempo y costo en cada proyecto, y hasta qué monto decide el gerente sin subir al comité?
**Proyecto:** los 13 · **Quién decide:** patrocinador / presidente del comité (no identificable en las fichas) · **Si no se decide hoy:** los puntos 2 a 5 no se pueden dirigir con certeza a quien tiene la facultad, y todo seguirá llegando al comité por defecto.
Las 13 fichas tienen vacío `identity.authority` (totals.no_authority = 13). Ninguna acta leída lo declara.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Fijar una tabla única de autoridad para todo el portafolio | Mismo umbral para todos | Decisión en un comité | Sin costo directo; puede ser rígida para proyectos de monto muy distinto (800.000.000 a 18.000.000.000 COP aprobados) |
| B. Fijar autoridad por proyecto, actualizando cada acta | Umbral a la medida | Más lento: 13 actas | Sin costo directo |
| C. No definirla y que todo suba al comité | Sin cambio | Cada cambio espera sesión | Costo de demora en cada cambio |

**Recomendación:** A como regla de partida y B solo para excepciones. Con un solo umbral, el comité de la semana siguiente ya puede devolver lo que no le corresponde.

### [2] ¿Se formaliza el CC-01 de PRY-203 (Open Banking) con línea base nueva y constancia de quién lo autorizó?
**Proyecto:** PRY-203 · **Quién decide:** no determinable (ver punto 1) · **Si no se decide hoy:** el proyecto sigue medido contra una línea base que no refleja el cambio y el atraso aparece como 114 días contra la original (46.2 %) mientras el informe de avance declara verde.
La solicitud CC-01 (2026-10-14, Óscar Ramírez) amplía alcance: +114 días y +228.000.000 COP, y dice "Autorizada por el comité". La ficha registra el cambio sin línea base nueva (`change_without_baseline`, 114 días). El comité del 2026-10-17 solo lista "Avance" y "Compromisos"; la autorización no consta en esa acta.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Ratificar y crear la línea base nueva, con motivo y autor | Amplía | +114 días sobre la vigente; fin vigente 2027-03-30 | +228.000.000 COP |
| B. Devolver: aportar el acta que respalda la autorización | Sin cambio hasta entonces | Sin cambio hasta entonces | Sin cambio hasta entonces |
| C. Rechazar y volver al alcance original | Vuelve al original | Cae el plazo adicional | Cae el costo adicional |

**Recomendación:** B primero. Una autorización que dice "del comité" y que ningún acta del comité muestra es un hallazgo antes que una decisión; si aparece el acta, A.

### [3] ¿Se aprueba el CC-01 de PRY-211 (Cobranza digital), o se devuelve?
**Proyecto:** PRY-211 · **Quién decide:** no determinable (ver punto 1) · **Si no se decide hoy:** el proyecto, que declara rojo, sigue con fin planificado 2026-01-27 ya pasado, sin plan aprobado que lo reemplace.
Solicitud CC-01 (2026-10-07, Natalia Ospina): ampliación de alcance, +116 días y +232.000.000 COP, "Pendiente de presentación al comité". Presupuesto aprobado 3.300.000.000, proyección al cierre 3.243.862.115 COP. El efecto combinado de proyección más el cambio no lo calcula el script, así que no se escribe.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar y abrir línea base nueva | Amplía | +116 días | +232.000.000 COP |
| B. Devolver con el plan y la proyección actualizados | Sin cambio | Sin cambio | Sin cambio |
| C. Rechazar | Se queda el original | Fin sigue vencido | Sin adicional |

**Recomendación:** B. El informe da como causa una dependencia con el core y una ventana de operaciones, pero la solicitud no dice qué entra al alcance ampliado ni qué hitos mueve; sin eso, aprobar es firmar a ciegas.

### [4] ¿Se exige solicitud de cambio formal a los tres proyectos que proyectan sobrecosto de más de 10 % sin ninguna?
**Proyecto:** PRY-207, PRY-202, PRY-200 · **Quién decide:** no determinable (ver punto 1) · **Si no se decide hoy:** los sobrecostos se absorben sin que nadie los haya autorizado, y dos de los tres informes siguen en verde.

| Proyecto | Aprobado (COP) | Proyección (COP) | Sobre lo aprobado | Estado declarado |
|---|---|---|---|---|
| PRY-207 Onboarding PyME | 18.000.000.000 | 21.962.012.879 | 22.0 % | rojo |
| PRY-202 Migración a la nube | 9.500.000.000 | 12.125.785.918 | 27.6 % | verde |
| PRY-200 Originación digital | 18.000.000.000 | 20.859.955.929 | 15.9 % | verde |

Ninguno tiene solicitud de cambio en la ficha. En PRY-200, el compromiso de Laura Vélez de "mandar el ajuste del presupuesto" (notas del 2026-10-17) no tiene fecha. Umbral de la configuración: 10 %.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Exigir CC con plazo (por ejemplo antes del siguiente comité) | Se explicita | Se explicita | Se explicita; decisión llega al comité con cifras |
| B. Aceptar la proyección como nueva línea sin CC | Sin trazabilidad | Sin trazabilidad | Se normaliza el sobrecosto |
| C. Pedir recorte de alcance para contenerlo | Baja | Posible mejora | Contenido; riesgo de calidad |

**Recomendación:** A. Es el único camino que deja una decisión sustentada; B y C piden decidir sin tener el cambio escrito.

### [5] ¿Se exige a Talento Digital S.A.S. (CT-882) un plan de entrega con fecha para PRY-210 (Portal de proveedores)?
**Proyecto:** PRY-210 · **Quién decide:** no determinable; el contrato lo administra un área que las fichas no identifican (ver punto 1) · **Si no se decide hoy:** el hito "Salida a producción" (vencido el 2026-10-08, 9 días) sigue sin camino y los dos entregables pendientes siguen corriendo.
Entregables pendientes del proveedor: "Licenciamiento del motor" (vencido desde 2025-12-06, 315 días) y "Parametrización del tarifario" (vencido desde 2026-05-28, 142 días). De 4 entregables hay 2 aceptados; facturado 1.361.054.552 COP, igual al monto aceptado (no hay factura adelantada). Avance declarado 52 % frente a 80 %-100 % que sustenta el plan. No se revisó el texto del contrato; lo que haya sobre penalidades no se afirma aquí.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Plan de entrega firmado con fechas y retención de pagos futuros | Sin cambio | Fecha nueva comprometida por escrito | Retención; sin costo adicional visible |
| B. Replanificar el proyecto sin exigir al proveedor | Sin cambio | Se mueve la línea base | Costo de espera no calculado |
| C. Escalar a revisión contractual | Posible | Más largo | Honorarios no calculados |

**Recomendación:** A, y revisar el contrato antes de B o C. Es la única opción que no mueve la línea base sin que el proveedor se haya comprometido.

## Escalamientos sin decisión asociada
| Proyecto | Qué | Desde cuándo | Qué se necesita |
|---|---|---|---|
| PRY-208 Motor de decisión | Sin movimiento, 17 días; declarado verde, avance 47 % | Último informe 2026-09-30 | Que su gerente responda o se declare en silencio |
| PRY-209 Nómina electrónica | Sin movimiento, 21 días; fin planificado 2026-06-28 ya pasado; declarado amarillo, 78 % | Último informe 2026-09-26 | Ídem; y aclarar cuál es la fecha vigente |
| PRY-200 Originación digital | 8 compromisos vencidos (de 22 a 2 días), 3 sin fecha, 2 reprogramados: Elena Duarte 6 veces (original 2026-09-25, última 2026-12-05) y Ricardo Salas 4 veces; hito "Diseño funcional aprobado" vencido 12 días; declarado verde | Desde 2026-09-20 | Dolientes responder por escrito; el punto 4 trata el costo |
| PRY-200 | Riesgo dicho y no registrado (notas del 2026-10-17): el proveedor podría no llegar con el equipo completo a la siguiente fase | 2026-10-17 | Que el gerente decida si lo formaliza, con doliente y fecha |
| PRY-205 Prevención de lavado de activos | "Licenciamiento del motor" de Núcleo Financiero S.A. (CT-172) pendiente, 25 días tarde; el informe declara verde y 82 % cuando el plan sustenta 20 %-40 % | Vencido el 2026-09-22 | Plan de entrega del proveedor; verificar el avance declarado |
| PRY-211 y PRY-203 | Ambos dependen del core según sus documentos (PRY-211: "calendario de liberaciones del core"; PRY-203: hito "Integración con el core" vencido 12 días), pero ninguna ficha declara la dependencia con código de proyecto | — | Que sus gerentes registren de qué proyecto del core dependen |

## Para conocimiento
- PRY-199 Renovación de cajeros: sin alertas.
- PRY-201 Core de depósitos: rojo declarado; 2 hitos "cumplidos" sin evidencia; avance 29 % frente al 75 %-100 % del plan.
- PRY-204 Débito contactless: verde con avance 68 % frente a 25 %-50 % del plan; 1 compromiso vencido (Jorge Medina, 5 días).
- PRY-206 Billetera y QR: verde con 36 % frente a 50 %-75 % del plan; 1 hito sin evidencia.
- PRY-207 Onboarding PyME: rojo declarado; 3 hitos sin evidencia; fin planificado 2026-08-29 pasado (sobrecosto en el punto 4).
- PRY-202 Migración a la nube: 2 hitos sin evidencia, avance 37 % frente a 67 %-100 %.

## Anexo
**Contradicciones abiertas:** 8 proyectos con estado verde contradicho por sus propias señales (green_contradicted = 8): PRY-200, 202, 203, 204, 205, 206, 208, 210 (en PRY-208 la contradicción es solo el silencio de 17 días). PRY-203: informe verde con corte 2026-09-23 (24 días) y 114 días de atraso contra la original.
**Hitos declarados cumplidos sin evidencia:** PRY-201 (2), PRY-202 (2), PRY-203 (2), PRY-206 (1), PRY-207 (3), PRY-210 (4).
**Vacíos de información:** `identity.authority` e `identity.phase` faltan en todas las fichas; `identity.product` falta en PRY-202, 205, 208, 210; facturado del proveedor no declarado en PRY-199 y PRY-205. Campos de identidad y plan con más de 12 meses en PRY-201, 202, 207, 210, 211 (13 a 16 meses). En ninguna ficha las fuentes están marcadas como evidencia o declaración (todas "sin marcar"): las cifras del estado declarado no se pueden separar de lo sustentado salvo por el cruce del script.

---
Pie: criterio-portfolio 0.4.0 · fichas aplicadas: raid-taxonomy, governance-artifacts · campos inciertos: autoridad, fase, fuentes sin marcar, contrato CT-882 sin revisar en esta corrida, comité anterior sin registro · términos: https://www.josenanez.com/es/agents/criterio-pmo/legal
