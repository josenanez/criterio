Informe generado con la ficha `estado/records/PRY-208.json` (actualizada el 2026-10-17), cálculo de `portafolio.py compute` al 2026-10-17. Términos v1.1 vigentes, aceptados por José Francisco Ñáñez el 2026-10-17.

## PRY-208 · Motor de decisión — estado al 2026-10-17

**Declara el gerente (Carlos Peña):** verde · 47% · al 2026-09-30 (hace 17 días; no está vencida: el umbral es 30)
**Sustento documental:** sin sustento. Las 13 fuentes de la ficha no tienen marca de evidencia (0 evidencia, 0 declaración, 13 sin marcar). Los únicos documentos leídos son el acta de constitución (2026-01-16) y el propio informe de avance (2026-09-30), que es la declaración.
**Lo que el semáforo no explica:** `silent` — 17 días sin documentos, con el umbral en 15. Alerta `declared_vs_evidence`: reporta verde y esa señal no queda cubierta.
**Último documento:** 2026-09-30 (hace 17 días) · **Última reunión:** sin dato (no hay minuta ni transcripción en la ficha)

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2027-03-15 | 2027-03-15 | 0 días |
| Presupuesto aprobado | COP 1.200.000.000 | COP 1.200.000.000 | proyección COP 1.129.393.870 (−5,9 % frente a lo aprobado) |

Ejecutado COP 459.175.619 (38,3 %) · Comprometido COP 844.902.221 (70,4 %) · Disponible real COP 355.097.779.
Replanificaciones: 0. Solo hay una versión de línea base (v1, aprobada el 2026-01-16). No hay solicitudes de cambio.

### Hitos
La ficha no tiene hitos cargados. No se puede contrastar el 47 % declarado contra el plan, ni hay hitos vencidos o cumplidos sin evidencia que medir.

### Dónde no coincide
- **Declarado:** verde, 47 %, al 2026-09-30 (informe de avance).
- **Documentos:** nada posterior al 2026-09-30, y nada que sustente el verde fuera del propio informe.
- **Dentro del mismo informe:** se levantó un hallazgo de seguridad en la revisión de arquitectura (incidencia desde 2026-09-30, sin responsable) y el informe mantiene el verde. El script no lo marca como señal; se cita como dato, y juzgar si cabe en un verde es del gerente y del comité.

### Abierto
**Riesgos e incidencias sin movimiento:**
- Riesgo: dependencia del calendario de liberaciones del core. Sin fecha ni responsable; la única fuente es el informe del 2026-09-30 (17 días).
- Incidencia: hallazgo de seguridad en la revisión de arquitectura, desde 2026-09-30 (17 días), sin responsable.
**Compromisos vencidos:** ninguno registrado (la ficha no tiene compromisos; sin minutas, no es lo mismo que «ninguno»).
**Dependencias sin confirmar:** ninguna registrada. El riesgo del core apunta a una dependencia externa que no está en la ficha como dependencia.

### Sin dato
- Producto, autoridad de aprobación y fase del proyecto (`identity.product`, `identity.authority`, `identity.phase`).
- Hitos y fechas de línea base por hito.
- Última reunión, compromisos y proveedores.

---
**Pie:** criterio-portfolio 0.4.0 · ficha PRY-208 aplicada, actualizada el 2026-10-17 (declaración del 2026-09-30) · campos inciertos: producto, autoridad, fase, hitos · Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.4.0

**Siguiente paso posible:** hay una señal de silencio sobre el umbral y una incidencia de seguridad sin responsable; puedo preparar el punto de comité. No hay cambio de alcance no formalizado, así que no corresponde solicitud de cambio.
