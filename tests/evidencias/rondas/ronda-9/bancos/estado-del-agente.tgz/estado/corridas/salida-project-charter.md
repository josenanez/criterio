Acta previa: sí, `00-gobierno/2025-06-28-acta-constitucion.md`, aprobada el 2025-06-28 por el Comité de Riesgos. Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17); no hizo falta registrarlos otra vez.

## Acta — PRY-211 · Cobranza digital
**Estado:** existe, del 2025-06-28 (modo revisar)

### Qué falta
| Campo | Estado | Consecuencia |
|---|---|---|
| Autoridad del gerente | **Ausente.** El acta no dice hasta qué monto ni qué cambio de alcance decide Natalia Ospina sin comité. | La CC-01 (+232.000.000 COP, +116 días, ampliación de alcance) quedó "pendiente de presentación al comité". Sin autoridad escrita no se puede saber si debía llegar al comité o si ella podía resolverla. Todo cambio, grande o pequeño, tiene que subir. |
| Objetivo de negocio | **Es la solución, no un resultado:** "Entregar cobranza digital para Banca PyME". | Nadie puede decir si el proyecto sirvió aunque entregue. No hay baja de mora, ni aumento de recaudo, ni tiempo de gestión contra qué comparar. |
| Alcance | **Marcador vacío:** "Componente 1, 2, 3". | El alcance no está definido. La CC-01 pide una "ampliación de alcance" sin que se pueda saber qué se amplía ni respecto de qué. Las "dos historias fuera del sprint" del informe tampoco se pueden ubicar. |
| Exclusiones | **Vagas:** "Lo que otro proyecto cubre", sin nombrar el proyecto. | No se sabe quién cubre qué. Con la dependencia del core abierta en el informe, el riesgo es que dos proyectos, o ninguno, asuman ese trabajo. |
| Patrocinador | Presente: Javier Hoyos. | Sin hallazgo. |
| Supuestos y restricciones | **Ausentes.** | Nada se pactó como supuesto, así que nada se puede vigilar. Los riesgos del informe llegan sin el supuesto que los origina. |
| Dependencias | Declara "Ninguna". El informe del 2026-10-15 reporta una dependencia del calendario de liberaciones del core. | El acta y el informe se contradicen. La dependencia que hoy tiene el proyecto en rojo nunca se acordó con el dueño del core. |
| Criterio de éxito | **No medible y sin medidor:** "en producción y medido". | "Medido" no dice qué métrica, qué umbral ni quién la mide. El cierre no se puede juzgar contra esto. |
| Hitos principales | **Ausentes.** Solo inicio y cierre. La ficha tiene `milestones` vacío. | El avance del 74% no se puede contrastar contra ningún hito. El atraso solo se ve en el cierre. |
| Cadencia de reporte al comité | **Ausente.** El comité está nombrado (Comité de Riesgos) y su cadencia no. | No hay un momento fijo en que el proyecto deba rendir cuentas. La CC-01 espera sin fecha de comité. |
| Línea base | Solo la v1 (cierre 2026-01-27). Sin replanificación registrada. | El cierre comprometido pasó hace unas 38 semanas y el proyecto sigue abierto, sin línea base nueva. La CC-01 habla de "+116 días sobre la línea base vigente", pero la única vigente es la que ya venció. |

### Contenido
**Objetivo de negocio:** pendiente de definir (el acta solo dice "Entregar cobranza digital para Banca PyME", que describe la solución). Fuente: acta, 2025-06-28.
**Alcance:** pendiente de definir. El acta enumera "Componente 1, 2, 3" sin contenido. Fuente: acta.
**Exclusiones:** "Lo que otro proyecto cubre". Sin proyecto nombrado; queda pendiente de precisar. Fuente: acta.
**Patrocinador:** Javier Hoyos · **Gerente:** Natalia Ospina. Fuente: acta.
**Autoridad del gerente:** pendiente de definir. No figura en ningún documento. No la completo con un valor razonable.
**Comité al que reporta:** Comité de Riesgos (fuente: acta) · **Cadencia:** pendiente de definir.
**Supuestos:** pendiente de definir · **Restricciones:** pendiente de definir.
**Criterio de éxito:** "Cobranza digital en producción y medido" (acta). No es medible tal como está. **Lo mide:** pendiente de definir.
**Hitos principales:** pendiente de definir. Solo constan inicio 2025-07-08 y cierre comprometido 2026-01-27 (acta).
**Presupuesto aprobado:** 3.300.000.000 COP, aprobado por el Comité de Riesgos el 2025-06-28 (acta).

### Lo que no sé
- Si Natalia Ospina tiene una autoridad delegada fuera de estos documentos. Puede existir en una política del banco o del comité que no está en la carpeta.
- Qué contienen los "Componente 1, 2, 3" y qué proyecto cubre lo excluido.
- Qué se amplía con la CC-01.
- Si la fecha de cierre se movió en alguna replanificación que no esté documentada. En la carpeta no hay ninguna.

### Después
- **Decisión para el comité:** el acta quedó sin autoridad declarada. Propongo llevar esa definición al Comité de Riesgos junto con la CC-01, porque es una decisión y no un trámite. Hasta que se defina, la CC-01 no tiene contra qué evaluarse. Dejo la preparación del material del comité a `/steering-pack` o `/change-control`; no la hago aquí.
- **RAID:** de la revisión salen dos supuestos por escribir: que el core libera según un calendario que el proyecto no controla, y que otro proyecto cubre lo excluido. Ofrezco pasarlos al registro RAID con `/raid-log PRY-211`. No los registré.

Rigor: todo lo anterior sale de tres documentos (acta del 2025-06-28, solicitud CC-01 del 2026-10-07, informe de avance del 2026-10-15) y de la ficha PRY-211. El informe de avance lo leí desde el texto convertido del PDF (caché), no desde el original. Lo declarado por el gerente (rojo, 74%) no se contrastó aquí. Es un tema de `/status-report`. Esta revisión es un borrador de trabajo: la verificación contra los originales es de quien la lea.
