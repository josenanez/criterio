# Corrida · 2026-10-17-product-requirements-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-requirements (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T20:17:33 · **Fin:** 2026-10-17T20:18:23 · **Duración:** 50 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-requirements` | 16 | — | 35 | 36 | 9 aceptados sin proyecto; 5 aceptados sin quien los pidiera; 7 propuestos sin decidir más de 60 días |

Por señal (`product-requirements`): `evidence_stale` 10, `requirement_untraced` 9, `requirement_undecided` 7, `requirement_accepted_without_evidence` 5, `requirement_without_acceptance` 2, `requirement_without_owner` 2, `claim_vs_metric` 1

## Lo que el agente mostró

## Registro — Remesas familiares (PRD-307) · al 2026-10-17

16 requerimientos, 9 decididos. El 44,4% de los decididos tiene evidencia y el 0% tiene un proyecto que lo ejecute. Los términos v1.1 ya estaban vigentes, aceptados por José Francisco Ñáñez el 2026-10-17. El cálculo salió de `producto.py compute`, y el único requerimiento que leí a mano fue REQ-4702.

El registro está en 7 propuestos, 9 aceptados y ninguno en construcción, entregado o descartado. Los vacíos, en el orden de lectura del comando:

- **Se va a construir y nadie lo pidió (5 aceptados):** REQ-4702, 4703, 4706, 4707 y 4713. El acta dice «—» en «Quién lo pidió».
- **Decidido y nadie lo construye (9):** los nueve aceptados, decididos el 2026-10-16, sin proyecto. Corresponde `/product-trace`.
- **Sin doliente (2):** REQ-4708 (propuesto) y REQ-4714 (aceptado), ambos «sin asignar». Quien cierra el vacío es Felipe Arango, el gerente de producto, y REQ-4714 va primero porque ya está aceptado.
- **Sin criterio de aceptación (2 decididos):** REQ-4702 y REQ-4705. REQ-4710 y REQ-4715 tampoco lo tienen, pero están propuestos y no se les exige.
- **Decidido sin documento:** ninguno. Pero el acta respalda poco: tiene un solo asistente, su única decisión es «Se mantiene el plan» y no dice quién aceptó cada requerimiento.
- **Lleva meses sin decidirse (7 propuestos, umbral de 60 días):**
  - REQ-4700: 205 días
  - REQ-4704: 192 días
  - REQ-4701: 152 días
  - REQ-4712: 108 días
  - REQ-4710: 98 días
  - REQ-4708: 91 días
  - REQ-4715: 87 días

  La facultad de decidir es del Comité de producto. Se propone decidirlos, no cerrarlos por viejos.
- **Evidencia vieja (10 requerimientos):** descansan en la misma cita de la entrevista del 2025-10-10, que ya tiene 12 meses.

Aparte, el caso de negocio declara un volumen mensual de 108.635 y el tablero mide 76.086. Es una brecha del 30%, por encima del umbral de 20%. El criterio de éxito de la definición no está dicho en ninguna parte.

Para `/product-charter`, REQ-4709 y REQ-4711 tienen evidencia y criterio, aunque la evidencia ya es vieja. REQ-4714 también, pero no tiene doliente.

La corrida quedó registrada como `2026-10-17-product-requirements-1`: 36 hallazgos en 35 segundos. El texto completo está en `estado-producto/PRD-307/corridas/salida-product-requirements.md`.
