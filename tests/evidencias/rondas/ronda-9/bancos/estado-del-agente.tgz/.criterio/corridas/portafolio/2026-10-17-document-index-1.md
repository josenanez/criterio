# Corrida · 2026-10-17-document-index-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:document-index (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T20:37:42 · **Fin:** 2026-10-17T20:38:06 · **Duración:** 25 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `document-index` | 13 | — | 14 | 58 | 71 documentos, ninguno cambió; 0 por releer. 14 citas de PRY-200 no resuelven (acta, cronograma e informe de avance ausentes). No verifiqué en disco que esos archivos falten; me apoyo en el índice. Formatos ilegibles: el índice no reportó ninguno. |

Por señal (`document-index`): `milestone_met_without_evidence` 14, `commitment_overdue` 11, `declared_vs_evidence` 8, `progress_vs_plan` 7, `milestone_overdue` 3, `variance_cost` 3, `commitment_undated` 3, `vendor_deliverable_late` 3, `commitment_rescheduled` 2, `silent` 2, `variance_time` 1, `change_without_baseline` 1

## Lo que el agente mostró

Ninguno de los 71 documentos cambió, así que no hay nada que releer. Aun así, 14 citas de PRY-200 ya no resuelven.

Los términos ya estaban vigentes (v1.1), aceptados por José Francisco Ñáñez el 2026-10-17. No hizo falta registrarlos de nuevo.

- **Sin cambio:** 71 de 71.
- **Por releer:** 0. No hay documentos reguardados, renombrados ni borrados, y `projects_to_recompute` está vacío.
- **Citas rotas:** son 14 campos de PRY-200, que citan documentos que el índice no encuentra:
  - **`2026-05-28-acta-constitucion.docx`:** respalda los campos de identidad, el inicio, el alcance y el presupuesto aprobado.
  - **`2026-05-28-cronograma-v1.xlsx`:** respalda la fecha de fin.
  - **`2026-10-17-informe-avance.md`:** respalda lo comprometido, lo ejecutado y la proyección.
- **Qué falta resolver:** el informe sigue mostrando esos datos como sustentados y ya no lo están. Hay que reponer los tres archivos o retirar las citas.
- **Qué no verifiqué:** no comprobé en disco que esos archivos falten. Me apoyo en lo que dice el índice.
- **Formatos ilegibles:** el índice no reportó ninguno.

No ofrezco `/portfolio-scan` porque no hay proyectos tocados, ni corregir citas por renombrado porque no hay renombrados.

La corrida quedó registrada como `2026-10-17-document-index-1`, con la salida guardada en `estado/corridas/salida-document-index.md`. Tardó 14 segundos.
