# Corrida · 2026-10-17-product-spec-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-spec (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T20:20:15 · **Fin:** 2026-10-17T20:21:27 · **Duración:** 72 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-spec` | 16 | — | 58 | 36 | Borrador sobre 9 aceptados (7 propuestos fuera). Comportamiento no redactado: ningún REQ trae need ni título real. Criterio 'se verifica en producción' no verificable en 7; 2 sin criterio. Barrido normativo: país no dicho, sin norma a la vista. No supo: problema de cada REQ, país, quién decidió, plan, equipos externos. |

Por señal (`product-spec`): `evidence_stale` 10, `requirement_untraced` 9, `requirement_undecided` 7, `requirement_accepted_without_evidence` 5, `requirement_without_acceptance` 2, `requirement_without_owner` 2, `claim_vs_metric` 1

## Lo que el agente mostró

**Borrador de especificación de PRD-307 (Remesas familiares), listo, pero sin la sección de comportamiento.** Ninguno de los 9 requerimientos aceptados dice qué problema resuelve. Todos tienen el título «Requerimiento REQ-47xx» y ninguno trae la necesidad, así que escribir comportamiento habría sido inventarlo. Felipe Arango tiene que cerrarlo.

Los términos ya estaban vigentes, aceptados por José Francisco Ñáñez el 2026-10-17, así que no los volví a registrar.

- **Alcance:** entran los 9 requerimientos aceptados. Quedan fuera los 7 que siguen en `propuesto`. Ninguno está en construcción.
- **Criterios de aceptación:**
  - Siete dicen solo «se verifica en producción», que no se puede verificar ni medir hoy.
  - Dos (REQ-4702 y REQ-4705) no tienen criterio.
  - Los transcribí tal cual, sin reemplazarlos por uno razonable.
- **Supuesto de la definición** («la regulación vigente lo permite»): figura como verificado, pero el anexo solo dice «se confirmó». No trae dato, norma ni país.
- **Vacíos señalados, cada uno con su dueño (12 en total).** Los más graves:
  - REQ-4714 está aceptado sin doliente.
  - Cinco aceptados no tienen evidencia de demanda.
  - Los demás citan una misma frase anónima de una entrevista de hace más de 12 meses.
  - Ninguno tiene proyecto que lo construya.
  - El acta no dice quién decidió, y su único acuerdo es «Se mantiene el plan», sin plan en los documentos.
  - El volumen mensual declarado (108.635) está 30 % por encima del medido (76.086).
- **Barrido normativo:** la definición no dice el país y no tengo ninguna norma a la vista, así que todas las filas quedan como «no tengo la norma a la vista». No inventé ninguna cita.
- **Requerimientos aceptados sin cubrir:** los 9 están en el alcance solo por su ID, sin comportamiento.
- **`/product-charter`:** no lo ofrezco todavía, porque siguen abiertos los vacíos de necesidad, criterio, doliente y proyecto.

La corrida quedó registrada: 16 requerimientos leídos, 36 hallazgos, 58 segundos.

Archivos en `/home/claude/banco/ronda-9/bancos/espacio/estado-producto/PRD-307/corridas/`:
- salida-product-spec.md
- 2026-10-17-product-spec-1.md
