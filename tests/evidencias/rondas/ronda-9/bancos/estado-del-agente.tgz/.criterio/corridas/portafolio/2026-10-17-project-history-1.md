# Corrida · 2026-10-17-project-history-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-history PRY-203

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-203

**Inicio:** 2026-10-17T20:43:02 · **Fin:** 2026-10-17T20:44:14 · **Duración:** 72 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-history` | 13 | — | 56 | 58 | Historia de PRY-203 sobre 6 documentos: 1 replanificación (114 días, 46.2 % vs original) sin motivo ni acta de aprobación; no se calcula meses sin sustento (un solo informe); no se sabe el motivo, quién autorizó CC-01 ni qué pasó en 2026-T2. |

Por señal (`project-history`): `milestone_met_without_evidence` 14, `commitment_overdue` 11, `declared_vs_evidence` 8, `progress_vs_plan` 7, `milestone_overdue` 3, `variance_cost` 3, `commitment_undated` 3, `vendor_deliverable_late` 3, `commitment_rescheduled` 2, `silent` 2, `variance_time` 1, `change_without_baseline` 1

## Lo que el agente mostró

Terminé la historia de PRY-203 Open Banking y dejé la corrida registrada. Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17), así que no los registré de nuevo.

Leí los 6 documentos del proyecto, entre 2026-03-24 y 2026-10-17. No hay ningún documento entre abril y junio de 2026.

**En una línea:** el cronograma v2 del 2026-09-23 movió el piloto del 2026-12-06 al 2027-03-30, y ese mismo día el informe de avance declaró verde, 60%, sin mencionarlo. La solicitud de cambio CC-01, que dice "Autorizada por el comité", es del 2026-10-14. Ningún acta de comité la respalda.

**Las cuatro cifras:**

| Cifra | Valor |
|---|---|
| Replanificaciones | 1, sin motivo documentado |
| Atraso acumulado contra la original | 114 días (46.2%) |
| Meses declarando sin sustento | No calculable: hay un solo informe declarado, sin serie |
| Cambios de gobierno | 0 documentados |

- **Hitos sin evidencia:** "Diseño funcional aprobado" y "Ambiente de pruebas certificado" figuran como cerrados sin acta de recibo. "Integración con el core" venció el 2026-10-05 y lleva 12 días de atraso.
- **Cronograma v1:** está fechado el 2026-03-24 pero marca como cerrados dos hitos que eran futuros en esa fecha. Hay que confirmar con quien conserva el archivo si se editó después.
- **Dependencia del core:** el acta dice "Ninguna declarada" en dependencias, y el informe del 2026-09-23 cita la dependencia del calendario de liberaciones del core.
- **Compromisos:** solo hay uno (Carlos Peña, "Entregar el punto 21", 2026-11-13), y ese punto no está definido en ningún documento.

**Lo que no sé:** por qué se replanificó, quién autorizó CC-01 y cuándo, qué pasó entre abril y septiembre, y si CC-01 es el mismo movimiento de 114 días del cronograma v2 o uno adicional. El texto de CC-01 dice "sobre la línea base vigente", que ya incluía esos días. No atribuyo intención a nadie.

En el registro de la corrida, `documentos` y `relectura` quedaron en `null`: el script no los midió.

Puedo llevar esta historia al comité, con la decisión pendiente sobre CC-01 y el acta que falta. No lo hice porque no me lo pidieron.

Archivos en `/home/claude/banco/ronda-9/bancos/espacio/estado/corridas/`:
- `salida-project-history.md`
- `2026-10-17-project-history-1.md`
