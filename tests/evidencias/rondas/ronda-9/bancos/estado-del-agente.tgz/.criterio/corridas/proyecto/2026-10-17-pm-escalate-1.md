# Corrida · 2026-10-17-pm-escalate-1

**Agente:** Samuel (proyecto) · **Comando:** `/criterio-project:pm-escalate (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T20:30:01 · **Fin:** 2026-10-17T20:31:05 · **Duración:** 64 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `pm-escalate` | 1 | — | 48 | 16 | Dos puntos: autoridad no declarada en el acta, y proyección 15,9 % sobre el aprobado con estado Verde. No sabe: autoridad, costo de recortar o replanificar, fecha de vencimiento, quién usa el calendario del core. Impacto calculado con 12 días de atraso del hito, no un cambio solicitado. |

Por señal (`pm-escalate`): `commitment_overdue` 8, `commitment_undated` 3, `commitment_rescheduled` 2, `milestone_overdue` 1, `variance_cost` 1, `declared_vs_evidence` 1

## Lo que el agente mostró

Armé el paquete de escalamiento de PRY-200 y dejé la corrida registrada. Salieron dos puntos, en este orden.

Los términos ya estaban vigentes (v1.1, José Francisco Ñáñez, 2026-10-17), así que no los registré de nuevo.

1. **Autoridad de la gerente.**
   - El acta del 2026-05-28 no declara qué puede decidir Diana Molina, así que este es el primer punto que escala.
   - La pregunta que va al comité es si se enmienda el acta con la autoridad escrita. Recomiendo que sí.
   - El acta tampoco declara dependencias («Ninguna declarada»), aunque el informe menciona la dependencia del calendario de liberaciones del core.
2. **Presupuesto.**
   - La proyección al cierre es de 20.859.955.929 COP, 2.859.955.929 sobre los 18.000 M aprobados (+15,9 %, con umbral de 10 %). El informe se declara Verde.
   - Recomiendo aplazar la decisión hasta el ajuste de presupuesto que Laura Vélez prometió «la otra semana» (sin fecha) y llevarla al comité del 2026-10-31.

Hay varias cosas que los documentos no dicen, y las dejé declaradas en lugar de inventarlas:
- el costo de recortar alcance o replanificar;
- la fecha en que vence cualquiera de las dos decisiones;
- qué otros proyectos usan el calendario del core.

El impacto sobre otros proyectos salió vacío, porque no hay otros en el estado ni dependencias declaradas. Eso no prueba que no haya impacto. Ningún punto propone mover una fecha, así que para el cálculo usé 12 días, el atraso ya acumulado del hito «Diseño funcional aprobado» (2026-10-05, sin evidencia). Los hitos por los que pasa son «Ambiente de pruebas certificado» (109 días) e «Integración con el core» (230 días).

No escalé dos compromisos con reprogramación repetida: «Enviar el documento 1» de Elena Duarte (6 veces, hoy 2026-12-05) y «Cerrar la prueba 2» de Ricardo Salas (4 veces, hoy 2026-11-20). Su doliente está dentro del proyecto, así que son llamadas de la gerente. También quedó anotado el riesgo del proveedor que se dijo en reunión y nadie registró.

Archivos en `/home/claude/banco/ronda-9/bancos/espacio/estado/PRY-200-originación-digital/corridas/`:
- `salida-pm-escalate.md`
- `2026-10-17-pm-escalate-1.md`
