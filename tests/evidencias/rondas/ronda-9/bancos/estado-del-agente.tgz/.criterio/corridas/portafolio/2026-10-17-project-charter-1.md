# Corrida · 2026-10-17-project-charter-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-charter PRY-211 revisar

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-211

**Inicio:** 2026-10-17T20:46:00 · **Fin:** 2026-10-17T20:46:44 · **Duración:** 44 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-charter` | 13 | — | 29 | 58 | Revisión del acta de PRY-211: falta la autoridad del gerente (la CC-01 quedó sin criterio de ruta), objetivo no medible, alcance con marcadores vacíos, sin hitos ni cadencia, dependencia del core no declarada en el acta, línea base vencida sin replanificar. No sé si hay autoridad delegada fuera de los documentos ni qué amplía la CC-01. Informe de avance leído desde el caché de texto. |

Por señal (`project-charter`): `milestone_met_without_evidence` 14, `commitment_overdue` 11, `declared_vs_evidence` 8, `progress_vs_plan` 7, `milestone_overdue` 3, `variance_cost` 3, `commitment_undated` 3, `vendor_deliverable_late` 3, `commitment_rescheduled` 2, `silent` 2, `variance_time` 1, `change_without_baseline` 1

## Lo que el agente mostró

Revisé el acta de PRY-211 y la corrida quedó registrada como `2026-10-17-project-charter-1`. Hay un acta previa, del 2025-06-28, aprobada por el Comité de Riesgos. Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17), así que no los registré otra vez.

Lo que falta en el acta y lo que eso provoca:

- **Autoridad del gerente:** no está escrita. Por eso la solicitud de cambio CC-01 (+232.000.000 COP, +116 días, ampliación de alcance) quedó pendiente del comité. Sin ese límite no se sabe si Natalia Ospina podía resolverla sola.
- **Objetivo de negocio:** dice "Entregar cobranza digital para Banca PyME", que es la solución y no un resultado. Nadie puede decir si el proyecto sirvió aunque entregue.
- **Alcance:** solo dice "Componente 1, 2, 3", sin contenido. Tampoco se puede saber qué amplía la CC-01.
- **Exclusiones:** "Lo que otro proyecto cubre", sin nombrar cuál.
- **Supuestos, restricciones, hitos y cadencia del comité:** no aparecen.
- **Criterio de éxito:** "en producción y medido", sin métrica ni quién la mide.
- **Dependencias:** el acta dice "Ninguna", pero el informe del 2026-10-15 reporta una del calendario de liberaciones del core.
- **Línea base:** el cierre pactado era el 2026-01-27 y sigue siendo la única línea base, sin replanificar. La CC-01 se mide "sobre la línea base vigente", y esa ya venció.

El patrocinador sí tiene nombre (Javier Hoyos).

Lo que no sé: si hay una autoridad delegada fuera de estos documentos, qué contienen los componentes y qué amplía la CC-01. Leí el informe de avance desde el texto convertido del PDF, no desde el original.

Dejé dos ofrecimientos, sin ejecutarlos:
- Llevar la definición de autoridad al Comité de Riesgos junto con la CC-01.
- Pasar dos supuestos al registro RAID: que el core libera según un calendario que el proyecto no controla, y que otro proyecto cubre lo excluido.

El resultado completo está en `estado/corridas/salida-project-charter.md`.

La corrida contó 13 proyectos y 58 hallazgos en todo el portafolio, y ninguno de ellos es de PRY-211. Esas cifras salen de las fichas existentes, no de esta revisión del acta.
