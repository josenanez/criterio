# Corrida · 2026-10-17-portfolio-scan-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-scan (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T20:35:26 · **Fin:** 2026-10-17T20:37:37 · **Duración:** 131 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-scan` | 13 | 71 | 115 | 58 | 10 fichas nuevas (PRY-199, 202, 204 a 211); nada movido ni omitido; sin carpeta entrada/. Mirar: hitos cerrados sin acta en 202, 206, 207, 210; entregables vencidos de proveedor en 205 y 210; CC-01 de PRY-211 pendiente; PRY-208 y 209 en silencio; 208, 209 y 211 sin cronograma. |

Por señal (`portfolio-scan`): `milestone_met_without_evidence` 14, `commitment_overdue` 11, `declared_vs_evidence` 8, `progress_vs_plan` 7, `milestone_overdue` 3, `variance_cost` 3, `commitment_undated` 3, `vendor_deliverable_late` 3, `commitment_rescheduled` 2, `silent` 2, `variance_time` 1, `change_without_baseline` 1

## Lo que el agente mostró

El barrido terminó: leí 44 de los 71 documentos, escribí y sellé 10 fichas nuevas, y los otros 27 no habían cambiado. Registré la corrida con `portafolio.py corrida` (id `2026-10-17-portfolio-scan-1`) y tomé la instantánea.

Los términos ya estaban vigentes, aceptados por José Francisco Ñáñez el 2026-10-17, así que no hubo que registrarlos de nuevo. La configuración existía y no inventé nada.

- **Proyectos con ficha nueva:** PRY-199, 202 y 204 a 211. PRY-200, 201 y 203 no se tocaron. No hay archivos ilegibles ni carpeta `entrada/`.
- **Contradicciones entre documentos:** ninguna.
- **Hitos cerrados sin acta de recibo:** 202, 206, 207 y 210. En 210 son cuatro.
- **Compromisos vencidos:** 204, 205 y 210. En 210 el de Andrés Lozano lleva 22 días vencido.
- **Entregables de proveedor vencidos sin entregar:** 205 (uno) y 210 (dos).
- **Sin documentos recientes:** 208 lleva 17 días y 209 lleva 21.
- **Cierre comprometido ya pasado:** 207, 209 y 211.
- **Proyección sobre el presupuesto:** 202 en 27,6% y 207 en 22%.
- **Solicitud de cambio CC-01 de PRY-211:** pide +116 días y +232.000.000 COP, y sigue pendiente del comité.
- **Sin cronograma:** 208, 209 y 211, así que no hay hitos que medir.
- **PRY-199:** no tiene señales.
- **Facturación de PRY-210:** la factura FV-1882 cuadra con los dos entregables que sí tienen acta.
- **Campos sin dato:** la autoridad y la fase no están en ningún acta y quedan `not_found` en los 10 proyectos. El producto también queda vacío en 202, 205, 208 y 210, porque el acta dice «No aplica».
- **Fechas nuevas de salida:** los informes de 210 y 211 dicen «se reprogramó la salida» pero no dan la fecha nueva. Dejé la comprometida y no inventé otra.
- **Compromisos con fecha anterior a su minuta:** los de 204, 205 y 210 vencían antes de la minuta que los registra. Los guardé como vencidos, con la fecha tal como está escrita.
- **Estado de los entregables:** guardé «en curso» como pendiente en el entregable de proveedor y «recibido» como aceptado.
- **Scripts encadenados:** corrí los `sellar` de 205 a 207 y de 208 a 211 en un bucle por llamada, no uno por llamada como pide la plantilla.

La salida completa está en `estado/corridas/salida-portfolio-scan.md`. El siguiente paso natural es `/portfolio-report`, con estas contradicciones y compromisos vencidos ya a la vista.
