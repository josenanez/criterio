# Corrida · 2026-10-17-product-trace-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-trace (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T20:52:49 · **Fin:** 2026-10-17T20:53:35 · **Duración:** 46 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-trace` | 16 | — | 32 | 36 | 9 requerimientos aceptados el 2026-10-16 sin proyecto; ninguna de las 13 fichas nombra PRD-307 |

Por señal (`product-trace`): `evidence_stale` 10, `requirement_untraced` 9, `requirement_undecided` 7, `requirement_accepted_without_evidence` 5, `requirement_without_acceptance` 2, `requirement_without_owner` 2, `claim_vs_metric` 1

## Lo que el agente mostró

## Trazabilidad — Remesas familiares (PRD-307) · al 2026-10-17

**9 requerimientos decididos, ninguno con proyecto.** Tampoco hay trazas confirmadas ni entregados.

Los términos ya estaban vigentes a nombre de José Francisco Ñáñez (2026-10-17), así que no los registré otra vez. Leí las 13 fichas de `estado/records` (PRY-199 a PRY-211).

- **Decidido y nadie lo construye:** REQ-4702, 4703, 4705, 4706, 4707, 4709, 4711, 4713 y 4714 se aceptaron el 2026-10-16 y ninguno tiene proyecto. El acta del comité deja «—» en la columna de proyecto de todos. La cadena se rompe en la decisión. La única que consta es «Se mantiene el plan», que no nombra ningún requerimiento ni proyecto.
- **Trazas sin confirmar:** ninguna. Ningún requerimiento declara un proyecto, así que no hay nada que contrastar con las fichas.
- **Lo que un proyecto construye y el registro no tiene:** nada. Ninguna de las 13 fichas nombra PRD-307 ni «Remesas familiares». Cuatro de ellas tienen vacío el campo de producto. Eso es un hallazgo del lado de esos proyectos, y desde aquí no puedo saber si alguna construye remesas.
- **Propuestos:** los otros 7 requerimientos (REQ-4700, 4701, 4704, 4708, 4710, 4712 y 4715) no están decididos y no entran en la cadena. Llevan entre 87 y 205 días sin decidirse.

El siguiente paso es `/criterio-product:product-charter` para el requerimiento que ya esté listo para volverse proyecto.

La corrida quedó registrada como `2026-10-17-product-trace-1`: 36 hallazgos en 32 segundos. Lo que te mostré está en `estado-producto/PRD-307/corridas/salida-product-trace.md`.
