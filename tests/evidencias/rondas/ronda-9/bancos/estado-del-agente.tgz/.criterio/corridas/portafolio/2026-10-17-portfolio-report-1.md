# Corrida · 2026-10-17-portfolio-report-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-report html

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T20:49:53 · **Fin:** 2026-10-17T20:50:46 · **Duración:** 53 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-report` | 13 | 71 | 39 | 58 | 8 de 13 proyectos declaran verde con señales en contra; PRY-200, 202 y 210 son los más cargados. Primera instantánea, sin delta. |

Por señal (`portfolio-report`): `milestone_met_without_evidence` 14, `commitment_overdue` 11, `declared_vs_evidence` 8, `progress_vs_plan` 7, `milestone_overdue` 3, `variance_cost` 3, `commitment_undated` 3, `vendor_deliverable_late` 3, `commitment_rescheduled` 2, `silent` 2, `variance_time` 1, `change_without_baseline` 1

## Lo que el agente mostró

Generé el informe HTML de portafolio y registré la corrida. Estaba por cerrar con el resumen.

**Términos:** ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17), así que no los registré de nuevo.

**Fichas:** cargué 13 (PRY-199 a PRY-211), todas del barrido de hoy. Están en `estado/records/`, no en `estado/fichas/`, y usé la carpeta que existe.

**Dónde quedó el informe:** `/home/claude/banco/ronda-9/bancos/espacio/reportes`, con 26 páginas.
- `index.html` es la vista por campo, con la cadena de evidencia. Va para quien actúa: el gerente de PMO y los gerentes de proyecto.
- `decisiones.html` es la vista por decisión, solo con lo que excede la facultad de quien gerencia. Va para el patrocinador y el comité del 2026-10-24.
- El PDF sale de imprimir el HTML.

**Lo que muestra:**
- **Qué cambió:** nada. Es la primera instantánea y el diff dio 0 cambios, así que no hay delta.
- **Señales:** 58 en 11 de los 13 proyectos.
- **Verdes contradichos:** 8 proyectos declaran verde y las señales no lo sostienen. Los más cargados son PRY-200 (16 señales), PRY-210 (10) y PRY-202 (5).
- **Sobrecosto:** PRY-202 proyecta +27,6 %, PRY-207 +22 % y PRY-200 +15,9 % sobre lo aprobado.
- **Silencio:** PRY-209 lleva 21 días y PRY-208 lleva 17.
- **Sin contradicciones entre fuentes ni dependencias entre proyectos:** ninguna ficha las declara.
- **Vacíos:** autoridad y fase faltan en los 13 proyectos, y 4 no tienen producto asociado.
- **Fechas de fin vencidas:** PRY-207, PRY-209 y PRY-211 ya pasaron su fecha de fin y no registran replanificación. Hay que confirmar si cerraron o si la fecha quedó sin actualizar.
- **Confirmación del mes:** no toca todavía.

La corrida quedó registrada como `2026-10-17-portfolio-report-1`, con el texto completo en `estado/corridas/salida-portfolio-report.md`. Tardó 39 segundos y no hubo que releer ningún documento (71 sin cambios).

Puedo preparar el material de comité del 2026-10-24 o entrar al detalle de PRY-200, PRY-210 o PRY-202.
