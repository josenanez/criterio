# Corrida · 2026-10-17-product-charter-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-charter REQ-4702

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** REQ-4702

**Inicio:** 2026-10-17T20:21:32 · **Fin:** 2026-10-17T20:22:17 · **Duración:** 45 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-charter` | 16 | — | 30 | 36 | Borrador de acta para REQ-4702, sin firmar y sin ficha creada. Marca vacíos: criterios de aceptación, evidencia de demanda, autoridad, patrocinador, quién decidió, criterio de éxito, norma. Supuesto regulatorio con verificación débil; volumen declarado 108635 contra medido 76086, brecha de unos 30 %. |

Por señal (`product-charter`): `evidence_stale` 10, `requirement_untraced` 9, `requirement_undecided` 7, `requirement_accepted_without_evidence` 5, `requirement_without_acceptance` 2, `requirement_without_owner` 2, `claim_vs_metric` 1

## Lo que el agente mostró

Dejé escrito el borrador del acta de REQ-4702, pero está sin firmar y no creé la ficha del proyecto. REQ-4702 está aceptado, pero le faltan casi todos los datos que el acta necesita, y los marqué como vacíos en vez de rellenarlos.

Los términos ya estaban vigentes (versión 0.4.0, aceptados por José Francisco Ñáñez el 2026-10-17), así que no los registré de nuevo. La corrida quedó registrada como `2026-10-17-product-charter-1`.

**Lo que falta en el requerimiento.** Tomé la respuesta sugerida, que era seguir sin esos datos y marcarlos como vacío:
- **Criterios de aceptación:** no hay.
- **Evidencia de demanda y quién lo pidió:** no hay.
- **Autoridad del gerente:** ningún documento la declara. "Comité de producto" viene solo de la configuración. El acta del comité (2026-10-16) lista a Felipe Arango como único asistente y no dice quién decidió aceptar el requerimiento.
- **Criterio de éxito, patrocinador, presupuesto e hitos:** tampoco están dichos.

**Alcance.** Entra solo REQ-4702. Los demás requerimientos del producto quedan fuera, con la razón. Los propuestos siguen sin decisión del gerente de producto. Los otros aceptados no son parte de esta acta.

**Otros hallazgos del borrador:**
- **Supuesto de regulación:** el supuesto "La regulación vigente lo permite" figura como verificado con la medición de un piloto. El anexo solo dice "se confirmó", sin norma ni dato, así que lo traté como poco sustentado. Ningún documento cita una norma, y no inventé una.
- **Volumen mensual:** el caso de negocio declara 108.635 y el tablero mide 76.086, una brecha de unos 30 %. El umbral configurado es 20 %.

**Qué sigue.** Alguien con autoridad, que hoy ningún documento nombra, tiene que cerrar los vacíos y firmar. Después el gerente del proyecto instala `criterio-project` y corre `/pm-setup`. Solo entonces se crea la ficha, y el estado declarado queda para ese gerente.

El acta completa está en `/home/claude/banco/ronda-9/bancos/espacio/estado-producto/PRD-307/corridas/salida-product-charter.md`.
