# Corrida · 2026-10-17-pm-commitments-1

**Agente:** Samuel (proyecto) · **Comando:** `/criterio-project:pm-commitments (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T20:25:59 · **Fin:** 2026-10-17T20:26:44 · **Duración:** 45 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `pm-commitments` | 1 | — | 28 | 16 | Elena Duarte (6 reprogramaciones) y Ricardo Salas (4) pasan el umbral; 8 vencidos sin evidencia, 3 de Carlos Peña; informe declara verde |

Por señal (`pm-commitments`): `commitment_overdue` 8, `commitment_undated` 3, `commitment_rescheduled` 2, `milestone_overdue` 1, `variance_cost` 1, `declared_vs_evidence` 1

## Lo que el agente mostró

## Compromisos — PRY-200 Originación digital · al 2026-10-17

Hay 21 compromisos abiertos: 8 vencidos sin evidencia, 2 reprogramados más allá del umbral, 3 sin fecha, 3 que vencen esta semana y 5 con fecha futura. Otros 5 están cerrados con documento. Los términos ya estaban vigentes a nombre de José Francisco Ñáñez, así que no registré nada nuevo.

**Se viene reprogramando**
- **Elena Duarte, «Enviar el documento 1».** Lo prometió para el 09-25 y lo ha movido seis veces, hasta el 12-05. Seis veces no es seguimiento: es un bloqueo que nadie ha nombrado. Las notas de hoy dicen «05/12/2026»; lo leí como día/mes y conviene confirmarlo con ella.
- **Ricardo Salas, «Cerrar la prueba 2».** Su primera fecha fue el 09-20 y la ha movido cuatro veces, hasta el 11-20. Es el mismo caso de bloqueo sin nombrar.

**Vencidos sin evidencia** (ninguno tiene acta ni entregable en el expediente):

| Quién | Qué | Hace |
|---|---|---|
| Sandra Gil | Validar el ambiente 12 | 25 días |
| Carlos Peña | Validar el ambiente 4 | 22 días |
| Felipe Arango | Revisar el anexo 11 | 18 días |
| María Restrepo | Aprobar el diseño 13 | 11 días |
| Gustavo Neira | Cerrar la prueba 18 | 9 días |
| Carlos Peña | Entregar el punto 8 | 7 días |
| Gustavo Neira | Confirmar la fecha 7 | 3 días |
| Carlos Peña | Confirmar la fecha 15 | 2 días |

- **Gustavo Neira:** dijo el 09-26 que «la fecha 7» ya estaba entregada, pero no hay acta que lo respalde. Sigue abierto.
- **Carlos Peña:** tiene tres de los ocho vencidos.

**Vencen esta semana**
- Elena Duarte, «Validar el ambiente 20», vence hoy.
- Mauricio Pérez, «Aprobar el diseño 21», vence el 10-20.
- Paula Céspedes, «Actualizar la matriz 22», vence el 10-24.

**Sin fecha** (no pueden estar vencidos, por eso se cuentan aparte)
- **Liliana Torres, «Actualizar la matriz 14».** Dijo el 10-03 que ya entregó, pero no hay acta. Sigue abierto.
- **María Restrepo, «Entregar el punto 24».**
- **Laura Vélez, «Mandar el ajuste del presupuesto».** Dijo «la otra semana» y nadie puso fecha.

**Contra el informe de avance:** hoy declara verde. Frente a eso están los compromisos vencidos y reprogramados, el hito «Diseño funcional aprobado» (vencía el 10-05, sin evidencia) y una proyección de costo 15,9 % sobre lo aprobado.

**Siguientes pasos, si los quieres:**
- Puedo formular los casos de Elena Duarte y Ricardo Salas como decisión para el comité: qué se pide, qué pasa si no se decide y quién tiene la facultad.
- Puedes correr `/pm-publish` para que la PMO vea lo que cambió en la ficha.

La corrida quedó registrada como `2026-10-17-pm-commitments-1`. El texto completo está en `estado/PRY-200-originación-digital/corridas/salida-pm-commitments.md`.
