# Corrida · 2026-10-17-vendor-tracking-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:vendor-tracking PRY-205

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-205

**Inicio:** 2026-10-17T20:41:05 · **Fin:** 2026-10-17T20:41:44 · **Duración:** 39 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `vendor-tracking` | 13 | — | 23 | 58 | Cruce de CT-172 (Núcleo Financiero) de PRY-205: 3 entregables, 0 aceptados, 1 vencido sin evidencia (licenciamiento, 25 días). Sin dato: facturado, vigencia y preaviso del contrato; quién es Laura Vélez. |

Por señal (`vendor-tracking`): `milestone_met_without_evidence` 14, `commitment_overdue` 11, `declared_vs_evidence` 8, `progress_vs_plan` 7, `milestone_overdue` 3, `variance_cost` 3, `commitment_undated` 3, `vendor_deliverable_late` 3, `commitment_rescheduled` 2, `silent` 2, `variance_time` 1, `change_without_baseline` 1

## Lo que el agente mostró

## Proveedores — PRY-205 Prevención de lavado de activos al 2026-10-17

**Sale de:** el contrato CT-172, el acta de constitución, el cronograma v1, el acta de recibo del 2026-10-08, el informe de avance del 2026-10-14, el comité del 2026-10-15 y la salida de `compute`. Los términos están vigentes y los aceptó José Francisco Ñáñez el 2026-10-17.

### Núcleo Financiero S.A. (CT-172)

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento del motor | 2026-09-22 · COP 90.410.166 | `pending` | ninguna | sin dato |
| Bolsa de horas de desarrollo | 2027-01-06 · COP 90.410.166 | `pending` | ninguna | sin dato |
| Parametrización del tarifario | 2027-04-22 · COP 90.410.166 | `pending` | ninguna | sin dato |

- **Aceptados:** 0 de 3.
- **Atrasado:** el licenciamiento lleva 25 días vencido y no hay acta ni mención de entrega.
- **Sin evidencia de recibo:** ninguno está declarado como entregado o aceptado, así que no hay entregables aceptados sin evidencia.

### Dónde no cuadra
- **Estados del contrato:** la bolsa de horas y la parametrización figuran "en curso" en el contrato, pero ningún documento muestra trabajo ni recibo. Quedan como `pending`.
- **Avance contra plan:** el informe del 2026-10-14 declara verde y 82%, pero el plan sustenta entre 20% y 40% (1 de 5 hitos cumplidos, brecha de 42 puntos).
- **Condición de pago:** CT-172 exige acta de recibo firmada por el gerente para facturar cada entregable. La única acta de la carpeta es del hito interno "Diseño funcional aprobado", no de un entregable del proveedor.

### Compromisos vencidos
Laura Vélez prometió "Entregar el punto 31" para el 2026-10-11, y lleva 6 días vencido. Ningún documento dice que sea del proveedor ni qué es el "punto 31". Lo incluyo porque es el único compromiso vencido del proyecto. El proveedor no asistió al comité.

### Sin dato
- **Facturado:** no hay ningún documento que lo declare. Por eso no se pudo cerrar el cruce contra lo entregado.
- **Contrato:** no trae vigencia, renovación ni preaviso. No puedo decir si hay un preaviso por vencer.
- **Ficha:** faltan producto, autoridad y fase del proyecto.

### Qué sigue
- Pedirle a Óscar Ramírez (gerente) que diga si el licenciamiento se entregó. Si sí, que muestre el acta; si no, que traiga una fecha nueva del proveedor.
- Pedirle a Finanzas lo facturado a CT-172.
- Pedir el contrato completo, con las cláusulas de vigencia y renovación.
- El proyecto reporta verde con tres señales abiertas sin explicar: avance contra plan, compromiso vencido y entregable del proveedor vencido. Esa discrepancia es lo que ofrezco llevar a comité.

*Las cifras vienen de `portafolio.py compute`, y lo que los documentos no traen aparece como "sin dato". No sé nada de lo que se habló fuera de ellos. La verificación es suya.*

La corrida quedó registrada como `2026-10-17-vendor-tracking-1`, con la salida guardada en `estado/corridas/salida-vendor-tracking.md`.
