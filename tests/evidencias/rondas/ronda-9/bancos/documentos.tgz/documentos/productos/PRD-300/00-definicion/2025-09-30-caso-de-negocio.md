# Caso de negocio · Pagos QR comercios

**Código:** PRD-300
**Fecha:** 2025-09-30
**Preparado por:** Jorge Medina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 235.239 | Caso de negocio, 2025-09-30 |

## Retorno esperado

Retorno esperado en 24 meses.
