# Caso de negocio · Cuenta de ahorros joven

**Código:** PRD-308
**Fecha:** 2026-07-21
**Preparado por:** Rubén Cárdenas

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 286.261 | Caso de negocio, 2026-07-21 |

## Retorno esperado

Retorno esperado en 24 meses.
