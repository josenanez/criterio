# Caso de negocio · Crédito hipotecario digital

**Código:** PRD-302
**Fecha:** 2025-10-25
**Preparado por:** Sandra Gil

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 98.693 | Caso de negocio, 2025-10-25 |

## Retorno esperado

Retorno esperado en 24 meses.
