# Caso de negocio · Cuenta PyME

**Código:** PRD-303
**Fecha:** 2025-09-26
**Preparado por:** Óscar Ramírez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 203.364 | Caso de negocio, 2025-09-26 |

## Retorno esperado

Retorno esperado en 24 meses.
