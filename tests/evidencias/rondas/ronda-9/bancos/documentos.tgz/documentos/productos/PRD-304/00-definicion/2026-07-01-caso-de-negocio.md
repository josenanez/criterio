# Caso de negocio · Tarjeta de crédito digital

**Código:** PRD-304
**Fecha:** 2026-07-01
**Preparado por:** Óscar Ramírez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 205.582 | Caso de negocio, 2026-07-01 |

## Retorno esperado

Retorno esperado en 24 meses.
