# Comité de producto · Cuenta PyME

**Fecha:** 2026-10-12
**Asistentes:** Óscar Ramírez

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4300 | Requerimiento REQ-4300 | Liliana Torres | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-20 | — |
| REQ-4301 | Requerimiento REQ-4301 | Liliana Torres | se verifica en producción | — | aceptado | 2026-09-01 | — |
| REQ-4302 | Requerimiento REQ-4302 | Rubén Cárdenas | — | Cliente entrevistado | aceptado | 2026-05-29 | — |
| REQ-4303 | Requerimiento REQ-4303 | Natalia Ospina | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-23 | — |
| REQ-4304 | Requerimiento REQ-4304 | sin asignar | — | — | aceptado | 2026-04-10 | — |
| REQ-4305 | Requerimiento REQ-4305 | Camilo Beltrán | se verifica en producción | Cliente entrevistado | propuesto | 2026-08-10 | — |
| REQ-4306 | Requerimiento REQ-4306 | Natalia Ospina | — | Cliente entrevistado | aceptado | 2026-05-07 | — |
| REQ-4307 | Requerimiento REQ-4307 | Gustavo Neira | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-20 | — |
| REQ-4308 | Requerimiento REQ-4308 | sin asignar | — | — | propuesto | 2026-04-18 | — |
| REQ-4309 | Requerimiento REQ-4309 | Elena Duarte | — | Cliente entrevistado | aceptado | 2026-05-18 | — |
| REQ-4310 | Requerimiento REQ-4310 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-29 | — |
| REQ-4311 | Requerimiento REQ-4311 | Carlos Peña | — | Cliente entrevistado | propuesto | 2026-04-17 | — |
| REQ-4312 | Requerimiento REQ-4312 | Sandra Gil | se verifica en producción | — | aceptado | 2026-05-06 | — |
| REQ-4313 | Requerimiento REQ-4313 | Rubén Cárdenas | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-08 | — |
| REQ-2028 | Requerimiento REQ-2028 | Gustavo Neira | se verifica en producción | Cliente entrevistado | aceptado | 2026-09-23 | — |
| REQ-2036 | Requerimiento REQ-2036 | Felipe Arango | — | — | aceptado | 2026-09-28 | — |

## Decisiones

- Se mantiene el plan
