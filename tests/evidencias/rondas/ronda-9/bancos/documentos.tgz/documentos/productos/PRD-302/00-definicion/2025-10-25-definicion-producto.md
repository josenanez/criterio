# Definición de producto · Crédito hipotecario digital

**Código:** PRD-302
**Gerente de producto:** Sandra Gil
**Segmento:** PyME
**Fecha de la definición:** 2025-10-25

## El problema

El segmento PyME no tiene crédito hipotecario digital.

## La propuesta

- Propuesta principal

## Supuestos

- **El canal actual soporta el volumen** · declarado el 2026-04-20 · verificado con la medición del piloto del 2026-07-22 (anexo «Verificación del supuesto» del 2026-07-22)

## Proyectos que lo construyen

- Ninguno declarado
