# Tablero de métricas · Nómina empresarial

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-09-30

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 180.831 | 2026-09-30 |
