# Entrevistas · Crédito hipotecario digital

**Ronda:** Ronda · 2026-06-19
**Realizadas por:** Sandra Gil

### Cliente entrevistado · 2026-06-19

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
