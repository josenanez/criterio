# Definición de producto · Remesas familiares

**Código:** PRD-307
**Gerente de producto:** Felipe Arango
**Segmento:** Microcomercio
**Fecha de la definición:** 2025-10-02

## El problema

El segmento Microcomercio no tiene remesas familiares.

## La propuesta

- Propuesta principal

## Supuestos

- **La regulación vigente lo permite** · declarado el 2026-08-31 · verificado con la medición del piloto del 2026-09-11 (anexo «Verificación del supuesto» del 2026-09-11)

## Proyectos que lo construyen

- Ninguno declarado
