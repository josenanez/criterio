# Definición de producto · Cuenta de ahorros joven

**Código:** PRD-308
**Gerente de producto:** Rubén Cárdenas
**Segmento:** PyME
**Fecha de la definición:** 2026-07-21

## El problema

El segmento PyME no tiene cuenta de ahorros joven.

## La propuesta

- Propuesta principal

## Supuestos

- **El segmento paga por esto** · declarado el 2026-06-05 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
