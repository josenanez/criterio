# Comité de producto · Crédito de libre inversión

**Fecha:** 2026-10-16
**Asistentes:** Sandra Gil

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4900 | Requerimiento REQ-4900 | Rubén Cárdenas | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-24 | — |
| REQ-4901 | Requerimiento REQ-4901 | Rubén Cárdenas | — | Cliente entrevistado | propuesto | 2026-05-22 | — |
| REQ-4902 | Requerimiento REQ-4902 | Andrés Lozano | se verifica en producción | — | propuesto | 2026-08-11 | — |
| REQ-4903 | Requerimiento REQ-4903 | sin asignar | se verifica en producción | — | propuesto | 2026-06-24 | — |
| REQ-4904 | Requerimiento REQ-4904 | Jorge Medina | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-30 | — |
| REQ-4905 | Requerimiento REQ-4905 | María Restrepo | se verifica en producción | — | aceptado | 2026-05-04 | — |
| REQ-4906 | Requerimiento REQ-4906 | Ricardo Salas | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-12 | — |
| REQ-4907 | Requerimiento REQ-4907 | Sandra Gil | se verifica en producción | Cliente entrevistado | propuesto | 2026-04-25 | — |
| REQ-4908 | Requerimiento REQ-4908 | Gustavo Neira | — | Cliente entrevistado | propuesto | 2026-08-31 | — |
| REQ-4909 | Requerimiento REQ-4909 | Óscar Ramírez | — | Cliente entrevistado | propuesto | 2026-07-05 | — |
| REQ-4910 | Requerimiento REQ-4910 | Elena Duarte | se verifica en producción | — | aceptado | 2026-05-24 | — |
| REQ-4911 | Requerimiento REQ-4911 | Carlos Peña | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-06 | — |
| REQ-4912 | Requerimiento REQ-4912 | Rubén Cárdenas | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-14 | — |
| REQ-4913 | Requerimiento REQ-4913 | Elena Duarte | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-30 | — |
| REQ-2035 | Requerimiento REQ-2035 | Beatriz Cuéllar | se verifica en producción | — | aceptado | 2026-10-07 | — |

## Decisiones

- Se mantiene el plan
