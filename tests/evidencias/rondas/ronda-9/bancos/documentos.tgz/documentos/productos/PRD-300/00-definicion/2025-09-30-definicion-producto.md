# Definición de producto · Pagos QR comercios

**Código:** PRD-300
**Gerente de producto:** Jorge Medina
**Segmento:** PyME
**Fecha de la definición:** 2025-09-30

## El problema

El segmento PyME no tiene pagos qr comercios.

## La propuesta

- Propuesta principal

## Supuestos

- **La demanda declarada se sostiene sin campaña** · declarado el 2026-07-23 · verificado con la entrevista con doce clientes del segmento del 2026-08-14 (anexo «Verificación del supuesto» del 2026-08-14)

## Proyectos que lo construyen

- Ninguno declarado
