# Entrevistas · Cuenta de ahorros joven

**Ronda:** Ronda · 2025-11-08
**Realizadas por:** Rubén Cárdenas

### Cliente entrevistado · 2025-11-08

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
