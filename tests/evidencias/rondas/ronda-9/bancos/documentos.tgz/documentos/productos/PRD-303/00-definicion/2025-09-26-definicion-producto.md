# Definición de producto · Cuenta PyME

**Código:** PRD-303
**Gerente de producto:** Óscar Ramírez
**Segmento:** Personas
**Fecha de la definición:** 2025-09-26

## El problema

El segmento Personas no tiene cuenta pyme.

## La propuesta

- Propuesta principal

## Supuestos

- **La demanda declarada se sostiene sin campaña** · declarado el 2026-06-27 · verificado con el concepto jurídico de cumplimiento del 2026-08-19 (anexo «Verificación del supuesto» del 2026-08-19)

## Proyectos que lo construyen

- Ninguno declarado
