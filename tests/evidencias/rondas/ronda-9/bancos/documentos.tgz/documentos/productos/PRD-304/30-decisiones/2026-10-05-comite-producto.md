# Comité de producto · Tarjeta de crédito digital

**Fecha:** 2026-10-05
**Asistentes:** Óscar Ramírez

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4400 | Requerimiento REQ-4400 | Gustavo Neira | se verifica en producción | Cliente entrevistado | propuesto | 2026-08-08 | — |
| REQ-4401 | Requerimiento REQ-4401 | Javier Hoyos | se verifica en producción | — | aceptado | 2026-03-21 | — |
| REQ-4402 | Requerimiento REQ-4402 | Jorge Medina | — | — | aceptado | 2026-05-03 | — |
| REQ-4403 | Requerimiento REQ-4403 | Beatriz Cuéllar | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-29 | — |
| REQ-4404 | Requerimiento REQ-4404 | Laura Vélez | se verifica en producción | — | aceptado | 2026-06-21 | — |
| REQ-4405 | Requerimiento REQ-4405 | Rubén Cárdenas | — | — | propuesto | 2026-08-12 | — |
| REQ-4406 | Requerimiento REQ-4406 | Liliana Torres | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-12 | — |
| REQ-4407 | Requerimiento REQ-4407 | Mauricio Pérez | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-07 | — |
| REQ-4408 | Requerimiento REQ-4408 | Beatriz Cuéllar | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-11 | — |
| REQ-4409 | Requerimiento REQ-4409 | Felipe Arango | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-11 | — |
| REQ-4410 | Requerimiento REQ-4410 | Camilo Beltrán | se verifica en producción | — | propuesto | 2026-07-13 | — |
| REQ-4411 | Requerimiento REQ-4411 | Jorge Medina | se verifica en producción | — | aceptado | 2026-07-20 | — |
| REQ-4412 | Requerimiento REQ-4412 | Paula Céspedes | — | Cliente entrevistado | aceptado | 2026-06-30 | — |
| REQ-4413 | Requerimiento REQ-4413 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-13 | — |
| REQ-4414 | Requerimiento REQ-4414 | Javier Hoyos | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-09 | — |
| REQ-4415 | Requerimiento REQ-4415 | sin asignar | — | Cliente entrevistado | aceptado | 2026-06-09 | — |

## Decisiones

- Se mantiene el plan
