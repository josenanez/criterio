# Comité de producto · Remesas familiares

**Fecha:** 2026-10-16
**Asistentes:** Felipe Arango

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4700 | Requerimiento REQ-4700 | Gustavo Neira | se verifica en producción | Cliente entrevistado | propuesto | 2026-03-26 | — |
| REQ-4701 | Requerimiento REQ-4701 | Rubén Cárdenas | se verifica en producción | Cliente entrevistado | propuesto | 2026-05-18 | — |
| REQ-4702 | Requerimiento REQ-4702 | Felipe Arango | — | — | aceptado | 2026-08-31 | — |
| REQ-4703 | Requerimiento REQ-4703 | Andrés Lozano | se verifica en producción | — | aceptado | 2026-05-09 | — |
| REQ-4704 | Requerimiento REQ-4704 | Laura Vélez | se verifica en producción | Cliente entrevistado | propuesto | 2026-04-08 | — |
| REQ-4705 | Requerimiento REQ-4705 | Carlos Peña | — | Cliente entrevistado | aceptado | 2026-04-19 | — |
| REQ-4706 | Requerimiento REQ-4706 | Laura Vélez | se verifica en producción | — | aceptado | 2026-03-25 | — |
| REQ-4707 | Requerimiento REQ-4707 | Elena Duarte | se verifica en producción | — | aceptado | 2026-04-01 | — |
| REQ-4708 | Requerimiento REQ-4708 | sin asignar | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-18 | — |
| REQ-4709 | Requerimiento REQ-4709 | Diana Molina | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-22 | — |
| REQ-4710 | Requerimiento REQ-4710 | Elena Duarte | — | Cliente entrevistado | propuesto | 2026-07-11 | — |
| REQ-4711 | Requerimiento REQ-4711 | Elena Duarte | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-07 | — |
| REQ-4712 | Requerimiento REQ-4712 | Javier Hoyos | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-01 | — |
| REQ-4713 | Requerimiento REQ-4713 | Paula Céspedes | se verifica en producción | — | aceptado | 2026-07-12 | — |
| REQ-4714 | Requerimiento REQ-4714 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-27 | — |
| REQ-4715 | Requerimiento REQ-4715 | María Restrepo | — | — | propuesto | 2026-07-22 | — |

## Decisiones

- Se mantiene el plan
