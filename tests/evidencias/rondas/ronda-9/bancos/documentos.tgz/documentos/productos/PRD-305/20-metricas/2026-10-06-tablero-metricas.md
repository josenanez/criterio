# Tablero de métricas · Recaudos y cobros

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-06

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 64.286 | 2026-10-06 |
