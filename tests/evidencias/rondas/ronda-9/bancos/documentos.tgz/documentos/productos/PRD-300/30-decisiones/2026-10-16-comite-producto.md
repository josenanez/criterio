# Comité de producto · Pagos QR comercios

**Fecha:** 2026-10-16
**Asistentes:** Jorge Medina

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4000 | Requerimiento REQ-4000 | Elena Duarte | se verifica en producción | — | propuesto | 2026-08-14 | — |
| REQ-4001 | Requerimiento REQ-4001 | Gustavo Neira | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-08 | — |
| REQ-4002 | Requerimiento REQ-4002 | Ricardo Salas | — | Cliente entrevistado | propuesto | 2026-07-05 | — |
| REQ-4003 | Requerimiento REQ-4003 | Liliana Torres | se verifica en producción | — | aceptado | 2026-05-30 | — |
| REQ-4004 | Requerimiento REQ-4004 | Rubén Cárdenas | — | Cliente entrevistado | aceptado | 2026-06-03 | — |
| REQ-4005 | Requerimiento REQ-4005 | Mauricio Pérez | — | Cliente entrevistado | aceptado | 2026-04-22 | — |
| REQ-4006 | Requerimiento REQ-4006 | sin asignar | — | — | aceptado | 2026-04-20 | — |
| REQ-4007 | Requerimiento REQ-4007 | Liliana Torres | — | — | aceptado | 2026-08-29 | — |
| REQ-4008 | Requerimiento REQ-4008 | Felipe Arango | se verifica en producción | Cliente entrevistado | propuesto | 2026-05-11 | — |
| REQ-4009 | Requerimiento REQ-4009 | Jorge Medina | — | — | aceptado | 2026-04-08 | — |
| REQ-4010 | Requerimiento REQ-4010 | sin asignar | se verifica en producción | — | propuesto | 2026-03-26 | — |
| REQ-4011 | Requerimiento REQ-4011 | Mauricio Pérez | se verifica en producción | Cliente entrevistado | propuesto | 2026-08-29 | — |
| REQ-4012 | Requerimiento REQ-4012 | Paula Céspedes | — | Cliente entrevistado | aceptado | 2026-08-28 | — |
| REQ-4013 | Requerimiento REQ-4013 | Carlos Peña | se verifica en producción | Cliente entrevistado | propuesto | 2026-05-21 | — |
| REQ-4014 | Requerimiento REQ-4014 | Javier Hoyos | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-10 | — |
| REQ-4015 | Requerimiento REQ-4015 | Jorge Medina | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-21 | — |
| REQ-2030 | Requerimiento REQ-2030 | Liliana Torres | — | Cliente entrevistado | aceptado | 2026-10-05 | — |

## Decisiones

- Se mantiene el plan
