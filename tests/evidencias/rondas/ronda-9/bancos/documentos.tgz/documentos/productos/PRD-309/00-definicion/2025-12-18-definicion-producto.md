# Definición de producto · Crédito de libre inversión

**Código:** PRD-309
**Gerente de producto:** Sandra Gil
**Segmento:** PyME
**Fecha de la definición:** 2025-12-18

## El problema

El segmento PyME no tiene crédito de libre inversión.

## La propuesta

- Propuesta principal

## Supuestos

- **El proveedor cumple el tiempo pactado** · declarado el 2026-05-01 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
