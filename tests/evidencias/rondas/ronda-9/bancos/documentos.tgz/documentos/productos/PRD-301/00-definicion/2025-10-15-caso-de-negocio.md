# Caso de negocio · Nómina empresarial

**Código:** PRD-301
**Fecha:** 2025-10-15
**Preparado por:** Gustavo Neira

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 253.922 | Caso de negocio, 2025-10-15 |

## Retorno esperado

Retorno esperado en 24 meses.
