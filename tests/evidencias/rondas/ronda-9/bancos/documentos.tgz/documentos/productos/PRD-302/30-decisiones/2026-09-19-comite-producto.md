# Comité de producto · Crédito hipotecario digital

**Fecha:** 2026-09-19
**Asistentes:** Sandra Gil

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4200 | Requerimiento REQ-4200 | Beatriz Cuéllar | se verifica en producción | — | aceptado | 2026-06-18 | — |
| REQ-4201 | Requerimiento REQ-4201 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-24 | — |
| REQ-4202 | Requerimiento REQ-4202 | Sandra Gil | se verifica en producción | — | aceptado | 2026-09-01 | — |
| REQ-4203 | Requerimiento REQ-4203 | Ricardo Salas | se verifica en producción | — | aceptado | 2026-05-16 | — |
| REQ-4204 | Requerimiento REQ-4204 | Felipe Arango | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-22 | — |
| REQ-4205 | Requerimiento REQ-4205 | Elena Duarte | se verifica en producción | — | aceptado | 2026-07-27 | — |
| REQ-4206 | Requerimiento REQ-4206 | Gustavo Neira | se verifica en producción | Cliente entrevistado | propuesto | 2026-08-12 | — |
| REQ-4207 | Requerimiento REQ-4207 | sin asignar | — | Cliente entrevistado | aceptado | 2026-06-19 | — |
| REQ-4208 | Requerimiento REQ-4208 | Javier Hoyos | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-17 | — |
| REQ-4209 | Requerimiento REQ-4209 | María Restrepo | — | Cliente entrevistado | propuesto | 2026-07-18 | — |
| REQ-4210 | Requerimiento REQ-4210 | María Restrepo | — | Cliente entrevistado | aceptado | 2026-06-29 | — |
| REQ-4211 | Requerimiento REQ-4211 | Rubén Cárdenas | se verifica en producción | — | aceptado | 2026-07-03 | — |
| REQ-4212 | Requerimiento REQ-4212 | Camilo Beltrán | — | — | propuesto | 2026-08-12 | — |
| REQ-4213 | Requerimiento REQ-4213 | Beatriz Cuéllar | se verifica en producción | Cliente entrevistado | propuesto | 2026-04-29 | — |

## Decisiones

- Se mantiene el plan
