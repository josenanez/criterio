# Tablero de métricas · Remesas familiares

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-16

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 76.086 | 2026-10-16 |
