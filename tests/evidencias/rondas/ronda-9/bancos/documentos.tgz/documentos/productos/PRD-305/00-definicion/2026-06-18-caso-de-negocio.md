# Caso de negocio · Recaudos y cobros

**Código:** PRD-305
**Fecha:** 2026-06-18
**Preparado por:** Paula Céspedes

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 91.093 | Caso de negocio, 2026-06-18 |

## Retorno esperado

Retorno esperado en 24 meses.
