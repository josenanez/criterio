# Caso de negocio · Remesas familiares

**Código:** PRD-307
**Fecha:** 2025-10-02
**Preparado por:** Felipe Arango

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 108.635 | Caso de negocio, 2025-10-02 |

## Retorno esperado

Retorno esperado en 24 meses.
