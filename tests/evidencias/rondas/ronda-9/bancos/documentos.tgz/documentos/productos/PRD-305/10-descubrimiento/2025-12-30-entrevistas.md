# Entrevistas · Recaudos y cobros

**Ronda:** Ronda · 2025-12-30
**Realizadas por:** Paula Céspedes

### Cliente entrevistado · 2025-12-30

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
