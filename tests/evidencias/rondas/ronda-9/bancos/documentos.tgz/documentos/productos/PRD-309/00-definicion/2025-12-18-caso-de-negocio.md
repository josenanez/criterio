# Caso de negocio · Crédito de libre inversión

**Código:** PRD-309
**Fecha:** 2025-12-18
**Preparado por:** Sandra Gil

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 267.017 | Caso de negocio, 2025-12-18 |

## Retorno esperado

Retorno esperado en 24 meses.
