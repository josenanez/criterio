# Caso de negocio · Microseguros

**Código:** PRD-306
**Fecha:** 2026-05-25
**Preparado por:** Beatriz Cuéllar

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 80.461 | Caso de negocio, 2026-05-25 |

## Retorno esperado

Retorno esperado en 24 meses.
