# Informe de avance · Open Banking

**Código:** PRY-203
**Fecha de corte:** 2026-09-23
**Gerente:** Óscar Ramírez

## Estado declarado

**Verde**

Avance reportado: **60%**

## Lo que pasó en el periodo

- La prueba de carga no alcanzó el umbral pactado y se repite
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales

## Presupuesto

| | COP |
|---|---|
| Aprobado | 6.800.000.000 |
| Comprometido | 4.287.613.069 |
| Ejecutado | 2.423.227.705 |
| Proyección al cierre | 6.372.447.197 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
- Dependencia del calendario de liberaciones del core
