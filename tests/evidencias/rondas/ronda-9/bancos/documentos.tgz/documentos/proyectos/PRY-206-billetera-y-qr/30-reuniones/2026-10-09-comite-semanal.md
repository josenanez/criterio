# Comité de Medios de Pago · Billetera y QR

**Fecha:** 2026-10-09
**Asistentes:** Mauricio Pérez, María Restrepo

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Mauricio Pérez | Entregar el punto 40 | 2026-10-22 |
