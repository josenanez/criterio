# Comité de Arquitectura · Originación digital

**Fecha:** 2026-10-10
**Asistentes:** Andrés Lozano, Camilo Beltrán, Carlos Peña, Diana Molina, Elena Duarte, Felipe Arango, Gustavo Neira, Jorge Medina, Laura Vélez, María Restrepo, Mauricio Pérez, Paula Céspedes, Ricardo Salas, Sandra Gil

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Elena Duarte | Enviar el documento 1 | 2026-11-21 |
| Ricardo Salas | Cerrar la prueba 2 | 2026-11-20 |
| Carlos Peña | Validar el ambiente 4 | 2026-09-25 |
| Carlos Peña | Entregar el punto 8 | 2026-10-10 |
| Felipe Arango | Revisar el anexo 11 | 2026-09-29 |
| Sandra Gil | Validar el ambiente 12 | 2026-09-22 |
| María Restrepo | Aprobar el diseño 13 | 2026-10-06 |
| Carlos Peña | Confirmar la fecha 15 | 2026-10-15 |
| Andrés Lozano | Entregar el punto 16 | 2026-10-27 |
| Jorge Medina | Enviar el documento 17 | 2026-10-28 |
| Gustavo Neira | Cerrar la prueba 18 | 2026-10-08 |
| Camilo Beltrán | Revisar el anexo 19 | 2026-11-08 |
| Elena Duarte | Validar el ambiente 20 | 2026-10-17 |
| Mauricio Pérez | Aprobar el diseño 21 | 2026-10-20 |
| Paula Céspedes | Actualizar la matriz 22 | 2026-10-24 |
| Laura Vélez | Confirmar la fecha 23 | 2026-11-07 |
| María Restrepo | Entregar el punto 24 | por definir |
