# Comité de Arquitectura · Originación digital

**Fecha:** 2026-09-05
**Asistentes:** Carlos Peña, Diana Molina, Elena Duarte, Gustavo Neira, Ricardo Salas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Elena Duarte | Enviar el documento 1 | 2026-09-25 |
| Ricardo Salas | Cerrar la prueba 2 | por definir |
| Gustavo Neira | Revisar el anexo 3 | 2026-09-10 |
| Carlos Peña | Validar el ambiente 4 | 2026-09-25 |
