# Informe de avance · Originación digital

**Código:** PRY-200
**Fecha de corte:** 2026-10-17
**Gerente:** Diana Molina

## Estado declarado

**Verde**

Avance reportado: **36%**

## Lo que pasó en el periodo

- Se ajustó el plan de pruebas con el área de seguridad
- La prueba de carga no alcanzó el umbral pactado y se repite

## Presupuesto

| | COP |
|---|---|
| Aprobado | 18.000.000.000 |
| Comprometido | 6.215.444.712 |
| Ejecutado | 4.617.386.288 |
| Proyección al cierre | 20.859.955.929 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
- Dependencia del calendario de liberaciones del core
