# Comité de Transformación Digital · Prevención de lavado de activos

**Fecha:** 2026-10-15
**Asistentes:** Óscar Ramírez, Rubén Cárdenas

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Laura Vélez | Entregar el punto 31 | 2026-10-11 |
