# Informe de avance · Prevención de lavado de activos

**Código:** PRY-205
**Fecha de corte:** 2026-10-14
**Gerente:** Óscar Ramírez

## Estado declarado

**Verde**

Avance reportado: **82%**

## Lo que pasó en el periodo

- La prueba de carga no alcanzó el umbral pactado y se repite
- Se recibió la aprobación regulatoria pendiente desde el trimestre anterior
- Dos historias quedaron fuera del alcance del sprint por dependencia con el core

## Presupuesto

| | COP |
|---|---|
| Aprobado | 800.000.000 |
| Comprometido | 665.725.356 |
| Ejecutado | 156.431.890 |
| Proyección al cierre | 762.502.965 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
