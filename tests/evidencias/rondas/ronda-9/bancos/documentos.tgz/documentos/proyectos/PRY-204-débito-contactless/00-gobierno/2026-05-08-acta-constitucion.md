# Acta de constitución · Débito contactless

**Código:** PRY-204
**Área dueña:** Medios de Pago
**Patrocinador:** Gustavo Neira
**Gerente de proyecto:** Ricardo Salas
**Comité:** Comité de Transformación Digital
**Producto asociado:** tarjeta débito
**Fecha de aprobación:** 2026-05-08

## Objetivo del negocio

Entregar débito contactless para Medios de Pago.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**3.300.000.000 COP**, aprobado por Comité de Transformación Digital el 2026-05-08.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-05-18 |
| Cierre | 2027-06-22 |

## Criterio de éxito

Débito contactless en producción y medido.

## Dependencias declaradas

- Ninguna declarada
