# Informe de avance · Motor de decisión

**Código:** PRY-208
**Fecha de corte:** 2026-09-30
**Gerente:** Carlos Peña

## Estado declarado

**Verde**

Avance reportado: **47%**

## Lo que pasó en el periodo

- Se levantó un hallazgo de seguridad en la revisión de arquitectura

## Presupuesto

| | COP |
|---|---|
| Aprobado | 1.200.000.000 |
| Comprometido | 844.902.221 |
| Ejecutado | 459.175.619 |
| Proyección al cierre | 1.129.393.870 |

## Riesgos abiertos

- Dependencia del calendario de liberaciones del core
