# Comité de Arquitectura · Originación digital

**Fecha:** 2026-09-26
**Asistentes:** Andrés Lozano, Carlos Peña, Diana Molina, Elena Duarte, Felipe Arango, Liliana Torres, María Restrepo, Ricardo Salas, Sandra Gil

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Elena Duarte | Enviar el documento 1 | 2026-11-03 |
| Ricardo Salas | Cerrar la prueba 2 | 2026-10-25 |
| Carlos Peña | Validar el ambiente 4 | 2026-09-25 |
| Carlos Peña | Entregar el punto 8 | 2026-10-10 |
| Elena Duarte | Cerrar la prueba 10 | 2026-10-26 |
| Felipe Arango | Revisar el anexo 11 | 2026-09-29 |
| Sandra Gil | Validar el ambiente 12 | 2026-09-22 |
| María Restrepo | Aprobar el diseño 13 | 2026-10-06 |
| Liliana Torres | Actualizar la matriz 14 | por definir |
| Carlos Peña | Confirmar la fecha 15 | 2026-10-15 |
| Andrés Lozano | Entregar el punto 16 | 2026-10-14 |

## Cerrados en esta reunión

- Revisar el anexo 3 (Gustavo Neira): recibido, acta de recibo del 2026-09-26.
- Enviar el documento 9 (Jorge Medina): recibido, acta de recibo del 2026-09-26.

## Lo que se dijo

- Gustavo Neira dice que ya entregó «confirmar la fecha 7». No se presentó acta.
