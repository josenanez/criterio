# Solicitud de cambio CC-01

**Proyecto:** PRY-203 · Open Banking
**Fecha:** 2026-10-14
**Solicitante:** Óscar Ramírez

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +114 días sobre la línea base vigente |
| Costo | 228.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
