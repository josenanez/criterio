# Acta de constitución · Onboarding PyME

**Código:** PRY-207
**Área dueña:** Banca Empresas
**Patrocinador:** Javier Hoyos
**Gerente de proyecto:** Beatriz Cuéllar
**Comité:** Comité de Arquitectura
**Producto asociado:** cuenta PyME
**Fecha de aprobación:** 2025-07-15

## Objetivo del negocio

Entregar onboarding pyme para Banca Empresas.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**18.000.000.000 COP**, aprobado por Comité de Arquitectura el 2025-07-15.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-07-25 |
| Cierre | 2026-08-29 |

## Criterio de éxito

Onboarding PyME en producción y medido.

## Dependencias declaradas

- Ninguna declarada
