# Comité de Medios de Pago · Open Banking

**Fecha:** 2026-10-17
**Asistentes:** Óscar Ramírez, Sandra Gil

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Carlos Peña | Entregar el punto 21 | 2026-11-13 |
