# Corrida · 2026-10-17-product-overlap-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-overlap PRD-308

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRD-308

**Inicio:** 2026-10-17T21:39:06 · **Fin:** 2026-10-17T21:39:13 · **Duración:** 7 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

> Esta corrida no dejó cifras medidas por `corrida`: lo que hay es lo que el agente mostró. Si el comando debía correr los scripts y no lo hizo, eso es un hallazgo de la prueba.

## Lo que el agente mostró

No existe la configuración de PRD-308: `.criterio/producto/PRD-308/config.json` no está en esta carpeta. Solo hay una de producto, la de PRD-309, y no la usé porque el argumento pedía PRD-308. Tampoco inventé una.

No corrí ningún paso del comando: ni los términos, ni el cruce, ni el registro de la corrida. Si PRD-308 todavía no se configuró, hay que correr `/criterio-product:product-setup` para ese producto. Si el código correcto era PRD-309, vuelve a lanzar `/product-overlap PRD-309`.
