# Corrida · 2026-10-17-vendor-tracking-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:vendor-tracking PRY-200

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-200

**Inicio:** 2026-10-17T21:23:59 · **Fin:** 2026-10-17T21:24:45 · **Duración:** 46 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `vendor-tracking` | 13 | — | 30 | 90 | Cruce de CT-497 contra FV-1497 y evidencia: 2 entregables vencidos, 1 recibido sin acta, 1 factura sin entregable identificable. Sin dato: vigencia, preaviso, a qué entregable corresponde la factura, si Beatriz Cuéllar es del proveedor. |

Por señal (`vendor-tracking`): `milestone_met_without_evidence` 28, `commitment_overdue` 12, `declared_vs_evidence` 9, `progress_vs_plan` 7, `vendor_deliverable_late` 7, `vendor_accepted_without_evidence` 5, `variance_time` 5, `rebaseline_unauthorized` 4, `commitment_undated` 4, `commitment_rescheduled` 3, `variance_cost` 2, `milestone_overdue` 1, `vendor_invoiced_over_accepted` 1, `vendor_invoiced_without_delivery` 1, `change_without_baseline` 1

## Lo que el agente mostró

## Proveedores — PRY-200 Tienda en línea al 2026-10-17

**De dónde sale:** el contrato CT-497, la factura FV-1497, el informe de avance del 2026-10-09, el comité del 2026-10-07 y la salida de `compute`. Los términos ya estaban vigentes: versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17. No hubo que registrarlos de nuevo.

### Sistemas Comerciales del Norte — contrato CT-497
El contrato no trae vigencia, renovación ni preaviso. Esos datos están en "Sin dato".

| Entregable | Comprometido | Estado | Evidencia |
|---|---|---|---|
| Licenciamiento de la plataforma (445.577.090 COP) | 2025-12-27 | El contrato dice "pendiente"; vencido hace 294 días | Ninguna |
| Bolsa de horas de desarrollo (445.577.090 COP) | 2026-05-02 | El contrato dice "recibido" | Ninguna: no hay acta de recibo |
| Configuración del catálogo (445.577.090 COP) | 2026-09-04 | El contrato dice "pendiente"; vencido hace 43 días | Ninguna |

Según el script, el proveedor tiene 3 entregables y 1 aceptado, sin documento que lo pruebe. Facturado: 445.577.090 COP.

### Dónde no cuadra
- **FV-1497 sin acta:** la factura es de 445.577.090 COP, del 2026-09-10. El contrato exige un acta de recibo firmada por la gerente (Sandra Gil) para facturar cada entregable. No hay ninguna acta en la carpeta. La factura dice "Entregables del contrato CT-497" sin precisar cuál.
- **Bolsa de horas sin soporte:** el contrato la marca como recibida, pero no hay acta, correo ni minuta que lo respalde.
- **Un solo recibido:** el monto de la factura coincide con un solo entregable. Solo la bolsa de horas figura como recibida, y sin soporte.
- **La señal de factura sin entrega no se levantó:** el script la reserva para cuando no hay ningún entregable aceptado. Aquí hay uno declarado, aunque sin documento, así que la factura queda sin sustento verificable.

### Compromiso vencido
Beatriz Cuéllar debía entregar el punto 17 el 2026-10-08; lleva 9 días vencido. Los documentos no dicen si ella es del proveedor o es interna, y no figura entre los asistentes al comité. Lo dejé como compromiso del proyecto.

### Sin dato
- Vigencia, renovación automática y preaviso de CT-497. Por eso no puedo decir si el preaviso vence antes del cierre del proyecto, el 2026-11-23.
- A qué entregable corresponde FV-1497.
- Si existen otras facturas. Solo hay una en la carpeta.

### Siguiente paso
Hay un entregable facturado sin evidencia de recibo y dos vencidos sin entrega. Puedo llevarlo al comité del 2026-10-23. Antes de pagar FV-1497 hay que pedir el acta de recibo firmada o devolver la factura. También hay que pedir el contrato completo o el anexo con vigencia y preaviso.

El informe del 2026-10-09 declara el proyecto en verde. Cuatro señales no quedan explicadas: el compromiso vencido, hitos cumplidos sin evidencia, el avance contra el plan y el entregable tardío del proveedor.

Este es un borrador de trabajo. Cada dato sale del documento citado y la verificación es de quien lo use.

La corrida quedó registrada como `2026-10-17-vendor-tracking-1`. La salida completa está en `estado/corridas/salida-vendor-tracking.md`.

- **Medición:** tardó 30 segundos. El conteo de documentos no se midió.
- **Alcance de los números:** los 90 hallazgos del registro son de los 13 proyectos del portafolio, no solo de PRY-200. Los de PRY-200 son 10 señales.
