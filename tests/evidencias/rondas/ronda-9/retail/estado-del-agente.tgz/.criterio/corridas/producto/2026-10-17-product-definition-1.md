# Corrida · 2026-10-17-product-definition-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-definition (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T20:58:16 · **Fin:** 2026-10-17T20:59:01 · **Duración:** 45 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-definition` | 15 | — | 29 | 36 | De la definición, la evidencia solo sostiene débilmente el problema (una entrevista de hace 12 meses); el volumen declarado está 22,9 % por encima de lo medido; faltan criterio de éxito, propuesta y país. |

Por señal (`product-definition`): `evidence_stale` 13, `requirement_untraced` 13, `requirement_without_acceptance` 4, `requirement_accepted_without_evidence` 2, `requirement_undecided` 2, `assumption_unverified` 1, `claim_vs_metric` 1

## Lo que el agente mostró

Terminé el contraste de la definición de PRD-309 (Tarjeta de la tienda) contra la evidencia. La evidencia sostiene muy poco de esa definición.

Los términos ya estaban vigentes: v1.1, aceptados por José Francisco Ñáñez el 2026-10-17. No los registré otra vez.

- **Lo que la evidencia contradice:** ningún par de documentos dice cosas opuestas. La única diferencia es de cifras.
- **El negocio y los datos:** el caso de negocio declara un volumen mensual de 278.242 (2026-02-23). El tablero mide 214.637 (corte 2026-10-09). El caso está 22,9 % por encima, y el umbral es 20 %. Hay un solo punto medido y nadie define qué cuenta como volumen.
- **Retorno esperado:** dice «24 meses», pero no trae cifra, así que no hay nada que medir.
- **Lo que sostiene el problema:** una sola entrevista de hace 12 meses, con la frase «Lo necesito y hoy no lo tengo». No nombra a Hogares ni la tarjeta. Esa misma entrevista es la evidencia de 13 de los 15 requerimientos.
- **Supuesto sin verificar:** «El cliente paga por la entrega rápida» lleva 31 días sin verificarse (umbral 30). Anoté qué haría falta para verificarlo.
- **No está dicho en ninguna parte:**
  - la propuesta, que es solo el rótulo «Propuesta principal»;
  - el criterio de éxito;
  - quién decide;
  - el país;
  - el proyecto que lo construye.
- **Lo normativo:** la definición no declara país, así que no cité ninguna norma. Las cinco filas del barrido (medio de pago o crédito, consumidor financiero, datos personales, transferencia de datos, retención) quedaron en «no tengo la norma a la vista». Salen del nombre del producto, no de su texto, y van a revisión jurídica.
- **Para cerrar la definición:** falta el criterio de éxito y quién decide. Por eso no corresponde `/product-charter`. Sí se puede convertir el supuesto de la entrega rápida en riesgo con doliente.

Dejé registrada la corrida `2026-10-17-product-definition-1`: 36 hallazgos, 29 segundos, caso PRD-309.

Archivos en `/home/claude/banco/ronda-9/retail/espacio/estado-producto/PRD-309/corridas/`:
- `salida-product-definition.md`
