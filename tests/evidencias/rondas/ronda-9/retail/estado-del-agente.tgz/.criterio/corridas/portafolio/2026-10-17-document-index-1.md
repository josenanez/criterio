# Corrida · 2026-10-17-document-index-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:document-index (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T21:19:52 · **Fin:** 2026-10-17T21:20:20 · **Duración:** 28 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `document-index` | 13 | — | 17 | 90 | 91 documentos sin cambio, 0 por releer. 16 citas de PRY-203 (ficha-pm) no resuelven por ruta sin prefijo de proyecto, aunque los archivos existen; causa no confirmada abriendo la ficha. No se tocó ninguna ficha. |

Por señal (`document-index`): `milestone_met_without_evidence` 28, `commitment_overdue` 12, `declared_vs_evidence` 9, `progress_vs_plan` 7, `vendor_deliverable_late` 7, `vendor_accepted_without_evidence` 5, `variance_time` 5, `rebaseline_unauthorized` 4, `commitment_undated` 4, `commitment_rescheduled` 3, `variance_cost` 2, `milestone_overdue` 1, `vendor_invoiced_over_accepted` 1, `vendor_invoiced_without_delivery` 1, `change_without_baseline` 1

## Lo que el agente mostró

## Carpeta al 2026-10-17

Los términos ya estaban vigentes a nombre de José Francisco Ñáñez (2026-10-17), así que no hubo que registrarlos de nuevo.

**Documentos:** 91 · **Sin cambio:** 91 · **Hay que releer:** 0

- **Cambió el contenido, solo se reguardó, renombrados, ya no está:** ninguno.
- **Citas que dejaron de resolver:** 16, todas de PRY-203, en la ficha del gerente (`pm_record`). Son los campos de identidad (código, nombre, área, producto, sponsor, gerente, comité), los de plan (inicio, fin, alcance, exclusiones), los de dinero (aprobado, comprometido, ejecutado, proyección) y la factura del proveedor. Citan el acta de constitución, el cronograma v1, el informe de avance del 15-oct y la factura CT-338.
- **Causa probable, sin confirmar:** esos cuatro archivos sí existen dentro de `PRY-203-reposición-automática/`. Las citas parecen estar escritas relativas a esa carpeta, sin el prefijo del proyecto, y el índice no las encuentra. No abrí la ficha para comprobarlo.
- **Formatos que no se pudieron leer:** ninguno. Este comando cuenta y compara, no lee contenido.

No hay nada que releer ni proyectos tocados, así que `/portfolio-scan` no hace falta. Queda abierta la decisión de corregir esas 16 citas. No toqué ninguna ficha.

La corrida quedó registrada como `2026-10-17-document-index-1` y tardó 17 segundos. La salida completa está en `estado/corridas/salida-document-index.md`.
