# Corrida · 2026-10-17-budget-tracking-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:budget-tracking PRY-203

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-203

**Inicio:** 2026-10-17T21:23:15 · **Fin:** 2026-10-17T21:23:54 · **Duración:** 40 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `budget-tracking` | 13 | — | 27 | 90 | Presupuesto PRY-203: proyección 19.4% sobre el aprobado, ejecutado 21.0% frente a avance declarado 92.0% sin evidencia de hitos, facturación 22.377.121 COP sobre lo aceptado. Dijo que no sabe: respaldo contable independiente, desglose de la proyección, y el ajuste de presupuesto pendiente sin documento. |

Por señal (`budget-tracking`): `milestone_met_without_evidence` 28, `commitment_overdue` 12, `declared_vs_evidence` 9, `progress_vs_plan` 7, `vendor_deliverable_late` 7, `vendor_accepted_without_evidence` 5, `variance_time` 5, `rebaseline_unauthorized` 4, `commitment_undated` 4, `commitment_rescheduled` 3, `variance_cost` 2, `milestone_overdue` 1, `vendor_invoiced_over_accepted` 1, `vendor_invoiced_without_delivery` 1, `change_without_baseline` 1

## Lo que el agente mostró

El informe de presupuesto de PRY-203 (Reposición automática) está terminado y la corrida quedó registrada.

Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17), así que no hubo que registrarlos de nuevo.

**Las cuatro cifras, en COP, con corte al 2026-10-17**

| | Monto | % del aprobado | Fuente |
|---|---|---|---|
| Aprobado | 1.200.000.000 | 100 | Acta de constitución, 2025-07-06 |
| Comprometido | 742.486.754 | 61.9 | Informe de avance, 2026-10-15 |
| Ejecutado | 251.538.678 | 21.0 | Informe de avance, 2026-10-15 |
| Proyección | 1.432.210.423 | 19.4 sobre el aprobado | Informe de avance, 2026-10-15 |

- **Disponible real:** 457.513.246 COP (aprobado menos comprometido).
- **Línea base:** no hay replanificaciones ni solicitudes de cambio de presupuesto. Nada respalda el exceso de la proyección, que supera el umbral de 10%.
- **Ejecución frente a avance:** el informe declara 92% de avance y 4 de 5 hitos cumplidos, pero lo ejecutado es solo 21%. Ninguno de esos hitos tiene evidencia en los documentos.
- **Proveedor** (Sistemas Comerciales del Norte): facturó 22.377.121 COP más de lo aceptado, y tiene 3 entregables vencidos y pendientes.
- **Estado declarado:** el informe lo marca en verde sin dar cuenta de ninguna de estas señales.

**Lo que no se pudo ver**
- Las tres cifras de ejecución salen de un solo PDF, sin documento contable que las contraste.
- El aprobado tiene 15 meses de antigüedad y no hay documento posterior que lo confirme.
- Laura Vélez tiene un compromiso sin fecha, "Mandar el ajuste del presupuesto" (notas del 2026-10-17), pero no hay documento que respalde ese ajuste.

Como la proyección excede el aprobado, puedo preparar la solicitud de cambio (`/change-control`). El comprometido está lejos del tope de 90%, así que no hace falta el detalle por proveedor.

El registro de la corrida (`2026-10-17-budget-tracking-1`) y el informe completo están en `estado/corridas/salida-budget-tracking.md`.
