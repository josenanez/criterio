# Corrida · 2026-10-17-product-wake-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-wake (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T21:39:18 · **Fin:** 2026-10-17T21:39:48 · **Duración:** 31 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-wake` | 15 | — | 17 | 36 | Primera revisión, sin corte anterior: todas las señales son nuevas. No hay carpeta de fichas, así que ninguna traza se confirmó. No se verificó ningún supuesto. |

Por señal (`product-wake`): `evidence_stale` 13, `requirement_untraced` 13, `requirement_without_acceptance` 4, `requirement_accepted_without_evidence` 2, `requirement_undecided` 2, `assumption_unverified` 1, `claim_vs_metric` 1

## Lo que el agente mostró

Hice la revisión de PRD-309 (Tarjeta de la tienda) y queda registrada. Es la primera, así que no había corte anterior y todo lo que aparece es nuevo. Los términos ya estaban vigentes (José Francisco Ñáñez, 2026-10-17).

**Para decisión del comité**
- **REQ-4908 y REQ-4905:** siguen propuestos, sin decidir, desde hace 179 y 161 días (umbral: 60). Los dolientes son Gustavo Neira y Natalia Ospina. Decide el Comité de producto.
- **Volumen mensual:** el caso de negocio declara 278.242 y el tablero del 2026-10-09 mide 214.637. La brecha es de 22,9 % (umbral: 20 %). Hay que aclarar qué cifra sostiene el caso.
- **Supuesto sin verificar:** «El cliente paga por la entrega rápida» lleva 31 días (umbral: 30). Falta verificarlo con clientes o registrarlo como riesgo.

**Aceptados sin sustento**
- **Sin evidencia:** REQ-4901 y REQ-4912.
- **Sin criterio de aceptación:** REQ-4901, REQ-4907, REQ-4909 y REQ-4913.
- **Evidencia vencida:** 13 requerimientos se apoyan en la misma entrevista del 2025-10-12, que ya cumple 12 meses y no nombra ninguno de ellos.
- **Sin criterio de éxito:** ni la definición ni el caso de negocio lo escriben.

**Trazas:** ninguno de los 13 aceptados tiene proyecto. No hay carpeta de fichas configurada, así que no confirmé ninguna traza y no sé si algún proyecto construye estos requerimientos.

Deje registrada la corrida y el corte del 2026-10-17. El informe está en `estado-producto/PRD-309/corridas/salida-product-wake.md` y la próxima revisión toca el **2026-11-16**.
