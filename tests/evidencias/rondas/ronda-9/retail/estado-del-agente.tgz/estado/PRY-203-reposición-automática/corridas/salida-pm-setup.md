## Listo — PRY-203 · Reposición automática

Soy Samuel. Proceso lo que pasa en tu proyecto y llevo la cuenta de lo que se prometió en cada reunión.

**Lo que miré:** 16 documentos · 7 minutas (6 actas de comité semanal y las notas del 2026-10-17, que están sueltas en la raíz de la carpeta) · la última del 2026-10-17. Leí todas, de la más vieja a la más nueva, más 4 actas de recibo, el acta de constitución, el contrato CT-338, el cronograma v1, la factura FV-1338 y el informe de avance. Formatos que no pude leer: ninguno.
**Quién eres y cuándo se reúnen:** gerente Laura Vélez, patrocinador Carlos Peña (acta de constitución, 2025-07-06). Comité de Expansión los sábados, cada semana (tomé la repetición de las minutas). Las notas del 17 dicen «próxima reunión en dos semanas», así que la próxima la anoté para el 2026-10-31.
**Dónde queda lo que encuentro:** `estado/PRY-203-reposición-automática`.
**Términos:** aceptados por José Francisco Ñáñez para la versión 0.4.0 (términos 1.1), 2026-10-17 · comprobante en `.criterio/terminos/aceptacion-criterio-project-0.4.0-2026-10-17.md` y `.pdf` · SHA-256 99704ec1070b83866591a7862f9b2f16d22fa0f9a8713e6139df8bbf54fddee5 (md) · 0c3de2b80140ee41… (pdf)
**Preguntas hechas:** 0. Sesión sin interfaz: tomé la respuesta sugerida en las cuatro y la dije en una línea.

### Lo que está abierto, y cuántas veces se ha movido

26 compromisos en total: 4 cumplidos con acta, 22 abiertos. De los 22: 8 vencidos, 3 sin fecha, 11 con fecha por delante.

**Reprogramados (3 o más veces)**

| Quién | Qué | Para cuándo | Veces |
|---|---|---|---|
| Natalia Ospina | Enviar el documento 1 | 2026-12-18 (la primera promesa fue 2026-09-28) | 6: 10-12, 10-23, 11-08, 11-25, 12-04, 12-18 (`30-reuniones/2026-09-05-comite-semanal.md` … `2026-10-17-notas-reunion.txt`) |
| Laura Vélez | Cerrar la prueba 2 | 2026-11-24 (la primera fue 2026-09-18) | 5: 09-27, 10-16, 10-29, 11-08, 11-24 (`30-reuniones/2026-09-05-comite-semanal.md` … `2026-10-10-comite-semanal.md`) |
| Jorge Medina | Revisar el anexo 11 | 2026-11-20 (la primera fue 2026-10-01) | 3: 10-17, 11-04, 11-20 (`30-reuniones/2026-09-19-comite-semanal.md` … `2026-10-10-comite-semanal.md`) |

Los dos primeros se movieron en cada una de las reuniones desde que se prometieron, y ninguna minuta sola lo muestra. Un tercer compromiso, «Entregar el punto 8» de Gustavo Neira, se movió dos veces (10-02 → 10-11 → 10-22); no llega al umbral de tres.

**Vencidos sin evidencia**

| Quién | Qué | Venció | Días | Cita |
|---|---|---|---|---|
| Carlos Peña | Validar el ambiente 4 | 2026-09-25 | 22 | `30-reuniones/2026-09-05-comite-semanal.md`; el 09-12 dijo que ya lo entregó, sin acta, y no vuelve a aparecer |
| Liliana Torres | Confirmar la fecha 15 | 2026-09-29 | 18 | `30-reuniones/2026-09-26-comite-semanal.md`; lleva la misma fecha en tres minutas |
| Laura Vélez | Cerrar la prueba 10 | 2026-10-03 | 14 | `30-reuniones/2026-09-19-comite-semanal.md`; lleva la misma fecha en cuatro minutas |
| Ricardo Salas | Enviar el documento 17 | 2026-10-06 | 11 | `30-reuniones/2026-10-03-comite-semanal.md`; la misma fecha en dos minutas |
| Natalia Ospina | Revisar el anexo 3 | 2026-10-10 | 7 | `30-reuniones/2026-09-05-comite-semanal.md`; el 10-10 dijo que ya lo entregó, sin acta |
| María Restrepo | Aprobar el diseño 13 | 2026-10-11 | 6 | `30-reuniones/2026-09-26-comite-semanal.md` |
| Camilo Beltrán | Actualizar la matriz 14 | 2026-10-11 | 6 | `30-reuniones/2026-09-26-comite-semanal.md`; el 10-03 dijo que ya lo entregó, sin acta, y no vuelve a aparecer |
| Elena Duarte | Entregar el punto 16 | 2026-10-15 | 2 | `30-reuniones/2026-09-26-comite-semanal.md` |

«Ya lo entregué» dicho en la reunión no cierra un compromiso: tres de estos ocho (Carlos Peña, Natalia Ospina, Camilo Beltrán) salieron de la lista con esa frase y sin acta.

**Cumplidos con acta de recibo:** Aprobar el diseño 5 (Jorge Medina, 2026-09-26), Actualizar la matriz 6 (Javier Hoyos, 2026-10-03), Enviar el documento 9 (Elena Duarte, 2026-10-03), Validar el ambiente 20 (Gustavo Neira, 2026-10-10).

### Sin fecha

Nadie los fechó, así que no pueden estar vencidos:
- Jorge Medina · Confirmar la fecha 7 (`30-reuniones/2026-09-12-comite-semanal.md`; el 10-10 dijo que ya lo entregó, sin acta).
- Gustavo Neira · Validar el ambiente 12 (`30-reuniones/2026-09-19-comite-semanal.md`; el 09-26 dijo que ya lo entregó, sin acta).
- Laura Vélez · Mandar el ajuste del presupuesto, «la otra semana» (`2026-10-17-notas-reunion.txt`).

### Otras señales que levantó el cálculo

- **Tu informe del 2026-10-15 dice verde, 92 %.** El cálculo no encuentra sustento para el verde: 7 tipos de señal quedan sin explicar (las de abajo y los compromisos). Eso lo declaras tú; esto es contra qué.
- **Cierre:** el hito «Despliegue en la cadena» vencía el 2026-10-09 y sigue en curso, 8 días de atraso (`10-plan/2025-07-06-cronograma-v1.xlsx`). Es el único cronograma que hay y su fecha coincide con la del acta, así que no hay desviación contra la línea base: tampoco hay replanificación registrada.
- **Hitos cerrados sin acta:** 4 de 5 hitos figuran «cerrado» en el cronograma y ninguna acta de recibo los prueba (Diseño de la experiencia, Ambiente de pruebas, Integración con el ERP, Piloto en tiendas).
- **Costo:** la proyección al cierre, 1.432.210.423 COP, supera en 19,4 % los 1.200.000.000 aprobados (`20-seguimiento/2026-10-15-informe-avance.pdf`). Comprometido 61,9 %, ejecutado 21,0 %.
- **Proveedor CT-338 (Sistemas Comerciales del Norte):** 3 de 4 entregables sin recibir y vencidos (Licenciamiento 359 días, Bolsa de horas 260, Configuración del catálogo 161). El «Soporte del primer trimestre» figura recibido en el contrato, sin acta. La factura FV-1338 por 118.225.663 COP supera en 22.377.121 COP lo aceptado (95.848.542).
- **Riesgo que nadie anotó:** en la reunión del 17 se comentó que el proveedor podría no llegar con el equipo completo en la siguiente fase (`2026-10-17-notas-reunion.txt`). Quedó en la ficha como riesgo, sin dueño.

### Qué le falta a tu carpeta

- Actas de recibo de los 4 hitos cerrados y del «Soporte del primer trimestre»: sin ellas lo cumplido se ve igual que lo incumplido.
- Un cronograma posterior al v1 de 2025-07-06: hoy no se ve ninguna replanificación, aunque el cierre ya pasó.
- Facultad del gerente (hasta qué monto y qué cambio decide sin subir a comité): no está en el acta.
- Etapa del proyecto: no está declarada en ningún documento.
- Las notas del 2026-10-17 están en la raíz de la carpeta, sin la convención `30-reuniones/AAAA-MM-DD-comite-semanal.md`.

**Cuándo vuelvo:** cada semana, el sábado de tu comité; la próxima, el 2026-10-31 según las notas del 17.
