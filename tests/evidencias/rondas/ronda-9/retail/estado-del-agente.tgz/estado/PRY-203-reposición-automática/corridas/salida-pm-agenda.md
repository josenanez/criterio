## Reunión de seguimiento — Reposición automática (PRY-203) · 2026-10-31
18 puntos · 49 minutos · 13 personas requeridas

Supuestos que conviene corregir: la configuración no fija duración, así que armé 49 minutos; y las cuentas de «hace N días» son al 2026-10-17 (hoy). El `diff` no encontró una corrida previa, de modo que «qué cambió» lo medí contra la última minuta (comité del 10-10 y notas del 10-17), no contra una foto anterior. Antes de la reunión, rehaz `/pm-agenda` para actualizar los días.

### Lo que no se destraba solo

> **[1] Qué es el «documento 1», qué lo bloquea y quién puede destrabarlo** · 10 min · **Natalia Ospina**
> Prometido para el 2026-12-18, y antes para el 12-04, 11-25, 11-08, 10-23 y 10-12. La primera promesa fue el 2026-09-28. Seis reprogramaciones.
> Fuente: notas de reunión del 2026-10-17 (línea 4: «no alcanzó, se compromete para el 18/12/2026»); comité del 2026-10-10.
> Las notas no dicen qué es el documento ni por qué no sale. Lo que tiene que quedar resuelto: el bloqueo con nombre, y alguien de la sala que lo pueda mover, o la decisión de subirlo al comité.
> **Si no se resuelve hoy:** la fecha se vuelve a mover y esta es la séptima.

> **[2] Cerrar la prueba 2: fecha con la que se cumple, o se sube** · 7 min · **Laura Vélez**
> Prometido para el 2026-11-24, y antes para el 11-08, 10-29, 10-16 y 09-27. La primera promesa fue el 2026-09-18. Cinco reprogramaciones.
> Fuente: comité del 2026-10-10 y ficha de compromisos al 2026-10-17.
> La doliente es la gerente. Si quien arma la agenda es quien incumple, otra persona tiene que conducir este punto. Lo que tiene que quedar resuelto: qué impide cerrarla, o que se formule para el comité con `/pm-escalate`.
> **Si no se resuelve hoy:** pasa de cinco a seis y arrastra lo que depende de esa prueba.

> **[3] Revisar el anexo 11: qué falta para que la fecha del 11-20 aguante** · 4 min · **Jorge Medina**
> Prometido para el 2026-11-20, y antes para el 11-04 y el 10-17. La primera promesa fue el 2026-10-01. Tres reprogramaciones, en el umbral configurado.
> Fuente: comité del 2026-10-10 y ficha de compromisos al 2026-10-17.
> **Si no se resuelve hoy:** pasa a cuatro.

### Vencido sin evidencia
Del más viejo al más reciente. En todos, lo que se necesita hoy es un acta de recibo o un correo de entrega, o una fecha nueva con su motivo.

| Quién | Qué | Desde | Qué se necesita hoy | Min |
|---|---|---|---|---|
| Liliana Torres | Confirmar la fecha 15 | 2026-09-29 (18 días) | Entrega con documento, o fecha nueva | 3 |
| Laura Vélez | Cerrar la prueba 10 | 2026-10-03 (14 días) | Ídem; revisar junto con el punto [2] | 3 |
| Ricardo Salas | Enviar el documento 17 | 2026-10-06 (11 días) | Ídem | 3 |
| Natalia Ospina | Revisar el anexo 3 (1 reprogramación) | 2026-10-10 (7 días) | Dijo el 10-10 que ya lo entregó y no hay acta: que la muestre hoy | 3 |
| María Restrepo | Aprobar el diseño 13 | 2026-10-11 (6 días) | Aprobación con documento, o fecha | 2 |
| Camilo Beltrán | Actualizar la matriz 14 | 2026-10-11 (6 días) | Dijo el 10-03 que ya lo entregó y no hay acta: que la muestre hoy | 2 |
| Elena Duarte | Entregar el punto 16 | 2026-10-15 (2 días) | Entrega con documento, o fecha | 2 |

Fuente: ficha de compromisos al 2026-10-17; minutas del comité del 09-12 al 10-10.

### Se decide hoy o se atrasa

| Qué | Quién decide | Si no se decide | Min |
|---|---|---|---|
| Fecha del ajuste del presupuesto. En las notas del 10-17 dice «la otra semana», que no es una fecha | Laura Vélez | Sigue sin fecha, no puede vencer y no se puede cobrar | 3 |
| «Confirmar la fecha 7» (Jorge Medina, dicho el 09-12) y «Validar el ambiente 12» (Gustavo Neira, dicho el 09-19): ambos dicen que ya entregaron y no hay acta, y ninguno tiene fecha. Acta o fecha | Jorge Medina y Gustavo Neira | Siguen abiertos sin poder vencer; el más viejo lleva 35 días sin fecha | 3 |

Fuente: notas de reunión del 2026-10-17 (línea 5) y minutas del 09-12 y 09-19.

### Vence antes de la próxima
Se lee en voz alta y cada uno confirma que llega o avisa hoy que no. Si Rubén Cárdenas o Mauricio Pérez no llegan, la fecha es el 10-19, que cae antes de la reunión.

| Quién | Qué | Para cuándo |
|---|---|---|
| Mauricio Pérez | Confirmar la fecha 23 | 2026-10-19 |
| Rubén Cárdenas | Entregar el punto 24 | 2026-10-19 |
| Rubén Cárdenas | Revisar el anexo 19 | 2026-10-20 |
| Gustavo Neira | Entregar el punto 8 (ya reprogramado 2 veces: 10-11 y 10-22) | 2026-10-22 |
| Andrés Lozano | Actualizar la matriz 22 | 2026-10-25 |
| Óscar Ramírez | Revisión con el proveedor. Las notas no aclaran si él se comprometió o si la reunión fijó la fecha: que lo confirme él (2 min) | 2026-10-27 |

Total del bloque: 4 minutos, con los 2 de Óscar incluidos.

### No es de esta reunión

| Qué | Por qué | Dónde va |
|---|---|---|
| Validar el ambiente 4 (Carlos Peña, vencido hace 22 días; dijo el 09-12 que ya lo había entregado y no hay acta) | Carlos Peña no figura entre los asistentes del 10-10 ni del 10-17 | Que la gerente lo contacte antes; si no responde, `/pm-commitments` |
| Hito «Despliegue en la cadena» vencido (fecha 2026-10-09), y cuatro hitos dados por cumplidos sin evidencia | El informe del 10-15 declara «verde» y 92 %; reabrirlo excede lo que esta sala decide | Comité del 2026-10-31, con `/pm-escalate` |
| Proyección de costo 19,4 % sobre lo aprobado | Pasa el umbral de 10 % y la autoridad del proyecto no consta en la ficha | Comité, con `/pm-escalate` |
| Entregables del proveedor CT-338 vencidos sin aceptación: Licenciamiento (2025-10-23), Bolsa de horas (2026-01-30), Configuración del catálogo (2026-05-09). Soporte del primer trimestre, aceptado sin documento | Ninguno tiene doliente del lado del proyecto en la ficha. El proveedor no está en la sala | Comité y control de proveedor |
| Facturado COP 118.225.663 contra COP 95.848.542 aceptado: COP 22.377.121 de más | Es una decisión de pago, no de seguimiento | Comité, con `/pm-escalate` |
| Riesgo dicho el 10-17 y nadie registró: «el proveedor podría no llegar con el equipo completo para la siguiente fase» | Sin dueño, sin probabilidad, sin impacto, y nadie dijo quién lo mencionó | Dueño en `raid-taxonomy`; se menciona de pasada en el punto de Óscar si hay tiempo |

Fuente: ficha `PRY-203.json` (vendors, plan, money, raid); informe de avance 2026-10-15.

### Anexo — sin cambios desde el 2026-10-10 (comité anterior)
- Sandra Gil · Cerrar la prueba 18 · 2026-11-04 (cae después de la reunión).
- Camilo Beltrán · Aprobar el diseño 21 · 2026-11-07.
- Cerrados con documento (4): diseño 5 (Jorge Medina), matriz 6 (Javier Hoyos), documento 9 (Elena Duarte), ambiente 20 (Gustavo Neira). No se repasan.

### Fuera por tiempo
Nada. La suma es 49 minutos; el bloque «Vence antes de la próxima» (4 min) es el primero en cortarse si hay que bajar a 40 minutos, y detrás de él los dos puntos de «Se decide hoy» (6 min).

Lo que no sé: la duración real de la reunión, si Óscar Ramírez se comprometió o lo asignaron, si Carlos Peña va a asistir, y qué es el «documento 1».

### Después
Citar a la reunión es de la gerente; esta agenda no convoca a nadie. Cuando termine, `/pm-minutes` sobre las notas, y `/pm-escalate` para los puntos que suben al comité.

*Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17).*
