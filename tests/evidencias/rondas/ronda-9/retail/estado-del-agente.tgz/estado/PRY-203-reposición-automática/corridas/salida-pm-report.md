# Reposición automática (PRY-203) — semana del 2026-10-10 al 2026-10-17

*Corte: 2026-10-17. Gerente: Laura Vélez. Moneda: COP.*

**Declaración (paso 2):** sesión sin interfaz, nadie respondió. No se propuso ningún estado. Se toma como declaración la que el gerente ya dejó firmada en su propio informe de avance del 2026-10-15 (`20-seguimiento/2026-10-15-informe-avance.pdf`). Si el gerente declara otra cosa hoy, esa línea se reemplaza.

**Declara el gerente:** verde · 92 % · al 2026-10-15 (hace 2 días, vigente)
**Sustento documental:** **contradicho**
**Lo que el semáforo no explica:** 7 señales — compromisos vencidos, compromisos reprogramados, hitos «cumplidos» sin evidencia, hito vencido, desviación de costo, entregables de proveedor vencidos, facturado por encima de lo aceptado.

## Qué cambió esta semana
No hay corrida anterior contra la cual comparar: esta es la primera instantánea del proyecto (`snapshots/2026-10-17.json`), y el diff devuelve 0 cambios. **No se puede decir qué se movió desde la semana pasada.** Desde la próxima corrida este apartado se llena solo.

Lo único fechado dentro de la semana: el plan terminaba el 2026-10-09 y el hito final no se cumplió (ver abajo); las notas de reunión del 2026-10-17 agregaron un riesgo dicho y no registrado y un compromiso sin fecha.

## Lo que sigue igual y sigue mal
Sin corrida previa no se miden «días así» desde un estado anterior; los días son contra la fecha de vencimiento.

| Qué | Desde | Días así |
|---|---|---|
| Hito «Despliegue en la cadena» sin cumplir (cierre del proyecto) | 2026-10-09 | 8 |
| Proveedor: «Licenciamiento de la plataforma» pendiente | 2025-10-23 | 359 |
| Proveedor: «Bolsa de horas de desarrollo» pendiente | 2026-01-30 | 260 |
| Proveedor: «Configuración del catálogo» pendiente | 2026-05-09 | 161 |
| Hito «Diseño de la experiencia aprobado» marcado cumplido, sin evidencia | 2025-10-14 | 368 |
| Hito «Ambiente de pruebas certificado» marcado cumplido, sin evidencia | 2026-01-12 | 278 |
| Hito «Integración con el ERP» marcado cumplido, sin evidencia | 2026-04-12 | 188 |
| Hito «Piloto en tiendas» marcado cumplido, sin evidencia | 2026-07-11 | 98 |

## Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2026-10-09 | 2026-10-09 | 0 días contra ambas, **pero el cierre ya pasó y el hito final está pendiente** |
| Presupuesto | 1.200.000.000 | 1.200.000.000 | proyección 1.432.210.423 → **+19,4 %** (umbral 10 %) |

Replanificaciones: **0**. La línea base no se ha movido; la fecha vencida no se replanificó, simplemente se pasó. Control de cambios: 0 solicitudes registradas.

Avance: declarado 92 %. Con 4 de 5 hitos marcados cumplidos el plan sostiene entre 80 % y 100 %, así que el número no contradice al plan, **pero los 4 hitos cumplidos no tienen ninguna evidencia en los documentos**.

### Hitos de las próximas cuatro semanas
| Hito | Base | Vigente | Evidencia |
|---|---|---|---|
| (ninguno: el único pendiente, «Despliegue en la cadena», venció el 2026-10-09) | 2026-10-09 | 2026-10-09 | sin evidencia |

## Las cifras
| Aprobado | Comprometido | Ejecutado | Proyectado | Disponible real |
|---|---|---|---|---|
| 1.200.000.000 | 742.486.754 (61,9 %) | 251.538.678 (21,0 %) | 1.432.210.423 | **457.513.246** (aprobado − comprometido) |

La proyección supera lo aprobado en 232.210.423. Con el disponible real de 457,5 M y el ejecutado en 21 %, la proyección no se reconcilia con lo ejecutado a la fecha de cierre: hay que pedir la explicación.

## Abierto
**Reprogramados:**
- Natalia Ospina — «Enviar el documento 1»: **6 veces**; original 2026-09-28, hoy 2026-12-18.
- Laura Vélez — «Cerrar la prueba 2»: **5 veces**; original 2026-09-18, hoy 2026-11-24.
- Jorge Medina — «Revisar el anexo 11»: 3 veces; original 2026-10-01, hoy 2026-11-20.

**Vencidos sin evidencia (8):**
| Quién | Qué | Vencía | Días |
|---|---|---|---|
| Carlos Peña | Validar el ambiente 4 | 2026-09-25 | 22 |
| Liliana Torres | Confirmar la fecha 15 | 2026-09-29 | 18 |
| Laura Vélez | Cerrar la prueba 10 | 2026-10-03 | 14 |
| Ricardo Salas | Enviar el documento 17 | 2026-10-06 | 11 |
| Natalia Ospina | Revisar el anexo 3 | 2026-10-10 | 7 |
| María Restrepo | Aprobar el diseño 13 | 2026-10-11 | 6 |
| Camilo Beltrán | Actualizar la matriz 14 | 2026-10-11 | 6 |
| Elena Duarte | Entregar el punto 16 | 2026-10-15 | 2 |

**Sin fecha (3):** Jorge Medina «Confirmar la fecha 7»; Gustavo Neira «Validar el ambiente 12»; Laura Vélez «Mandar el ajuste del presupuesto» (notas del 2026-10-17).

**RAID sin movimiento:** 2 riesgos y 1 incidencia, ninguno con dueño, probabilidad, impacto ni fecha de último movimiento, así que los días sin moverse no se pueden contar:
- Riesgo: concentración del conocimiento en una sola persona.
- Riesgo: el proveedor podría no llegar con el equipo completo a la siguiente fase (dicho en reunión el 2026-10-17, nadie lo registró).
- Incidencia: dos semanas perdidas por la rotación de un desarrollador clave.

**Proveedor (Sistemas Comerciales del Norte, CT-338):** 1 de 4 entregables aceptado.
- Vencidos: 3 (licenciamiento, bolsa de horas, configuración del catálogo), todos pendientes.
- Aceptado sin documento: «Soporte del primer trimestre».
- **Facturado por encima de lo aceptado:** facturado 118.225.663 vs aceptado 95.848.542 → **22.377.121** de diferencia (4 de 4 montos declarados).

## Lo que necesito de alguien
- **Laura Vélez:** declarar el estado hoy, con las siete señales a la vista. Y la evidencia de los 4 hitos «cumplidos»: actas de recibo o aprobación.
- **Laura Vélez:** fecha para «Mandar el ajuste del presupuesto».
- **Natalia Ospina:** «Enviar el documento 1» lleva 6 reprogramaciones. Fecha firme o decisión de reasignarlo.
- **Laura Vélez:** «Cerrar la prueba 2», 5 reprogramaciones.
- **Dueño del contrato CT-338:** explicar los 22,4 M facturados sobre lo aceptado antes de aprobar pagos. *(Excede la autoridad del gerente: material de comité.)*
- **Comité (2026-10-31):** el cierre del 2026-10-09 pasó sin replanificar y la proyección está +19,4 % sobre lo aprobado. Se requiere decisión sobre nueva línea base y sobre el sobrecosto. *(Material de comité.)*

## Lo que no se sabe
**Sin dato:** producto (`identity.product`), autoridad que aprueba (`identity.authority`), fase (`identity.phase`).
**Datos viejos (más de 12 meses):** 12 campos de identidad, plan y presupuesto aprobado vienen del acta del 2025-07-06 (15 meses). Ninguno de los 15 campos de la ficha está marcado como evidencia ni como declaración.
**Silencio:** último documento hace 0 días (notas del 2026-10-17; último informe de seguimiento hace 2 días) · última acta de comité hace 7 días (2026-10-10).

---
*Ficha: `estado/PRY-203-reposición-automática/records/PRY-203.json`, al 2026-10-17. 3 campos sin dato. Términos v1.1 aceptados por José Francisco Ñáñez el 2026-10-17: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.4.0*
