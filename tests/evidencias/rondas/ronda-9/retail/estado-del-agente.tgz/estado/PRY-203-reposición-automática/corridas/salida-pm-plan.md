# Plan — PRY-203 Reposición automática · borrador del 2026-10-17
**Desde:** acta de constitución del 2025-07-06 (`00-gobierno/2025-07-06-acta-constitucion.docx`) · **Criterio de éxito:** «Reposición automática en producción y medido» (acta). Está declarado, pero sin métrica ni meta de «medido».

> Términos: ya vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17), no se registraron de nuevo. Esta es una sesión sin interfaz: las preguntas que habría hecho van abajo como «Preguntas para el equipo».

**Dos cosas antes de leer el plan**
1. Este proyecto no está en su punto de partida. Ya existe el cronograma v1 (línea base 1, aprobada el 2025-07-06), el cierre comprometido era el 2026-10-09 —ya pasó— y el informe del 2026-10-15 declara verde y 92 %. Este borrador es la estructura que sale **del acta**; no sustituye ni corrige la línea base. Si lo que se busca es revisar el plan vigente, el comando es `/pm-plan revisar` sobre el cronograma.
2. No hay carpeta de fichas de la PMO en la configuración, así que no hay proyectos análogos a la vista.

## Lo que le falta al acta
| Qué | Consecuencia de planificar sin eso |
|---|---|
| Autoridad del gerente no declarada | No se sabe qué puede decidir quien planifica y qué debe subir al patrocinador. Todo cambio de fecha o de presupuesto queda sin dueño de la decisión. |
| Alcance con marcadores: «Componente 1 / 2 / 3» | No hay entregables reales que descomponer. La WBS no puede pasar de ese nivel sin que alguien invente qué es cada componente. |
| Fuera de alcance genérico: «Lo que otro proyecto cubre» | No dice cuál proyecto ni qué. No se puede defender la frontera cuando llegue una solicitud de cambio. |
| Objetivo del negocio genérico: «Entregar reposición automática para Mercadeo» | Sin resultado esperado no hay forma de saber si «medido» se cumplió. |
| «Medido» sin indicador, línea de base ni meta | El criterio de éxito no se puede verificar. Es el vacío más caro: define cuándo se acepta el proyecto. |
| Quién acepta cada entregable: el acta no lo dice | Los nodos terminales quedan sin aceptante, salvo los del proveedor (ver WBS). |
| Producto asociado: «No aplica» | No hay producto contra el cual cruzar el proyecto. Puede ser correcto; confirmarlo. |
| Dependencias: «Ninguna declarada» | Contradice el plan: hay un proveedor (CT-338) y una integración con el ERP. Se anota como dependencia no declarada, no como inexistente. |
| Presupuesto y fechas | Sí están (1.200.000.000 COP; inicio 2025-07-16, cierre 2026-10-09). Patrocinador, gerente y comité también (Carlos Peña, Laura Vélez, Comité de Expansión). |

## WBS
Solo hay entregables identificables en tres fuentes: el acta, el contrato CT-338 y los hitos del cronograma v1. Lo demás está sin definir.

| # | Entregable | Quién lo acepta | De dónde sale | Duración |
|---|---|---|---|---|
| 1 | Componente 1 (el acta no dice qué es) | Sin definir | del acta (nombre) · contenido **sin definir** | — |
| 2 | Componente 2 (ídem) | Sin definir | del acta (nombre) · contenido **sin definir** | — |
| 3 | Componente 3 (ídem) | Sin definir | del acta (nombre) · contenido **sin definir** | — |
| 4 | Licenciamiento de la plataforma (proveedor) | Gerente del proyecto, con acta de recibo firmada | del contrato CT-338 | — |
| 5 | Bolsa de horas de desarrollo (proveedor) | Gerente del proyecto, con acta de recibo firmada | del contrato CT-338 | — |
| 6 | Configuración del catálogo (proveedor) | Gerente del proyecto, con acta de recibo firmada | del contrato CT-338 | — |
| 7 | Soporte del primer trimestre (proveedor) | Gerente del proyecto, con acta de recibo firmada | del contrato CT-338 | — |
| 8 | Diseño de la experiencia aprobado | Sin definir (quién aprueba) | del cronograma v1 (hito) | — |
| 9 | Ambiente de pruebas certificado | Sin definir (quién certifica) | del cronograma v1 (hito) | — |
| 10 | Integración con el ERP | Sin definir | del cronograma v1 (hito) | — |
| 11 | Piloto en tiendas | Sin definir | del cronograma v1 (hito) | — |
| 12 | Despliegue en la cadena | Sin definir | del cronograma v1 (hito) | — |
| 13 | Reposición automática en producción y medido | Sin definir; el patrocinador es quien más probablemente acepta, pero el acta no lo dice | del acta (criterio de éxito); la medición está **sin definir** | — |
| 14 | Medición de resultados | Sin definir | **supuesto**: «medido» exige un entregable propio; ningún documento lo lista | — |

Los hitos 8–12 son puntos de control, no entregables aceptables hasta que alguien diga qué se recibe en cada uno. Por eso su aceptante está sin definir.

**Duraciones.** La única cifra citable es del cronograma v1: entre cada par de hitos consecutivos hay 90 días (2025-07-16 → 2025-10-14 → 2026-01-12 → 2026-04-12 → 2026-07-11 → 2026-10-09). Esa regularidad parece plantilla más que estimación; la dejo como dato y no como duración propuesta. Las fechas del contrato son fechas comprometidas, no duraciones.

## Orden
Sin fechas; solo qué necesita qué.
- Todo lo del proveedor (4–7) depende del contrato CT-338 vigente. Cada uno se factura contra acta de recibo firmada, así que su cierre depende de que exista esa acta.
- 8 (diseño aprobado) antes que 9 (ambiente certificado), que antes que 10 (integración con el ERP), según el orden del cronograma v1.
- 11 (piloto en tiendas) necesita 10 y 9. **Supuesto.**
- 12 (despliegue en la cadena) necesita 11. **Supuesto.**
- 13 (producción) necesita 12; 14 (medición) necesita 13 y una definición de «medido».
- Dónde encajan los Componentes 1–3 y el licenciamiento, la bolsa de horas y el catálogo respecto a 8–12: **sin definir.**
- Dependencia no declarada: la integración con el ERP implica a un tercero que el acta no nombra.

## Supuestos sobre los que está construido
| Supuesto | Qué pasa si resulta falso |
|---|---|
| Los hitos del cronograma v1 son la columna vertebral del trabajo y el orden entre ellos es el listado | La secuencia de la sección Orden se rompe y hay que reordenar. |
| Piloto, despliegue y producción son una cadena: cada uno necesita el anterior | Podría haber trabajo en paralelo que acorta el cierre, o un despliegue sin piloto completo. |
| «Medido» exige un entregable de medición separado (nodo 14) | Si la medición es parte del nodo 13, sobra el nodo. Si no existe, el criterio de éxito no se puede cerrar. |
| Los hitos son puntos de control y no entregables | Si cada uno tiene un entregable aceptable, falta nombrarlo y su aceptante. |
| Los Componentes 1–3 son entregables propios y no sinónimos de los hitos | Si son lo mismo que los hitos, la WBS duplica nodos. |
| Quien aceptó los hitos ya cerrados no se necesita para el plan hacia adelante | Si hay aceptaciones pendientes por escrito, el avance declarado (92 %) se sostiene en menos de lo que parece. |

Estos pasan al registro de riesgos en cuanto el plan se apruebe.

## Sin definir
| Qué | Quién lo define |
|---|---|
| Qué son los Componentes 1, 2 y 3 | Patrocinador (Carlos Peña) y gerente (Laura Vélez) |
| Qué proyecto cubre lo que queda fuera de alcance, y qué es | Patrocinador / Comité de Expansión |
| Indicador, línea de base y meta de «medido» | Patrocinador |
| Autoridad del gerente al planificar | Patrocinador / Comité de Expansión |
| Aceptante de cada entregable que no es del proveedor (1–3, 8–14) | Patrocinador |
| Qué se recibe en cada hito | Gerente con el aceptante |
| Dependencias reales (ERP, tiendas piloto, el proveedor) | Gerente |
| Estado de las aceptaciones previas de los hitos cerrados | Gerente (la evidencia no está en la carpeta) |

## Proyectos análogos
Ninguno a la vista: la configuración de este proyecto no apunta a una carpeta de fichas de la PMO. Es la respuesta correcta y evita una falsa precisión; no hay base para decir cuánto suelen correrse proyectos así.

## Preguntas para el equipo
Una por cada duración vacía.
1. ¿Qué entrega cada uno de los Componentes 1, 2 y 3, y cuánto toma cada uno?
2. ¿Cuánto toma el licenciamiento de la plataforma desde que el proveedor arranca, y quién lo recibe?
3. ¿Cuánto toma consumir la bolsa de horas de desarrollo, y quién certifica que se consumió?
4. ¿Cuánto toma la configuración del catálogo, y quién valida el catálogo configurado?
5. ¿Qué se recibe en el soporte del primer trimestre, y quién lo acepta? (el contrato dice que ya está recibido)
6. ¿Cuánto toma el diseño de la experiencia y quién lo aprueba?
7. ¿Cuánto toma certificar el ambiente de pruebas y quién certifica?
8. ¿Cuánto toma la integración con el ERP y quién del lado del ERP la valida?
9. ¿Cuánto dura el piloto en tiendas, cuántas tiendas son y quién lo da por bueno?
10. ¿Cuánto toma el despliegue en la cadena y quién lo acepta?
11. ¿Qué es «medido»: qué indicador, con qué meta, durante cuánto tiempo y quién lo lee?
12. ¿Cuánto tiempo hace falta entre producción y la medición del resultado?

## Para comprometer una fecha falta
- **La disponibilidad real del equipo.** El informe del 2026-10-15 menciona dos semanas perdidas por la rotación de un desarrollador clave y concentración del conocimiento en una persona; ningún documento dice quién queda y con cuánta dedicación.
- **La fecha del proveedor.** En la reunión del 2026-10-17 se comentó que el proveedor podría no llegar con el equipo completo a la siguiente fase; la revisión con el proveedor (Óscar Ramírez) quedó para el 2026-10-27.
- **La ventana de la sala de producción / el despliegue en tiendas.** No está en ningún documento.
- **El ajuste del presupuesto** que Laura Vélez quedó de mandar «la otra semana» (sin fecha). La proyección del informe (1.432.210.423 COP) supera el aprobado (1.200.000.000 COP).

## Lo que este borrador no hizo
No comprometió ninguna fecha, no estimó por analogía, no rellenó nodos sin definir, no creó línea base ni asignó personas. Cuando el plan se apruebe, puede registrarse como línea base y los supuestos pasar al RAID con doliente; hoy ya existe la línea base 1 y habría que decidir cómo se relaciona con esta.
