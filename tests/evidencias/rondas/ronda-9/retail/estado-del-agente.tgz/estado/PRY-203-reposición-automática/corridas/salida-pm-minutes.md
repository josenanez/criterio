# Acta — Reposición automática (PRY-203) · 2026-10-17
**Asistieron:** Andrés Lozano, Camilo Beltrán, Elena Duarte, Gustavo Neira, Jorge Medina, Laura Vélez, Liliana Torres, María Restrepo, Mauricio Pérez, Natalia Ospina, Ricardo Salas, Rubén Cárdenas, Sandra Gil, Óscar Ramírez · **Fuente:** `2026-10-17-notas-reunion.txt` · **Ausentes con tema en agenda:** no se puede decir; las notas no traen agenda. (Estuvieron en la del 10-10 y no están hoy: nadie. Hoy aparece por primera vez Óscar Ramírez.)

## Compromisos
| Quién | Qué | Para cuándo | |
|---|---|---|---|
| Natalia Ospina | Enviar el documento 1 | 2026-12-18 | **Reprogramado por 6.ª vez.** Primera promesa 2026-09-28 (original); fechas siguientes: 10-12, 10-23, 11-08, 11-25, 12-04 y ahora 12-18. Línea 4 de las notas: «no alcanzó, se compromete para el 18/12/2026». |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-27 | Nuevo. Línea 6: «Óscar Ramírez: revisión con el proveedor, queda para el 2026-10-27». Ver nota en «Sin resolver». |

### Sin fecha
| Quién | Qué |
|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto — «la otra semana» (línea 5). No es una fecha; se registra como `no_declarada`. |

Ya había otros dos sin fecha de reuniones anteriores (Jorge Medina, «Confirmar la fecha 7»; Gustavo Neira, «Validar el ambiente 12»). Con este son **3 sin fecha**.

## Decisiones
Ninguna. Las notas no registran una sola decisión con quién la tomó y qué se descartó.

## Quedó sin decidir
| Qué | Por qué | Quién tiene la facultad |
|---|---|---|
| Qué se hace con «Enviar el documento 1», que lleva 6 reprogramaciones | Se movió la fecha otra vez y no se discutió otra cosa | No consta en las notas |
| Cuándo se envía el ajuste del presupuesto | Se dijo «la otra semana» | No consta; la doliente es Laura Vélez |

## Intenciones sin doliente
Ninguna en esta reunión.

## Dicho al pasar y no registrado
| Qué | Quién lo dijo | Categoría | Ya estaba en el RAID |
|---|---|---|---|
| «El proveedor podría no llegar con el equipo completo para la siguiente fase» (línea 7: «nadie lo anotó como riesgo») | No consta: la nota dice «se comentó», sin nombre | Riesgo (proveedor: Sistemas Comerciales del Norte, CT-338) | **No.** Entra a la ficha sin dueño, sin probabilidad ni impacto: no se los inventé. |

## Cerrado en esta reunión
Nada. Ninguna de las líneas trae un documento de recibo, así que no se cierra ningún compromiso.

## Lo que esta reunión contradice
Nada. Ni cambio de patrocinador, ni de fecha de cierre, ni de comité. (El informe de avance del 10-15 dice «verde» y 92 %; eso no lo contradice la reunión, lo contradicen los documentos: ver abajo.)

## Sin resolver de la transcripción
- «Óscar Ramírez: revisión con el proveedor, queda para el 2026-10-27»: no queda claro si él se comprometió a hacerla o si la reunión la fijó para esa fecha y él es solo el nombre asociado. La registré a su nombre porque es lo que dice la línea; confírmalo con él.
- «Laura Vélez queda de mandar el ajuste del presupuesto la otra semana»: «la otra semana» dicho el sábado 10-17 sería 10-19 a 10-25 o 10-26 a 11-01; no lo resolví.
- «Próxima reunión en dos semanas»: sería 2026-10-31, que coincide con `committee_next` de la configuración. No hay día dicho.
- «Documento 1»: en las notas no se dice qué es ni por qué «no alcanzó».

## Recalculado (`compute`, sin `record_issues`)
- Compromisos vencidos sin evidencia: **8** (Natalia Ospina «anexo 3», Carlos Peña «ambiente 4», Laura Vélez «prueba 10», María Restrepo, Camilo Beltrán, Liliana Torres, Elena Duarte, Ricardo Salas).
- Reprogramados por encima del umbral de 3: **3** (Natalia Ospina 6 veces, Laura Vélez «prueba 2» 5 veces, Jorge Medina «anexo 11» 3 veces).
- Sin fecha: **3**.
- Contra el informe del 10-15 («verde», 92 %): el cálculo encuentra 7 señales que el informe no recoge: hito «Despliegue en la cadena» vencido hace 8 días; 4 hitos dados por cumplidos sin evidencia; proyección de costo 19,4 % sobre lo aprobado; 3 entregables del proveedor vencidos y lo facturado por encima de lo aceptado en COP 22.377.121; y los compromisos de arriba. Esta reunión no resolvió ninguna.

## Qué quedó en la ficha
Los compromisos de hoy y el riesgo del proveedor ya estaban cargados en `estado/…/records/PRY-203.json` desde `pm-setup` (con fecha 2026-10-17 y esta misma fuente); los verifiqué contra las notas y coinciden. No modifiqué la ficha en esta corrida.

## Después
`/pm-commitments` para el seguimiento completo. `/pm-publish` solo si cambias algún campo de la ficha; esta reunión no contradice al expediente. **El acta sale aquí; guárdala tú.**

*Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17).*
