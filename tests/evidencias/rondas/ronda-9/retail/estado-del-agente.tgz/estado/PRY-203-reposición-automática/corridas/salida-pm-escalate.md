## Para decisión — Reposición automática (PRY-203) · 2026-10-17

Para el Comité de Expansión del 2026-10-31. No pasaste un tema concreto, así que armé el paquete con lo que ya estaba marcado como escalable en la agenda y en la ficha. Son cuatro decisiones, de la primera depende que las otras tres lleguen a quien puede tomarlas.

**Primero, lo que no encuentro:** el acta de constitución del 2025-07-06 no declara la autoridad de la gerente: ni umbral de gasto, ni facultad para mover fechas, ni quién aprueba cambios. Tampoco declara dependencias («Ninguna declarada») ni producto asociado. Por eso en cada decisión de abajo «quién decide» sale como *sin definir en el acta*, y no lo completo por suposición.

---

### 1. ¿Quién tiene la facultad sobre fechas, costo y cambios en PRY-203? (la pregunta que va primero)

**Quién decide:** Comité de Expansión (aprobó el acta y el presupuesto el 2025-07-06) · **Si no se decide hoy:** las decisiones 2, 3 y 4 se pueden volver a devolver con un «eso lo decide usted». La reunión del 2026-10-31 es la próxima fecha de comité; no encontré en los documentos una fecha límite externa.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. El comité declara por escrito la autoridad de la gerente (umbrales de costo, de fecha y de cambio) y queda anexa al acta | Sin cambio | Se resuelve en la sesión del 10-31 | Sin costo directo declarado |
| B. El patrocinador (Carlos Peña) decide los tres puntos siguientes en su nombre | Sin cambio | Depende de su agenda; no consta en documentos | Sin costo directo; concentra la decisión en una persona que además tiene un compromiso abierto sin evidencia («Validar el ambiente 4», vence 2026-09-25) |

**Recomiendo:** A. Deja la regla escrita para todo lo que venga después; con B se decide una vez y la pregunta vuelve.

---

### 2. ¿Se reabre el estado «verde / 92 %» y se declara vencido el hito «Despliegue en la cadena»?

**Quién decide:** sin definir en el acta (ver 1); el informe lo firma la gerente, la revisión de su estado es del comité · **Si no se decide hoy:** el hito lleva 8 días vencido (2026-10-09) y el informe del 10-15 sigue diciendo verde; cada comité que pasa con ese estado deja una fecha más sin base.

Hechos con cita: el hito «Despliegue en la cadena» tenía fecha 2026-10-09 y sigue pendiente (cronograma v1). Los otros cuatro hitos aparecen como cumplidos, pero sin evidencia de cumplimiento en ningún documento. El informe declara verde y 92 %; lo ejecutado es COP 251.538.678 de 1.200.000.000 (21 %) y los compromisos de las reuniones llevan reprogramaciones de hasta seis veces.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Reabrir el estado: pasar a rojo/ámbar, pedir la evidencia de los cuatro hitos y una fecha nueva del despliegue con su motivo, como control de cambios | Sin cambio declarado | La fecha nueva no está en ningún documento. Mínimo 8 días ya consumidos | Sin dato |
| B. Mantener el verde hasta que haya fecha nueva | Sin cambio | Sin fecha | Sin dato; el costo es que el comité decide sobre un estado que los documentos no sostienen |

**Recomiendo:** A. Es la única opción donde la fecha nueva llega con evidencia; la línea base v1 no se toca, la nueva se agrega como v2.

---

### 3. ¿Se aprueba una proyección de COP 1.432.210.423 (19,4 % sobre lo aprobado), o se recorta alcance?

**Quién decide:** sin definir en el acta (ver 1); el presupuesto lo aprobó el Comité de Expansión · **Si no se decide hoy:** la gerente quedó de mandar «el ajuste del presupuesto la otra semana» sin fecha (notas del 10-17); sin decisión, ese ajuste llega y no hay a quién dirigirlo.

Hechos con cita: aprobado 1.200.000.000; proyección 1.432.210.423; diferencia 232.210.423 (informe de avance del 2026-10-15). Supera el umbral de 10 % de la configuración. El informe declara verde con esa proyección.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Ampliar el presupuesto en la diferencia | Sin cambio | Sin cambio declarado | +COP 232.210.423 (+19,4 %) |
| B. Mantener los 1.200 M y recortar alcance | Sin dato: la ficha dice «Componente 1, 2, 3» y no los describe | Sin dato | 0 sobre lo aprobado; qué componente sale lo tiene que decir la gerente |
| C. Esperar el ajuste de la gerente antes de decidir | Sin cambio | Una semana o más; no tiene fecha | Sin costo de decisión, pero la decisión se aplaza |

**Recomiendo:** C, con una condición: que el ajuste llegue con fecha declarada antes del comité. Sin ese ajuste no hay base para elegir entre A y B, y no tengo cifras para armarlo yo.

---

### 4. ¿Se pagan COP 22.377.121 de la factura FV-1338 que exceden lo aceptado, y se regulariza CT-338?

**Quién decide:** sin definir en el acta (ver 1); la condición de pago del contrato dice que cada entregable se factura contra acta de recibo firmada por la gerente · **Si no se decide hoy:** la factura está radicada en cuentas por pagar desde el 2026-09-09; no encontré en los documentos una fecha de vencimiento de pago, así que no la invento.

Hechos con cita: facturado 118.225.663 (FV-1338). Entregable aceptado: uno, «Soporte del primer trimestre», 95.848.542, y la ficha lo da por aceptado sin acta de recibo. Diferencia: 22.377.121. Otros tres entregables (Licenciamiento 2025-10-23, Bolsa de horas 2026-01-30, Configuración del catálogo 2026-05-09) están vencidos y sin acta. Los 118.225.663 no corresponden al monto de ninguna combinación de entregables de 95.848.542 cada uno.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Pagar solo lo respaldado por acta (hoy, 0 con acta firmada en la carpeta; 95.848.542 si aparece el acta del Soporte) y devolver el resto | Sin cambio | Se reabre la discusión con el proveedor | Se evita pagar hasta COP 22.377.121 sin soporte |
| B. Pagar la factura completa | Sin cambio | Cierra rápido | COP 22.377.121 pagados sin respaldo contractual |
| C. Retener el pago hasta que el proveedor aclare a qué entregables corresponde la factura | Sin cambio | Depende del proveedor | Riesgo de relación con el proveedor, que además ya fue mencionado en reunión como posible falta de equipo para la fase siguiente |

**Recomiendo:** C y, en paralelo, que la gerente muestre el acta del Soporte o diga que no existe. El contrato condiciona el pago al acta; mientras no la veamos, A y B son decisiones sin respaldo.

---

### A quién alcanza

| Proyecto | Gerente | ¿Sostiene su fecha? | Dependencia confirmada |
|---|---|---|---|
| Ninguno en la ficha | — | — | — |

El cálculo de efecto (`impact`, con 8 días: lo que el despliegue ya lleva vencido) devuelve **cero proyectos y cero hitos alcanzados**. Eso solo quiere decir que *este* estado no tiene otros proyectos cargados ni dependencias declaradas (el acta dice «Ninguna declarada»). No quiere decir que ningún otro proyecto dependa de este. Antes del comité, la gerente debería confirmarlo con la PMO. Tampoco puedo decir cuántos días más se mueve cada proyecto alcanzado: eso necesita holgura por actividad y la ficha no la tiene.

### Mis hitos por los que pasa

| Hito | Fecha vigente | En cuántos días |
|---|---|---|
| Despliegue en la cadena | 2026-10-09 (ya vencido) | 8 días vencido al 2026-10-17; días adicionales: sin dato |

### Lo que no escala, y se queda en la reunión de la semana

- «Documento 1» (Natalia Ospina, seis reprogramaciones, ahora 2026-12-18) y «Cerrar la prueba 2» (Laura Vélez, cinco): cumplen el criterio de reprogramación de la configuración (3), pero no sé qué las bloquea. Lo que escala es esa pregunta, y la sala del 10-31 es quien la contesta; solo suben si ahí sigue sin respuesta.
- «Validar el ambiente 4» (Carlos Peña): que la gerente lo llame antes; si no responde, `/pm-commitments`.
- El riesgo «el proveedor podría no llegar con el equipo completo» no tiene dueño, probabilidad ni impacto: registrarlo es de la gerente.

### De dónde sale esto

- Autoridad no declarada, dependencias y presupuesto aprobado: `00-gobierno/2025-07-06-acta-constitucion.docx`.
- Condición de pago, montos y fechas de entregables: `00-gobierno/2025-06-30-contrato-ct-338.docx`.
- Factura de 118.225.663: `20-seguimiento/2026-09-09-factura-ct-338.pdf`.
- Estado verde, 92 %, proyección, ejecutado y riesgos: `20-seguimiento/2026-10-15-informe-avance.pdf`.
- Hito «Despliegue en la cadena» y los demás: `10-plan/2025-07-06-cronograma-v1.xlsx`.
- «Ajuste del presupuesto la otra semana», riesgo del proveedor, documento 1 al 12-18: `2026-10-17-notas-reunion.txt`.
- Reprogramaciones: minutas `30-reuniones/2026-09-05` a `2026-10-10`.
- Efecto en otros proyectos: `portafolio.py impact` (8 días), sobre `estado/PRY-203-reposición-automática`.

**Lo que no sé:** qué puede decidir la gerente según el acta; a qué entregables corresponde la factura; si existe un acta de recibo del Soporte; qué es el «documento 1» y qué lo bloquea; la fecha nueva del despliegue; si otro proyecto depende de este. No lo rellené.

*Este paquete no escala solo: llevarlo al comité es tuyo. No decide ni le escribe a nadie. Las recomendaciones son mías y están para que el comité las acepte o las cambie.*

*Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17).*
