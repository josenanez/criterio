## Reposición automática (PRY-203) · 2026-10-17

**Revisé:** 17 documentos · 17 nuevos para el índice (primer barrido, no había índice previo) · 0 minutas sin procesar. La última, `2026-10-17-notas-reunion.txt`, ya tiene su acta y sus compromisos en la ficha de hoy.

### Lo que se venció solo
No hay una corrida anterior contra la cual comparar, así que no puedo separar lo que cruzó de lo que ya estaba. El estado de hoy, de la revisión de compromisos de las 21:06 (sin cambios desde entonces):
- **Ocho compromisos vencidos sin evidencia**, el más viejo desde el 2026-09-25 (Carlos Peña, ambiente 4, 22 días).
- **Tres reprogramados** en o sobre el umbral de 3: Natalia Ospina (documento 1, seis veces), Laura Vélez (prueba 2, cinco) y Jorge Medina (anexo 11, tres).
- **Vencen hasta el 2026-10-24:** Mauricio Pérez, fecha 23 (10-19); Rubén Cárdenas, punto 24 (10-19) y anexo 19 (10-20); Gustavo Neira, punto 8 (10-22).

Detalle y citas en `corridas/salida-pm-commitments.md`. No repito el resto.

### La reunión
Próximo comité: 2026-10-31, a 14 días. Todavía no toca agenda; ya hay una armada hoy (`salida-pm-agenda.md`), así que no la vuelvo a ofrecer. No hay reunión pasada sin acta. El informe toca el 2026-10-30.

### Tu ficha publicada
Al día: se publicó hoy después del último cambio de la ficha.

**Vuelvo el 2026-10-18.**
