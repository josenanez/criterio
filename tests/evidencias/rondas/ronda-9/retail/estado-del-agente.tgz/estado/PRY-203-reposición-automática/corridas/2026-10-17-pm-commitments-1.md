# Corrida del 2026-10-17 · pm-commitments

1 proyectos · 32 s · 26 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_overdue` | 8 |
| `milestone_met_without_evidence` | 4 |
| `commitment_undated` | 3 |
| `commitment_rescheduled` | 3 |
| `vendor_deliverable_late` | 3 |
| `milestone_overdue` | 1 |
| `variance_cost` | 1 |
| `vendor_accepted_without_evidence` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `declared_vs_evidence` | 1 |

3 compromisos reprogramados 3 o más veces (Natalia Ospina 6, Laura Vélez 5, Jorge Medina 3); 8 vencidos sin evidencia; 3 sin fecha

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## Compromisos — Reposición automática (PRY-203) · al 2026-10-17

Cifras de `compute` sobre la ficha (sin `record_issues`). Revisión de todo lo abierto: 26 compromisos en la ficha, 4 cerrados con documento, 22 abiertos.

### Se viene reprogramando

> **Natalia Ospina** · Enviar el documento 1
> Prometido para el 2026-12-18, y antes para el 12-04, 11-25, 11-08, 10-23 y 10-12. La primera promesa fue el 2026-09-28.
> **Seis reprogramaciones no son un problema de seguimiento: son un bloqueo que nadie ha nombrado.** Las notas del 10-17 solo dicen «no alcanzó»; no dicen qué es el documento ni por qué no sale.

> **Laura Vélez** · Cerrar la prueba 2
> Prometido para el 2026-11-24, y antes para el 11-08, 10-29, 10-16 y 09-27. La primera promesa fue el 2026-09-18. **Cinco reprogramaciones.** La doliente es la gerente del proyecto.

> **Jorge Medina** · Revisar el anexo 11
> Prometido para el 2026-11-20, y antes para el 11-04 y el 10-17. La primera promesa fue el 2026-10-01. **Tres reprogramaciones**, en el umbral configurado (3).

### Vencidos sin evidencia
| Quién | Qué | Prometido para | Hace |
|---|---|---|---|
| Carlos Peña | Validar el ambiente 4 | 2026-09-25 | 22 días |
| Liliana Torres | Confirmar la fecha 15 | 2026-09-29 | 18 días |
| Laura Vélez | Cerrar la prueba 10 | 2026-10-03 | 14 días |
| Ricardo Salas | Enviar el documento 17 | 2026-10-06 | 11 días |
| Natalia Ospina | Revisar el anexo 3 (reprogramado 1 vez) | 2026-10-10 | 7 días |
| María Restrepo | Aprobar el diseño 13 | 2026-10-11 | 6 días |
| Camilo Beltrán | Actualizar la matriz 14 | 2026-10-11 | 6 días |
| Elena Duarte | Entregar el punto 16 | 2026-10-15 | 2 días |

Ocho vencidos. En dos la persona dijo que ya lo había entregado y no hay nada en el expediente que lo respalde: **Carlos Peña** (ambiente 4, minuta del 09-12) y **Natalia Ospina** (anexo 3, minuta del 10-10). Sigue abierto en ambos casos hasta que haya un acta de recibo o un correo de entrega. Camilo Beltrán (matriz 14, listado arriba) dijo lo mismo en la minuta del 10-03, también sin acta; y Jorge Medina (fecha 7) y Gustavo Neira (ambiente 12), que están en «Sin fecha».

### Vencen esta semana (hasta el 2026-10-24)
| Quién | Qué | Para cuándo |
|---|---|---|
| Mauricio Pérez | Confirmar la fecha 23 | 2026-10-19 |
| Rubén Cárdenas | Entregar el punto 24 | 2026-10-19 |
| Rubén Cárdenas | Revisar el anexo 19 | 2026-10-20 |
| Gustavo Neira | Entregar el punto 8 (ya reprogramado 2 veces: 10-11 y 10-22) | 2026-10-22 |

Fuera de la semana pero cerca: Andrés Lozano, matriz 22, el 2026-10-25; Óscar Ramírez, revisión con el proveedor, el 2026-10-27 (las notas no aclaran si él se comprometió o si la reunión fijó la fecha).

### Sin fecha
| Quién | Qué | Dicho el |
|---|---|---|
| Jorge Medina | Confirmar la fecha 7 (dice que ya lo entregó; sin acta) | 2026-09-12 |
| Gustavo Neira | Validar el ambiente 12 (dice que ya lo entregó; sin acta; no vuelve a aparecer) | 2026-09-19 |
| Laura Vélez | Mandar el ajuste del presupuesto («la otra semana») | 2026-10-17 |

Tres sin fecha. No pueden estar vencidos; por eso se cuentan aparte. El más viejo lleva 35 días sin una fecha.

### Cerrados con documento
| Quién | Qué | Documento |
|---|---|---|
| Jorge Medina | Aprobar el diseño 5 | `20-seguimiento/2026-09-26-acta-recibo-5.md` |
| Javier Hoyos | Actualizar la matriz 6 | `20-seguimiento/2026-10-03-acta-recibo-6.md` |
| Elena Duarte | Enviar el documento 9 | `20-seguimiento/2026-10-03-acta-recibo-9.md` |
| Gustavo Neira | Validar el ambiente 20 | `20-seguimiento/2026-10-10-acta-recibo-20.md` |

No hay una revisión de compromisos anterior a esta; estos cuatro son todos los cerrados que constan en la ficha.

### Contra el informe de avance
El informe del 10-15 declara «verde» y 92 %. Los compromisos son una de siete señales que ese informe no recoge (las otras: hito «Despliegue en la cadena» vencido hace 8 días, cuatro hitos dados por cumplidos sin evidencia, proyección de costo 19,4 % sobre lo aprobado, tres entregables del proveedor vencidos, y lo facturado por encima de lo aceptado en COP 22.377.121). Esas no son de este comando, pero cambian cómo se lee la lista de arriba.

### Después
- **Ofrezco formular como decisión para el comité** los tres reprogramados (Natalia Ospina, Laura Vélez, Jorge Medina): qué se pide, qué pasa si no se decide y quién tiene la facultad. Excede la autoridad de la gerente y por eso sube. Ojo: uno de los tres es de la propia gerente, y la autoridad del proyecto no consta en la ficha (`identity.authority` sin encontrar). Próximo comité: 2026-10-31. Se hace con `/pm-escalate`.
- Si algo de esto cambia lo que la ficha dice, `/pm-publish` para que la PMO lo vea. En esta corrida no modifiqué la ficha.

*Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17).*
