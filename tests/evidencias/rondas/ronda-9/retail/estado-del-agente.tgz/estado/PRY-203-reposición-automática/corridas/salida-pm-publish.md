Publiqué la ficha en `/home/claude/banco/ronda-9/retail/espacio/documentos/proyectos/PRY-203-reposición-automática/00-gobierno/ficha-pm.json`, con corte al 2026-10-17.

**Lleva:** 15 campos con dato · 3 sin decir en ninguna parte (identity.product, identity.authority, identity.phase) · declara **verde** al 2026-10-15 (92 % de avance)

**Lo más viejo que va ahí:** identity.code, identity.name, identity.sponsor, identity.manager, identity.committee, plan.end_date, money.approved y otros, todos del acta de constitución y el cronograma v1 del 2025-07-06 — 15 meses, pasa de un año.

**Fecha de cierre:** `plan.end_date` = 2026-10-09. No hay cronograma más nuevo que el v1 citado, así que la vigente coincide con la línea base original; el hito «Despliegue en la cadena» (2026-10-09) sigue pendiente, 8 días vencido.

**Lo primero que va a mirar la PMO:** el estado declarado es verde, y la recomputación de hoy lo contradice con 7 señales: compromisos vencidos y reprogramados, 4 hitos «cumplidos» sin evidencia, hito de despliegue vencido, proyección de costo 19,4 % sobre lo aprobado (COP 1.432.210.423 contra 1.200.000.000), tres entregables del proveedor atrasados y facturado por encima de lo aceptado (COP 22.377.121 de diferencia). Van en la ficha tal cual; la declaración sigue siendo tuya y va marcada como declarada.

Términos: vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17); no hizo falta registrarlos de nuevo. No avisé a nadie: vera la leerá en su próximo barrido.
