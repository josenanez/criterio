# Corrida del 2026-10-17 · portfolio-server

13 proyectos · 90 hallazgos

> El tiempo no se midió: faltó `corrida-inicio` al arrancar. Un tiempo escrito a mano es un recuerdo, no una medición.

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 28 |
| `commitment_overdue` | 12 |
| `declared_vs_evidence` | 9 |
| `progress_vs_plan` | 7 |
| `vendor_deliverable_late` | 7 |
| `vendor_accepted_without_evidence` | 5 |
| `variance_time` | 5 |
| `rebaseline_unauthorized` | 4 |
| `commitment_undated` | 4 |
| `commitment_rescheduled` | 3 |
| `variance_cost` | 2 |
| `milestone_overdue` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `vendor_invoiced_without_delivery` | 1 |
| `change_without_baseline` | 1 |

puerto 8787, carpeta del informe reportes, modo rato

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

# Rostrum — para mirarlo un rato

Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17); no se pidió aceptarlos de nuevo.

Modo elegido: **«para mirarlo un rato»** (respuesta sugerida; en una sesión sin interfaz nadie contestó, y es el modo con el que se empieza si no se sabe cuál se quiere). Se levanta en diez segundos, se ve funcionando, y la conversación con seguridad ya no es pedir permiso para una idea.

Hay informe: `reportes/` (13 proyectos PRY-199 a PRY-211, 7 productos, decisiones, proyectos, productos, portada).

Comando:

```
python3 "/home/claude/banco/criterio/plugins/criterio-portfolio/scripts/servidor.py" --informe reportes --estado estado --config .criterio/portafolio/config.json
```

Escucha en `127.0.0.1:8787`, solo en ese equipo. Se para con Ctrl-C. Si el puerto está ocupado, `--puerto 8788`. La configuración trae `organization.name` = Retail, así que el portal lleva ese nombre en todas las páginas.

| Ruta | Qué es | Para quién |
|---|---|---|
| `/` | Portada con las tres secciones y el formulario de peticiones | Todos |
| `/pmo` | Cómo va el portafolio: verdes que la evidencia no sostiene, silencios, patrocinadores con más de una cosa | La PMO |
| `/decisiones` | Lo que necesita decisión, como pregunta cerrada y con la consecuencia de no decidirla | Comité y patrocinador |
| `/proyectos` | Listado ordenado por lo que más pide atención | Todos |
| `/p/<código>` | Informe de un proyecto, con enlace al producto que lo originó | Quien gerencia y quien pregunta |
| `/productos` | Listado de productos y proyectos que no dicen qué producto construyen | Quien responde por un producto |
| `/producto/<nombre>` | Informe de un producto, con enlace a los proyectos que lo construyen | Quien responde por un producto |
| `/estado.json` | De cuándo es el informe y cuántas peticiones hay abiertas | Un mecanismo |

El enlace proyecto ↔ producto va en los dos sentidos: quien entra por un producto puede descubrir que lo construyen proyectos que reportan a comités distintos, y ese hallazgo no existe en ninguna otra página.

Lo que Rostrum no hace: no calcula (sirve lo que `informe.py` ya escribió), no escribe ninguna ficha (solo la petición, en `estado/peticiones/`), no autentica, no manda nada.

La cola de peticiones: el formulario de la portada no contesta en el momento; escribe la petición y ahí se queda hasta que el agente despierte (`due` y `requests` la cuentan; `answered` la cierra). Una petición abierta rompe el silencio de `/portfolio-wake`.

Cierre: para el patrocinador, el enlace de la portada solo sirve mientras alguien tenga el servidor encendido en ese equipo; mañana no funcionará. Si lo quiere estable, la siguiente conversación es «que quede corriendo» (`--abierto`, host y puerto dentro de la red, detrás del control de acceso que ya usan; el servidor no trae autenticación a propósito). El informe es del 2026-10-17 21:35; la portada lo dice sola, y queda desactualizado en cuanto se corra otro barrido sin regenerarlo con `/portfolio-report html`.
