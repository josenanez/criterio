Sale de: las fichas `estado/records/PRY-199…PRY-211` (RAID registrado), los informes de avance citados en ellas, las actas de constitución (sección «Dependencias declaradas»), las 11 minutas de comité de `30-reuniones/` (incl. las dos `.docx`, leídas por su caché) y `PRY-203/2026-10-17-notas-reunion.txt`. Términos vigentes (aceptados por José Francisco Ñáñez, 2026-10-17). Escala de probabilidad/impacto: ninguna definida por la organización; se usaría alta/media/baja, pero ningún ítem trae valoración.

## RAID — portafolio (13 proyectos) al 2026-10-17
19 riesgos · 0 supuestos · 13 incidencias · 0 dependencias
32 sin doliente · 32 sin movimiento medible · 1 no registrado formalmente

Los ids (`PRY-199·R1`, `·I1`) son de este informe: las fichas no traen id por ítem.

### Necesitan decisión ahora
| Id | Tipo | Qué | Doliente | Desde | Por qué sube |
|---|---|---|---|---|---|
| PRY-199·I1, 200·I1, 201·I1, 211·I1 | Incidencia | «Hallazgo de seguridad en los medios de pago» (misma redacción en 4 informes) | sin doliente | 2026-10-09 (200, 201, 211) / 2026-10-15 (199) | Aparece en 4 proyectos: afecta a más de uno. Hay que confirmar si es un solo hallazgo con un solo responsable o cuatro. |
| PRY-199·I2, 204·I1, 208·I1, 209·I1, 211·I2 | Incidencia | «La prueba de carga de temporada no alcanzó el umbral pactado y se repite» (5 informes) | sin doliente | 2026-10-05 a 2026-10-17 | Cruza 5 proyectos y la temporada alta es una fecha que no se mueve. Sin doliente ni fecha de la repetición. |
| PRY-199 (estado) | Incidencia | PRY-199 declara «verde» (informe 2026-10-15) con las dos incidencias anteriores abiertas en el mismo informe | sin doliente | 2026-10-15 | Contradicción entre el estado declarado y el RAID del mismo documento. |
| PRY-202·I1, 203·I1 | Incidencia | «El equipo perdió dos semanas por rotación de un desarrollador clave»; en ambos proyectos también está abierto el riesgo «concentración del conocimiento en una sola persona» (202·R2, 203·R1) | sin doliente | 2026-10-16 / 2026-10-15 | El riesgo ya se materializó parcialmente; mantenerlo como riesgo oculta que hay un daño ocurrido. |

### Detectados en reuniones, no registrados
| Qué | Tipo | Dicho en | Fecha |
|---|---|---|---|
| «Se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo» (PRY-203). Depende de un tercero: clasificable como dependencia. No dice qué proveedor. | Riesgo (candidato a dependencia) | PRY-203/2026-10-17-notas-reunion.txt, línea 7 | 2026-10-17 |

Es el único. Las otras 10 minutas (PRY-199, 200, 201, 202, 204, 206, 210, 211 y las seis de PRY-203) solo traen compromisos y asistentes; no dicen ningún riesgo, supuesto ni dependencia. No inventé ninguno.

### Sin doliente o sin fecha
| Id | Tipo | Qué | Qué falta |
|---|---|---|---|
| Los 19 riesgos | Riesgo | Todos | Doliente, fecha, probabilidad, impacto y último movimiento |
| Las 13 incidencias | Incidencia | Todas | Doliente y fecha de resolución (solo traen «desde») |

No relleno nada. Sin «último movimiento» no puedo decir cuáles llevan dos períodos quietos: es desconocido, no cero.

### Reclasificaciones propuestas
| Id | Está como | Debería ser | Por qué |
|---|---|---|---|
| PRY-207·R2, PRY-210·R1 | Riesgo | Dependencia | «El proveedor no ha confirmado la fecha de la última entrega» depende de un tercero (prueba rápida). Sería dependencia declarada, no confirmada. |
| PRY-202·R1, 204·R2, 205·R1, 206·R2, 209·R1 | Riesgo | Supuesto | «Disponibilidad de los jefes de tienda para el piloto» se está dando por cierta sin verificar. |
| PRY-201·R1, 209·R2 | Riesgo | Se mantiene, a confirmar | «Congelamiento de cambios en temporada alta» es un hecho de calendario; el riesgo real sería qué trabajo queda atrapado. |

### Dependencias en riesgo
| Id | Depende de | Confirmada | Qué pasó |
|---|---|---|---|
| — | — | — | Ninguna que cruzar. Las 6 actas con la sección «Dependencias declaradas» (PRY-201, 202, 204, 207, 209, 210) dicen «Ninguna declarada», y las fichas tienen 0 dependencias. Las dos dependencias de proveedor de arriba apuntan a un tercero, no a un código de proyecto. |

Esto no prueba que no existan: en los otros 7 proyectos (199, 200, 203, 205, 206, 208, 211) mi búsqueda de esa sección no encontró nada en los `.md`, y no leí sus actas `.docx` o su ausencia; no sé si declaran algo.

### Registro completo
Prob., impacto, doliente, fecha y último movimiento: «no registrado» en los 32 ítems (por eso las columnas van abreviadas).

| Id | Tipo | Qué | Fuente / desde |
|---|---|---|---|
| PRY-199·R1 | Riesgo | Cambio en la regulación de datos personales que puede mover el alcance | informe 2026-10-15 |
| PRY-199·I1 | Incidencia | Hallazgo de seguridad en los medios de pago | desde 2026-10-15 |
| PRY-199·I2 | Incidencia | Prueba de carga de temporada bajo el umbral, se repite | desde 2026-10-15 |
| PRY-200·R1 | Riesgo | Cambio en la regulación de datos personales | informe 2026-10-09 |
| PRY-200·I1 | Incidencia | Hallazgo de seguridad en los medios de pago | desde 2026-10-09 |
| PRY-201·R1 | Riesgo | Congelamiento de cambios en temporada alta | informe 2026-10-09 |
| PRY-201·I1 | Incidencia | Hallazgo de seguridad en los medios de pago | desde 2026-10-09 |
| PRY-202·R1 | Riesgo | Disponibilidad de los jefes de tienda para el piloto | informe 2026-10-16 |
| PRY-202·R2 | Riesgo | Concentración del conocimiento en una sola persona | informe 2026-10-16 |
| PRY-202·I1 | Incidencia | Dos semanas perdidas por rotación de un desarrollador clave | desde 2026-10-16 |
| PRY-203·R1 | Riesgo | Concentración del conocimiento en una sola persona | informe 2026-10-15 |
| PRY-203·R2 | Riesgo (no registrado) | Proveedor podría no llegar con el equipo completo | notas 2026-10-17 |
| PRY-203·I1 | Incidencia | Dos semanas perdidas por rotación de un desarrollador clave | desde 2026-10-15 |
| PRY-204·R1 | Riesgo | Concentración del conocimiento en una sola persona | informe 2026-10-15 |
| PRY-204·R2 | Riesgo | Disponibilidad de los jefes de tienda para el piloto | informe 2026-10-15 |
| PRY-204·I1 | Incidencia | Prueba de carga de temporada bajo el umbral, se repite | desde 2026-10-15 |
| PRY-205·R1 | Riesgo | Disponibilidad de los jefes de tienda para el piloto | informe 2026-10-07 |
| PRY-205·I1 | Incidencia | Validación con dos tiendas extendida una semana por conteo de inventario | desde 2026-10-07 |
| PRY-206·R1 | Riesgo | Cambio en la regulación de datos personales | informe 2026-10-09 |
| PRY-206·R2 | Riesgo | Disponibilidad de los jefes de tienda para el piloto | informe 2026-10-09 |
| PRY-206·I1 | Incidencia | Validación con dos tiendas extendida una semana por conteo de inventario | desde 2026-10-09 |
| PRY-207·R1 | Riesgo | Cambio en la regulación de datos personales | informe 2026-10-15 |
| PRY-207·R2 | Riesgo | Proveedor sin confirmar fecha de la última entrega | informe 2026-10-15 |
| PRY-208·R1 | Riesgo | Concentración del conocimiento en una sola persona | informe 2026-10-17 |
| PRY-208·I1 | Incidencia | Prueba de carga de temporada bajo el umbral, se repite | desde 2026-10-17 |
| PRY-209·R1 | Riesgo | Disponibilidad de los jefes de tienda para el piloto | informe 2026-10-05 |
| PRY-209·R2 | Riesgo | Congelamiento de cambios en temporada alta | informe 2026-10-05 |
| PRY-209·I1 | Incidencia | Prueba de carga de temporada bajo el umbral, se repite | desde 2026-10-05 |
| PRY-210·R1 | Riesgo | Proveedor sin confirmar fecha de la última entrega | informe 2026-09-29 |
| PRY-211·R1 | Riesgo | Concentración del conocimiento en una sola persona | informe 2026-10-09 |
| PRY-211·I1 | Incidencia | Hallazgo de seguridad en los medios de pago | desde 2026-10-09 |
| PRY-211·I2 | Incidencia | Prueba de carga de temporada bajo el umbral, se repite | desde 2026-10-09 |

## Qué no sé
- No sé quién es doliente de nada: ningún ítem lo trae.
- No sé si las incidencias repetidas en varios proyectos son un solo hecho; la redacción es idéntica, pero eso no lo prueba.
- No sé si los informes de PRY-199, 200 y 203 en adelante tienen más riesgos fuera de su sección «Riesgos abiertos»; no leí los PDF/DOCX originales, solo la caché de texto y las fichas.
- Los compromisos de las minutas (p. ej. los repetidos de PRY-203) no son RAID; quedan para `pm-commitments`.

## Siguiente paso
Puedo subir a comité las 2 incidencias que cruzan proyectos (seguridad de pagos, prueba de carga) y la contradicción de PRY-199, para el comité del 2026-10-23. Y proponer doliente para los 32 ítems: proponer, no asignar. ¿Cuál hago?

*Pie de rigor: borrador de trabajo, no decisión ni asesoría. Cada dato sale del documento citado; la verificación es suya.*
