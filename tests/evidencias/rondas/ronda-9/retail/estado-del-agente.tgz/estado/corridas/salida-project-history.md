Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17); no hizo falta registrarlos de nuevo.

## Historia · PRY-201 Programa de fidelización · 2025-05-14 a 2026-10-17

**Leí:** 7 documentos entre 2025-05-14 y 2026-10-17
**Trimestres sin un solo documento:** 2025-T3, 2025-T4, 2026-T1, 2026-T2 y 2026-T3. Los documentos están en 2025-T2 (el acta y el cronograma v1, del mismo día) y en 2026-T4 (los otros cinco).

### En una línea
El proyecto nace el 2025-05-14 con cierre el 2026-08-24; no hay ningún documento entre esa fecha y 2026-10-06, y todo lo que dice cómo fue la ejecución se escribió entre el 2026-10-06 y el 2026-10-17. En ese tramo aparecen un cronograma v2 que mueve el cierre a 2026-09-17 sin documento que lo apruebe, un informe en verde con 34% de avance contra un plan con 5 de 5 hitos cumplidos, y una solicitud de cambio (CC-01) pendiente de comité.

### Las cuatro cifras
| Replanificaciones | Atraso acumulado vs. original | Meses declarando sin sustento | Cambios de gobierno |
|---|---|---|---|
| 1 | 24 días (5.3 %) | No calculable: hay una sola declaración de estado (2026-10-09) | 0 vistos en los documentos |

### Línea de tiempo
| Fecha | Documento | Qué cambió |
|---|---|---|
| 2025-05-14 | 00-gobierno/2025-05-14-acta-constitucion.md | Se constituye el proyecto: 9.500.000.000 COP, inicio 2025-05-24, cierre 2026-08-24. Patrocinador Jorge Medina, gerente Andrés Lozano. Dependencias: ninguna declarada. |
| 2025-05-14 | 10-plan/2025-05-14-cronograma-v1.csv | Línea base v1: cinco hitos, el último el 2026-08-24. Los cinco figuran como «cerrado» en un documento con fecha de la constitución. |
| 2026-10-06 | 20-seguimiento/2026-10-06-acta-recibo-piloto-en-tiendas.pdf | Andrés Lozano recibe a satisfacción el piloto en tiendas (hito con fecha 2026-05-24). Único hito con evidencia. |
| 2026-10-09 | 10-plan/2026-10-09-cronograma-v2.xlsx | Cronograma v2: «Despliegue en la cadena» pasa de 2026-08-24 a 2026-09-17; los cinco hitos «cerrado». Sin motivo ni aprobación en el documento. |
| 2026-10-09 | 20-seguimiento/2026-10-09-informe-avance.md | Estado declarado **verde**, avance **34 %**; ejecutado 5.399.915.224 COP; abre un hallazgo de seguridad en los medios de pago y un riesgo (congelamiento en temporada alta). |
| 2026-10-16 | 30-reuniones/2026-10-16-comite-semanal.md | Comité con Lozano y Medina; se registra un compromiso de Natalia Ospina con fecha 2026-10-01, anterior a la reunión. |
| 2026-10-17 | 20-seguimiento/2026-10-17-solicitud-cambio-cc-01.md | Lozano solicita ampliación de alcance: +24 días sobre la línea base vigente y +48.000.000 COP. «Pendiente de presentación al comité». |

### Replanificaciones
| Nº | Fecha | Fecha de cierre nueva | Motivo declarado | Documento que la aprobó |
|---|---|---|---|---|
| 1 | 2026-10-09 (fecha del archivo v2) | 2026-09-17 | No hay motivo documentado | Ninguno. Los 24 días de atraso contra la original no tienen autorización (0 días autorizados). |

Hecho al margen: la nueva fecha de cierre (2026-09-17) ya estaba vencida cuando se escribió el cronograma que la contiene (2026-10-09).

### Gobierno
| Fecha | Qué cambió | Documento |
|---|---|---|
| — | No se ve ningún cambio de patrocinador, gerente ni comité. | Los siete documentos nombran a las mismas personas. No hay documentos de gobierno entre 2025-05-14 y 2026-10-16, así que un cambio intermedio no habría dejado rastro aquí. |

El campo «autoridad» de la ficha no se encontró en ningún documento.

### Compromisos que se repitieron
| Doliente | Qué | Veces | Fechas prometidas |
|---|---|---|---|
| Natalia Ospina | Entregar el punto 16 | 1 (no se repitió) | 2026-10-01; abierto, vencido hace 16 días a hoy |

No hay compromisos reprogramados. Con un solo comité en el expediente no hay serie contra la cual detectar repeticiones; que no se vea repetición no prueba que no la hubo.

### Desde cuándo lo declarado no se sostiene
**No se puede fechar un deslizamiento: hay una sola declaración de estado, la del 2026-10-09, y no hay serie anterior que recorrer.** Lo que sí se puede decir:

- Sobre esa declaración (verde, 34 %), el plan v2 muestra 5 de 5 hitos cumplidos, es decir, el plan sustenta 100 % y lo declarado está 66.0 puntos por debajo. Las dos cosas no pueden ser ciertas a la vez.
- Primer hito sin evidencia: «Diseño de la experiencia aprobado», con fecha 2025-08-23. Cuatro de los cinco hitos «cumplidos» no tienen evidencia de cumplimiento: ese, «Ambiente de pruebas certificado» (2025-11-22), «Integración con el ERP» (2026-02-22) y «Despliegue en la cadena» (2026-09-17). Solo el piloto la tiene, con un acta fechada 2026-10-06.
- Lo que se siguió reportando como verde el 2026-10-09: un hallazgo de seguridad abierto sin responsable, un compromiso vencido, un cierre movido sin autorización y los cuatro hitos sin evidencia.
- Dinero (copiado del cálculo): ejecutado 56.8 % del aprobado y comprometido 30.5 %; la proyección al cierre queda 0.5 % por debajo del presupuesto. El informe no explica la distancia entre 56.8 % ejecutado y 34 % de avance.

### Lecciones ancladas a un hecho
1. **Un cronograma sin aprobación no mueve la línea base.** Hecho: el cronograma v2 (2026-10-09) cambió el cierre de 2026-08-24 a 2026-09-17 sin acta ni decisión. Efecto: 24 días de atraso sin autorizar, que la solicitud CC-01 del 2026-10-17 mide ahora «sobre la línea base vigente» y pide otros 24 días sobre una base que nadie aprobó.
2. **Un hito «cumplido» sin documento no es un hito cumplido.** Hecho: la única acta de recibo (piloto) es del 2026-10-06, y el hito tenía fecha 2026-05-24. Efecto: los otros cuatro hitos no se pueden verificar, y el informe del 2026-10-09 se emitió con ellos dados por cumplidos.
3. **Un compromiso con fecha anterior a la reunión que lo registra ya nace vencido.** Hecho: acta del 2026-10-16 con fecha 2026-10-01. Efecto: nace abierto y atrasado, sin fecha nueva.

### Lo que no sé
- Qué pasó entre 2025-05-14 y 2026-10-06: no hay un solo documento. Pudo haber actas, correos o informes que no están en la carpeta.
- Por qué se movió el cierre, y quién lo autorizó, si alguien lo hizo.
- Por qué el cronograma v1 de 2025-05-14 marca como «cerrado» hitos de fechas futuras.
- Si el hallazgo de seguridad en los medios de pago tiene dueño; el informe no lo nombra.

Ninguno de estos hechos dice que alguien haya ocultado nada. Sirven para tener esa conversación con datos, y quién la tiene es una persona. Puedo llevar esta historia al cierre del proyecto o al comité del 2026-10-23, donde ya debe decidirse CC-01.

**Pie de rigor:** 7 documentos leídos (el PDF y el xlsx desde su caché de texto). Las cifras vienen del cálculo de `portafolio.py compute` al 2026-10-17; lo que no pudo calcular se declara como no calculable. Es un borrador de trabajo: la verificación contra los originales es suya.
