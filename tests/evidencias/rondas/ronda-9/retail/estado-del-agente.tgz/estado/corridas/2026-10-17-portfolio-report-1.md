# Corrida del 2026-10-17 · portfolio-report

13 proyectos · 91 documentos, 0 releídos y 91 sin cambio · 36 s · 90 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 28 |
| `commitment_overdue` | 12 |
| `declared_vs_evidence` | 9 |
| `progress_vs_plan` | 7 |
| `vendor_deliverable_late` | 7 |
| `vendor_accepted_without_evidence` | 5 |
| `variance_time` | 5 |
| `rebaseline_unauthorized` | 4 |
| `commitment_undated` | 4 |
| `commitment_rescheduled` | 3 |
| `variance_cost` | 2 |
| `milestone_overdue` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `vendor_invoiced_without_delivery` | 1 |
| `change_without_baseline` | 1 |

El informe quedó en `/home/claude/banco/ronda-9/retail/espacio/reportes/index.html`.

9 proyectos declaran verde contra evidencia; PRY-203 factura 22,4 M COP sobre lo aceptado; 4 replanificaciones sin autorizar

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

# Portafolio — 2026-10-17
13 proyectos · 11 con hallazgos · último barrido 2026-10-17 (las 13 fichas de `estado/records/`, todas de hoy, ninguna vencida)

Términos vigentes: versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17 (prueba sin interfaz). Nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.4.0

## Qué cambió desde 2026-10-17
Sin cambios desde la corrida anterior. La única instantánea previa es de hoy, así que esto es un punto de partida, no un delta.

## Contradicciones abiertas
Sin campos en `ambiguous` en la salida de `compute`; las fichas no registran `record_issues` (0). La contradicción que sí aparece es entre lo declarado y lo sustentado (ver "Estado general").

## Hitos vencidos sin evidencia
| Proyecto | Hito | Fecha | Días | Última mención |
|---|---|---|---|---|
| PRY-203 Reposición automática | 1 hito vencido (detalle en la página del proyecto) | — | — | informe de avance 2026-10-15 |

Además hay 28 hitos dados por cumplidos sin evidencia, en 10 proyectos; los más cargados son PRY-200, PRY-201, PRY-203 y PRY-211, con 4 cada uno.

## Proyectos en silencio
Vacía: ningún proyecto supera el umbral de 15 días. El más callado es PRY-205, con 10 días.

## Dependencias en riesgo
Esta corrida no calculó dependencias entre proyectos. Hay 6 proyectos sin producto asignado (PRY-202, 203, 206, 209, 210, 211), lo que limita el cruce por producto.

## Sin sustento
Nueve proyectos declaran verde y las señales lo contradicen: PRY-200, 201, 202, 203, 204, 205, 206, 210 y 211.
- **PRY-203:** el informe del 2026-10-15 dice verde, pero hay compromisos vencidos (8), tres reprogramados, un hito vencido, sobrecosto, entregables de proveedor atrasados y facturación por encima de lo aceptado en 22.377.121 COP (facturado 118.225.663 contra aceptado 95.848.542).
- **PRY-206:** hay facturación de proveedor sin entrega.

## Vacíos de información
| Proyecto | Qué falta |
|---|---|
| Los 13 | No tienen autoridad de aprobación identificada (`no_authority` = 13) |
| PRY-203, PRY-210, PRY-200 y otros | Compromisos sin fecha (PRY-203: 3; PRY-210: 1) |
| PRY-210 | Un cambio sin línea base |

## Estado general
| Proyecto | Declarado | Sustento | Desviación vs original | vs vigente | Replanificaciones |
|---|---|---|---|---|---|
| PRY-199 Iluminación LED | — | Sin señales | 0 d | 0 d | 0 |
| PRY-200 Tienda en línea | verde | Contradicho | 0 d | 0 d | 0 |
| PRY-201 Fidelización | verde | Contradicho | +24 d | 0 d | 1 (sin autorizar) |
| PRY-202 Centro de distribución norte | verde | Contradicho | +116 d | 0 d | 1 (sin autorizar) |
| PRY-203 Reposición automática | verde | Contradicho (26 señales) | 0 d | 0 d | 0 |
| PRY-204 Cajas de autopago | verde | Contradicho | 0 d | 0 d | 0 |
| PRY-205 Pago con QR | verde | Contradicho | 0 d | 0 d | 0 |
| PRY-206 Precios dinámicos | verde | Contradicho | 0 d | 0 d | 0 |
| PRY-207 Marca propia | — | Sin señales | 0 d | 0 d | 0 |
| PRY-208 Domicilios en dos horas | — | Retraso en tiempo | +78 d | 0 d | 1 |
| PRY-209 Migración del ERP | — | Retraso en tiempo | +80 d | 0 d | 1 (sin autorizar) |
| PRY-210 Etiquetas electrónicas | verde | Contradicho | +106 d | 0 d | 1 |
| PRY-211 Pronóstico de demanda | verde | Contradicho | +118 d | 0 d | 1 (sin autorizar) |

Total: 90 señales sobre 13 proyectos. Replanificaciones sin autorización: PRY-201, 202, 209 y 211. Donde la columna "Declarado" dice "—", la salida resumida que leí no trae el estado declarado.

## Necesito que confirmes
No toca este mes. La configuración pide 5 campos por corrida y la ficha más vieja es de hoy.

## Dónde quedó el informe
`/home/claude/banco/ronda-9/retail/espacio/reportes/` (24 páginas):
- `index.html`: vista por campo, con la cadena de evidencia completa. Es para quien va a actuar.
- `decisiones.html`: vista por decisión, para el patrocinador.
- Una página por proyecto, más páginas de producto.

El PDF sale de imprimir el HTML.

---
Pie: criterio-portfolio 0.4.0 · fichas de `estado/records/` del 2026-10-17 · campos inciertos: 0 en `ambiguous`; las dependencias entre proyectos y los hitos vencidos de PRY-203 no se detallaron aquí · términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.4.0
