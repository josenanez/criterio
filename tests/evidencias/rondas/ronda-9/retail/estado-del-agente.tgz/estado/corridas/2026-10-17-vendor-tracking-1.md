# Corrida del 2026-10-17 · vendor-tracking

13 proyectos · 30 s · 90 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 28 |
| `commitment_overdue` | 12 |
| `declared_vs_evidence` | 9 |
| `progress_vs_plan` | 7 |
| `vendor_deliverable_late` | 7 |
| `vendor_accepted_without_evidence` | 5 |
| `variance_time` | 5 |
| `rebaseline_unauthorized` | 4 |
| `commitment_undated` | 4 |
| `commitment_rescheduled` | 3 |
| `variance_cost` | 2 |
| `milestone_overdue` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `vendor_invoiced_without_delivery` | 1 |
| `change_without_baseline` | 1 |

Cruce de CT-497 contra FV-1497 y evidencia: 2 entregables vencidos, 1 recibido sin acta, 1 factura sin entregable identificable. Sin dato: vigencia, preaviso, a qué entregable corresponde la factura, si Beatriz Cuéllar es del proveedor.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

Sale de: contrato CT-497 (`00-gobierno/2025-08-18-contrato-ct-497.md`), factura FV-1497 (`20-seguimiento/2026-09-10-factura-ct-497.pdf`), informe de avance del 2026-10-09 y comité del 2026-10-07 de PRY-200, más la salida de `portafolio.py compute`. Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17).

## Proveedores — PRY-200 Tienda en línea al 2026-10-17

### Sistemas Comerciales del Norte — contrato CT-497
**Vigencia:** firmado el 2025-08-18; inicio y fin no declarados en el contrato · **Preaviso de no renovación:** no declarado · **Vence el:** no declarado

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento de la plataforma (445.577.090 COP) | 2025-12-27 | `unknown`; el contrato dice "pendiente"; vencido hace 294 días | Ninguna | No identificable |
| Bolsa de horas de desarrollo (445.577.090 COP) | 2026-05-02 | `unknown`; el contrato dice "recibido" | Ninguna: no hay acta de recibo | No identificable |
| Configuración del catálogo (445.577.090 COP) | 2026-09-04 | `unknown`; el contrato dice "pendiente"; vencido hace 43 días | Ninguna | No identificable |

Cifras del script: 3 entregables, 1 aceptado (declarado, sin documento que lo pruebe), 2 con fecha pasada y sin entrega, facturado 445.577.090 COP.

### Dónde no cuadra
| Qué | Dice el contrato | Dice la evidencia | Fuentes |
|---|---|---|---|
| Pago de la factura FV-1497 (445.577.090 COP, 2026-09-10) | Cada entregable se factura contra acta de recibo firmada por el gerente | No hay ninguna acta de recibo en la carpeta. La factura cita "Entregables del contrato CT-497" sin decir cuál. | CT-497 (condición de pago); FV-1497 |
| Bolsa de horas de desarrollo | Estado "recibido" | Sin acta, correo ni minuta que lo respalde | CT-497; carpeta sin acta |
| Factura y entregables | Los dos pendientes siguen vencidos | La factura de 445.577.090 COP coincide con el monto de un solo entregable. Solo la bolsa de horas figura como recibida. | FV-1497; CT-497 |

El script no levantó `vendor_invoiced_without_delivery`, porque hay un entregable aceptado en el registro. Pero esa aceptación no tiene documento, así que la factura queda sin sustento verificable.

### Sin evidencia de recibo
| Entregable | Marcado como | Desde |
|---|---|---|
| Bolsa de horas de desarrollo | Recibido (contrato) / aceptado (ficha) | Vencía el 2026-05-02; no hay fecha de aceptación |

### Compromisos del proveedor vencidos
| Qué | Prometido en | Para | Días |
|---|---|---|---|
| Entregar el punto 17 (Beatriz Cuéllar) | Comité 2026-10-07 | 2026-10-08 | 9 |

El documento no dice si Beatriz Cuéllar es del proveedor o es interna, y no asistió al comité (asistieron Sandra Gil y Carlos Peña). Lo registro como compromiso vencido del proyecto; si es del proveedor, cuenta aquí.

### Sin dato
- Vigencia, renovación automática y preaviso de CT-497: el contrato no los trae. No puedo decir si el preaviso vence antes del cierre del proyecto (2026-11-23).
- A qué entregable corresponde FV-1497.
- Si hay otras facturas: solo hay una en la carpeta.
- Fecha y firmante de cualquier acta de recibo.
- Contexto: el informe del 2026-10-09 declara verde, con 4 señales sin explicar (compromiso vencido, hitos cumplidos sin evidencia, avance contra plan, entregable de proveedor tardío).

## Después
- Hay un entregable facturado sin evidencia de recibo, y dos entregables vencidos sin entrega. Ofrezco llevarlo al comité del 2026-10-23.
- Antes de que se pague FV-1497: pedir el acta de recibo firmada por la gerente (Sandra Gil) o devolver la factura.
- Pedir el contrato completo o el anexo que fije vigencia y preaviso.

*Pie de rigor: borrador de trabajo, no decisión ni asesoría. Cada dato sale del documento citado; la verificación es de quien lo usa. Lo que no está en la carpeta se declara como sin dato.*
