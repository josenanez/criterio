## Diagnóstico · PRY-200 Tienda en línea · 2026-10-17

**Leí:** 6 documentos de la carpeta del proyecto · del 2025-08-14 al 2026-10-09 · formatos: docx, xlsx, pdf, md (3).
Además busqué el código, el nombre del proyecto, el contrato CT-497 y el proveedor en los documentos de los otros proyectos y productos. Ninguno menciona a PRY-200. Hay coincidencias de nombres de personas, que no cuentan como evidencia de este proyecto (ver «Lo que esta carpeta no permite saber»).
**No pude leer:** nada quedó ilegible. El docx, el xlsx y el pdf los leí por su texto convertido en caché, no abriendo el original. El pdf no tiene huella de texto registrada.

### Dictamen
**Sostenido:** 3 afirmaciones · **Sin sustento:** 12 · **Contradicho:** 2

Desde esta carpeta se puede afirmar el gobierno nominal (patrocinador, gerente, comité, presupuesto aprobado y fecha de cierre de 2026-11-23), que existe una factura de 445.577.090 COP radicada y que el plan no tiene replanificaciones registradas. No se puede afirmar que el proyecto esté en verde ni que su avance sea 57%. El informe de avance del 2026-10-09 es la única fuente de los tres montos de dinero que no son el aprobado, del hallazgo de seguridad y del riesgo regulatorio. Dos de sus afirmaciones centrales las contradicen otros documentos de la carpeta. El proyecto no está en silencio (8 días desde el último documento, contra un umbral de 15), pero lo que habla es la declaración y casi nada la respalda. Una nota sobre el cronograma: todos sus hitos cerrados llevan fecha de archivo 2025-08-14, y ese día no podía saberse que se cerrarían en 2026, así que el archivo se editó después sin dejar fecha ni versión nueva.

### Gobierno
| | Qué dice el documento | Fuente |
|---|---|---|
| Patrocinador | Carlos Peña | Acta de constitución, 2025-08-14 |
| Gerente | Sandra Gil | Acta de constitución, 2025-08-14; informe 2026-10-09 |
| Autoridad declarada | No está. El acta no dice qué puede aprobar el gerente en fechas, dinero o alcance. | Acta de constitución |
| Comité | Comité Comercial. La minuta del 2026-10-07 es de ese comité y asisten Sandra Gil y Carlos Peña. | Acta; minuta 2026-10-07 |

Sin autoridad declarada no hay desviación aprobada. Cualquier fecha distinta de la línea base sería una fecha que alguien escribió. El alcance del acta son «Componente 1, 2 y 3» sin detalle, y su exclusión es «lo que otro proyecto cubre». Con eso no se puede verificar qué entra y qué no. La única dependencia declarada es «Ninguna declarada».

### Contra el plan
Hay una sola línea base: v1, aprobada el 2025-08-14, con inicio 2025-08-24 y cierre 2026-11-23. En el cronograma, la fecha vigente y la de línea base coinciden en los cinco hitos. Replanificaciones: 0. Desviación contra la original: 0 días. Contra la vigente: 0 días.
El informe del 2026-10-09 dice que «se reprogramó el despliegue». Ningún documento registra ese cambio: no hay solicitud de cambio, no hay línea base nueva y el cronograma conserva 2026-11-23. Si el despliegue se movió, el movimiento está fuera de la línea base y sin autoridad que lo apruebe.

### Hitos vencidos sin evidencia
El cronograma marca cuatro hitos como cerrados. Ninguno tiene un documento de cierre en la carpeta. Los días son contados hasta hoy.

| Hito | Fecha | Días | Qué documento se esperaría |
|---|---|---|---|
| Diseño de la experiencia aprobado | 2025-11-23 | 328 | Acta de aprobación del diseño |
| Ambiente de pruebas certificado | 2026-02-22 | 237 | Certificado o acta de pruebas |
| Integración con el ERP | 2026-05-24 | 146 | Acta de recibo o prueba de integración |
| Piloto en tiendas | 2026-08-24 | 54 | Informe o acta de cierre del piloto |

«Despliegue en la cadena» (2026-11-23) está en curso y no vencido.
Avance declarado: 57%. El plan, con 4 de 5 hitos cerrados, soporta entre 80% y 100%, una distancia de 23 puntos. Que el avance reportado esté por debajo del cronograma no es una buena señal: significa que el informe y el cronograma no cuentan la misma historia.

Proveedor Sistemas Comerciales del Norte, contrato CT-497:

| Entregable | Fecha | Estado en el contrato | Días de atraso | Evidencia de recibo |
|---|---|---|---|---|
| Licenciamiento de la plataforma | 2025-12-27 | pendiente | 294 | No aplica (pendiente) |
| Bolsa de horas de desarrollo | 2026-05-02 | recibido | — | No hay acta de recibo |
| Configuración del catálogo | 2026-09-04 | pendiente | 43 | No aplica (pendiente) |

El contrato dice que cada entregable se factura contra acta de recibo firmada por el gerente. En la carpeta no hay ninguna.

### Dinero
Todo lo que no es el aprobado sale del informe de avance. No hay libro de ejecución, ni órdenes de compra, ni facturas distintas a la FV-1497.

| Aprobado | Comprometido | Ejecutado | Proyección | Disponible real |
|---|---|---|---|---|
| 6.800.000.000 | 4.942.981.659 (72,7%) | 3.696.476.343 (54,4%) | 6.859.551.454 (0,9% sobre lo aprobado) | 1.857.018.341 |

Moneda: COP. La proyección supera lo aprobado, pero por debajo del umbral de 10%. Aprobado: sostenido por el acta. Comprometido, ejecutado y proyección: sin sustento.
Factura FV-1497, 2026-09-10, 445.577.090 COP, «Entregables del contrato CT-497», radicada en cuentas por pagar. Ese valor es igual al de cada uno de los tres entregables. La factura no dice cuál cobra. El único entregable marcado como recibido es la bolsa de horas, pero sin acta. Si cobra la configuración del catálogo, que vencía el 2026-09-04 y sigue pendiente, se facturó algo no recibido. Con los documentos no se puede decidir.

### Lo que se dijo y nadie registró
No existe registro RAID ni de compromisos en la carpeta.
- **Compromiso vencido:** Beatriz Cuéllar, «Entregar el punto 17», para 2026-10-08, anotado en la minuta del 2026-10-07. Lleva 9 días vencido y sin evidencia de entrega. Ningún documento define qué es el «punto 17». Beatriz Cuéllar no figura entre los asistentes ni en el acta.
- **Riesgo (solo en el informe):** cambio en la regulación de datos personales que puede mover el alcance. Sin probabilidad, impacto, dueño ni fecha. El acta lo deja sin sustento previo: declara «Ninguna dependencia».
- **Incidencia (solo en el informe):** hallazgo de seguridad en los medios de pago, sin dueño ni fecha de cierre, levantado en el informe del 2026-10-09. No aparece en la minuta del 2026-10-07, que es anterior. Con el despliegue previsto para 2026-11-23, es lo que más puede mover el cierre.
- **Dependencia con el área de seguridad:** el informe habla de ajustar el plan de pruebas «con el área de seguridad», y el acta no lista dependencia alguna.
- La minuta del 2026-10-07 tiene como temas «Avance» y «Compromisos» y no registra lo tratado en ninguno.

### Contradicho
| Afirmación | Documento A | Documento B |
|---|---|---|
| Estado **Verde** | Informe 2026-10-09: «Verde» | Contrato CT-497: dos entregables vencidos y pendientes (294 y 43 días); cronograma con 4 hitos cerrados sin evidencia; compromiso de la minuta vencido 9 días sin entrega |
| Avance **57%** | Informe 2026-10-09: «57%» | Cronograma v1: 4 de 5 hitos cerrados, que el plan soporta entre 80% y 100% (23 puntos de distancia) |

### Sin sustento
Lo que nada contradice y nada respalda (12):
1. Se ajustó el plan de pruebas con el área de seguridad: no hay plan de pruebas en la carpeta.
2. Se reprogramó el despliegue por el congelamiento de fin de año: ninguna solicitud de cambio, ninguna línea base nueva. El cronograma conserva 2026-11-23.
3. Se levantó un hallazgo de seguridad en los medios de pago: sin informe de seguridad ni registro, y sin dueño.
4. Presupuesto comprometido de 4.942.981.659 COP.
5. Presupuesto ejecutado de 3.696.476.343 COP.
6. Proyección al cierre de 6.859.551.454 COP.
7. Riesgo del cambio en la regulación de datos personales.
8. Hito «Diseño de la experiencia aprobado» cerrado.
9. Hito «Ambiente de pruebas certificado» cerrado.
10. Hito «Integración con el ERP» cerrado.
11. Hito «Piloto en tiendas» cerrado.
12. Entregable «Bolsa de horas de desarrollo» recibido (sin acta de recibo).

Sostenidas (3): presupuesto aprobado de 6.800.000.000 COP (acta); gerente Sandra Gil (acta e informe); factura de 445.577.090 COP por el mismo valor que cada entregable del contrato.

### Lo que esta carpeta no permite saber
- **Quién puede aprobar un cambio.** No hay autoridad declarada. Consecuencia: no se puede decir si «se reprogramó el despliegue» fue una decisión o una deriva.
- **Si el avance es 57%, 80% o menos.** No hay evidencia de cierre de ningún hito. Consecuencia: ninguna cifra de avance se puede sostener ni descartar.
- **Cuál entregable cobra la factura FV-1497 y si estaba recibido.** Falta el acta de recibo firmada. Consecuencia: no se puede afirmar que se pagó lo entregado.
- **Cuánto se ha gastado y comprometido.** Falta un libro de ejecución o las órdenes de compra. Consecuencia: el «disponible real» de 1.857.018.341 COP es aritmética sobre una declaración.
- **Qué es el «punto 17» y por qué su responsable no figura en el proyecto.** Consecuencia: no se puede decir qué se dejó de entregar.
- **Si el hallazgo de seguridad bloquea el despliegue.** No hay informe, severidad ni dueño. Consecuencia: la fecha de cierre de 2026-11-23 no se puede evaluar.
- **Qué entra en el alcance.** El acta trae «Componente 1, 2 y 3». Consecuencia: ni el cambio regulatorio ni el hallazgo se pueden medir contra el alcance.
- **Si las coincidencias de nombres en otros proyectos son las mismas personas.** Sandra Gil asiste a los comités de PRY-203 con compromisos propios. Beatriz Cuéllar es gerente de PRY-208 y tiene un compromiso en una minuta de PRY-204. No lo afirmo ni lo descarto.

No recomiendo detener, continuar ni reestructurar: eso lo decide quien tiene la facultad. Puedo preparar el punto de comité con esta lista de lo que falta, o llevar las dos contradicciones al gerente como preguntas, una por una.

---
**Pie de rigor.** Leí 6 documentos (2025-08-14 a 2026-10-09). Cada cifra derivada sale de `portafolio.py compute` del 2026-10-17. Lo declarado y lo probado van separados y la verificación de las citas es suya. Este es un borrador de trabajo, no una decisión.
