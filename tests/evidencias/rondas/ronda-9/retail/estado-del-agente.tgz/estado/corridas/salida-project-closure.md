**Cierre de PRY-201 — Programa de fidelización.** Sale de la ficha `estado/records/PRY-201.json` (actualizada 2026-10-17), de la salida de `portafolio.py compute` (corte 2026-10-17) y de estos documentos: acta de constitución (2025-05-14), cronograma v1 (2025-05-14), cronograma v2 (2026-10-09, solo vía ficha), acta de recibo del piloto (2026-10-06), informe de avance (2026-10-09), solicitud de cambio CC-01 (2026-10-17) y acta del comité semanal (2026-10-16). Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17).

## Cierre — PRY-201 Programa de fidelización — 2026-10-17

**Lectura previa:** nadie ha declarado este cierre. El proyecto reporta estado **verde, 34 %** (informe del 2026-10-09), tiene una solicitud de cambio pendiente y un hallazgo de seguridad abierto. Lo que sigue es lo que se puede decir hoy si se pidiera cerrarlo; **no sustenta un cierre por cumplimiento**.

### Contra lo comprometido
**Criterio de éxito:** "Programa de fidelización en producción y medido." (acta de constitución, 2025-05-14).
**Se cumplió:** **no se puede determinar**. Ningún documento muestra el programa en producción ni una medición. El único entregable con evidencia de recibo es el piloto en tiendas.

El acta tampoco define el alcance con detalle: lista "Componente 1, 2 y 3" sin describirlos, y la exclusión es "Lo que otro proyecto cubre". Sin eso no hay contra qué contrastar lo entregado.

| Entregable comprometido (hito) | Estado declarado | Evidencia |
|---|---|---|
| Diseño de la experiencia aprobado (base 2025-08-23) | cumplido | Ninguna |
| Ambiente de pruebas certificado (base 2025-11-22) | cumplido | Ninguna |
| Integración con el ERP (base 2026-02-22) | cumplido | Ninguna |
| Piloto en tiendas (base 2026-05-24) | cumplido | Acta de recibo del 2026-10-06, firmada por Andrés Lozano (el gerente; no consta recibo de otra parte) |
| Despliegue en la cadena (base 2026-08-24, vigente 2026-09-17) | cumplido | Ninguna |

Cuatro de cinco hitos figuran cumplidos sin evidencia. El plan marca 5 de 5, pero el avance declarado es 34 %: una brecha de 66 puntos que el informe no explica.

### Fuera de alcance final
| Qué quedó fuera | Decidido por | Cuándo |
|---|---|---|
| No determinable: no hay documento que registre un recorte | — | — |

Hay una ampliación de alcance **pendiente**, no decidida (CC-01, 2026-10-17, "Pendiente de presentación al comité"). Su campo `decided_by` está vacío.

### Números finales
| | Original | Vigente | Final | Desviación vs original |
|---|---|---|---|---|
| Fecha de cierre | 2026-08-24 | 2026-09-17 | **sin dato** (no hay cierre ni despliegue con evidencia) | 24 días (5,3 %) |
| Presupuesto aprobado | 9.500.000.000 COP | 9.500.000.000 COP | — | — |

- Ejecutado: 5.399.915.224 COP (56,8 % del aprobado). Comprometido: 2.898.628.541 COP (30,5 %). Proyección al cierre: 9.448.830.972 COP (−0,5 % sobre lo aprobado). Fuente: informe de avance 2026-10-09.
- Desviación contra la línea base vigente: 0 días. La vigente (v2) ya incorpora los 24 días.
- **Replanificaciones: 1.**
- La v2 movió el cierre 24 días **sin cambio autorizado** (cambios autorizados: 0; movido: 24). No se encontró el motivo de la replanificación.
- CC-01 pide +24 días "sobre la línea base vigente" y 48.000.000 COP adicionales. Está pendiente y no se sumó a ninguna cifra. No puedo decir si esos 24 días son los mismos de la v2 o 24 adicionales, y el documento no lo aclara.
- Presupuesto final: no se puede dar. El ejecutado es el del 2026-10-09 y el proyecto sigue en curso.

### RAID al cierre
**Materializados:**
- Hallazgo de seguridad en los medios de pago: incidencia abierta desde 2026-10-09, **sin responsable** (informe de avance).

**No materializados:** ninguno se puede afirmar.

**Abiertos, con doliente:**
- Riesgo "Congelamiento de cambios en temporada alta": sin responsable, sin probabilidad ni impacto, sin fecha. **No está cerrado.**
- Incidencia de seguridad en medios de pago: **sin doliente**. **No está cerrada.**
- Compromiso "Entregar el punto 16", Natalia Ospina, para 2026-10-01 (comité del 2026-10-16): vencido hace 16 días, sin evidencia de entrega. Tiene doliente. Sigue abierto, y el acta no dice qué es el "punto 16".
- CC-01: pendiente de comité, sin decisor.

Con dos elementos sin doliente, el cierre no puede declararse según el criterio de la skill.

### Lecciones
| Qué pasó | Cuándo | Efecto | Qué haríamos distinto |
|---|---|---|---|
| El cronograma v2 trasladó el despliegue en la cadena del 2026-08-24 al 2026-09-17 sin cambio autorizado ni motivo | v2 fechada 2026-10-09 | 24 días de atraso contra la original, ya incorporados como línea base vigente | No aceptar una línea base nueva sin solicitud de cambio aprobada que diga el motivo. La v2 quedó fechada 2026-10-09 y la solicitud CC-01 solo se redactó el 2026-10-17 |
| Cuatro hitos figuran cumplidos sin acta de recibo ni otra evidencia (diseño, ambiente de pruebas, integración con ERP, despliegue) | Fechas base 2025-08-23, 2025-11-22, 2026-02-22 y 2026-09-17 | El estado verde y el 34 % no se pueden contrastar con nada; tampoco el cierre | Exigir acta de aceptación firmada por quien recibe para marcar un hito como cumplido |
| El acta de recibo del piloto lleva fecha 2026-10-06; el hito estaba para 2026-05-24 | 2026-10-06 | La evidencia de recibo llega después de la fecha de la línea base y de la del despliegue vigente | Registrar el recibo cuando ocurre, no al regularizar el informe |
| El acta de constitución no define componentes ni exclusiones, y el criterio de éxito no tiene medida | 2025-05-14 | Hoy no se puede decir si algo quedó fuera, ni qué es "medido" | No aprobar un acta con "Componente 1, 2 y 3" ni una exclusión sin nombre |

Todas salen de documentos citados. No agrego lecciones sobre comunicación o equipo porque ningún documento las sostiene.

### Sin dato
- Si el programa está en producción y medido (criterio de éxito).
- Qué cubren los componentes 1 a 3 y qué se excluyó, con qué decisión.
- Motivo y aprobación de la replanificación v2.
- Evidencia de cuatro hitos declarados cumplidos.
- Fecha real de cierre y ejecución final del presupuesto.
- Qué es el "punto 16" y si se entregó.
- Responsable del hallazgo de seguridad y del riesgo de congelamiento de cambios.
- Autoridad (`identity.authority`) y fase (`identity.phase`): no encontradas.
- El cronograma v2 (.xlsx) lo leí solo a través de la ficha, no directamente.
- El estado de los datos es antiguo: los campos de identidad, alcance y presupuesto aprobado vienen del acta de 2025-05-14 (17 meses).

### Después
Mover la carpeta a `archivo/` y congelar la ficha **no procede** mientras el proyecto siga declarado en curso con RAID abierto sin doliente. Lo que sí procede antes de cualquier cierre: (1) que el comité decida CC-01; (2) asignar doliente al hallazgo de seguridad y al riesgo; (3) obtener evidencia de los cuatro hitos; (4) que alguien declare formalmente el cierre, o lo declare "por decisión" y no por cumplimiento. No archivé nada.

---
**Pie de rigor.** Cifras derivadas copiadas de `portafolio.py compute` (corte 2026-10-17). Fuentes citadas por documento; todo lo sin documento va como "sin dato". Señal abierta en el informe declarado: verde contra cuatro señales (compromiso vencido, hitos cumplidos sin evidencia, avance contra plan, línea base movida sin autorización). La verificación es de quien lo lea.
