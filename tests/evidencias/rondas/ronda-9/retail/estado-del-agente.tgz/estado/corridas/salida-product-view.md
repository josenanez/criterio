Fuente: fichas de `estado/records/`, cálculo `portafolio.py compute` con corte 2026-10-17. Términos vigentes (v0.4.0), aceptados por José Francisco Ñáñez el 2026-10-17.

## Productos al 2026-10-17 — marca propia

**marca propia tiene un solo proyecto (PRY-207, Marca propia de alimentos).** La vista por producto no aporta una sección aparte aquí: lo que sigue es la lectura del proyecto, no un agregado.

| Producto | Proyectos | Con alertas | Fecha más tardía | Aprobado | Comprometido |
|---|---|---|---|---|---|
| marca propia | 1 (PRY-207) | 0 | 2026-04-17 | COP 9.500.000.000 | COP 4.249.815.175 |

Las cuatro cifras de dinero están en el único proyecto (4 de 4).

**Cero alertas no es salud.** El cálculo no marca nada, pero por una razón que conviene leer bien:

- **La fecha comprometida (2026-04-17) es anterior al corte (2026-10-17)** y el proyecto sigue abierto, con avance declarado de 66 %. El cálculo reporta atraso 0 contra la línea base original y la vigente porque la línea base es una sola (v1, acta de constitución del 2025-05-27) y nadie la ha movido: no hay replanificación registrada, ni solicitud de cambio. Una fecha vencida sin cambio aprobado es justo lo que ese cero esconde. El script no entrega un conteo de días de atraso, así que no lo escribo.
- **La ficha no tiene hitos** (`milestones` vacío). Sin hitos no pueden saltar las señales de hito vencido, hito cumplido sin evidencia ni avance contra plan: ausencia de señal por falta de dato, no por buen estado.
- **El estado declarado es rojo** (informe de avance del 2026-10-15, gerente Javier Hoyos), y es lo único que el proyecto dice de sí. Evidencia: 0 fuentes; declaración: 2; sin marcar: 17.
- **Dinero:** ejecutado 1.531.882.450 (16,1 %), comprometido 44,7 %, proyección al cierre 9.186.690.012 (−3,3 % frente a lo aprobado). Esa proyección no es el problema; el problema es que se proyecta cerrar dentro del presupuesto un proyecto cuya fecha ya pasó.
- **Riesgos abiertos, sin dueño, probabilidad, impacto ni fecha:** cambio en la regulación de datos personales que puede mover el alcance; el proveedor no ha confirmado la fecha de la última entrega. Ninguno está en un registro RAID con doliente.
- **Campos faltantes:** autoridad (`identity.authority`) y fase (`identity.phase`). Proveedores: ninguno registrado, aunque el riesgo habla de un proveedor con entrega pendiente.
- **Datos viejos:** 13 campos de identidad, plan y dinero vienen del acta del 2025-05-27 (17 meses, por encima del umbral de 12).

**Dependencias internas:** ninguna declarada (un solo proyecto).

**Fecha comprometida del producto:** 2026-04-17, de PRY-207; vencida frente al corte.

### Proyectos sin producto declarado

Seis de los 13 proyectos del portafolio no declaran producto, así que nadie puede responder por el conjunto al que sirven. Un séptimo (PRY-199) declara «PRD-299», un código y no un nombre de producto, y queda como producto de un solo proyecto.

| Proyecto |
|---|
| PRY-202 Centro de distribución norte |
| PRY-203 Reposición automática |
| PRY-206 Precios dinámicos |
| PRY-209 Migración del ERP |
| PRY-210 Etiquetas electrónicas de precio |
| PRY-211 Pronóstico de demanda |

El área dueña de estos seis no la extraje en esta corrida; no la invento.

## Lo que no sé

- Cuántos días lleva vencida la fecha de PRY-207: el cálculo no lo da.
- Si hubo un cambio de fecha acordado fuera de los documentos: la carpeta no lo muestra.
- Si PRY-207 comparte producto con alguno de los seis proyectos sin producto (p. ej. PRY-206 Precios dinámicos o PRY-211 Pronóstico de demanda): sin producto declarado no se puede cruzar.

## Pie de rigor

Cifras copiadas de la salida de `compute` (corte 2026-10-17); la lectura de la ficha PRY-207 cita `00-gobierno/2025-05-27-acta-constitucion.md` y `20-seguimiento/2026-10-15-informe-avance.pdf`. Todo es borrador de trabajo: la verificación contra los originales es de la persona que decide.
