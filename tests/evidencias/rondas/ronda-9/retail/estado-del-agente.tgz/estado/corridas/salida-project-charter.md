Acta previa: sí, del 2025-05-27 (aprobada). Modo revisar.
Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17); no se pidió nueva aceptación.

## Acta — PRY-207 Marca propia de alimentos
**Estado:** existe, del 2025-05-27 (`00-gobierno/2025-05-27-acta-constitucion.md`)

### Qué falta
| Campo | Estado | Consecuencia |
|---|---|---|
| Autoridad del gerente | **No está.** El acta no dice hasta qué monto ni qué cambio de alcance puede decidir Javier Hoyos sin comité. | Cualquier ajuste de alcance o presupuesto sube al comité por defecto. Con el proyecto en rojo, el riesgo de datos personales que "puede mover el alcance" no tiene a nadie con facultad declarada para decidir. |
| Objetivo de negocio | **Débil.** "Entregar marca propia de alimentos para Comercial" describe el entregable, no un resultado de negocio medible. | No hay con qué juzgar si el proyecto valió la pena, ni si un recorte de alcance sigue sirviendo al objetivo. |
| Alcance | **Sin contenido.** "Componente 1, 2 y 3" sin descripción. | No se puede decir qué es un cambio de alcance. El control de cambios y el 66 % reportado no tienen contra qué medirse. |
| Exclusiones | **Vacía en la práctica.** "Lo que otro proyecto cubre" no nombra ningún proyecto. | Riesgo de solapamiento con otro proyecto, o de que algo quede sin dueño. Nadie puede verificar la frontera. |
| Patrocinador / Gerente | Presentes con nombre: Felipe Arango y Javier Hoyos. | Sin hallazgo. |
| Supuestos | **No están.** | Nada contra qué contrastar el cambio regulatorio ni la fecha de entrega del proveedor, que hoy aparecen solo como riesgos del informe. |
| Restricciones | **No están.** | Sin topes declarados de tiempo, regulación o capacidad. |
| Dependencias | Declara "Ninguna declarada". El informe del 2026-10-15 menciona un proveedor con la última entrega sin fecha. | El acta no refleja una dependencia que el informe sí reconoce. |
| Criterio de éxito | **Parcial.** "En producción y medido" no dice qué métrica, qué umbral ni cuándo. | "Medido" no tiene cifra. No hay meta contra la cual declarar cumplido el proyecto. |
| Quién mide el éxito | **No está.** | Quien reporta el avance es quien lo declara; no hay una figura independiente. |
| Hitos principales | **No hay.** Solo inicio (2025-06-06) y cierre (2026-04-17). | Sin hitos intermedios, el atraso solo se ve al final. La ficha no tiene hitos que comparar con el 66 %. |
| Cadencia del comité | **No está.** | No hay frecuencia de reporte pactada. |
| Fase | No aparece. | Sin hallazgo mayor. |
| Comité | Comité de Arquitectura aprobó el presupuesto de 9.500.000.000 COP. | Es una instancia técnica aprobando una marca propia comercial. No lo puedo confirmar con los documentos: conviene verificar si es el comité correcto. |

### Contenido
**Objetivo de negocio:** pendiente de definir como resultado medible. El acta dice solo "Entregar marca propia de alimentos para Comercial" (acta, "Objetivo del negocio").
**Alcance:** "Componente 1, 2 y 3", sin detalle (acta, "Alcance").
**Exclusiones:** "Lo que otro proyecto cubre", sin nombrar el proyecto (acta, "Fuera de alcance").
**Patrocinador:** Felipe Arango · **Gerente:** Javier Hoyos (acta, encabezado).
**Autoridad del gerente:** pendiente de definir. No hay monto ni tipo de cambio en ningún documento.
**Comité al que reporta:** Comité de Arquitectura (acta) · **Cadencia:** pendiente de definir.
**Supuestos:** pendiente de definir · **Restricciones:** pendiente de definir.
**Criterio de éxito:** "Marca propia de alimentos en producción y medido" (acta, "Criterio de éxito"); falta métrica y umbral · **Lo mide:** pendiente de definir.
**Hitos principales:** pendiente de definir. Solo hay inicio 2025-06-06 y cierre 2026-04-17 (acta, "Fechas comprometidas").
**Presupuesto aprobado:** 9.500.000.000 COP, aprobado el 2025-05-27 (acta).

### Lo que el acta no puede explicar y el informe sí muestra
- El cierre comprometido era el 2026-04-17. El informe del 2026-10-15 reporta 66 % de avance y estado rojo, unos 6 meses después. La línea base sigue siendo la versión 1; no hay replanificación aprobada.
- El informe reporta comprometido 4.249.815.175 COP y ejecutado 1.531.882.450 COP, con proyección al cierre de 9.186.690.012 COP (informe, "Presupuesto"). No hay un monto declarado de autoridad contra el cual saber quién podría aprobar un desvío.
- Los dos riesgos del informe (regulación de datos personales y fecha de entrega del proveedor) no tienen responsable, fecha ni probabilidad. Esto pertenece al registro RAID, no al acta.

### Qué ofrezco
1. La definición de la autoridad del gerente es una decisión, no un trámite: puedo prepararla como punto para el comité (`/steering-pack`).
2. De esta revisión salen supuestos implícitos (que la regulación de datos personales no cambia el alcance; que el proveedor entrega a tiempo). Puedo pasarlos al registro RAID (`/raid-log`).

**Pie de rigor:** esto es un borrador de trabajo, no una decisión. Cada dato lleva la cita del documento del que sale; la verificación es suya. Solo vi el acta del 2025-05-27 y el informe del 2026-10-15. No sé lo que se habló fuera de esos documentos: puede existir una autoridad delegada, una replanificación o una instrucción del comité que no está escrita.
