# Corrida del 2026-10-17 · portfolio-setup

3 proyectos · 91 documentos, 71 releídos y 20 sin cambio · 103 s · 15 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 6 |
| `rebaseline_unauthorized` | 2 |
| `variance_time` | 2 |
| `vendor_deliverable_late` | 2 |
| `progress_vs_plan` | 1 |
| `commitment_overdue` | 1 |
| `declared_vs_evidence` | 1 |

0 preguntas (sesión sin interfaz, valores sugeridos); primer resultado en una sola conversación, sin cronómetro de pared; probó PRY-201, PRY-208 y PRY-209: 15 señales, PRY-201 declara verde contradicho por 4 señales

Primera corrida: no hay una anterior contra la cual comparar.

## Lo que produjo

## Listo — Retail

**Miré:** 91 documentos en 13 proyectos · formatos: md (45), docx (13), pdf (13), xlsx (13), csv (5), json (1), txt (1) · más reciente: 2026-10-17
**Eres:** PMO del portafolio (13 proyectos)
**Te aviso:** dos días antes del comité semanal; el próximo lo supuse para el 2026-10-23 (tus comités caen en jueves o viernes) y si no es así me lo dices
**En:** presentación (queda como página HTML, que es el formato que el agente entrega)
**Términos:** aceptados por José Francisco Ñáñez para la versión 0.4.0 (términos 1.1), fecha 2026-10-17 · comprobante en `.criterio/terminos/aceptacion-criterio-portfolio-0.4.0-2026-10-17.md` y `.pdf` · SHA-256 del comprobante: 96015115a67f6c94…

Decisiones tomadas con el valor sugerido, sin preguntar: la configuración queda en `.criterio/portafolio/config.json`; lo que voy encontrando en `estado/` y los informes en `reportes/`, junto a tus documentos; lectura de un proyecto a la vez, en lotes de diez, hasta 400 documentos por corrida.

### Probé con tres proyectos

Los tres de documentación más reciente. PRY-203 también tiene un documento del 2026-10-17, pero queda para el barrido completo.

| Proyecto | Documentos | Qué supe | Qué no está |
|---|---|---|---|
| PRY-201 Programa de fidelización | 7 | Patrocinador Jorge Medina, gerente Andrés Lozano (acta 2025-05-14). Declara **verde** y 34 % de avance (informe 2026-10-09). Presupuesto aprobado 9.500 M COP; ejecutado 5.399,9 M (informe 2026-10-09). Cierre original 2026-08-24, vigente 2026-09-17 (cronograma v2). CC-01 pendiente de comité (2026-10-17). | Facultad del gerente, fase, acta de recibo de 4 de los 5 hitos, quién decidirá CC-01. |
| PRY-208 Domicilios en dos horas | 7 | Patrocinador Camilo Beltrán, gerente Beatriz Cuéllar. Declara **rojo** y 54 % (informe 2026-10-17). Cierre original 2027-01-23, vigente 2027-04-11 por CC-01, autorizada por el comité el 2026-10-11. Contrato CT-741 con Datos y Demanda, 3 entregables de 859,5 M COP cada uno. | Facultad del gerente, fase, acta de recibo de 2 de los 3 hitos cerrados (hay una de Integración con el ERP, 2026-10-06), recibo de cualquier entregable del proveedor, facturación. |
| PRY-209 Migración del ERP | 6 | Patrocinador Natalia Ospina, gerente Javier Hoyos. Declara **amarillo** y 41 % (informe 2026-10-05). Presupuesto aprobado 1.200 M COP. Cierre original 2027-07-28, vigente 2027-10-16 (cronograma v2). Diseño de la experiencia con acta de recibo (2026-10-09). CC-01 pendiente de comité. | Producto asociado (el acta dice «No aplica»), facultad del gerente, fase. |

### Lo que levantó el cálculo

**PRY-201 · 8 señales. Declara verde y los documentos no lo sostienen.**
- `declared_vs_evidence`: el verde del 2026-10-09 convive con cuatro señales sin explicar.
- `progress_vs_plan`: declara 34 % y el cronograma marca los cinco hitos como cerrados (el plan sostiene 100 %). Son dos documentos que se desmienten.
- `milestone_met_without_evidence` ×4: Diseño de la experiencia (vencido hace 420 días), Ambiente de pruebas (329), Integración con el ERP (237) y Despliegue en la cadena (30) están cerrados en el cronograma sin acta de recibo. Solo Piloto en tiendas tiene acta (2026-10-06).
- `rebaseline_unauthorized`: el cronograma v2 (2026-10-09) ya corrió el cierre 24 días, y CC-01, que pide esos mismos 24 días, sigue pendiente de comité.
- `commitment_overdue`: Natalia Ospina debía «Entregar el punto 16» el 2026-10-01 (16 días); el comité del 2026-10-16 lo registra con esa fecha.

**PRY-208 · 5 señales.**
- `variance_time`: 78 días (23,2 %) contra el cierre original. Es una desviación autorizada, porque CC-01 está aprobada y quedó como línea base v2.
- `milestone_met_without_evidence` ×2: Diseño de la experiencia (171 días) y Ambiente de pruebas (104) cerrados sin acta.
- `vendor_deliverable_late` ×2: Licenciamiento de la plataforma (146 días) y Bolsa de horas (53 días) siguen sin recibo. El contrato los marcaba «en curso» y «pendiente»; los leí como pendientes.

**PRY-209 · 2 señales.**
- `variance_time`: 80 días (17,4 %) contra el original.
- `rebaseline_unauthorized`: el cronograma v2 ya mueve el cierre 80 días, y CC-01 sigue pendiente.

Los tres: ninguna ficha tiene la facultad del gerente. En PRY-201 hay además 12 campos tomados del acta de hace 17 meses, sin confirmación posterior.

### El portafolio completo
10 proyectos más y 71 documentos, en un solo lote, de uno en uno. Calculo entre 3 y 4 veces lo que tomó esta prueba. Como los documentos son pocos y están ordenados por carpeta, cabe en una sola corrida.

### Lo que le falta a tu carpeta
- Casi ningún hito cerrado tiene acta de recibo. De los 9 hitos cerrados que vi en los tres proyectos, solo 3 tienen una, y eso es lo que genera más señales.
- Las solicitudes de cambio no dicen quién las decidió ni cuándo (PRY-201 y PRY-209 siguen «pendientes de presentación al comité»).
- Ninguna acta de constitución fija qué puede decidir el gerente sin subir a comité.
- En `PRY-203-reposición-automática` hay un `ficha-pm.json` y unas notas de reunión del 2026-10-17 sueltas fuera de `30-reuniones`; las leeré en el barrido.
- Dentro de `estado/` ya había una carpeta `PRY-203-reposición-automática/` con su propio estado (`records/`, `corridas/`, `snapshots/`). No es mía y no la toqué; conviene mover ese contenido o borrarlo si es un resto de otra prueba.
