Fuentes: ficha `estado/records/PRY-203.json` (acta de constitución del 2025-07-06 e informe de avance del 2026-10-15) y salida de `portafolio.py compute` con fecha de corte 2026-10-17. Términos vigentes (v1.1), aceptados por José Francisco Ñáñez el 2026-10-17.

## Presupuesto — PRY-203 Reposición automática al 2026-10-17
**Moneda:** COP (única; no hay contratos en otra moneda ni conversión)

| | Monto (COP) | % del aprobado | Fuente | Fecha |
|---|---|---|---|---|
| Aprobado | 1.200.000.000 | 100 | 00-gobierno/2025-07-06-acta-constitucion.docx | 2025-07-06 |
| Comprometido | 742.486.754 | 61.9 | 20-seguimiento/2026-10-15-informe-avance.pdf | 2026-10-15 |
| Ejecutado | 251.538.678 | 21.0 | 20-seguimiento/2026-10-15-informe-avance.pdf | 2026-10-15 |
| Proyección al cierre | 1.432.210.423 | 19.4 por encima del aprobado | 20-seguimiento/2026-10-15-informe-avance.pdf | 2026-10-15 |

**Disponible real** (aprobado menos comprometido): 457.513.246 COP

### Contra la línea base
| | Original | Vigente | Desviación |
|---|---|---|---|
| Presupuesto aprobado | 1.200.000.000 | 1.200.000.000 | sin movimiento declarado |

Replanificaciones de presupuesto: 0. Solicitudes de cambio registradas: 0. La proyección (1.432.210.423) supera el aprobado en 19.4%, por encima del umbral de desviación de costo (10%). No existe ninguna solicitud de cambio que respalde ese exceso.

### Ejecución frente a avance
Ejecutado 21.0% · Hitos cumplidos 4 de 5 · El avance declarado es 92.0% y el ejecutado es 21.0%: o el avance está inflado, o hay trabajo hecho y no causado que aparecerá de golpe. Ninguno de los 4 hitos "cumplidos" tiene evidencia de cumplimiento en los documentos (0 evidencias), así que el 92% es una declaración, no un dato. El hito "Despliegue en la cadena" venció el 2026-10-09 (8 días).

### Alertas
- **Proyección por encima del aprobado:** 19.4% (umbral 10%). El informe del 2026-10-15 declara estado **verde** y no da cuenta de esta señal.
- **Ejecución desalineada del avance:** 21.0% ejecutado contra 92.0% declarado.
- **Facturación por encima de lo aceptado** (Sistemas Comerciales del Norte, CT-338): facturado 118.225.663 COP contra 95.848.542 COP aceptado; diferencia 22.377.121 COP. Los 4 montos están declarados (4 de 4).
- **Entregables del proveedor vencidos y pendientes:** Licenciamiento de la plataforma (359 días), Bolsa de horas de desarrollo (260 días), Configuración del catálogo (161 días). "Soporte del primer trimestre" figura aceptado sin evidencia.
- **Comprometido:** 61.9%, por debajo del umbral de 90%; no hay alerta de tope. La holgura disponible es real, pero la proyección dice que no alcanzará.
- **Pendiente de presupuesto:** hay un compromiso sin fecha de Laura Vélez, "Mandar el ajuste del presupuesto" (notas del 2026-10-17). Indica que un ajuste está en camino sin documento que lo respalde.

### Sin dato
- La proyección es una declaración del informe del 2026-10-15, no un dato duro. Es posterior a cualquier movimiento de presupuesto (no hay ninguno registrado), así que no está desactualizada frente a ellos.
- El aprobado sale de un acta de hace 15 meses (2025-07-06), por encima del umbral de antigüedad de 12 meses; no hay un documento posterior que lo confirme o lo reemplace.
- Los montos comprometido, ejecutado y proyección tienen una sola fuente (el informe de avance, un PDF): no hay un documento contable que los contraste. Ninguna de las 161 afirmaciones de la ficha marcadas como "sin marca" ni las 2 declaraciones cuenta como evidencia (evidencia: 0).
- No hay desglose de la proyección ni detalle por proveedor del comprometido.

### Después
La proyección excede el aprobado: puedo preparar la solicitud de cambio (`/change-control`). No ofrezco detalle por proveedor por tope porque el comprometido no está cerca del umbral; sí puede revisarse `/vendor-tracking` por la facturación sobre lo aceptado.

*Pie de rigor: borrador de trabajo, no decisión ni asesoría. Cada cifra sale de la ficha y de `compute`; la verificación contra los documentos citados es de quien lo lee. Lo que no está en los documentos (acuerdos verbales, ajustes en trámite) no se pudo ver.*
