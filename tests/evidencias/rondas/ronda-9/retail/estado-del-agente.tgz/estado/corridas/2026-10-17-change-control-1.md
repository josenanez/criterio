# Corrida del 2026-10-17 · change-control

13 proyectos · 35 s · 90 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 28 |
| `commitment_overdue` | 12 |
| `declared_vs_evidence` | 9 |
| `progress_vs_plan` | 7 |
| `vendor_deliverable_late` | 7 |
| `vendor_accepted_without_evidence` | 5 |
| `variance_time` | 5 |
| `rebaseline_unauthorized` | 4 |
| `commitment_undated` | 4 |
| `commitment_rescheduled` | 3 |
| `variance_cost` | 2 |
| `milestone_overdue` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `vendor_invoiced_without_delivery` | 1 |
| `change_without_baseline` | 1 |

Solicitud de +30 días a la salida a producción de PRY-200. Impacto calculado: sin proyectos alcanzados, porque no hay dependencias declaradas. No se sabe quién pide ni por qué; el acta no fija autoridad de cambios; el informe dice despliegue reprogramado sin línea base v2; el costo del mes adicional no es calculable. Se propone Comité Comercial.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

Ficha de la que sale: `estado/records/PRY-200.json` (actualizada 2026-10-17). Términos vigentes: aceptados por José Francisco Ñáñez, 2026-10-17, versión 0.4.0.

## Solicitud de cambio — PRY-200 Tienda en línea — 2026-10-17

**Qué se pide:** mover la salida a producción 30 días. Lo leo como el hito «Despliegue en la cadena» (2026-11-23), que en la línea base v1 coincide con el cierre del proyecto. Es una interpretación mía: la solicitud no nombra el hito.
**Quién lo pide:** no consta en ningún documento de la carpeta.
**Por qué:** no consta una justificación de esta solicitud. El informe de avance del 2026-10-09 dice solo que «se reprogramó el despliegue por el congelamiento de temporada de fin de año» y que hay un «hallazgo de seguridad en los medios de pago», sin fecha nueva ni documento de aprobación.

### Punto de partida: la línea base
Hay una sola línea base, v1, aprobada el 2025-08-14 con el acta de constitución (cierre 2026-11-23, presupuesto 6.800.000.000 COP). No hay v2, ni solicitud de cambio previa, ni cronograma posterior (`changes` vacío en la ficha).
El informe del 2026-10-09 ya dice que el despliegue **se reprogramó**, pero el plan sigue mostrando 2026-11-23. Es decir, puede haber un movimiento ya hecho que ningún documento autoriza ni fecha. Este cambio se evaluaría sobre un plan cuya fecha vigente no está clara.

### Impacto
| Dimensión | Hoy | Con el cambio | Diferencia |
| Alcance | Componentes 1, 2 y 3 «sin detalle» (acta) | No declarado | Sin impacto declarado. Alguien lo absorbe: ver abajo |
| Tiempo | Cierre y despliegue 2026-11-23 | 2026-12-23 | +30 días (6,6 % de los 456 días del plan, bajo el umbral de 10 %) |
| Costo | Aprobado 6.800.000.000 · proyección 6.859.551.454 COP | No calculable | Sin dato: la ficha no trae costo de mantener el equipo 30 días más |

**Quién absorbe lo que no está declarado.** La solicitud no dice nada del alcance ni del costo. Con +30 días el equipo y el proveedor trabajan un mes más sin presupuesto asignado, o se recorta alcance en silencio.
El proyecto ya proyecta cerrar 59.551.454 COP (0,9 %) por encima de lo aprobado, antes de este cambio. Cualquier costo del mes adicional se suma a un sobrecosto que ya existe.
El comprometido es 4.942.981.659 (72,7 % del aprobado) y el ejecutado 3.696.476.343 (54,4 %), frente a un avance declarado de 57 %.

### Efecto en el portafolio
| Proyecto afectado | Cómo | Gerente |
| Ninguno | El cálculo (`impact`, 30 días) no alcanza ningún proyecto, directo ni indirecto. Ningún proyecto declara depender de PRY-200 y PRY-200 declara «Ninguna» | — |

Esto dice solo que **no hay dependencias declaradas**, no que no existan. Tampoco hay dependencias sin confirmar ni proyectos que no puedan sostener su fecha: no hay ninguna declarada.
El único hito que atraviesa el cambio es «Despliegue en la cadena» (2026-11-23, a 37 días).
**Lo que no sé:** cuántos días se mueve cada actividad intermedia. La ficha no tiene holgura por actividad, y no pongo un número que parezca cálculo.
Sí es un riesgo que el despliegue pasaría del 2026-11-23 al 2026-12-23. El informe lo atribuye al congelamiento de fin de año, y no tengo las fechas del congelamiento, así que no sé si la nueva fecha cae dentro de él.

### Quién decide
**Autoridad requerida:** no declarada. El acta de constitución no fija quién aprueba cambios de fecha, y la ficha marca `identity.authority` como no encontrado. Este es el hallazgo de fondo.
**Según:** acta de constitución 2025-08-14, sin cláusula de autoridad de cambios. Lo único que consta: el Comité Comercial aprobó el presupuesto; el patrocinador es Carlos Peña; la gerente es Sandra Gil.
**Va a comité:** sí, por defecto. Sin autoridad declarada, la gerente no puede aprobarlo sola. Propongo el Comité Comercial, que aprobó la línea base, con Carlos Peña como patrocinador. Es una propuesta mía, no una atribución del acta.

### Si no se aprueba
El proyecto sigue con cierre 2026-11-23, a 37 días, con un hallazgo de seguridad en medios de pago abierto sin responsable (`owner` nulo) desde el 2026-10-09 y un despliegue que el propio informe dice reprogramado. Ese informe declara verde, y eso no cuadra con una fecha ya movida y un hallazgo de seguridad abierto.
Hay además dos entregables del proveedor (CT-497) vencidos y sin acta de recibo: Licenciamiento de la plataforma (2025-12-27) y Configuración del catálogo (2026-09-04), de 445.577.090 COP cada uno. Los hitos «cumplidos» tampoco tienen evidencia.

### Si se aprueba
Línea base 2 — cierre 2026-12-23 · presupuesto: **sin monto, por definir** (hoy 6.800.000.000 COP aprobado; proyección 6.859.551.454) · motivo: por registrar. Los documentos solo mencionan el congelamiento de temporada y el hallazgo de seguridad, sin una justificación firmada para esta solicitud.
La v1 no se toca. El conteo de replanificaciones pasa de 0 a 1.
**Desviación acumulada contra la línea base original:** tiempo +30 días (2026-11-23 → 2026-12-23) · costo +59.551.454 COP (+0,9 %) de sobrecosto proyectado, más el costo del mes adicional que no está calculado.
Si el despliegue ya se había movido de hecho antes de esta solicitud, el atraso real contra la original es mayor y hoy no está documentado.

### Lo que falta antes de decidir
1. Quién lo pide y el motivo, por escrito.
2. La fecha real vigente del despliegue (el informe dice «reprogramado», el plan dice 2026-11-23).
3. Las fechas del congelamiento de fin de año, para saber si el 2026-12-23 cae dentro.
4. El costo del mes adicional y quién lo financia.
5. Quién aprueba cambios en este proyecto, porque el acta no lo dice.
6. Un responsable para el hallazgo de seguridad.

### Pie de rigor
- Calculado por script: efecto en el portafolio (`impact`).
- Leído de los documentos citados: fechas, montos, estados y entregables.
- No sabido: solicitante, motivo, autoridad, holgura por actividad, costo del cambio, fechas del congelamiento.
- Para esta corrida se tomó la respuesta sugerida en cada pregunta, sin consultar a nadie.
