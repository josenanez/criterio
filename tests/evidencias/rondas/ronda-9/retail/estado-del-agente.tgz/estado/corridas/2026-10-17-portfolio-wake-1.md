# Corrida del 2026-10-17 · portfolio-wake

13 proyectos · 33 s · 90 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 28 |
| `commitment_overdue` | 12 |
| `declared_vs_evidence` | 9 |
| `progress_vs_plan` | 7 |
| `vendor_deliverable_late` | 7 |
| `vendor_accepted_without_evidence` | 5 |
| `variance_time` | 5 |
| `rebaseline_unauthorized` | 4 |
| `commitment_undated` | 4 |
| `commitment_rescheduled` | 3 |
| `variance_cost` | 2 |
| `milestone_overdue` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `vendor_invoiced_without_delivery` | 1 |
| `change_without_baseline` | 1 |

Barrido: 91 documentos sin cambios, nada recalculado. 16 citas de PRY-203 sin resolver aunque los archivos existen (rutas, no borrado). Confirmación: 5 preguntas sobre PRY-203 sin respuesta (sesión sin interfaz). No consulté peticiones: no tocaban. No sé por qué el índice no resuelve esas rutas.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## 2026-10-17

**Revisé:** 91 documentos · 0 cambiaron · 0 proyectos recalculados

Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17); no hizo falta registrarlos de nuevo.

### Lo que cruzó un umbral
Nada nuevo por documentos: no hubo archivos nuevos, cambiados, renombrados ni borrados, así que no corrí `/portfolio-scan`.

Un hallazgo del índice que no es de cambio sino de citas: **16 citas de PRY-203 no resuelven** (identidad, fechas de plan, monto aprobado, comprometido, ejecutado, proyección y facturado del proveedor). Los archivos citados (acta de constitución, cronograma v1, informe de avance del 2026-10-15, factura CT-338) **sí existen en la carpeta** de PRY-203; el índice no los encuentra con la ruta que usa la ficha. No es un borrado. No corregí la ficha ni la ruta: queda para que alguien revise cómo se escribieron las rutas.

Además, sin recalcular nada: la ficha de PRY-203 declara estado **verde** y **92 %** de avance al 2026-10-15 (informe de avance), pero su fecha fin de línea base es **2026-10-09**, ya vencida hace 8 días. Es lo declarado contra el plan, no un dictamen; `/health-check` sobre PRY-203 es el siguiente paso.

### Peticiones atendidas
No se consultaron peticiones del servidor (hoy no tocaban por `due`).

### Preguntas
Nadie responde en esta corrida; se dejan formuladas una sola vez, sobre PRY-203, elegidas por importancia:
1. `plan.end_date` — 2026-10-09 (cronograma v1, 2025-07-06): ¿sigue vigente o hay una fecha replanificada sin documento?
2. `declared.status` — verde (informe de avance, 2026-10-15): ¿se mantiene con la fecha fin ya vencida?
3. `declared.progress_pct` — 92 % (informe de avance, 2026-10-15): ¿qué documento lo sustenta?
4. `money.projection` — según el informe de avance, 2026-10-15: ¿cuál es la proyección actual al cierre?
5. `identity.phase` — no encontrada: ¿en qué fase está el proyecto hoy?

**Vuelvo el 2026-10-18.** El informe de comité aterriza el 2026-10-21 (comité del 2026-10-23).
