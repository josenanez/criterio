# Corrida del 2026-10-17 · status-report

13 proyectos · 34 s · 90 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 28 |
| `commitment_overdue` | 12 |
| `declared_vs_evidence` | 9 |
| `progress_vs_plan` | 7 |
| `vendor_deliverable_late` | 7 |
| `vendor_accepted_without_evidence` | 5 |
| `variance_time` | 5 |
| `rebaseline_unauthorized` | 4 |
| `commitment_undated` | 4 |
| `commitment_rescheduled` | 3 |
| `variance_cost` | 2 |
| `milestone_overdue` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `vendor_invoiced_without_delivery` | 1 |
| `change_without_baseline` | 1 |

Informe de estado de PRY-203: verde declarado al 2026-10-15 contradicho por 7 señales; no se pudo calcular días sin movimiento de los riesgos ni hay evidencia de hitos ni entregables del proveedor

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

Informe sale de la ficha PRY-203 (actualizada el 2026-10-17), recalculada con `portafolio.py compute` al 2026-10-17. Términos vigentes: aceptados por José Francisco Ñáñez el 2026-10-17 (versión 0.4.0), sin nuevo registro.

## PRY-203 · Reposición automática — estado al 2026-10-17

**Declara el gerente (Laura Vélez):** verde · 92% · al 2026-10-15 (hace 2 días, vigente) — fuente: `20-seguimiento/2026-10-15-informe-avance.pdf`
**Sustento documental:** **contradicho** — el script marca `declared_vs_evidence`: el verde no explica 7 señales abiertas. Ninguna fuente de la ficha está marcada como evidencia (0 de evidencia, 2 de declaración, 161 sin marcar).
**Lo que el semáforo no explica:** compromisos vencidos, compromisos reprogramados, hitos «cumplidos» sin evidencia, hito vencido, desviación de costo, entregables de proveedor atrasados, proveedor facturado por encima de lo aceptado.
**Último documento:** 2026-10-17 (notas de reunión) · **Última reunión de comité:** 2026-10-10 (días en silencio: 0)

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2026-10-09 | 2026-10-09 | 0 días contra original y contra vigente en el papel; pero la fecha ya pasó y el hito de cierre sigue pendiente (ver Hitos) |
| Presupuesto (COP) | 1.200.000.000 | 1.200.000.000 | Proyección 1.432.210.423 → **+19,4 %** (umbral 10 %) |

Replanificaciones: 0 — no hay línea base posterior a la v1 (acta de constitución, 2025-07-06) ni solicitudes de cambio. El plan no se ha movido, aunque la fecha de cierre ya venció.

Dinero: comprometido 742.486.754 (61,9 %), ejecutado 251.538.678 (21,0 %), disponible real 457.513.246.

### Hitos
| Hito | Base | Vigente | Estado | Evidencia |
|---|---|---|---|---|
| Diseño de la experiencia aprobado | 2025-10-14 | 2025-10-14 | cumplido (declarado) | **sin evidencia** (368 días) |
| Ambiente de pruebas certificado | 2026-01-12 | 2026-01-12 | cumplido (declarado) | **sin evidencia** (278 días) |
| Integración con el ERP | 2026-04-12 | 2026-04-12 | cumplido (declarado) | **sin evidencia** (188 días) |
| Piloto en tiendas | 2026-07-11 | 2026-07-11 | cumplido (declarado) | **sin evidencia** (98 días) |
| Despliegue en la cadena | 2026-10-09 | 2026-10-09 | pendiente | **vencido hace 8 días** |

El 92 % declarado cabe en el rango que sostiene el plan (80–100 %, 4 de 5 hitos), pero ese rango depende de cuatro hitos que nadie sustenta.

### Dónde no coincide
- **Verde vs. hito de cierre:** el informe del 2026-10-15 reporta verde; el cronograma v1 pone el despliegue el 2026-10-09 y sigue pendiente (8 días).
- **Verde vs. costo:** el mismo informe da una proyección de 1.432.210.423 sobre 1.200.000.000 aprobados (+19,4 %).
- **Proveedor Sistemas Comerciales del Norte (CT-338):** facturado 118.225.663 frente a 95.848.542 aceptado: **22.377.121 por encima de lo aceptado** (4 de 4 montos declarados). Tres entregables pendientes y vencidos: Licenciamiento de la plataforma (2025-10-23, 359 días), Bolsa de horas de desarrollo (2026-01-30, 260 días), Configuración del catálogo (2026-05-09, 161 días). «Soporte del primer trimestre» figura aceptado sin evidencia de recibo.
- **Incidencia declarada en el mismo informe:** el equipo perdió dos semanas por rotación de un desarrollador clave (desde 2026-10-15), sin responsable y sin replanificación registrada.

### Abierto
**Riesgos e incidencias sin movimiento:**
- Riesgo «Concentración del conocimiento en una sola persona» (informe 2026-10-15): sin responsable, probabilidad, impacto ni fecha de último movimiento — los días sin movimiento no se pueden calcular.
- Riesgo «El proveedor podría no llegar con el equipo completo para la siguiente fase» (dicho en reunión, notas del 2026-10-17; nadie lo registró): mismos campos vacíos.
- Incidencia de rotación del desarrollador: abierta desde 2026-10-15 (2 días), sin responsable.

**Compromisos vencidos (8):**
| Quién | Qué | Vencía | Días |
|---|---|---|---|
| Carlos Peña | Validar el ambiente 4 | 2026-09-25 | 22 |
| Liliana Torres | Confirmar la fecha 15 | 2026-09-29 | 18 |
| Laura Vélez | Cerrar la prueba 10 | 2026-10-03 | 14 |
| Ricardo Salas | Enviar el documento 17 | 2026-10-06 | 11 |
| Natalia Ospina | Revisar el anexo 3 | 2026-10-10 | 7 |
| María Restrepo | Aprobar el diseño 13 | 2026-10-11 | 6 |
| Camilo Beltrán | Actualizar la matriz 14 | 2026-10-11 | 6 |
| Elena Duarte | Entregar el punto 16 | 2026-10-15 | 2 |

**Reprogramados repetidamente:** Natalia Ospina, «Enviar el documento 1» (6 veces; original 2026-09-28, hoy 2026-12-18) · Laura Vélez, «Cerrar la prueba 2» (5 veces; original 2026-09-18, hoy 2026-11-24) · Jorge Medina, «Revisar el anexo 11» (3 veces; original 2026-10-01, hoy 2026-11-20).
**Sin fecha:** Jorge Medina «Confirmar la fecha 7»; Gustavo Neira «Validar el ambiente 12»; Laura Vélez «Mandar el ajuste del presupuesto» (notas del 2026-10-17).
**Dependencias sin confirmar:** ninguna registrada en la ficha.

### Sin dato
- Evidencia de cumplimiento de los 5 hitos y de los 4 entregables del proveedor.
- Producto, autoridad y fase del proyecto (`identity.product`, `identity.authority`, `identity.phase`).
- Probabilidad, impacto, responsable y último movimiento de los riesgos.
- Datos de identidad, plan y presupuesto aprobado tienen 15 meses (fuente: acta y cronograma del 2025-07-06; umbral 12 meses): hay que confirmarlos con quien los gobierna.

### Siguiente paso
Hay desviación de costo por encima del umbral (19,4 % > 10 %) y un cierre vencido sin replanificar: puedo preparar el punto de comité (próximo: 2026-10-23) y, si el atraso viene de un cambio no formalizado, la solicitud de cambio.

---
Criterio Portfolio 0.4.0 · ficha aplicada: PRY-203, actualizada el 2026-10-17 · campos inciertos: los listados en «Sin dato» · Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.4.0
