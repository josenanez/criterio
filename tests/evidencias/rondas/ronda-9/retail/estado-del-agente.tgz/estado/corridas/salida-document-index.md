## Carpeta al 2026-10-17

**Documentos:** 91 · **Sin cambio:** 91 · **Hay que releer:** 0

### Cambió el contenido
Ninguno.

### Solo se reguardó
Ninguno.

### Renombrado o movido
Ninguno.

### Ya no está
Ninguno.

### Citas que dejaron de resolver
| Proyecto | Campo | Documento citado |
|---|---|---|
| PRY-203 | pm_record.identity.code | 00-gobierno/2025-07-06-acta-constitucion.docx |
| PRY-203 | pm_record.identity.name | 00-gobierno/2025-07-06-acta-constitucion.docx |
| PRY-203 | pm_record.identity.business_area | 00-gobierno/2025-07-06-acta-constitucion.docx |
| PRY-203 | pm_record.identity.product | 00-gobierno/2025-07-06-acta-constitucion.docx |
| PRY-203 | pm_record.identity.sponsor | 00-gobierno/2025-07-06-acta-constitucion.docx |
| PRY-203 | pm_record.identity.manager | 00-gobierno/2025-07-06-acta-constitucion.docx |
| PRY-203 | pm_record.identity.committee | 00-gobierno/2025-07-06-acta-constitucion.docx |
| PRY-203 | pm_record.plan.start_date | 00-gobierno/2025-07-06-acta-constitucion.docx |
| PRY-203 | pm_record.plan.end_date | 10-plan/2025-07-06-cronograma-v1.xlsx |
| PRY-203 | pm_record.plan.scope_summary | 00-gobierno/2025-07-06-acta-constitucion.docx |
| PRY-203 | pm_record.plan.exclusions | 00-gobierno/2025-07-06-acta-constitucion.docx |
| PRY-203 | pm_record.money.approved | 00-gobierno/2025-07-06-acta-constitucion.docx |
| PRY-203 | pm_record.money.committed | 20-seguimiento/2026-10-15-informe-avance.pdf |
| PRY-203 | pm_record.money.executed | 20-seguimiento/2026-10-15-informe-avance.pdf |
| PRY-203 | pm_record.money.projection | 20-seguimiento/2026-10-15-informe-avance.pdf |
| PRY-203 | pm_record.vendors[0].invoiced | 20-seguimiento/2026-09-09-factura-ct-338.pdf |

Los 16 archivos citados sí existen dentro de `PRY-203-reposición-automática/`; las citas están escritas relativas a esa carpeta (sin el prefijo del proyecto), y el índice no las resuelve contra la carpeta de documentos. Es un problema de la ruta citada, no de documentos borrados. No lo sé con certeza: no abrí la ficha para confirmarlo.

### Formatos que no se pudieron leer
Ninguno: este comando cuenta y compara, no lee contenido.

### Siguiente paso
No hay nada que releer ni proyectos tocados (`projects_to_recompute` vacío), así que no hace falta `/portfolio-scan`. Queda por decidir si se corrigen las 16 citas de PRY-203 (prefijo de proyecto); no se tocó ninguna ficha.
