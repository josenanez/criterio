# Corrida del 2026-10-17 · portfolio-scan

13 proyectos · 91 documentos, 0 releídos y 91 sin cambio · 260 s · 90 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 28 |
| `commitment_overdue` | 12 |
| `declared_vs_evidence` | 9 |
| `progress_vs_plan` | 7 |
| `vendor_deliverable_late` | 7 |
| `vendor_accepted_without_evidence` | 5 |
| `variance_time` | 5 |
| `rebaseline_unauthorized` | 4 |
| `commitment_undated` | 4 |
| `commitment_rescheduled` | 3 |
| `variance_cost` | 2 |
| `milestone_overdue` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `vendor_invoiced_without_delivery` | 1 |
| `change_without_baseline` | 1 |

10 fichas nuevas (PRY-199,200,202,203,204,205,206,207,210,211); PRY-201/208/209 sin tocar por no haber cambiado; nada movido (no hay entrada/); notas-reunion.txt de PRY-203 está en la raíz del proyecto, leído en su sitio. Mirar: 22 hitos cerrados sin acta, facturas sin entregable recibido en PRY-206/203/210, cronogramas v2 que mueven fechas antes de aprobar el CC (PRY-202, 210, 211), PRY-211 con patrocinador=gerente y 27% con todos los hitos cerrados, PRY-207 rojo sin cronograma.

Contra la corrida del 2026-10-17: +75 hallazgos.

## Lo que produjo

## Barrido — 2026-10-17

Encontré `.criterio/portafolio/config.json` (rol PMO, organización Retail) y los términos vigentes: v1.1, aceptados por José Francisco Ñáñez el 2026-10-17 para esta prueba, comprobante en `.criterio/terminos/`. En la prueba sin interfaz tomé las respuestas sugeridas en cada pregunta, y no hubo que decidir nada que no estuviera en la configuración.

**Documentos:** 91 en la carpeta · 71 leídos · 20 sin cambio desde la corrida anterior · 0 ilegibles
**Proyectos:** 13 distinguidos (13 carpetas) · 10 con ficha nueva en esta corrida · 3 sin tocar (PRY-201, PRY-208, PRY-209: sus documentos no cambiaron) · 0 sin carpeta propia

Formatos: 45 .md, 13 .docx, 13 .pdf, 13 .xlsx, 5 .csv, 1 .txt, 1 .json. El plan fue un solo lote de 10 proyectos, uno tras otro en esta conversación, sin subagentes. Nada quedó diferido. Cada ficha se escribió y se selló al terminar su proyecto.

### Nuevos
| Proyecto | Documentos | Campos encontrados | Campos sin dato |
|---|---|---|---|
| PRY-199 Iluminación LED en bodegas | 6 | identidad, plan, presupuesto, contrato CT-199 (3 entregables), 2 incidencias, 1 riesgo, 1 compromiso | autoridad, fase |
| PRY-200 Tienda en línea | 6 | ídem; CT-497 (3 entregables) y factura FV-1497 | autoridad, fase |
| PRY-202 Centro de distribución norte | 8 | ídem; 2 líneas base, CC-01, 2 riesgos | producto («No aplica»), autoridad, fase |
| PRY-203 Reposición automática | 17 | ídem; CT-338 (4 entregables), factura FV-1338, 26 compromisos de 6 minutas y las notas del 17-oct, y la ficha del gerente guardada aparte en `pm_record` | producto («No aplica»), autoridad, fase |
| PRY-204 Cajas de autopago | 4 | identidad, plan, presupuesto, 2 riesgos, 1 incidencia, 1 compromiso | autoridad, fase; no hay contrato en la carpeta |
| PRY-205 Pago con QR en caja | 3 | identidad, plan, presupuesto, 1 riesgo, 1 incidencia | autoridad, fase; sin contrato ni minutas |
| PRY-206 Precios dinámicos | 6 | ídem; CT-783 (2 entregables) y factura FV-1783 | producto («No aplica»), autoridad, fase |
| PRY-207 Marca propia de alimentos | 2 | acta de constitución e informe de avance | autoridad, fase; **sin cronograma, sin hitos, sin contrato, sin minutas** |
| PRY-210 Etiquetas electrónicas de precio | 9 | ídem; CT-451 (4 entregables), factura FV-1451, 2 líneas base, CC-01 | producto («No aplica»), autoridad, fase |
| PRY-211 Pronóstico de demanda | 10 | ídem; CT-101 (2 entregables), factura FV-1101, 2 líneas base, CC-01 | producto («No aplica»), autoridad, fase |

Ninguna de las 10 declara en ningún documento la autoridad del gerente (hasta qué monto o cambio puede decidir sin comité) ni la fase.

### Actualizados
| Proyecto | Qué cambió | Fuente |
|---|---|---|
| — | Ninguno: ninguna ficha previa del portafolio cambió. Las fichas PRY-201, PRY-208 y PRY-209 se conservan tal cual. | — |

### Lo que miré primero, antes del informe
Lo siguiente son hallazgos de lectura; el cálculo (umbrales, desviaciones, semáforo) lo hace el informe, no este barrido.

**Contradicciones y cosas que no cuadran entre documentos**
- **Hitos declarados cerrados sin acta que los pruebe: 22** en 9 proyectos (PRY-200: 4, PRY-202: 2, PRY-203: 4, PRY-204: 2, PRY-205: 2, PRY-206: 1, PRY-210: 3, PRY-211: 4). Se registró lo que declara el cronograma (`met`) y la prueba quedó vacía. Con acta sí: PRY-199 (diseño), PRY-202 (ambiente de pruebas, integración con el ERP) y PRY-211 (piloto, recibido 2026-10-07 contra una fecha vigente de 2026-03-26).
- **PRY-211**: el avance declarado es 27 % y verde, pero el cronograma v2 da los cinco hitos por cerrados y ya se ejecutó 5.560 M de 9.500 M. El patrocinador y el gerente son la misma persona (Camilo Beltrán) y el acta del comité del 2026-10-06 lista a Camilo Beltrán dos veces como asistente.
- **PRY-202 y PRY-211**: el cronograma v2 ya desplaza el último hito (+116 y +118 días) por una solicitud de cambio que sigue **pendiente de presentación al comité** (CC-01). **PRY-210**: el v2 (2026-09-29) desplaza el despliegue +106 días antes de la solicitud CC-01 (2026-10-05, «autorizada por el comité»), y la minuta del comité del 2026-10-08 no la menciona. En los tres casos la línea base v2 se registró con el motivo que sugiere la cifra, dicho como tal.
- **Facturas contra entregables sin recibo**: PRY-206 facturó 182.444.266 (FV-1783, 2026-09-06) y ninguno de sus 2 entregables figura recibido (el primero vence el 2026-12-24). PRY-203 facturó 118.225.663 con un solo entregable recibido, de 95.848.542. PRY-210 facturó 616.866.660 = tres entregables «recibidos», pero solo hay acta de recibo de uno (la bolsa de horas, 2026-06-03). PRY-200 (445.577.090, un entregable declarado recibido) no tiene ninguna acta de recibo, y PRY-211 (1.101.719.908, dos declarados recibidos) tiene acta de uno solo.
- **Presupuesto**: en PRY-202 lo ejecutado (2.072 M) supera lo comprometido (1.550 M); en PRY-199 se comprometieron 1.080 M y se ejecutaron 720 M sin ningún entregable del contrato recibido (el contrato suma 432 M). Las proyecciones al cierre de PRY-202 (4.947 M contra 4.200 M), PRY-203 (1.432 M contra 1.200 M) y PRY-206 (3.402 M contra 3.300 M) superan lo aprobado.
- **PRY-207** declara **rojo**, 66 %, con cierre comprometido el 2026-04-17 (hace seis meses) y no hay cronograma que diga si hay otra fecha.
- **PRY-203**: el despliegue en la cadena vence el 2026-10-09 y sigue pendiente, con 92 % verde declarado. El gerente publicó su propia ficha (`ficha-pm.json`); quedó entera en `pm_record`, sin mezclar con mi lectura. Aquí la contrastación la hace el informe.
- Los informes de PRY-199, 200, 204 y 211 mencionan incidencias o reprogramaciones («hallazgo de seguridad en los medios de pago», «prueba de carga no alcanzó el umbral», «se reprogramó el despliegue») que ningún cronograma, minuta o solicitud de cambio recoge. Se levantaron como incidencias; el plan de PRY-200 y PRY-204 no muestra el cambio.

**Compromisos (PRY-203 concentra 26 de los 33 registrados)**
- «Enviar el documento 1» (Natalia Ospina) lleva 6 reprogramaciones: de 2026-09-28 a 2026-12-18, la última dicha en las notas del 2026-10-17. «Cerrar la prueba 2» (Laura Vélez) lleva 5, de 2026-09-18 a 2026-11-24. «Revisar el anexo 11» (Jorge Medina) lleva 3.
- Cinco compromisos fueron «ya entregados» de palabra sin acta (anexo 3, ambiente 4, fecha 7, ambiente 12, matriz 14): se dejaron abiertos porque no hay acta. Cuatro se cerraron con acta de recibo (diseño 5, matriz 6, documento 9, ambiente 20).
- Sin fecha: «Confirmar la fecha 7», «Validar el ambiente 12», «Mandar el ajuste del presupuesto» («la otra semana») y, en PRY-210, el punto 16 de Gustavo Neira («por definir»).
- PRY-204: «Entregar el punto 9» (Beatriz Cuéllar) está fechado 2026-10-08, anterior a la minuta que lo registra (2026-10-15).
- Responsables que no figuran como asistentes de la minuta donde se les asigna: Carlos Peña (PRY-199), Beatriz Cuéllar (PRY-200 y PRY-204), Liliana Torres (PRY-202), Camilo Beltrán (PRY-206), Rubén Cárdenas (PRY-211), Gustavo Neira (PRY-210).
- Riesgo dicho en reunión y no registrado (PRY-203, notas del 2026-10-17): «el proveedor podría no llegar con el equipo completo para la siguiente fase». Se registró con su fuente.

### No pude leer
| Archivo | Por qué |
|---|---|
| — | Los 91 documentos se leyeron o se confirmaron sin cambio. Los PDF, Word y Excel pasaron por `texto.py` al caché `estado/cache/texto/`; las citas de las fichas apuntan a los originales. |

### Movidos desde entrada/
| Archivo | A qué proyecto | Por qué |
|---|---|---|
| — | No existe carpeta `entrada/` en `documentos/proyectos`; no se movió nada. | — |

### Pendientes de clasificar
| Archivo | Por qué no pude decidir |
|---|---|
| `PRY-203-reposición-automática/2026-10-17-notas-reunion.txt` | Está en la raíz de la carpeta del proyecto, no en `30-reuniones/`. Es inequívoco de qué proyecto es (lo dice su título), así que lo leí en su sitio y no lo moví; la estructura propuesta sería moverlo a `30-reuniones/`. |

### Cosas que decidí y conviene que mires
- «Producto asociado: No aplica» se registró como campo sin dato, no como un producto de ese nombre.
- «recibido» del contrato se registró como `accepted` (lo que el documento afirma); «en curso» y «pendiente», como `pending`. La evidencia solo se llenó donde hay acta que nombra ese entregable.
- Las fichas PRY-201, PRY-208 y PRY-209 no se releyeron: sus documentos no cambiaron.

## Después
Hay más de un proyecto: puedo producir el informe consolidado (`/portfolio-report`), donde el código calcula las desviaciones y el semáforo y contrasta la ficha del gerente de PRY-203 con esta lectura. Las contradicciones y los compromisos vencidos de arriba irán ahí con su señal.

---
criterio-portfolio 0.4.0 · fichas tocadas: 10 (PRY-199, 200, 202, 203, 204, 205, 206, 207, 210, 211) · campos en `not_found`: autoridad y fase en las 10; producto en 5 (PRY-202, 203, 206, 210, 211) · hitos sin acta de prueba: 22 declarados cerrados · términos v1.1 y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.4.0
