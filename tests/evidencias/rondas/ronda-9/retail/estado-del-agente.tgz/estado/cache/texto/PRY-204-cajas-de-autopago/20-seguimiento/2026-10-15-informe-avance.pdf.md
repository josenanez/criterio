<!-- origen: PRY-204-cajas-de-autopago/20-seguimiento/2026-10-15-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Cajas de autopago
Código: PRY-204
Fecha de corte: 2026-10-15
Gerente: Laura Vélez

Estado declarado
Verde
Avance reportado: 57%

Lo que pasó en el periodo
- La prueba de carga de temporada no alcanzó el umbral pactado y se repite
- Se reprogramó el despliegue por el congelamiento de temporada de fin de año

Presupuesto
COP
Aprobado 3.300.000.000
Comprometido 1.666.430.444
Ejecutado 686.513.947
Proyección al cierre 3.200.947.593

Riesgos abiertos
- Concentración del conocimiento en una sola persona
- Disponibilidad de los jefes de tienda para el piloto
