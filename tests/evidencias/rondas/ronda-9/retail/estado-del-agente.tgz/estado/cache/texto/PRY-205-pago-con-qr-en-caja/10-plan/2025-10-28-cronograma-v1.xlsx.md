<!-- origen: PRY-205-pago-con-qr-en-caja/10-plan/2025-10-28-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la experiencia aprobado | 2026-03-02 | 2026-03-02 | cerrado
Ambiente de pruebas certificado | 2026-06-25 | 2026-06-25 | cerrado
Integración con el ERP | 2026-10-19 | 2026-10-19 | en curso
