<!-- origen: PRY-203-reposición-automática/30-reuniones/2026-10-03-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Expansión · Reposición automática

**Fecha:** 2026-10-03
**Asistentes:** Elena Duarte, Gustavo Neira, Jorge Medina, Laura Vélez, Liliana Torres, María Restrepo, Natalia Ospina, Ricardo Salas, Rubén Cárdenas, Sandra Gil

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Natalia Ospina | Enviar el documento 1 | 2026-11-25 |
| Laura Vélez | Cerrar la prueba 2 | 2026-11-08 |
| Natalia Ospina | Revisar el anexo 3 | 2026-10-10 |
| Jorge Medina | Confirmar la fecha 7 | por definir |
| Gustavo Neira | Entregar el punto 8 | 2026-10-22 |
| Laura Vélez | Cerrar la prueba 10 | 2026-10-03 |
| Jorge Medina | Revisar el anexo 11 | 2026-11-04 |
| María Restrepo | Aprobar el diseño 13 | 2026-10-11 |
| Liliana Torres | Confirmar la fecha 15 | 2026-09-29 |
| Elena Duarte | Entregar el punto 16 | 2026-10-15 |
| Ricardo Salas | Enviar el documento 17 | 2026-10-06 |
| Sandra Gil | Cerrar la prueba 18 | 2026-10-23 |
| Rubén Cárdenas | Revisar el anexo 19 | 2026-10-20 |
| Gustavo Neira | Validar el ambiente 20 | 2026-10-09 |

## Cerrados en esta reunión

- Actualizar la matriz 6 (Javier Hoyos): recibido, acta de recibo del 2026-10-03.
- Enviar el documento 9 (Elena Duarte): recibido, acta de recibo del 2026-10-03.

## Lo que se dijo

- Camilo Beltrán dice que ya entregó «actualizar la matriz 14». No se presentó acta.
