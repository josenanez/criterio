<!-- origen: PRY-202-centro-de-distribución-norte/20-seguimiento/2026-10-16-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Centro de distribución norte
Código: PRY-202
Fecha de corte: 2026-10-16
Gerente: Ricardo Salas

Estado declarado
Verde
Avance reportado: 82%

Lo que pasó en el periodo
- El equipo perdió dos semanas por rotación de un desarrollador clave

Presupuesto
COP
Aprobado 4.200.000.000
Comprometido 1.549.946.435
Ejecutado 2.072.313.113
Proyección al cierre 4.947.059.386

Riesgos abiertos
- Disponibilidad de los jefes de tienda para el piloto
- Concentración del conocimiento en una sola persona
