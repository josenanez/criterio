<!-- origen: PRY-210-etiquetas-electrónicas-de-precio/10-plan/2026-09-29-cronograma-v2.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la experiencia aprobado | 2026-01-18 | 2026-01-18 | cerrado
Ambiente de pruebas certificado | 2026-04-28 | 2026-04-28 | cerrado
Integración con el ERP | 2026-08-07 | 2026-08-07 | cerrado
Piloto en tiendas | 2026-11-15 | 2026-11-15 | en curso
Despliegue en la cadena | 2027-02-23 | 2027-06-09 | en curso
