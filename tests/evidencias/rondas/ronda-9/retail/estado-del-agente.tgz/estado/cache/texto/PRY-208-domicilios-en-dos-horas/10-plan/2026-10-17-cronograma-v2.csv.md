<!-- origen: PRY-208-domicilios-en-dos-horas/10-plan/2026-10-17-cronograma-v2.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño de la experiencia aprobado,2026-04-29,2026-04-29,cerrado
Ambiente de pruebas certificado,2026-07-05,2026-07-05,cerrado
Integración con el ERP,2026-09-10,2026-09-10,cerrado
Piloto en tiendas,2026-11-17,2026-11-17,en curso
Despliegue en la cadena,2027-01-23,2027-04-11,en curso
