<!-- origen: PRY-201-programa-de-fidelización/30-reuniones/2026-10-16-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Cadena de Abastecimiento · Programa de fidelización

**Fecha:** 2026-10-16
**Asistentes:** Andrés Lozano, Jorge Medina

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Natalia Ospina | Entregar el punto 16 | 2026-10-01 |
