<!-- origen: PRY-211-pronóstico-de-demanda/20-seguimiento/2026-10-09-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Pronóstico de demanda

**Código:** PRY-211
**Fecha de corte:** 2026-10-09
**Gerente:** Camilo Beltrán

## Estado declarado

**Verde**

Avance reportado: **27%**

## Lo que pasó en el periodo

- Se reprogramó el despliegue por el congelamiento de temporada de fin de año
- Se levantó un hallazgo de seguridad en los medios de pago
- La prueba de carga de temporada no alcanzó el umbral pactado y se repite

## Presupuesto

| | COP |
|---|---|
| Aprobado | 9.500.000.000 |
| Comprometido | 6.757.032.671 |
| Ejecutado | 5.560.111.981 |
| Proyección al cierre | 8.871.865.226 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
