<!-- origen: PRY-200-tienda-en-línea/00-gobierno/2025-08-14-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Tienda en línea

Código: PRY-200

Área dueña: Mercadeo

Patrocinador: Carlos Peña

Gerente de proyecto: Sandra Gil

Comité: Comité Comercial

Producto asociado: venta en línea

Fecha de aprobación: 2025-08-14

Objetivo del negocio

Entregar tienda en línea para Mercadeo.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

6.800.000.000 COP, aprobado por Comité Comercial el 2025-08-14.

Fechas comprometidas

Fecha

Inicio

2025-08-24

Cierre

2026-11-23

Criterio de éxito

Tienda en línea en producción y medido.

Dependencias declaradas

• Ninguna declarada
