<!-- origen: PRY-203-reposición-automática/20-seguimiento/2026-10-15-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Reposición automática
Código: PRY-203
Fecha de corte: 2026-10-15
Gerente: Laura Vélez

Estado declarado
Verde
Avance reportado: 92%

Lo que pasó en el periodo
- El equipo perdió dos semanas por rotación de un desarrollador clave
- Se ajustó el plan de pruebas con el área de seguridad

Presupuesto
COP
Aprobado 1.200.000.000
Comprometido 742.486.754
Ejecutado 251.538.678
Proyección al cierre 1.432.210.423

Riesgos abiertos
- Concentración del conocimiento en una sola persona
