<!-- origen: PRY-210-etiquetas-electrónicas-de-precio/20-seguimiento/2026-06-03-acta-recibo-ct-451-bolsa-de-horas-de-desarrollo.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de recibo · Bolsa de horas de desarrollo
Proyecto: PRY-210 · Etiquetas electrónicas de precio
Fecha de recibo: 2026-06-03
Recibido por: Natalia Ospina
Se recibe a satisfacción el entregable Bolsa de horas de desarrollo.
Contrato CT-451 · Integra Comercio S.A.S..
