<!-- origen: PRY-208-domicilios-en-dos-horas/00-gobierno/2026-02-11-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Domicilios en dos horas

Código: PRY-208

Área dueña: Abastecimiento

Patrocinador: Camilo Beltrán

Gerente de proyecto: Beatriz Cuéllar

Comité: Comité Comercial

Producto asociado: entrega rápida

Fecha de aprobación: 2026-02-11

Objetivo del negocio

Entregar domicilios en dos horas para Abastecimiento.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

9.500.000.000 COP, aprobado por Comité Comercial el 2026-02-11.

Fechas comprometidas

Fecha

Inicio

2026-02-21

Cierre

2027-01-23

Criterio de éxito

Domicilios en dos horas en producción y medido.

Dependencias declaradas

• Ninguna declarada
