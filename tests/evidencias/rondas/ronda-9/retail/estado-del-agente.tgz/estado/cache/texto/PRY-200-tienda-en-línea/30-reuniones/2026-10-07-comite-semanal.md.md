<!-- origen: PRY-200-tienda-en-línea/30-reuniones/2026-10-07-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité Comercial · Tienda en línea

**Fecha:** 2026-10-07
**Asistentes:** Sandra Gil, Carlos Peña

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Beatriz Cuéllar | Entregar el punto 17 | 2026-10-08 |
