<!-- origen: PRY-206-precios-dinámicos/00-gobierno/2026-06-09-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Precios dinámicos

Código: PRY-206

Área dueña: Talento humano

Patrocinador: Felipe Arango

Gerente de proyecto: Gustavo Neira

Comité: Comité de Expansión

Producto asociado: No aplica

Fecha de aprobación: 2026-06-09

Objetivo del negocio

Entregar precios dinámicos para Talento humano.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

3.300.000.000 COP, aprobado por Comité de Expansión el 2026-06-09.

Fechas comprometidas

Fecha

Inicio

2026-06-19

Cierre

2027-11-13

Criterio de éxito

Precios dinámicos en producción y medido.

Dependencias declaradas

• Ninguna declarada
