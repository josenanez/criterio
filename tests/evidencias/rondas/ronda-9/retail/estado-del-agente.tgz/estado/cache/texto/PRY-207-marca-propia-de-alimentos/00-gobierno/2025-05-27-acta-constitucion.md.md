<!-- origen: PRY-207-marca-propia-de-alimentos/00-gobierno/2025-05-27-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Marca propia de alimentos

**Código:** PRY-207
**Área dueña:** Comercial
**Patrocinador:** Felipe Arango
**Gerente de proyecto:** Javier Hoyos
**Comité:** Comité de Arquitectura
**Producto asociado:** marca propia
**Fecha de aprobación:** 2025-05-27

## Objetivo del negocio

Entregar marca propia de alimentos para Comercial.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**9.500.000.000 COP**, aprobado por Comité de Arquitectura el 2025-05-27.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-06-06 |
| Cierre | 2026-04-17 |

## Criterio de éxito

Marca propia de alimentos en producción y medido.

## Dependencias declaradas

- Ninguna declarada
