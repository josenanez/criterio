<!-- origen: PRY-209-migración-del-erp/20-seguimiento/2026-10-05-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Migración del ERP
Código: PRY-209
Fecha de corte: 2026-10-05
Gerente: Javier Hoyos

Estado declarado
Amarillo
Avance reportado: 41%

Lo que pasó en el periodo
- La prueba de carga de temporada no alcanzó el umbral pactado y se repite
- Se ajustó el plan de pruebas con el área de seguridad

Presupuesto
COP
Aprobado 1.200.000.000
Comprometido 769.346.817
Ejecutado 625.595.912
Proyección al cierre 1.194.027.192

Riesgos abiertos
- Disponibilidad de los jefes de tienda para el piloto
- Congelamiento de cambios en temporada alta
