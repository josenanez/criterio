<!-- origen: PRY-209-migración-del-erp/10-plan/2026-10-05-cronograma-v2.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la experiencia aprobado | 2026-07-25 | 2026-07-25 | cerrado
Ambiente de pruebas certificado | 2026-10-25 | 2026-10-25 | en curso
Integración con el ERP | 2027-01-25 | 2027-01-25 | en curso
Piloto en tiendas | 2027-04-27 | 2027-04-27 | en curso
Despliegue en la cadena | 2027-07-28 | 2027-10-16 | en curso
