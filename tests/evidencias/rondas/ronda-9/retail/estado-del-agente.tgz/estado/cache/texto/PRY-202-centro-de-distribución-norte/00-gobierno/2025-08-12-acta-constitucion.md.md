<!-- origen: PRY-202-centro-de-distribución-norte/00-gobierno/2025-08-12-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Centro de distribución norte

**Código:** PRY-202
**Área dueña:** Logística
**Patrocinador:** Elena Duarte
**Gerente de proyecto:** Ricardo Salas
**Comité:** Comité de Cadena de Abastecimiento
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-08-12

## Objetivo del negocio

Entregar centro de distribución norte para Logística.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**4.200.000.000 COP**, aprobado por Comité de Cadena de Abastecimiento el 2025-08-12.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-08-22 |
| Cierre | 2026-05-27 |

## Criterio de éxito

Centro de distribución norte en producción y medido.

## Dependencias declaradas

- Ninguna declarada
