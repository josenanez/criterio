<!-- origen: PRY-203-reposición-automática/10-plan/2025-07-06-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la experiencia aprobado | 2025-10-14 | 2025-10-14 | cerrado
Ambiente de pruebas certificado | 2026-01-12 | 2026-01-12 | cerrado
Integración con el ERP | 2026-04-12 | 2026-04-12 | cerrado
Piloto en tiendas | 2026-07-11 | 2026-07-11 | cerrado
Despliegue en la cadena | 2026-10-09 | 2026-10-09 | en curso
