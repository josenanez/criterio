<!-- origen: PRY-203-reposición-automática/30-reuniones/2026-09-19-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Expansión · Reposición automática

**Fecha:** 2026-09-19
**Asistentes:** Elena Duarte, Gustavo Neira, Javier Hoyos, Jorge Medina, Laura Vélez, Natalia Ospina

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Natalia Ospina | Enviar el documento 1 | 2026-10-23 |
| Laura Vélez | Cerrar la prueba 2 | 2026-10-16 |
| Natalia Ospina | Revisar el anexo 3 | 2026-10-03 |
| Jorge Medina | Aprobar el diseño 5 | 2026-10-02 |
| Javier Hoyos | Actualizar la matriz 6 | 2026-09-21 |
| Jorge Medina | Confirmar la fecha 7 | por definir |
| Gustavo Neira | Entregar el punto 8 | 2026-10-02 |
| Elena Duarte | Enviar el documento 9 | 2026-10-10 |
| Laura Vélez | Cerrar la prueba 10 | 2026-10-03 |
| Jorge Medina | Revisar el anexo 11 | 2026-10-01 |
| Gustavo Neira | Validar el ambiente 12 | por definir |
