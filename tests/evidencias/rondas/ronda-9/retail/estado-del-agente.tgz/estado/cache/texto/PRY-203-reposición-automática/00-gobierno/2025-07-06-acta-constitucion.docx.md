<!-- origen: PRY-203-reposición-automática/00-gobierno/2025-07-06-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Reposición automática

Código: PRY-203

Área dueña: Mercadeo

Patrocinador: Carlos Peña

Gerente de proyecto: Laura Vélez

Comité: Comité de Expansión

Producto asociado: No aplica

Fecha de aprobación: 2025-07-06

Objetivo del negocio

Entregar reposición automática para Mercadeo.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

1.200.000.000 COP, aprobado por Comité de Expansión el 2025-07-06.

Fechas comprometidas

Fecha

Inicio

2025-07-16

Cierre

2026-10-09

Criterio de éxito

Reposición automática en producción y medido.

Dependencias declaradas

• Ninguna declarada
