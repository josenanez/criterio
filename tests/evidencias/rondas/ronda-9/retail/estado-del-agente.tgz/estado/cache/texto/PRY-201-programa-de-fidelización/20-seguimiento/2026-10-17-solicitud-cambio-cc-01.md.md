<!-- origen: PRY-201-programa-de-fidelización/20-seguimiento/2026-10-17-solicitud-cambio-cc-01.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-01

**Proyecto:** PRY-201 · Programa de fidelización
**Fecha:** 2026-10-17
**Solicitante:** Andrés Lozano

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +24 días sobre la línea base vigente |
| Costo | 48.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
