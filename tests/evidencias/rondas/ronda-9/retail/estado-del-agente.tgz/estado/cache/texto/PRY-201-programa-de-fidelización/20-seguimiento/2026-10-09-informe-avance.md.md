<!-- origen: PRY-201-programa-de-fidelización/20-seguimiento/2026-10-09-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Programa de fidelización

**Código:** PRY-201
**Fecha de corte:** 2026-10-09
**Gerente:** Andrés Lozano

## Estado declarado

**Verde**

Avance reportado: **34%**

## Lo que pasó en el periodo

- Se acordó con arquitectura cómo se revisan los requisitos no funcionales
- Se ajustó el plan de pruebas con el área de seguridad
- Se levantó un hallazgo de seguridad en los medios de pago

## Presupuesto

| | COP |
|---|---|
| Aprobado | 9.500.000.000 |
| Comprometido | 2.898.628.541 |
| Ejecutado | 5.399.915.224 |
| Proyección al cierre | 9.448.830.972 |

## Riesgos abiertos

- Congelamiento de cambios en temporada alta
