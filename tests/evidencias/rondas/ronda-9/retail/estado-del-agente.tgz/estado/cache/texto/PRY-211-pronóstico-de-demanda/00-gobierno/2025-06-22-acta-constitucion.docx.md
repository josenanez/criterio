<!-- origen: PRY-211-pronóstico-de-demanda/00-gobierno/2025-06-22-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Pronóstico de demanda

Código: PRY-211

Área dueña: Comercial

Patrocinador: Camilo Beltrán

Gerente de proyecto: Camilo Beltrán

Comité: Comité de Cadena de Abastecimiento

Producto asociado: No aplica

Fecha de aprobación: 2025-06-22

Objetivo del negocio

Entregar pronóstico de demanda para Comercial.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

9.500.000.000 COP, aprobado por Comité de Cadena de Abastecimiento el 2025-06-22.

Fechas comprometidas

Fecha

Inicio

2025-07-02

Cierre

2026-06-01

Criterio de éxito

Pronóstico de demanda en producción y medido.

Dependencias declaradas

• Ninguna declarada
