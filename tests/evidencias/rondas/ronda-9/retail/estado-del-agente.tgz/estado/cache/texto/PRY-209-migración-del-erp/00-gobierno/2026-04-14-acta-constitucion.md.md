<!-- origen: PRY-209-migración-del-erp/00-gobierno/2026-04-14-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Migración del ERP

**Código:** PRY-209
**Área dueña:** Logística
**Patrocinador:** Natalia Ospina
**Gerente de proyecto:** Javier Hoyos
**Comité:** Comité Comercial
**Producto asociado:** No aplica
**Fecha de aprobación:** 2026-04-14

## Objetivo del negocio

Entregar migración del erp para Logística.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**1.200.000.000 COP**, aprobado por Comité Comercial el 2026-04-14.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-04-24 |
| Cierre | 2027-07-28 |

## Criterio de éxito

Migración del ERP en producción y medido.

## Dependencias declaradas

- Ninguna declarada
