<!-- origen: PRY-199-iluminación-led-en-bodegas/30-reuniones/2026-10-13-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Expansión · Iluminación LED en bodegas

Fecha: 2026-10-13

Asistentes: Andrés Lozano, María Restrepo

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Carlos Peña

Presentar el cierre de la fase

2026-11-06
