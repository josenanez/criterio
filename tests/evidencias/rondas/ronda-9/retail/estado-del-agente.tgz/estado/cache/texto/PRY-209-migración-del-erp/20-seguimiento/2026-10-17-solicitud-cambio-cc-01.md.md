<!-- origen: PRY-209-migración-del-erp/20-seguimiento/2026-10-17-solicitud-cambio-cc-01.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-01

**Proyecto:** PRY-209 · Migración del ERP
**Fecha:** 2026-10-17
**Solicitante:** Javier Hoyos

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +80 días sobre la línea base vigente |
| Costo | 160.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
