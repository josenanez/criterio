<!-- origen: PRY-210-etiquetas-electrónicas-de-precio/30-reuniones/2026-10-08-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité Comercial · Etiquetas electrónicas de precio

**Fecha:** 2026-10-08
**Asistentes:** Natalia Ospina, Carlos Peña

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Gustavo Neira | Entregar el punto 16 | por definir |
