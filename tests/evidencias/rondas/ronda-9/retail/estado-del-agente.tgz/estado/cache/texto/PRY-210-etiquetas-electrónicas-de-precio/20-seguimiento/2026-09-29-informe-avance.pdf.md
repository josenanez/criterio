<!-- origen: PRY-210-etiquetas-electrónicas-de-precio/20-seguimiento/2026-09-29-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Etiquetas electrónicas de precio
Código: PRY-210
Fecha de corte: 2026-09-29
Gerente: Natalia Ospina

Estado declarado
Verde
Avance reportado: 75%

Lo que pasó en el periodo
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales
- Se ajustó el plan de pruebas con el área de seguridad
- Se recibió el concepto de Jurídica sobre los términos de uso

Presupuesto
COP
Aprobado 2.400.000.000
Comprometido 1.513.276.252
Ejecutado 525.081.165
Proyección al cierre 2.480.849.056

Riesgos abiertos
- El proveedor no ha confirmado la fecha de la última entrega
