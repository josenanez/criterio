<!-- origen: PRY-201-programa-de-fidelización/00-gobierno/2025-05-14-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Programa de fidelización

**Código:** PRY-201
**Área dueña:** Servicio al cliente
**Patrocinador:** Jorge Medina
**Gerente de proyecto:** Andrés Lozano
**Comité:** Comité de Cadena de Abastecimiento
**Producto asociado:** puntos de fidelización
**Fecha de aprobación:** 2025-05-14

## Objetivo del negocio

Entregar programa de fidelización para Servicio al cliente.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**9.500.000.000 COP**, aprobado por Comité de Cadena de Abastecimiento el 2025-05-14.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-05-24 |
| Cierre | 2026-08-24 |

## Criterio de éxito

Programa de fidelización en producción y medido.

## Dependencias declaradas

- Ninguna declarada
