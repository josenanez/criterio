<!-- origen: PRY-206-precios-dinámicos/10-plan/2026-06-09-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la experiencia aprobado | 2026-09-29 | 2026-09-29 | cerrado
Ambiente de pruebas certificado | 2027-01-10 | 2027-01-10 | en curso
Integración con el ERP | 2027-04-22 | 2027-04-22 | en curso
Piloto en tiendas | 2027-08-03 | 2027-08-03 | en curso
Despliegue en la cadena | 2027-11-13 | 2027-11-13 | en curso
