<!-- origen: PRY-200-tienda-en-línea/10-plan/2025-08-14-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la experiencia aprobado | 2025-11-23 | 2025-11-23 | cerrado
Ambiente de pruebas certificado | 2026-02-22 | 2026-02-22 | cerrado
Integración con el ERP | 2026-05-24 | 2026-05-24 | cerrado
Piloto en tiendas | 2026-08-24 | 2026-08-24 | cerrado
Despliegue en la cadena | 2026-11-23 | 2026-11-23 | en curso
