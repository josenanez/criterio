<!-- origen: PRY-211-pronóstico-de-demanda/10-plan/2025-06-22-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño de la experiencia aprobado,2025-09-06,2025-09-06,cerrado
Ambiente de pruebas certificado,2025-11-12,2025-11-12,cerrado
Integración con el ERP,2026-01-18,2026-01-18,cerrado
Piloto en tiendas,2026-03-26,2026-03-26,cerrado
Despliegue en la cadena,2026-06-01,2026-06-01,cerrado
