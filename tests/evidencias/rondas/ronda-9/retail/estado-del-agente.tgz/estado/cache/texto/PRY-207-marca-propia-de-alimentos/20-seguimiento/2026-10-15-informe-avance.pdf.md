<!-- origen: PRY-207-marca-propia-de-alimentos/20-seguimiento/2026-10-15-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Marca propia de alimentos
Código: PRY-207
Fecha de corte: 2026-10-15
Gerente: Javier Hoyos

Estado declarado
Rojo
Avance reportado: 66%

Lo que pasó en el periodo
- Se ajustó el plan de pruebas con el área de seguridad

Presupuesto
COP
Aprobado 9.500.000.000
Comprometido 4.249.815.175
Ejecutado 1.531.882.450
Proyección al cierre 9.186.690.012

Riesgos abiertos
- Cambio en la regulación de datos personales que puede mover el alcance
- El proveedor no ha confirmado la fecha de la última entrega
