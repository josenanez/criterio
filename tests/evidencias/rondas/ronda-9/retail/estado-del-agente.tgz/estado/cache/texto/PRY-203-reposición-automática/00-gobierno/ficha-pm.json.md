<!-- origen: PRY-203-reposición-automática/00-gobierno/ficha-pm.json · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

{
 "schema_version": "0.2",
 "identity": {
 "code": {
 "value": "PRY-203",
 "source": "00-gobierno/2025-07-06-acta-constitucion.docx",
 "source_date": "2025-07-06",
 "state": "found"
 },
 "name": {
 "value": "Reposición automática",
 "source": "00-gobierno/2025-07-06-acta-constitucion.docx",
 "source_date": "2025-07-06",
 "state": "found"
 },
 "aliases": [],
 "business_area": {
 "value": "Mercadeo",
 "source": "00-gobierno/2025-07-06-acta-constitucion.docx",
 "source_date": "2025-07-06",
 "state": "found"
 },
 "product": {
 "value": null,
 "source": "00-gobierno/2025-07-06-acta-constitucion.docx",
 "source_date": "2025-07-06",
 "state": "not_found"
 },
 "authority": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "sponsor": {
 "value": "Carlos Peña",
 "source": "00-gobierno/2025-07-06-acta-constitucion.docx",
 "source_date": "2025-07-06",
 "state": "found"
 },
 "manager": {
 "value": "Laura Vélez",
 "source": "00-gobierno/2025-07-06-acta-constitucion.docx",
 "source_date": "2025-07-06",
 "state": "found"
 },
 "committee": {
 "value": "Comité de Expansión",
 "source": "00-gobierno/2025-07-06-acta-constitucion.docx",
 "source_date": "2025-07-06",
 "state": "found"
 },
 "phase": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 }
 },
 "declared": {
 "status": "verde",
 "progress_pct": 92,
 "as_of": "2026-10-15",
 "source": "20-seguimiento/2026-10-15-informe-avance.pdf"
 },
 "plan": {
 "start_date": {
 "value": "2025-07-16",
 "source": "00-gobierno/2025-07-06-acta-constitucion.docx",
 "source_date": "2025-07-06",
 "state": "found"
 },
 "end_date": {
 "value": "2026-10-09",
 "source": "10-plan/2025-07-06-cronograma-v1.xlsx",
 "source_date": "2025-07-06",
 "state": "found"
 },
 "baseline": [
 {
 "version": 1,
 "approved_on": "2025-07-06",
 "start_date": "2025-07-16",
 "end_date": "2026-10-09",
 "reason": "Aprobación del acta de constitución por el Comité de Expansión",
 "source": "00-gobierno/2025-07-06-acta-constitucion.docx"
 }
 ],
 "milestones": [
 {
 "name": "Diseño de la experiencia aprobado",
 "baseline_date": "2025-10-14",
 "current_date": "2025-10-14",
 "state": "met",
 "evidence": null,
 "source": "10-plan/2025-07-06-cronograma-v1.xlsx"
 },
 {
 "name": "Ambiente de pruebas certificado",
 "baseline_date": "2026-01-12",
 "current_date": "2026-01-12",
 "state": "met",
 "evidence": null,
 "source": "10-plan/2025-07-06-cronograma-v1.xlsx"
 },
 {
 "name": "Integración con el ERP",
 "baseline_date": "2026-04-12",
 "current_date": "2026-04-12",
 "state": "met",
 "evidence": null,
 "source": "10-plan/2025-07-06-cronograma-v1.xlsx"
 },
 {
 "name": "Piloto en tiendas",
 "baseline_date": "2026-07-11",
 "current_date": "2026-07-11",
 "state": "met",
 "evidence": null,
 "source": "10-plan/2025-07-06-cronograma-v1.xlsx"
 },
 {
 "name": "Despliegue en la cadena",
 "baseline_date": "2026-10-09",
 "current_date": "2026-10-09",
 "state": "pending",
 "evidence": null,
 "source": "10-plan/2025-07-06-cronograma-v1.xlsx"
 }
 ],
 "scope_summary": {
 "value": "Componente 1; Componente 2; Componente 3",
 "source": "00-gobierno/2025-07-06-acta-constitucion.docx",
 "source_date": "2025-07-06",
 "state": "found"
 },
 "exclusions": {
 "value": "Lo que otro proyecto cubre",
 "source": "00-gobierno/2025-07-06-acta-constitucion.docx",
 "source_date": "2025-07-06",
 "state": "found"
 }
 },
 "money": {
 "currency": "COP",
 "approved": {
 "value": 1200000000,
 "source": "00-gobierno/2025-07-06-acta-constitucion.docx",
 "source_date": "2025-07-06",
 "state": "found"
 },
 "committed": {
 "value": 742486754,
 "source": "20-seguimiento/2026-10-15-informe-avance.pdf",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "executed": {
 "value": 251538678,
 "source": "20-seguimiento/2026-10-15-informe-avance.pdf",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "projection": {
 "value": 1432210423,
 "source": "20-seguimiento/2026-10-15-informe-avance.pdf",
 "source_date": "2026-10-15",
 "state": "found"
 }
 },
 "vendors": [
 {
 "name": "Sistemas Comerciales del Norte",
 "contract_ref": "CT-338",
 "deliverables": [
 {
 "name": "Licenciamiento de la plataforma",
 "due_date": "2025-10-23",
 "amount": 95848542,
 "state": "pending",
 "evidence": null,
 "source": "00-gobierno/2025-06-30-contrato-ct-338.docx"
 },
 {
 "name": "Bolsa de horas de desarrollo",
 "due_date": "2026-01-30",
 "amount": 95848542,
 "state": "pending",
 "evidence": null,
 "source": "00-gobierno/2025-06-30-contrato-ct-338.docx"
 },
 {
 "name": "Configuración del catálogo",
 "due_date": "2026-05-09",
 "amount": 95848542,
 "state": "pending",
 "evidence": null,
 "source": "00-gobierno/2025-06-30-contrato-ct-338.docx"
 },
 {
 "name": "Soporte del primer trimestre",
 "due_date": "2026-08-16",
 "amount": 95848542,
 "state": "accepted",
 "evidence": null,
 "source": "00-gobierno/2025-06-30-contrato-ct-338.docx"
 }
 ],
 "invoiced": {
 "value": 118225663,
 "source": "20-seguimiento/2026-09-09-factura-ct-338.pdf",
 "source_date": "2026-09-09",
 "state": "found"
 },
 "source": "00-gobierno/2025-06-30-contrato-ct-338.docx"
 }
 ],
 "raid": {
 "risks": [
 {
 "what": "Concentración del conocimiento en una sola persona",
 "probability": null,
 "impact": null,
 "owner": null,
 "due_date": null,
 "last_moved": null,
 "source": "20-seguimiento/2026-10-15-informe-avance.pdf"
 },
 {
 "what": "El proveedor podría no llegar con el equipo completo para la siguiente fase (dicho en reunión, nadie lo anotó como riesgo)",
 "probability": null,
 "impact": null,
 "owner": null,
 "due_date": null,
 "last_moved": null,
 "source": "2026-10-17-notas-reunion.txt"
 }
 ],
 "assumptions": [],
 "issues": [
 {
 "what": "El equipo perdió dos semanas por rotación de un desarrollador clave",
 "since": null,
 "owner": null,
 "source": "20-seguimiento/2026-10-15-informe-avance.pdf"
 }
 ],
 "dependencies": []
 },
 "changes": [],
 "commitments": [
 {
 "who": "Natalia Ospina",
 "what": "Enviar el documento 1",
 "due_date": "2026-12-18",
 "original_due_date": "2026-09-28",
 "stated_on": "2026-09-05",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-12",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md"
 },
 {
 "due_date": "2026-10-23",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md"
 },
 {
 "due_date": "2026-11-08",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md"
 },
 {
 "due_date": "2026-11-25",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 },
 {
 "due_date": "2026-12-04",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 },
 {
 "due_date": "2026-12-18",
 "stated_on": "2026-10-17",
 "source": "2026-10-17-notas-reunion.txt"
 }
 ]
 },
 {
 "who": "Laura Vélez",
 "what": "Cerrar la prueba 2",
 "due_date": "2026-11-24",
 "original_due_date": "2026-09-18",
 "stated_on": "2026-09-05",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-09-27",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md"
 },
 {
 "due_date": "2026-10-16",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md"
 },
 {
 "due_date": "2026-10-29",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md"
 },
 {
 "due_date": "2026-11-08",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 },
 {
 "due_date": "2026-11-24",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Natalia Ospina",
 "what": "Revisar el anexo 3",
 "due_date": "2026-10-10",
 "original_due_date": "2026-10-03",
 "stated_on": "2026-09-05",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-10",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 }
 ],
 "note": "Natalia Ospina dice que ya lo entregó; no se presentó acta (minuta 2026-10-10)"
 },
 {
 "who": "Carlos Peña",
 "what": "Validar el ambiente 4",
 "due_date": "2026-09-25",
 "original_due_date": "2026-09-25",
 "stated_on": "2026-09-05",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "state": "open",
 "reschedules": [],
 "note": "Carlos Peña dice que ya lo entregó; no se presentó acta (minuta 2026-09-12); no vuelve a aparecer en las minutas siguientes"
 },
 {
 "who": "Jorge Medina",
 "what": "Aprobar el diseño 5",
 "due_date": "2026-10-02",
 "original_due_date": "2026-10-02",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-09-26-acta-recibo-5.md",
 "closed_on": "2026-09-26"
 },
 {
 "who": "Javier Hoyos",
 "what": "Actualizar la matriz 6",
 "due_date": "2026-09-21",
 "original_due_date": "2026-09-21",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-10-03-acta-recibo-6.md",
 "closed_on": "2026-10-03"
 },
 {
 "who": "Jorge Medina",
 "what": "Confirmar la fecha 7",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "state": "open",
 "reschedules": [],
 "note": "Jorge Medina dice que ya lo entregó; no se presentó acta (minuta 2026-10-10)"
 },
 {
 "who": "Gustavo Neira",
 "what": "Entregar el punto 8",
 "due_date": "2026-10-22",
 "original_due_date": "2026-10-02",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-11",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md"
 },
 {
 "due_date": "2026-10-22",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 }
 ],
 "note": "en la minuta del 2026-09-12 salió «por definir»; la primera fecha se puso el 2026-09-19"
 },
 {
 "who": "Elena Duarte",
 "what": "Enviar el documento 9",
 "due_date": "2026-10-10",
 "original_due_date": "2026-10-10",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-10-03-acta-recibo-9.md",
 "closed_on": "2026-10-03"
 },
 {
 "who": "Laura Vélez",
 "what": "Cerrar la prueba 10",
 "due_date": "2026-10-03",
 "original_due_date": "2026-10-03",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Jorge Medina",
 "what": "Revisar el anexo 11",
 "due_date": "2026-11-20",
 "original_due_date": "2026-10-01",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-17",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md"
 },
 {
 "due_date": "2026-11-04",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 },
 {
 "due_date": "2026-11-20",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Gustavo Neira",
 "what": "Validar el ambiente 12",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "state": "open",
 "reschedules": [],
 "note": "Gustavo Neira dice que ya lo entregó; no se presentó acta (minuta 2026-09-26); no vuelve a aparecer"
 },
 {
 "who": "María Restrepo",
 "what": "Aprobar el diseño 13",
 "due_date": "2026-10-11",
 "original_due_date": "2026-10-11",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Camilo Beltrán",
 "what": "Actualizar la matriz 14",
 "due_date": "2026-10-11",
 "original_due_date": "2026-10-11",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "state": "open",
 "reschedules": [],
 "note": "Camilo Beltrán dice que ya lo entregó; no se presentó acta (minuta 2026-10-03); no vuelve a aparecer"
 },
 {
 "who": "Liliana Torres",
 "what": "Confirmar la fecha 15",
 "due_date": "2026-09-29",
 "original_due_date": "2026-09-29",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Elena Duarte",
 "what": "Entregar el punto 16",
 "due_date": "2026-10-15",
 "original_due_date": "2026-10-15",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Ricardo Salas",
 "what": "Enviar el documento 17",
 "due_date": "2026-10-06",
 "original_due_date": "2026-10-06",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Sandra Gil",
 "what": "Cerrar la prueba 18",
 "due_date": "2026-11-04",
 "original_due_date": "2026-10-23",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-11-04",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Rubén Cárdenas",
 "what": "Revisar el anexo 19",
 "due_date": "2026-10-20",
 "original_due_date": "2026-10-20",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Gustavo Neira",
 "what": "Validar el ambiente 20",
 "due_date": "2026-10-09",
 "original_due_date": "2026-10-09",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-10-10-acta-recibo-20.md",
 "closed_on": "2026-10-10"
 },
 {
 "who": "Camilo Beltrán",
 "what": "Aprobar el diseño 21",
 "due_date": "2026-11-07",
 "original_due_date": "2026-11-07",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Andrés Lozano",
 "what": "Actualizar la matriz 22",
 "due_date": "2026-10-25",
 "original_due_date": "2026-10-25",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Mauricio Pérez",
 "what": "Confirmar la fecha 23",
 "due_date": "2026-10-19",
 "original_due_date": "2026-10-19",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Rubén Cárdenas",
 "what": "Entregar el punto 24",
 "due_date": "2026-10-19",
 "original_due_date": "2026-10-19",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Laura Vélez",
 "what": "Mandar el ajuste del presupuesto",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-10-17",
 "source": "2026-10-17-notas-reunion.txt",
 "state": "open",
 "reschedules": [],
 "note": "«la otra semana», sin fecha dicha"
 },
 {
 "who": "Óscar Ramírez",
 "what": "Revisión con el proveedor",
 "due_date": "2026-10-27",
 "original_due_date": "2026-10-27",
 "stated_on": "2026-10-17",
 "source": "2026-10-17-notas-reunion.txt",
 "state": "open",
 "reschedules": []
 }
 ],
 "meta": {
 "record_updated": "2026-10-17",
 "fields_not_found": [
 "identity.product",
 "identity.authority",
 "identity.phase"
 ],
 "open_conflicts": []
 }
}
