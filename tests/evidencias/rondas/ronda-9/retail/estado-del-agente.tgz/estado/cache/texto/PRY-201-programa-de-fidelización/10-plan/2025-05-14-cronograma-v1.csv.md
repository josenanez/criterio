<!-- origen: PRY-201-programa-de-fidelización/10-plan/2025-05-14-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño de la experiencia aprobado,2025-08-23,2025-08-23,cerrado
Ambiente de pruebas certificado,2025-11-22,2025-11-22,cerrado
Integración con el ERP,2026-02-22,2026-02-22,cerrado
Piloto en tiendas,2026-05-24,2026-05-24,cerrado
Despliegue en la cadena,2026-08-24,2026-08-24,cerrado
