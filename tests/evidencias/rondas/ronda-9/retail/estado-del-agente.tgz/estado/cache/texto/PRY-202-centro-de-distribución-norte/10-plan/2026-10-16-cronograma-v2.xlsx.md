<!-- origen: PRY-202-centro-de-distribución-norte/10-plan/2026-10-16-cronograma-v2.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la experiencia aprobado | 2025-10-30 | 2025-10-30 | cerrado
Ambiente de pruebas certificado | 2026-01-08 | 2026-01-08 | cerrado
Integración con el ERP | 2026-03-18 | 2026-03-18 | cerrado
Piloto en tiendas | 2026-05-27 | 2026-09-20 | cerrado
