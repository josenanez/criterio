## Tarjeta de la tienda (PRD-309) · 2026-10-17

**Primera revisión: no hay corte anterior, así que todo lo que sigue es nuevo.** 15 requerimientos (13 aceptados, 2 propuestos).

### Para decisión del comité
| Qué | REQ | Cuánto lleva | Qué se necesita | Quién |
|---|---|---|---|---|
| Propuesto sin decidir | REQ-4908 | 179 días (desde 2026-04-21) | Que se decida: aceptar o descartar. Falta saber quién tiene la facultad. | Gustavo Neira (doliente); decide el Comité de producto |
| Propuesto sin decidir | REQ-4905 | 161 días (desde 2026-05-09) | Lo mismo | Natalia Ospina (doliente); decide el Comité de producto |
| Declarado vs. medido | volumen_mensual | Caso de negocio 2026-02-23: 278.242. Tablero 2026-10-09: 214.637 | Brecha de 22,9 % (umbral 20 %). Hay que aclarar qué cifra sostiene el caso de negocio. | Ricardo Salas |
| Supuesto sin verificar | «El cliente paga por la entrega rápida» | 31 días (umbral 30) | Una verificación con clientes, o tratarlo como riesgo registrado. | Ricardo Salas |

### Aceptados sin sustento
- **Sin evidencia:** REQ-4901, REQ-4912.
- **Sin criterio de aceptación:** REQ-4901, REQ-4907, REQ-4909, REQ-4913.
- **Evidencia vencida (12 meses):** 13 requerimientos se apoyan en la misma entrevista del 2025-10-12, que además no nombra ninguno de ellos. La definición queda sin respaldo de demanda reciente.
- **Sin criterio de éxito:** ni la definición ni el caso de negocio lo escriben.

### Las trazas
Ningún requerimiento aceptado tiene proyecto (0 de 13 trazados). No hay carpeta de fichas configurada, así que **ninguna traza se da por confirmada** y no sé si algún proyecto construye estos requerimientos. Queda en el anexo.

### Del descubrimiento
Sin documentos nuevos desde la configuración. El único material de descubrimiento es la entrevista del 2025-10-12.

**Vuelvo el 2026-11-16.**
