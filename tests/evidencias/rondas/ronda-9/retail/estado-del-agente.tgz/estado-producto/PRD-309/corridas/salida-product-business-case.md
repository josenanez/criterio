# Caso de negocio — Tarjeta de la tienda (PRD-309) · borrador del 2026-10-17
**Desde:** la definición y el caso de negocio, ambos del 2026-02-23 · **Cifras con fuente:** 1 de 1 (una declarada, una medida; ninguna supuesta que se haya podido citar)
**Términos:** vigentes (v1.1), aceptados por José Francisco Ñáñez el 2026-10-17; no hizo falta registrarlos de nuevo.

Es un borrador de estructura. No produce ni estima cifras, y no recomienda aprobar ni rechazar.

## Qué problema resuelve, y para quién
- **Problema:** «El segmento Hogares no tiene tarjeta de la tienda.» (`00-definicion/2026-02-23-definicion-producto.md`, 2026-02-23)
- **Para quién:** Hogares, sin tamaño. No hay cifra de cuántos hogares son.
- **Propuesta:** la definición solo dice «Propuesta principal». El caso no dice qué se construye.

## Qué se construye
El registro tiene 15 requerimientos: 13 aceptados y 2 propuestos. El caso de negocio solo recibe los decididos. Todos vienen del acta del comité del 2026-10-11 (`30-decisiones/2026-10-11-comite-producto.docx`), que solo los nombra con su número.

| Requerimiento | Estado | Evidencia de demanda |
|---|---|---|
| REQ-2035, 4900, 4901, 4902, 4903, 4904, 4906, 4907, 4909, 4910, 4911, 4912, 4913 (13) | aceptado | Una sola voz: la entrevista a «cliente entrevistado» del 2025-10-12, «Lo necesito y hoy no lo tengo.» No nombra ningún requerimiento. 11 la tienen citada; REQ-4901 y REQ-4912 no tienen ninguna. |
| REQ-4905, REQ-4908 (2) | propuesto | Fuera del caso hasta que se decidan. |

- Ningún requerimiento tiene proyecto asignado, y la definición dice «Ninguno declarado».
- Ningún requerimiento escribe qué necesidad cubre. El criterio de aceptación más repetido es «se verifica en producción», que no se puede verificar.
- **Quién decidió:** el acta no lo nombra en ninguno.
- La entrevista tiene 12 meses, que es el umbral de antigüedad de la evidencia.

## Las cifras
| Cifra | Valor | Clase | De dónde sale | De cuándo |
|---|---|---|---|---|
| volumen_mensual | 278.242 | Declarada | Caso de negocio, `00-definicion/2026-02-23-caso-de-negocio.md`. No dice cómo se calculó. | 2026-02-23 |
| volumen_mensual | 214.637 | Medida | Bodega de datos, tablero de producto, `20-metricas/2026-10-09-tablero-metricas.md`. El tablero no define qué cuenta como volumen. | corte 2026-10-09 |
| Retorno esperado | «en 24 meses» | Declarada, sin cifra | Caso de negocio, 2026-02-23 | 2026-02-23 |
| Que el cliente paga por la entrega rápida | — | Supuesta | Definición, supuesto declarado el 2026-09-16, sin verificar | 2026-09-16 |

El retorno trae un plazo y ningún monto. Por eso no hay nada que medir ni que calcular.

### Donde la cifra declarada y la medida no coinciden
| Métrica | Declarada | Medida | Las dos fuentes y fechas |
|---|---|---|---|
| volumen_mensual | 278.242 | 214.637 | Diferencia de 22,9 % con la declarada por encima, y el umbral es 20 %. Caso de negocio, 2026-02-23 · tablero de producto, corte 2026-10-09 |

Hay un solo punto medido, así que no hay tendencia. No se sabe si las dos cifras cuentan lo mismo, porque ni el caso ni el tablero definen el volumen. Hasta que alguien lo aclare, la diferencia puede ser de negocio o de definición.

## Los costos
| Concepto | Valor | De dónde sale |
|---|---|---|
| Costo de construir | **No está en ningún documento** | — |
| Costo del equipo, contratos, cotizaciones, costo de operar | No están | — |

Este es el primer vacío. Sin el costo de construir lo que hay es una propuesta, y todavía no un caso de negocio que se pueda evaluar.

## Supuestos sobre los que se sostiene
| Supuesto | Qué pasa si resulta falso | Quién lo verificaría |
|---|---|---|
| El cliente paga por la entrega rápida (declarado el 2026-09-16, 31 días sin verificar; umbral 30) | No lo dice el caso. Además no se ve qué relación tiene la entrega rápida con una tarjeta de la tienda, porque no aparece ni en el problema ni en la propuesta. | Sin nombrar. Haría falta un hecho observable, por ejemplo cuántos clientes de Hogares pagaron por entrega rápida en un período. |
| Que 278.242 sea el volumen que la tarjeta moverá | No lo dice el caso | Sin nombrar. Lo declara el negocio y no tiene método. |

## Vacíos
| Qué falta | Por qué importa | Quién lo produce |
|---|---|---|
| Costo de construir y operar | Sin él no hay caso que evaluar | Sin nombrar; el negocio (Ricardo Salas, gerente de producto, lo declararía) |
| Cifra del retorno, y no solo el plazo | «Retorno en 24 meses» no se puede defender ni medir | El negocio |
| Cómo se calculó el volumen de 278.242 y qué cuenta el tablero | Sin eso no se sabe si la diferencia de 22,9 % es real | Quien preparó el caso (Ricardo Salas) y quien mantiene el tablero |
| Tamaño del segmento Hogares | No hay cuántos clientes son | El negocio |
| Evidencia de demanda de más de una voz | 13 aceptados se apoyan en una entrevista de hace 12 meses | Descubrimiento (`/product-discovery`) |
| Qué se construye (la propuesta) | El caso no describe el producto | Ricardo Salas |
| Qué pasa si no se hace, y qué alternativas se consideraron | El caso no los menciona | El negocio |
| Quién decide | Ningún documento lo nombra; «Comité de producto» es la respuesta sugerida en la configuración | La organización |
| País y qué datos o dinero mueve la tarjeta | Una tarjeta es un medio de pago y probablemente crédito. Sin país no se puede citar ninguna norma, y no la invento. | El negocio, con revisión jurídica |
| Proyecto que lo construye | Ninguno declarado | Ricardo Salas / PMO |

## Cómo se sabrá si funcionó
**No está declarado.** Ni la definición ni el caso de negocio escriben un criterio de éxito, una métrica de cierre o una fecha de corte. El único número es el volumen mensual, y es una afirmación sin umbral de éxito. Sin esto el producto no se puede cerrar meses después. Esta línea la tiene que escribir el negocio.

## Si hay otros productos publicados
No hay ninguno a la vista: `estado-producto/` solo contiene PRD-309, así que no se pudo hacer el cruce de `/product-overlap`. Las carpetas de documentos de PRD-299 a PRD-308 existen y varias traen una métrica con el mismo nombre, `volumen_mensual`. No las leí ni afirmo que cuenten lo mismo; tener el mismo nombre no prueba coincidencia. Si esos productos se publican, conviene cruzar antes del comité para que no sumen las mismas transacciones dos veces.

## Después
El caso no se sostiene todavía. Faltan el costo de construir y el criterio de éxito, y el retorno no tiene cifra. Se puede pasar el supuesto de la entrega rápida a seguimiento (assumption-tracking), porque ya cruzó los 30 días. `/product-charter` no corresponde mientras la definición esté abierta.
