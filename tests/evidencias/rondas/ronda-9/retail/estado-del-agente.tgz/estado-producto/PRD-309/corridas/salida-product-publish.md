**No publiqué la ficha de PRD-309 (Tarjeta de la tienda).** Corte al 2026-10-17.

Motivo: la configuración (`.criterio/producto/PRD-309/config.json`) no tiene carpeta de productos publicados, y no existe ninguna carpeta `publicados/` en el espacio. Sin un sitio común acordado esto no sirve, y acordarlo es una conversación de la organización, no un comando. No creé ni inventé la carpeta.

**La ficha quedó calculada y lista, sin escribir:**
- 15 requerimientos (13 aceptados, 2 propuestos) · 0 proyectos (ninguno tiene proyecto asignado) · 1 métrica afirmada
- Segmento declarado: Hogares
- Métrica: volumen_mensual, 278242 declarado, según `documentos/productos/PRD-309/00-definicion/2026-02-23-caso-de-negocio.md` (2026-02-23)

Cuando la organización acuerde la carpeta, se configura y se vuelve a correr el comando.
