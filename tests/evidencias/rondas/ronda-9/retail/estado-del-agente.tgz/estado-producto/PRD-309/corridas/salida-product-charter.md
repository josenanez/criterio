# Acta de constitución — Tarjeta de la tienda · REQ-4900 · borrador del 2026-10-17
**Producto:** PRD-309 Tarjeta de la tienda · **Requerimientos:** REQ-4900

> **Verificación previa (paso 1).** REQ-4900 está *aceptado* (desde 2026-04-16), pero el acta sale con cuatro vacíos. Como nadie puede responder en esta sesión, tomé la respuesta sugerida —seguir marcando los vacíos— y no rellené ninguno.
> - **Criterio de aceptación:** existe pero no es verificable. Dice solo «se verifica en producción» (acta del comité 2026-10-11).
> - **Evidencia de demanda:** débil. La cita no nombra este requerimiento y tiene 12 meses y 5 días (umbral: 12).
> - **Autoridad:** ningún documento la declara.
> - **Quién decidió la aceptación:** no está escrito.
>
> Términos: ya vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17). No hubo que registrarlos de nuevo.

## Qué problema resuelve
«El segmento Hogares no tiene tarjeta de la tienda.» (`00-definicion/2026-02-23-definicion-producto.md`, 2026-02-23).
**Qué es REQ-4900 en concreto: no está dicho.** El acta del comité lo titula «Requerimiento REQ-4900», sin descripción. Hay que leer el problema del *producto*, no el del requerimiento.

## Criterio de éxito
| Criterio | Fuente | Cómo se verifica |
|---|---|---|
| «se verifica en producción» | `30-decisiones/2026-10-11-comite-producto.docx` | **No dice qué se mide, con qué umbral ni quién lo certifica.** Vacío del acta. |

El criterio de éxito *del producto* tampoco existe: ni la definición ni el caso de negocio lo escriben. El retorno esperado dice solo «Retorno esperado en 24 meses», sin cifra (`2026-02-23-caso-de-negocio.md`).

## Alcance
### Entra
| REQ | Título | Evidencia que lo sostiene |
|---|---|---|
| REQ-4900 | «Requerimiento REQ-4900» (sin descripción) | Entrevista 2025-10-12: «Lo necesito y hoy no lo tengo.» **No nombra el requerimiento** y es anterior a la aceptación en 6 meses. El acta lo cita como pedido por «Cliente entrevistado». |

### No entra
| REQ | Título | Por qué no |
|---|---|---|
| REQ-4901 … REQ-4913, REQ-2035 | «Requerimiento REQ-49xx» | Este acta se pidió solo para REQ-4900. Ninguno de ellos tiene proyecto asignado (columna «Proyecto que lo ejecuta» del acta: «—»). |
| REQ-4905, REQ-4908 | — | Están *propuestos*, no aceptados: no pueden entrar a un acta. |

Nada del texto del requerimiento permite excluir partes de REQ-4900: no hay texto. **La lista de exclusiones internas queda vacía y es otro vacío.**

## Gobierno
- **Patrocinador:** no está dicho en ningún documento.
- **Gerente propuesto:** no está dicho. Ricardo Salas es gerente *de producto* (definición, 2026-02-23); no consta que deba ser gerente del proyecto. Propongo solo que lo nombre quien tenga la autoridad.
- **Doliente del requerimiento:** Óscar Ramírez (acta del comité, 2026-10-11).
- **Comité:** Comité de producto. Esto es la respuesta sugerida de `product-setup`, **no sale de un documento**. El acta del comité solo lista como asistente a Ricardo Salas.
- **Autoridad del gerente:** no está dicha. Un proyecto sin esto escala todo o no escala nada.
- **Quién aceptó REQ-4900:** no está dicho (campo «quién decidió» sin fuente). La decisión del comité dice solo «Se mantiene el plan».

## Supuestos que se llevan al proyecto
| Supuesto | Verificado | Se convierte en riesgo de |
|---|---|---|
| «El cliente paga por la entrega rápida» (declarado 2026-09-16, `definicion-producto.md`) | No. Lleva 31 días sin verificar (umbral: 30). | Riesgo del proyecto, **sin doliente asignado**. Además no se ve qué relación tiene la entrega rápida con una tarjeta de la tienda, y su fecha (2026-09-16) es posterior a la de la definición (2026-02-23). Hay que aclarar eso. |
| Cifra del caso: `volumen_mensual` = 278.242 | Contradicha por el tablero: 214.637 (corte 2026-10-09) | Riesgo de caso de negocio. Brecha de 22,9 %, sobre el umbral de 20 %. Es una cifra del negocio, no mía. |

REQ-4900 no tiene supuestos propios registrados.

## Restricciones normativas sin resolver
| Qué toca | Obligación | Norma | Estado |
|---|---|---|---|
| Una tarjeta de la tienda toca crédito o pagos al consumidor y datos personales | No determinada | **Ningún documento cita una norma** | Sin barrer. No cito normas de memoria. Queda abierto para quien conozca la jurisdicción. |

## Vacíos de este acta
| Qué falta | Consecuencia de firmar sin eso | Quién lo cierra |
|---|---|---|
| Descripción de REQ-4900 | Se firma un proyecto cuyo contenido nadie puede leer | Óscar Ramírez (doliente) |
| Criterio de aceptación verificable | El cierre no se podrá juzgar | Óscar Ramírez / Comité de producto |
| Evidencia que nombre el requerimiento y esté vigente (>12 meses) | La demanda queda sostenida en una cita genérica y vencida | Ricardo Salas (nueva ronda de descubrimiento) |
| Patrocinador, gerente del proyecto y autoridad | El gerente no sabrá qué puede decidir | Quien tenga autoridad sobre el producto (no declarada) |
| Quién aceptó REQ-4900 | No hay decisor trazable | Comité de producto |
| Criterio de éxito y cifra de retorno del producto | Sin referencia contra la cual medir | Ricardo Salas |
| Alcance excluido dentro de REQ-4900 | Discusión del tercer mes | Óscar Ramírez |
| Barrido normativo | Obligaciones sin dueño | A definir |

---
**Esto es un borrador.** Lo firma la persona con autoridad sobre el producto, que **no está nombrada en los documentos**. Pendiente: nombrarla.
**No se creó la ficha del proyecto** (`portafolio.py init`) ni se escribió el estado declarado: sin firma no hay ficha.

**Qué sigue:** quien firme debe cerrar los vacíos o firmar sabiendo que están. Después, el gerente del proyecto instala `criterio-project` y corre `/pm-setup`. Cuando publique su ficha con `/pm-publish`, `/product-trace` podrá confirmar la traza.
