## Registro — Tarjeta de la tienda (PRD-309) · al 2026-10-17
15 requerimientos · 13 decididos · 84.6% con evidencia · 0% con proyecto que lo ejecuta

Todas las cifras salen de `producto.py compute`. Cada requerimiento se conoce solo por su número: el acta del comité (2026-10-11) no los describe.

### Se va a construir y nadie lo pidió
| REQ | Título | Estado | Doliente |
|---|---|---|---|
| REQ-4901 | Requerimiento REQ-4901 | aceptado (2026-05-10) | Paula Céspedes |
| REQ-4912 | Requerimiento REQ-4912 | aceptado (2026-03-17) | Mauricio Pérez |

Ninguno tiene una sola cita de quien lo pidió. REQ-4901 tampoco tiene criterio de aceptación.

### Decidido y nadie lo está construyendo
Los 13 aceptados no tienen proyecto que los ejecute (0% trazado). Aviso: la carpeta de fichas de proyectos (`estado`) está vacía, así que esto significa «sin traza declarada», no «confirmado que nadie lo construye». Primero hay que correr el barrido de proyectos.

| REQ | Decidido el |
|---|---|
| REQ-4912 | 2026-03-17 |
| REQ-4913 | 2026-03-26 |
| REQ-4904 | 2026-04-01 |
| REQ-4903 | 2026-04-05 |
| REQ-4900 | 2026-04-16 |
| REQ-4909 | 2026-04-20 |
| REQ-4901 | 2026-05-10 |
| REQ-4910 | 2026-05-10 |
| REQ-4906 | 2026-07-08 |
| REQ-4902 | 2026-07-09 |
| REQ-4911 | 2026-08-13 |
| REQ-4907 | 2026-09-02 |
| REQ-2035 | 2026-09-27 |

### Sin doliente, o con un área en vez de una persona
Ninguno: los 15 tienen una persona como doliente.

### Sin criterio de aceptación
Solo los decididos.

| REQ | Estado |
|---|---|
| REQ-4901 | aceptado |
| REQ-4907 | aceptado |
| REQ-4909 | aceptado |
| REQ-4913 | aceptado |

Los propuestos REQ-4905 y REQ-4908 tampoco lo tienen, pero a un propuesto no se le exige.

### Decidido sin documento que lo respalde
Los 13 aceptados quedan registrados en el acta del comité de 2026-10-11, pero ninguno dice **quién decidió**. Ese acta se escribió meses después de varias de las fechas de decisión (la más vieja es de 2026-03-17).

| REQ | Quién decidió | Cuándo |
|---|---|---|
| REQ-2035, 4900, 4901, 4902, 4903, 4904, 4906, 4907, 4909, 4910, 4911, 4912, 4913 | no está dicho | ver fechas arriba |

### Lleva meses y nadie lo decide
Umbral de la configuración: 60 días.

| REQ | Título | Propuesto hace | Quién tiene la facultad |
|---|---|---|---|
| REQ-4908 (doliente: Gustavo Neira) | Requerimiento REQ-4908 | 179 días (desde 2026-04-21) | Comité de producto |
| REQ-4905 (doliente: Natalia Ospina) | Requerimiento REQ-4905 | 161 días (desde 2026-05-09) | Comité de producto |

Proponer decidirlos (aceptar o descartar) en el próximo comité. Descartar con su documento también es una decisión valiosa. Ninguno se cierra por viejo.

### Evidencia vieja
Umbral: 12 meses. Todos se sostienen en la misma entrevista de cliente del 2025-10-12, y esa entrevista **no nombra ninguno de estos requerimientos** («Lo necesito y hoy no lo tengo.»). El acta lo cita como quien lo pidió. Es evidencia genérica, no evidencia por requerimiento.

| REQ | Lo más nuevo que lo sostiene | Hace |
|---|---|---|
| REQ-2035, 4900, 4902, 4903, 4904, 4906, 4907, 4909, 4910, 4911, 4913 (decididos) | 2025-10-12 | 12 meses |
| REQ-4905, 4908 (propuestos) | 2025-10-12 | 12 meses |

### De la definición del producto
- **Sin criterio de éxito:** ni la definición ni el caso de negocio lo escriben.
- **Cifra declarada vs medida:** volumen mensual declarado 278 242 (caso de negocio, 2026-02-23) contra 214 637 medidos (tablero, 2026-10-09). El declarado está 22.9% por encima, y el umbral es 20%.
- **Supuesto sin verificar:** «El cliente paga por la entrega rápida», 31 días (umbral: 30).

## Por estado
| propuesto | aceptado | en construcción | entregado | descartado |
|---|---|---|---|---|
| 2 | 13 | 0 | 0 | 0 |

Siguiente paso: `/product-trace` para los 13 decididos sin proyecto, una vez haya fichas de proyectos.
