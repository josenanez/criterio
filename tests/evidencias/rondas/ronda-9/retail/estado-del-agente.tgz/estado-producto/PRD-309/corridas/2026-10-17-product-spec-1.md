# Corrida del 2026-10-17 · product-spec

PRD-309 · 15 requerimientos · 47 s · 36 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 13 |
| `requirement_untraced` | 13 |
| `requirement_without_acceptance` | 4 |
| `requirement_accepted_without_evidence` | 2 |
| `requirement_undecided` | 2 |
| `assumption_unverified` | 1 |
| `claim_vs_metric` | 1 |

Borrador esqueleto: 13 aceptados cubiertos solo por número, 0 secciones de comportamiento porque ningún requerimiento dice qué pide. Dijo que no sabe: qué pide cada REQ, quién decidió, jurisdicción/tipo de tarjeta (no hizo barrido normativo), y qué equipos intervienen.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

**Borrador. Lo cierra Ricardo Salas (gerente de producto); lo aprueba el Comité de producto. Este agente no aprueba ni decide alcance.**

# Especificación — Tarjeta de la tienda (PRD-309) · borrador del 2026-10-17

**Lo principal, antes de la tabla:** con lo que hay en el registro no se puede escribir ninguna sección de comportamiento. Ninguno de los 13 requerimientos aceptados dice qué pide: el acta del comité (2026-10-11) los nombra solo con su número, y el campo «necesidad» está sin encontrar en los 15. Inventar un comportamiento razonable para una tarjeta de la tienda sería decidir por el comité. Lo que sigue es, entonces, el esqueleto con todos los huecos a la vista.

## Alcance

### Entra
Los 13 requerimientos en estado `aceptado`, **solo por número y sin descripción** (acta 2026-10-11): REQ-2035, REQ-4900, REQ-4901, REQ-4902, REQ-4903, REQ-4904, REQ-4906, REQ-4907, REQ-4909, REQ-4910, REQ-4911, REQ-4912, REQ-4913.

Contexto que sí está escrito: el problema («El segmento Hogares no tiene tarjeta de la tienda», definición 2026-02-23) y el segmento (Hogares). La propuesta de la definición es solo el rótulo «Propuesta principal»; no la describe.

### No entra
- **REQ-4905** (Natalia Ospina, propuesto, 2026-05-09) y **REQ-4908** (Gustavo Neira, propuesto, 2026-04-21): nadie los ha decidido. Especificarlos sería escribir el documento dos veces.
- Todo lo que no esté en el registro: cualquier función, canal, límite de crédito, plazo, tasa o condición de la tarjeta. Ningún documento los dice.
- Diseño, estimación, costo y fecha: no son de este comando.

## Criterios de aceptación

| Criterio | Requerimiento | Cómo se verifica | ¿Se puede medir hoy? |
|---|---|---|---|
| «se verifica en producción» (acta 2026-10-11) | REQ-2035, 4900, 4902, 4903, 4904, 4906, 4910, 4911, 4912 | No es un criterio: dice dónde se mira, no qué se mira. Dos personas no llegarían a la misma respuesta. | **No verificable.** Falta el umbral y la métrica. |
| *(ninguno)* | REQ-4901, 4907, 4909, 4913 | — | **Sin criterio de aceptación.** |

No propongo criterios en su lugar: sin saber qué pide cada requerimiento, cualquier cifra sería mía.

Única métrica medida en la bodega: `volumen_mensual` = 214.637 (corte 2026-10-09, tablero de métricas). Ningún requerimiento la cita como criterio, así que no la uso para verificar ninguno.

## Supuestos sobre los que está escrita

| Supuesto | Verificado | Quién lo verificaría |
|---|---|---|
| «El cliente paga por la entrega rápida» (declarado 2026-09-16, definición) | No. Lleva 31 días sin verificar; el umbral configurado es 30. Además, la definición está fechada 2026-02-23 y el supuesto dice 2026-09-16: no sé cuándo se escribió realmente. Y no se ve cómo se relaciona con una tarjeta de la tienda. | Sin dueño en el documento. Propongo a Ricardo Salas (gerente) como quien debe asignarlo. |
| Hay un cliente que pidió cada requerimiento (el acta lo afirma) | No. La única evidencia es una cita de la entrevista del 2025-10-12 («Lo necesito y hoy no lo tengo»), que no nombra ningún requerimiento. Tiene 12 meses de antigüedad, justo en el umbral de 12. | Ricardo Salas (hizo las entrevistas). |
| `volumen_mensual` de 278.242 (caso de negocio, 2026-02-23) | Contradicho: lo medido es 214.637, una brecha de 22,9 % (umbral configurado: 20 %). | Quien firmó el caso de negocio; no consta en el documento. |

## Vacíos

| Qué falta decidir | Consecuencia de no decidirlo | Quién lo cierra |
|---|---|---|
| Qué pide cada requerimiento (los 13 solo tienen número) | No hay nada que especificar ni construir; hoy la especificación es un esqueleto. | Cada dueño, según el registro: Óscar Ramírez (4900), Paula Céspedes (4901), Liliana Torres (4902, 4903, 4909), Jorge Medina (4904), Beatriz Cuéllar (4906, 2035), Ricardo Salas (4907), Javier Hoyos (4910), Rubén Cárdenas (4911), Mauricio Pérez (4912), Felipe Arango (4913) |
| Criterio de aceptación para 4901, 4907, 4909, 4913 | No se pueden aceptar entregables contra nada. | Sus dueños (arriba) |
| Criterio verificable en lugar de «se verifica en producción» para los otros 9 | Cualquier entrega se puede declarar cumplida. | Sus dueños (arriba) |
| Casos borde: ninguno está definido para ningún requerimiento | No se puede saber qué pasa con rechazo de solicitud, mora, devolución, cliente fuera del segmento Hogares, etc. (ejemplos míos, el registro no los menciona). | Sus dueños; el Comité de producto para los transversales |
| Criterio de éxito del producto: no existe en la definición ni en el caso de negocio. «Retorno esperado en 24 meses» no tiene cifra. | No hay con qué juzgar si lo construido sirvió. Bloquea `/product-charter`. | Ricardo Salas, con el Comité de producto |
| Quién aceptó cada requerimiento: el acta da la fecha pero no la persona (los 13) | Decisiones sin firma; no se puede rastrear quién respondería por ellas. | Comité de producto (autoridad sugerida en el setup, **no sale de ningún documento**) |
| Proyecto o equipo que lo construye: «Ninguno declarado» | Los 13 aceptados no tienen quién los construya ni entregable. Lo que otro equipo tenga que hacer (riesgo, pagos, sistemas) tampoco está acordado con nadie; el registro no menciona ningún equipo. | Ricardo Salas |
| Obligaciones normativas: una tarjeta de la tienda toca datos personales y, según sea de crédito o cerrada, consumidor financiero. Ningún documento dice el país, el tipo de tarjeta ni quién la emite. No hice el barrido normativo: sin jurisdicción y tipo, tendría que suponerlos. | Riesgo de construir algo que no se puede lanzar. | Sin dueño identificado. Propongo que el Comité de producto nombre a Legal/Cumplimiento. |

## Requerimientos aceptados que esta especificación no cubre

Los 13 entran al alcance por número, pero **ninguno queda cubierto por una sección de comportamiento**.

| REQ | Título | Por qué no |
|---|---|---|
| REQ-2035 | (solo número) | No dice qué pide; criterio no verificable; sin decisor |
| REQ-4900 | (solo número) | Ídem |
| REQ-4901 | (solo número) | No dice qué pide; sin criterio; sin evidencia de demanda; sin decisor |
| REQ-4902 | (solo número) | No dice qué pide; criterio no verificable; sin decisor |
| REQ-4903 | (solo número) | Ídem |
| REQ-4904 | (solo número) | Ídem |
| REQ-4906 | (solo número) | Ídem |
| REQ-4907 | (solo número) | No dice qué pide; sin criterio; sin decisor |
| REQ-4909 | (solo número) | Ídem |
| REQ-4910 | (solo número) | No dice qué pide; criterio no verificable; sin decisor |
| REQ-4911 | (solo número) | Ídem |
| REQ-4912 | (solo número) | Ídem, y además **sin ninguna evidencia de demanda** |
| REQ-4913 | (solo número) | No dice qué pide; sin criterio; sin decisor |

Además, REQ-4901 y REQ-4912 no tienen evidencia de demanda; los otros 11 apoyan su demanda en la misma cita genérica, que no nombra ningún requerimiento.

---
**Pie.** Sale del registro de requerimientos de PRD-309 (15 requerimientos: 13 aceptados, 2 propuestos), con el acta del comité del 2026-10-11 como fuente de todos, y la definición y el caso de negocio del 2026-02-23. Registro actualizado el 2026-10-17. Cubre 13 requerimientos por número, 0 con contenido. Es un borrador de trabajo: la verificación de cada cita es de quien lo cierre. Términos aceptados por José Francisco Ñáñez el 2026-10-17: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.4.0

**Después:** no corresponde ofrecer `/product-charter`: los vacíos no están cerrados y el producto no tiene criterio de éxito.
