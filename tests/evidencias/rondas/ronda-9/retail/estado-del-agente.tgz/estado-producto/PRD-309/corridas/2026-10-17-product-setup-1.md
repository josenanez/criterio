# Corrida del 2026-10-17 · product-setup

PRD-309 · 15 requerimientos · 28 s · 36 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 13 |
| `requirement_untraced` | 13 |
| `requirement_without_acceptance` | 4 |
| `requirement_accepted_without_evidence` | 2 |
| `requirement_undecided` | 2 |
| `assumption_unverified` | 1 |
| `claim_vs_metric` | 1 |

0 preguntas a una persona (4 contestadas con la respuesta sugerida, sesión sin interfaz); 1 sola entrevista de hace 12 meses; 15 requerimientos, 13 con evidencia envejecida y 0 con proyecto; volumen declarado 22,9 % por encima de lo medido

Primera corrida: no hay una anterior contra la cual comparar.

## Lo que produjo

## Listo — Tarjeta de la tienda (PRD-309)

**Lo que miré:** 6 documentos · 1 de descubrimiento (una sola ronda de entrevistas, 2025-10-12) · la definición del 2026-02-23 · lo más reciente es el acta del comité de producto del 2026-10-11. Todos los formatos se pudieron leer. No hay transcripciones: solo la frase de una entrevista.
**Términos:** aceptados por José Francisco Ñáñez para la versión 0.4.0 (términos 1.1), 2026-10-17 · comprobante en `.criterio/terminos/aceptacion-criterio-product-0.4.0-2026-10-17.md` y `.pdf` · SHA-256 38ea1d146bbd84f3…
**Configuración:** `.criterio/producto/PRD-309/config.json` · estado en `estado-producto/PRD-309` · decide: Comité de producto (respuesta sugerida; ningún documento lo nombra).

### Lo que tu definición afirma, y qué lo sostiene
| Afirmación | Sostenida por | De cuándo |
|---|---|---|
| «El segmento Hogares no tiene tarjeta de la tienda» | Una entrevista a «cliente entrevistado»: «Lo necesito y hoy no lo tengo.» No dice quién es, no nombra Hogares ni la tarjeta. Sostiene poco | 2025-10-12 (12 meses) |
| volumen_mensual = 278.242 | Solo el caso de negocio, que no dice cómo se calculó. El tablero mide 214.637 al corte 2026-10-09: el caso está 22,9 % por encima de lo medido | caso 2026-02-23; medición 2026-10-09 |
| «El cliente paga por la entrega rápida» | Un supuesto, sin verificar desde hace 31 días | declarado 2026-09-16 |
| «Retorno esperado en 24 meses» | Nada: no hay cifra | 2026-02-23 |

### Lo que no está dicho en ninguna parte
- **La propuesta.** La definición dice «Propuesta principal» y nada más.
- **El criterio de éxito.** Ni la definición ni el caso de negocio lo escriben.
- **Cuánto es el retorno esperado.** Hay un plazo (24 meses), no una cifra.
- **Cómo se calculó el volumen mensual** de 278.242, y qué cuenta el tablero como volumen (no tiene definición).
- **Cuántos hogares son el segmento**, y qué evidencia hay de que lo quieran.
- **Qué relación tiene la entrega rápida con una tarjeta de la tienda.** El supuesto no aparece en el problema ni en la propuesta.
- **De dónde salen los 15 requerimientos.** El acta del comité los lista solo con su número, sin descripción.
- **Quién decidió cada aceptación.** El acta solo registra a Ricardo Salas como asistente; la decisión es «Se mantiene el plan».
- **Qué proyecto construye algo de esto.** La definición dice «Ninguno declarado» y los 15 requerimientos no tienen proyecto.

### Supuestos sobre los que está escrita
Uno declarado: «El cliente paga por la entrega rápida», sin verificar, 31 días desde que se declaró. Además está fechado 2026-09-16 dentro de una definición cuya fecha es 2026-02-23; la definición se editó después de esa fecha sin que cambie su encabezado.

### El registro de requerimientos (15 en el acta del 2026-10-11)
13 aceptados y 2 propuestos. Con evidencia de demanda: 11 de 15 (84,6 %). Con proyecto que los ejecute: 0 de 15 (0,0 %).

| Señal | Cuántos | Cuáles |
|---|---|---|
| evidencia envejecida (12 meses, una misma entrevista del 2025-10-12) | 13 | todos los que citan a «cliente entrevistado» |
| aceptado sin proyecto que lo ejecute | 13 | todos los aceptados |
| aceptado sin criterio de aceptación | 4 | REQ-4901, REQ-4907, REQ-4909, REQ-4913 |
| aceptado sin evidencia de demanda | 2 | REQ-4901, REQ-4912 |
| propuesto sin decidir | 2 | REQ-4905 (161 días), REQ-4908 (179 días) |

Otros hallazgos del registro: REQ-4907 lo pidió su propio dueño, Ricardo Salas, citando a un cliente. REQ-2035 sigue otra numeración que los demás (REQ-49xx).
Y los 11 requerimientos con evidencia citan **la misma** entrevista, de una sola frase genérica. La demanda es una voz, no once.

### Qué le falta a tu carpeta
Como hallazgo, no como requisito:
- Las transcripciones de las entrevistas, con quién habló y de qué producto.
- Una serie de la métrica principal, con fuente y definición: hay un solo punto (2026-10-09).
- Las decisiones del comité de producto con su razón: «Se mantiene el plan» no permite distinguir un requerimiento descartado de uno que nadie miró.
- Un proyecto declarado para este producto.

### Siguiente paso
`/product-discovery` sobre el material de entrevistas, para que los temas se vuelvan requerimientos con la cita de quién los pidió.
