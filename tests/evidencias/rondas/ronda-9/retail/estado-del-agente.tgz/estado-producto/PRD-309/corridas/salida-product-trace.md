## Trazabilidad — Tarjeta de la tienda (PRD-309) · al 2026-10-17
13 decididos · 0 con proyecto · 0 confirmados contra la ficha · 0 entregados

Ninguno de los 13 requerimientos aceptados nombra un proyecto que lo ejecute (`traces.project` vacío en todos). La cadena se rompe en el segundo eslabón: hay decisión, no hay proyecto.

### Decidido y nadie lo está construyendo
Decisión: acta de comité de producto (`documentos/productos/PRD-309/30-decisiones/2026-10-11-comite-producto.docx`). El acta no dice quién decidió cada uno (campo «quién» sin encontrar), así que figura el órgano, no una persona.

| REQ | Título | Decidido el | Por quién |
|---|---|---|---|
| REQ-4912 | (el acta solo da el número) | 2026-03-17 | no consta en el acta (Comité de producto) |
| REQ-4913 | ídem | 2026-03-26 | ídem |
| REQ-4904 | ídem | 2026-04-01 | ídem |
| REQ-4903 | ídem | 2026-04-05 | ídem |
| REQ-4900 | ídem | 2026-04-16 | ídem |
| REQ-4909 | ídem | 2026-04-20 | ídem |
| REQ-4901 | ídem | 2026-05-10 | ídem |
| REQ-4910 | ídem | 2026-05-10 | ídem |
| REQ-4906 | ídem | 2026-07-08 | ídem |
| REQ-4902 | ídem | 2026-07-09 | ídem |
| REQ-4911 | ídem | 2026-08-13 | ídem |
| REQ-4907 | ídem | 2026-09-02 | ídem |
| REQ-2035 | ídem | 2026-09-27 | ídem |

El más viejo lleva 214 días decidido sin proyecto (REQ-4912). Los dos requerimientos en estado «propuesto» (REQ-4905, REQ-4908) no están decididos y no entran aquí.

### La traza no se confirma
Nada que confirmar: ningún requerimiento declara proyecto, así que no hay ficha contra la cual contrastar. No hay desacuerdo registro/ficha.

### Lo que un proyecto construye y el registro no tiene
Ninguna ficha dice que ejecute PRD-309. La única ficha publicada (PRY-203, Reposición automática) tiene el campo producto vacío («no encontrado» en el acta de constitución de 2025-07-06). Eso es un hallazgo del lado de PRY-203, no de este registro; no se corrige desde aquí.

### La cadena completa
| REQ | Estado | Decisión | Proyecto | Confirmado | Entregables |
|---|---|---|---|---|---|
| REQ-2035 | aceptado | 2026-09-27 | — | — | — |
| REQ-4900 | aceptado | 2026-04-16 | — | — | — |
| REQ-4901 | aceptado | 2026-05-10 | — | — | — |
| REQ-4902 | aceptado | 2026-07-09 | — | — | — |
| REQ-4903 | aceptado | 2026-04-05 | — | — | — |
| REQ-4904 | aceptado | 2026-04-01 | — | — | — |
| REQ-4905 | propuesto | sin decidir (161 días) | — | — | — |
| REQ-4906 | aceptado | 2026-07-08 | — | — | — |
| REQ-4907 | aceptado | 2026-09-02 | — | — | — |
| REQ-4908 | propuesto | sin decidir (179 días) | — | — | — |
| REQ-4909 | aceptado | 2026-04-20 | — | — | — |
| REQ-4910 | aceptado | 2026-05-10 | — | — | — |
| REQ-4911 | aceptado | 2026-08-13 | — | — | — |
| REQ-4912 | aceptado | 2026-03-17 | — | — | — |
| REQ-4913 | aceptado | 2026-03-26 | — | — | — |

### Sin fichas a la vista
Solo hay una ficha en la carpeta de proyectos (PRY-203). Las demás carpetas (PRY-199 a PRY-211) no tienen ficha publicada, de modo que ninguna traza se podría haber confirmado aunque existiera; que no haya ficha no prueba que el proyecto no exista.
