## Definición — Tarjeta de la tienda (PRD-309) · contrastada al 2026-10-17
**Documento:** `00-definicion/2026-02-23-definicion-producto.md` y `2026-02-23-caso-de-negocio.md` · **del** 2026-02-23 · 4 afirmaciones (el problema, el segmento, el volumen mensual de 278.242 y el retorno a 24 meses) y 1 supuesto declarado. La propuesta es solo el rótulo «Propuesta principal».
**Términos:** vigentes (v1.1), aceptados por José Francisco Ñáñez el 2026-10-17; no hizo falta registrarlos de nuevo.

### Lo que la evidencia contradice
Nada que dos documentos digan en sentidos opuestos. Lo único que se separa es una diferencia de cifras, en la sección siguiente.

### El negocio y los datos
| Métrica | Declarado | Medido | Diferencia | Las dos fuentes y fechas |
|---|---|---|---|---|
| volumen_mensual | 278.242 | 214.637 | 22,9 % (declarado por encima; umbral 20 %) | Caso de negocio, 2026-02-23 · bodega de datos, tablero de producto (`20-metricas/2026-10-09-tablero-metricas.md`), corte 2026-10-09 |

Hay un solo punto medido. El tablero no define qué cuenta como volumen y el caso no dice cómo se calculó 278.242. Por eso no se sabe si las dos cifras cuentan lo mismo.

### Afirmaciones numéricas que nadie mide
| Afirma | De qué documento | No hay serie |
|---|---|---|
| Retorno esperado en 24 meses | Caso de negocio, 2026-02-23 | No trae cifra, así que no hay nada que medir |

### No está dicho en ninguna parte
- **La propuesta.** La definición dice «Propuesta principal» y nada más.
- **El criterio de éxito.** Ni la definición ni el caso de negocio lo escriben.
- **La cifra del retorno.** Hay un plazo de 24 meses, no un monto.
- **Cómo se calculó el volumen mensual** y qué cuenta el tablero como volumen.
- **Cuántos hogares son el segmento Hogares**, y qué evidencia hay de que quieran la tarjeta.
- **Qué relación tiene la entrega rápida con una tarjeta de la tienda.** El supuesto no aparece ni en el problema ni en la propuesta.
- **Quién decide.** Ningún documento lo nombra. El acta del comité (2026-10-11) solo lista a Ricardo Salas como asistente, y «Comité de producto» es la respuesta sugerida en la configuración.
- **Qué proyecto construye esto.** La definición dice «Ninguno declarado» y los 15 requerimientos no tienen proyecto.
- **País y qué datos o dinero mueve la tarjeta.** Es un producto financiero por su nombre, pero la definición no describe nada de eso.

### Sostenida por un supuesto
| Supuesto | Días sin verificar | Qué haría falta para verificarlo |
|---|---|---|
| El cliente paga por la entrega rápida | 31 (declarado el 2026-09-16; umbral 30) | Un hecho observable: por ejemplo, cuántos clientes de Hogares pagaron por entrega rápida en un período, o una prueba con cobro real. Hoy no hay serie ni experimento, y el supuesto no dice cuánto, quién ni frente a qué alternativa. |

El supuesto tiene fecha 2026-09-16 dentro de una definición fechada 2026-02-23. El documento se editó después sin cambiar su encabezado.

### Sostenida por evidencia
| Afirmación | Sostenida por | De cuándo | Qué tan fuerte |
|---|---|---|---|
| «El segmento Hogares no tiene tarjeta de la tienda» | Una entrevista a «cliente entrevistado»: «Lo necesito y hoy no lo tengo.» | 2025-10-12 | Débil. Es una voz que dijo que usaría algo. No dice quién es, no nombra a Hogares ni la tarjeta, y no hay pago ni compromiso. |

### Evidencia que ya envejeció
| Afirmación | Lo más nuevo que la sostiene | Hace |
|---|---|---|
| El problema de Hogares | La entrevista del 2025-10-12 | 12 meses (umbral 12) |
| 13 de los 15 requerimientos | Esa misma entrevista | 12 meses. Es una voz, no trece. |

### Lo normativo que toca
La definición no declara país. Esto es un barrido para la revisión jurídica, no la reemplaza ni dice si el producto cumple.

| Qué toca | País | Obligación | Norma | Estado |
|---|---|---|---|---|
| Una tarjeta es un medio de pago, y probablemente crédito | no declarado | Quién puede emitirla y con qué autorización | — | no tengo la norma a la vista |
| Atención al consumidor financiero: información previa, cobros, reclamos | no declarado | Obligaciones de quien atiende consumidor financiero | — | no tengo la norma a la vista |
| Datos personales del solicitante, y probablemente su historial crediticio | no declarado | Autorización previa y finalidad declarada | — | no tengo la norma a la vista |
| Dónde se guardan esos datos y si salen del país | no declarado | Transferencia internacional | — | no tengo la norma a la vista |
| Conservar la trazabilidad y los registros de las operaciones | no declarado | Retención | — | no tengo la norma a la vista |

No cito ninguna norma porque ninguna a la vista corresponde a un país declarado. Una cita inventada sería peor que el vacío. La definición no dice qué recoge ni qué cobra: las filas salen del nombre del producto, no de su texto.

### Lo que falta para cerrar la definición
- **Problema:** está, en una línea.
- **Para quién:** está, «Hogares», sin tamaño.
- **Criterio de éxito:** no está. Sin él el producto no se puede cerrar, porque el cierre se juzga contra él meses después.
- **Quién decide:** no está escrito en ningún documento.
- Falta además la propuesta, la cifra del retorno y el país.

### Después
El supuesto de la entrega rápida cruzó los 30 días. Se puede convertir en riesgo con doliente (raid-taxonomy). La definición no está cerrada, así que no corresponde `/product-charter`.
