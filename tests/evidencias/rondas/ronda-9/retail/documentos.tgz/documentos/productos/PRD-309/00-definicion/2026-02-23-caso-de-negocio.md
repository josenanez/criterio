# Caso de negocio · Tarjeta de la tienda

**Código:** PRD-309
**Fecha:** 2026-02-23
**Preparado por:** Ricardo Salas

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 278.242 | Caso de negocio, 2026-02-23 |

## Retorno esperado

Retorno esperado en 24 meses.
