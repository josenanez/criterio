# Tablero de métricas · App de clientes

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-09-30

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 90.114 | 2026-09-30 |
