# Definición de producto · Tarjeta de la tienda

**Código:** PRD-309
**Gerente de producto:** Ricardo Salas
**Segmento:** Hogares
**Fecha de la definición:** 2026-02-23

## El problema

El segmento Hogares no tiene tarjeta de la tienda.

## La propuesta

- Propuesta principal

## Supuestos

- **El cliente paga por la entrega rápida** · declarado el 2026-09-16 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
