# Caso de negocio · Autopago en tienda

**Código:** PRD-302
**Fecha:** 2026-04-15
**Preparado por:** Camilo Beltrán

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 203.411 | Caso de negocio, 2026-04-15 |

## Retorno esperado

Retorno esperado en 24 meses.
