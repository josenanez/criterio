# Comité de producto · Autopago en tienda

**Fecha:** 2026-10-12
**Asistentes:** Camilo Beltrán

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4200 | Requerimiento REQ-4200 | Carlos Peña | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-27 | — |
| REQ-4201 | Requerimiento REQ-4201 | Óscar Ramírez | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-29 | — |
| REQ-4202 | Requerimiento REQ-4202 | Natalia Ospina | — | Cliente entrevistado | aceptado | 2026-06-09 | — |
| REQ-4203 | Requerimiento REQ-4203 | Carlos Peña | — | Cliente entrevistado | aceptado | 2026-06-22 | — |
| REQ-4204 | Requerimiento REQ-4204 | Elena Duarte | se verifica en producción | — | aceptado | 2026-05-27 | — |
| REQ-4205 | Requerimiento REQ-4205 | Jorge Medina | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-27 | — |
| REQ-4206 | Requerimiento REQ-4206 | Jorge Medina | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-28 | — |
| REQ-4207 | Requerimiento REQ-4207 | Laura Vélez | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-01 | — |
| REQ-4208 | Requerimiento REQ-4208 | Felipe Arango | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-21 | — |
| REQ-4209 | Requerimiento REQ-4209 | Ricardo Salas | se verifica en producción | — | aceptado | 2026-04-05 | — |
| REQ-4210 | Requerimiento REQ-4210 | sin asignar | — | — | aceptado | 2026-04-13 | — |
| REQ-4211 | Requerimiento REQ-4211 | Gustavo Neira | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-17 | — |
| REQ-4212 | Requerimiento REQ-4212 | Andrés Lozano | se verifica en producción | — | aceptado | 2026-08-18 | — |
| REQ-4213 | Requerimiento REQ-4213 | sin asignar | se verifica en producción | — | propuesto | 2026-04-09 | — |
| REQ-2028 | Requerimiento REQ-2028 | Diana Molina | se verifica en producción | Cliente entrevistado | aceptado | 2026-09-20 | — |
| REQ-2036 | Requerimiento REQ-2036 | Paula Céspedes | se verifica en producción | Cliente entrevistado | aceptado | 2026-10-02 | — |

## Decisiones

- Se mantiene el plan
