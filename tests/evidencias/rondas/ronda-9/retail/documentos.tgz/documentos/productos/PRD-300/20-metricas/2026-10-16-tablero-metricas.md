# Tablero de métricas · Venta en línea

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-16

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 264.767 | 2026-10-16 |
