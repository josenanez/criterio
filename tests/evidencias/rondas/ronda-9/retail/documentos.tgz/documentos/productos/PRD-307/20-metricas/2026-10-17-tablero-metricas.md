# Tablero de métricas · Compra y recoge

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-17

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 117.411 | 2026-10-17 |
