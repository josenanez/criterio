# Comité de producto · Marketplace

**Fecha:** 2026-10-08
**Asistentes:** Javier Hoyos

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4800 | Requerimiento REQ-4800 | Carlos Peña | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-18 | — |
| REQ-4801 | Requerimiento REQ-4801 | Gustavo Neira | — | Cliente entrevistado | aceptado | 2026-04-19 | — |
| REQ-4802 | Requerimiento REQ-4802 | Carlos Peña | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-30 | — |
| REQ-4803 | Requerimiento REQ-4803 | Beatriz Cuéllar | se verifica en producción | Cliente entrevistado | propuesto | 2026-05-27 | — |
| REQ-4804 | Requerimiento REQ-4804 | María Restrepo | — | Cliente entrevistado | aceptado | 2026-04-01 | — |
| REQ-4805 | Requerimiento REQ-4805 | María Restrepo | se verifica en producción | — | aceptado | 2026-07-19 | — |
| REQ-4806 | Requerimiento REQ-4806 | Elena Duarte | se verifica en producción | — | aceptado | 2026-04-18 | — |
| REQ-4807 | Requerimiento REQ-4807 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-27 | — |
| REQ-4808 | Requerimiento REQ-4808 | Diana Molina | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-28 | — |
| REQ-4809 | Requerimiento REQ-4809 | sin asignar | se verifica en producción | Cliente entrevistado | propuesto | 2026-04-17 | — |
| REQ-4810 | Requerimiento REQ-4810 | Gustavo Neira | — | Cliente entrevistado | propuesto | 2026-06-01 | — |
| REQ-4811 | Requerimiento REQ-4811 | Andrés Lozano | se verifica en producción | Cliente entrevistado | propuesto | 2026-05-10 | — |
| REQ-4812 | Requerimiento REQ-4812 | Liliana Torres | se verifica en producción | — | aceptado | 2026-08-28 | — |
| REQ-4813 | Requerimiento REQ-4813 | Óscar Ramírez | se verifica en producción | Cliente entrevistado | propuesto | 2026-04-04 | — |

## Decisiones

- Se mantiene el plan
