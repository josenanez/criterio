# Caso de negocio · App de clientes

**Código:** PRD-306
**Fecha:** 2025-12-03
**Preparado por:** Beatriz Cuéllar

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 91.205 | Caso de negocio, 2025-12-03 |

## Retorno esperado

Retorno esperado en 24 meses.
