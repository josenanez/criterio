# Caso de negocio · Compra y recoge

**Código:** PRD-307
**Fecha:** 2026-04-24
**Preparado por:** Andrés Lozano

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 140.571 | Caso de negocio, 2026-04-24 |

## Retorno esperado

Retorno esperado en 24 meses.
