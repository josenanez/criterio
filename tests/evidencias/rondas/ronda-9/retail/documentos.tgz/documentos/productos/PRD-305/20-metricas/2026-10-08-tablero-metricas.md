# Tablero de métricas · Entrega rápida

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-08

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 181.305 | 2026-10-08 |
