# Caso de negocio · Puntos de fidelización

**Código:** PRD-301
**Fecha:** 2026-02-24
**Preparado por:** Sandra Gil

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 161.363 | Caso de negocio, 2026-02-24 |

## Retorno esperado

Retorno esperado en 24 meses.
