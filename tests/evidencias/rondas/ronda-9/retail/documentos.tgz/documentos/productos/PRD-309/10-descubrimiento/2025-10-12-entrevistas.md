# Entrevistas · Tarjeta de la tienda

**Ronda:** Ronda · 2025-10-12
**Realizadas por:** Ricardo Salas

### Cliente entrevistado · 2025-10-12

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
