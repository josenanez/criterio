# Tablero de métricas · Pago con QR

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-09

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 161.727 | 2026-10-09 |
