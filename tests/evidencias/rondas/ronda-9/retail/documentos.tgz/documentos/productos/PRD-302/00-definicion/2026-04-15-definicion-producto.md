# Definición de producto · Autopago en tienda

**Código:** PRD-302
**Gerente de producto:** Camilo Beltrán
**Segmento:** Hogares
**Fecha de la definición:** 2026-04-15

## El problema

El segmento Hogares no tiene autopago en tienda.

## La propuesta

- Propuesta principal

## Supuestos

- **El cliente paga por la entrega rápida** · declarado el 2026-05-15 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
