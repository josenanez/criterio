# Definición de producto · Venta en línea

**Código:** PRD-300
**Gerente de producto:** Diana Molina
**Segmento:** Empresas
**Fecha de la definición:** 2026-04-25

## El problema

El segmento Empresas no tiene venta en línea.

## La propuesta

- Propuesta principal

## Supuestos

- **La regulación de datos lo permite** · declarado el 2026-06-13 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
