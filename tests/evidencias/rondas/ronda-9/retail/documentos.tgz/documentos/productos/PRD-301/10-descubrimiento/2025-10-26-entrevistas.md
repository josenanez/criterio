# Entrevistas · Puntos de fidelización

**Ronda:** Ronda · 2025-10-26
**Realizadas por:** Sandra Gil

### Cliente entrevistado · 2025-10-26

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
