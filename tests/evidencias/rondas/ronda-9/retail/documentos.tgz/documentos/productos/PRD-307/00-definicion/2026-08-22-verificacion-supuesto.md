# Verificación del supuesto · Compra y recoge

**Fecha:** 2026-08-22

**Supuesto:** La demanda se sostiene sin descuento

**Con qué se verificó:** la medición del piloto del 2026-08-22

**Resultado:** se confirmó.
