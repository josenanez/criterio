# Tablero de métricas · Tarjeta de la tienda

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-09

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 214.637 | 2026-10-09 |
