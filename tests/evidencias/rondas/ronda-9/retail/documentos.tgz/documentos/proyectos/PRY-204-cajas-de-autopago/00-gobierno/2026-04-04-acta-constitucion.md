# Acta de constitución · Cajas de autopago

**Código:** PRY-204
**Área dueña:** Talento humano
**Patrocinador:** María Restrepo
**Gerente de proyecto:** Laura Vélez
**Comité:** Comité Comercial
**Producto asociado:** autopago en tienda
**Fecha de aprobación:** 2026-04-04

## Objetivo del negocio

Entregar cajas de autopago para Talento humano.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**3.300.000.000 COP**, aprobado por Comité Comercial el 2026-04-04.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-04-14 |
| Cierre | 2026-10-31 |

## Criterio de éxito

Cajas de autopago en producción y medido.

## Dependencias declaradas

- Ninguna declarada
