# Informe de avance · Domicilios en dos horas

**Código:** PRY-208
**Fecha de corte:** 2026-10-17
**Gerente:** Beatriz Cuéllar

## Estado declarado

**Rojo**

Avance reportado: **54%**

## Lo que pasó en el periodo

- La prueba de carga de temporada no alcanzó el umbral pactado y se repite

## Presupuesto

| | COP |
|---|---|
| Aprobado | 9.500.000.000 |
| Comprometido | 7.189.838.255 |
| Ejecutado | 3.991.991.824 |
| Proyección al cierre | 8.919.574.709 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
