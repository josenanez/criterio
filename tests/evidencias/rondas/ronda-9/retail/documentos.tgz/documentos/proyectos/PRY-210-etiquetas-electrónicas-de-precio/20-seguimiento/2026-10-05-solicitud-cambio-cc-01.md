# Solicitud de cambio CC-01

**Proyecto:** PRY-210 · Etiquetas electrónicas de precio
**Fecha:** 2026-10-05
**Solicitante:** Natalia Ospina

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +106 días sobre la línea base vigente |
| Costo | 212.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
