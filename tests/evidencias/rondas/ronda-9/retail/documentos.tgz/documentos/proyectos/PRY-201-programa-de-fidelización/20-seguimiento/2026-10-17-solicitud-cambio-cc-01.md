# Solicitud de cambio CC-01

**Proyecto:** PRY-201 · Programa de fidelización
**Fecha:** 2026-10-17
**Solicitante:** Andrés Lozano

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +24 días sobre la línea base vigente |
| Costo | 48.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
