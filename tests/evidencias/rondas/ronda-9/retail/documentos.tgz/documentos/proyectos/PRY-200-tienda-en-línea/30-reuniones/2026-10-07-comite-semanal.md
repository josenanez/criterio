# Comité Comercial · Tienda en línea

**Fecha:** 2026-10-07
**Asistentes:** Sandra Gil, Carlos Peña

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Beatriz Cuéllar | Entregar el punto 17 | 2026-10-08 |
