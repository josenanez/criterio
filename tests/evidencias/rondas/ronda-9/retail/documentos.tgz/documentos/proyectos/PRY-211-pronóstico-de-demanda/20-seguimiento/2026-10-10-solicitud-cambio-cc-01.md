# Solicitud de cambio CC-01

**Proyecto:** PRY-211 · Pronóstico de demanda
**Fecha:** 2026-10-10
**Solicitante:** Camilo Beltrán

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +118 días sobre la línea base vigente |
| Costo | 236.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
