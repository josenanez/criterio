# Informe de avance · Tienda en línea

**Código:** PRY-200
**Fecha de corte:** 2026-10-09
**Gerente:** Sandra Gil

## Estado declarado

**Verde**

Avance reportado: **57%**

## Lo que pasó en el periodo

- Se ajustó el plan de pruebas con el área de seguridad
- Se reprogramó el despliegue por el congelamiento de temporada de fin de año
- Se levantó un hallazgo de seguridad en los medios de pago

## Presupuesto

| | COP |
|---|---|
| Aprobado | 6.800.000.000 |
| Comprometido | 4.942.981.659 |
| Ejecutado | 3.696.476.343 |
| Proyección al cierre | 6.859.551.454 |

## Riesgos abiertos

- Cambio en la regulación de datos personales que puede mover el alcance
