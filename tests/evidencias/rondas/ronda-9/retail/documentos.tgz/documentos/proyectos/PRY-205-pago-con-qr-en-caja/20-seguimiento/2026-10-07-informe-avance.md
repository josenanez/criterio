# Informe de avance · Pago con QR en caja

**Código:** PRY-205
**Fecha de corte:** 2026-10-07
**Gerente:** Mauricio Pérez

## Estado declarado

**Verde**

Avance reportado: **43%**

## Lo que pasó en el periodo

- La validación con dos tiendas se extendió una semana por el conteo de inventario
- Se recibió el concepto de Jurídica sobre los términos de uso
- Se ajustó el plan de pruebas con el área de seguridad

## Presupuesto

| | COP |
|---|---|
| Aprobado | 1.200.000.000 |
| Comprometido | 629.483.864 |
| Ejecutado | 545.529.233 |
| Proyección al cierre | 1.195.999.493 |

## Riesgos abiertos

- Disponibilidad de los jefes de tienda para el piloto
