# Comité Comercial · Cajas de autopago

**Fecha:** 2026-10-15
**Asistentes:** Laura Vélez, María Restrepo

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Beatriz Cuéllar | Entregar el punto 9 | 2026-10-08 |
