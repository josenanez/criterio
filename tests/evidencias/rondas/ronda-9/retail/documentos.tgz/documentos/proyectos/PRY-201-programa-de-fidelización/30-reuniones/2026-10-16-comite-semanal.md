# Comité de Cadena de Abastecimiento · Programa de fidelización

**Fecha:** 2026-10-16
**Asistentes:** Andrés Lozano, Jorge Medina

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Natalia Ospina | Entregar el punto 16 | 2026-10-01 |
