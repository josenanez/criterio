# Comité de Expansión · Reposición automática

**Fecha:** 2026-09-26
**Asistentes:** Camilo Beltrán, Elena Duarte, Gustavo Neira, Javier Hoyos, Jorge Medina, Laura Vélez, Liliana Torres, María Restrepo, Natalia Ospina

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Natalia Ospina | Enviar el documento 1 | 2026-11-08 |
| Laura Vélez | Cerrar la prueba 2 | 2026-10-29 |
| Natalia Ospina | Revisar el anexo 3 | 2026-10-03 |
| Javier Hoyos | Actualizar la matriz 6 | 2026-09-21 |
| Jorge Medina | Confirmar la fecha 7 | por definir |
| Gustavo Neira | Entregar el punto 8 | 2026-10-11 |
| Elena Duarte | Enviar el documento 9 | 2026-10-10 |
| Laura Vélez | Cerrar la prueba 10 | 2026-10-03 |
| Jorge Medina | Revisar el anexo 11 | 2026-10-17 |
| María Restrepo | Aprobar el diseño 13 | 2026-10-11 |
| Camilo Beltrán | Actualizar la matriz 14 | 2026-10-11 |
| Liliana Torres | Confirmar la fecha 15 | 2026-09-29 |
| Elena Duarte | Entregar el punto 16 | 2026-10-15 |

## Cerrados en esta reunión

- Aprobar el diseño 5 (Jorge Medina): recibido, acta de recibo del 2026-09-26.

## Lo que se dijo

- Gustavo Neira dice que ya entregó «validar el ambiente 12». No se presentó acta.
