# Comité Comercial · Etiquetas electrónicas de precio

**Fecha:** 2026-10-08
**Asistentes:** Natalia Ospina, Carlos Peña

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Gustavo Neira | Entregar el punto 16 | por definir |
