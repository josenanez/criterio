# Comité de Expansión · Reposición automática

**Fecha:** 2026-09-05
**Asistentes:** Carlos Peña, Laura Vélez, Natalia Ospina

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Natalia Ospina | Enviar el documento 1 | 2026-09-28 |
| Laura Vélez | Cerrar la prueba 2 | 2026-09-18 |
| Natalia Ospina | Revisar el anexo 3 | 2026-10-03 |
| Carlos Peña | Validar el ambiente 4 | 2026-09-25 |
