# Acta de constitución · Etiquetas electrónicas de precio

**Código:** PRY-210
**Área dueña:** Finanzas
**Patrocinador:** Carlos Peña
**Gerente de proyecto:** Natalia Ospina
**Comité:** Comité Comercial
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-09-30

## Objetivo del negocio

Entregar etiquetas electrónicas de precio para Finanzas.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**2.400.000.000 COP**, aprobado por Comité Comercial el 2025-09-30.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-10-10 |
| Cierre | 2027-02-23 |

## Criterio de éxito

Etiquetas electrónicas de precio en producción y medido.

## Dependencias declaradas

- Ninguna declarada
