# Solicitud de cambio CC-01

**Proyecto:** PRY-209 · Migración del ERP
**Fecha:** 2026-10-17
**Solicitante:** Javier Hoyos

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +80 días sobre la línea base vigente |
| Costo | 160.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
