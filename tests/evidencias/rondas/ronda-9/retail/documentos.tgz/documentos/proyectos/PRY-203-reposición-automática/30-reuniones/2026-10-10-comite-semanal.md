# Comité de Expansión · Reposición automática

**Fecha:** 2026-10-10
**Asistentes:** Andrés Lozano, Camilo Beltrán, Elena Duarte, Gustavo Neira, Jorge Medina, Laura Vélez, Liliana Torres, María Restrepo, Mauricio Pérez, Natalia Ospina, Ricardo Salas, Rubén Cárdenas, Sandra Gil

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Natalia Ospina | Enviar el documento 1 | 2026-12-04 |
| Laura Vélez | Cerrar la prueba 2 | 2026-11-24 |
| Gustavo Neira | Entregar el punto 8 | 2026-10-22 |
| Laura Vélez | Cerrar la prueba 10 | 2026-10-03 |
| Jorge Medina | Revisar el anexo 11 | 2026-11-20 |
| María Restrepo | Aprobar el diseño 13 | 2026-10-11 |
| Liliana Torres | Confirmar la fecha 15 | 2026-09-29 |
| Elena Duarte | Entregar el punto 16 | 2026-10-15 |
| Ricardo Salas | Enviar el documento 17 | 2026-10-06 |
| Sandra Gil | Cerrar la prueba 18 | 2026-11-04 |
| Rubén Cárdenas | Revisar el anexo 19 | 2026-10-20 |
| Camilo Beltrán | Aprobar el diseño 21 | 2026-11-07 |
| Andrés Lozano | Actualizar la matriz 22 | 2026-10-25 |
| Mauricio Pérez | Confirmar la fecha 23 | 2026-10-19 |
| Rubén Cárdenas | Entregar el punto 24 | 2026-10-19 |

## Cerrados en esta reunión

- Validar el ambiente 20 (Gustavo Neira): recibido, acta de recibo del 2026-10-10.

## Lo que se dijo

- Natalia Ospina dice que ya entregó «revisar el anexo 3». No se presentó acta.
- Jorge Medina dice que ya entregó «confirmar la fecha 7». No se presentó acta.
