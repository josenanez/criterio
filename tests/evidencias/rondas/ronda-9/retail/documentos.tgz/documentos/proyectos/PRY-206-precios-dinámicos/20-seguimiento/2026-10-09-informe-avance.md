# Informe de avance · Precios dinámicos

**Código:** PRY-206
**Fecha de corte:** 2026-10-09
**Gerente:** Gustavo Neira

## Estado declarado

**Verde**

Avance reportado: **61%**

## Lo que pasó en el periodo

- Se acordó con arquitectura cómo se revisan los requisitos no funcionales
- La validación con dos tiendas se extendió una semana por el conteo de inventario

## Presupuesto

| | COP |
|---|---|
| Aprobado | 3.300.000.000 |
| Comprometido | 2.248.068.230 |
| Ejecutado | 1.381.899.405 |
| Proyección al cierre | 3.401.699.097 |

## Riesgos abiertos

- Cambio en la regulación de datos personales que puede mover el alcance
- Disponibilidad de los jefes de tienda para el piloto
