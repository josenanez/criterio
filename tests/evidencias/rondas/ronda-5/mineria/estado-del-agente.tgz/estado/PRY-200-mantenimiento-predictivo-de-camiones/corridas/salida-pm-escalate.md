Términos: ya vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-16); no hubo nada que registrar.

No pasaste tema, así que tomé «lo que ya está marcado como escalable» (la agenda del 2026-10-30 y la ficha). Resultado: **un solo punto escala hoy, y es el primero que manda la regla: la autoridad del gerente no está declarada.**

## Para decisión — PRY-200 Mantenimiento predictivo de camiones · 2026-10-16

### ¿Quién declara por escrito qué puede decidir el gerente de PRY-200: el Comité de Operaciones mediante adenda al acta (A), el patrocinador Andrés Lozano en una carta firmada (B), o se sigue sin autoridad declarada (C)?

**Quién decide:** el acta (2025-06-03) no lo dice. Lo más cercano: el Comité de Operaciones aprobó el presupuesto de 1.200.000.000 COP en esa fecha, y Andrés Lozano figura como patrocinador. Quién tiene la facultad de declarar la autoridad es una lectura mía, no algo que el acta afirme: confírmalo antes de llevarlo.
**Si no se decide hoy:** el comité del **2026-10-30** se reúne sin saber qué puede resolver Ricardo Salas y qué excede su autoridad. La agenda ya tiene dos puntos que dependen de eso: «Enviar el documento 1» (6 reprogramaciones, última al 2026-12-12) y los vencidos de Andrés Lozano («Entregar el punto 8», vencido 2026-10-13). Cada uno se va a decidir sin poder saber si valía.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Adenda al acta por el Comité de Operaciones | Sin cambio en el alcance (Componentes 1, 2 y 3); agrega la autoridad del gerente por tema | Un punto en el comité del 2026-10-30; la adenda queda fechada | Sin costo directo declarado; no hay documento que lo cuantifique |
| B. Carta del patrocinador | Igual; la autoridad queda fuera del acta | Puede salir antes del 10-30 si Lozano responde. Hoy tiene un compromiso vencido sin acta de recibo | Sin costo directo declarado. Riesgo: la carta no pasó por el comité que aprobó el presupuesto |
| C. Seguir sin autoridad declarada | Sin cambio | Sin trámite, pero cada punto que supere al gerente se decide sin saber si es válido | Sin cifra: no hay documento que la dé. El costo es que una decisión se tome y se devuelva |

**Recomiendo:** A. Es el mismo órgano que aprobó el presupuesto, deja la autoridad en el acta y no depende de que responda alguien que hoy tiene un compromiso vencido.

### A quién alcanza
No se calculó con `portafolio.py impact`: el cálculo exige un número de días y este punto no mueve ninguna fecha. No inventé uno. Qué otros proyectos quedan alcanzados no se sabe: el acta declara «Dependencias declaradas: Ninguna declarada» y la ficha tiene `dependencies` vacío. Eso tampoco prueba que no existan.

### Mis hitos por los que pasa
Ninguno por este punto. Aparte, y no es escalamiento: el cierre vigente de la línea base v1 es **2026-09-30** y ya pasó, con avance declarado de 54 % (informe del 2026-10-14) y sin ningún cambio registrado en la ficha (`changes` vacío). Eso es control de cambios (`/criterio-portfolio:change-control`) y la línea base v1 no se toca. Cuando haya una fecha nueva propuesta, ahí sí corre `impact` con los días.

### De dónde sale esto
- Autoridad no declarada: `00-gobierno/2025-06-03-acta-constitucion.docx` (leí el acta completa; trae patrocinador, gerente, comité, presupuesto, fechas y criterio de éxito, y ninguna sección de autoridad). La ficha lo marca en `identity.authority` como `not_found`.
- Comité y presupuesto aprobado: la misma acta.
- Cronograma de «Enviar el documento 1»: `30-reuniones/2026-09-04-comite-semanal.md` a `2026-10-16-notas-reunion.txt`, línea 4.
- Punto 8 de Andrés Lozano: `30-reuniones/2026-09-11-comite-semanal.md` y `2026-10-02-comite-semanal.md` («ya lo entregué», sin acta).
- Fecha del comité: `config.json`, `committee_next` 2026-10-30. Las notas del 10-16 dicen «próxima reunión en dos semanas».
- Avance y cierre: `20-seguimiento/2026-10-14-informe-avance.md`, `10-plan/2025-06-03-cronograma-v1.csv`.

## Lo que no escala todavía (no armé paquete)

| Asunto | Por qué no |
|---|---|
| «Enviar el documento 1» (Elena Duarte, 6 reprogramaciones) | Ningún documento dice qué la frena. Sin el bloqueo nombrado no hay pregunta cerrada. Se nombra en la reunión; si excede lo que la sala puede mover, vuelve aquí. Depende de la autoridad de arriba |
| «Entregar el punto 8» y «Aprobar el diseño 5» (Andrés Lozano, Liliana Torres, vencidos) | Ricardo les pide el acta de recibo antes del 2026-10-29 (agenda, «No es de esta reunión»). Escala solo si el patrocinador no responde. Hoy la llamada se puede hacer sin comité |
| Riesgos del proveedor y las dos incidencias (lluvias, ensayo de disponibilidad) | Sin dueño, probabilidad ni impacto. Es registro, no escalamiento: el gerente los asigna y los valora. Si el proveedor termina afectando la fecha de cierre, entonces sí |
| Presupuesto: proyección 1.175.719.466 frente a 1.200.000.000 aprobados | Dentro del aprobado según el informe. Pero «Mandar el ajuste del presupuesto» (Laura Vélez) no tiene fecha ni contenido; si el ajuste supera el aprobado, es control de cambios y escala |

## Lo que este paquete no sabe
- Quién tiene la facultad real de declarar la autoridad: el acta no lo dice.
- El costo de cada opción en pesos o en días: ningún documento lo da.
- Qué proyectos se tocan: sin dependencias declaradas ni días propuestos, `impact` no tiene qué calcular.
- Qué se dijo el 10-16 más allá de cinco viñetas para 12 asistentes.
- El paquete no escala solo: llevarlo al Comité de Operaciones es de Ricardo Salas.
