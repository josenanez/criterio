# Corrida del 2026-10-16 · pm-commitments

1 proyectos · 53 s · 17 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_overdue` | 6 |
| `milestone_met_without_evidence` | 4 |
| `commitment_rescheduled` | 4 |
| `commitment_undated` | 2 |
| `progress_vs_plan` | 1 |

Reprogramados: Elena Duarte (6), Diana Molina (5), Javier Hoyos (3); 6 vencidos sin evidencia, 3 con 'ya lo entregué' sin acta; 2 sin fecha

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

## Compromisos — PRY-200 Mantenimiento predictivo de camiones · al 2026-10-16

23 compromisos abiertos: 6 vencidos sin evidencia, 2 sin fecha, 3 reprogramados tres veces o más (todas las cifras salen de `compute`).

### Se viene reprogramando

> **Elena Duarte** · Enviar el documento 1 — reprogramado **6 veces**
> Prometido para el 2026-09-19, y antes para el 09-26, 10-17, 11-02, 11-18, 11-28, y hoy para el **2026-12-12**.
> La última fecha es de hoy (notas del 2026-10-16: «no alcanzó, se compromete para el 12/12/2026»). Tres meses de diferencia entre la primera promesa y la vigente.
> **Más de tres veces no es un problema de seguimiento: es un bloqueo que nadie ha nombrado.**

> **Diana Molina** · Cerrar la prueba 2 — reprogramado **5 veces**
> Prometido para el 2026-09-15, y antes para el 09-23, 10-02, 10-13, 10-25, y hoy para el **2026-11-14**.
> Además tiene vencido «Validar el ambiente 20» (ver abajo): dos compromisos de Diana en riesgo a la vez.

> **Javier Hoyos** · Confirmar la fecha 7 — reprogramado **3 veces**
> Prometido para el 2026-09-16, y antes para el 09-26, 10-16, y hoy para el **2026-10-28**.
> Y tiene vencido «Confirmar la fecha 23» (ver abajo): el mismo tipo de compromiso, confirmar fechas, falla dos veces con la misma persona.

(«Revisar el anexo 3», de Óscar Ramírez, también se reprogramó 3 veces, pero está cerrado con acta; ver Cerrados.)

### Vencidos sin evidencia
| Quién | Qué | Prometido para | Hace |
|---|---|---|---|
| Sandra Gil | Validar el ambiente 4 (reprogramado 2 veces; original 09-13) | 2026-10-04 | 12 días |
| Liliana Torres | Aprobar el diseño 5 | 2026-10-04 | 12 días |
| Jorge Medina | Entregar el punto 16 | 2026-10-12 | 4 días |
| Andrés Lozano | Entregar el punto 8 (reprogramado 1 vez) | 2026-10-13 | 3 días |
| Javier Hoyos | Confirmar la fecha 23 | 2026-10-13 | 3 días |
| Diana Molina | Validar el ambiente 20 | 2026-10-15 | 1 día |

Tres de estos tienen una frase en el comité del 2026-10-02 diciendo que ya los entregaron (Liliana Torres, Andrés Lozano, Jorge Medina). **No hay nada en el expediente que lo respalde**: ningún acta de recibo, y dejaron de aparecer en la tabla de la reunión. Siguen abiertos hasta que haya un documento.

### Vencen esta semana
| Quién | Qué | Para cuándo |
|---|---|---|
| Natalia Ospina | Entregar el punto 24 | 2026-10-17 |
| Felipe Arango | Revisar el anexo 19 | 2026-10-18 |
| Elena Duarte | Revisar el anexo 11 (reprogramado 1 vez) | 2026-10-19 |
| Ricardo Salas | Aprobar el diseño 21 | 2026-10-23 |

Ricardo Salas es el gerente del proyecto: este compromiso es suyo.

### Sin fecha
| Quién | Qué | Dicho el |
|---|---|---|
| Gustavo Neira | Cerrar la prueba 18 («por definir» en dos reuniones seguidas) | 2026-10-02 |
| Laura Vélez | Mandar el ajuste del presupuesto («la otra semana»; nadie dijo fecha) | 2026-10-16 |

No pueden estar vencidos; se cuentan aparte para que no desaparezcan.

### Cerrados desde la última revisión
| Quién | Qué | Documento que lo cierra |
|---|---|---|
| Óscar Ramírez | Revisar el anexo 3 | `20-seguimiento/2026-10-09-acta-recibo-3.md` |
| Ricardo Salas | Actualizar la matriz 6 | `20-seguimiento/2026-10-09-acta-recibo-6.md` |
| Beatriz Cuéllar | Validar el ambiente 12 | `20-seguimiento/2026-10-02-acta-recibo-12.md` |

Nota: «Revisión con el proveedor» (Óscar Ramírez, 2026-10-26) se registró aparte del anexo 3; las notas no los relacionan.

### Después
- **Elena Duarte (6) y Diana Molina (5) justifican formularse como decisión para el comité**, con Javier Hoyos (3) si se quiere incluir: qué se pide (nombrar el bloqueo y reasignar o desbloquear), qué pasa si no se decide (la siguiente reprogramación), y quién tiene la facultad. La ficha no tiene autoridad registrada (`identity.authority` no encontrada), así que quién decide hay que confirmarlo. Excede la autoridad del gerente.
- Los compromisos nuevos y los cambios de fecha de hoy alteran lo que dice la ficha: `/pm-publish` para que la PMO lo vea.
- Este comando no le escribe a nadie ni valora las razones de cada atraso: perseguir cada uno es del gerente.
