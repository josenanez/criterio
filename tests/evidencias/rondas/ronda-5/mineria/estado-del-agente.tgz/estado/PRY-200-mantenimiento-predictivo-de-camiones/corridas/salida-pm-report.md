**Señales abiertas (lo que tengo a la vista antes de preguntar):** 17 — cierre planeado ya pasado, avance declarado 54 % frente a 4 de 4 hitos «cumplidos» sin evidencia, 6 compromisos vencidos, 4 reprogramados, 2 sin fecha.

**Pregunta de declaración:** ¿qué estado declara esta semana y con qué avance? *(Sesión sin interfaz: nadie respondió. No propongo ninguna respuesta; la línea queda en blanco.)*

---

# Mantenimiento predictivo de camiones (PRY-200) — semana del 2026-10-10 al 2026-10-16

**Declara el gerente (Ricardo Salas) esta semana:** — sin declaración — (nadie la dio en esta corrida; la línea queda en blanco a propósito)
**Última declaración documentada:** amarillo · 54 % · al 2026-10-14 (`20-seguimiento/2026-10-14-informe-avance.md`, hace 2 días, vigente). Es un documento del gerente, no una declaración de esta corrida.
**Sustento documental:** sin sustento. La declaración de 54 % no la sostiene el plan, y los hitos que la rodean no tienen evidencia.
**Lo que el semáforo (amarillo) no explica:** `progress_vs_plan`, `milestone_met_without_evidence`, `commitment_overdue`, `commitment_rescheduled`.

## Qué cambió esta semana
No hay corrida anterior contra la cual comparar: este es el primer snapshot (`snapshots/2026-10-16.json`) y el diff devuelve 0 cambios. No puedo decir qué cambió desde la semana pasada; lo que sigue es el estado de partida.

## Lo que sigue igual y sigue mal
Sin base de comparación no se pueden contar los días «así» desde una corrida previa; se da la antigüedad que sí consta en los documentos.

| Qué | Desde | Días así |
|---|---|---|
| Fecha de cierre planeada (2026-09-30) ya pasó, sin replanificación registrada y con 54 % declarado | 2026-09-30 | 16 |
| Hito «Ingeniería básica aprobada» marcado cumplido, sin evidencia | 2025-09-26 | 385 |
| Hito «Ingeniería de detalle aprobada» cumplido, sin evidencia | 2026-01-09 | 280 |
| Hito «Licencia y permisos obtenidos» cumplido, sin evidencia | 2026-04-25 | 174 |
| Hito «Montaje e instalación» cumplido, sin evidencia | 2026-08-08 | 69 |

## Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2026-09-30 | 2026-09-30 | 0 días contra ambas — pero la fecha ya pasó |
| Presupuesto | COP 1.200.000.000 | COP 1.200.000.000 | proyección COP 1.175.719.466 (−2,0 %) |

Replanificaciones: **0** — no hay ninguna registrada. Que la desviación sea 0 días no es buena noticia: la base nunca se movió y el cierre planeado ya venció. El plan (4 de 4 hitos cumplidos) sostendría 100 % de avance; lo declarado es 54 %: brecha de 46 puntos. O los hitos no se cumplieron, o el avance está mal declarado; los documentos no permiten decir cuál.

### Hitos de las próximas cuatro semanas
| Hito | Base | Vigente | Evidencia |
|---|---|---|---|
| Ninguno en la ficha: los 4 hitos registrados están en «cumplido» y el plan no tiene más | — | — | — |

## Las cifras
| Aprobado | Comprometido | Ejecutado | Proyectado | Disponible real |
|---|---|---|---|---|
| COP 1.200.000.000 | COP 390.173.338 (32,5 %) | COP 438.812.017 (36,6 %) | COP 1.175.719.466 | **COP 809.826.662** (aprobado − comprometido) |

Nota: el ejecutado (438,8 M) supera al comprometido (390,2 M); esa inconsistencia hay que aclararla con quien lleva la ejecución. Todas las cifras salen del informe de avance del 2026-10-14.

## Abierto
**Reprogramados (primero):**
- Elena Duarte — «Enviar el documento 1»: **6 veces** (original 2026-09-19 → 2026-12-12; 84 días de corrimiento).
- Diana Molina — «Cerrar la prueba 2»: **5 veces** (2026-09-15 → 2026-11-14).
- Óscar Ramírez — «Revisar el anexo 3»: 3 veces; **cumplido**, con acta de recibo del 2026-10-09.
- Javier Hoyos — «Confirmar la fecha 7»: 3 veces (2026-09-16 → 2026-10-28).

**Vencidos sin evidencia:**
- Sandra Gil — «Validar el ambiente 4»: venció 2026-10-04 (12 días).
- Liliana Torres — «Aprobar el diseño 5»: venció 2026-10-04 (12 días); dijo el 10-02 que ya lo entregó, sin acta.
- Jorge Medina — «Entregar el punto 16»: venció 2026-10-12 (4 días).
- Andrés Lozano — «Entregar el punto 8»: venció 2026-10-13 (3 días); dijo el 10-02 que ya lo entregó, sin acta.
- Javier Hoyos — «Confirmar la fecha 23»: venció 2026-10-13 (3 días).
- Diana Molina — «Validar el ambiente 20»: venció 2026-10-15 (1 día).

**Sin fecha:** Gustavo Neira — «Cerrar la prueba 18»; Laura Vélez — «Mandar el ajuste del presupuesto» (notas de hoy).

**RAID sin movimiento:** 2 riesgos y 2 incidencias, ninguno con dueño, fecha ni última fecha de movimiento, así que no puedo contar días:
- Riesgo: el proveedor no ha confirmado la fecha de la última entrega.
- Riesgo (dicho en la reunión de hoy, nadie lo registró): el proveedor podría no llegar con el equipo completo a la siguiente fase.
- Incidencia: las lluvias detuvieron el montaje diez días.
- Incidencia: el primer ensayo de disponibilidad no alcanzó lo pactado y se repite.

**Proveedor:** la ficha no tiene proveedores registrados (`vendors` vacío), aunque dos riesgos hablan de uno. No se puede contrastar entregables contra facturado.

## Lo que necesito de alguien
- **Ricardo Salas:** declarar estado y avance de esta semana (queda en blanco).
- **Ricardo Salas:** evidencia de los 4 hitos «cumplidos» (actas de aprobación, licencia, acta de montaje), o corregir su estado.
- **Ricardo Salas / Andrés Lozano (patrocinador):** el cierre planeado del 2026-09-30 ya pasó; falta replanificación o explicación. **Excede la autoridad del gerente → material de comité** (próximo comité: 2026-10-30).
- **Elena Duarte** y **Diana Molina:** fecha firme o decisión; llevan 6 y 5 reprogramaciones. **Material de comité** (umbral de 3 superado).
- **Liliana Torres** y **Andrés Lozano:** el acta o documento que respalde lo que dijeron haber entregado.
- **Laura Vélez, Gustavo Neira:** fecha para sus compromisos.
- **Quien lleve la ejecución:** aclarar por qué ejecutado > comprometido.

## Lo que no se sabe
**Sin dato:** autoridad que aprueba (`identity.authority`), fase del proyecto (`identity.phase`), proveedores, dueño y fecha de cada riesgo/incidencia. Además, 10 campos de identidad y plan vienen del acta de constitución de 2025-06-03 (16 meses) y no se han reconfirmado.
**Silencio:** último documento hace 0 días (notas de reunión del 2026-10-16) · última reunión hace 0 días. No hay silencio; el problema no es la falta de papel sino que ninguno de los 14 datos de la ficha está marcado como evidencia (0 evidencia, 0 declaración, 14 sin marcar).

---
**Pie:** ficha `estado/PRY-200-…/records/PRY-200.json`, corte al 2026-10-16, 2 campos sin dato (autoridad, fase) y 10 desactualizados. Términos 1.1 aceptados por José Francisco Ñáñez el 2026-10-16 (comprobante en `.criterio/terminos/`); nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal

**Después (ofrecido, no ejecutado):** hay dos compromisos con más de 3 reprogramaciones y el cierre planeado vencido, así que puedo armar el punto de comité con la decisión formulada (`/pm-escalate`). Si el gerente declara y la evidencia lo contradice, queda `/pm-publish` para que la PMO lo lea de la ficha.
