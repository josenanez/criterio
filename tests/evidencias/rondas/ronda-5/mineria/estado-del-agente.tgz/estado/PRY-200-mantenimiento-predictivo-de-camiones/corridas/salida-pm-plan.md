# Plan — Mantenimiento predictivo de camiones (PRY-200) · borrador del 2026-10-16
**Desde:** acta de constitución del 2025-06-03 (`00-gobierno/2025-06-03-acta-constitucion.docx`) · **Criterio de éxito:** «Mantenimiento predictivo de camiones en producción y medido.» (acta)

> Lo primero: esto no es un plan de arranque. El acta tiene 16 meses y el proyecto ya está en ejecución (54 % declarado, amarillo, informe del 2026-10-14). Ya existe un cronograma v1 (`10-plan/2025-06-03-cronograma-v1.csv`) con cuatro hitos. Este borrador reconstruye la estructura que el acta y ese cronograma permiten sostener, y deja a la vista lo que no permiten.
> Términos de uso vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-16).

## Lo que le falta al acta
| Qué | Consecuencia de planificar sin eso |
|---|---|
| **Alcance sin contenido real.** El acta dice «Componente 1 / Componente 2 / Componente 3» y, fuera de alcance, «Lo que otro proyecto cubre». | No hay entregables que descomponer. La WBS de abajo no puede tener nodos terminales aceptables; los tres componentes quedan «sin definir». «Fuera de alcance» sin nombrar el otro proyecto no excluye nada. |
| **Autoridad no declarada** (el acta no dice qué puede decidir el gerente y qué debe subir; la ficha lo registra como no encontrado). | No se sabe qué del plan decide Ricardo Salas y qué va al Comité de Operaciones o al patrocinador. Cada excepción queda sin ruta. |
| **Dependencias: «Ninguna declarada».** | El informe del 2026-10-14 y las notas del 2026-10-16 mencionan un proveedor cuya última entrega no tiene fecha confirmada. Hay una dependencia real que el acta no recoge. |
| **«Medido» sin métrica.** El criterio de éxito exige «en producción y medido», pero no dice contra qué indicador ni con qué umbral. El informe habla de un ensayo de disponibilidad «pactado» sin decir qué se pactó. | No se puede saber cuándo está cumplido el criterio de éxito. |
| **Quién acepta cada entregable: no está dicho.** | Ningún nodo tiene aceptante citable. |

Sí está: patrocinador (Andrés Lozano), gerente (Ricardo Salas), comité (Comité de Operaciones), presupuesto (1.200.000.000 COP), inicio 2025-06-13 y cierre 2026-09-30. No relleno nada de lo que falta.

## WBS
Tres estados únicamente: del acta · supuesto · sin definir. «Duración» solo si sale de algo citable.

| # | Entregable | Quién lo acepta | De dónde sale | Duración |
|---|---|---|---|---|
| 1 | Componente 1 | sin definir | sin definir (el acta no dice qué es) | vacía |
| 2 | Componente 2 | sin definir | sin definir | vacía |
| 3 | Componente 3 | sin definir | sin definir | vacía |
| 4 | Ingeniería básica aprobada | sin definir | supuesto — figura como hito del cronograma v1, no del acta | 105 días entre el inicio y el hito de la línea base v1 (2025-06-13 → 2025-09-26) |
| 5 | Ingeniería de detalle aprobada | sin definir | supuesto — cronograma v1 | 105 días en la línea base v1 (2025-09-26 → 2026-01-09) |
| 6 | Licencia y permisos obtenidos | sin definir | supuesto — cronograma v1 | 106 días en la línea base v1 (2026-01-09 → 2026-04-25) |
| 7 | Montaje e instalación | sin definir | supuesto — cronograma v1 | 105 días en la línea base v1 (2026-04-25 → 2026-08-08) |
| 8 | Ensayo de disponibilidad de los equipos aprobado | sin definir | supuesto — lo menciona el informe del 2026-10-14 («el primer ensayo… no alcanzó lo pactado y se repite»); ni el acta ni el cronograma lo tienen como entregable | vacía |
| 9 | Mantenimiento predictivo en producción | sin definir | del acta, en el criterio de éxito («en producción») | vacía |
| 10 | Medición del resultado | sin definir | del acta, en el criterio de éxito («medido») — sin indicador ni umbral | vacía |
| 11 | Entrega final del proveedor | sin definir | supuesto — el informe lista como riesgo que el proveedor no ha confirmado la fecha de «la última entrega» | vacía |

Las duraciones de 4–7 son los intervalos de la línea base v1, no una estimación. Desde el hito 7 hasta el cierre comprometido (2026-08-08 → 2026-09-30) quedan 53 días en el plan v1, y ese tramo no tiene hitos en el cronograma.

Una discrepancia que hay que mirar antes de usar el nodo 7: el cronograma v1 da «Montaje e instalación» como cerrado, y el informe del 2026-10-14 dice que las lluvias detuvieron el montaje diez días en este periodo. Los dos documentos no pueden estar describiendo el mismo estado.

## Orden
Sin fechas; es el orden del trabajo.
- 4 → 5 → 6 → 7 (así lo secuencia el cronograma v1; que 6 deba esperar a 5 es supuesto mío).
- 7 → 8 (no se ensaya lo que no está montado).
- 8 → 9 (supuesto: nadie pasa a producción sin pasar el ensayo de disponibilidad).
- 9 → 10 (no se mide en producción lo que aún no está en producción).
- 11 condiciona 7, 8 o 9 según qué entregue el proveedor; **no se sabe cuál**. Es la dependencia que el acta declara como «ninguna».
- 1, 2 y 3 no se pueden ordenar: no se sabe qué son.

## Supuestos sobre los que está construido
| Supuesto | Qué pasa si resulta falso |
|---|---|
| Los cuatro hitos del cronograma v1 son entregables y no solo marcas de calendario. | Los nodos 4–7 no tienen algo que alguien reciba y acepte; la WBS se reduce a los nodos 9 y 10. |
| Los Componentes 1, 2 y 3 corresponden total o parcialmente a esos hitos. | Hay entregables sin hito y hitos sin entregable. |
| El ensayo de disponibilidad es condición previa de la puesta en producción. | El nodo 8 no gobierna el 9 y el orden cambia. |
| La licencia y permisos (6) son previos al montaje (7). | Si se montó sin licencia, hay un problema de cumplimiento, no solo de plan. |
| La entrega pendiente del proveedor (11) es lo único externo que falta. | Hay más dependencias externas sin nombrar. |

Estos pasan a riesgos del proyecto en cuanto el plan se apruebe.

## Sin definir
| Qué | Quién lo define |
|---|---|
| Qué son los Componentes 1, 2 y 3 | Patrocinador (Andrés Lozano) con el gerente. El acta no lo dice. |
| Qué se declara fuera de alcance y qué otro proyecto lo cubre | Patrocinador / Comité de Operaciones |
| Qué puede decidir el gerente y qué sube | Patrocinador / Comité de Operaciones |
| Indicador y umbral de «medido» y de la disponibilidad «pactada» | Sin dueño visible en los documentos |
| Quién acepta cada entregable | Sin dueño visible en los documentos |
| Qué entrega exactamente el proveedor y cuándo | El proveedor; aún sin confirmar |
| Vigencia de las fechas: el cierre comprometido (2026-09-30) ya pasó y no hay cambios ni línea base nueva registrados | Gerente y Comité de Operaciones, por control de cambios |

## Proyectos análogos
Ninguno a la vista. La configuración no apunta a una carpeta de fichas de la PMO y no hay fichas de otros proyectos del mismo producto («monitoreo de flota») en el estado. Sin análogos no se trae referencia, y por eso no hay ninguna duración estimada por comparación.

## Preguntas para el equipo
1. ¿Cuánto toma terminar el Componente 1? ¿Y el 2, y el 3? Primero: ¿qué es cada uno y qué se entrega?
2. ¿Cuánto toma repetir el ensayo de disponibilidad, y cuál era el umbral pactado?
3. ¿Cuánto toma pasar a producción una vez aprobado el ensayo?
4. ¿Cuánto tiempo de operación hace falta para considerar que está «medido», con qué indicador?
5. ¿Qué falta recibir del proveedor, con qué fecha, y qué nodos bloquea?
6. ¿Montaje e instalación está cerrado o no? Hay que reconciliar el cronograma v1 con el informe del 2026-10-14.
7. ¿Cuánto toma cerrar el tramo entre el montaje y el cierre comprometido (53 días en el plan v1), y qué se hace en él?

## Para comprometer una fecha falta
- La fecha confirmada del proveedor para su última entrega (hoy sin confirmar, informe del 2026-10-14; en la reunión del 2026-10-16 se comentó que podría no llegar con el equipo completo para la siguiente fase y nadie lo registró como riesgo).
- La disponibilidad real del equipo: la ficha registra 23 compromisos abiertos de 26, y 14 de los 26 han sido reprogramados al menos una vez; no sé cuánto tiempo tiene cada persona para este plan.
- La ventana operativa para repetir el ensayo y pasar a producción con los camiones en uso (no está en ningún documento).
- Una decisión de control de cambios sobre el cierre, que ya venció.
- El ajuste del presupuesto que Laura Vélez quedó de mandar «la otra semana» sin fecha (notas del 2026-10-16).

Ninguna fecha queda comprometida en este borrador, ni se crea línea base. Si el plan se aprueba, se puede registrar como línea base y pasar los supuestos al RAID con doliente.
