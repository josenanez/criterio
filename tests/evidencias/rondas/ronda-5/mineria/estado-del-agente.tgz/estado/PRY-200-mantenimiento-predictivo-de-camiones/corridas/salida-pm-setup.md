## Listo — PRY-200 · Mantenimiento predictivo de camiones

**Lo que miré:** 13 documentos · 7 minutas o notas de reunión (6 comités semanales del 2026-09-04 al 2026-10-09 y las notas del 2026-10-16) · la última del 2026-10-16. Leí todas, de la más vieja a la más nueva, más 3 actas de recibo. Sin formatos ilegibles.
**Términos:** aceptados por José Francisco Ñáñez para la versión 0.3.11 (fecha 2026-10-16) · comprobante en `.criterio/terminos/aceptacion-criterio-project-0.3.11-2026-10-16.md` y `.pdf` · SHA-256 042a62265e2a038b… (md) y 51a20680f2513579… (pdf). Nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.11

Preguntas tomadas por defecto (sin interfaz): gerente y proyecto según el acta (Ricardo Salas, PRY-200); reunión los viernes, cada semana; estado en `estado/PRY-200-mantenimiento-predictivo-de-camiones`; términos aceptados con el nombre indicado en la instrucción de prueba.

### Lo que está abierto, y cuántas veces se ha movido
| Quién | Qué | Para cuándo | |
|---|---|---|---|
| Elena Duarte | Enviar el documento 1 | 2026-12-12 | Prometido primero para 2026-09-19; **6 reprogramaciones** (09-26, 10-17, 11-02, 11-18, 11-28, 12-12). Las notas del 10-16 dicen «no alcanzó» y dan 12/12/2026, que leí como 12 de diciembre. |
| Diana Molina | Cerrar la prueba 2 | 2026-11-14 | Primero 2026-09-15; **5 reprogramaciones**. |
| Óscar Ramírez | Revisar el anexo 3 | cerrado | Se reprogramó 3 veces (09-22, 10-09, 10-18) y se cerró con acta de recibo del 2026-10-09. |
| Javier Hoyos | Confirmar la fecha 7 | 2026-10-28 | Primero 2026-09-16; **3 reprogramaciones**. |
| Sandra Gil | Validar el ambiente 4 | 2026-10-04 | **Vencido 12 días**, sin acta. Sigue en la tabla del 10-09. |
| Liliana Torres | Aprobar el diseño 5 | 2026-10-04 | **Vencido 12 días**, sin acta. El 10-02 dijo que ya lo entregó; no hay acta y salió de la tabla. |
| Andrés Lozano | Entregar el punto 8 | 2026-10-13 | **Vencido 3 días**, sin acta. El 10-02 dijo que ya lo entregó; no hay acta. |
| Jorge Medina | Entregar el punto 16 | 2026-10-12 | **Vencido 4 días**, sin acta. El 10-02 dijo que ya lo entregó; no hay acta. |
| Diana Molina | Validar el ambiente 20 | 2026-10-15 | **Vencido 1 día**, sin acta. |
| Javier Hoyos | Confirmar la fecha 23 | 2026-10-13 | **Vencido 3 días**, sin acta. |

Cerrados con acta de recibo: Revisar el anexo 3 (Óscar Ramírez), Actualizar la matriz 6 (Ricardo Salas) y Validar el ambiente 12 (Beatriz Cuéllar). Los demás compromisos abiertos tienen fecha futura y están en la ficha con su historial.

Las señales vienen de `compute`. La más grave es la de Elena Duarte: seis cambios de fecha en siete semanas, y nadie ha dicho qué la bloquea.

### Sin fecha
- Gustavo Neira · Cerrar la prueba 18: «por definir» en las dos últimas minutas (10-02 y 10-09).
- Laura Vélez · Mandar el ajuste del presupuesto: «la otra semana» (notas del 10-16); nadie dijo fecha.

No pueden estar vencidos, y por eso mismo son los que desaparecen de los informes.

### Otros hallazgos del cálculo
- **Hitos:** el cronograma declara 4 de 4 hitos cerrados, y ninguno tiene acta que lo pruebe (`milestone_met_without_evidence`): ingeniería básica (2025-09-26), ingeniería de detalle (2026-01-09), licencia y permisos (2026-04-25) y montaje (2026-08-08).
- **Avance declarado vs. plan:** el informe del 2026-10-14 declara 54% y amarillo; el cronograma sustenta 100%. Diferencia de 46.0 puntos. Los hitos no incluyen nada posterior al montaje, y la fecha de cierre de la constitución (2026-09-30) ya pasó.
- **Presupuesto (informe del 10-14):** ejecutado 438.812.017 COP contra comprometido 390.173.338 COP; el ejecutado supera lo comprometido. Aprobado 1.200.000.000 COP; ejecutado 36.6%, comprometido 32.5%, proyección 1.175.719.466 COP (-2.0% sobre lo aprobado).
- **Riesgo que nadie registró:** el 10-16 se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase. Queda en la ficha, pero no en un registro de riesgos.
- **Pendiente de aclarar:** «Revisión con el proveedor» de Óscar Ramírez (2026-10-26) la guardé como compromiso nuevo, distinto del anexo 3, que ya estaba cerrado. Las notas no los relacionan.
- Compromisos sin fecha o vencidos que el informe del gerente no recoge: `compute` marca 4 señales (vencidos, reprogramados, hitos sin prueba y avance contra plan) sin contabilizar en su declaración.

### Qué le falta a tu carpeta
- Actas de recibo de los hitos declarados cerrados (4) y de los compromisos que dicen haber entregado (puntos 8 y 16, diseño 5).
- Cronograma vigente: solo hay la versión 1 de 2025-06-03, sin hitos posteriores al montaje.
- Autoridad del gerente y etapa del proyecto: el acta no los trae (`not_found`).
- Un acta de constitución nunca reexpedida: sus datos (patrocinador, gerente, alcance, fechas) tienen 16 meses sin confirmación posterior.

**Cuándo vuelvo:** el viernes 2026-10-30, la próxima reunión según las notas del 10-16; después, cada semana.
