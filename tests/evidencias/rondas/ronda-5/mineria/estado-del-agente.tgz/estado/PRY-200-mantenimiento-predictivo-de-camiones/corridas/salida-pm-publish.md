**Antes de escribir (lo que iba a publicar):** recalculé la ficha con corte al 2026-10-16. Va con 14 campos con dato y 2 sin decir en ninguna parte (`identity.authority`, `identity.phase`). Declara **amarillo** (54 %) al 2026-10-14, según el informe de avance de esa fecha; es una declaración tuya, no de la PMO. Los diez campos de identidad y plan vienen del acta de constitución, que tiene 16 meses.

Publiqué la ficha en `/home/claude/banco/ronda-5/mineria/espacio/documentos/proyectos/PRY-200-mantenimiento-predictivo-de-camiones/00-gobierno/ficha-pm.json`, con corte al 2026-10-16.

**Lleva:** 14 campos con dato · 2 sin decir en ninguna parte · declara **amarillo** al 2026-10-14

**Lo más viejo que va ahí:** `identity.code`, `identity.name`, `identity.business_area`, `identity.product`, `identity.sponsor`, `identity.manager`, `identity.committee`, `plan.start_date`, `plan.end_date` y `plan.scope_summary`, todos del 2025-06-03 (acta de constitución). Pasan de un año: 16 meses.

**Para que lo sepas antes de que la PMO lo lea:** el recálculo deja 17 alertas, y la ficha las hace visibles.
- Declaras 54 % de avance, pero los 4 hitos del cronograma figuran cumplidos sin evidencia (el plan sostiene 100 %).
- Hay 6 compromisos vencidos, 2 sin fecha y 4 reprogramados varias veces. El peor es "Enviar el documento 1" de Elena Duarte, con 6 reprogramaciones.
- La autoridad del proyecto no está dicha en ninguna parte.
