## Reunión de seguimiento — PRY-200 Mantenimiento predictivo de camiones · 2026-10-30
9 puntos · 52 minutos · 7 personas requeridas (Ricardo Salas, Elena Duarte, Diana Molina, Javier Hoyos, Sandra Gil, Jorge Medina, Laura Vélez)

Términos: ya vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-16); no hubo nada que registrar.

Supuestos que conviene leer antes: la fecha sale de la configuración (`committee_next` 2026-10-30; las notas del 10-16 dicen «en dos semanas», que coincide). No pasaste duración, así que no hay tope: la suma es 52 min. Los datos son del 2026-10-16; lo que vence entre hoy y el 10-30 va a haber cambiado, así que **la agenda se rehace el 2026-10-29** (`/pm-agenda` o `pm-wake`) antes de convocar. «Quién va a estar» se estima con la asistencia del 10-16, que es lo único que hay.

### Lo que no se destraba solo
> **[1] Nombrar qué frena «Enviar el documento 1» y decidir quién lo destraba o si se reasigna** · 12 min · **Elena Duarte**
> Prometido para el 2026-09-19, y antes para el 09-26, 10-17, 11-02, 11-18, 11-28, y hoy para el **2026-12-12**. Seis movimientos; tres meses entre la primera promesa y la vigente.
> Fuente: `30-reuniones/2026-09-04-comite-semanal.md` (promesa original) y `2026-10-16-notas-reunion.txt`, línea 4 (última fecha).
> **Si no se resuelve hoy:** la séptima reprogramación. Más de tres veces no es seguimiento, es un bloqueo que nadie ha nombrado. Si el bloqueo excede lo que la sala puede mover, sale de aquí formulado con `/pm-escalate`; la ficha no tiene autoridad registrada (`identity.authority` no encontrada), así que quién decide hay que confirmarlo.

> **[2] Qué impide cerrar «Cerrar la prueba 2» y qué pasa con «Validar el ambiente 20», vencido** · 10 min · **Diana Molina**
> Prueba 2: prometido para el 2026-09-15, y antes para el 09-23, 10-02, 10-13, 10-25, y hoy para el **2026-11-14**. Cinco movimientos. Ambiente 20 venció el 10-15 sin evidencia: dos compromisos de la misma persona en riesgo a la vez.
> Fuente: `30-reuniones/2026-10-09-comite-semanal.md` (fecha vigente) y `2026-09-04-comite-semanal.md` (original); ambiente 20 en `2026-10-02-comite-semanal.md`.
> **Si no se resuelve hoy:** prueba 2 cruza a 11-14 sin causa dicha, y el ensayo de disponibilidad que ya «no alcanzó lo pactado y se repite» (informe 10-14) queda sin su prueba cerrada. Esa relación es una lectura; los documentos no la afirman.

> **[3] Fecha firme de «Confirmar la fecha 7» (vence 10-28) y estado de «Confirmar la fecha 23», vencido** · 8 min · **Javier Hoyos**
> Fecha 7: prometido para el 2026-09-16, y antes para el 09-26, 10-16, y hoy para el **2026-10-28**. Tres movimientos; si la reunión cae después de esa fecha, ya habrá cumplido o será el cuarto. Fecha 23 venció el 10-13 sin evidencia: el mismo tipo de compromiso (confirmar fechas) falla dos veces con la misma persona.
> Fuente: `2026-10-09-comite-semanal.md` y `2026-09-11-comite-semanal.md`.
> **Si no se resuelve hoy:** las fechas que otros esperan de Javier siguen sin confirmarse; no hay documento que diga quiénes las esperan, así que pregúntalo en la sala.

### Vencido sin evidencia
Al 2026-10-16, más viejo primero.

| Quién | Qué | Desde | Qué se necesita hoy | Min |
|---|---|---|---|---|
| Sandra Gil | Validar el ambiente 4 (reprogramado 2 veces; original 09-13) | 2026-10-04 | Evidencia de la validación o fecha con causa. Además tiene abiertos «Enviar el documento 9» (10-27, reprogramado 2 veces) y «Enviar el documento 17» (11-07): tres compromisos abiertos con la misma persona | 4 |
| Liliana Torres | Aprobar el diseño 5 | 2026-10-04 | Ver «No es de esta reunión» | 0 |
| Jorge Medina | Entregar el punto 16 | 2026-10-12 | Dijo el 10-02 que ya lo entregó; falta el acta de recibo. Que la traiga o que diga qué falta | 3 |
| Andrés Lozano | Entregar el punto 8 (reprogramado 1 vez) | 2026-10-13 | Ver «No es de esta reunión» | 0 |
| Javier Hoyos | Confirmar la fecha 23 | 2026-10-13 | En el punto 3 | — |
| Diana Molina | Validar el ambiente 20 | 2026-10-15 | En el punto 2 | — |

Fuente: `2026-10-02-comite-semanal.md` (las tres frases de «ya lo entregué», sin acta), `2026-09-25` y `2026-10-09`.

### Se decide hoy o se atrasa
| Qué | Quién decide | Si no se decide | Min |
|---|---|---|---|
| Fecha para «Mandar el ajuste del presupuesto» (hoy es «la otra semana») | Laura Vélez con Ricardo Salas | Un compromiso sin fecha no vence nunca en los informes y no aparece en la siguiente agenda. Fuente: notas 10-16, línea 3 | 2 |
| Fecha para «Cerrar la prueba 18» («por definir» el 10-02 y el 10-09). **Solo si Gustavo Neira asiste**; no figuró el 10-16 | Gustavo Neira | Mismo efecto: no vence nunca. Si no está, pasa a «No es de esta reunión» | 2 |
| Dueño, probabilidad e impacto de los riesgos abiertos: «El proveedor no ha confirmado la fecha de la última entrega» (informe 10-14) y «el proveedor podría no llegar con el equipo completo para la siguiente fase» (notas 10-16, línea 5: «se comentó», sin autor, nadie lo registró). Y dueño de las dos incidencias del informe: lluvias (10 días de montaje detenido) y ensayo de disponibilidad que se repite | Ricardo Salas | Cuatro asuntos abiertos sin dueño ni fecha. Las notas no relacionan el segundo riesgo con la «Revisión con el proveedor» de Óscar Ramírez (10-26); preguntarlo es parte del punto | 6 |

### Vence antes de la próxima
Ronda de confirmación, no repaso. Pide la evidencia, no la promesa.

| Quién | Qué | Para cuándo |
|---|---|---|
| Natalia Ospina | Entregar el punto 24 | 2026-10-17 |
| Felipe Arango | Revisar el anexo 19 | 2026-10-18 |
| Elena Duarte | Revisar el anexo 11 (reprogramado 1 vez) | 2026-10-19 |
| Ricardo Salas | Aprobar el diseño 21 | 2026-10-23 |
| María Restrepo | Actualizar la matriz 22 | 2026-10-24 |
| Óscar Ramírez | Revisión con el proveedor (nuevo, 10-16) | 2026-10-26 |
| Sandra Gil | Enviar el documento 9 (reprogramado 2 veces) | 2026-10-27 |
| Jorge Medina | Aprobar el diseño 13 (reprogramado 1 vez) | 2026-10-28 |

Tiempo: 5 min en bloque. Todo lo de esta tabla que no tenga acta de recibo el 10-29 pasa a la sección «Vencido» al rehacer la agenda.

### No es de esta reunión
| Qué | Por qué | Dónde va |
|---|---|---|
| Liliana Torres: «Aprobar el diseño 5» (vencido 10-04). Andrés Lozano (patrocinador según el acta): «Entregar el punto 8» (vencido 10-13) | Ninguno figura en la asistencia del 10-02, 10-09 ni 10-16 (último: 09-25), así que nadie en la sala puede mover su punto. Los dos «ya lo entregué» del 10-02 no tienen acta | Ricardo les pide directamente el acta de recibo antes del 10-29. Si el patrocinador no responde, es decisión para comité: `/pm-escalate` |
| Los 4 hitos del plan figuran cumplidos sin acta de recibo, y el informe del 10-14 dice que las lluvias detuvieron el montaje diez días (hito «Montaje e instalación», cerrado con fecha 2026-08-08) | No hay quien lo resuelva sentado en esa sala; es evidencia que el gerente reúne. Estado declarado: amarillo, 54 % | `/pm-report`, donde el estado lo declara Ricardo contra esta evidencia |
| Cadencia: las notas dicen «próxima reunión en dos semanas»; la configuración dice comité semanal | Es un dato de configuración, no un punto | Ricardo confirma y corrige `config.json` si ahora es quincenal |
| «Aprobar el diseño 21» (Ricardo Salas, 10-23) | Es del gerente, no necesita sala | Aparece en la ronda de arriba solo para constar |

### Anexo — sin cambios desde el 2026-10-09
`diff` no tiene foto previa (esta es la primera corrida), así que «sin cambios» se mide contra la tabla del comité del 10-09 y las notas del 10-16. No se repasa en la reunión.
- Diana Molina — la prueba 2 y el ambiente 20, ver arriba. Sin otros compromisos.
- Jorge Medina — Actualizar la matriz 14: 2026-11-09 (reprogramado 1 vez)
- Carlos Peña — Confirmar la fecha 15: 2026-11-23 (reprogramado 2 veces; vigilar: es el mismo patrón de fechas que Javier Hoyos)
- Felipe Arango — Cerrar la prueba 10: 2026-11-11 (reprogramado 2 veces)
- Sandra Gil — Enviar el documento 17: 2026-11-07 (reprogramado 1 vez)
- Cerrados con acta: Revisar el anexo 3 (Óscar Ramírez, 10-09), Actualizar la matriz 6 (Ricardo Salas, 10-09), Validar el ambiente 12 (Beatriz Cuéllar, 10-02)

### Lo que esta agenda no sabe
- Quién va a estar el 10-30: se estimó con la asistencia del 10-16.
- Si Elena, Diana o Javier tienen una causa distinta de la que aquí se sugiere: ningún documento dice por qué se movieron las fechas.
- Qué decidió o dejó sin decidir el 10-16: las notas son de 5 viñetas para 12 asistentes y no registran decisiones ni asuntos abiertos, así que no se hereda ninguno.
- Si el tiempo disponible es menor a 52 min: se cortaría desde el final, primero la ronda «Vence antes» (5) y luego el punto de riesgos (6), con lo que quedan 41.

### Después
Cuando termine la reunión: `/pm-minutes` sobre la transcripción o las notas; los compromisos nuevos entran a `/pm-commitments`. Esta agenda no convoca a nadie: citar es del gerente.
