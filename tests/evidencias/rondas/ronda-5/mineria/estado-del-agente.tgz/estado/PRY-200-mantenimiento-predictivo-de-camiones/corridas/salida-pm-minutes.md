# Acta — PRY-200 Mantenimiento predictivo de camiones · 2026-10-16
**Asistieron:** Carlos Peña, Diana Molina, Elena Duarte, Felipe Arango, Javier Hoyos, Jorge Medina, Laura Vélez, María Restrepo, Natalia Ospina, Ricardo Salas, Sandra Gil, Óscar Ramírez
**Fuente:** `2026-10-16-notas-reunion.txt` (notas de 9 líneas; no es transcripción)
**Ausentes con tema en agenda:** no consta agenda en las notas, así que no se puede decir. (Gustavo Neira, que tiene «Cerrar la prueba 18» sin fecha, estuvo el 2026-10-09 y hoy no figura.)

Términos: ya vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-16); no hubo nada que registrar.

## Compromisos
| Quién | Qué | Para cuándo | |
|---|---|---|---|
| Elena Duarte | Enviar el documento 1 | 2026-12-12 | **Reprogramado 6 veces.** Promesa original 2026-09-19; fechas: 09-26, 10-17, 11-02, 11-18, 11-28, 12-12. Cada reunión la corrió; hoy se movió 14 días más. Cita: «lo de "enviar el documento 1" no alcanzó, se compromete para el 12/12/2026» (línea 4) |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-26 | Nuevo (línea 6). Se registra aparte de «Revisar el anexo 3», cerrado el 2026-10-09; las notas no dicen que sean lo mismo |

### Sin fecha
| Quién | Qué |
|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto. Cita: «queda de mandar el ajuste del presupuesto la otra semana» (línea 5). «La otra semana» no es una fecha; se registra `due_date: no_declarada` y no vence nunca en los informes. |

(Sigue abierto de reuniones anteriores, también sin fecha: Gustavo Neira, «Cerrar la prueba 18», desde 2026-10-02.)

## Decisiones
Ninguna. Las notas no registran que alguien haya decidido algo.

## Quedó sin decidir
Las notas no nombran asuntos puestos sobre la mesa y no resueltos, así que no se inventa ninguno.

## Intenciones sin doliente
Ninguna en estas notas.

## Dicho al pasar y no registrado
| Qué | Quién lo dijo | Categoría | Ya estaba en el RAID |
|---|---|---|---|
| «Se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo» (línea 7) | No se sabe: las notas dicen «se comentó» | Riesgo (es un evento futuro incierto) | **No**, no con ese contenido. El informe de avance del 2026-10-14 tiene un riesgo cercano pero distinto: «El proveedor no ha confirmado la fecha de la última entrega» (fecha, no equipo completo). Sin probabilidad, impacto ni dueño |

## Cerrado en esta reunión
Nada. Ninguna acta de recibo acompaña estas notas, así que no se cierra ningún compromiso.

## Lo que esta reunión contradice
| Campo | Dijo la reunión | Dice el expediente | Fuente y fecha de cada uno |
|---|---|---|---|
| Cadencia del comité | «Próxima reunión en dos semanas» (≈ 2026-10-30) | Configuración: comité semanal, próximo 2026-10-30 | Notas 2026-10-16 / `config.json`. La fecha coincide; la cadencia no. Si ahora es quincenal, la configuración está vieja |

Ningún campo de la ficha (patrocinador, gerente, comité, fechas de cierre) cambió en esta reunión.

## Sin resolver de la transcripción
- «la otra semana» (Laura Vélez): no se sabe cuál semana ni qué día.
- «Revisión con el proveedor» (Óscar Ramírez): no se entiende de qué proveedor ni si tiene relación con el riesgo de la línea 7.
- «Se comentó…» (línea 7): no hay autor de la frase.
- Las notas son un resumen de 5 viñetas de una reunión con 12 asistentes: probablemente quedó más dicho de lo que quedó escrito.

## Lo que pasó al recalcular (`compute`)
- Compromisos sin fecha: 2 (Laura Vélez, Gustavo Neira).
- Reprogramados 3 veces o más: Elena Duarte (6), Diana Molina (5), Óscar Ramírez en el anexo 3 (3, ya cerrado), Javier Hoyos (3).
- Vencidos sin evidencia: 6 (Sandra Gil, Liliana Torres, Andrés Lozano, Jorge Medina, Diana Molina, Javier Hoyos). Ninguno sale de estas notas.
- Informe del 2026-10-14 declara amarillo con 54 %; el plan marca 4 de 4 hitos cumplidos y ninguno tiene acta de recibo. Esto es previo a la reunión y no lo cambia.

## Después
`/pm-commitments` para el seguimiento completo. `/pm-publish` no hace falta por contradicción de ficha; solo si quieres publicar. El acta sale aquí y la guardas tú: no se escribe en tu carpeta de reuniones.
