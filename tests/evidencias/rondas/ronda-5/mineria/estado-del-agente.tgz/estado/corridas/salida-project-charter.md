Acta previa: **sí existe**, del 2025-11-01 (`PRY-209-electrificación-de-equipos/00-gobierno/2025-11-01-acta-constitucion.docx`). Modo revisar.

## Acta — PRY-209 Electrificación de equipos
**Estado:** existe, del 2025-11-01

### Qué falta
| Campo | Estado | Consecuencia |
|---|---|---|
| **Autoridad del gerente** | **Ausente.** El acta no dice hasta qué monto ni qué cambio de alcance decide Javier Hoyos sin subir a comité. | Cualquier desviación va al comité por defecto. Es relevante ahora: la proyección al cierre (COP 3.289.376.978) deja COP 10.623.022 de margen sobre el aprobado (COP 3.300.000.000), el 0,3 %. Cualquier sobrecosto menor excede el aprobado y nadie sabe quién puede decidirlo. |
| Objetivo de negocio | **Débil.** «Entregar electrificación de equipos para Mina» describe la solución, no el resultado de negocio. | Sin un resultado que medir, no hay forma de decir si el proyecto valió la pena ni de defender el presupuesto frente a otra alternativa. |
| Alcance | **Vacío de contenido.** «Componente 1, 2 y 3» no dice qué es cada componente. | Un cambio de alcance no se puede reconocer como tal: no hay línea contra la cual compararlo. Control de cambios queda sin base. |
| Exclusiones | **Vacías.** «Lo que otro proyecto cubre» no nombra ningún proyecto ni elemento. | No se puede distinguir lo excluido de lo olvidado; el solapamiento con otro proyecto no se puede detectar. |
| Criterio de éxito | **Sin medida ni medidor.** «En producción y medido» no dice qué se mide, con qué umbral ni quién lo mide. | El cierre se vuelve una opinión: el proyecto puede declararse exitoso o fallido con los mismos datos. |
| Dependencias | **Contradicción.** El acta declara «Ninguna»; el informe del 2026-10-07 reporta que el proveedor no ha confirmado la fecha de la última entrega. | Una dependencia de proveedor existe en la práctica y no está en el acta ni tiene dueño ni fecha. |
| Supuestos y restricciones | **Ausentes.** | Nada del acta indica qué se dio por cierto al aprobar el presupuesto; no hay qué revisar cuando algo cambie. |
| Hitos principales | **Ausentes.** No hay cronograma en la carpeta; la única fecha es el cierre (2026-12-31). | El atraso no se puede medir contra una línea base: el 54 % declarado no tiene contra qué compararse. |
| Cadencia del comité | **Ausente.** | No se sabe cada cuánto debe verse el proyecto. |
| Comité al que reporta | Presente, pero para revisar: **Comité de Seguridad**. | Es el que aprobó el presupuesto de un proyecto de electrificación; confirmar si es el comité correcto para decidir costo y alcance, o solo seguridad. |
| Patrocinador / Gerente | Presentes: Andrés Lozano / Javier Hoyos. | — |
| Producto asociado | «No aplica». | Sin producto, el beneficio no tiene a quién rendirle cuentas. |

### Contenido (lo que el acta sustenta)
**Objetivo de negocio:** pendiente de definir (el acta solo dice «Entregar electrificación de equipos para Mina», que es la solución).
**Alcance:** Componentes 1, 2 y 3, sin descripción. *(acta 2025-11-01)*
**Exclusiones:** «Lo que otro proyecto cubre», sin nombrar. *(acta)*
**Patrocinador:** Andrés Lozano · **Gerente:** Javier Hoyos *(acta)*
**Autoridad del gerente:** **pendiente de definir.** No consta en ningún documento.
**Comité al que reporta:** Comité de Seguridad *(acta)* · **Cadencia:** pendiente de definir.
**Supuestos:** pendiente de definir · **Restricciones:** pendiente de definir.
**Presupuesto aprobado:** COP 3.300.000.000, por el Comité de Seguridad el 2025-11-01 *(acta)*.
**Criterio de éxito:** «Electrificación de equipos en producción y medido» *(acta)* · **Lo mide:** pendiente de definir.
**Hitos principales:** pendiente de definir; inicio 2025-11-11 y cierre 2026-12-31 *(acta)*.

### Lo que el informe del 2026-10-07 agrega
- Declara estado amarillo y 54 % de avance (declaración del gerente, no verificada). Ejecutado COP 1.620.829.158 = 49,1 % del aprobado; comprometido COP 2.261.539.217 = 68,5 %, por debajo del umbral de 90 %.
- Hallazgo abierto en la auditoría de seguridad, sin dueño ni fecha.
- Riesgo abierto: proveedor sin fecha de la última entrega.

### Lo que no sé
No sé qué se habló fuera de estos dos documentos. No sé si existe una delegación de autoridad en otro lugar (política corporativa, acta del comité): no la encontré en la carpeta, y por eso no la doy por inexistente, solo por no documentada aquí.

## Después
- Autoridad no declarada: lo apropiado es llevar su definición al comité como decisión (monto y tipo de cambio que Javier Hoyos puede aprobar sin subir). No lo hice; lo propongo.
- Del acta salen supuestos pendientes (dependencia del proveedor, hallazgo de auditoría) que podrían pasar al registro RAID. No lo hice; lo propongo.

*Pie de rigor: borrador de trabajo basado solo en dos documentos (acta 2025-11-01, informe 2026-10-07); cada dato lleva su fuente; la verificación es de quien lo usa. Términos vigentes, v1.1 aceptados por José Francisco Ñáñez el 2026-10-16.*
