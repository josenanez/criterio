# Corrida del 2026-10-16 · change-control

13 proyectos · 41 s · 58 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 19 |
| `progress_vs_plan` | 7 |
| `commitment_overdue` | 7 |
| `declared_vs_evidence` | 6 |
| `commitment_rescheduled` | 4 |
| `variance_time` | 4 |
| `commitment_undated` | 3 |
| `rebaseline_unauthorized` | 3 |
| `variance_cost` | 2 |
| `pm_vs_pmo` | 1 |
| `milestone_overdue` | 1 |
| `vendor_deliverable_late` | 1 |

Solicitud de mover 30 días la salida a producción de PRY-207. Impacto en portafolio 0 porque no hay dependencias declaradas (no es ausencia de efecto). Sin autoridad declarada: va a comité por defecto. No se sabe solicitante, motivo, costo ni cuál de las dos fechas de cierre (acta 2027-06-16, cronograma 2027-04-26) es la correcta. No se creó línea base nueva.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

Sale de la ficha `estado/records/PRY-207.json` (corte 2026-10-14, sellada 2026-10-16), del acta de constitución (2025-12-01) y del cronograma v1. Supuesto de lectura: «salida a producción» no es un hito del plan; se toma como el cierre del proyecto, es decir «Pruebas en operación» (2027-04-26), que es lo que el criterio de éxito del acta llama «en producción y medido».

## Solicitud de cambio — PRY-207 Gemelo digital de la planta — 2026-10-16

**Qué se pide:** mover 30 días la salida a producción. · **Quién lo pide:** no consta en los documentos (la solicitud llega por este comando, sin solicitante nombrado). · **Por qué:** no consta; no hay motivo escrito. El informe de avance del 2026-10-14 menciona dos semanas perdidas por rotación de un ingeniero clave y un ensayo de disponibilidad que se repite, pero no los liga a esta solicitud: es un contexto posible, no el motivo declarado.

### Impacto
| Dimensión | Hoy | Con el cambio | Diferencia |
|---|---|---|---|
| Alcance | Componentes 1, 2 y 3 (acta) | Sin cambio declarado | 0 |
| Tiempo | Cierre 2027-04-26 (cronograma v1, vigente). El acta dice 2027-06-16 | 2027-05-26 contra el cronograma; 2027-07-16 contra el acta | +30 días |
| Costo | Aprobado 9.500.000.000 COP; proyección 9.553.085.251 (+0,6 %); ejecutado 3.711.432.409 (39,1 %); comprometido 6.646.347.227 (70,0 %) | No declarado | No se sabe |

**Quién absorbe lo que no se declaró.** La solicitud mueve tiempo y no dice nada de alcance ni de costo. Treinta días más con el mismo equipo y el mismo alcance cuestan algo: horas del equipo, la bolsa de horas del proveedor (CT-858, 503.962.353 COP por entregable) y la ventana de calibración de sensores. Si nadie lo aprueba como costo, lo absorbe el proyecto en horas no pagadas o en calidad de las pruebas. La holgura sobre el presupuesto es de 2.853.652.773 COP sin comprometer. Cuánto cuesta el mes extra no se puede calcular con estos documentos y no se inventa.

**Dos fechas de cierre que no coinciden, y nadie las reconcilió.** El acta aprobó el 2027-06-16 y el cronograma v1 (misma fecha, 2025-12-01) cierra el 2027-04-26: 51 días de diferencia entre dos documentos del mismo día. La ficha tomó la del cronograma y no registra conflicto. Antes de aprobar hay que decir contra cuál de las dos se mide el cambio: con el cronograma el cierre pasa de abril a mayo; con el acta, a mediados de julio.

### Efecto en el portafolio
| Proyecto afectado | Cómo | Gerente |
|---|---|---|
| Ninguno | El cálculo de impacto recorre las dependencias declaradas y no encuentra proyectos alcanzados: 0 directos, 0 indirectos, 0 que no puedan sostener su fecha, 0 dependencias sin confirmar. | — |

**Esto no significa que no haya efecto.** El acta dice «Ninguna declarada» en dependencias, y la ficha tiene la lista de dependencias vacía. El acta excluye del alcance «lo que otro proyecto cubre», lo que sugiere que hay otro proyecto, y no está nombrado. Un cero aquí es ausencia de declaración, no ausencia de dependencia.

Hitos por los que pasa el cambio, no los que se mueven. No se dice cuántos días se mueve cada uno, porque eso necesita holgura por actividad y la ficha no la tiene:
- Montaje e instalación — 2027-01-16 (a 92 días)
- Pruebas en operación — 2027-04-26 (a 192 días)

El hito «Licencia y permisos obtenidos» (2026-10-08) ya lleva 8 días vencido sin evidencia de cierre y queda fuera de lo que pasa por este cambio. Si ese retraso es la causa del movimiento, el cambio no es de 30 días sino que arrastra una línea base que ya no se sostiene.

### Quién decide
**Autoridad requerida:** no determinable. · **Según:** la ficha no encuentra autoridad declarada (`identity.authority`: no encontrado) y el acta no tiene cláusula de autoridad ni de cambios. El acta nombra al Comité de Inversiones, que aprobó el presupuesto el 2025-12-01. · **Va a comité:** sí, por defecto. Sin umbral escrito que diga lo contrario, un cambio en la fecha de cierre sobre un presupuesto aprobado por el Comité de Inversiones va a quien lo aprobó.

**Hallazgo de fondo:** el proyecto no declara quién puede aprobar un cambio de fecha. Es lo primero que hay que corregir en el acta.

### Si no se aprueba
Queda la línea base v1 como única referencia (cierre 2027-04-26, 0 replanificaciones, 0 días de desviación). Sin cambio, el proyecto llega a esa fecha con una licencia 8 días vencida, un ensayo de disponibilidad que se repite, una entrega de proveedor sin fecha confirmada y una bolsa de horas 33 días vencida. Declara 75 % de avance con un plan que sostiene entre 40 y 60 %: la fecha tiene más riesgo que el que el amarillo declarado deja ver.

### Si se aprueba
Línea base 2 — cierre 2027-05-26 (contra el cronograma) · presupuesto 9.500.000.000 COP sin cambio solicitado, y proyección actual de 9.553.085.251 · motivo: no consta; debe escribirse y citarse el documento que lo aprueba.
Desviación acumulada contra la línea base original: +30 días · costo sin determinar (hoy +0,6 % en proyección). Con una sola replanificación, la desviación contra la vigente y contra la original son la misma; si el mes se mide contra el acta (2027-06-16), el cierre nuevo sería 2027-07-16.

**No se creó línea base nueva.** Nadie con autoridad ha aprobado nada; la ficha sigue sin cambios registrados.

### Qué no sé
- Quién pide el cambio y por qué.
- El costo del mes adicional.
- Si hay dependencias con otros proyectos sin declarar.
- Cuántos días se mueve cada hito intermedio.
- Cuál de las dos fechas de cierre es la correcta.
- Quién tiene autoridad para aprobar.

### Después
Cuando haya solicitante, motivo y fecha de referencia, se puede preparar el paquete para el Comité de Inversiones (`/steering-pack`). La línea base 2 se registra solo cuando quien podía aprobarlo lo haya aprobado, con el documento que lo respalda.

---
Rigor: cifras de `portafolio.py impact` y `compute` sobre la ficha del 2026-10-16. El acta, el cronograma y el informe de avance se leyeron completos. Sin evidencia independiente del estado declarado: ningún campo de la ficha está marcado como evidencia. Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-16).
