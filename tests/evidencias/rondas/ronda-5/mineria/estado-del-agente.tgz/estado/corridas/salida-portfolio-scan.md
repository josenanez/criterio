## Barrido — 2026-10-16

Encontré la configuración en `.criterio/portafolio/config.json` y los términos vigentes (v1.1, familia 0.3.11), aceptados por José Francisco Ñáñez el 2026-10-16: no hizo falta volver a registrarlos. Esta sesión no tenía a quién preguntar; en cada punto tomé el valor sugerido.

**Documentos:** 77 en la carpeta · 50 leídos · 27 sin cambio desde la corrida anterior · 0 ilegibles
**Proyectos:** 13 con ficha · 10 nuevos · 0 sin carpeta propia

Formatos: .md (38), .docx (11), .pdf (10), .csv (9), .xlsx (7), .json (1), .txt (1). Word, Excel y PDF se leyeron por su texto convertido; las citas van a los originales.

Plan de lectura: 50 de 77 documentos, en un solo lote de 10 proyectos, uno tras otro, sin subagentes. Nada quedó diferido. Los 27 documentos sin cambio son los de PRY-200, PRY-202 y PRY-210, que ya tenían ficha del arranque.

### Nuevos
| Proyecto | Documentos | Campos encontrados | Campos sin dato |
|---|---|---|---|
| PRY-199 Cambio de luminarias del campamento | 6 | Patrocinador María Restrepo, gerente Andrés Lozano, presupuesto COP 2.400 M, producto PRD-299, contrato CT-199 (3 entregables de COP 144 M) | Facultad del gerente, etapa |
| PRY-201 Ampliación de la relavera | 3 | Patrocinador Felipe Arango, gerente Jorge Medina, presupuesto COP 800 M | Facultad del gerente, etapa, producto («No aplica») |
| PRY-203 Despacho automático de flota | 7 | Patrocinador Javier Hoyos, gerente Beatriz Cuéllar, presupuesto COP 800 M, producto «despacho de flota», CC-01 pendiente | Facultad del gerente, etapa |
| PRY-204 Monitoreo de taludes | 7 | Patrocinador Paula Céspedes, gerente Ricardo Salas, presupuesto COP 4.200 M, producto «alerta de taludes», CC-01 autorizada | Facultad del gerente, etapa |
| PRY-205 Sistema de gestión de seguridad | 3 | Patrocinador Beatriz Cuéllar, gerente Rubén Cárdenas, presupuesto COP 18.000 M | Facultad del gerente, etapa, producto («No aplica») |
| PRY-206 Red privada LTE en mina | 2 | Patrocinador Óscar Ramírez, gerente Liliana Torres, presupuesto COP 6.800 M | Facultad del gerente, etapa, producto («No aplica»); sin cronograma |
| PRY-207 Gemelo digital de la planta | 8 | Patrocinador Jorge Medina, gerente Natalia Ospina, presupuesto COP 9.500 M, producto «gemelo digital», contrato CT-858 con acta de recibo y factura | Facultad del gerente, etapa |
| PRY-208 Trazabilidad del mineral | 6 | Patrocinador Natalia Ospina, gerente Paula Céspedes, presupuesto COP 2.400 M, producto «trazabilidad», CC-01 autorizada | Facultad del gerente, etapa |
| PRY-209 Electrificación de equipos | 2 | Patrocinador Andrés Lozano, gerente Javier Hoyos, presupuesto COP 3.300 M | Facultad del gerente, etapa, producto («No aplica»); sin cronograma |
| PRY-211 Control de polvo en vías | 6 | Patrocinador Javier Hoyos, gerente Elena Duarte, presupuesto COP 800 M | Facultad del gerente, etapa, producto («No aplica») |

### Actualizados
| Proyecto | Qué cambió | Fuente |
|---|---|---|
| PRY-200, PRY-202, PRY-210 | Nada: sus 27 documentos no cambiaron y no se releyeron | Hashes contra `meta.documents_seen` |

### Señales que levantó el cálculo (32 en los 10 proyectos nuevos)

Lo declarado por cada gerente y lo que sustentan los documentos van por separado.

- **PRY-211 (verde declarado, 48%)**: el verde queda contradicho por cuatro señales.
  - `rebaseline_unauthorized`: el cronograma v2 del 2026-10-14 mueve «Montaje e instalación» 70 días (2026-10-02 → 2026-12-11) y CC-01 sigue pendiente de comité: 70 días movidos, 0 autorizados.
  - `milestone_met_without_evidence`: 3 hitos cerrados sin acta (hace entre 103 y 282 días).
  - `progress_vs_plan`: declara 48%, el plan sustenta entre 75% y 100%.
  - `variance_time`: 70 días (19,6%) contra la línea base original.
- **PRY-203 (rojo declarado, 82%)**
  - `rebaseline_unauthorized`: 66 días movidos (cronograma v2 del 2026-10-13), 0 autorizados; CC-01 pendiente de presentación al comité.
  - `variance_cost`: proyección COP 966,3 M contra 800 M aprobados (+20,8%).
  - `variance_time`: 66 días (22,4%).
  - `milestone_met_without_evidence`: Ingeniería básica cerrada sin acta, hace 138 días. Ingeniería de detalle sí tiene acta (2026-10-08).
- **PRY-208 (verde declarado, 48%)**: el verde queda contradicho por tres señales.
  - `variance_time`: 110 días (21,4%), con CC-01 autorizada por el comité.
  - `progress_vs_plan`: declara 48%, el plan sustenta entre 75% y 100%.
  - `milestone_met_without_evidence`: Ingeniería básica (280 días) y Licencia y permisos (22 días) sin acta.
- **PRY-205 (verde declarado, 73%)**: `declared_vs_evidence` por dos hitos cerrados sin acta (Ingeniería básica, 184 días; Ingeniería de detalle, 56 días).
- **PRY-206 (verde declarado, 80%)**: `variance_cost`, proyección COP 7.518 M contra 6.800 M aprobados (+10,6%). `declared_vs_evidence` por esa razón.
- **PRY-204 (rojo declarado, 77%)**
  - `variance_time`: 61 días (31,4%), CC-01 autorizada.
  - `progress_vs_plan`: declara 77% con los 4 hitos cerrados (el plan sustenta 100%).
  - `milestone_met_without_evidence`: 3 de 4 hitos sin acta (hace entre 239 y 446 días).
  - `commitment_overdue`: Andrés Lozano, «Entregar el punto 18», vencido hace 9 días.
- **PRY-207 (amarillo declarado, 75%)**
  - `milestone_overdue`: «Licencia y permisos obtenidos» vencido hace 8 días.
  - `vendor_deliverable_late`: «Bolsa de horas de ingeniería» (CT-858), 33 días de atraso.
  - `milestone_met_without_evidence`: Ingeniería de detalle, 109 días.
  - `progress_vs_plan`: declara 75%, el plan sustenta entre 40% y 60%.
- **PRY-201 (amarillo declarado, 58%)**: `milestone_met_without_evidence`, Ingeniería básica, 86 días.
- **PRY-199 y PRY-209**: ninguna señal. PRY-209 no tiene cronograma, así que no hay contra qué medir atraso.

**Contradicciones y compromisos vencidos:** cuatro verdes contradichos por la evidencia (PRY-205, PRY-206, PRY-208 y PRY-211) y dos cambios de fecha sin autorizar (PRY-203 y PRY-211). Hay un compromiso vencido (PRY-204).

### Lo que los documentos dicen y la ficha no calcula
- **PRY-203 y PRY-205:** el informe declara comprometido menor que ejecutado (PRY-203: 339 M contra 389 M; PRY-205: 6.223 M contra 9.946 M). Lo registré tal cual, con nota; no lo corregí.
- **PRY-204:** el compromiso de Andrés Lozano lleva fecha 2026-10-07, anterior a la reunión donde se dijo (2026-10-13). No figura entre los asistentes.
- **PRY-199:** el informe dice que se recibió el permiso ambiental, pero el cronograma tiene «Licencia y permisos obtenidos» en curso, y a la vez el informe lista como riesgo un cambio en la licencia ambiental.
- **PRY-207:** la factura FV-1858 (COP 503.962.353, radicada) tiene el valor de un entregable, pero su concepto dice «Entregables del contrato CT-858» sin nombrarlo. Solo «Licenciamiento del software» tiene acta de recibo.
- **PRY-204 y PRY-208:** CC-01 dice «Autorizada por el comité» sin nombrar cuál ni la fecha.
- **Fechas de cierre:** para los proyectos con cronograma, la fecha de cierre calculada es la del último hito, no la del acta. Difieren en PRY-199 (2027-12-15 contra 2028-02-08), PRY-201, PRY-203, PRY-204, PRY-205, PRY-207, PRY-208 y PRY-211. Conviene confirmar cuál cuenta.

### No pude leer
| Archivo | Por qué |
|---|---|
| (ninguno) | Los 77 documentos se convirtieron a texto |

### Movidos desde entrada/
| Archivo | A qué proyecto | Por qué |
|---|---|---|
| (ninguno) | No existe carpeta `entrada/` en la documentación | |

### Pendientes de clasificar
| Archivo | Por qué no pude decidir |
|---|---|
| `PRY-200-mantenimiento-predictivo-de-camiones/2026-10-16-notas-reunion.txt` | Está fuera de `30-reuniones/`. Ya estaba leído en el arranque y no lo moví |

Además: en PRY-200, PRY-202 y PRY-210 no hubo cambios; hay una carpeta `estado/PRY-200-mantenimiento-predictivo-de-camiones/` previa a esta sesión que no toqué.

## Después

Hay más de un proyecto: puedo producir el informe consolidado (`/criterio-portfolio:portfolio-report`).

---
*criterio-portfolio 0.3.11 · fichas tocadas: 10 (PRY-199, 201, 203, 204, 205, 206, 207, 208, 209, 211) · campos en `not_found`: autoridad del gerente y etapa en los 10; producto en PRY-201, 205, 206, 209 y 211 («No aplica») · Términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.11*
