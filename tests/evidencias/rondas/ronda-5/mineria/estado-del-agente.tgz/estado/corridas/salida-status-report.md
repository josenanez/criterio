Ficha: `estado/records/PRY-207.json`, actualizada el 2026-10-16. Cifras recalculadas con `portafolio.py compute` el 2026-10-16.

## PRY-207 — Gemelo digital de la planta — estado al 2026-10-16

**Declara el gerente (Natalia Ospina):** amarillo · 75 % · al 2026-10-14 (2 días; vigente) — `20-seguimiento/2026-10-14-informe-avance.md`
**Sustento documental:** contradicho en parte (4 señales abiertas que el amarillo no explica)
**Lo que el semáforo no explica:** `milestone_met_without_evidence`, `milestone_overdue`, `progress_vs_plan`, `vendor_deliverable_late`
**Último documento:** 2026-10-15 (hace 1 día) · **Última reunión:** 2026-10-09 (comité semanal, hace 7 días)

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2027-04-26 | 2027-04-26 | 0 días (contra original y contra vigente) |
| Presupuesto | COP 9.500.000.000 (aprobado) | Proyección COP 9.553.085.251 | +0,6 % sobre lo aprobado (umbral 10 %) |

Replanificaciones: 0. No hay solicitudes de cambio. Solo existe la línea base v1 (acta de constitución, 2025-12-01).

Dinero (COP): comprometido 6.646.347.227 (70,0 %) · ejecutado 3.711.432.409 (39,1 %) · disponible real 2.853.652.773. Fuente: informe de avance del 2026-10-14.

### Hitos
| Hito | Base | Vigente | Estado | Evidencia |
|---|---|---|---|---|
| Ingeniería básica aprobada | 2026-03-21 | 2026-03-21 | cumplido | Acta de recibo (`2026-10-15-acta-recibo-ingeniería-básica-aprobada.pdf`), fechada 7 meses después del hito |
| Ingeniería de detalle aprobada | 2026-06-29 | 2026-06-29 | declarado cumplido | **Ninguna** (109 días) |
| Licencia y permisos obtenidos | 2026-10-08 | 2026-10-08 | pendiente | Vencido hace 8 días |
| Montaje e instalación | 2027-01-16 | 2027-01-16 | pendiente | — |
| Pruebas en operación | 2027-04-26 | 2027-04-26 | pendiente | — |

### Dónde no coincide
- **Avance:** el gerente declara 75 % (2026-10-14); los hitos cumplidos (2 de 5) sostienen entre 40 % y 60 %. La declaración está 15 puntos por encima de lo que el plan respalda. Además, se ha ejecutado el 39,1 % del presupuesto.
- **Ingeniería de detalle:** declarada cumplida, sin documento que lo pruebe.
- **Licencia y permisos:** vencida desde el 2026-10-08; el amarillo no la menciona como explicación.
- **Proveedor Automatización de Procesos Ltda. (CT-858):** 1 de 3 entregables aceptados (licenciamiento, acta del 2026-05-08). «Bolsa de horas de ingeniería» venció el 2026-09-13 (33 días), sin acta de recibo; el contrato la declara «en curso». Facturado COP 503.962.353 (FV-1858, 2026-09-06) = monto aceptado; la factura dice «Entregables del contrato CT-858» y no nombra el entregable.

### Abierto
**Riesgos e incidencias sin movimiento:** ninguno trae fecha de último movimiento ni responsable, así que los días sin movimiento no se pueden calcular.
- Riesgo: concentración del conocimiento en una sola persona.
- Riesgo: el proveedor no ha confirmado la fecha de la última entrega.
- Incidencia: dos semanas perdidas por rotación de un ingeniero clave.
- Incidencia: el primer ensayo de disponibilidad de equipos no alcanzó lo pactado y se repite.

**Compromisos vencidos:** ninguno. Hay uno abierto: Beatriz Cuéllar, «Entregar el punto 23», vence hoy 2026-10-16 (dicho el 2026-10-09). Ella no figura entre los asistentes al comité (Natalia Ospina, Jorge Medina).
**Dependencias sin confirmar:** ninguna registrada.

### Sin dato
- Autoridad de aprobación (`identity.authority`): no encontrada.
- Fase del proyecto (`identity.phase`): no encontrada.
- Probabilidad, impacto, responsable y fecha de los riesgos; fecha de inicio y responsable de las incidencias.
- Línea base de presupuesto distinta del aprobado: no hay; la desviación se mide contra el aprobado.

### Siguiente paso
La desviación en fecha y costo está por debajo del umbral (0 días; 0,6 %), pero hay un hito vencido, uno sin evidencia, un entregable de proveedor atrasado y un avance declarado sin respaldo. Puedo preparar el punto de comité (`/steering-pack`) si lo quieres.

---
Criterio Portafolio v0.3.11 · ficha PRY-207 actualizada el 2026-10-16 · campos inciertos: autoridad, fase, datos de RAID · Términos v1.1 aceptados por José Francisco Ñáñez el 2026-10-16: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.11
