Cierre de PRY-200 — Mantenimiento predictivo de camiones. Sale de la ficha `estado/records/PRY-200.json` y de estos documentos: acta de constitución (2025-06-03), cronograma v1 (2025-06-03), informe de avance (2026-10-14), tres actas de recibo (2026-10-02 y 2026-10-09), seis actas de comité (2026-09-04 a 2026-10-09) y las notas del 2026-10-16. Las cifras derivadas salen de `portafolio.py compute`. Los términos están vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-16).

## Cierre — PRY-200 Mantenimiento predictivo de camiones — 2026-10-16

**Resultado: el proyecto no está en condiciones de cerrarse contra lo pactado. Esta acta documenta por qué y qué falta. Si se cierra hoy, sería por decisión y no por cumplimiento.**

### Contra lo comprometido
**Criterio de éxito (sí fue declarado):** «Mantenimiento predictivo de camiones en producción y medido.» (acta de constitución, 2025-06-03).
**Se cumplió:** no se puede determinar, y la evidencia disponible apunta a que no.
- Ningún documento muestra el sistema en producción ni una medición.
- El informe de avance del 2026-10-14 declara 54 % de avance y estado amarillo. El script lo contrasta con el plan: los 4 hitos de 4 figuran cumplidos, que sustentan 100 %. La diferencia es de 46.0 puntos.
- El informe del 2026-10-14 dice que el primer ensayo de disponibilidad no alcanzó lo pactado y se repite. Esa es la única prueba de resultado que existe, y no se cumplió.

| Entregable comprometido | Estado | Evidencia |
|---|---|---|
| Componente 1 | Sin dato | El acta lista «Componente 1, 2 y 3» sin describirlos ni darles criterio de aceptación. Ningún documento los trata por separado. |
| Componente 2 | Sin dato | Igual que el 1. |
| Componente 3 | Sin dato | Igual que el 1. |
| Hito: Ingeniería básica aprobada (2025-09-26) | Declarado «cerrado» | Sin evidencia de cumplimiento (385 días desde su fecha). |
| Hito: Ingeniería de detalle aprobada (2026-01-09) | Declarado «cerrado» | Sin evidencia (280 días). |
| Hito: Licencia y permisos obtenidos (2026-04-25) | Declarado «cerrado» | Sin evidencia (174 días). |
| Hito: Montaje e instalación (2026-08-08) | Declarado «cerrado» | Sin evidencia (69 días). El informe del 2026-10-14 dice que las lluvias detuvieron el montaje diez días, lo que choca con darlo por cerrado. |

### Fuera de alcance final
| Qué quedó fuera | Decidido por | Cuándo |
|---|---|---|
| «Lo que otro proyecto cubre» (exclusión original del acta, sin concretar) | Acta de constitución | 2025-06-03 |

No hay registro de ningún recorte de alcance posterior: `changes` está vacío y no hay solicitudes de cambio. Tampoco hay decisión que reduzca el alcance. Como la exclusión del acta no nombra qué proyecto cubre qué, no se puede verificar que nada se haya caído por esa vía.

### Números finales
| | Original | Vigente | Final | Desviación vs original |
|---|---|---|---|---|
| Fecha de cierre (acta de constitución) | 2026-09-30 | 2026-09-30 | No hay: el proyecto sigue abierto | El script no la calculó |
| Fecha de cierre (cronograma v1) | 2026-08-08 | 2026-08-08 | No hay | El script reporta 0 días de atraso contra la original y contra la vigente |
| Presupuesto aprobado | 1.200.000.000 COP | Igual | Proyección al cierre: 1.175.719.466 COP | Proyección −2.0 % sobre lo aprobado |

Replanificaciones: 0. Hay una sola línea base (v1, 2025-06-03).

**El «0 días» del script no significa que no haya atraso.** Existe una sola línea base y nadie la movió, pero la fecha de cierre ya pasó (2026-08-08 o 2026-09-30, según qué documento valga) y el proyecto sigue abierto con 54 % declarado. El atraso real no está medido.

Ejecución del presupuesto, tal como el script la calculó:

| Concepto | COP | % del aprobado |
|---|---|---|
| Comprometido | 390.173.338 | 32.5 % |
| Ejecutado | 438.812.017 | 36.6 % |
| Disponible real | 809.826.662 | — |

El ejecutado es mayor que el comprometido. Eso no cuadra y el informe no lo explica. Además, la proyección al cierre (1.175.719.466 COP) es casi igual al aprobado con una ejecución de 36.6 % y un plazo vencido; el informe no explica cómo se llega a ella.

### Contradicciones entre documentos
- **Fecha de cierre:** el acta de constitución dice 2026-09-30 y el cronograma v1 dice 2026-08-08. Ambos son del 2025-06-03 y no hay cuál prevalezca. Se pide que el sponsor diga cuál es la línea base.
- **Hitos:** el cronograma los marca todos como «cerrado» y el informe de avance declara 54 %. Las dos cosas no pueden ser ciertas a la vez.

### RAID al cierre
**Materializados:**
- Las lluvias detuvieron el montaje diez días (informe 2026-10-14). Sin responsable ni fecha de inicio.
- El primer ensayo de disponibilidad no alcanzó lo pactado y se repite (informe 2026-10-14). Sin responsable.

**No materializados:** ninguno confirmado. El registro de riesgos nunca tuvo probabilidad, impacto ni responsable en ninguno de sus riesgos.

**Abiertos, y ninguno tiene doliente:** por eso el cierre no puede declararse.
- Riesgo: el proveedor no ha confirmado la fecha de la última entrega (informe 2026-10-14). Sin responsable.
- Riesgo: el proveedor podría no llegar con el equipo completo para la siguiente fase. Se comentó el 2026-10-16 y nadie lo registró. Sin responsable.
- Incidencia: el ensayo de disponibilidad se repite. Sin responsable ni fecha.
- Compromisos abiertos (los 23 que la ficha tiene como `open`; 6 vencidos según el script):
  - Vencidos, según el script: Sandra Gil, *Validar el ambiente 4* (12 días); Liliana Torres, *Aprobar el diseño 5* (12 días); Andrés Lozano, *Entregar el punto 8* (3 días); Jorge Medina, *Entregar el punto 16* (4 días); Diana Molina, *Validar el ambiente 20* (1 día); Javier Hoyos, *Confirmar la fecha 23* (3 días).
  - Tres de los vencidos (Torres, Lozano, Medina) dijeron el 2026-10-02 que ya habían entregado. No hay acta de recibo de ninguno.
  - Reprogramados: Elena Duarte, *Enviar el documento 1*, 6 veces (original 2026-09-19, hoy 2026-12-12); Diana Molina, *Cerrar la prueba 2*, 5 veces (original 2026-09-15, hoy 2026-11-14); Óscar Ramírez, *Revisar el anexo 3*, 3 veces, cerrado con acta el 2026-10-09; Javier Hoyos, *Confirmar la fecha 7*, 3 veces.
  - Sin fecha: Gustavo Neira, *Cerrar la prueba 18* («por definir» en dos reuniones seguidas); Laura Vélez, *Mandar el ajuste del presupuesto* («la otra semana»).
- Proveedor: la ficha no tiene contratos ni entregables de proveedor registrados (`vendors` vacío), aunque el informe y las notas hablan de un proveedor que debe entregar. Es un vacío para la facturación y la aceptación.

### Lecciones
Solo entran las que se anclan a un hecho documentado.

| Qué pasó | Cuándo | Efecto | Qué haríamos distinto |
|---|---|---|---|
| El acta y el cronograma se firmaron el mismo día con dos fechas de cierre distintas: 2026-09-30 y 2026-08-08. | 2025-06-03 | Hoy no se puede medir el atraso, porque no hay una sola fecha de referencia. | Revisar el acta contra el cronograma antes de aprobar la línea base. |
| Los 4 hitos figuran «cerrado» sin ninguna acta de aceptación, mientras el avance declarado es 54 %. | Fechas de hito: 2025-09-26, 2026-01-09, 2026-04-25 y 2026-08-08; informe 2026-10-14 | El tablero muestra 100 % de hitos con un proyecto que no ha terminado. Los hitos no sirven para medir. | Exigir un acta de recibo para cada hito antes de marcarlo cumplido. |
| Compromisos reprogramados en cadena sin que nadie decida: «Enviar el documento 1» se movió 6 veces en 6 semanas, del 2026-09-19 al 2026-12-12. | Del 2026-09-04 al 2026-10-16 | La fecha actual queda casi tres meses después de la original y se sigue moviendo. | Escalar al comité al tercer cambio de fecha. |
| El primer ensayo de disponibilidad no alcanzó lo pactado. | Informe 2026-10-14 | El criterio de éxito del acta («en producción y medido») no se cumple. | Sin dato: el informe no dice cuándo ni por qué falló, y no se puede extraer más. |

No se incluye como lección ninguna sobre las lluvias ni sobre el proveedor: los documentos las mencionan sin fecha de inicio ni efecto en el plan, y una lección sin esos datos no se puede sustentar.

### Sin dato
- Si el sistema está en producción y qué se midió. Es lo que dice el criterio de éxito.
- Qué son los componentes 1, 2 y 3, y cuáles se entregaron.
- Cuál de las dos fechas de cierre (2026-08-08 o 2026-09-30) vale.
- Fecha real de terminación y atraso real.
- Evidencia de aceptación de los 4 hitos.
- Por qué lo ejecutado (438.812.017) supera lo comprometido (390.173.338), y de dónde sale la proyección de 1.175.719.466.
- Responsable de cada riesgo e incidencia abierta; probabilidad e impacto de los riesgos.
- Contrato(s) de proveedor, entregables y facturación.
- Quién es la autoridad del proyecto y su fase (campos no encontrados en la ficha).
- Qué cubre el «otro proyecto» de la exclusión del alcance.
- La ficha tiene 16 meses de antigüedad en los campos de identidad y plan (acta del 2025-06-03).

### Qué haría falta para cerrar de verdad
1. El sponsor (Andrés Lozano) fija la fecha de cierre válida, entre 2026-08-08 y 2026-09-30.
2. Evidencia de producción y medición, o una decisión explícita del comité de cerrar sin cumplir el criterio.
3. Actas de aceptación de los 4 hitos, o la corrección del cronograma.
4. Un doliente con nombre para cada riesgo e incidencia abiertos, y para los 23 compromisos abiertos.
5. Aclarar la diferencia entre ejecutado y comprometido.

### Después
No muevo la carpeta a `archivo/` ni congelo la ficha: el proyecto sigue en ejecución y, si lo saco del barrido diario, quedarían sin seguimiento 6 compromisos vencidos y 3 riesgos/incidencias sin doliente. Dejo la oferta de archivarlo para cuando se resuelvan los puntos anteriores.

---
Rigor: toda cifra derivada viene de `portafolio.py compute` del 2026-10-16. Las demás son lectura directa de los documentos citados. Ninguna lección se infirió sin un hecho fechado. Lo que no se pudo determinar está en «Sin dato». Revisar contra los originales antes de actuar: esto es un borrador de trabajo.
