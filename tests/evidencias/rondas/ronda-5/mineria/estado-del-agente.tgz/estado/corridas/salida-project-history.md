## Historia · PRY-210 Programa de relacionamiento comunitario · 2026-05-11 a 2026-10-16

**Leí:** 7 documentos entre 2026-05-11 y 2026-10-16 (acta de constitución, cronogramas v1 y v2, informe de avance, acta de recibo, comité semanal, solicitud de cambio CC-01). Fecha de cada uno: la del nombre del archivo; la fecha de modificación en disco es 2026-10-16 para todos y no sirve para ordenar.
**Trimestres sin un solo documento:** 2026-T3 (julio a septiembre). Entre el 2026-05-11 y el 2026-10-14 no hay ningún documento fechado.

### En una línea
El proyecto nació el 2026-05-11 con cierre comprometido al 2027-08-31 y una línea base de cinco hitos que terminaba el 2027-07-19. Después de cinco meses sin documentos, entre el 2026-10-14 y el 2026-10-16 aparecen seis a la vez: un cronograma v2 que mueve el último hito al 2027-08-21 (33 días), un informe que declara verde con 72% de avance, y una solicitud de cambio CC-01 con ese mismo corrimiento de 33 días, todavía sin autorización. El plan ya se movió antes de que el cambio se presentara.

### Las cuatro cifras
| Replanificaciones | Atraso acumulado vs. original | Meses declarando sin sustento | Cambios de gobierno |
|---|---|---|---|
| 1 | 33 días (7,8 %) | No calculable: hay un solo estado declarado (2026-10-14), no una serie | 0 |

### Línea de tiempo
| Fecha | Documento | Qué cambió |
|---|---|---|
| 2026-05-11 | `00-gobierno/2026-05-11-acta-constitucion.docx` | Se constituye el proyecto. Patrocinador Carlos Peña, gerente Laura Vélez, Comité Ambiental. Presupuesto 3.300.000.000 COP. Inicio 2026-05-21, cierre 2027-08-31. |
| 2026-05-11 | `10-plan/2026-05-11-cronograma-v1.xlsx` | Línea base: cinco hitos, el último (Pruebas en operación) el 2027-07-19. |
| 2026-05-11 a 2026-10-13 | (ninguno) | Sin documentos. |
| 2026-10-14 | `10-plan/2026-10-14-cronograma-v2.xlsx` | Pruebas en operación pasa de 2027-07-19 a 2027-08-21. Los otros cuatro hitos no cambian. |
| 2026-10-14 | `20-seguimiento/2026-10-14-informe-avance.md` | Gerente declara Verde, 72 % de avance. Dice que "se reprogramó la parada de planta por la ventana de mantenimiento". |
| 2026-10-15 | `20-seguimiento/2026-10-15-acta-recibo-ingeniería-básica-aprobada.pdf` | Laura Vélez recibe a satisfacción Ingeniería básica aprobada (línea base 2026-08-13). |
| 2026-10-15 | `30-reuniones/2026-10-15-comite-semanal.md` | Asisten Laura Vélez y Carlos Peña. Un compromiso de Paula Céspedes sin fecha. |
| 2026-10-16 | `20-seguimiento/2026-10-16-solicitud-cambio-cc-01.md` | CC-01: ampliación de alcance, +33 días y +66.000.000 COP. "Pendiente de presentación al comité." |

### Replanificaciones
| Nº | Fecha | Fecha de cierre nueva | Motivo declarado | Documento que la aprobó |
|---|---|---|---|---|
| 1 | 2026-10-14 (fecha del cronograma v2) | 2027-08-21 (último hito; antes 2027-07-19) | Dos que no coinciden: el informe del 2026-10-14 habla de la parada de planta; CC-01 habla de ampliación de alcance | **Ninguno.** CC-01 sigue pendiente de comité; el script cuenta 33 días movidos y 0 autorizados |

La fecha 2027-08-21 queda diez días antes del cierre del acta (2027-08-31). Dentro de ese cierre, pero la línea base de hitos sí se corrió.

### Gobierno
Sin cambios de patrocinador, gerente ni comité en los documentos leídos. Carlos Peña y Laura Vélez aparecen en el acta y en el comité del 2026-10-15.

### Compromisos que se repitieron
Ninguno se repite. Hay uno solo, sin fecha ("por definir"):

| Doliente | Qué | Veces | Fechas prometidas |
|---|---|---|---|
| Paula Céspedes | Entregar el punto 35 | 1 | Ninguna |

Paula Céspedes no figura como asistente del comité del 2026-10-15. Además, el acta no dice qué es el "punto 35".

### Desde cuándo lo declarado no se sostiene
- **Fecha:** 2026-10-14, el único estado declarado que hay. No puedo hablar de deslizamiento: no hay estados anteriores contra los cuales ver cuándo empezó.
- **Qué se declaró:** Verde y 72 %. El plan sostiene entre 20 y 40 %, con 1 de 5 hitos cumplido. Diferencia: 32 puntos por encima del techo.
- **Primer hito sin evidencia:** ninguno. El único hito cerrado (Ingeniería básica aprobada) sí tiene acta de recibo, pero fechada 2026-10-15, después del informe que declara 72 %, y con la fecha de línea base en 2026-08-13.
- **Qué se siguió reportando:** presupuesto con proyección al cierre de 3.118.748.068 COP (5,5 % por debajo del aprobado), aunque CC-01 pide 66.000.000 COP adicionales. No sé si la proyección los incluye.
- El informe verde no menciona la replanificación de 33 días ni la CC-01.

### Lecciones ancladas a un hecho
1. **El plan se movió antes que la solicitud.** Hecho: el cronograma v2 es del 2026-10-14 y CC-01 es del 2026-10-16 y sigue sin autorizar. Efecto: la línea base cambió sin pasar por el comité (33 días, 0 autorizados).
2. **El motivo no es el mismo en dos documentos.** Hecho: informe del 2026-10-14 (parada de planta) vs. CC-01 del 2026-10-16 (ampliación de alcance). Efecto: el comité va a decidir sobre un motivo que no es el que el gerente reportó.
3. **Cinco meses sin papel.** Hecho: ningún documento entre 2026-05-11 y 2026-10-14. Efecto: no se puede reconstruir cuándo cambió el plan ni cuándo se avanzó; solo se ve el resultado.
4. **Un compromiso sin fecha no vence.** Hecho: "por definir" en el comité del 2026-10-15. Efecto: nada que revisar en el siguiente.

### Qué no sé
- Qué se habló fuera de estos documentos, incluida la ventana de parada de planta.
- Por qué el cronograma v1, fechado 2026-05-11, ya marca "cerrado" el hito del 2026-08-13: puede ser una versión editada después sin cambiar el nombre. No puedo confirmarlo.
- Si hubo documentos anteriores al 2026-10-14 que no están en la carpeta.
- Ficha y registros: las cifras vienen de la salida de `compute` de hoy; las fechas, de los documentos citados.

### Nota
Nada de esto dice por qué ocurrió ni quién lo decidió. Que el plan se moviera antes de la solicitud puede ser un orden de papeles y no una intención. Esa conversación la tiene una persona, y esta historia sirve para tenerla con fechas. Si sirve, puedo llevarla al comité para la decisión de CC-01, o al cierre del proyecto cuando llegue. La verificación de cada dato contra su documento es suya.
