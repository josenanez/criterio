# Corrida del 2026-10-16 · vendor-tracking

13 proyectos · 41 s · 58 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 19 |
| `progress_vs_plan` | 7 |
| `commitment_overdue` | 7 |
| `declared_vs_evidence` | 6 |
| `commitment_rescheduled` | 4 |
| `variance_time` | 4 |
| `commitment_undated` | 3 |
| `rebaseline_unauthorized` | 3 |
| `variance_cost` | 2 |
| `pm_vs_pmo` | 1 |
| `milestone_overdue` | 1 |
| `vendor_deliverable_late` | 1 |

Proveedor CT-858 de PRY-207: 1 de 3 entregables aceptado con acta; bolsa de horas vencida 33 días sin evidencia; factura FV-1858 no nombra el entregable y no se puede atribuir. Sin dato: vigencia, renovación y preaviso del contrato; entregable que cubre la factura.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

Documentos de los que sale: la ficha `estado/records/PRY-207.json` y la salida de `portafolio.py compute` (corte 2026-10-16), y los originales de PRY-207: contrato CT-858 (`00-gobierno/2025-12-10-contrato-ct-858.docx`), acta de recibo del licenciamiento (`20-seguimiento/2026-05-08-…pdf`), factura FV-1858 (`20-seguimiento/2026-09-06-factura-ct-858.pdf`), informe de avance (`20-seguimiento/2026-10-14-informe-avance.md`), acta de recibo de ingeniería básica (`20-seguimiento/2026-10-15-…pdf`) y comité del 2026-10-09 (`30-reuniones/`).

## Proveedores — PRY-207 Gemelo digital de la planta al 2026-10-16

### Automatización de Procesos Ltda. — contrato CT-858
**Vigencia:** firmado 2025-12-10; fecha de fin no declarada · **Preaviso de no renovación:** no declarado · **Vence el:** sin dato (el último entregable está comprometido para 2027-01-29)

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento del software | 2026-04-28 | accepted | Acta de recibo 2026-05-08, firmada por Natalia Ospina (gerente) | 503.962.353 COP (ver abajo: la factura no lo nombra) |
| Bolsa de horas de ingeniería | 2026-09-13 | pending (el contrato lo declara «en curso») | Ninguna | No identificable |
| Calibración de sensores | 2027-01-29 | pending (el contrato lo declara «en curso») | Ninguna | No identificable |

Cada entregable vale 503.962.353 COP. Facturado total: 503.962.353 COP (compute); aceptado: 503.962.353 COP. Entregables: 3; aceptados: 1; tarde: 1.

### Dónde no cuadra
| Qué | Dice el contrato | Dice la evidencia | Fuentes |
|---|---|---|---|
| Factura FV-1858 (2026-09-06) | Cada entregable se factura contra acta de recibo firmada por el gerente | La factura dice «Entregables del contrato CT-858» y no nombra el entregable. Su valor coincide con el del licenciamiento (aceptado el 2026-05-08), pero los tres entregables valen lo mismo, así que el monto no prueba a cuál corresponde. Se radicó 7 días antes de la fecha de la bolsa de horas (2026-09-13), que no tiene acta. | contrato CT-858; factura FV-1858; acta de recibo 2026-05-08 |

El script no levanta `vendor_invoiced_without_delivery`: hay un entregable aceptado y el monto facturado no lo excede. Lo que no se puede afirmar es que la factura sea del licenciamiento. Hay que pedirle a cuentas por pagar el desglose de FV-1858.

### Sin evidencia de recibo
| Entregable | Marcado como | Desde |
|---|---|---|
| Ninguno del proveedor: el único entregable aceptado tiene acta | — | — |

Fuera del proveedor, pero relacionado: el hito «Ingeniería de detalle aprobada» (2026-06-29) figura como cumplido y no tiene acta ni otro documento que lo pruebe (109 días). No se sabe si es entregable de CT-858.

### Entregables vencidos del proveedor
| Qué | Vencía | Días | Estado |
|---|---|---|---|
| Bolsa de horas de ingeniería | 2026-09-13 | 33 | pending, sin evidencia y sin declarar entrega |

El informe de avance del 2026-10-14 dice que «el proveedor no ha confirmado la fecha de la última entrega». No dice cuál es.

### Compromisos del proveedor vencidos
Ninguno. El único compromiso abierto es de Beatriz Cuéllar («Entregar el punto 23», comité del 2026-10-09, para el 2026-10-16). Vence hoy, no está vencido. La minuta no la lista entre los asistentes y no dice si es del proveedor ni de qué contrato; no lo asumo.

### Sin dato
- Vigencia, fecha de terminación, renovación automática y preaviso del contrato CT-858: el documento no los trae. No puedo decir si hay un preaviso por vencer.
- Qué entregable cubre FV-1858.
- Si la persona que debe entregar «el punto 23» pertenece al proveedor.
- Fecha de entrega comprometida para «la última entrega» según el proveedor.

### Contexto del proyecto (no es del proveedor)
El avance declarado es 75% y el plan sostiene entre 40% y 60% (2 de 5 hitos cumplidos). El hito «Licencia y permisos obtenidos» lleva 8 días vencido (2026-10-08). El acta de ingeniería básica es del 2026-10-15, para un hito de 2026-03-21.

## Después
- Pedir a cuentas por pagar el soporte de FV-1858 antes de aprobar el pago. Si corresponde a la bolsa de horas, se facturó sin acta y habría que llevarlo a comité.
- Pedir al proveedor la fecha de la bolsa de horas, vencida hace 33 días.
- Conseguir el contrato completo, o su anexo de vigencia, para revisar el preaviso.

*Pie de rigor: borrador de trabajo hecho con los documentos citados. No sé lo que se haya hablado fuera de ellos. Las cifras salen de `portafolio.py compute`. La verificación es de quien lo lea.*
