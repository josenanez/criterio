# Corrida del 2026-10-16 · document-index

13 proyectos · 13 s · 58 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 19 |
| `progress_vs_plan` | 7 |
| `commitment_overdue` | 7 |
| `declared_vs_evidence` | 6 |
| `commitment_rescheduled` | 4 |
| `variance_time` | 4 |
| `commitment_undated` | 3 |
| `rebaseline_unauthorized` | 3 |
| `variance_cost` | 2 |
| `pm_vs_pmo` | 1 |
| `milestone_overdue` | 1 |
| `vendor_deliverable_late` | 1 |

77 documentos, todos sin cambio; 0 por releer, 0 citas rotas. El índice no reporta formatos ilegibles, así que no se afirma nada sobre ellos.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

Carpeta al 2026-10-16: 77 documentos, 77 sin cambio, 0 por releer, 0 citas rotas. No hay nada que hacer; no se produce nada más.
