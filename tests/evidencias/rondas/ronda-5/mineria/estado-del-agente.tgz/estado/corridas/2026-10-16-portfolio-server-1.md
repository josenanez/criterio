# Corrida del 2026-10-16 · portfolio-server

13 proyectos · 58 hallazgos

> El tiempo no se midió: faltó `corrida-inicio` al arrancar. Un tiempo escrito a mano es un recuerdo, no una medición.

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 19 |
| `progress_vs_plan` | 7 |
| `commitment_overdue` | 7 |
| `declared_vs_evidence` | 6 |
| `commitment_rescheduled` | 4 |
| `variance_time` | 4 |
| `commitment_undated` | 3 |
| `rebaseline_unauthorized` | 3 |
| `variance_cost` | 2 |
| `pm_vs_pmo` | 1 |
| `milestone_overdue` | 1 |
| `vendor_deliverable_late` | 1 |

puerto 8787, carpeta del informe reportes, modo rato

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

# /portfolio-server — Rostrum, modo «para mirarlo un rato»

**Términos:** ya estaban vigentes (versión de la familia 0.3.11, términos 1.1), aceptados por José Francisco Ñáñez el 2026-10-16. No hizo falta pedirlos de nuevo.

**Forma elegida:** «para mirarlo un rato» (argumento `rato`). Nadie tiene que pedirle nada a seguridad: se levanta, se mira y se apaga con Ctrl-C. Lo que se pierde es que el patrocinador no tiene un enlace que funcione mañana. Si más adelante quiere que quede corriendo, se usa `--abierto` y hay que pedirle a la organización un host con puerto y publicarlo detrás de su control de acceso, porque el servidor no autentica.

**Informe:** existe en `reportes/` (13 proyectos PRY-199 a PRY-211, `index.html`, `decisiones.html`, `proyectos.html`, `productos.html` y 6 páginas de producto), generado el 2026-10-16 a las 12:45.

**Qué se levanta:** `servidor.py --informe reportes --estado estado --config .criterio/portafolio/config.json`, escuchando en `127.0.0.1:8787`, solo en este equipo.

| Ruta | Qué es | Para quién |
|---|---|---|
| `/` | Portada y formulario de peticiones | Todos |
| `/pmo` | Cómo va el portafolio | La PMO |
| `/decisiones` | Lo que necesita una decisión | Comité y patrocinador |
| `/proyectos` | Listado por atención | Todos |
| `/p/<código>` | Informe de un proyecto | Quien gerencia |
| `/productos`, `/producto/<nombre>` | Productos y los proyectos que los construyen | Quien responde por un producto |
| `/estado.json` | Fecha del informe y peticiones abiertas | Un mecanismo |

**Lo que Rostrum no hace:** no calcula (sirve lo que `informe.py` ya escribió), no escribe fichas (solo crea la petición en `estado/peticiones/`), no autentica y no manda correos. El formulario no despierta al agente: la petición espera hasta que `due` la cuente.

**Cierre:** el enlace `http://127.0.0.1:8787` solo sirve en este equipo, para mirar con alguien al lado. Al patrocinador no se le pasa ningún enlace en este modo. Cuando se publique, el informe estará desactualizado desde el momento en que cambie un documento posterior al 2026-10-16 12:45, y la portada lo dice con la fecha del informe.
