# Corrida del 2026-10-16 · product-view

13 proyectos · 48 s · 58 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 19 |
| `progress_vs_plan` | 7 |
| `commitment_overdue` | 7 |
| `declared_vs_evidence` | 6 |
| `commitment_rescheduled` | 4 |
| `variance_time` | 4 |
| `commitment_undated` | 3 |
| `rebaseline_unauthorized` | 3 |
| `variance_cost` | 2 |
| `pm_vs_pmo` | 1 |
| `milestone_overdue` | 1 |
| `vendor_deliverable_late` | 1 |

Producto con un solo proyecto (PRY-200), sin sección de producto. 18 señales. No hay dependencias declaradas. 7 proyectos con producto 'No aplica'. No leí los documentos fuente, solo fichas y cálculo.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

# Producto «monitoreo de flota» al 2026-10-16

**Fuentes:** fichas en `estado/records` (13 proyectos) y cálculo de `portafolio.py compute` con fecha 2026-10-16. Términos vigentes: aceptados por José Francisco Ñáñez el 2026-10-16 (v1.1, plugin 0.3.11).

**«Monitoreo de flota» tiene un solo proyecto, PRY-200 (Mantenimiento predictivo de camiones).** La vista por producto no aporta nada aquí, así que no armo sección de producto. Dejo el estado de ese proyecto en una tabla.

| Producto | Proyectos | Con alertas | Fecha más tardía | Aprobado | Comprometido |
|---|---|---|---|---|---|
| monitoreo de flota | 1 (PRY-200) | 18 señales | 2026-08-08 (ya vencida) | COP 1.200.000.000 | COP 390.173.338 |

Las cuatro cifras de dinero están completas (1 de 1 proyecto): aprobado 1.200.000.000, comprometido 390.173.338, ejecutado 438.812.017 y proyección 1.175.719.466, todo en COP.

## Lo que hay que ver en PRY-200 (18 señales)

- **Avance frente al plan:** declara 54 %, pero los 4 hitos del plan figuran cumplidos y el plan respalda 100 %. La brecha es de 46 puntos y el proyecto va por detrás.
- **Hitos cumplidos sin evidencia (4):** Ingeniería básica (vencía 2025-09-26, hace 385 días), Ingeniería de detalle (2026-01-09, 280 días), Licencia y permisos (2026-04-25, 174 días) y Montaje e instalación (2026-08-08, 69 días).
- **Compromisos vencidos sin evidencia (6):**
  - Sandra Gil, «Validar el ambiente 4»: venció el 2026-10-04, hace 12 días.
  - Liliana Torres, «Aprobar el diseño 5»: venció el 2026-10-04, hace 12 días.
  - Andrés Lozano, «Entregar el punto 8»: venció el 2026-10-13, hace 3 días.
  - Jorge Medina, «Entregar el punto 16»: venció el 2026-10-12, hace 4 días.
  - Diana Molina, «Validar el ambiente 20»: venció el 2026-10-15, hace 1 día.
  - Javier Hoyos, «Confirmar la fecha 23»: venció el 2026-10-13, hace 3 días.
- **Compromisos reprogramados (4):**
  - Elena Duarte, «Enviar el documento 1»: 6 veces, de 2026-09-19 a 2026-12-12.
  - Diana Molina, «Cerrar la prueba 2»: 5 veces, de 2026-09-15 a 2026-11-14.
  - Óscar Ramírez, «Revisar el anexo 3»: 3 veces.
  - Javier Hoyos, «Confirmar la fecha 7»: 3 veces.
- **Compromisos sin fecha (2):** Gustavo Neira, «Cerrar la prueba 18», y Laura Vélez, «Mandar el ajuste del presupuesto» (en las notas de reunión del 2026-10-16).
- **El gerente y la PMO no coinciden en la fecha de fin del plan:** el cronograma v1 (PMO) dice 2026-08-08 y el acta de constitución (gerente) dice 2026-09-30. Ambas fuentes son del 2025-06-03 y ninguna es más nueva, así que no puedo decir cuál manda. **Las dos fechas ya pasaron y el proyecto declara 54 %.**
- **Dinero:** lo ejecutado (438.812.017) supera lo comprometido (390.173.338). No sé por qué, porque la ficha no lo explica. Hay que preguntar si falta registrar compromisos o si se ejecutó sin comprometer.

## Dependencias internas
Ninguna. Es un solo proyecto y su ficha no declara dependencias (campo vacío). Esto no prueba que no existan, solo que ningún documento las menciona. Con otros productos tampoco hay dependencias declaradas que se puedan cruzar.

## Fecha comprometida del producto
2026-08-08 según el plan de la PMO, y 2026-09-30 según el acta del gerente. Las dos salen de PRY-200. Hoy ninguna se sostiene.

## Proyectos sin producto declarado (hallazgo de gobierno)
Siete proyectos no entran en ninguna vista por producto, porque su acta dice «No aplica» como producto al que sirven. No es que falte el dato: lo declaran como ausente.

| Proyecto | Área dueña |
|---|---|
| PRY-201 Ampliación de la relavera | Logística |
| PRY-202 Planta de tratamiento de agua | Mina |
| PRY-205 Sistema de gestión de seguridad | Tecnología |
| PRY-206 Red privada LTE en mina | Tecnología |
| PRY-209 Electrificación de equipos | Mina |
| PRY-210 Programa de relacionamiento comunitario | Medio Ambiente |
| PRY-211 Control de polvo en vías | Seguridad y Salud |

Consecuencia: nadie puede responder por el conjunto al que sirven. Hay que decidir si de verdad no sirven a ningún producto o si el acta se llenó por salir del paso. Cifras del portafolio, tal como las da el cálculo: 13 proyectos, 11 con alertas, 58 señales, 6 en verde contradichos por la evidencia y ninguno con autoridad de aprobación declarada (`no_authority` = 13).

*Rigor:* las cifras vienen de `compute` al 2026-10-16. Las citas de cada señal están en las fichas. Esto es un borrador de trabajo y la verificación es de quien lo lee. No vi los documentos fuente en esta corrida, solo las fichas y el cálculo.
