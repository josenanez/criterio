# Corrida del 2026-10-16 · health-check

13 proyectos · 74 s · 58 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 19 |
| `progress_vs_plan` | 7 |
| `commitment_overdue` | 7 |
| `declared_vs_evidence` | 6 |
| `commitment_rescheduled` | 4 |
| `variance_time` | 4 |
| `commitment_undated` | 3 |
| `rebaseline_unauthorized` | 3 |
| `variance_cost` | 2 |
| `pm_vs_pmo` | 1 |
| `milestone_overdue` | 1 |
| `vendor_deliverable_late` | 1 |

Diagnóstico PRY-211: 3 sostenidas, 11 sin sustento, 2 contradichas. Verde contradicho por cambio de línea base de 70 días sin autorizar; dijo no saber autoridad, motivo del v2, alcance de CC-01, respaldo del dinero ni evidencia de 3 hitos cerrados.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

## Diagnóstico · PRY-211 Control de polvo en vías · 2026-10-16

**Leí:** 6 documentos · de 2025-09-30 a 2026-10-15 · formatos: md (4), csv (1), xlsx (1; leído por su texto convertido en caché, la cita apunta al original)
**No pude leer:** nada quedó sin leer. Busqué «PRY-211» en el resto de `documentos/`: ninguna minuta de otro proyecto lo menciona, así que no hay más fuentes.

*Términos vigentes (v1.1), aceptados por José Francisco Ñáñez el 2026-10-16. Criterio produce borradores de trabajo, no decisiones; la verificación de cada cita es de quien lee.*

### Dictamen
**Sostenido:** 3 afirmaciones · **Sin sustento:** 11 · **Contradicho:** 2

El informe del 2026-10-14 declara **verde** con 48 % de avance, y la carpeta no lo sostiene. El mismo día se publicó un cronograma v2 que mueve el montaje del 2026-10-02 al 2026-12-11 (70 días sobre la línea base original, 19.6 %). La solicitud CC-01 que lo justificaría figura «pendiente de presentación al comité», y el comité del 2026-10-15 no registra ninguna decisión. Los tres hitos cerrados no tienen acta de recibo. Todas las cifras de dinero salen solo del informe del gerente. Desde esta carpeta se puede afirmar quién gobierna el proyecto, cuál fue el presupuesto aprobado y que hay un cambio de fechas sin autorización. No se puede afirmar que el proyecto esté en verde, ni cuánto se ha ejecutado de verdad, ni que la ingeniería y la licencia estén cerradas.

### Gobierno
| | Qué dice el documento | Fuente |
|---|---|---|
| Patrocinador | Javier Hoyos | `00-gobierno/2025-09-30-acta-constitucion.md` |
| Gerente | Elena Duarte | `00-gobierno/2025-09-30-acta-constitucion.md` |
| Autoridad declarada | **No declarada.** El acta no dice qué puede aprobar el gerente ni hasta qué monto o días. Sin autoridad declarada, el cambio de fechas no tiene quién lo haya aprobado. | — |
| Comité | Comité de Operaciones; aprobó el presupuesto el 2025-09-30. Sesionó el 2026-10-15 con Elena Duarte y Javier Hoyos; los temas son «Avance» y «Compromisos», sin contenido, sin decisión sobre CC-01. | acta; `30-reuniones/2026-10-15-comite-semanal.md` |

Además, el acta tiene el alcance en blanco («Componente 1, 2, 3») y una exclusión genérica («Lo que otro proyecto cubre»). Con eso no se puede decir qué amplía CC-01.

### Contra el plan
- **Línea base original (v1, 2025-09-30, acta):** montaje e instalación 2026-10-02. Cierre comprometido en el acta: 2026-11-16.
- **Línea base vigente (v2, 2026-10-14):** montaje e instalación 2026-12-11. Los otros tres hitos no cambian.
- **Replanificaciones:** 1. **Motivo: no figura en ningún documento.** El v2 no lo dice.
- **Desviación contra la original:** 70 días, 19.6 % (umbral 10 %). Contra la vigente: 0 días, porque la vigente ya absorbió el atraso.
- **Autorizado:** 0 de 70 días. CC-01 pide +70 días y está pendiente.
- **Avance contra el plan:** el informe declara 48 %. Con 3 de 4 hitos cerrados según el cronograma, el plan sostiene entre 75 % y 100 %, una diferencia de 27.0 puntos. Una de las dos cifras está mal, y la carpeta no dice cuál.
- **Lo que explica el informe:** diez días de lluvia, un hallazgo de auditoría y un ensayo de disponibilidad repetido. Eso no explica 70 días y no tiene documento de respaldo.

### Hitos vencidos sin evidencia
| Hito | Fecha | Días | Qué documento se esperaría |
|---|---|---|---|
| Ingeniería básica aprobada (cerrado) | 2026-01-07 | 282 | Acta de recibo de la aprobación de ingeniería básica |
| Ingeniería de detalle aprobada (cerrado) | 2026-04-06 | 193 | Acta de recibo de la aprobación de ingeniería de detalle |
| Licencia y permisos obtenidos (cerrado) | 2026-07-05 | 103 | Licencia o resolución de la autoridad, con acta de recibo |

Los días se cuentan desde la fecha del hito hasta hoy. El montaje, en curso, tenía fecha original 2026-10-02 y ya pasó; con la fecha vigente 2026-12-11 no figura vencido. Eso solo es así por el cambio sin autorizar.

### Dinero
| Aprobado | Comprometido | Ejecutado | Proyección | Disponible real |
|---|---|---|---|---|
| 800.000.000 COP | 479.425.244 COP (59.9 %) | 262.125.757 COP (32.8 %) | 835.519.093 COP (4.4 % sobre lo aprobado) | 320.574.756 COP |

Fuente de comprometido, ejecutado y proyección: solo el informe del 2026-10-14, que es declaración del gerente. Ningún documento de contabilidad ni de compras los respalda. La proyección ya supera lo aprobado, sin que el 4.4 % cruce el umbral del 10 %. CC-01 pide 140.000.000 COP adicionales, sin autorizar; el informe no lo menciona.

### Lo que se dijo y nadie registró
- **Compromiso:** Rubén Cárdenas, «Entregar el punto 17», para 2026-10-17 (acta 2026-10-15). No venció aún. No hay forma de saber qué es el «punto 17», y el responsable no asistió a esa reunión.
- **Incidencias** solo en el informe, sin responsable ni fecha de inicio: lluvias (10 días de montaje detenido), hallazgo en auditoría de seguridad, ensayo de disponibilidad no alcanzado. Ninguna aparece en las minutas.
- **Riesgo** «Bloqueo de la vía de acceso a la mina»: sin probabilidad, impacto ni responsable. El acta declara «Ninguna dependencia», así que la dependencia de la vía de acceso tampoco está registrada.
- **Silencio:** el proyecto no está en silencio (último documento 2026-10-15, hace 1 día). Lo que calla es quien reporta: ni el informe ni la minuta mencionan CC-01 ni el cronograma v2.

### Contradicho
| Afirmación | Documento A | Documento B |
|---|---|---|
| Estado verde | Informe 2026-10-14: «Verde» | Cronograma v2 (2026-10-14): +70 días y 19.6 % sobre la original; CC-01 (2026-10-12) sin autorizar; hitos cerrados sin acta |
| Fecha vigente del montaje 2026-12-11, y cierre posterior al comprometido (acta: 2026-11-16) | Cronograma v2 | CC-01: «Pendiente de presentación al comité»; acta: cierre 2026-11-16; sin autoridad declarada para moverla |

### Sin sustento
- Avance de 48 % (no hay documento de medición; el plan sugiere otra cosa).
- Lluvias de diez días, hallazgo de auditoría, ensayo de disponibilidad repetido.
- Dinero comprometido, ejecutado y proyección.
- Riesgo de bloqueo de la vía de acceso.
- Cierre de los tres hitos: ingeniería básica, ingeniería de detalle, licencia y permisos.

### Lo que esta carpeta no permite saber
- **Si hay desviación aprobada:** no hay autoridad declarada ni decisión de comité sobre CC-01. Consecuencia: los 70 días son fechas escritas, no un cambio aprobado.
- **Por qué se movió la línea base:** el v2 no trae motivo. Consecuencia: no se puede separar atraso real de ampliación de alcance.
- **Qué amplía CC-01:** el alcance del acta está en blanco. Consecuencia: no se puede validar +70 días ni +140.000.000 COP.
- **Si los hitos cerrados lo están:** faltan 3 actas de recibo. Consecuencia: el avance real no se puede medir.
- **Cuánto se gastó de verdad:** no hay respaldo de contabilidad. Consecuencia: el disponible real de 320.574.756 COP es el del informe, no un dato verificado.
- **Si hay proveedores:** no hay contrato en la carpeta; no se puede contrastar entregables ni facturas.
- **Fase, producto y autoridad:** sin dato en la carpeta.

### Qué sigue
No recomiendo detener, continuar ni reestructurar: lo decide quien tiene la facultad. Puedo preparar el punto de comité con la lista de lo que falta, o llevar las dos contradicciones a Elena Duarte como preguntas, una por una.
