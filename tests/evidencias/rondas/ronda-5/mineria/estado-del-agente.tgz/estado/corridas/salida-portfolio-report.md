**Términos:** vigentes (versión 0.3.11, aceptados por José Francisco Ñáñez el 2026-10-16). Criterio produce borradores de trabajo, no decisiones ni asesoría; cada dato trae la cita del documento de donde salió y la verificación es suya. Nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.11

**Fichas cargadas:** 13 (PRY-199 a PRY-211), barrido y instantánea del 2026-10-16. Ninguna tiene más de una semana sin barrido.

# Portafolio — 2026-10-16
13 proyectos · 11 con hallazgos (58 señales) · último barrido 2026-10-16

## Qué cambió desde 2026-10-16
Sin cambios desde la corrida anterior. La instantánea anterior es del mismo día (2026-10-16) y el diff dio 0 cambios. No hay delta que reportar.

## Contradicciones abiertas
| Proyecto | Campo | Dice | Fuente | Dice también | Fuente |
|---|---|---|---|---|---|
| PRY-200 | Fecha de fin del plan | 2026-08-08 | 10-plan/2025-06-03-cronograma-v1.csv | 2026-09-30 | 00-gobierno/2025-06-03-acta-constitucion.docx |

Las dos fuentes son del mismo día (2025-06-03), así que ninguna es más reciente y el script no puede desempatar. Además, seis proyectos declaran verde y la evidencia lo contradice: PRY-202, PRY-205, PRY-206, PRY-208, PRY-210 y PRY-211 (ver "Sin sustento").

## Hitos vencidos sin evidencia
| Proyecto | Hito | Fecha | Días | Última mención |
|---|---|---|---|---|
| PRY-207 | Licencia y permisos obtenidos | 2026-10-08 | 8 | no calculada por el script |

Los demás proyectos no tienen hitos vencidos sin marcar; sus problemas son hitos declarados cumplidos sin soporte (ver "Sin sustento").

## Proyectos en silencio
Vacía. Umbral de 15 días; el más callado es PRY-208 / PRY-209 con 9 días.

## Dependencias en riesgo
Vacía en este informe: el cálculo no devolvió ninguna señal de dependencia entre proyectos. Tampoco hubo cambio de gobierno (sin diff). Lo que sí aparece son entregables de proveedor tardíos: PRY-207, "Bolsa de horas de ingeniería" (Automatización de Procesos Ltda., contrato CT-858), vencía 2026-09-13, 33 días, pendiente.

## Sin sustento
Hitos declarados cumplidos sin evidencia en documentos:
| Proyecto | Declara | Qué lo respalda |
|---|---|---|
| PRY-200 | 4 de 4 hitos cumplidos, avance 54% | Nada para los 4 hitos (385, 280, 174 y 69 días de vencidos) |
| PRY-201 | Ingeniería básica cumplida | Nada (86 días) |
| PRY-202 | Verde, 35%; 2 hitos cumplidos | Nada; los hitos suponen 100% del plan |
| PRY-203 | Ingeniería básica cumplida | Nada (138 días) |
| PRY-204 | 3 hitos cumplidos | Nada (446, 348 y 239 días) |
| PRY-205 | Verde; 2 hitos cumplidos | Nada (184 y 56 días) |
| PRY-207 | Ingeniería de detalle cumplida | Nada (109 días) |
| PRY-208 | Verde; 2 hitos cumplidos | Nada (280 y 22 días) |
| PRY-211 | Verde; 3 hitos cumplidos | Nada (282, 193 y 103 días) |

Avance declarado que no cuadra con el plan: PRY-200 (54% frente a 100% que suponen sus hitos, 46 puntos), PRY-202 (65 puntos), PRY-204 (23), PRY-208 (27), PRY-211 (27), todos por atraso; PRY-207 (15 puntos) y PRY-210 (32) van por delante de lo que sus hitos soportan.

Compromisos de reunión: PRY-200 tiene 4+ vencidos sin evidencia (hasta 12 días), 2 sin fecha y reprogramaciones repetidas (Elena Duarte 6 veces, Diana Molina 5, Óscar Ramírez 3, Javier Hoyos 3); PRY-204 tiene 1 vencido (Andrés Lozano, 9 días); PRY-210 tiene 1 sin fecha.

## Vacíos de información
| Proyecto | Qué falta |
|---|---|
| Los 13 | Autoridad (`identity.authority`) y fase (`identity.phase`) |
| PRY-201, 202, 205, 206, 209, 210, 211 | Producto asociado |
| PRY-206, PRY-209 | Línea base (sin ella no se mide desviación) |
| PRY-200, 204, 208, 211 | Campos de identidad con más de 12 meses (13 a 17 meses) |

## Estado general
| Proyecto | Declarado | Sustento | Desviación vs original | vs vigente | Replanificaciones |
|---|---|---|---|---|---|
| PRY-199 | verde | sin alertas | 0 d | 0 d | 0 |
| PRY-200 | amarillo | 18 señales; 4 hitos sin evidencia | 0 d | 0 d | 0 |
| PRY-201 | amarillo | 1 hito sin evidencia | 0 d | 0 d | 0 |
| PRY-202 | **verde** | contradicho (hitos y avance) | 0 d | 0 d | 0 |
| PRY-203 | rojo | coherente | +66 d (22,4%); costo +20,8% | sin autorizar | 1 |
| PRY-204 | rojo | coherente | +61 d (31,4%) | autorizada | 1 |
| PRY-205 | **verde** | contradicho (2 hitos) | 0 d | 0 d | 0 |
| PRY-206 | **verde** | contradicho (costo +10,6%) | sin línea base | n/d | 0 |
| PRY-207 | amarillo | coherente | 0 d | 0 d | 0 |
| PRY-208 | **verde** | contradicho (+110 d, 21,4%) | +110 d | autorizada | 1 |
| PRY-209 | amarillo | sin alertas | sin línea base | n/d | 0 |
| PRY-210 | **verde** | contradicho (+33 d sin autorizar) | +33 d (7,8%) | sin autorizar | 1 |
| PRY-211 | **verde** | contradicho (+70 d, 19,6%, sin autorizar) | +70 d | sin autorizar | 1 |

Líneas base movidas sin autorización: PRY-203 (66 d), PRY-210 (33 d), PRY-211 (70 d).

Fechas de fin ya pasadas con el proyecto sin cerrar, según la ficha: PRY-200 (2026-08-08), PRY-202 (2026-08-29), PRY-204 (2026-02-19), PRY-206 (2026-10-07). El script no las marca como señal; las menciono porque están en los datos.

Por producto: monitoreo de flota (PRY-200) 18 señales; alerta de taludes (PRY-204) 6; trazabilidad (PRY-208) 5; despacho de flota (PRY-203) y gemelo digital (PRY-207) 4 cada uno; PRD-299 (PRY-199) ninguna.

## Necesito que confirmes
Sesión sin interfaz: tomo la respuesta sugerida (confirmar que el dato sigue vigente) y lo dejo anotado como pendiente de tu confirmación real.
1. PRY-200: ¿el patrocinador y el gerente siguen siendo los del acta de 2025-06-03 (16 meses)? Sí / No
2. PRY-200: ¿la fecha de fin vigente es 2026-08-08 (cronograma) o 2026-09-30 (acta)?
3. PRY-204: ¿el comité y el gerente siguen siendo los del acta de 2025-05-30 (17 meses)? Sí / No
4. PRY-208: ¿el patrocinador sigue siendo el del acta de 2025-08-24 (14 meses)? Sí / No
5. PRY-211: ¿el gerente sigue siendo el del acta de 2025-09-30 (13 meses)? Sí / No

## Archivos del informe
Quedaron en `reportes/` (23 páginas): `index.html` (por campo, con la cadena de evidencia; para quien va a actuar) y `decisiones.html` (por decisión; para el patrocinador). También una página por proyecto, por producto, `productos.html` y `proyectos.html`. El PDF sale de imprimir el HTML.

Siete proyectos no tienen producto asociado: PRY-201, 202, 205, 206, 209, 210 y 211.

---
Pie: criterio-portfolio 0.3.11 · fichas aplicadas: 13, del 2026-10-16 · campos inciertos: fecha de fin de PRY-200 (dos fuentes del mismo día), autoridad y fase sin dato en los 13 proyectos · términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.11
