# Corrida del 2026-10-16 · portfolio-wake

13 proyectos · 33 s · 58 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 19 |
| `progress_vs_plan` | 7 |
| `commitment_overdue` | 7 |
| `declared_vs_evidence` | 6 |
| `commitment_rescheduled` | 4 |
| `variance_time` | 4 |
| `commitment_undated` | 3 |
| `rebaseline_unauthorized` | 3 |
| `variance_cost` | 2 |
| `pm_vs_pmo` | 1 |
| `milestone_overdue` | 1 |
| `vendor_deliverable_late` | 1 |

Barrido: 77 documentos sin cambios, nada que recalcular. Confirmación pendiente: las 5 preguntas de hoy siguen sin respuesta, no se repitieron. No sé si los datos de PRY-200/204/208/211 siguen vigentes.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

**Términos:** vigentes (versión 0.3.11, aceptados por José Francisco Ñáñez el 2026-10-16). Nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.11

## 2026-10-16

**Revisé:** 77 documentos · 0 cambiaron · 0 proyectos recalculados (sin citas rotas, renombrados ni borrados).

### Lo que cruzó un umbral
Nada nuevo. El barrido no encontró documentos cambiados, así que no se corrió `/portfolio-scan` ni se recalculó nada. Las señales abiertas son las del informe de portafolio de hoy.

### Peticiones atendidas
No tocaban: `requests` no estaba pendiente.

### Preguntas
Tocaba la confirmación mensual (nunca se había hecho). No pregunté de nuevo: las cinco preguntas de hoy ya están en el informe de portafolio y siguen sin respuesta. Estado: *preguntadas el 2026-10-16, sin respuesta.*
1. PRY-200: ¿patrocinador y gerente siguen siendo los del acta de 2025-06-03 (16 meses)?
2. PRY-200: ¿la fecha de fin vigente es 2026-08-08 (cronograma) o 2026-09-30 (acta)?
3. PRY-204: ¿comité y gerente siguen siendo los del acta de 2025-05-30 (17 meses)?
4. PRY-208: ¿el patrocinador sigue siendo el del acta de 2025-08-24 (14 meses)?
5. PRY-211: ¿el gerente sigue siendo el del acta de 2025-09-30 (13 meses)?

Dejé registrado solo el barrido (`ran --what sweep`). La confirmación no la marqué como corrida, porque no la hice en esta corrida: mañana volverá a tocar y se reportará igual como sin respuesta.

**Vuelvo el 2026-10-17.**
