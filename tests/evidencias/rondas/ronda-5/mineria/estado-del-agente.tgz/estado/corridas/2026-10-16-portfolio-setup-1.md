# Corrida del 2026-10-16 · portfolio-setup

3 proyectos · 77 documentos, 50 releídos y 27 sin cambio · 137 s · 26 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 6 |
| `commitment_overdue` | 6 |
| `commitment_rescheduled` | 4 |
| `progress_vs_plan` | 3 |
| `commitment_undated` | 3 |
| `declared_vs_evidence` | 2 |
| `pm_vs_pmo` | 1 |
| `rebaseline_unauthorized` | 1 |

0 preguntas (sesión sin interfaz, valores sugeridos); primer resultado sobre 3 proyectos (PRY-200, PRY-210, PRY-202) unos 2 minutos después de iniciar la corrida; 26 señales: 4+2 hitos cerrados sin acta, brecha avance-plan en los tres, 2 verdes contradichos, 33 días de línea base movidos sin autorizar en PRY-210, compromisos vencidos y reprogramados en PRY-200

Primera corrida: no hay una anterior contra la cual comparar.

## Lo que produjo

## Listo — Portafolio de proyectos

**Miré:** 77 documentos en 13 proyectos · formatos: .md (38), .docx (11), .pdf (10), .csv (9), .xlsx (7), .json (1), .txt (1) · más reciente: 2026-10-16
**Eres:** PMO del portafolio (propuesto porque hay varios proyectos)
**Te aviso:** dos días antes del comité; no dijiste fecha de comité, así que propuse un informe semanal
**En:** presentación (valor sugerido)
**Términos:** aceptados para la versión 0.3.11 (términos 1.1) por José Francisco Ñáñez el 2026-10-16 · comprobante en `.criterio/terminos/aceptacion-criterio-portfolio-0.3.11-2026-10-16.md` y `.pdf` · SHA-256 41a739aec7049af3…

Dónde quedó todo: configuración en `.criterio/portafolio/config.json`; lo que voy encontrando en `estado/`; los informes irán a `reportes/`. Hice cero preguntas: en cada punto tomé el valor sugerido.

### Probé con tres proyectos

Los de documentación más reciente: PRY-200 (2026-10-16), PRY-210 (2026-10-16) y PRY-202 (2026-10-15, empatado con otros tres; elegí por orden de código). Cada ficha quedó en `estado/records/` y sellada.

| Proyecto | Documentos | Qué supe | Qué no está |
|---|---|---|---|
| PRY-200 Mantenimiento predictivo de camiones | 14 (acta, cronograma, informe, 3 actas de recibo, 6 comités, notas del 16-oct, ficha del gerente) | Patrocinador Andrés Lozano, gerente Ricardo Salas, presupuesto COP 1.200 M (acta 2025-06-03). Declara amarillo, 54% (informe 2026-10-14). 26 compromisos tomados de los comités. | Facultad del gerente (`authority`), etapa. Ninguna acta de recibo de los 4 hitos que el cronograma da por cerrados. |
| PRY-210 Programa de relacionamiento comunitario | 7 | Patrocinador Carlos Peña, gerente Laura Vélez, presupuesto COP 3.300 M. Declara verde, 72%. Solicitud de cambio CC-01 (+33 días, +COP 66 M) pendiente de comité. | Facultad del gerente, etapa, producto (el acta dice «No aplica»). |
| PRY-202 Planta de tratamiento de agua | 6 | Patrocinador Felipe Arango, gerente Javier Hoyos, presupuesto COP 6.800 M. Declara verde, 35%. | Facultad del gerente, etapa, producto («No aplica»). Sin acta de recibo para 2 de sus 4 hitos. |

**Señales que levantó el cálculo (26 en total, con el nombre de portfolio-health):**

- **PRY-200 (amarillo declarado)**
  - `milestone_met_without_evidence`: 4 hitos declarados cerrados sin acta de recibo, hace entre 69 y 385 días (Ingeniería básica, Ingeniería de detalle, Licencia y permisos, Montaje e instalación).
  - `progress_vs_plan`: declara 54%, pero el cronograma tiene los 4 hitos cerrados (100%); la brecha son 46 puntos.
  - `commitment_overdue`: 6 compromisos vencidos. Los más viejos, Sandra Gil («Validar el ambiente 4») y Liliana Torres («Aprobar el diseño 5»), llevan 12 días. Liliana Torres, Andrés Lozano y Jorge Medina dicen haber entregado y no hay acta.
  - `commitment_rescheduled`: «Enviar el documento 1» (Elena Duarte) se ha reprogramado 6 veces, del 2026-09-19 al 2026-12-12. «Cerrar la prueba 2» (Diana Molina), 5 veces. «Revisar el anexo 3» y «Confirmar la fecha 7», 3 veces cada uno.
  - `commitment_undated`: 2 compromisos sin fecha: «Cerrar la prueba 18» (Gustavo Neira, «por definir» en dos reuniones) y «Mandar el ajuste del presupuesto» (Laura Vélez, «la otra semana»).
  - `pm_vs_pmo`: la fecha de cierre no coincide entre la ficha publicada por el gerente (2026-09-30, del acta) y mi lectura del cronograma (2026-08-08, su último hito).
- **PRY-202 (verde declarado)**
  - `declared_vs_evidence`: el verde queda contradicho por las dos señales siguientes.
  - `progress_vs_plan`: declara 35%, con los 4 hitos cerrados; la brecha son 65 puntos.
  - `milestone_met_without_evidence`: Ingeniería básica y Licencia y permisos, cerrados sin acta. Las actas que sí existen son del 2026-10-09 y 2026-10-15, meses después de las fechas de línea base.
- **PRY-210 (verde declarado)**
  - `declared_vs_evidence`: el verde queda contradicho por las dos señales siguientes.
  - `rebaseline_unauthorized`: el cronograma v2 del 2026-10-14 ya movió 33 días el último hito, del 2027-07-19 al 2027-08-21. Es justo lo que pide CC-01, que sigue pendiente de comité, así que hay 33 días movidos y 0 autorizados.
  - `progress_vs_plan`: declara 72%, pero solo 1 de 5 hitos está cerrado (el plan sustenta entre 20% y 40%); la brecha son 32 puntos.
  - `commitment_undated`: «Entregar el punto 35» (Paula Céspedes), sin fecha.
- **Los tres:** ninguno tiene definida la facultad del gerente para decidir sin subir a comité.

Una nota sobre cómo se calcula: al sellar, el sistema toma como fecha de cierre la del último hito del cronograma, no la «Cierre» del acta. Por eso PRY-200 queda con cierre 2026-08-08 (el acta dice 2026-09-30) y PRY-202 con 2026-08-29 (el acta dice 2026-09-23). Conviene confirmar cuál es la fecha vigente que cuenta.

### El portafolio completo

10 proyectos más (PRY-199, 201, 203 a 209 y 211), unos 62 documentos que aún no leí, en dos lotes uno tras otro. Calculo unos 25 a 30 minutos, a un ritmo parecido al de estos tres.

### Lo que le falta a tu carpeta

Ninguno es bloqueante:
- **Actas de recibo:** en los tres proyectos hay hitos «cerrados» en el cronograma sin acta que lo pruebe. Es lo que más señales produjo.
- **Facultad del gerente:** ninguna acta de constitución dice hasta qué monto o cambio de alcance puede decidir el gerente sin subir a comité.
- **Cronograma ausente:** PRY-206 y PRY-209 no tienen carpeta de plan, y PRY-205 y PRY-201 no tienen actas de reunión. Sin eso no se puede medir atraso.
- **Archivo suelto:** las notas de reunión de PRY-200 (`2026-10-16-notas-reunion.txt`) están fuera de `30-reuniones/`.
- **Actas con texto genérico:** «Fuera de alcance: lo que otro proyecto cubre» y «Dependencias: ninguna declarada» no dicen nada que se pueda contrastar.
- **Aprobación del cambio de fechas:** el cronograma v2 de PRY-210 mueve fechas antes de que el comité apruebe CC-01.
- **Carpeta ajena:** hay una carpeta `estado/PRY-200-mantenimiento-predictivo-de-camiones/` con corridas del agente de proyecto, creada antes de esta sesión. No la toqué; conviene decidir si es su sitio.

¿Corro el portafolio completo? Si tienes equipo de gerentes de proyecto, también puedo publicar el estándar en una carpeta compartida para que usen los mismos criterios.
