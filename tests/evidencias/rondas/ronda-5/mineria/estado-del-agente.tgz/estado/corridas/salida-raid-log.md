**Sale de:** las 13 fichas de `estado/records` (PRY-199 a PRY-211), los informes de avance, las actas de constitución de PRY-199, 201, 210 y 211 (sección «Dependencias declaradas»), los comités semanales y las notas de reunión del 2026-10-16 de PRY-200. Los ids (p. ej. `PRY-200-R2`) los asigné yo para poder referirme a cada ítem; no existen en las fichas.

## RAID — Portafolio al 2026-10-16
23 riesgos · 0 supuestos · 17 incidencias · 0 dependencias (40 ítems en total)
40 sin doliente · 40 sin fecha · 40 sin movimiento medible · 1 no registrado formalmente

**Lo primero:** ninguna de las 13 fichas trae doliente, fecha, probabilidad, impacto ni fecha de último movimiento en un solo ítem. Todo el registro sale de las listas de «Riesgos abiertos» y de hallazgos de los informes de avance. Por eso no pude aplicar tres de los cinco criterios de escalamiento (dos períodos sin movimiento, doliente externo sin respuesta, mitigación vencida): no hay dato con qué medirlos. Eso es un hallazgo, no una ausencia de problemas. No rellené nada. Probabilidad e impacto quedan «sin dato»; no usé una escala inventada.

### Necesitan decisión ahora
| Id | Tipo | Qué | Doliente | Desde | Por qué sube |
|---|---|---|---|---|---|
| PRY-200-R2 | Riesgo | El proveedor podría no llegar con el equipo completo para la siguiente fase | sin doliente | dicho 2026-10-16 | Está en las notas como «nadie lo anotó como riesgo». Decisión: formalizarlo con doliente y fecha. Se relaciona con PRY-200-R1 (el proveedor no ha confirmado la fecha de la última entrega, ya en el informe del 2026-10-14); si son el mismo problema, conviene unirlos. |
| PRY-202-R1 / PRY-202-I1 y PRY-210-R2 / PRY-210-I1 | Riesgo + Incidencia | «Ventana de parada de planta definida por operaciones» sigue abierto como riesgo, y el mismo informe ya reporta «se reprogramó la parada de planta» | sin doliente | informes 2026-10-13 y 2026-10-14 | Inferencia mía: el riesgo parece haberse cumplido al menos en parte. La decisión es de cada gerente: confirmar si es el mismo evento y, si lo es, cerrar el riesgo y gestionar la incidencia con doliente y fecha. Lo dicen los informes; los documentos no muestran que sea el mismo evento. |

No hay ítem que pueda declarar escalado al comité por el criterio «afecta a otro proyecto»: ningún documento nombra a un proyecto del que otro dependa.

### Detectados en reuniones, no registrados
| Qué | Tipo | Dicho en | Fecha |
|---|---|---|---|
| «Se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo» | Riesgo | PRY-200, `2026-10-16-notas-reunion.txt` | 2026-10-16 |

Es el único. Leí los seis comités semanales de PRY-200 y los de PRY-199, 202, 203, 204, 207, 210 y 211: son tablas de compromisos y no contienen riesgos dichos al pasar. No inventé ninguno. La ficha de PRY-200 ya lo trae marcado como «nadie lo registró».

### Reclasificar (la prueba rápida)
| Ítem | Hoy | Debería ser | Por qué |
|---|---|---|---|
| «El proveedor no ha confirmado la fecha de la última entrega»: PRY-200-R1, 201-R2, 203-R1, 206-R1, 207-R2, 209-R1, 210-R1 | Riesgo | Dependencia (declarada, no confirmada) | Depende de un tercero fuera del proyecto. |
| «Ventana de parada de planta definida por operaciones»: PRY-199-R2, 202-R1, 203-R2, 205-R2, 208-R2, 210-R2 | Riesgo | Dependencia | La fecha la fija operaciones, que no es parte del proyecto. |

Quedan como riesgo, correctamente: licencia ambiental (199, 201, 204, 205, 208), concentración del conocimiento (202, 206, 207) y bloqueo de la vía de acceso (211). Los 17 incidentes están en pasado y están bien clasificados. Dos son dudosos: «equipos entregados, pendientes de aceptación» (204-I1 y 208-I1) es un hecho, pero lo que pesa es la aceptación pendiente.

Al reclasificar como dependencia hay que anotar de quién se depende. Aquí la contraparte es el proveedor o operaciones, no un proyecto del portafolio, así que no hay código PRY que poner. No lo inventé.

### Sin doliente o sin fecha
Los 40 ítems. Qué falta en todos: doliente y fecha. En los 23 riesgos falta además probabilidad e impacto. En las 17 incidencias, desde cuándo. Detalle en el registro completo.

### Dependencias en riesgo
Ninguna que cruzar. Ninguna ficha tiene dependencias, y las actas de PRY-199, 201, 210 y 211 dicen «Ninguna declarada». No pude revisar si otro proyecto movió una fecha de la que dependa uno de estos, porque nadie declaró la dependencia. Ojo: los seis ítems del bloque anterior son dependencias reales no declaradas; por ahora son con terceros.

### Alertas sobre la calidad del dato
- Los 40 ítems usan solo 12 frases distintas, repetidas casi textuales entre proyectos distintos (p. ej. «las lluvias detuvieron el montaje durante diez días» aparece en PRY-200, 208 y 211; «el primer ensayo de disponibilidad…» en 200, 205, 207 y 211). Puede ser lenguaje de plantilla y no reflejar cada proyecto. Verifíquenlo con los gerentes antes de usarlos en comité.
- En el comité de PRY-200 del 2026-10-02 tres personas dicen haber entregado compromisos y no presentaron acta. Eso es de seguimiento de compromisos, no del RAID; lo dejo señalado.

### Registro completo
Doliente, fecha y último movimiento no están en ningún documento. «Sin movimiento registrado» significa que no hay fecha de último movimiento, no que lo haya habido.

| Id | Tipo | Qué | Prob. | Impacto | Doliente | Fecha | Último movimiento |
|---|---|---|---|---|---|---|---|
| PRY-199-R1 | Riesgo | Cambio en la licencia ambiental que puede mover el alcance | sin dato | sin dato | sin doliente | sin fecha | sin movimiento registrado |
| PRY-199-R2 | Riesgo | Ventana de parada de planta definida por operaciones | sin dato | sin dato | sin doliente | sin fecha | sin movimiento registrado |
| PRY-200-R1 | Riesgo | El proveedor no ha confirmado la fecha de la última entrega | sin dato | sin dato | sin doliente | sin fecha | sin movimiento registrado |
| PRY-200-R2 | Riesgo | El proveedor podría no llegar con el equipo completo para la siguiente fase (se comentó en la reunión; nadie lo registró) | sin dato | sin dato | sin doliente | sin fecha | sin movimiento registrado |
| PRY-200-I1 | Incidencia | Las lluvias detuvieron el montaje durante diez días | — | — | sin doliente | sin fecha | sin movimiento registrado |
| PRY-200-I2 | Incidencia | El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite | — | — | sin doliente | sin fecha | sin movimiento registrado |
| PRY-201-R1 | Riesgo | Cambio en la licencia ambiental que puede mover el alcance | sin dato | sin dato | sin doliente | sin fecha | sin movimiento registrado |
| PRY-201-R2 | Riesgo | El proveedor no ha confirmado la fecha de la última entrega | sin dato | sin dato | sin doliente | sin fecha | sin movimiento registrado |
| PRY-201-I1 | Incidencia | Se levantó un hallazgo en la auditoría de seguridad | — | — | sin doliente | sin fecha | sin movimiento registrado |
| PRY-202-R1 | Riesgo | Ventana de parada de planta definida por operaciones | sin dato | sin dato | sin doliente | sin fecha | sin movimiento registrado |
| PRY-202-R2 | Riesgo | Concentración del conocimiento en una sola persona | sin dato | sin dato | sin doliente | sin fecha | sin movimiento registrado |
| PRY-202-I1 | Incidencia | Se reprogramó la parada de planta por la ventana de mantenimiento | — | — | sin doliente | sin fecha | sin movimiento registrado |
| PRY-203-R1 | Riesgo | El proveedor no ha confirmado la fecha de la última entrega | sin dato | sin dato | sin doliente | sin fecha | sin movimiento registrado |
| PRY-203-R2 | Riesgo | Ventana de parada de planta definida por operaciones | sin dato | sin dato | sin doliente | sin fecha | sin movimiento registrado |
| PRY-203-I1 | Incidencia | Se levantó un hallazgo en la auditoría de seguridad | — | — | sin doliente | sin fecha | sin movimiento registrado |
| PRY-204-R1 | Riesgo | Cambio en la licencia ambiental que puede mover el alcance | sin dato | sin dato | sin doliente | sin fecha | sin movimiento registrado |
| PRY-204-I1 | Incidencia | El proveedor entregó los equipos en el campamento, pendientes de aceptación | — | — | sin doliente | sin fecha | sin movimiento registrado |
| PRY-205-R1 | Riesgo | Cambio en la licencia ambiental que puede mover el alcance | sin dato | sin dato | sin doliente | sin fecha | sin movimiento registrado |
| PRY-205-R2 | Riesgo | Ventana de parada de planta definida por operaciones | sin dato | sin dato | sin doliente | sin fecha | sin movimiento registrado |
| PRY-205-I1 | Incidencia | El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite | — | — | sin doliente | sin fecha | sin movimiento registrado |
| PRY-206-R1 | Riesgo | El proveedor no ha confirmado la fecha de la última entrega | sin dato | sin dato | sin doliente | sin fecha | sin movimiento registrado |
| PRY-206-R2 | Riesgo | Concentración del conocimiento en una sola persona | sin dato | sin dato | sin doliente | sin fecha | sin movimiento registrado |
| PRY-206-I1 | Incidencia | Se reprogramó la parada de planta por la ventana de mantenimiento | — | — | sin doliente | sin fecha | sin movimiento registrado |
| PRY-207-R1 | Riesgo | Concentración del conocimiento en una sola persona | sin dato | sin dato | sin doliente | sin fecha | sin movimiento registrado |
| PRY-207-R2 | Riesgo | El proveedor no ha confirmado la fecha de la última entrega | sin dato | sin dato | sin doliente | sin fecha | sin movimiento registrado |
| PRY-207-I1 | Incidencia | El equipo perdió dos semanas por rotación de un ingeniero clave | — | — | sin doliente | sin fecha | sin movimiento registrado |
| PRY-207-I2 | Incidencia | El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite | — | — | sin doliente | sin fecha | sin movimiento registrado |
| PRY-208-R1 | Riesgo | Cambio en la licencia ambiental que puede mover el alcance | sin dato | sin dato | sin doliente | sin fecha | sin movimiento registrado |
| PRY-208-R2 | Riesgo | Ventana de parada de planta definida por operaciones | sin dato | sin dato | sin doliente | sin fecha | sin movimiento registrado |
| PRY-208-I1 | Incidencia | El proveedor entregó los equipos en el campamento, pendientes de aceptación | — | — | sin doliente | sin fecha | sin movimiento registrado |
| PRY-208-I2 | Incidencia | Las lluvias detuvieron el montaje durante diez días | — | — | sin doliente | sin fecha | sin movimiento registrado |
| PRY-209-R1 | Riesgo | El proveedor no ha confirmado la fecha de la última entrega | sin dato | sin dato | sin doliente | sin fecha | sin movimiento registrado |
| PRY-209-I1 | Incidencia | Se levantó un hallazgo en la auditoría de seguridad | — | — | sin doliente | sin fecha | sin movimiento registrado |
| PRY-210-R1 | Riesgo | El proveedor no ha confirmado la fecha de la última entrega | sin dato | sin dato | sin doliente | sin fecha | sin movimiento registrado |
| PRY-210-R2 | Riesgo | Ventana de parada de planta definida por operaciones | sin dato | sin dato | sin doliente | sin fecha | sin movimiento registrado |
| PRY-210-I1 | Incidencia | Se reprogramó la parada de planta por la ventana de mantenimiento | — | — | sin doliente | sin fecha | sin movimiento registrado |
| PRY-211-R1 | Riesgo | Bloqueo de la vía de acceso a la mina | sin dato | sin dato | sin doliente | sin fecha | sin movimiento registrado |
| PRY-211-I1 | Incidencia | Las lluvias detuvieron el montaje durante diez días | — | — | sin doliente | sin fecha | sin movimiento registrado |
| PRY-211-I2 | Incidencia | Se levantó un hallazgo en la auditoría de seguridad | — | — | sin doliente | sin fecha | sin movimiento registrado |
| PRY-211-I3 | Incidencia | El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite | — | — | sin doliente | sin fecha | sin movimiento registrado |

### Lo que no sé
- Quién es el doliente de cualquiera de los 40 ítems, y para cuándo vence.
- Si alguno se movió en los últimos dos períodos: las fichas no guardan historial.
- Si los textos repetidos entre proyectos son reales o de plantilla.

### Siguiente paso
¿Subo a comité los dos puntos de «necesitan decisión» (formalizar PRY-200-R2 y revisar la parada de planta en PRY-202 y PRY-210)? Puedo proponer un doliente por ítem, pero lo elige cada gerente: propongo, no asigno.

---
Pie de rigor: borrador de trabajo, no decisión ni asesoría. Cada dato se puede rastrear al informe o nota citado en la ficha (campo `source`); la verificación es suya. Términos vigentes (v1.1) aceptados por José Francisco Ñáñez el 2026-10-16.
