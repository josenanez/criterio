**Fuentes:** ficha PRY-203 (actualizada 2026-10-16), construida desde `20-seguimiento/2026-10-13-informe-avance.md`, `20-seguimiento/2026-10-09-solicitud-cambio-cc-01.md` y `10-plan/2026-10-13-cronograma-v2.xlsx`. Cifras derivadas: salida de `portafolio.py compute` al 2026-10-16. Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-16).

## Presupuesto — PRY-203 Despacho automático de flota al 2026-10-16
**Moneda:** COP (única moneda; no hay contratos en otra moneda ni conversiones)

| | Monto (COP) | % del aprobado | Fuente | Fecha |
|---|---|---|---|---|
| Aprobado | 800.000.000 | — | informe de avance | 2026-10-13 |
| Comprometido | 339.448.354 | 42.4% | informe de avance | 2026-10-13 |
| Ejecutado | 389.245.930 | 48.7% | informe de avance | 2026-10-13 |
| Proyección al cierre | 966.342.753 | 20.8% por encima del aprobado | informe de avance | 2026-10-13 |

**Disponible real** (aprobado menos comprometido): 460.551.646 COP, según el script. **No es confiable:** el informe declara un comprometido menor que el ejecutado, lo cual no cuadra (lo ejecutado debería estar ya comprometido). El comprometido real es al menos igual al ejecutado, así que el disponible real es menor que esa cifra. Hay que pedir a la gerente el comprometido correcto.

### Contra la línea base
- **Costo:** no hay línea base de presupuesto en ningún documento. Solo existe un aprobado (800.000.000), declarado en el informe de avance, no en el acta de constitución. Original, vigente y desviación de costo contra línea base: `not_found`. Replanificaciones de presupuesto: no se puede contar.
- **Cambio CC-01 (2026-10-09):** pide 132.000.000 COP adicionales y +66 días. Está pendiente de presentación al comité, sin decisión ni quien decida. El aprobado de 800.000.000 no lo incluye.
- **Tiempo (contexto):** fin original 2027-01-08, fin vigente 2027-03-15. Desviación de 66 días (22.4%) contra la original. 1 replanificación, v2 del 2026-10-13, sin motivo declarado.

### Ejecución frente a avance
Ejecutado 48.7% · Hitos cumplidos 2 de 4 · Avance declarado 82%.
Lectura: la ejecución (48.7%) está muy por debajo del avance declarado (82%), y el plan sustenta entre 50% y 75%. Los 82% no se sostienen con los hitos. Además, el hito "Ingeniería básica aprobada" figura cumplido sin evidencia, 138 días después de su fecha (2026-05-31).

### Alertas
- **Proyección por encima del aprobado:** 966.342.753 contra 800.000.000, 20.8% sobre el aprobado y por encima del umbral de 10%. Es una declaración del informe del 2026-10-13, no un dato duro. Es posterior al último movimiento de presupuesto que consta, así que no está desactualizada. Según el informe, el proyecto está en rojo.
- **Línea base movida sin autorización:** la fecha de fin se movió 66 días y ninguna decisión la autoriza. CC-01 sigue pendiente.
- **Inconsistencia comprometido/ejecutado:** el comprometido (42.4%) es menor que el ejecutado (48.7%). El umbral de comprometido de 90% no se alcanza con la cifra declarada, pero la cifra misma es dudosa.
- **Avance declarado sin soporte:** 82% contra lo que sustentan los hitos.

### Sin dato
- Línea base de presupuesto (original y vigente) y fecha de su aprobación.
- Comprometido consistente con lo ejecutado.
- Desglose por proveedor: la ficha no tiene proveedores (`vendors` vacío).
- Autoridad que aprobaría el cambio (`identity.authority`) y fase (`identity.phase`).

### Siguiente paso
La proyección excede el aprobado: puedo preparar la solicitud de cambio de presupuesto (CC-01 ya existe, pendiente de comité). No ofrezco el detalle por proveedor porque no hay proveedores registrados.

---
*Pie de rigor: borrador de trabajo, no decisión ni asesoría. Cada cifra sale de los documentos citados y del cálculo del script; la verificación es suya. Lo hablado fuera de los documentos no está aquí.*
