<!-- origen: PRY-202-planta-de-tratamiento-de-agua/10-plan/2026-02-02-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Ingeniería básica aprobada,2026-04-02,2026-04-02,cerrado
Ingeniería de detalle aprobada,2026-05-22,2026-05-22,cerrado
Licencia y permisos obtenidos,2026-07-10,2026-07-10,cerrado
Montaje e instalación,2026-08-29,2026-08-29,cerrado
