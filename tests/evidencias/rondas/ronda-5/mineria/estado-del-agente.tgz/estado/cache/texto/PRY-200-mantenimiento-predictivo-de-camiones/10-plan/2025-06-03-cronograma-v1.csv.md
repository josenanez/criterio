<!-- origen: PRY-200-mantenimiento-predictivo-de-camiones/10-plan/2025-06-03-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Ingeniería básica aprobada,2025-09-26,2025-09-26,cerrado
Ingeniería de detalle aprobada,2026-01-09,2026-01-09,cerrado
Licencia y permisos obtenidos,2026-04-25,2026-04-25,cerrado
Montaje e instalación,2026-08-08,2026-08-08,cerrado
