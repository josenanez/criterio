<!-- origen: PRY-208-trazabilidad-del-mineral/20-seguimiento/2026-10-07-solicitud-cambio-cc-01.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-01

**Proyecto:** PRY-208 · Trazabilidad del mineral
**Fecha:** 2026-10-07
**Solicitante:** Paula Céspedes

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +110 días sobre la línea base vigente |
| Costo | 220.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
