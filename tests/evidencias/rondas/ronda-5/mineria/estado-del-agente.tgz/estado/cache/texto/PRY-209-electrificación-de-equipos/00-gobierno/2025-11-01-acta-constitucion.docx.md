<!-- origen: PRY-209-electrificación-de-equipos/00-gobierno/2025-11-01-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Electrificación de equipos

Código: PRY-209

Área dueña: Mina

Patrocinador: Andrés Lozano

Gerente de proyecto: Javier Hoyos

Comité: Comité de Seguridad

Producto asociado: No aplica

Fecha de aprobación: 2025-11-01

Objetivo del negocio

Entregar electrificación de equipos para Mina.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

3.300.000.000 COP, aprobado por Comité de Seguridad el 2025-11-01.

Fechas comprometidas

Fecha

Inicio

2025-11-11

Cierre

2026-12-31

Criterio de éxito

Electrificación de equipos en producción y medido.

Dependencias declaradas

• Ninguna declarada
