<!-- origen: PRY-203-despacho-automático-de-flota/10-plan/2026-10-13-cronograma-v2.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Ingeniería básica aprobada | 2026-05-31 | 2026-05-31 | cerrado
Ingeniería de detalle aprobada | 2026-08-13 | 2026-08-13 | cerrado
Licencia y permisos obtenidos | 2026-10-26 | 2026-10-26 | en curso
Montaje e instalación | 2027-01-08 | 2027-03-15 | en curso
