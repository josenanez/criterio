<!-- origen: PRY-201-ampliación-de-la-relavera/00-gobierno/2026-02-06-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Ampliación de la relavera

**Código:** PRY-201
**Área dueña:** Logística
**Patrocinador:** Felipe Arango
**Gerente de proyecto:** Jorge Medina
**Comité:** Comité de Tecnología
**Producto asociado:** No aplica
**Fecha de aprobación:** 2026-02-06

## Objetivo del negocio

Entregar ampliación de la relavera para Logística.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**800.000.000 COP**, aprobado por Comité de Tecnología el 2026-02-06.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-02-16 |
| Cierre | 2027-08-16 |

## Criterio de éxito

Ampliación de la relavera en producción y medido.

## Dependencias declaradas

- Ninguna declarada
