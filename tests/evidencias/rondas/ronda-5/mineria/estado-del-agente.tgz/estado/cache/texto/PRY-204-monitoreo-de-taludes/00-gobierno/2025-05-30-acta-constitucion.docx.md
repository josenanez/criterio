<!-- origen: PRY-204-monitoreo-de-taludes/00-gobierno/2025-05-30-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Monitoreo de taludes

Código: PRY-204

Área dueña: Mantenimiento

Patrocinador: Paula Céspedes

Gerente de proyecto: Ricardo Salas

Comité: Comité de Inversiones

Producto asociado: alerta de taludes

Fecha de aprobación: 2025-05-30

Objetivo del negocio

Entregar monitoreo de taludes para Mantenimiento.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

4.200.000.000 COP, aprobado por Comité de Inversiones el 2025-05-30.

Fechas comprometidas

Fecha

Inicio

2025-06-09

Cierre

2026-01-14

Criterio de éxito

Monitoreo de taludes en producción y medido.

Dependencias declaradas

• Ninguna declarada
