<!-- origen: PRY-205-sistema-de-gestión-de-seguridad/10-plan/2025-11-28-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Ingeniería básica aprobada,2026-04-15,2026-04-15,cerrado
Ingeniería de detalle aprobada,2026-08-21,2026-08-21,cerrado
Licencia y permisos obtenidos,2026-12-27,2026-12-27,en curso
