<!-- origen: PRY-208-trazabilidad-del-mineral/10-plan/2025-08-24-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Ingeniería básica aprobada,2026-01-09,2026-01-09,cerrado
Ingeniería de detalle aprobada,2026-05-18,2026-05-18,cerrado
Licencia y permisos obtenidos,2026-09-24,2026-09-24,cerrado
Montaje e instalación,2027-01-30,2027-01-30,en curso
