<!-- origen: PRY-203-despacho-automático-de-flota/20-seguimiento/2026-10-13-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Despacho automático de flota

**Código:** PRY-203
**Fecha de corte:** 2026-10-13
**Gerente:** Beatriz Cuéllar

## Estado declarado

**Rojo**

Avance reportado: **82%**

## Lo que pasó en el periodo

- Se levantó un hallazgo en la auditoría de seguridad

## Presupuesto

| | COP |
|---|---|
| Aprobado | 800.000.000 |
| Comprometido | 339.448.354 |
| Ejecutado | 389.245.930 |
| Proyección al cierre | 966.342.753 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
- Ventana de parada de planta definida por operaciones
