<!-- origen: PRY-210-programa-de-relacionamiento-comunitario/30-reuniones/2026-10-15-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité Ambiental · Programa de relacionamiento comunitario

**Fecha:** 2026-10-15
**Asistentes:** Laura Vélez, Carlos Peña

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Paula Céspedes | Entregar el punto 35 | por definir |
