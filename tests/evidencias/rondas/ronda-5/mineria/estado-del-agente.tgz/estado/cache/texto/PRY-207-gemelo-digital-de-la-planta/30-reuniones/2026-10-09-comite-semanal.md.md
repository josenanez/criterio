<!-- origen: PRY-207-gemelo-digital-de-la-planta/30-reuniones/2026-10-09-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Inversiones · Gemelo digital de la planta

**Fecha:** 2026-10-09
**Asistentes:** Natalia Ospina, Jorge Medina

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Beatriz Cuéllar | Entregar el punto 23 | 2026-10-16 |
