<!-- origen: PRY-203-despacho-automático-de-flota/30-reuniones/2026-10-14-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Seguridad · Despacho automático de flota

Fecha: 2026-10-14

Asistentes: Beatriz Cuéllar, Javier Hoyos

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Natalia Ospina

Entregar el punto 25

2026-11-08

Beatriz Cuéllar

Entregar el punto 23

2026-11-02
