<!-- origen: PRY-203-despacho-automático-de-flota/00-gobierno/2026-03-09-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Despacho automático de flota

**Código:** PRY-203
**Área dueña:** Geología
**Patrocinador:** Javier Hoyos
**Gerente de proyecto:** Beatriz Cuéllar
**Comité:** Comité de Seguridad
**Producto asociado:** despacho de flota
**Fecha de aprobación:** 2026-03-09

## Objetivo del negocio

Entregar despacho automático de flota para Geología.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**800.000.000 COP**, aprobado por Comité de Seguridad el 2026-03-09.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-03-19 |
| Cierre | 2027-02-14 |

## Criterio de éxito

Despacho automático de flota en producción y medido.

## Dependencias declaradas

- Ninguna declarada
