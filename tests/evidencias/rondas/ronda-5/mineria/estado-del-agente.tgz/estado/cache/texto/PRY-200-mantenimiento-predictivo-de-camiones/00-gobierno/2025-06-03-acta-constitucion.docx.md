<!-- origen: PRY-200-mantenimiento-predictivo-de-camiones/00-gobierno/2025-06-03-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Mantenimiento predictivo de camiones

Código: PRY-200

Área dueña: Medio Ambiente

Patrocinador: Andrés Lozano

Gerente de proyecto: Ricardo Salas

Comité: Comité de Operaciones

Producto asociado: monitoreo de flota

Fecha de aprobación: 2025-06-03

Objetivo del negocio

Entregar mantenimiento predictivo de camiones para Medio Ambiente.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

1.200.000.000 COP, aprobado por Comité de Operaciones el 2025-06-03.

Fechas comprometidas

Fecha

Inicio

2025-06-13

Cierre

2026-09-30

Criterio de éxito

Mantenimiento predictivo de camiones en producción y medido.

Dependencias declaradas

• Ninguna declarada
