<!-- origen: PRY-207-gemelo-digital-de-la-planta/10-plan/2025-12-01-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Ingeniería básica aprobada,2026-03-21,2026-03-21,cerrado
Ingeniería de detalle aprobada,2026-06-29,2026-06-29,cerrado
Licencia y permisos obtenidos,2026-10-08,2026-10-08,en curso
Montaje e instalación,2027-01-16,2027-01-16,en curso
Pruebas en operación,2027-04-26,2027-04-26,en curso
