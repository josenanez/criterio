<!-- origen: PRY-203-despacho-automático-de-flota/20-seguimiento/2026-10-09-solicitud-cambio-cc-01.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-01

**Proyecto:** PRY-203 · Despacho automático de flota
**Fecha:** 2026-10-09
**Solicitante:** Beatriz Cuéllar

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +66 días sobre la línea base vigente |
| Costo | 132.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
