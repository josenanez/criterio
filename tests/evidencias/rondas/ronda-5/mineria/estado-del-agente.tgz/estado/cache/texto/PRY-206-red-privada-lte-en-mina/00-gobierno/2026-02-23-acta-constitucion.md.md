<!-- origen: PRY-206-red-privada-lte-en-mina/00-gobierno/2026-02-23-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Red privada LTE en mina

**Código:** PRY-206
**Área dueña:** Tecnología
**Patrocinador:** Óscar Ramírez
**Gerente de proyecto:** Liliana Torres
**Comité:** Comité de Inversiones
**Producto asociado:** No aplica
**Fecha de aprobación:** 2026-02-23

## Objetivo del negocio

Entregar red privada lte en mina para Tecnología.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**6.800.000.000 COP**, aprobado por Comité de Inversiones el 2026-02-23.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-03-05 |
| Cierre | 2026-10-07 |

## Criterio de éxito

Red privada LTE en mina en producción y medido.

## Dependencias declaradas

- Ninguna declarada
