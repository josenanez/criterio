<!-- origen: PRY-211-control-de-polvo-en-vías/20-seguimiento/2026-10-14-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Control de polvo en vías

**Código:** PRY-211
**Fecha de corte:** 2026-10-14
**Gerente:** Elena Duarte

## Estado declarado

**Verde**

Avance reportado: **48%**

## Lo que pasó en el periodo

- Las lluvias detuvieron el montaje durante diez días
- Se levantó un hallazgo en la auditoría de seguridad
- El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite

## Presupuesto

| | COP |
|---|---|
| Aprobado | 800.000.000 |
| Comprometido | 479.425.244 |
| Ejecutado | 262.125.757 |
| Proyección al cierre | 835.519.093 |

## Riesgos abiertos

- Bloqueo de la vía de acceso a la mina
