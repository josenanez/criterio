<!-- origen: PRY-211-control-de-polvo-en-vías/10-plan/2025-09-30-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Ingeniería básica aprobada,2026-01-07,2026-01-07,cerrado
Ingeniería de detalle aprobada,2026-04-06,2026-04-06,cerrado
Licencia y permisos obtenidos,2026-07-05,2026-07-05,cerrado
Montaje e instalación,2026-10-02,2026-10-02,en curso
