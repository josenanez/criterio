<!-- origen: PRY-210-programa-de-relacionamiento-comunitario/00-gobierno/2026-05-11-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Programa de relacionamiento comunitario

Código: PRY-210

Área dueña: Medio Ambiente

Patrocinador: Carlos Peña

Gerente de proyecto: Laura Vélez

Comité: Comité Ambiental

Producto asociado: No aplica

Fecha de aprobación: 2026-05-11

Objetivo del negocio

Entregar programa de relacionamiento comunitario para Medio Ambiente.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

3.300.000.000 COP, aprobado por Comité Ambiental el 2026-05-11.

Fechas comprometidas

Fecha

Inicio

2026-05-21

Cierre

2027-08-31

Criterio de éxito

Programa de relacionamiento comunitario en producción y medido.

Dependencias declaradas

• Ninguna declarada
