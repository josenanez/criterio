<!-- origen: PRY-207-gemelo-digital-de-la-planta/00-gobierno/2025-12-01-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Gemelo digital de la planta

**Código:** PRY-207
**Área dueña:** Tecnología
**Patrocinador:** Jorge Medina
**Gerente de proyecto:** Natalia Ospina
**Comité:** Comité de Inversiones
**Producto asociado:** gemelo digital
**Fecha de aprobación:** 2025-12-01

## Objetivo del negocio

Entregar gemelo digital de la planta para Tecnología.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**9.500.000.000 COP**, aprobado por Comité de Inversiones el 2025-12-01.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-12-11 |
| Cierre | 2027-06-16 |

## Criterio de éxito

Gemelo digital de la planta en producción y medido.

## Dependencias declaradas

- Ninguna declarada
