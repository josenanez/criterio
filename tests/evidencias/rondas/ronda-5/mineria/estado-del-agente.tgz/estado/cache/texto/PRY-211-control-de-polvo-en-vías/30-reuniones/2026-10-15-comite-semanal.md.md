<!-- origen: PRY-211-control-de-polvo-en-vías/30-reuniones/2026-10-15-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Operaciones · Control de polvo en vías

**Fecha:** 2026-10-15
**Asistentes:** Elena Duarte, Javier Hoyos

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Rubén Cárdenas | Entregar el punto 17 | 2026-10-17 |
