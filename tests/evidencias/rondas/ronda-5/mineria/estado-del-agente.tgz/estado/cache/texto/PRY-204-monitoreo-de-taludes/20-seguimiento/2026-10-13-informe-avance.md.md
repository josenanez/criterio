<!-- origen: PRY-204-monitoreo-de-taludes/20-seguimiento/2026-10-13-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Monitoreo de taludes

**Código:** PRY-204
**Fecha de corte:** 2026-10-13
**Gerente:** Ricardo Salas

## Estado declarado

**Rojo**

Avance reportado: **77%**

## Lo que pasó en el periodo

- Se actualizó el presupuesto de la obra con el área de compras
- El proveedor entregó los equipos en el campamento, pendientes de aceptación

## Presupuesto

| | COP |
|---|---|
| Aprobado | 4.200.000.000 |
| Comprometido | 1.381.230.197 |
| Ejecutado | 1.091.528.211 |
| Proyección al cierre | 3.896.903.162 |

## Riesgos abiertos

- Cambio en la licencia ambiental que puede mover el alcance
