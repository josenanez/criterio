<!-- origen: PRY-200-mantenimiento-predictivo-de-camiones/00-gobierno/ficha-pm.json · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

{
 "schema_version": "0.2",
 "identity": {
 "code": {
 "value": "PRY-200",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/00-gobierno/2025-06-03-acta-constitucion.docx",
 "source_date": "2025-06-03",
 "state": "found"
 },
 "name": {
 "value": "Mantenimiento predictivo de camiones",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/00-gobierno/2025-06-03-acta-constitucion.docx",
 "source_date": "2025-06-03",
 "state": "found"
 },
 "aliases": [],
 "business_area": {
 "value": "Medio Ambiente",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/00-gobierno/2025-06-03-acta-constitucion.docx",
 "source_date": "2025-06-03",
 "state": "found"
 },
 "product": {
 "value": "monitoreo de flota",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/00-gobierno/2025-06-03-acta-constitucion.docx",
 "source_date": "2025-06-03",
 "state": "found"
 },
 "authority": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "sponsor": {
 "value": "Andrés Lozano",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/00-gobierno/2025-06-03-acta-constitucion.docx",
 "source_date": "2025-06-03",
 "state": "found"
 },
 "manager": {
 "value": "Ricardo Salas",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/00-gobierno/2025-06-03-acta-constitucion.docx",
 "source_date": "2025-06-03",
 "state": "found"
 },
 "committee": {
 "value": "Comité de Operaciones",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/00-gobierno/2025-06-03-acta-constitucion.docx",
 "source_date": "2025-06-03",
 "state": "found"
 },
 "phase": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 }
 },
 "declared": {
 "status": "amarillo",
 "progress_pct": 54,
 "as_of": "2026-10-14",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/20-seguimiento/2026-10-14-informe-avance.md",
 "source_kind": "declaration"
 },
 "plan": {
 "start_date": {
 "value": "2025-06-13",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/00-gobierno/2025-06-03-acta-constitucion.docx",
 "source_date": "2025-06-03",
 "state": "found"
 },
 "end_date": {
 "value": "2026-09-30",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/00-gobierno/2025-06-03-acta-constitucion.docx",
 "source_date": "2025-06-03",
 "state": "found"
 },
 "baseline": [
 {
 "version": 1,
 "approved_on": "2025-06-03",
 "start_date": "2025-06-13",
 "end_date": "2026-09-30",
 "reason": "Acta de constitución",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/00-gobierno/2025-06-03-acta-constitucion.docx"
 }
 ],
 "milestones": [
 {
 "name": "Ingeniería básica aprobada",
 "baseline_date": "2025-09-26",
 "current_date": "2025-09-26",
 "state": "met",
 "evidence": null,
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/10-plan/2025-06-03-cronograma-v1.csv"
 },
 {
 "name": "Ingeniería de detalle aprobada",
 "baseline_date": "2026-01-09",
 "current_date": "2026-01-09",
 "state": "met",
 "evidence": null,
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/10-plan/2025-06-03-cronograma-v1.csv"
 },
 {
 "name": "Licencia y permisos obtenidos",
 "baseline_date": "2026-04-25",
 "current_date": "2026-04-25",
 "state": "met",
 "evidence": null,
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/10-plan/2025-06-03-cronograma-v1.csv"
 },
 {
 "name": "Montaje e instalación",
 "baseline_date": "2026-08-08",
 "current_date": "2026-08-08",
 "state": "met",
 "evidence": null,
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/10-plan/2025-06-03-cronograma-v1.csv"
 }
 ],
 "scope_summary": {
 "value": "Componentes 1, 2 y 3",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/00-gobierno/2025-06-03-acta-constitucion.docx",
 "source_date": "2025-06-03",
 "state": "found"
 },
 "exclusions": [
 "Lo que otro proyecto cubre"
 ]
 },
 "money": {
 "currency": "COP",
 "approved": {
 "value": 1200000000,
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/20-seguimiento/2026-10-14-informe-avance.md",
 "source_date": "2026-10-14",
 "state": "found"
 },
 "committed": {
 "value": 390173338,
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/20-seguimiento/2026-10-14-informe-avance.md",
 "source_date": "2026-10-14",
 "state": "found"
 },
 "executed": {
 "value": 438812017,
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/20-seguimiento/2026-10-14-informe-avance.md",
 "source_date": "2026-10-14",
 "state": "found"
 },
 "projection": {
 "value": 1175719466,
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/20-seguimiento/2026-10-14-informe-avance.md",
 "source_date": "2026-10-14",
 "state": "found"
 }
 },
 "vendors": [],
 "raid": {
 "risks": [
 {
 "what": "El proveedor no ha confirmado la fecha de la última entrega",
 "probability": null,
 "impact": null,
 "owner": null,
 "due_date": null,
 "last_moved": null,
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/20-seguimiento/2026-10-14-informe-avance.md"
 },
 {
 "what": "El proveedor podría no llegar con el equipo completo para la siguiente fase (se comentó; nadie lo registró)",
 "probability": null,
 "impact": null,
 "owner": null,
 "due_date": null,
 "last_moved": null,
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/2026-10-16-notas-reunion.txt"
 }
 ],
 "assumptions": [],
 "issues": [
 {
 "what": "Las lluvias detuvieron el montaje durante diez días",
 "since": null,
 "owner": null,
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/20-seguimiento/2026-10-14-informe-avance.md"
 },
 {
 "what": "El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite",
 "since": null,
 "owner": null,
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/20-seguimiento/2026-10-14-informe-avance.md"
 }
 ],
 "dependencies": []
 },
 "changes": [],
 "commitments": [
 {
 "who": "Elena Duarte",
 "what": "Enviar el documento 1",
 "due_date": "2026-12-12",
 "original_due_date": "2026-09-19",
 "stated_on": "2026-09-04",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-09-04-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-09-26",
 "stated_on": "2026-09-11",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-09-11-comite-semanal.md"
 },
 {
 "due_date": "2026-10-17",
 "stated_on": "2026-09-18",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-09-18-comite-semanal.md"
 },
 {
 "due_date": "2026-11-02",
 "stated_on": "2026-09-25",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-09-25-comite-semanal.md"
 },
 {
 "due_date": "2026-11-18",
 "stated_on": "2026-10-02",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-10-02-comite-semanal.md"
 },
 {
 "due_date": "2026-11-28",
 "stated_on": "2026-10-09",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-10-09-comite-semanal.md"
 },
 {
 "due_date": "2026-12-12",
 "stated_on": "2026-10-16",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/2026-10-16-notas-reunion.txt"
 }
 ]
 },
 {
 "who": "Diana Molina",
 "what": "Cerrar la prueba 2",
 "due_date": "2026-11-14",
 "original_due_date": "2026-09-15",
 "stated_on": "2026-09-04",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-09-04-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-09-23",
 "stated_on": "2026-09-11",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-09-11-comite-semanal.md"
 },
 {
 "due_date": "2026-10-02",
 "stated_on": "2026-09-18",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-09-18-comite-semanal.md"
 },
 {
 "due_date": "2026-10-13",
 "stated_on": "2026-09-25",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-09-25-comite-semanal.md"
 },
 {
 "due_date": "2026-10-25",
 "stated_on": "2026-10-02",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-10-02-comite-semanal.md"
 },
 {
 "due_date": "2026-11-14",
 "stated_on": "2026-10-09",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-10-09-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Óscar Ramírez",
 "what": "Revisar el anexo 3",
 "due_date": "2026-10-18",
 "original_due_date": "2026-09-12",
 "stated_on": "2026-09-04",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-09-04-comite-semanal.md",
 "state": "met",
 "reschedules": [
 {
 "due_date": "2026-09-22",
 "stated_on": "2026-09-11",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-09-11-comite-semanal.md"
 },
 {
 "due_date": "2026-10-09",
 "stated_on": "2026-09-18",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-09-18-comite-semanal.md"
 },
 {
 "due_date": "2026-10-18",
 "stated_on": "2026-10-02",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-10-02-comite-semanal.md"
 }
 ],
 "evidence": "PRY-200-mantenimiento-predictivo-de-camiones/20-seguimiento/2026-10-09-acta-recibo-3.md"
 },
 {
 "who": "Sandra Gil",
 "what": "Validar el ambiente 4",
 "due_date": "2026-10-04",
 "original_due_date": "2026-09-13",
 "stated_on": "2026-09-04",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-09-04-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-09-20",
 "stated_on": "2026-09-11",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-09-11-comite-semanal.md"
 },
 {
 "due_date": "2026-10-04",
 "stated_on": "2026-09-25",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-09-25-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Liliana Torres",
 "what": "Aprobar el diseño 5",
 "due_date": "2026-10-04",
 "original_due_date": "2026-09-24",
 "stated_on": "2026-09-11",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-09-11-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-04",
 "stated_on": "2026-09-25",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-09-25-comite-semanal.md"
 }
 ],
 "note": "El 2026-10-02 dice que ya lo entregó; no se presentó acta. Dejó de aparecer en la tabla."
 },
 {
 "who": "Ricardo Salas",
 "what": "Actualizar la matriz 6",
 "due_date": "2026-09-16",
 "original_due_date": "2026-09-16",
 "stated_on": "2026-09-11",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-09-11-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "PRY-200-mantenimiento-predictivo-de-camiones/20-seguimiento/2026-10-09-acta-recibo-6.md"
 },
 {
 "who": "Javier Hoyos",
 "what": "Confirmar la fecha 7",
 "due_date": "2026-10-28",
 "original_due_date": "2026-09-16",
 "stated_on": "2026-09-11",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-09-11-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-09-26",
 "stated_on": "2026-09-18",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-09-18-comite-semanal.md"
 },
 {
 "due_date": "2026-10-16",
 "stated_on": "2026-10-02",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-10-02-comite-semanal.md"
 },
 {
 "due_date": "2026-10-28",
 "stated_on": "2026-10-09",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-10-09-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Andrés Lozano",
 "what": "Entregar el punto 8",
 "due_date": "2026-10-13",
 "original_due_date": "2026-09-26",
 "stated_on": "2026-09-11",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-09-11-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-13",
 "stated_on": "2026-09-18",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-09-18-comite-semanal.md"
 }
 ],
 "note": "El 2026-10-02 dice que ya lo entregó; no se presentó acta. Dejó de aparecer en la tabla."
 },
 {
 "who": "Sandra Gil",
 "what": "Enviar el documento 9",
 "due_date": "2026-10-27",
 "original_due_date": "2026-09-29",
 "stated_on": "2026-09-18",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-09-18-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-12",
 "stated_on": "2026-09-25",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-09-25-comite-semanal.md"
 },
 {
 "due_date": "2026-10-27",
 "stated_on": "2026-10-09",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-10-09-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Felipe Arango",
 "what": "Cerrar la prueba 10",
 "due_date": "2026-11-11",
 "original_due_date": "2026-10-03",
 "stated_on": "2026-09-18",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-09-18-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-22",
 "stated_on": "2026-10-02",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-10-02-comite-semanal.md"
 },
 {
 "due_date": "2026-11-11",
 "stated_on": "2026-10-09",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-10-09-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Elena Duarte",
 "what": "Revisar el anexo 11",
 "due_date": "2026-10-19",
 "original_due_date": "2026-10-04",
 "stated_on": "2026-09-18",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-09-18-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-19",
 "stated_on": "2026-10-09",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-10-09-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Beatriz Cuéllar",
 "what": "Validar el ambiente 12",
 "due_date": "2026-10-04",
 "original_due_date": "2026-10-04",
 "stated_on": "2026-09-18",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-09-18-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "PRY-200-mantenimiento-predictivo-de-camiones/20-seguimiento/2026-10-02-acta-recibo-12.md"
 },
 {
 "who": "Jorge Medina",
 "what": "Aprobar el diseño 13",
 "due_date": "2026-10-28",
 "original_due_date": "2026-10-09",
 "stated_on": "2026-09-25",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-09-25-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-28",
 "stated_on": "2026-10-09",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-10-09-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Jorge Medina",
 "what": "Actualizar la matriz 14",
 "due_date": "2026-11-09",
 "original_due_date": "2026-10-20",
 "stated_on": "2026-09-25",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-09-25-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-11-09",
 "stated_on": "2026-10-02",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-10-02-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Carlos Peña",
 "what": "Confirmar la fecha 15",
 "due_date": "2026-11-23",
 "original_due_date": "2026-10-19",
 "stated_on": "2026-09-25",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-09-25-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-11-06",
 "stated_on": "2026-10-02",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-10-02-comite-semanal.md"
 },
 {
 "due_date": "2026-11-23",
 "stated_on": "2026-10-09",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-10-09-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Jorge Medina",
 "what": "Entregar el punto 16",
 "due_date": "2026-10-12",
 "original_due_date": "2026-10-12",
 "stated_on": "2026-09-25",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-09-25-comite-semanal.md",
 "state": "open",
 "reschedules": [],
 "note": "El 2026-10-02 dice que ya lo entregó; no se presentó acta. Dejó de aparecer en la tabla."
 },
 {
 "who": "Sandra Gil",
 "what": "Enviar el documento 17",
 "due_date": "2026-11-07",
 "original_due_date": "2026-10-30",
 "stated_on": "2026-10-02",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-10-02-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-11-07",
 "stated_on": "2026-10-09",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-10-09-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Gustavo Neira",
 "what": "Cerrar la prueba 18",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-10-02",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-10-02-comite-semanal.md",
 "state": "open",
 "reschedules": [],
 "note": "«por definir» en dos reuniones seguidas."
 },
 {
 "who": "Felipe Arango",
 "what": "Revisar el anexo 19",
 "due_date": "2026-10-18",
 "original_due_date": "2026-10-18",
 "stated_on": "2026-10-02",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-10-02-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Diana Molina",
 "what": "Validar el ambiente 20",
 "due_date": "2026-10-15",
 "original_due_date": "2026-10-15",
 "stated_on": "2026-10-02",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-10-02-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Ricardo Salas",
 "what": "Aprobar el diseño 21",
 "due_date": "2026-10-23",
 "original_due_date": "2026-10-23",
 "stated_on": "2026-10-09",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-10-09-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "María Restrepo",
 "what": "Actualizar la matriz 22",
 "due_date": "2026-10-24",
 "original_due_date": "2026-10-24",
 "stated_on": "2026-10-09",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-10-09-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Javier Hoyos",
 "what": "Confirmar la fecha 23",
 "due_date": "2026-10-13",
 "original_due_date": "2026-10-13",
 "stated_on": "2026-10-09",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-10-09-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Natalia Ospina",
 "what": "Entregar el punto 24",
 "due_date": "2026-10-17",
 "original_due_date": "2026-10-17",
 "stated_on": "2026-10-09",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-10-09-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Laura Vélez",
 "what": "Mandar el ajuste del presupuesto",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-10-16",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/2026-10-16-notas-reunion.txt",
 "state": "open",
 "reschedules": [],
 "note": "«la otra semana»: nadie dijo fecha."
 },
 {
 "who": "Óscar Ramírez",
 "what": "Revisión con el proveedor",
 "due_date": "2026-10-26",
 "original_due_date": "2026-10-26",
 "stated_on": "2026-10-16",
 "source": "PRY-200-mantenimiento-predictivo-de-camiones/2026-10-16-notas-reunion.txt",
 "state": "open",
 "reschedules": [],
 "note": "Se registra aparte del anexo 3 (cerrado el 2026-10-09); las notas no los relacionan."
 }
 ],
 "meta": {
 "record_updated": "2026-10-16",
 "documents_seen": [
 {
 "path": "PRY-200-mantenimiento-predictivo-de-camiones/00-gobierno/2025-06-03-acta-constitucion.docx",
 "hash": "c453ba62908b4fbed7f8011680255bb5cda016cb2767cee98f5518474d30441c",
 "text_hash": null,
 "date": "2025-06-03"
 },
 {
 "path": "PRY-200-mantenimiento-predictivo-de-camiones/10-plan/2025-06-03-cronograma-v1.csv",
 "hash": "10b0ef8a89ce738602b1485daabb748f83e0be4e8e2f77bcfa360d4fea83b09e",
 "text_hash": null,
 "date": "2025-06-03"
 },
 {
 "path": "PRY-200-mantenimiento-predictivo-de-camiones/20-seguimiento/2026-10-02-acta-recibo-12.md",
 "hash": "3a0a3f0420c314009dcbe29f9d10451679b5dae2aaf20fb3bf2bf144e5e002e8",
 "text_hash": null,
 "date": "2026-10-02"
 },
 {
 "path": "PRY-200-mantenimiento-predictivo-de-camiones/20-seguimiento/2026-10-09-acta-recibo-3.md",
 "hash": "0b98cb74f49c71a1e0987be0782e1404b132c52e8f1c9a5e448a8877fcced36e",
 "text_hash": null,
 "date": "2026-10-09"
 },
 {
 "path": "PRY-200-mantenimiento-predictivo-de-camiones/20-seguimiento/2026-10-09-acta-recibo-6.md",
 "hash": "39d5cd7387b1ac4ee4677be8d436a1d2080eca56e2b5b26d76ff83bc06e80fe1",
 "text_hash": null,
 "date": "2026-10-09"
 },
 {
 "path": "PRY-200-mantenimiento-predictivo-de-camiones/20-seguimiento/2026-10-14-informe-avance.md",
 "hash": "808896c92df2b6c9647271bb9fb4e0ed8a693502733769ac9d1979baac038d18",
 "text_hash": null,
 "date": "2026-10-14"
 },
 {
 "path": "PRY-200-mantenimiento-predictivo-de-camiones/2026-10-16-notas-reunion.txt",
 "hash": "1ab035f25f8f5206d83870956b46dc61317371532a1f40f706265ad22bdbf2df",
 "text_hash": null,
 "date": "2026-10-16"
 },
 {
 "path": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-09-04-comite-semanal.md",
 "hash": "e6224369538278b4e4d263f257fef8a753e727b7a085cd0dd4f3a663adbbabf5",
 "text_hash": null,
 "date": "2026-09-04"
 },
 {
 "path": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-09-11-comite-semanal.md",
 "hash": "29d6991af3d93726e5a9a8c350df236015e481a22ee2cce3af4708b65c50b40d",
 "text_hash": null,
 "date": "2026-09-11"
 },
 {
 "path": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-09-18-comite-semanal.md",
 "hash": "fd92b9bbf54a8e74719be025b4889aedebdb21ef96633601bf5819a23e94512a",
 "text_hash": null,
 "date": "2026-09-18"
 },
 {
 "path": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-09-25-comite-semanal.md",
 "hash": "c3aec04931fac091f16856883cd1f169a08ddff5539f5613201a01d92154cd15",
 "text_hash": null,
 "date": "2026-09-25"
 },
 {
 "path": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-10-02-comite-semanal.md",
 "hash": "7d0f4403548d7e41d214ae82cb21dcc81e6a044ec32310082ed99b31a4efa47f",
 "text_hash": null,
 "date": "2026-10-02"
 },
 {
 "path": "PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-10-09-comite-semanal.md",
 "hash": "18645fdc6f4cb7b926179dfea765d5a19b042f33fc87dc0a2064f6e2ee2db666",
 "text_hash": null,
 "date": "2026-10-09"
 }
 ],
 "fields_not_found": [
 "identity.authority",
 "identity.phase"
 ],
 "open_conflicts": []
 }
}
