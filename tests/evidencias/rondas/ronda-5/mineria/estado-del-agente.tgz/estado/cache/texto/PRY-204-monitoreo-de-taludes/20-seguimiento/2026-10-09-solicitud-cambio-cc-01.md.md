<!-- origen: PRY-204-monitoreo-de-taludes/20-seguimiento/2026-10-09-solicitud-cambio-cc-01.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-01

**Proyecto:** PRY-204 · Monitoreo de taludes
**Fecha:** 2026-10-09
**Solicitante:** Ricardo Salas

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +61 días sobre la línea base vigente |
| Costo | 122.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
