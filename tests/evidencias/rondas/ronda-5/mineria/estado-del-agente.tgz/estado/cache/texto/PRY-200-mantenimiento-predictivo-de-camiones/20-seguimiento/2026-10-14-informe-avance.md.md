<!-- origen: PRY-200-mantenimiento-predictivo-de-camiones/20-seguimiento/2026-10-14-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Mantenimiento predictivo de camiones

**Código:** PRY-200
**Fecha de corte:** 2026-10-14
**Gerente:** Ricardo Salas

## Estado declarado

**Amarillo**

Avance reportado: **54%**

## Lo que pasó en el periodo

- Las lluvias detuvieron el montaje durante diez días
- El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite

## Presupuesto

| | COP |
|---|---|
| Aprobado | 1.200.000.000 |
| Comprometido | 390.173.338 |
| Ejecutado | 438.812.017 |
| Proyección al cierre | 1.175.719.466 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
