<!-- origen: PRY-201-ampliación-de-la-relavera/20-seguimiento/2026-10-15-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Ampliación de la relavera
Código: PRY-201
Fecha de corte: 2026-10-15
Gerente: Jorge Medina

Estado declarado
Amarillo
Avance reportado: 58%

Lo que pasó en el periodo
- Se levantó un hallazgo en la auditoría de seguridad
- Se actualizó el presupuesto de la obra con el área de compras

Presupuesto
COP
Aprobado 800.000.000
Comprometido 442.122.350
Ejecutado 199.320.802
Proyección al cierre 775.123.302

Riesgos abiertos
- Cambio en la licencia ambiental que puede mover el alcance
- El proveedor no ha confirmado la fecha de la última entrega
