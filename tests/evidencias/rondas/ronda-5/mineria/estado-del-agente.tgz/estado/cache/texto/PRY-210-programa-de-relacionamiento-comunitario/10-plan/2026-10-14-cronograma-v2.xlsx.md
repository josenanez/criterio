<!-- origen: PRY-210-programa-de-relacionamiento-comunitario/10-plan/2026-10-14-cronograma-v2.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Ingeniería básica aprobada | 2026-08-13 | 2026-08-13 | cerrado
Ingeniería de detalle aprobada | 2026-11-06 | 2026-11-06 | en curso
Licencia y permisos obtenidos | 2027-01-30 | 2027-01-30 | en curso
Montaje e instalación | 2027-04-25 | 2027-04-25 | en curso
Pruebas en operación | 2027-07-19 | 2027-08-21 | en curso
