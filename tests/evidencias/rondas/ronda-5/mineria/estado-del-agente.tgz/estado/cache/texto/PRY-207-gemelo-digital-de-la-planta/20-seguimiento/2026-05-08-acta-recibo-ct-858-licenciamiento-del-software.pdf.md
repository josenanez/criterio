<!-- origen: PRY-207-gemelo-digital-de-la-planta/20-seguimiento/2026-05-08-acta-recibo-ct-858-licenciamiento-del-software.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de recibo · Licenciamiento del software
Proyecto: PRY-207 · Gemelo digital de la planta
Fecha de recibo: 2026-05-08
Recibido por: Natalia Ospina
Se recibe a satisfacción el entregable Licenciamiento del software.
Contrato CT-858 · Automatización de Procesos Ltda..
