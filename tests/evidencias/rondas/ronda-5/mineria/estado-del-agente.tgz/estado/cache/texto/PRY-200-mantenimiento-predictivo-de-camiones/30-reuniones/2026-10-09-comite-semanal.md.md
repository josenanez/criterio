<!-- origen: PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-10-09-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Operaciones · Mantenimiento predictivo de camiones

**Fecha:** 2026-10-09
**Asistentes:** Carlos Peña, Diana Molina, Elena Duarte, Felipe Arango, Gustavo Neira, Javier Hoyos, Jorge Medina, María Restrepo, Natalia Ospina, Ricardo Salas, Sandra Gil

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Elena Duarte | Enviar el documento 1 | 2026-11-28 |
| Diana Molina | Cerrar la prueba 2 | 2026-11-14 |
| Sandra Gil | Validar el ambiente 4 | 2026-10-04 |
| Javier Hoyos | Confirmar la fecha 7 | 2026-10-28 |
| Sandra Gil | Enviar el documento 9 | 2026-10-27 |
| Felipe Arango | Cerrar la prueba 10 | 2026-11-11 |
| Elena Duarte | Revisar el anexo 11 | 2026-10-19 |
| Jorge Medina | Aprobar el diseño 13 | 2026-10-28 |
| Jorge Medina | Actualizar la matriz 14 | 2026-11-09 |
| Carlos Peña | Confirmar la fecha 15 | 2026-11-23 |
| Sandra Gil | Enviar el documento 17 | 2026-11-07 |
| Gustavo Neira | Cerrar la prueba 18 | por definir |
| Felipe Arango | Revisar el anexo 19 | 2026-10-18 |
| Diana Molina | Validar el ambiente 20 | 2026-10-15 |
| Ricardo Salas | Aprobar el diseño 21 | 2026-10-23 |
| María Restrepo | Actualizar la matriz 22 | 2026-10-24 |
| Javier Hoyos | Confirmar la fecha 23 | 2026-10-13 |
| Natalia Ospina | Entregar el punto 24 | 2026-10-17 |

## Cerrados en esta reunión

- Revisar el anexo 3 (Óscar Ramírez): recibido, acta de recibo del 2026-10-09.
- Actualizar la matriz 6 (Ricardo Salas): recibido, acta de recibo del 2026-10-09.
