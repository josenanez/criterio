<!-- origen: PRY-208-trazabilidad-del-mineral/00-gobierno/2025-08-24-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Trazabilidad del mineral

Código: PRY-208

Área dueña: Medio Ambiente

Patrocinador: Natalia Ospina

Gerente de proyecto: Paula Céspedes

Comité: Comité de Inversiones

Producto asociado: trazabilidad

Fecha de aprobación: 2025-08-24

Objetivo del negocio

Entregar trazabilidad del mineral para Medio Ambiente.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

2.400.000.000 COP, aprobado por Comité de Inversiones el 2025-08-24.

Fechas comprometidas

Fecha

Inicio

2025-09-03

Cierre

2027-04-05

Criterio de éxito

Trazabilidad del mineral en producción y medido.

Dependencias declaradas

• Ninguna declarada
