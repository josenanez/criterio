<!-- origen: PRY-201-ampliación-de-la-relavera/10-plan/2026-02-06-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Ingeniería básica aprobada,2026-07-22,2026-07-22,cerrado
Ingeniería de detalle aprobada,2026-12-25,2026-12-25,en curso
Licencia y permisos obtenidos,2027-05-30,2027-05-30,en curso
