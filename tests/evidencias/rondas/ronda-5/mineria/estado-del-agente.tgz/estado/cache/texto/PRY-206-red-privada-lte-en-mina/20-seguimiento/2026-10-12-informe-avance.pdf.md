<!-- origen: PRY-206-red-privada-lte-en-mina/20-seguimiento/2026-10-12-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Red privada LTE en mina
Código: PRY-206
Fecha de corte: 2026-10-12
Gerente: Liliana Torres

Estado declarado
Verde
Avance reportado: 80%

Lo que pasó en el periodo
- Se reprogramó la parada de planta por la ventana de mantenimiento

Presupuesto
COP
Aprobado 6.800.000.000
Comprometido 4.816.495.906
Ejecutado 2.629.808.719
Proyección al cierre 7.517.983.731

Riesgos abiertos
- El proveedor no ha confirmado la fecha de la última entrega
- Concentración del conocimiento en una sola persona
