<!-- origen: PRY-204-monitoreo-de-taludes/10-plan/2026-10-13-cronograma-v2.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Ingeniería básica aprobada | 2025-07-27 | 2025-07-27 | cerrado
Ingeniería de detalle aprobada | 2025-09-14 | 2025-09-14 | cerrado
Licencia y permisos obtenidos | 2025-11-02 | 2025-11-02 | cerrado
Montaje e instalación | 2025-12-20 | 2026-02-19 | cerrado
