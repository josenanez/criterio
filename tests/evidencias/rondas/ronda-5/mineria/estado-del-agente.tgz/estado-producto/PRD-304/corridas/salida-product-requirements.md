## Registro — Trazabilidad (PRD-304) · al 2026-10-16
16 requerimientos · 14 decididos · 78,6 % con evidencia · 0 % con proyecto que lo ejecuta

Gerente de producto: Gustavo Neira. Quien decide: Comité de producto. Fuente de los estados: acta del comité del 2026-10-13 (`documentos/productos/PRD-304/30-decisiones/2026-10-13-comite-producto.docx`).

**Dos salvedades antes de leer las tablas:**
- El 78,6 % es generoso. La única evidencia que sostiene a los 11 requerimientos que la tienen es una entrevista del 2025-08-15 («Lo necesito y hoy no lo tengo.»), y el registro anota que la cita no nombra ninguno de ellos. Sostiene la necesidad del producto, no cada requerimiento.
- El 0 % con proyecto sale de que el acta dice «—» en la columna de proyecto de los 14 aceptados. No había carpeta de fichas de proyecto contra la que confirmarlo (`estado/` está vacía), así que no se pudo comprobar si algún proyecto de la carpeta (por ejemplo PRY-208 «Trazabilidad del mineral») ejecuta alguno. Está sin verificar, no confirmado como ausente.

### Se va a construir y nadie lo pidió
| REQ | Título | Estado | Doliente |
|---|---|---|---|
| REQ-2036 | Requerimiento REQ-2036 | aceptado el 2026-10-05 | Liliana Torres |
| REQ-4407 | Requerimiento REQ-4407 | aceptado el 2026-07-28 | Diana Molina |
| REQ-4410 | Requerimiento REQ-4410 | aceptado el 2026-06-15 | Jorge Medina |

Ninguno tiene una sola cita de quien lo pidió. REQ-2036 es el más reciente y el que menos tiene: tampoco trae criterio de aceptación.

### Decidido y nadie lo está construyendo
Los 14 aceptados. Ninguno tiene proyecto registrado. Del más antiguo al más reciente:

| REQ | Decidido el |
|---|---|
| REQ-4403 | 2026-03-20 |
| REQ-4412 | 2026-03-30 |
| REQ-4406 | 2026-04-02 |
| REQ-4408 | 2026-04-02 |
| REQ-4405 | 2026-06-07 |
| REQ-4410 | 2026-06-15 |
| REQ-4402 | 2026-07-02 |
| REQ-4409 | 2026-07-12 |
| REQ-4407 | 2026-07-28 |
| REQ-4413 | 2026-08-10 |
| REQ-4401 | 2026-08-19 |
| REQ-4404 | 2026-08-22 |
| REQ-2028 | 2026-09-24 |
| REQ-2036 | 2026-10-05 |

Cuatro llevan más de seis meses aceptados sin proyecto (REQ-4403, 4412, 4406 y 4408).

### Sin doliente, o con un área en vez de una persona
| REQ | Título | Dice |
|---|---|---|
| REQ-4401 | Requerimiento REQ-4401 | «sin asignar» |
| REQ-4402 | Requerimiento REQ-4402 | «sin asignar» |
| REQ-4405 | Requerimiento REQ-4405 | «sin asignar» |

Los tres están aceptados. Los cierra el gerente de producto, Gustavo Neira, nombrando una persona.

### Sin criterio de aceptación
| REQ | Título | Estado |
|---|---|---|
| REQ-2028 | Requerimiento REQ-2028 | aceptado |
| REQ-2036 | Requerimiento REQ-2036 | aceptado |
| REQ-4402 | Requerimiento REQ-4402 | aceptado |
| REQ-4412 | Requerimiento REQ-4412 | aceptado |

Solo decididos. Los dos propuestos no se listan: nadie ha dicho todavía que se hacen. Quien lo cierra es el doliente de cada uno (María Restrepo, L. Torres, sin asignar, C. Peña). Los criterios que sí existen son frases como «se verifica en producción», que el registro recoge tal cual y que no dicen cómo medir; esa discusión queda para el borrador de especificación.

### Decidido sin documento que lo respalde
Los 14 aceptados tienen el acta del comité del 2026-10-13 como documento, pero **en ninguno el acta dice quién los aceptó**. La decisión está escrita con fecha y sin nombre.

| REQ | Quién decidió | Cuándo |
|---|---|---|
| Los 14 aceptados | no consta en el acta | desde 2026-03-20 hasta 2026-10-05 |

Además, el acta es del 2026-10-13 y recoge decisiones de entre marzo y octubre: se registraron después, algunas casi siete meses después. Cerrarlo es pedirle al Comité de producto que deje constancia de quién decidió.

### Lleva meses y nadie lo decide
Umbral de la configuración: 60 días.

| REQ | Título | Propuesto hace | Quién tiene la facultad |
|---|---|---|---|
| REQ-4411 | Requerimiento REQ-4411 (doliente Felipe Arango; sin evidencia ni criterio) | 176 días (desde 2026-04-23) | Comité de producto |
| REQ-4400 | Requerimiento REQ-4400 (doliente Carlos Peña; evidencia de 2025-08-15 y un criterio) | 155 días (desde 2026-05-14) | Comité de producto |

Se propone llevarlos al próximo comité para aceptar o descartar. Un descarte queda con su acta, para que no vuelva a discutirse.

### Evidencia vieja
Umbral: 12 meses. Todo lo que hay es la misma entrevista del 2025-08-15, con 14 meses.

| REQ | Lo más nuevo que lo sostiene | Hace |
|---|---|---|
| REQ-2028, 4400, 4401, 4402, 4403, 4404, 4405, 4406, 4408, 4409, 4412, 4413 (12) | entrevista 2025-08-15 | 14 meses |

REQ-4400 es propuesto: la edad de su evidencia es dato, no vacío que se le exija cerrar.

### Aparte: el caso de negocio declara más de lo que se mide
Volumen mensual: el caso de negocio (2026-02-26) declara 151.914; la bodega de datos mide 116.821 (2026-10-14). Diferencia de 23,1 % con lo declarado por encima, sobre el umbral de 20 %. Criterio de éxito de la definición: no está dicho en ningún documento.

## Por estado
| propuesto | aceptado | en construcción | entregado | descartado |
|---|---|---|---|---|
| 2 | 14 | 0 | 0 | 0 |

Nada pasa de aceptado: ninguno en construcción, entregado ni descartado.

Siguiente paso posible: `/product-trace`, por los 14 decididos sin proyecto confirmado. `/product-charter` no se ofrece todavía: los aceptados que tienen doliente y criterio (REQ-4403, 4404, 4406, 4408, 4409, 4413) solo cuentan con la evidencia genérica de hace 14 meses y sin quién los decidió.
