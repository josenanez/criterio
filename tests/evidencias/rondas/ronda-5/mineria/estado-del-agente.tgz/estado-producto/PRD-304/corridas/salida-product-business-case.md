# Caso de negocio — Trazabilidad (PRD-304) · borrador del 2026-10-16
**Desde:** `00-definicion/2026-02-26-definicion-producto.docx` (2026-02-26) y `00-definicion/2026-02-26-caso-de-negocio.md` (2026-02-26) · **Cifras con fuente:** 2 de 2 con valor (volumen declarado y volumen medido); el retorno y los costos no traen cifra y van a vacíos.

Nota de la prueba: sin interfaz, se tomaron las respuestas sugeridas. Términos vigentes (v0.3.11), aceptados por José Francisco Ñáñez el 2026-10-16; no hubo que registrarlos de nuevo. Este borrador no recomienda aprobar ni rechazar.

## Qué problema resuelve, y para quién
- **Problema:** «El segmento Mantenimiento no tiene trazabilidad.» (definición, 2026-02-26). Qué cuenta como «tener trazabilidad» no está definido, ni hay línea base.
- **Para quién:** segmento Mantenimiento (definición, 2026-02-26).
- **Propuesta:** la definición trae el rótulo «Propuesta principal» sin texto debajo. No se inventa.

## Qué se construye
Entran los 14 requerimientos aceptados del acta del comité del 2026-10-13 (`30-decisiones/2026-10-13-comite-producto.docx`). Los 2 propuestos (REQ-4400, REQ-4411) quedan fuera: nadie ha dicho que se hacen. En el acta, ninguno de los 14 tiene proyecto («—») y ninguno dice quién lo aceptó.

| Requerimiento | Estado | Evidencia de demanda |
|---|---|---|
| REQ-4401, 4402, 4403, 4404, 4405, 4406, 4408, 4409, 4412, 4413, 2028 (11) | aceptado | «Cliente entrevistado»: «Lo necesito y hoy no lo tengo.» (`10-descubrimiento/2025-08-15-entrevistas.md`, 2025-08-15, 14 meses; umbral 12). Es una sola cita de un solo cliente y no nombra ningún requerimiento. |
| REQ-4407, 4410, 2036 (3) | aceptado | **Sin cita de quien lo pidió.** Se van a construir y nadie lo pidió. |

## Las cifras
| Cifra | Valor | Clase | De dónde sale | De cuándo |
|---|---|---|---|---|
| volumen_mensual | 151.914 | Declarada | Caso de negocio, preparado por Gustavo Neira (`00-definicion/2026-02-26-caso-de-negocio.md`) | 2026-02-26 |
| volumen_mensual | 116.821 | Medida | Bodega de datos, tablero de producto (`20-metricas/2026-10-14-tablero-metricas.md`) | 2026-10-14 |
| Retorno esperado | «en 24 meses», sin cifra | Declarada solo en el plazo | `caso-de-negocio.md` | 2026-02-26 |
| La red de la mina soporta el volumen | — | **Supuesta** (el documento la marca «verificado» sin citar qué la verificó) | `definicion-producto.docx` | declarada 2026-03-27, posterior al documento (2026-02-26) |

Ninguna cifra de este caso es propia del agente ni viene de un valor de referencia del sector.

### Donde la cifra declarada y la medida no coinciden
| Métrica | Declarada | Medida | Las dos fuentes y fechas |
|---|---|---|---|
| volumen_mensual | 151.914 | 116.821 | Declarada: caso de negocio, 2026-02-26. Medida: bodega de datos, 2026-10-14. Diferencia de 23,1 % con lo declarado por encima (umbral 20 %). |

La serie medida tiene un solo punto: la brecha es contra ese punto, no contra una tendencia. Cualquier beneficio que se apoye en 151.914 transacciones al mes está apoyado en una cifra que la medición no confirma.

## Los costos
| Concepto | Valor | De dónde sale |
|---|---|---|
| Costo de construir | **No consta** | Ningún documento de la carpeta (sin contrato, cotización ni costo declarado del equipo) |
| Costo de operar | **No consta** | Ningún documento |

Sin el costo de construir no hay caso de negocio que evaluar: hay una propuesta. Es el primer vacío.

## Supuestos sobre los que se sostiene
| Supuesto | Qué pasa si resulta falso | Quién lo verificaría |
|---|---|---|
| La red de la mina soporta el volumen | El producto no opera al volumen que el caso declara. Además depende de una cifra de volumen que hoy está 23,1 % por encima de lo medido. | Nadie nombrado. Haría falta una prueba de carga o medición de ancho de banda con fecha y responsable. |
| El volumen declarado (151.914) es el que el producto va a mover | Todo beneficio calculado sobre él se sobrestima | Gustavo Neira (autor del caso) con la bodega de datos |
| La necesidad de un cliente representa al segmento | Los 14 requerimientos se apoyan en una sola cita de hace 14 meses | Quien haga el descubrimiento: más entrevistas |

## Vacíos
| Qué falta | Por qué importa | Quién lo produce |
|---|---|---|
| Costo de construir y de operar | Sin él no hay caso que evaluar | Gerente de producto / finanzas del negocio |
| Cifra del retorno esperado (solo hay plazo, 24 meses) | «Retorno» sin cifra no se puede medir ni cerrar | Gustavo Neira |
| Criterio de éxito | Sin él el producto no se puede cerrar meses después | Gustavo Neira; lo aprueba el Comité de producto (propuesto, no consta en ningún documento) |
| Qué pasa si no se hace | El comité no puede comparar contra no actuar | Gustavo Neira |
| Alternativas consideradas | No consta ninguna | Gustavo Neira |
| Propuesta (rótulo vacío) | No se sabe qué se construye como solución | Gustavo Neira |
| Proyecto que lo construye («Ninguno declarado») | Ningún requerimiento tiene dónde ejecutarse; no se pudo comprobar contra fichas de proyecto (`estado/` vacía) | Comité de producto / PMO |
| Quién decidió cada aceptación | El acta fecha las decisiones sin nombre | Comité de producto |
| Línea base de «tener trazabilidad» | No se puede medir el problema | Gustavo Neira |
| Cuántos clientes tienen el problema | Hay una sola cita | Descubrimiento |

## Cómo se sabrá si funcionó
**No está declarado.** Ningún documento dice el criterio de éxito, ni la métrica ni la fecha de corte. La única métrica con serie es volumen_mensual (un punto, 2026-10-14). Sin esto, el producto no se puede cerrar meses después.

## Si hay otros productos publicados
No hay otros productos publicados a la vista (solo PRD-304 en la carpeta), así que no se pudo hacer el cruce de `/product-overlap`. Queda pendiente cuando haya otro.

## Después
Ofrezco pasar los supuestos al seguimiento con **assumption-tracking**: el de la red tiene una verificación sin fuente y conviene convertirlo en riesgo con doliente. `/product-charter` no se ofrece: el caso no está en condiciones, sin costo ni criterio de éxito.
