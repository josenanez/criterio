No publiqué la ficha de PRD-304 (Trazabilidad): la configuración no define una carpeta de productos publicados, y sin un sitio común acordado publicar no sirve. Acordarlo es una conversación de la organización, no un comando. No inventé una ruta ni creé carpetas.

Lo que la ficha habría llevado (corte 2026-10-16):

- Requerimientos: 16 (14 aceptados, 2 propuestos)
- Proyectos: 0 (ningún requerimiento tiene proyecto)
- Métricas afirmadas: 1
- Segmento declarado: Segmento Mantenimiento
- Métrica: volumen_mensual, declarado 151914, del documento documentos/productos/PRD-304/00-definicion/2026-02-26-caso-de-negocio.md (2026-02-26). El tablero mide 116821 al 2026-10-14, y la definición queda 23.1 % por encima.

Para publicar: configurar la carpeta común de fichas publicadas y volver a correr /product-publish.
