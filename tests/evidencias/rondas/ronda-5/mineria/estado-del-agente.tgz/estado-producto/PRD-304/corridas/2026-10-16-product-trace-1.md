# Corrida del 2026-10-16 · product-trace

PRD-304 · 16 requerimientos · 43 s · 39 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 14 |
| `evidence_stale` | 12 |
| `requirement_without_acceptance` | 4 |
| `requirement_accepted_without_evidence` | 3 |
| `requirement_without_owner` | 3 |
| `requirement_undecided` | 2 |
| `claim_vs_metric` | 1 |

14 requerimientos decididos y ningún proyecto los construye; PRY-208 declara 'trazabilidad' y ningún REQ lo nombra

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

## Trazabilidad — Trazabilidad (PRD-304) · al 2026-10-16
14 decididos · 0 con proyecto · 0 confirmados contra la ficha · 0 entregados

Fichas leídas: las 13 de `estado/records` (PRY-199 a PRY-211). Todas las decisiones salen del acta `documentos/productos/PRD-304/30-decisiones/2026-10-13-comite-producto.docx`, y en ella el campo de proyecto dice «—» en los 16 requerimientos.

### Decidido y nadie lo está construyendo
Los 14 requerimientos aceptados. El acta del 2026-10-13 no dice quién aceptó ninguno.

| REQ | Título | Decidido el | Por quién |
|---|---|---|---|
| REQ-4403 | Requerimiento REQ-4403 | 2026-03-20 | no consta en el acta |
| REQ-4412 | Requerimiento REQ-4412 | 2026-03-30 | no consta en el acta |
| REQ-4406 | Requerimiento REQ-4406 | 2026-04-02 | no consta en el acta |
| REQ-4408 | Requerimiento REQ-4408 | 2026-04-02 | no consta en el acta |
| REQ-4405 | Requerimiento REQ-4405 | 2026-06-07 | no consta en el acta |
| REQ-4410 | Requerimiento REQ-4410 | 2026-06-15 | no consta en el acta |
| REQ-4402 | Requerimiento REQ-4402 | 2026-07-02 | no consta en el acta |
| REQ-4409 | Requerimiento REQ-4409 | 2026-07-12 | no consta en el acta |
| REQ-4407 | Requerimiento REQ-4407 | 2026-07-28 | no consta en el acta |
| REQ-4413 | Requerimiento REQ-4413 | 2026-08-10 | no consta en el acta |
| REQ-4401 | Requerimiento REQ-4401 | 2026-08-19 | no consta en el acta |
| REQ-4404 | Requerimiento REQ-4404 | 2026-08-22 | no consta en el acta |
| REQ-2028 | Requerimiento REQ-2028 | 2026-09-24 | no consta en el acta |
| REQ-2036 | Requerimiento REQ-2036 | 2026-10-05 | no consta en el acta |

El más antiguo, REQ-4403, lleva 210 días decidido sin proyecto. Los otros dos requerimientos (REQ-4400 y REQ-4411) siguen en «propuesto», no están decididos y no entran aquí.

### La traza no se confirma
Ninguna: ningún requerimiento dice ejecutarse en un proyecto, así que no hay traza que confirmar ni desacuerdo entre registro y ficha.

### Lo que un proyecto construye y el registro no tiene
| Proyecto | Su ficha dice que ejecuta este producto | Ningún REQ lo nombra |
|---|---|---|
| PRY-208 Trazabilidad del mineral | Campo producto = «trazabilidad» (acta de constitución del 2025-08-24, `PRY-208-trazabilidad-del-mineral/00-gobierno/2025-08-24-acta-constitucion.docx`) | Sí: ningún REQ de PRD-304 nombra a PRY-208 |

Esto es un candidato y no una confirmación: la ficha dice «trazabilidad», que coincide con el nombre del producto pero no con su código PRD-304. Hay que ir a ver si PRY-208 construye este producto o es otro con nombre parecido. Las otras 12 fichas declaran productos distintos (por ejemplo PRY-200: «monitoreo de flota»).

### La cadena completa
| REQ | Estado | Decisión | Proyecto | Confirmado | Entregables |
|---|---|---|---|---|---|
| 14 aceptados (tabla de arriba) | aceptado | acta del comité 2026-10-13, fecha de decisión propia de cada uno | ninguno: la cadena se rompe aquí | no | sin entregables |
| REQ-4400 | propuesto | sin decisión (155 días desde que se planteó, 2026-05-14) | ninguno | no | sin entregables |
| REQ-4411 | propuesto | sin decisión (176 días desde que se planteó, 2026-04-23) | ninguno | no | sin entregables |

### Sin fichas a la vista
Se tienen las 13 fichas, así que la ausencia de confirmaciones no viene de fichas que falten. Viene de que el registro no nombra ningún proyecto.

### Lo que hay que saber
- Un requerimiento más viejo que su evidencia: 12 alertas de evidencia vencida (la entrevista más reciente es del 2025-08-15, 14 meses, y no nombra los requerimientos).
- Sin avance que contar: el comando no mide avance.
