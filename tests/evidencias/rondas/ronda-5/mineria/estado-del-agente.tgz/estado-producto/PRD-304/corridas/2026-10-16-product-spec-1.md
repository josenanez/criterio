# Corrida del 2026-10-16 · product-spec

PRD-304 · 16 requerimientos · 69 s · 39 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 14 |
| `evidence_stale` | 12 |
| `requirement_without_acceptance` | 4 |
| `requirement_accepted_without_evidence` | 3 |
| `requirement_without_owner` | 3 |
| `requirement_undecided` | 2 |
| `claim_vs_metric` | 1 |

Borrador sobre 14 aceptados; no se pudo redactar comportamiento porque el registro no dice qué pide ningún requerimiento (títulos son solo el número). Criterio 'se verifica en producción' en 10 no es verificable; 4 sin criterio. Vacíos con dueño; sin barrido normativo; sin fichas de proyecto. No se ofrece charter.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

# Especificación — Trazabilidad (PRD-304) · borrador del 2026-10-16

**Esto es un borrador y lo cierra el gerente de producto, Gustavo Neira; lo aprueba quien tiene la facultad, el Comité de producto. Este agente no firma.** Una advertencia antes de leer: el registro solo trae de cada requerimiento su número, su estado y a veces un doliente. **Ninguno dice qué pide.** Todos los títulos son «Requerimiento REQ-xxxx». Por eso no hay sección de comportamiento: escribirla habría sido inventarla.

## Qué problema resuelve
«El segmento Mantenimiento no tiene trazabilidad.» (definición, 2026-02-26). Para quién: segmento Mantenimiento. La **propuesta principal** está como rótulo sin texto, y el **criterio de éxito no está dicho en ninguna parte.** El problema está nombrado; lo que se construiría para resolverlo no.

## Alcance
### Entra
Los 14 requerimientos aceptados, como candidatos. Entran por su estado, no por su contenido, porque el contenido no está en el registro:
REQ-2028, 2036, 4401, 4402, 4403, 4404, 4405, 4406, 4407, 4408, 4409, 4410, 4412 y 4413.

### No entra
- **REQ-4400** y **REQ-4411**: están en `propuesto`. Nadie ha decidido que se hacen. Llevan 155 y 176 días así, con un umbral de 60.
- Decidir la arquitectura, estimar esfuerzo, costo o fecha: no es de este documento.
- Cualquier comportamiento que ningún documento haya pedido.

## Comportamiento
**No se puede redactar.** Ninguna sección cubre ningún requerimiento, porque el registro no dice qué problema tiene cada uno. Ver «Requerimientos aceptados que esta especificación no cubre».

## Criterios de aceptación
Es lo único que el registro trae por requerimiento, y no pasa la prueba de que dos personas lleguen a la misma respuesta.

| Criterio | Requerimiento | Cómo se verifica | ¿Se puede medir hoy? |
|---|---|---|---|
| «se verifica en producción» | REQ-4401, 4403, 4404, 4405, 4406, 4407, 4408, 4409, 4410, 4413 (10) | No dice qué se mide, con qué valor, ni quién lo mira. No es verificable tal como está | No. El único dato medido que aparece en los documentos es `volumen_mensual` (tablero, 2026-10-14); ningún criterio lo usa |
| *(ninguno)* | REQ-2028, 2036, 4402, 4412 (4) | — | — |

Fuente de los criterios: acta del comité del 2026-10-13.

## Supuestos sobre los que está escrita
| Supuesto | Verificado | Quién lo verificaría |
|---|---|---|
| «La red de la mina soporta el volumen» (definición, 2026-02-26) | El documento dice «verificado» sin citar qué lo verificó. La fecha de declaración (2026-03-27) es posterior a la del documento (2026-02-26). No se toma como verificado | Gustavo Neira; el responsable de la red de la mina no consta en ningún documento |
| El volumen es 151.914 al mes (caso de negocio, 2026-02-26) | La bodega de datos mide 116.821 al 2026-10-14: 23,1 % menos de lo declarado, sobre el umbral de 20 %. Ninguna de las dos fuentes gana por defecto | Gustavo Neira |
| Que la necesidad de los requerimientos está sustentada | Solo hay una entrevista del 2025-08-15 («Lo necesito y hoy no lo tengo.»), con 14 meses y sin nombrar ningún requerimiento | Gustavo Neira |

## Vacíos
| Qué falta decidir | Consecuencia de no decidirlo | Quién lo cierra |
|---|---|---|
| Qué pide cada uno de los 14 requerimientos (el título es solo el número) | No hay nada que construir ni verificar; cualquier texto lo pondría el agente | El doliente de cada uno; sin doliente (REQ-4401, 4402, 4405), Gustavo Neira |
| Criterio de aceptación de REQ-2028, 2036, 4402 y 4412 | Se aceptó algo sin forma de saber cuándo está hecho | María Restrepo (2028), Liliana Torres (2036), Carlos Peña (4412); REQ-4402 sin doliente: Gustavo Neira |
| Reemplazar «se verifica en producción» por una frase medible en 10 requerimientos | Se discutirá si quedó bien después de construirlo | Los dolientes: Ricardo Salas (4403), Gustavo Neira (4404), Jorge Medina (4406 y 4410), Diana Molina (4407), Liliana Torres (4408), Rubén Cárdenas (4409), Sandra Gil (4413); 4401 y 4405 sin doliente: Gustavo Neira |
| Doliente de REQ-4401, 4402 y 4405 | Nadie responde por el problema | Gustavo Neira, nombrando una persona |
| Quién aceptó los 14 (el acta da fechas, de 2026-03-20 a 2026-10-05, sin nombre) | La decisión no se puede rastrear ni reabrir con su autor | Comité de producto |
| Demanda de REQ-2036, 4407 y 4410 (ninguna evidencia, ni de quién los pidió) | Se construye algo que nadie ha pedido | Liliana Torres, Diana Molina, Jorge Medina |
| Criterio de éxito del producto y propuesta principal | No hay con qué juzgar si el producto funcionó | Gustavo Neira |
| Casos borde: no hay comportamiento definido, y sin contenido ni siquiera se puede listar cuáles aplican | Lo que pase fuera del camino feliz lo decidirá quien construya, sin dejarlo escrito | Dolientes, una vez exista el comportamiento |
| Otros equipos: ningún documento dice qué debe hacer otro equipo. No consta si no hay ninguno o si no se ha mirado | Un acuerdo pendiente se descubre durante la construcción | Gustavo Neira |
| Obligaciones normativas: no se hizo barrido. La definición no dice qué se traza ni si toca datos personales, pagos u otra materia regulada. Que no esté identificada no prueba que no exista | Una obligación aparece tarde y obliga a rehacer | Gustavo Neira, con el área legal o de cumplimiento (nombre no consta) |
| Proyecto que ejecute cada requerimiento: el acta dice «—» en los 14; no se confirmó contra fichas porque no hay | Aceptado hace hasta siete meses y sin quien construya | Comité de producto, con Gustavo Neira |

## Requerimientos aceptados que esta especificación no cubre
Los 14, por la misma razón de fondo: el registro no dice qué pide ninguno. Además:

| REQ | Título | Por qué no |
|---|---|---|
| REQ-2028 | Requerimiento REQ-2028 | Sin contenido; sin criterio de aceptación |
| REQ-2036 | Requerimiento REQ-2036 | Sin contenido; sin criterio; sin evidencia ni quién lo pidió |
| REQ-4401 | Requerimiento REQ-4401 | Sin contenido; sin doliente; criterio no verificable |
| REQ-4402 | Requerimiento REQ-4402 | Sin contenido; sin doliente; sin criterio |
| REQ-4403 | Requerimiento REQ-4403 | Sin contenido; criterio no verificable |
| REQ-4404 | Requerimiento REQ-4404 | Sin contenido; criterio no verificable |
| REQ-4405 | Requerimiento REQ-4405 | Sin contenido; sin doliente; criterio no verificable |
| REQ-4406 | Requerimiento REQ-4406 | Sin contenido; criterio no verificable |
| REQ-4407 | Requerimiento REQ-4407 | Sin contenido; sin evidencia ni quién lo pidió; criterio no verificable |
| REQ-4408 | Requerimiento REQ-4408 | Sin contenido; criterio no verificable |
| REQ-4409 | Requerimiento REQ-4409 | Sin contenido; criterio no verificable |
| REQ-4410 | Requerimiento REQ-4410 | Sin contenido; sin evidencia ni quién lo pidió; criterio no verificable |
| REQ-4412 | Requerimiento REQ-4412 | Sin contenido; sin criterio |
| REQ-4413 | Requerimiento REQ-4413 | Sin contenido; criterio no verificable |

---
Sale del registro `estado-producto/PRD-304/requirements/` (actualizado el 2026-10-16; estados según el acta del comité del 2026-10-13). Cubre **0 de 14** requerimientos aceptados con comportamiento; 14 listados como candidatos; 2 propuestos fuera. Términos aceptados (v1.1, 2026-10-16, José Francisco Ñáñez): https://www.josenanez.com/es/agents/criterio-pmo/legal

**Siguiente paso:** no se ofrece `/product-charter`. Los vacíos no están cerrados y ningún requerimiento tiene criterio de éxito.
