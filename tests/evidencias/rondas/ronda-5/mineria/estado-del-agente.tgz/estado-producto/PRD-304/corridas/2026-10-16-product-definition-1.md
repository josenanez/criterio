# Corrida del 2026-10-16 · product-definition

PRD-304 · 16 requerimientos · 30 s · 39 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 14 |
| `evidence_stale` | 12 |
| `requirement_without_acceptance` | 4 |
| `requirement_accepted_without_evidence` | 3 |
| `requirement_without_owner` | 3 |
| `requirement_undecided` | 2 |
| `claim_vs_metric` | 1 |

El problema y el segmento están sostenidos solo por una entrevista de hace 14 meses. Falta criterio de éxito, propuesta y quién decide. El volumen declarado está 23,1 % por encima de lo medido.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

## Definición — Trazabilidad (PRD-304) · contrastada al 2026-10-16
**Documento:** `00-definicion/2026-02-26-definicion-producto.docx` (con `2026-02-26-caso-de-negocio.md`) · **del** 2026-02-26 · 7 afirmaciones

Nota de la prueba: sin interfaz, se tomaron las respuestas sugeridas. Términos vigentes (v0.3.11), aceptados por José Francisco Ñáñez el 2026-10-16; no hubo que registrarlos de nuevo.

### Lo que la evidencia contradice
Nada contradice la definición en lo cualitativo. Lo único que choca es una cifra; va en la sección siguiente.

### El negocio y los datos
| Métrica | Declarado | Medido | Diferencia | Las dos fuentes y fechas |
|---|---|---|---|---|
| volumen_mensual | 151.914 | 116.821 | 23,1 % (declarado por encima; umbral 20 %) | Declarado: `00-definicion/2026-02-26-caso-de-negocio.md`, 2026-02-26. Medido: bodega de datos, tablero de producto (`20-metricas/2026-10-14-tablero-metricas.md`), 2026-10-14. |

Solo hay un punto en la serie medida. La brecha es contra ese único punto, no contra una tendencia.

### Afirmaciones numéricas que nadie mide
| Afirma | De qué documento | No hay serie |
|---|---|---|
| «Retorno esperado en 24 meses» | `caso-de-negocio.md`, 2026-02-26 | No trae cifra, así que no hay nada que medir. Nadie dijo cuánto es el retorno. |

### No está dicho en ninguna parte
- **El criterio de éxito.** Ningún documento lo dice.
- **La propuesta.** La definición trae el rótulo «Propuesta principal» sin texto debajo.
- **Quién decide qué se construye.** Ningún documento lo dice. «Comité de producto» es la respuesta sugerida en el setup, marcada como propuesta.
- **Cuánto es el retorno esperado.** Solo se dice el plazo (24 meses).
- **Qué proyecto lo construye.** La definición dice «Ninguno declarado», y los 14 requerimientos aceptados no tienen proyecto.
- **Qué significa «no tiene trazabilidad».** No hay línea base ni definición de qué cuenta como tenerla.
- **Cuántos clientes del segmento tienen el problema.** Hay una sola cita, de un solo cliente.

### Sostenida por un supuesto
| Supuesto | Días sin verificar | Qué haría falta para verificarlo |
|---|---|---|
| La red de la mina soporta el volumen | 0 según el documento, que lo marca «verificado» | El documento dice «verificado» pero no cita qué lo verificó, y la fecha de declaración (2026-03-27) es posterior a la del documento (2026-02-26). Haría falta una prueba de carga o una medición de ancho de banda con fecha y responsable. Además depende de la cifra de volumen, que hoy está 23,1 % por encima de lo medido. |

### Sostenida por evidencia
| Afirmación | Sostenida por | De cuándo | Qué tan fuerte |
|---|---|---|---|
| El segmento Mantenimiento necesita trazabilidad y hoy no la tiene | Entrevista a un cliente: «Lo necesito y hoy no lo tengo.» (`10-descubrimiento/2025-08-15-entrevistas.md`) | 2025-08-15 | Débil. Es una persona que dijo que lo usaría; nadie pagó ni pidió nada concreto, y la cita no nombra ningún requerimiento. |

### Evidencia que ya envejeció
| Afirmación | Lo más nuevo que la sostiene | Hace |
|---|---|---|
| Necesidad del segmento (y 12 requerimientos que se apoyan en esa misma cita) | Entrevista del 2025-08-15 | 14 meses (umbral 12) |

### Lo normativo que toca
| Qué toca | País | Obligación | Norma | Estado |
|---|---|---|---|---|
| Nada identificado en la definición | No declarado | — | — | No tengo la norma a la vista. La definición no menciona datos personales, pagos, consumidor financiero ni retención de información. Eso no quiere decir que no haya obligaciones; una trazabilidad en minería puede tocar normas sectoriales que este barrido no cubre. Va a revisión jurídica. |

### Lo que falta para cerrar la definición
- **Criterio de éxito:** no está. Sin él el producto no se puede cerrar, porque el cierre se juzga contra él.
- **Propuesta:** el rótulo está vacío.
- **Quién decide:** no está en ningún documento, solo la respuesta sugerida.
- Quedan resueltos el problema («El segmento Mantenimiento no tiene trazabilidad») y para quién (segmento Mantenimiento).

### Después
- El supuesto de la red tiene una verificación sin fuente. Si nadie la respalda, conviene convertirlo en riesgo con doliente (raid-taxonomy).
- La definición no está cerrada, así que no se ofrece `/product-charter`.
