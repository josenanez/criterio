# Corrida del 2026-10-16 · product-setup

PRD-304 · 16 requerimientos · 47 s · 39 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 14 |
| `evidence_stale` | 12 |
| `requirement_without_acceptance` | 4 |
| `requirement_accepted_without_evidence` | 3 |
| `requirement_without_owner` | 3 |
| `requirement_undecided` | 2 |
| `claim_vs_metric` | 1 |

0 preguntas hechas (sesión sin interfaz, respuestas sugeridas), primer resultado en una sola pasada; 5 documentos, 16 requerimientos; sin criterio de éxito, 0 de 14 aceptados con proyecto, evidencia vencida en 12, volumen declarado 23,1 % sobre lo medido

Primera corrida: no hay una anterior contra la cual comparar.

## Lo que produjo

Soy Alba. Trabajo antes de que haya proyecto: miro qué sostiene tu definición y qué se sostiene solo.

Sesión sin interfaz: nadie contestó preguntas. En cada una tomé la respuesta sugerida y lo dije.

**Lo que vi:** 5 documentos en `documentos/productos/PRD-304`, 1 de ellos de descubrimiento (una ronda de entrevistas del 2025-08-15, con una sola cita). Hay caso de negocio y definición de producto, ambos del 2026-02-26; un tablero de métricas del 2026-10-14 y el acta del comité de producto del 2026-10-13. Lo más reciente es del 2026-10-14. Los dos .docx los leí abriéndolos como texto; no hay formatos que no pueda leer.

**Material de descubrimiento:** hay, pero es mínimo: una ronda, una cita («Lo necesito y hoy no lo tengo.»), sin decir quién es el cliente, qué necesita ni de qué segmento. Es el primer hallazgo.

**Las cuatro preguntas (respuesta sugerida en todas):**
1. Quién eres y qué producto es: Gustavo Neira, gerente del producto PRD-304 «Trazabilidad», segmento Mantenimiento (del caso de negocio y la definición).
2. Quién decide qué se construye: «Comité de producto». Es una propuesta mía: ningún documento dice quién decide. Queda marcada como propuesta.
3. Dónde guardo lo que encuentre: `estado-producto/PRD-304`, hermana de la documentación y separada de `estado/`, que es del portafolio.
4. Términos: versión 1.1 del plugin criterio-product 0.3.11. Texto mostrado tal cual. Aceptados por José Francisco Ñáñez, 2026-10-16, por la instrucción de esta sesión. Comprobante en `.criterio/terminos/aceptacion-criterio-product-0.3.11-2026-10-16.md` y `.pdf`, SHA-256 del Markdown f969d4f658630df3… 

## Listo — Trazabilidad (PRD-304)

**Lo que miré:** 5 documentos · 1 de descubrimiento · la definición del 2026-02-26
**Términos:** aceptados para la versión 0.3.11 · comprobante en `.criterio/terminos/aceptacion-criterio-product-0.3.11-2026-10-16.md` y `.pdf` · SHA-256 f969d4f658630df3…

Levanté la ficha del producto y 16 requerimientos nombrados en el acta (14 aceptados, 2 propuestos). Solo lo escrito: lo que no está, quedó como `not_found`.

### Lo que tu definición afirma, y qué lo sostiene
| Afirmación | Sostenida por | De cuándo |
|---|---|---|
| «El segmento Mantenimiento no tiene trazabilidad» | Solo una cita genérica del cliente entrevistado («Lo necesito y hoy no lo tengo.»), que no nombra trazabilidad ni Mantenimiento | 2025-08-15 (14 meses) |
| Volumen mensual de 151.914 | Caso de negocio. Lo medido hoy es 116.821: el negocio declaró 23,1 % por encima de lo medido | declarado 2026-02-26 · medido 2026-10-14 |
| «La red de la mina soporta el volumen» (supuesto) | El propio documento dice «verificado», sin decir qué lo verificó; además lo fecha el 2026-03-27, posterior al documento (2026-02-26) | 2026-03-27 |
| Retorno esperado en 24 meses | Nada: sin cifra, sin fuente | — |

### Lo que no está dicho en ninguna parte
- **El criterio de éxito.** La definición no lo trae; sin él el producto no se puede cerrar.
- **La propuesta.** El rótulo «Propuesta principal» está sin texto debajo.
- **Quién decide qué se construye.** Ningún documento lo dice (usé «Comité de producto» como propuesta).
- **Quién aceptó cada requerimiento.** El acta lista 14 aceptados sin decir quién los aceptó.
- **Ningún proyecto ejecuta nada:** los 14 aceptados tienen «—» y la definición dice «Ninguno declarado» (14 de 14, 0,0 % trazados).
- **Demanda para 3 requerimientos aceptados:** REQ-4407, REQ-4410 y REQ-2036 no tienen quién los pidió.
- **Doliente para 3 aceptados:** REQ-4401, REQ-4402 y REQ-4405 están «sin asignar».
- **Criterio de aceptación para 4 aceptados:** REQ-4402, REQ-4412, REQ-2028 y REQ-2036. En los demás, «se verifica en producción» está escrito, pero no es un criterio verificable.
- **Decisión pendiente:** REQ-4400 lleva 155 días propuesto y REQ-4411 lleva 176, sin decidirse. El acta del 2026-10-13 solo dice «Se mantiene el plan».

### Supuestos sobre los que está escrita
Uno declarado: que la red de la mina soporta el volumen, marcado «verificado» pero sin fuente de verificación. Ninguno más. La definición no declara supuestos sobre la demanda, que es de donde cuelga todo lo demás.

### Qué le falta a tu carpeta
- La evidencia de demanda de los 12 requerimientos que tienen alguna (11 aceptados y REQ-4400) es la misma entrevista de hace 14 meses (2025-08-15), y su cita no nombra ningún requerimiento. Con 12 meses como límite, está vencida.
- Las transcripciones completas de entrevistas, con quién habló y de qué segmento.
- La serie de la métrica: hay un solo punto (116.821 al 2026-10-14), así que no se ve tendencia; y no hay de dónde salió el 151.914 más que la afirmación del propio caso.
- Las decisiones del comité con quién decidió y por qué; sin ellas, un requerimiento descartado se ve igual que uno que nadie miró.

**Siguiente paso:** `/product-discovery` sobre el material de entrevistas, para convertir los temas en requerimientos con la cita de quién lo pidió.
