# Corrida del 2026-10-16 · product-charter

PRD-304 · 16 requerimientos · 34 s · 39 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 14 |
| `evidence_stale` | 12 |
| `requirement_without_acceptance` | 4 |
| `requirement_accepted_without_evidence` | 3 |
| `requirement_without_owner` | 3 |
| `requirement_undecided` | 2 |
| `claim_vs_metric` | 1 |

Borrador de acta de REQ-4401; faltan criterio verificable, autoridad, quién aceptó, doliente, patrocinador y gerente. Sin firma: ficha no creada.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

Términos: vigentes (versión 0.3.11, aceptados por José Francisco Ñáñez el 2026-10-16); no hizo falta registrarlos de nuevo.
Configuración: PRD-304 (único producto configurado). El argumento REQ-4401 es un requerimiento, no un código de producto.

**Verificación previa (paso 1): el requerimiento NO tiene con qué para un acta completa.** Respuesta sugerida tomada: seguir, marcando cada vacío como vacío del acta, sin rellenarlo.

| Condición | Resultado |
|---|---|
| Aceptado, no propuesto | Sí en el estado («aceptado desde 2026-08-19», acta de comité 2026-10-13), pero **el acta no dice quién lo aceptó** |
| Criterios de aceptación verificables | **No.** Solo dice «se verifica en producción», que no es un criterio medible |
| Evidencia de demanda con cita | **Débil.** Cliente entrevistado, 2025-08-15: «Lo necesito y hoy no lo tengo.» La cita no nombra este requerimiento y tiene más de 12 meses |
| Autoridad declarada en la definición | **No.** Ningún documento dice quién decide qué se construye; «Comité de producto» es solo la respuesta sugerida en product-setup |

---

# Acta de constitución — Trazabilidad / REQ-4401 · borrador del 2026-10-16
**Producto:** PRD-304 Trazabilidad · **Requerimientos:** REQ-4401

## Qué problema resuelve
«El segmento Mantenimiento no tiene trazabilidad.» (definición de producto, 2026-02-26, `00-definicion/2026-02-26-definicion-producto.docx`). La definición no dice qué se propone: trae el rótulo «Propuesta principal» sin texto.

## Criterio de éxito
| Criterio | Cómo se verifica | Fuente |
|---|---|---|
| «se verifica en producción» | **No dice cómo.** No hay métrica, umbral ni fecha | Acta de comité 2026-10-13 |

La definición del producto tampoco declara criterio de éxito. **Vacío.**

## Alcance
### Entra
| REQ | Título | Evidencia que lo sostiene |
|---|---|---|
| REQ-4401 | «Requerimiento REQ-4401» (el título es el propio código; no hay descripción) | Cliente entrevistado, 2025-08-15: «Lo necesito y hoy no lo tengo.» No nombra el requerimiento. |

### No entra
| REQ | Título | Por qué no |
|---|---|---|
| REQ-4400, REQ-4411 | Requerimientos REQ-4400 y REQ-4411 | Están en estado «propuesto»; no los aceptó nadie |
| REQ-4402 a REQ-4410, REQ-4412, REQ-4413, REQ-2028, REQ-2036 | Requerimientos aceptados del mismo producto | Este acta cubre solo REQ-4401, que es el pedido. Ningún documento dice que se excluyan por una razón de fondo: **la exclusión es por el pedido, no por una decisión de alcance**. Quien firme debe confirmar si alguno debe entrar |

## Gobierno
- **Patrocinador:** no está dicho en ningún documento.
- **Gerente propuesto:** no está dicho. Gustavo Neira es el gerente de producto (definición, 2026-02-26), no necesariamente del proyecto. Este comando no nombra gerente.
- **Comité:** «Comité de producto» (acta 2026-10-13; asistió solo Gustavo Neira).
- **Autoridad del gerente del proyecto:** no está dicha. **Vacío.**
- **Doliente de REQ-4401:** sin asignar (acta 2026-10-13).
- **Quién lo aceptó:** el acta no lo dice.

## Supuestos que se llevan al proyecto
| Supuesto | Verificado | Se convierte en riesgo de |
|---|---|---|
| La red de la mina soporta el volumen (definición, declarado 2026-03-27) | El documento dice «verificado» sin citar qué lo verificó, y la fecha de declaración (2026-03-27) es posterior a la del documento (2026-02-26). **Tratar como no verificado.** | Riesgo del proyecto; doliente por asignar |
| Cifra del caso de negocio: volumen mensual 151.914 | Sin contrastar en esta corrida contra el tablero de métricas (2026-10-14) | Riesgo si la cifra no se sostiene; doliente por asignar |

No se registra en RAID: eso lo hace el gerente del proyecto una vez exista.

## Restricciones normativas sin resolver
| Qué toca | Obligación | Norma | Estado |
|---|---|---|---|
| Ninguna identificada | La definición no menciona datos personales, pagos ni retención de información | — | Sin barrido; no es una afirmación de que no apliquen |

## Vacíos de este acta
| Qué falta | Consecuencia de firmar sin eso | Quién lo cierra |
|---|---|---|
| Criterio de aceptación verificable | El cierre no se podrá juzgar meses después | Gustavo Neira, con el Comité de producto |
| Autoridad declarada | El gerente escala todo o no escala nada | Comité de producto |
| Quién aceptó REQ-4401 | No consta que lo decidiera quien tiene la autoridad | Comité de producto |
| Doliente del requerimiento | Nadie responde por él | Comité de producto |
| Evidencia que nombre el requerimiento | La demanda es genérica y de hace más de un año | Gustavo Neira |
| Propuesta y criterio de éxito del producto | No hay qué construir ni cómo medirlo | Gustavo Neira |
| Patrocinador y gerente del proyecto | No hay a quién entregar la ficha | Quien tenga la autoridad |
| Presupuesto e hitos | El acta no los declara | Patrocinador |

---
**Esto es un borrador.** Lo firma el patrocinador o quien tenga la autoridad (por definir). **La ficha del proyecto NO se creó**: se crea después de la firma, y en esta prueba nadie firmó. `portafolio.py init` no se corrió; `declared` no se escribió.

**Qué sigue y para quién:** cerrados los vacíos y firmada el acta, el gerente del proyecto instala `criterio-project` y corre `/pm-setup`; cuando publique su ficha con `/pm-publish`, `/product-trace` podrá confirmar la traza.
