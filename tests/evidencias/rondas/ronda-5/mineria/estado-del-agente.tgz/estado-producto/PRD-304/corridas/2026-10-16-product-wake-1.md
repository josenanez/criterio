# Corrida del 2026-10-16 · product-wake

PRD-304 · 16 requerimientos · 30 s · 39 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 14 |
| `evidence_stale` | 12 |
| `requirement_without_acceptance` | 4 |
| `requirement_accepted_without_evidence` | 3 |
| `requirement_without_owner` | 3 |
| `requirement_undecided` | 2 |
| `claim_vs_metric` | 1 |

Primer corte del registro: 16 requerimientos, 0 con proyecto. No se pudo confirmar ninguna traza por falta de la carpeta de fichas; no hay criterio de éxito escrito ni corte anterior contra el cual comparar.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

## Trazabilidad (PRD-304) · 2026-10-16

Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-16). Tocaba `review` (nunca se había corrido). Es el primer corte: no hay corte anterior, así que no existe `crossed` y lo que sigue es la línea base, no novedad. Sin carpeta de fichas de proyecto: ninguna traza se da por confirmada.

16 requerimientos (14 aceptados, 2 propuestos). 0 con proyecto asignado.

### Para el comité (necesita decisión)
| Qué | REQ | Cuánto lleva | Qué se necesita | Quién |
|---|---|---|---|---|
| Sin decidir | REQ-4411 | 176 días (desde 2026-04-23); sin criterio de aceptación ni evidencia | Saber quién tiene la facultad de decidirlo; llevarlo al Comité de producto | Dueño: Felipe Arango |
| Sin decidir | REQ-4400 | 155 días (desde 2026-05-14) | Ídem; además su única evidencia tiene 14 meses | Dueño: Carlos Peña |
| Aceptado sin evidencia de demanda | REQ-2036, REQ-4407, REQ-4410 | Aceptados el 2026-10-05, 2026-07-28 y 2026-06-15 | Quién lo pidió; o reabrir la decisión | Liliana Torres, Diana Molina, Jorge Medina |
| Aceptado sin dueño | REQ-4401, REQ-4402, REQ-4405 | — | Asignar doliente | Gustavo Neira (gerente del producto) |
| Aceptado sin criterio de aceptación | REQ-2028, REQ-2036, REQ-4402, REQ-4412 | — | Definirlo antes de construir | Dueños respectivos |
| Aceptado y que nadie construye | Los 14 aceptados | Desde 2026-03-20 (REQ-4403, el más antiguo) | Ninguno tiene proyecto; la decisión de pasarlos a proyecto (`/product-charter`) | Comité de producto |

### Lo que el negocio declara contra lo que miden los datos
`volumen_mensual`: el caso de negocio (2026-02-26) declara 151.914; el tablero (2026-10-14) mide 116.821. Brecha de 23,1 %, sobre el umbral de 20 %, con lo declarado por encima. Pregunta para el comité: ¿se revisa la cifra del caso de negocio o se explica la diferencia?

### Evidencia que envejeció
12 requerimientos se sostienen en una sola cita (entrevista del 2025-08-15, 14 meses, umbral 12), y esa cita no nombra el requerimiento: es una necesidad general («Lo necesito y hoy no lo tengo»). La afirmación de demanda de la definición queda sin sustento fresco. Se necesita una ronda de descubrimiento nueva (`/product-discovery`).

### Lo que no se sabe
El criterio de éxito de la definición no está escrito (`success` vacío). No hay supuestos sin verificar registrados. No se revisó la carpeta de fichas de proyectos: no hay forma de saber si algún proyecto ejecuta este producto.

### Anexo
Totales por señal: evidencia vencida 12, sin traza 14, sin criterio de aceptación 4, aceptado sin evidencia 3, sin dueño 3, sin decidir 2, declarado contra medido 1.

**Vuelvo el 2026-11-15.**
