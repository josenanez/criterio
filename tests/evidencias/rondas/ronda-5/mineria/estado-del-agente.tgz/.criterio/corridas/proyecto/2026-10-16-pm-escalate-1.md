# Corrida · 2026-10-16-pm-escalate-1

**Agente:** Samuel (proyecto) · **Comando:** `/criterio-project:pm-escalate (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-16T12:17:31 · **Fin:** 2026-10-16T12:18:36 · **Duración:** 65 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `pm-escalate` | 1 | — | 43 | 17 | Un paquete: la autoridad del gerente no está declarada en el acta (opciones A/B/C, recomienda A). No calculó impact: ningún cambio de fecha ni días propuestos. No armó paquete para doc 1, punto 8, riesgos del proveedor ni presupuesto. No sabe quién tiene la facultad ni el costo de cada opción. |

Por señal (`pm-escalate`): `commitment_overdue` 6, `milestone_met_without_evidence` 4, `commitment_rescheduled` 4, `commitment_undated` 2, `progress_vs_plan` 1

## Lo que el agente mostró

**Escala un solo punto: el acta de PRY-200 no declara la autoridad del gerente.** Es el primero que manda la regla. Leí el acta completa y no tiene ninguna sección de autoridad. La ficha lo marca como no encontrado. No me pasaste un tema, así que tomé lo que ya estaba marcado como escalable.

Los términos ya estaban vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-16), así que no hubo nada que registrar.

**La pregunta cerrada:** ¿quién declara por escrito qué puede decidir Ricardo Salas?
- **A:** el Comité de Operaciones, con una adenda al acta.
- **B:** el patrocinador Andrés Lozano, con una carta firmada.
- **C:** se sigue sin autoridad declarada.

**Recomiendo A.** Es el mismo órgano que aprobó el presupuesto, deja la autoridad en el acta y no depende de que responda Lozano, que tiene un compromiso vencido sin acta de recibo.

**Si no se decide hoy:** el comité del 2026-10-30 se reúne sin saber qué puede resolver el gerente. Eso afecta a «Enviar el documento 1» (seis reprogramaciones, la última al 2026-12-12) y al vencido de Lozano (el punto 8, vencido el 10-13).

**Costos y alcance:** ningún documento da el costo de las opciones en pesos o en días, y lo dejé escrito así en el paquete. No corrí `impact` porque nada de esto mueve una fecha y no me diste un número de días. El acta tampoco declara dependencias, así que no sé qué otros proyectos quedan alcanzados.

**Dudas que dejo declaradas:**
- Que el Comité de Operaciones tenga la facultad de declarar la autoridad es una lectura mía, no algo que el acta diga. Confírmalo antes de llevarlo.

**No armé paquete para:**
- «Enviar el documento 1»: ningún documento dice qué la frena.
- El punto 8 de Lozano y el diseño 5 de Torres: Ricardo les pide el acta de recibo antes del 10-29 y escala solo si no responden.
- Los riesgos del proveedor y las dos incidencias (lluvias, ensayo de disponibilidad): son registro, no escalamiento.
- El presupuesto: la proyección de 1.175.719.466 COP queda dentro de los 1.200.000.000 aprobados.

**Aparte, no es escalamiento:** el cierre de la línea base v1 era el 2026-09-30, ya pasó, y el avance declarado es 54 %. No hay ningún cambio registrado. Eso va por control de cambios y la línea base v1 no se toca.

Llevar el paquete al comité es tuyo.

Archivos en `estado/PRY-200-mantenimiento-predictivo-de-camiones/corridas/`:
- salida-pm-escalate.md
- 2026-10-16-pm-escalate-1.md
