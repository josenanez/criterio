# Corrida · 2026-10-16-project-history-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-history PRY-210

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-210

**Inicio:** 2026-10-16T12:34:35 · **Fin:** 2026-10-16T12:35:53 · **Duración:** 78 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-history` | 13 | — | 58 | 58 | Historia de PRY-210 sobre 7 documentos (2026-05-11 a 2026-10-16): 1 replanificación de 33 días sin autorizar, verde declarado con 72% contra 20-40% sustentado. Dijo que no sabe: meses declarando sin sustento (un solo estado declarado), qué se habló fuera de los documentos, y por qué el cronograma v1 de mayo ya marca cerrado el hito de agosto. |

Por señal (`project-history`): `milestone_met_without_evidence` 19, `progress_vs_plan` 7, `commitment_overdue` 7, `declared_vs_evidence` 6, `commitment_rescheduled` 4, `variance_time` 4, `commitment_undated` 3, `rebaseline_unauthorized` 3, `variance_cost` 2, `pm_vs_pmo` 1, `milestone_overdue` 1, `vendor_deliverable_late` 1

## Lo que el agente mostró

## Historia · PRY-210 Programa de relacionamiento comunitario · 2026-05-11 a 2026-10-16

**Leí:** 7 documentos entre 2026-05-11 y 2026-10-16. Ordené cada uno por la fecha de su nombre, porque la fecha de modificación en disco es 2026-10-16 para todos.
**Términos:** ya estaban vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-16), así que no los registré de nuevo.
**Trimestres sin documentos:** 2026-T3. No hay ningún documento entre 2026-05-11 y 2026-10-14.

**Qué pasó:**
- El proyecto se constituyó el 2026-05-11, con cierre comprometido al 2027-08-31. Su línea base terminaba el 2027-07-19.
- Entre el 2026-10-14 y el 2026-10-16 aparecen seis documentos a la vez. El cronograma v2 mueve el último hito al 2027-08-21, 33 días más tarde.
- El informe de avance del 2026-10-14 declara Verde con 72 % de avance. El plan sostiene entre 20 % y 40 %, con 1 de 5 hitos cumplido.
- La solicitud de cambio CC-01 pide esos mismos 33 días y 66.000.000 COP más, pero sigue pendiente de comité. El plan se movió dos días antes de que la solicitud existiera.

| Replanificaciones | Atraso vs. original | Meses declarando sin sustento | Cambios de gobierno |
|---|---|---|---|
| 1 | 33 días (7,8 %) | No calculable: hay un solo estado declarado | 0 |

- **Motivo de la replanificación:** el informe habla de la parada de planta y la CC-01 de una ampliación de alcance. Ningún documento aprueba el movimiento: 33 días movidos, 0 autorizados.
- **Compromisos:** hay uno solo, de Paula Céspedes ("Entregar el punto 35") y sin fecha. Paula no figura entre los asistentes del comité del 2026-10-15.

**Lo que no sé:**
- Qué se habló fuera de estos documentos.
- Por qué el cronograma v1, fechado 2026-05-11, ya marca como cerrado el hito del 2026-08-13.
- Si hubo documentos anteriores a octubre que no están en la carpeta.

La historia no atribuye intención: que el plan se moviera antes de la solicitud puede ser solo un orden de papeles. La verificación de cada dato contra su documento es suya. Puedo llevar esto al comité para decidir CC-01, o al cierre del proyecto.

La corrida quedó registrada como `2026-10-16-project-history-1`, con la salida completa en `estado/corridas/salida-project-history.md`.
