# Corrida · 2026-10-16-product-trace-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-trace (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-16T12:48:40 · **Fin:** 2026-10-16T12:49:41 · **Duración:** 60 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-trace` | 16 | — | 43 | 39 | 14 requerimientos decididos y ningún proyecto los construye; PRY-208 declara 'trazabilidad' y ningún REQ lo nombra |

Por señal (`product-trace`): `requirement_untraced` 14, `evidence_stale` 12, `requirement_without_acceptance` 4, `requirement_accepted_without_evidence` 3, `requirement_without_owner` 3, `requirement_undecided` 2, `claim_vs_metric` 1

## Lo que el agente mostró

## Trazabilidad — Trazabilidad (PRD-304) · al 2026-10-16

Hay 14 requerimientos decididos y ninguno tiene proyecto, ni confirmado contra una ficha ni entregado. Los términos ya estaban vigentes y aceptados por José Francisco Ñáñez el 2026-10-16, así que no volví a registrarlos.

**Decidido y nadie lo está construyendo.** Son los 14 aceptados: REQ-4403, 4412, 4406, 4408, 4405, 4410, 4402, 4409, 4407, 4413, 4401, 4404, 2028 y 2036.
- Todos salen del acta del comité del 2026-10-13, y en ella el campo de proyecto dice «—» en los 16 requerimientos.
- El acta no dice quién aceptó ninguno.
- El más antiguo, REQ-4403, lleva 210 días decidido sin proyecto.
- REQ-4400 y REQ-4411 siguen en «propuesto» (155 y 176 días), no están decididos y no entran en esta lista.

**La traza no se confirma.** No hay ninguna. Ningún requerimiento dice ejecutarse en un proyecto, así que no hay desacuerdo entre el registro y las fichas. La cadena se rompe en el eslabón del proyecto.

**Lo que un proyecto construye y el registro no tiene.** PRY-208 (Trazabilidad del mineral) tiene en su ficha el producto «trazabilidad», tomado de su acta del 2025-08-24, y ningún requerimiento lo nombra.
- Es un candidato, no una confirmación: la ficha coincide con el nombre del producto, no con el código PRD-304. Hay que ir a ver si PRY-208 construye este producto o uno de nombre parecido.
- Las otras 12 fichas declaran otros productos.

**Fichas.** Usé las 13 fichas de `estado/records`, así que nada quedó sin confirmar por falta de fichas.

La corrida quedó registrada como `2026-10-16-product-trace-1`, con 39 hallazgos en 43 segundos. El texto completo está en `estado-producto/PRD-304/corridas/salida-product-trace.md`.

Los pasos siguientes:
- **Charter:** `/product-charter` sirve para el requerimiento que ya esté listo para volverse proyecto.
- **PRY-208:** conviene hablar con su gerente de proyecto para ver si su trabajo corresponde a este producto.
