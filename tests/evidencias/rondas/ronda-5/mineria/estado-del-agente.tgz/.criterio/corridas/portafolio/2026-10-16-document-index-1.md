# Corrida · 2026-10-16-document-index-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:document-index (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-16T12:27:50 · **Fin:** 2026-10-16T12:28:21 · **Duración:** 32 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `document-index` | 13 | — | 13 | 58 | 77 documentos, todos sin cambio; 0 por releer, 0 citas rotas. El índice no reporta formatos ilegibles, así que no se afirma nada sobre ellos. |

Por señal (`document-index`): `milestone_met_without_evidence` 19, `progress_vs_plan` 7, `commitment_overdue` 7, `declared_vs_evidence` 6, `commitment_rescheduled` 4, `variance_time` 4, `commitment_undated` 3, `rebaseline_unauthorized` 3, `variance_cost` 2, `pm_vs_pmo` 1, `milestone_overdue` 1, `vendor_deliverable_late` 1

## Lo que el agente mostró

Carpeta al 2026-10-16: 77 documentos, ninguno cambió. No hay nada que releer y no hay citas rotas, así que no produje nada más.

- **Términos:** ya estaban vigentes (v0.3.11, aceptados por José Francisco Ñáñez el 2026-10-16), así que no hubo que registrar nada nuevo.
- **Formatos ilegibles:** el índice no reporta formatos que no se pudieron leer, así que no afirmo nada sobre ellos.
- **Corrida registrada:** quedó en `estado/corridas/` como `2026-10-16-document-index-1`, con la salida en `estado/corridas/salida-document-index.md`. Tardó 13 segundos.
- **Cifras que no vienen de este comando:** el registro arrastra 58 hallazgos de corridas anteriores sobre 13 proyectos. Este índice no leyó nada nuevo.
