# Corrida · 2026-10-16-project-charter-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-charter PRY-209 revisar

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-209

**Inicio:** 2026-10-16T12:37:56 · **Fin:** 2026-10-16T12:39:04 · **Duración:** 68 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-charter` | 13 | — | 50 | 58 | Revisión del acta de PRY-209 (2025-11-01): falta autoridad del gerente, objetivo es la solución, alcance/exclusiones/criterio de éxito sin contenido, dependencias contradicen el informe, sin supuestos ni hitos. No sé si hay delegación de autoridad fuera de la carpeta. Ofertas de comité y RAID no ejecutadas. |

Por señal (`project-charter`): `milestone_met_without_evidence` 19, `progress_vs_plan` 7, `commitment_overdue` 7, `declared_vs_evidence` 6, `commitment_rescheduled` 4, `variance_time` 4, `commitment_undated` 3, `rebaseline_unauthorized` 3, `variance_cost` 2, `pm_vs_pmo` 1, `milestone_overdue` 1, `vendor_deliverable_late` 1

## Lo que el agente mostró

Revisé el acta de PRY-209 y la corrida quedó registrada (`2026-10-16-project-charter-1`).

**El acta existe, del 2025-11-01.** Estos son los vacíos que encontré y su consecuencia:

- **Autoridad del gerente: no está declarada.** La proyección al cierre es COP 3.289.376.978 contra COP 3.300.000.000 aprobados, un margen de 0,3 %. Cualquier sobrecosto pasa del aprobado y nadie sabe quién puede decidirlo.
- **El objetivo describe la solución, no un resultado de negocio.** Dice «Entregar electrificación de equipos», así que no hay resultado que medir.
- **Alcance, exclusiones y criterio de éxito no tienen contenido medible.**
  - El alcance es «Componente 1, 2 y 3», sin decir qué es cada uno.
  - La exclusión es «Lo que otro proyecto cubre», sin nombrar ninguno.
  - El criterio de éxito es «en producción y medido», sin umbral ni quién lo mide.
- **Las dependencias se contradicen con el informe.** El acta dice «Ninguna», pero el informe del 2026-10-07 reporta un proveedor sin fecha de la última entrega.
- **Faltan supuestos, restricciones, hitos y cadencia del comité.**
- **Patrocinador (Andrés Lozano) y gerente (Javier Hoyos) sí tienen nombre.**

No sé si existe una delegación de autoridad fuera de la carpeta. Solo vi el acta y el informe de avance.

Me quedé en la revisión, sin redactar nada nuevo. Sin nadie que respondiera, tomé la respuesta sugerida y no ejecuté las dos ofertas finales: llevar la definición de autoridad al comité como decisión, y pasar los supuestos y la dependencia del proveedor al registro RAID. Quedan propuestas en la salida.

Los términos ya estaban vigentes a nombre de José Francisco Ñáñez (versión 1.1, 2026-10-16), así que no registré una aceptación nueva.

La salida completa está en `/home/claude/banco/ronda-5/mineria/espacio/estado/corridas/salida-project-charter.md`.
