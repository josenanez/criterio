# Informe de avance · Programa de relacionamiento comunitario

**Código:** PRY-210
**Fecha de corte:** 2026-10-14
**Gerente:** Laura Vélez

## Estado declarado

**Verde**

Avance reportado: **72%**

## Lo que pasó en el periodo

- Se reprogramó la parada de planta por la ventana de mantenimiento

## Presupuesto

| | COP |
|---|---|
| Aprobado | 3.300.000.000 |
| Comprometido | 1.917.858.493 |
| Ejecutado | 655.590.341 |
| Proyección al cierre | 3.118.748.068 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
- Ventana de parada de planta definida por operaciones
