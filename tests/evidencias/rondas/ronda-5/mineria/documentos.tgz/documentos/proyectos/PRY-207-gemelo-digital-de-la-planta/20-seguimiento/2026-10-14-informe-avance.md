# Informe de avance · Gemelo digital de la planta

**Código:** PRY-207
**Fecha de corte:** 2026-10-14
**Gerente:** Natalia Ospina

## Estado declarado

**Amarillo**

Avance reportado: **75%**

## Lo que pasó en el periodo

- El equipo perdió dos semanas por rotación de un ingeniero clave
- El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite
- Se actualizó el presupuesto de la obra con el área de compras

## Presupuesto

| | COP |
|---|---|
| Aprobado | 9.500.000.000 |
| Comprometido | 6.646.347.227 |
| Ejecutado | 3.711.432.409 |
| Proyección al cierre | 9.553.085.251 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
- El proveedor no ha confirmado la fecha de la última entrega
