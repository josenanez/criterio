# Informe de avance · Trazabilidad del mineral

**Código:** PRY-208
**Fecha de corte:** 2026-10-07
**Gerente:** Paula Céspedes

## Estado declarado

**Verde**

Avance reportado: **48%**

## Lo que pasó en el periodo

- El proveedor entregó los equipos en el campamento, pendientes de aceptación
- Las lluvias detuvieron el montaje durante diez días

## Presupuesto

| | COP |
|---|---|
| Aprobado | 2.400.000.000 |
| Comprometido | 1.869.649.137 |
| Ejecutado | 975.753.496 |
| Proyección al cierre | 2.358.211.719 |

## Riesgos abiertos

- Cambio en la licencia ambiental que puede mover el alcance
- Ventana de parada de planta definida por operaciones
