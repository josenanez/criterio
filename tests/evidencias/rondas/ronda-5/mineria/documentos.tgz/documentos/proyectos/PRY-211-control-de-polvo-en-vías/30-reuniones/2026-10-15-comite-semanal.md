# Comité de Operaciones · Control de polvo en vías

**Fecha:** 2026-10-15
**Asistentes:** Elena Duarte, Javier Hoyos

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Rubén Cárdenas | Entregar el punto 17 | 2026-10-17 |
