# Comité de Operaciones · Mantenimiento predictivo de camiones

**Fecha:** 2026-09-11
**Asistentes:** Andrés Lozano, Diana Molina, Elena Duarte, Javier Hoyos, Liliana Torres, Ricardo Salas, Sandra Gil, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Elena Duarte | Enviar el documento 1 | 2026-09-26 |
| Diana Molina | Cerrar la prueba 2 | 2026-09-23 |
| Óscar Ramírez | Revisar el anexo 3 | 2026-09-22 |
| Sandra Gil | Validar el ambiente 4 | 2026-09-20 |
| Liliana Torres | Aprobar el diseño 5 | 2026-09-24 |
| Ricardo Salas | Actualizar la matriz 6 | 2026-09-16 |
| Javier Hoyos | Confirmar la fecha 7 | 2026-09-16 |
| Andrés Lozano | Entregar el punto 8 | 2026-09-26 |
