# Comité de Inversiones · Gemelo digital de la planta

**Fecha:** 2026-10-09
**Asistentes:** Natalia Ospina, Jorge Medina

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Beatriz Cuéllar | Entregar el punto 23 | 2026-10-16 |
