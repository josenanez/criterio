# Comité de Tecnología · Planta de tratamiento de agua

**Fecha:** 2026-10-12
**Asistentes:** Javier Hoyos, Felipe Arango

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Rubén Cárdenas | Entregar el punto 19 | 2026-11-07 |
| Sandra Gil | Entregar el punto 27 | 2026-10-18 |
