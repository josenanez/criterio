# Informe de avance · Planta de tratamiento de agua

**Código:** PRY-202
**Fecha de corte:** 2026-10-13
**Gerente:** Javier Hoyos

## Estado declarado

**Verde**

Avance reportado: **35%**

## Lo que pasó en el periodo

- Se reprogramó la parada de planta por la ventana de mantenimiento

## Presupuesto

| | COP |
|---|---|
| Aprobado | 6.800.000.000 |
| Comprometido | 4.935.969.607 |
| Ejecutado | 4.175.232.521 |
| Proyección al cierre | 6.474.985.210 |

## Riesgos abiertos

- Ventana de parada de planta definida por operaciones
- Concentración del conocimiento en una sola persona
