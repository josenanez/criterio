# Solicitud de cambio CC-01

**Proyecto:** PRY-208 · Trazabilidad del mineral
**Fecha:** 2026-10-07
**Solicitante:** Paula Céspedes

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +110 días sobre la línea base vigente |
| Costo | 220.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
