# Comité Ambiental · Programa de relacionamiento comunitario

**Fecha:** 2026-10-15
**Asistentes:** Laura Vélez, Carlos Peña

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Paula Céspedes | Entregar el punto 35 | por definir |
