# Comité de Operaciones · Mantenimiento predictivo de camiones

**Fecha:** 2026-10-02
**Asistentes:** Carlos Peña, Diana Molina, Elena Duarte, Felipe Arango, Gustavo Neira, Javier Hoyos, Jorge Medina, Ricardo Salas, Sandra Gil, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Elena Duarte | Enviar el documento 1 | 2026-11-18 |
| Diana Molina | Cerrar la prueba 2 | 2026-10-25 |
| Óscar Ramírez | Revisar el anexo 3 | 2026-10-18 |
| Sandra Gil | Validar el ambiente 4 | 2026-10-04 |
| Ricardo Salas | Actualizar la matriz 6 | 2026-09-16 |
| Javier Hoyos | Confirmar la fecha 7 | 2026-10-16 |
| Sandra Gil | Enviar el documento 9 | 2026-10-12 |
| Felipe Arango | Cerrar la prueba 10 | 2026-10-22 |
| Elena Duarte | Revisar el anexo 11 | 2026-10-04 |
| Jorge Medina | Aprobar el diseño 13 | 2026-10-09 |
| Jorge Medina | Actualizar la matriz 14 | 2026-11-09 |
| Carlos Peña | Confirmar la fecha 15 | 2026-11-06 |
| Sandra Gil | Enviar el documento 17 | 2026-10-30 |
| Gustavo Neira | Cerrar la prueba 18 | por definir |
| Felipe Arango | Revisar el anexo 19 | 2026-10-18 |
| Diana Molina | Validar el ambiente 20 | 2026-10-15 |

## Cerrados en esta reunión

- Validar el ambiente 12 (Beatriz Cuéllar): recibido, acta de recibo del 2026-10-02.

## Lo que se dijo

- Liliana Torres dice que ya entregó «aprobar el diseño 5». No se presentó acta.
- Andrés Lozano dice que ya entregó «entregar el punto 8». No se presentó acta.
- Jorge Medina dice que ya entregó «entregar el punto 16». No se presentó acta.
