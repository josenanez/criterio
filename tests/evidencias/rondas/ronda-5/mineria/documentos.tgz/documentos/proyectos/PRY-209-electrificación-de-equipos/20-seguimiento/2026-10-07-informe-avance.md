# Informe de avance · Electrificación de equipos

**Código:** PRY-209
**Fecha de corte:** 2026-10-07
**Gerente:** Javier Hoyos

## Estado declarado

**Amarillo**

Avance reportado: **54%**

## Lo que pasó en el periodo

- Se actualizó el presupuesto de la obra con el área de compras
- Se levantó un hallazgo en la auditoría de seguridad

## Presupuesto

| | COP |
|---|---|
| Aprobado | 3.300.000.000 |
| Comprometido | 2.261.539.217 |
| Ejecutado | 1.620.829.158 |
| Proyección al cierre | 3.289.376.978 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
