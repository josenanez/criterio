# Solicitud de cambio CC-01

**Proyecto:** PRY-210 · Programa de relacionamiento comunitario
**Fecha:** 2026-10-16
**Solicitante:** Laura Vélez

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +33 días sobre la línea base vigente |
| Costo | 66.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
