# Comité de Operaciones · Mantenimiento predictivo de camiones

**Fecha:** 2026-09-25
**Asistentes:** Andrés Lozano, Beatriz Cuéllar, Carlos Peña, Diana Molina, Elena Duarte, Felipe Arango, Javier Hoyos, Jorge Medina, Liliana Torres, Ricardo Salas, Sandra Gil, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Elena Duarte | Enviar el documento 1 | 2026-11-02 |
| Diana Molina | Cerrar la prueba 2 | 2026-10-13 |
| Óscar Ramírez | Revisar el anexo 3 | 2026-10-09 |
| Sandra Gil | Validar el ambiente 4 | 2026-10-04 |
| Liliana Torres | Aprobar el diseño 5 | 2026-10-04 |
| Ricardo Salas | Actualizar la matriz 6 | 2026-09-16 |
| Javier Hoyos | Confirmar la fecha 7 | 2026-09-26 |
| Andrés Lozano | Entregar el punto 8 | 2026-10-13 |
| Sandra Gil | Enviar el documento 9 | 2026-10-12 |
| Felipe Arango | Cerrar la prueba 10 | 2026-10-03 |
| Elena Duarte | Revisar el anexo 11 | 2026-10-04 |
| Beatriz Cuéllar | Validar el ambiente 12 | 2026-10-04 |
| Jorge Medina | Aprobar el diseño 13 | 2026-10-09 |
| Jorge Medina | Actualizar la matriz 14 | 2026-10-20 |
| Carlos Peña | Confirmar la fecha 15 | 2026-10-19 |
| Jorge Medina | Entregar el punto 16 | 2026-10-12 |
