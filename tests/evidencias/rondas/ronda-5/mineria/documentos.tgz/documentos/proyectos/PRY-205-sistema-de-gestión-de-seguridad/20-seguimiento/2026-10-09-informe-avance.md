# Informe de avance · Sistema de gestión de seguridad

**Código:** PRY-205
**Fecha de corte:** 2026-10-09
**Gerente:** Rubén Cárdenas

## Estado declarado

**Verde**

Avance reportado: **73%**

## Lo que pasó en el periodo

- El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite

## Presupuesto

| | COP |
|---|---|
| Aprobado | 18.000.000.000 |
| Comprometido | 6.223.168.923 |
| Ejecutado | 9.946.270.998 |
| Proyección al cierre | 16.651.362.791 |

## Riesgos abiertos

- Cambio en la licencia ambiental que puede mover el alcance
- Ventana de parada de planta definida por operaciones
