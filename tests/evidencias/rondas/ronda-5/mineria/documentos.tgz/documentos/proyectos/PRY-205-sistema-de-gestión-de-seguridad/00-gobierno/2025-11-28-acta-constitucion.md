# Acta de constitución · Sistema de gestión de seguridad

**Código:** PRY-205
**Área dueña:** Tecnología
**Patrocinador:** Beatriz Cuéllar
**Gerente de proyecto:** Rubén Cárdenas
**Comité:** Comité de Tecnología
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-11-28

## Objetivo del negocio

Entregar sistema de gestión de seguridad para Tecnología.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**18.000.000.000 COP**, aprobado por Comité de Tecnología el 2025-11-28.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-12-08 |
| Cierre | 2027-03-02 |

## Criterio de éxito

Sistema de gestión de seguridad en producción y medido.

## Dependencias declaradas

- Ninguna declarada
