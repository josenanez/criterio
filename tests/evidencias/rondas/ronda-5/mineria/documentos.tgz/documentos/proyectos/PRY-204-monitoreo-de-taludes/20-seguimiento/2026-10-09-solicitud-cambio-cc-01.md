# Solicitud de cambio CC-01

**Proyecto:** PRY-204 · Monitoreo de taludes
**Fecha:** 2026-10-09
**Solicitante:** Ricardo Salas

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +61 días sobre la línea base vigente |
| Costo | 122.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
