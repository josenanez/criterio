# Comité de Operaciones · Mantenimiento predictivo de camiones

**Fecha:** 2026-09-18
**Asistentes:** Andrés Lozano, Beatriz Cuéllar, Diana Molina, Elena Duarte, Felipe Arango, Javier Hoyos, Liliana Torres, Ricardo Salas, Sandra Gil, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Elena Duarte | Enviar el documento 1 | 2026-10-17 |
| Diana Molina | Cerrar la prueba 2 | 2026-10-02 |
| Óscar Ramírez | Revisar el anexo 3 | 2026-10-09 |
| Sandra Gil | Validar el ambiente 4 | 2026-09-20 |
| Liliana Torres | Aprobar el diseño 5 | 2026-09-24 |
| Ricardo Salas | Actualizar la matriz 6 | 2026-09-16 |
| Javier Hoyos | Confirmar la fecha 7 | 2026-09-26 |
| Andrés Lozano | Entregar el punto 8 | 2026-10-13 |
| Sandra Gil | Enviar el documento 9 | 2026-09-29 |
| Felipe Arango | Cerrar la prueba 10 | 2026-10-03 |
| Elena Duarte | Revisar el anexo 11 | 2026-10-04 |
| Beatriz Cuéllar | Validar el ambiente 12 | 2026-10-04 |
