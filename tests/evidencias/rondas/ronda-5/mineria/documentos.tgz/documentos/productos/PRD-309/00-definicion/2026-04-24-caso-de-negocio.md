# Caso de negocio · Inspección con drones

**Código:** PRD-309
**Fecha:** 2026-04-24
**Preparado por:** Paula Céspedes

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 124.520 | Caso de negocio, 2026-04-24 |

## Retorno esperado

Retorno esperado en 24 meses.
