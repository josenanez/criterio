# Tablero de métricas · Trazabilidad

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-14

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 116.821 | 2026-10-14 |
