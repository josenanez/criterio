# Comité de producto · Almacén de repuestos

**Fecha:** 2026-09-19
**Asistentes:** Javier Hoyos

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4600 | Requerimiento REQ-4600 | Beatriz Cuéllar | se verifica en producción | — | aceptado | 2026-03-27 | — |
| REQ-4601 | Requerimiento REQ-4601 | María Restrepo | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-27 | — |
| REQ-4602 | Requerimiento REQ-4602 | Javier Hoyos | se verifica en producción | — | aceptado | 2026-07-16 | — |
| REQ-4603 | Requerimiento REQ-4603 | Beatriz Cuéllar | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-19 | — |
| REQ-4604 | Requerimiento REQ-4604 | Laura Vélez | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-26 | — |
| REQ-4605 | Requerimiento REQ-4605 | Ricardo Salas | — | Cliente entrevistado | aceptado | 2026-05-24 | — |
| REQ-4606 | Requerimiento REQ-4606 | Elena Duarte | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-10 | — |
| REQ-4607 | Requerimiento REQ-4607 | Camilo Beltrán | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-04 | — |
| REQ-4608 | Requerimiento REQ-4608 | Elena Duarte | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-24 | — |
| REQ-4609 | Requerimiento REQ-4609 | Óscar Ramírez | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-05 | — |
| REQ-4610 | Requerimiento REQ-4610 | Natalia Ospina | se verifica en producción | — | propuesto | 2026-04-26 | — |
| REQ-4611 | Requerimiento REQ-4611 | sin asignar | — | Cliente entrevistado | aceptado | 2026-05-10 | — |
| REQ-4612 | Requerimiento REQ-4612 | sin asignar | — | Cliente entrevistado | propuesto | 2026-04-14 | — |
| REQ-4613 | Requerimiento REQ-4613 | Ricardo Salas | se verifica en producción | — | aceptado | 2026-08-30 | — |

## Decisiones

- Se mantiene el plan
