# Tablero de métricas · Alerta de fatiga

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-15

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 55.059 | 2026-10-15 |
