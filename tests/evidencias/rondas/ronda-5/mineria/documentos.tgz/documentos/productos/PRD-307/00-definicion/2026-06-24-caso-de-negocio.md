# Caso de negocio · Reporte ambiental

**Código:** PRD-307
**Fecha:** 2026-06-24
**Preparado por:** Rubén Cárdenas

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 227.161 | Caso de negocio, 2026-06-24 |

## Retorno esperado

Retorno esperado en 24 meses.
