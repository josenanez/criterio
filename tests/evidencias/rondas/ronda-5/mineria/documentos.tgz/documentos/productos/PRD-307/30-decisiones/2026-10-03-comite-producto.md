# Comité de producto · Reporte ambiental

**Fecha:** 2026-10-03
**Asistentes:** Rubén Cárdenas

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4700 | Requerimiento REQ-4700 | Carlos Peña | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-10 | — |
| REQ-4701 | Requerimiento REQ-4701 | Sandra Gil | — | — | aceptado | 2026-04-15 | — |
| REQ-4702 | Requerimiento REQ-4702 | Gustavo Neira | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-19 | — |
| REQ-4703 | Requerimiento REQ-4703 | Javier Hoyos | — | Cliente entrevistado | aceptado | 2026-09-02 | — |
| REQ-4704 | Requerimiento REQ-4704 | Diana Molina | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-31 | — |
| REQ-4705 | Requerimiento REQ-4705 | Mauricio Pérez | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-21 | — |
| REQ-4706 | Requerimiento REQ-4706 | Andrés Lozano | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-06 | — |
| REQ-4707 | Requerimiento REQ-4707 | Gustavo Neira | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-20 | — |
| REQ-4708 | Requerimiento REQ-4708 | Mauricio Pérez | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-14 | — |
| REQ-4709 | Requerimiento REQ-4709 | Laura Vélez | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-11 | — |
| REQ-4710 | Requerimiento REQ-4710 | Elena Duarte | se verifica en producción | — | aceptado | 2026-06-01 | — |
| REQ-4711 | Requerimiento REQ-4711 | Elena Duarte | se verifica en producción | Cliente entrevistado | propuesto | 2026-08-04 | — |
| REQ-4712 | Requerimiento REQ-4712 | Sandra Gil | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-24 | — |
| REQ-4713 | Requerimiento REQ-4713 | sin asignar | — | — | propuesto | 2026-04-21 | — |
| REQ-2028 | Requerimiento REQ-2028 | Sandra Gil | se verifica en producción | Cliente entrevistado | aceptado | 2026-09-19 | — |

## Decisiones

- Se mantiene el plan
