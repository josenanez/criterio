# Caso de negocio · Alerta de taludes

**Código:** PRD-301
**Fecha:** 2026-05-30
**Preparado por:** Óscar Ramírez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 123.463 | Caso de negocio, 2026-05-30 |

## Retorno esperado

Retorno esperado en 24 meses.
