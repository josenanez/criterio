# Tablero de métricas · Monitoreo de flota

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-02

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 48.010 | 2026-10-02 |
