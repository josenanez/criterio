# Caso de negocio · Despacho de flota

**Código:** PRD-302
**Fecha:** 2025-11-20
**Preparado por:** Elena Duarte

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 152.670 | Caso de negocio, 2025-11-20 |

## Retorno esperado

Retorno esperado en 24 meses.
