# Caso de negocio · Permisos de trabajo digitales

**Código:** PRD-308
**Fecha:** 2026-04-15
**Preparado por:** Diana Molina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 209.706 | Caso de negocio, 2026-04-15 |

## Retorno esperado

Retorno esperado en 24 meses.
