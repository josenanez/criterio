# Tablero de métricas · Inspección con drones

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-13

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 86.430 | 2026-10-13 |
