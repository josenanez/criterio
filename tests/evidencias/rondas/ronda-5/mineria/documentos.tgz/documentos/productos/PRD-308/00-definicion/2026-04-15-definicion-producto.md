# Definición de producto · Permisos de trabajo digitales

**Código:** PRD-308
**Gerente de producto:** Diana Molina
**Segmento:** Gerencia
**Fecha de la definición:** 2026-04-15

## El problema

El segmento Gerencia no tiene permisos de trabajo digitales.

## La propuesta

- Propuesta principal

## Supuestos

- **La licencia ambiental lo permite** · declarado el 2026-08-07 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
