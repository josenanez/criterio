# Tablero de métricas · Reporte ambiental

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-03

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 166.264 | 2026-10-03 |
