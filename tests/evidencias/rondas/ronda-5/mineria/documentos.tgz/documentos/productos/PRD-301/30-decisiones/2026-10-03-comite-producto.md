# Comité de producto · Alerta de taludes

**Fecha:** 2026-10-03
**Asistentes:** Óscar Ramírez

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4100 | Requerimiento REQ-4100 | Liliana Torres | — | — | aceptado | 2026-07-17 | — |
| REQ-4101 | Requerimiento REQ-4101 | Felipe Arango | — | Cliente entrevistado | aceptado | 2026-07-11 | — |
| REQ-4102 | Requerimiento REQ-4102 | Javier Hoyos | se verifica en producción | — | aceptado | 2026-04-14 | — |
| REQ-4103 | Requerimiento REQ-4103 | Gustavo Neira | se verifica en producción | — | aceptado | 2026-05-10 | — |
| REQ-4104 | Requerimiento REQ-4104 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-12 | — |
| REQ-4105 | Requerimiento REQ-4105 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-10 | — |
| REQ-4106 | Requerimiento REQ-4106 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-27 | — |
| REQ-4107 | Requerimiento REQ-4107 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-04 | — |
| REQ-4108 | Requerimiento REQ-4108 | Diana Molina | — | Cliente entrevistado | aceptado | 2026-05-27 | — |
| REQ-4109 | Requerimiento REQ-4109 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-06 | — |
| REQ-4110 | Requerimiento REQ-4110 | Beatriz Cuéllar | — | Cliente entrevistado | aceptado | 2026-04-16 | — |
| REQ-4111 | Requerimiento REQ-4111 | Sandra Gil | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-18 | — |
| REQ-2026 | Requerimiento REQ-2026 | Rubén Cárdenas | se verifica en producción | — | aceptado | 2026-09-24 | — |

## Decisiones

- Se mantiene el plan
