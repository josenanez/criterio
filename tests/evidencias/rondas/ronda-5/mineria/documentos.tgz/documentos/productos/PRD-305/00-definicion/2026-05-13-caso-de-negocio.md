# Caso de negocio · Alerta de fatiga

**Código:** PRD-305
**Fecha:** 2026-05-13
**Preparado por:** Beatriz Cuéllar

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 76.325 | Caso de negocio, 2026-05-13 |

## Retorno esperado

Retorno esperado en 24 meses.
