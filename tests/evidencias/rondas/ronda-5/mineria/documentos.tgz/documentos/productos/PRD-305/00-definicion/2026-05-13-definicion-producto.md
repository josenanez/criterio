# Definición de producto · Alerta de fatiga

**Código:** PRD-305
**Gerente de producto:** Beatriz Cuéllar
**Segmento:** Comunidad
**Fecha de la definición:** 2026-05-13

## El problema

El segmento Comunidad no tiene alerta de fatiga.

## La propuesta

- Propuesta principal

## Supuestos

- **El ahorro se sostiene sin inversión adicional** · declarado el 2026-08-20 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
