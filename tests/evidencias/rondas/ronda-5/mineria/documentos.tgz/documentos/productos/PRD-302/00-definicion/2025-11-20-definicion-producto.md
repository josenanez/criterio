# Definición de producto · Despacho de flota

**Código:** PRD-302
**Gerente de producto:** Elena Duarte
**Segmento:** Gerencia
**Fecha de la definición:** 2025-11-20

## El problema

El segmento Gerencia no tiene despacho de flota.

## La propuesta

- Propuesta principal

## Supuestos

- **La licencia ambiental lo permite** · declarado el 2026-06-29 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
