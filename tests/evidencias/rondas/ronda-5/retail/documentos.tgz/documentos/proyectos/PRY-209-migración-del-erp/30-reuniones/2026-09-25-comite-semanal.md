# Comité de Arquitectura · Migración del ERP

**Fecha:** 2026-09-25
**Asistentes:** Andrés Lozano, Carlos Peña, Felipe Arango, Javier Hoyos, Laura Vélez, Liliana Torres, Mauricio Pérez, Natalia Ospina, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Natalia Ospina | Enviar el documento 1 | 2026-10-19 |
| Mauricio Pérez | Cerrar la prueba 2 | 2026-10-29 |
| Óscar Ramírez | Revisar el anexo 3 | 2026-09-10 |
| Mauricio Pérez | Validar el ambiente 4 | 2026-10-04 |
| Laura Vélez | Aprobar el diseño 5 | 2026-10-19 |
| Andrés Lozano | Actualizar la matriz 6 | 2026-09-29 |
| Óscar Ramírez | Confirmar la fecha 7 | 2026-10-25 |
| Felipe Arango | Enviar el documento 9 | 2026-10-07 |
| Natalia Ospina | Cerrar la prueba 10 | 2026-10-09 |
| Carlos Peña | Validar el ambiente 12 | por definir |
| Natalia Ospina | Aprobar el diseño 13 | 2026-10-16 |
| Javier Hoyos | Actualizar la matriz 14 | 2026-09-30 |
| Mauricio Pérez | Confirmar la fecha 15 | 2026-10-04 |
| Óscar Ramírez | Entregar el punto 16 | 2026-10-21 |

## Cerrados en esta reunión

- Entregar el punto 8 (Ricardo Salas): recibido, acta de recibo del 2026-09-25.

## Lo que se dijo

- Beatriz Cuéllar dice que ya entregó «revisar el anexo 11». No se presentó acta.
