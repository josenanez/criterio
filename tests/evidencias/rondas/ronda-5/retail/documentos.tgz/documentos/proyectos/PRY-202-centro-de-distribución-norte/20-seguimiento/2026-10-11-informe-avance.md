# Informe de avance · Centro de distribución norte

**Código:** PRY-202
**Fecha de corte:** 2026-10-11
**Gerente:** Laura Vélez

## Estado declarado

**Amarillo**

Avance reportado: **63%**

## Lo que pasó en el periodo

- La validación con dos tiendas se extendió una semana por el conteo de inventario

## Presupuesto

| | COP |
|---|---|
| Aprobado | 4.200.000.000 |
| Comprometido | 2.694.656.765 |
| Ejecutado | 2.157.815.149 |
| Proyección al cierre | 5.168.800.668 |

## Riesgos abiertos

- Cambio en la regulación de datos personales que puede mover el alcance
- Disponibilidad de los jefes de tienda para el piloto
