# Comité de Arquitectura · Migración del ERP

**Fecha:** 2026-09-11
**Asistentes:** Andrés Lozano, Laura Vélez, Liliana Torres, Mauricio Pérez, Natalia Ospina, Ricardo Salas, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Natalia Ospina | Enviar el documento 1 | 2026-09-29 |
| Mauricio Pérez | Cerrar la prueba 2 | 2026-10-08 |
| Óscar Ramírez | Revisar el anexo 3 | 2026-09-10 |
| Mauricio Pérez | Validar el ambiente 4 | 2026-09-27 |
| Laura Vélez | Aprobar el diseño 5 | 2026-09-18 |
| Andrés Lozano | Actualizar la matriz 6 | 2026-09-29 |
| Óscar Ramírez | Confirmar la fecha 7 | 2026-10-03 |
| Ricardo Salas | Entregar el punto 8 | 2026-09-25 |
