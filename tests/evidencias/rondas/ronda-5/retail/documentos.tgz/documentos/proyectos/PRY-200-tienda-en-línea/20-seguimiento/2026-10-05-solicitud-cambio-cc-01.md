# Solicitud de cambio CC-01

**Proyecto:** PRY-200 · Tienda en línea
**Fecha:** 2026-10-05
**Solicitante:** Beatriz Cuéllar

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +27 días sobre la línea base vigente |
| Costo | 54.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
