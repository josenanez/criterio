# Comité de Transformación Digital · Domicilios en dos horas

**Fecha:** 2026-10-16
**Asistentes:** Ricardo Salas, Liliana Torres

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Javier Hoyos | Entregar el punto 13 | por definir |
