# Informe de avance · Pronóstico de demanda

**Código:** PRY-211
**Fecha de corte:** 2026-10-07
**Gerente:** Liliana Torres

## Estado declarado

**Verde**

Avance reportado: **30%**

## Lo que pasó en el periodo

- Se levantó un hallazgo de seguridad en los medios de pago
- El equipo perdió dos semanas por rotación de un desarrollador clave

## Presupuesto

| | COP |
|---|---|
| Aprobado | 18.000.000.000 |
| Comprometido | 5.348.240.642 |
| Ejecutado | 5.809.195.257 |
| Proyección al cierre | 22.674.610.455 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
