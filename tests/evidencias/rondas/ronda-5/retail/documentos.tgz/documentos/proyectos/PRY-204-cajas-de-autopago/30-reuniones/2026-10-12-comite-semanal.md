# Comité de Transformación Digital · Cajas de autopago

**Fecha:** 2026-10-12
**Asistentes:** Javier Hoyos, María Restrepo

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Paula Céspedes | Entregar el punto 2 | 2026-10-13 |
