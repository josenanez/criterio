# Acta de constitución · Cajas de autopago

**Código:** PRY-204
**Área dueña:** Tiendas
**Patrocinador:** María Restrepo
**Gerente de proyecto:** Javier Hoyos
**Comité:** Comité de Transformación Digital
**Producto asociado:** autopago en tienda
**Fecha de aprobación:** 2026-06-02

## Objetivo del negocio

Entregar cajas de autopago para Tiendas.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**800.000.000 COP**, aprobado por Comité de Transformación Digital el 2026-06-02.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-06-12 |
| Cierre | 2027-03-16 |

## Criterio de éxito

Cajas de autopago en producción y medido.

## Dependencias declaradas

- Ninguna declarada
