# Comité Comercial · Tienda en línea

**Fecha:** 2026-10-08
**Asistentes:** Beatriz Cuéllar, Paula Céspedes

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Óscar Ramírez | Entregar el punto 1 | 2026-10-30 |
