# Comité de Arquitectura · Migración del ERP

**Fecha:** 2026-09-18
**Asistentes:** Andrés Lozano, Beatriz Cuéllar, Carlos Peña, Felipe Arango, Laura Vélez, Liliana Torres, Mauricio Pérez, Natalia Ospina, Ricardo Salas, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Natalia Ospina | Enviar el documento 1 | 2026-10-08 |
| Mauricio Pérez | Cerrar la prueba 2 | 2026-10-19 |
| Óscar Ramírez | Revisar el anexo 3 | 2026-09-10 |
| Mauricio Pérez | Validar el ambiente 4 | 2026-09-27 |
| Laura Vélez | Aprobar el diseño 5 | 2026-10-06 |
| Andrés Lozano | Actualizar la matriz 6 | 2026-09-29 |
| Óscar Ramírez | Confirmar la fecha 7 | 2026-10-12 |
| Ricardo Salas | Entregar el punto 8 | 2026-09-25 |
| Felipe Arango | Enviar el documento 9 | 2026-10-07 |
| Natalia Ospina | Cerrar la prueba 10 | por definir |
| Beatriz Cuéllar | Revisar el anexo 11 | 2026-09-24 |
| Carlos Peña | Validar el ambiente 12 | por definir |
