# Informe de avance · Tienda en línea

**Código:** PRY-200
**Fecha de corte:** 2026-10-13
**Gerente:** Beatriz Cuéllar

## Estado declarado

**Verde**

Avance reportado: **79%**

## Lo que pasó en el periodo

- Se levantó un hallazgo de seguridad en los medios de pago
- Se reprogramó el despliegue por el congelamiento de temporada de fin de año
- La validación con dos tiendas se extendió una semana por el conteo de inventario

## Presupuesto

| | COP |
|---|---|
| Aprobado | 9.500.000.000 |
| Comprometido | 4.320.569.896 |
| Ejecutado | 1.982.398.380 |
| Proyección al cierre | 11.453.287.850 |

## Riesgos abiertos

- Congelamiento de cambios en temporada alta
- Disponibilidad de los jefes de tienda para el piloto
