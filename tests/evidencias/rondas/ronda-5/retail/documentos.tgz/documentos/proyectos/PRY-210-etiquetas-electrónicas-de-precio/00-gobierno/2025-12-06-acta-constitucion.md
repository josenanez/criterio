# Acta de constitución · Etiquetas electrónicas de precio

**Código:** PRY-210
**Área dueña:** Finanzas
**Patrocinador:** Rubén Cárdenas
**Gerente de proyecto:** Paula Céspedes
**Comité:** Comité de Expansión
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-12-06

## Objetivo del negocio

Entregar etiquetas electrónicas de precio para Finanzas.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**2.400.000.000 COP**, aprobado por Comité de Expansión el 2025-12-06.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-12-16 |
| Cierre | 2027-06-28 |

## Criterio de éxito

Etiquetas electrónicas de precio en producción y medido.

## Dependencias declaradas

- Ninguna declarada
