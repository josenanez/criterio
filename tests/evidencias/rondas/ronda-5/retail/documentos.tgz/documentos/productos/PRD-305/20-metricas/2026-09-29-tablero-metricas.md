# Tablero de métricas · Entrega rápida

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-09-29

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 152.852 | 2026-09-29 |
