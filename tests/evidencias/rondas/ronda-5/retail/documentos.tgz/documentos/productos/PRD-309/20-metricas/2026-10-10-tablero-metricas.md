# Tablero de métricas · Tarjeta de la tienda

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-10

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 70.717 | 2026-10-10 |
