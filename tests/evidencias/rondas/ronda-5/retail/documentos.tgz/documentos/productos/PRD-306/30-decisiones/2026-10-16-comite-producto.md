# Comité de producto · App de clientes

**Fecha:** 2026-10-16
**Asistentes:** Felipe Arango

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4600 | Requerimiento REQ-4600 | Camilo Beltrán | se verifica en producción | Cliente entrevistado | propuesto | 2026-06-18 | — |
| REQ-4601 | Requerimiento REQ-4601 | Diana Molina | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-21 | — |
| REQ-4602 | Requerimiento REQ-4602 | Jorge Medina | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-20 | — |
| REQ-4603 | Requerimiento REQ-4603 | Camilo Beltrán | — | Cliente entrevistado | aceptado | 2026-06-03 | — |
| REQ-4604 | Requerimiento REQ-4604 | Mauricio Pérez | — | Cliente entrevistado | aceptado | 2026-07-24 | — |
| REQ-4605 | Requerimiento REQ-4605 | Paula Céspedes | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-26 | — |
| REQ-4606 | Requerimiento REQ-4606 | Andrés Lozano | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-23 | — |
| REQ-4607 | Requerimiento REQ-4607 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-23 | — |
| REQ-4608 | Requerimiento REQ-4608 | María Restrepo | — | — | aceptado | 2026-08-05 | — |
| REQ-4609 | Requerimiento REQ-4609 | Natalia Ospina | — | Cliente entrevistado | aceptado | 2026-08-27 | — |
| REQ-4610 | Requerimiento REQ-4610 | Elena Duarte | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-22 | — |
| REQ-4611 | Requerimiento REQ-4611 | Liliana Torres | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-18 | — |
| REQ-4612 | Requerimiento REQ-4612 | Sandra Gil | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-15 | — |
| REQ-4613 | Requerimiento REQ-4613 | Mauricio Pérez | — | Cliente entrevistado | aceptado | 2026-06-02 | — |
| REQ-2028 | Requerimiento REQ-2028 | Sandra Gil | se verifica en producción | — | aceptado | 2026-09-19 | — |
| REQ-2036 | Requerimiento REQ-2036 | Javier Hoyos | se verifica en producción | Cliente entrevistado | aceptado | 2026-10-04 | — |

## Decisiones

- Se mantiene el plan
