# Caso de negocio · App de clientes

**Código:** PRD-306
**Fecha:** 2026-03-16
**Preparado por:** Felipe Arango

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 67.794 | Caso de negocio, 2026-03-16 |

## Retorno esperado

Retorno esperado en 24 meses.
