# Definición de producto · Compra y recoge

**Código:** PRD-307
**Gerente de producto:** Beatriz Cuéllar
**Segmento:** Hogares
**Fecha de la definición:** 2026-01-30

## El problema

El segmento Hogares no tiene compra y recoge.

## La propuesta

- Propuesta principal

## Supuestos

- **La demanda se sostiene sin descuento** · declarado el 2026-04-20 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
