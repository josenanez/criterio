# Tablero de métricas · Autopago en tienda

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-08

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 180.563 | 2026-10-08 |
