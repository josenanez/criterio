# Caso de negocio · Marketplace

**Código:** PRD-308
**Fecha:** 2026-04-19
**Preparado por:** Beatriz Cuéllar

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 71.781 | Caso de negocio, 2026-04-19 |

## Retorno esperado

Retorno esperado en 24 meses.
