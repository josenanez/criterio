# Comité de producto · Venta en línea

**Fecha:** 2026-10-03
**Asistentes:** Felipe Arango

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4000 | Requerimiento REQ-4000 | María Restrepo | se verifica en producción | — | aceptado | 2026-08-31 | — |
| REQ-4001 | Requerimiento REQ-4001 | Javier Hoyos | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-13 | — |
| REQ-4002 | Requerimiento REQ-4002 | Ricardo Salas | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-11 | — |
| REQ-4003 | Requerimiento REQ-4003 | sin asignar | se verifica en producción | Cliente entrevistado | propuesto | 2026-06-18 | — |
| REQ-4004 | Requerimiento REQ-4004 | Diana Molina | — | Cliente entrevistado | aceptado | 2026-06-02 | — |
| REQ-4005 | Requerimiento REQ-4005 | María Restrepo | se verifica en producción | — | propuesto | 2026-06-24 | — |
| REQ-4006 | Requerimiento REQ-4006 | Natalia Ospina | se verifica en producción | — | aceptado | 2026-04-28 | — |
| REQ-4007 | Requerimiento REQ-4007 | Rubén Cárdenas | se verifica en producción | — | aceptado | 2026-04-26 | — |
| REQ-4008 | Requerimiento REQ-4008 | Liliana Torres | — | Cliente entrevistado | aceptado | 2026-06-28 | — |
| REQ-4009 | Requerimiento REQ-4009 | Camilo Beltrán | se verifica en producción | — | aceptado | 2026-04-03 | — |
| REQ-4010 | Requerimiento REQ-4010 | sin asignar | se verifica en producción | Cliente entrevistado | propuesto | 2026-06-05 | — |
| REQ-4011 | Requerimiento REQ-4011 | Ricardo Salas | se verifica en producción | Cliente entrevistado | propuesto | 2026-08-24 | — |
| REQ-4012 | Requerimiento REQ-4012 | Felipe Arango | se verifica en producción | — | aceptado | 2026-07-16 | — |
| REQ-4013 | Requerimiento REQ-4013 | Diana Molina | — | Cliente entrevistado | propuesto | 2026-03-31 | — |

## Decisiones

- Se mantiene el plan
