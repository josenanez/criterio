# Entrevistas · Puntos de fidelización

**Ronda:** Ronda · 2025-12-30
**Realizadas por:** Diana Molina

### Cliente entrevistado · 2025-12-30

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
