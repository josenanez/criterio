# Caso de negocio · Entrega rápida

**Código:** PRD-305
**Fecha:** 2025-09-25
**Preparado por:** Rubén Cárdenas

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 195.175 | Caso de negocio, 2025-09-25 |

## Retorno esperado

Retorno esperado en 24 meses.
