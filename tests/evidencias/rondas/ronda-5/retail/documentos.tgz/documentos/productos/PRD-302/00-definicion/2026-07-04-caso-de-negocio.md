# Caso de negocio · Autopago en tienda

**Código:** PRD-302
**Fecha:** 2026-07-04
**Preparado por:** Óscar Ramírez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 277.018 | Caso de negocio, 2026-07-04 |

## Retorno esperado

Retorno esperado en 24 meses.
