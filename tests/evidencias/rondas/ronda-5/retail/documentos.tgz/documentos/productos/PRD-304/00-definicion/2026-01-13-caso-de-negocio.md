# Caso de negocio · Marca propia

**Código:** PRD-304
**Fecha:** 2026-01-13
**Preparado por:** María Restrepo

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 227.421 | Caso de negocio, 2026-01-13 |

## Retorno esperado

Retorno esperado en 24 meses.
