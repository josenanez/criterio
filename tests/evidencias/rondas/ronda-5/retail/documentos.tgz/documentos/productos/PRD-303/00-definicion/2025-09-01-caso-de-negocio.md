# Caso de negocio · Pago con QR

**Código:** PRD-303
**Fecha:** 2025-09-01
**Preparado por:** Elena Duarte

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 119.643 | Caso de negocio, 2025-09-01 |

## Retorno esperado

Retorno esperado en 24 meses.
