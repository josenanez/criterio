# Tablero de métricas · Puntos de fidelización

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-08

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 270.076 | 2026-10-08 |
