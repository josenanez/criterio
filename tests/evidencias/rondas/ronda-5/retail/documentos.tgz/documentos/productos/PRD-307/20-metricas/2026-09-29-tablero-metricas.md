# Tablero de métricas · Compra y recoge

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-09-29

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 175.794 | 2026-09-29 |
