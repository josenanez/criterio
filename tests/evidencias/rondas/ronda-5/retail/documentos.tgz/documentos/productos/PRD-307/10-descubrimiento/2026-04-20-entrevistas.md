# Entrevistas · Compra y recoge

**Ronda:** Ronda · 2026-04-20
**Realizadas por:** Beatriz Cuéllar

### Cliente entrevistado · 2026-04-20

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
