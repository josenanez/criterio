# Definición de producto · Marketplace

**Código:** PRD-308
**Gerente de producto:** Beatriz Cuéllar
**Segmento:** Clientes frecuentes
**Fecha de la definición:** 2026-04-19

## El problema

El segmento Clientes frecuentes no tiene marketplace.

## La propuesta

- Propuesta principal

## Supuestos

- **El proveedor cumple el tiempo pactado** · declarado el 2026-06-18 · verificado

## Proyectos que lo construyen

- Ninguno declarado
