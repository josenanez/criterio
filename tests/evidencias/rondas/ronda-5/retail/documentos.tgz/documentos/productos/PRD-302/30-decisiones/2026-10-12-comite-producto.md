# Comité de producto · Autopago en tienda

**Fecha:** 2026-10-12
**Asistentes:** Óscar Ramírez

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4200 | Requerimiento REQ-4200 | Sandra Gil | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-03 | — |
| REQ-4201 | Requerimiento REQ-4201 | sin asignar | se verifica en producción | — | aceptado | 2026-05-22 | — |
| REQ-4202 | Requerimiento REQ-4202 | Javier Hoyos | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-13 | — |
| REQ-4203 | Requerimiento REQ-4203 | Elena Duarte | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-14 | — |
| REQ-4204 | Requerimiento REQ-4204 | Jorge Medina | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-19 | — |
| REQ-4205 | Requerimiento REQ-4205 | María Restrepo | — | Cliente entrevistado | aceptado | 2026-08-15 | — |
| REQ-4206 | Requerimiento REQ-4206 | Rubén Cárdenas | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-17 | — |
| REQ-4207 | Requerimiento REQ-4207 | Óscar Ramírez | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-24 | — |
| REQ-4208 | Requerimiento REQ-4208 | Carlos Peña | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-23 | — |
| REQ-4209 | Requerimiento REQ-4209 | Jorge Medina | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-11 | — |
| REQ-4210 | Requerimiento REQ-4210 | Jorge Medina | — | Cliente entrevistado | aceptado | 2026-07-27 | — |
| REQ-4211 | Requerimiento REQ-4211 | Gustavo Neira | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-12 | — |

## Decisiones

- Se mantiene el plan
