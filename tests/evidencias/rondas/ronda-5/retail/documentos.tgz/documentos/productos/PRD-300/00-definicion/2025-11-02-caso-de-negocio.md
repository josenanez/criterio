# Caso de negocio · Venta en línea

**Código:** PRD-300
**Fecha:** 2025-11-02
**Preparado por:** Felipe Arango

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 275.978 | Caso de negocio, 2025-11-02 |

## Retorno esperado

Retorno esperado en 24 meses.
