# Comité de producto · Puntos de fidelización

**Fecha:** 2026-10-12
**Asistentes:** Diana Molina

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4100 | Requerimiento REQ-4100 | Gustavo Neira | — | Cliente entrevistado | propuesto | 2026-08-01 | — |
| REQ-4101 | Requerimiento REQ-4101 | Liliana Torres | se verifica en producción | — | aceptado | 2026-05-18 | — |
| REQ-4102 | Requerimiento REQ-4102 | Óscar Ramírez | se verifica en producción | — | propuesto | 2026-08-08 | — |
| REQ-4103 | Requerimiento REQ-4103 | Jorge Medina | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-15 | — |
| REQ-4104 | Requerimiento REQ-4104 | sin asignar | se verifica en producción | — | aceptado | 2026-04-26 | — |
| REQ-4105 | Requerimiento REQ-4105 | Carlos Peña | — | Cliente entrevistado | aceptado | 2026-06-13 | — |
| REQ-4106 | Requerimiento REQ-4106 | Laura Vélez | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-17 | — |
| REQ-4107 | Requerimiento REQ-4107 | Rubén Cárdenas | se verifica en producción | Cliente entrevistado | propuesto | 2026-04-27 | — |
| REQ-4108 | Requerimiento REQ-4108 | Elena Duarte | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-21 | — |
| REQ-4109 | Requerimiento REQ-4109 | sin asignar | — | Cliente entrevistado | aceptado | 2026-06-17 | — |
| REQ-4110 | Requerimiento REQ-4110 | Ricardo Salas | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-10 | — |
| REQ-4111 | Requerimiento REQ-4111 | Andrés Lozano | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-24 | — |
| REQ-4112 | Requerimiento REQ-4112 | Liliana Torres | se verifica en producción | — | propuesto | 2026-04-06 | — |
| REQ-4113 | Requerimiento REQ-4113 | Javier Hoyos | — | — | aceptado | 2026-07-06 | — |

## Decisiones

- Se mantiene el plan
