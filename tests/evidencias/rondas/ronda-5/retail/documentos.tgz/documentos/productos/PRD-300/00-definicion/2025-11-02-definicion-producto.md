# Definición de producto · Venta en línea

**Código:** PRD-300
**Gerente de producto:** Felipe Arango
**Segmento:** Empresas
**Fecha de la definición:** 2025-11-02

## El problema

El segmento Empresas no tiene venta en línea.

## La propuesta

- Propuesta principal

## Supuestos

- **El proveedor cumple el tiempo pactado** · declarado el 2026-04-26 · verificado

## Proyectos que lo construyen

- Ninguno declarado
