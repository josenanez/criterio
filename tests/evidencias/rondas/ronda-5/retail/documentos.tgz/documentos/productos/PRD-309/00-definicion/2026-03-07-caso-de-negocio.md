# Caso de negocio · Tarjeta de la tienda

**Código:** PRD-309
**Fecha:** 2026-03-07
**Preparado por:** Mauricio Pérez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 74.642 | Caso de negocio, 2026-03-07 |

## Retorno esperado

Retorno esperado en 24 meses.
