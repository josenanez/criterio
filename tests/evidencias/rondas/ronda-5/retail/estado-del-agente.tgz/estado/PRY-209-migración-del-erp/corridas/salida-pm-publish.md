Publiqué la ficha en `documentos/proyectos/PRY-209-migración-del-erp/00-gobierno/ficha-pm.json`, con corte al 2026-10-16.

**Lleva:** 35 campos con dato · 7 sin decir en ninguna parte · declara **verde** al 2026-10-12 (informe de avance, 4 días de antigüedad)

Los 7 sin decir: `identity.authority`, `identity.product`, `identity.phase`, `vendors`, y la evidencia de los hitos 2, 3 y 4 (ambiente de pruebas, integración con el ERP, piloto en tiendas).

**Lo más viejo que va ahí:** identidad, plan y presupuesto aprobado, del 2026-04-17 (acta de constitución) — menos de un año, dentro del umbral de 12 meses.

**Antes de que la PMO la lea, conviene que sepas:**
- La declaración **verde** no la sostiene la evidencia: el cálculo marca 3 señales que el informe no recoge — avance declarado 71 % frente a 1 de 4 hitos cumplidos (el plan sustenta 25–50 %), 6 compromisos vencidos sin evidencia y 2 reprogramados 5 y 6 veces.
- Declarado queda marcado como declarado (`source_kind: declaration`): estado, avance y las cifras de comprometido, ejecutado y proyección.
- Escribí solo este archivo. No avisé a nadie; Vera la encontrará en su próximo barrido.
- La ficha publicada es la de `records/PRY-209.json`, actualizada hoy; el recálculo (`compute`) no encontró cambios que obliguen a reescribirla.
