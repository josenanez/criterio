## Listo — PRY-209 · Migración del ERP

**Lo que miré:** 15 documentos · 7 minutas (6 comités semanales del 2026-09-04 al 2026-10-09 y las notas del 2026-10-16) · la última del 2026-10-16. Leí las siete, de la más vieja a la más nueva, y las cinco actas de recibo. Todos los formatos (md, csv, pdf, txt) se pudieron leer.

**Las cuatro preguntas** (sesión sin interfaz, tomé la respuesta sugerida en cada una):
1. Eres Liliana Torres, gerente de PRY-209 Migración del ERP (acta de constitución del 2026-04-17).
2. Tu reunión es el comité semanal de los viernes; las notas del 2026-10-16 dicen «próxima reunión en dos semanas», así que dejé el 2026-10-30 como la próxima.
3. Guardo lo que encuentre en `estado/PRY-209-migración-del-erp`, fuera de tu carpeta de documentación y de `.criterio/`.
4. Términos 1.1 aceptados por José Francisco Ñáñez, con el sí explícito que trajo la prueba.

**Términos:** aceptados para la versión 0.3.11 · comprobante en `.criterio/terminos/aceptacion-criterio-project-0.3.11-2026-10-16.md` y `.pdf` · SHA-256 `042a62265e2a038b`… (md) y `51a20680f2513579`… (pdf)

Leídas todas, el proyecto tiene **26 compromisos: 4 cumplidos con acta y 22 sin cerrar**. Solo 2 nacen en las notas del 2026-10-16; los otros 24 salen de leer las minutas anteriores en orden, y las notas de ese día solo mueven uno de ellos (el documento 1).

### Lo que está abierto, y cuántas veces se ha movido

**Los que se han movido más (el script los levantó, umbral 3):**

| Quién | Qué | Para cuándo | Veces movido |
|---|---|---|---|
| Natalia Ospina | Enviar el documento 1 | 2026-11-25 (era 2026-09-20) | **6** — 09-29, 10-08, 10-19, 11-03, 11-11, 11-25 |
| Mauricio Pérez | Cerrar la prueba 2 | 2026-11-28 (era 2026-09-30) | **5** — 10-08, 10-19, 10-29, 11-13, 11-28 |

Citas: Natalia, `30-reuniones/2026-09-04-comite-semanal.md` (la primera promesa) hasta `2026-10-16-notas-reunion.txt` («no alcanzó, se compromete para el 25/11/2026»); Mauricio, `30-reuniones/2026-09-04-comite-semanal.md` hasta `30-reuniones/2026-10-09-comite-semanal.md`. Ninguno tiene acta de recibo.

**Vencidos sin evidencia (el script los levantó):**

| Quién | Qué | Venció | Días | Cita |
|---|---|---|---|---|
| Beatriz Cuéllar | Revisar el anexo 11 | 2026-09-24 | 22 | `30-reuniones/2026-09-18-comite-semanal.md`; el 09-25 dijo que ya lo entregó, «no se presentó acta» |
| Javier Hoyos | Actualizar la matriz 14 | 2026-09-30 | 16 | `30-reuniones/2026-09-25-comite-semanal.md` |
| Felipe Arango | Enviar el documento 9 | 2026-10-07 | 9 | `30-reuniones/2026-09-18-comite-semanal.md` |
| Natalia Ospina | Cerrar la prueba 10 | 2026-10-09 | 7 | `30-reuniones/2026-09-18-comite-semanal.md`; el 10-02 dijo que ya lo entregó, «no se presentó acta» |
| Carlos Peña | Actualizar la matriz 22 | 2026-10-15 | 1 | `30-reuniones/2026-10-09-comite-semanal.md` |
| Elena Duarte | Confirmar la fecha 23 | 2026-10-15 | 1 | `30-reuniones/2026-10-09-comite-semanal.md` |

**Abiertos y todavía en fecha** (algunos reprogramados menos de tres veces):

| Quién | Qué | Para cuándo | Veces movido |
|---|---|---|---|
| Laura Vélez | Aprobar el diseño 5 | 2026-10-19 | 2 |
| Andrés Lozano | Actualizar la matriz 6 | 2026-11-13 | 2 |
| Óscar Ramírez | Confirmar la fecha 7 | 2026-10-25 | 2 — el 10-09 dijo que ya lo entregó, «no se presentó acta» |
| Óscar Ramírez | Revisar el anexo 3 | 2026-10-21 | 1 (la fecha original, 09-10, se quedó vencida tres reuniones seguidas) |
| Óscar Ramírez | Entregar el punto 16 | 2026-10-29 | 1 |
| Elena Duarte | Enviar el documento 17 | 2026-11-08 | 1 |
| Andrés Lozano | Entregar el punto 24 | 2026-10-18 | 0 |
| Diana Molina | Cerrar la prueba 18 | 2026-10-27 | 0 |
| Elena Duarte | Revisar el anexo 19 | 2026-10-27 | 0 |
| Paula Céspedes | Aprobar el diseño 21 | 2026-10-24 | 0 |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-26 | 0 — nuevo en `2026-10-16-notas-reunion.txt` |

**Cumplidos, con acta:** Entregar el punto 8 (Ricardo Salas, acta del 2026-09-25) · Validar el ambiente 4 (Mauricio Pérez, acta del 2026-10-02) · Aprobar el diseño 13 (Natalia Ospina, acta del 2026-10-09) · Confirmar la fecha 15 (Mauricio Pérez, acta del 2026-10-09).

### Sin fecha
Estos no pueden estar vencidos, y por eso son los que desaparecen de los informes:
- **Carlos Peña — Validar el ambiente 12.** «Por definir» desde el 2026-09-18; el 10-02 dijo que ya lo entregó, «no se presentó acta».
- **Javier Hoyos — Validar el ambiente 20.** «Por definir» desde el 2026-10-02.
- **Laura Vélez — Mandar el ajuste del presupuesto.** «La otra semana» (`2026-10-16-notas-reunion.txt`); nadie dijo una fecha, no calculé una.

### Contra lo que declaras
El informe del 2026-10-12 declara **verde** y **71 %** de avance. Contra eso, el script levantó:
- **Avance contra plan:** el cronograma sostiene entre 25 y 50 %, con 1 de 4 hitos cumplidos (Diseño de la experiencia aprobado, acta del 2026-10-04). Diferencia de −21,0 puntos: el 71 % declarado va por delante de lo que sustenta el plan.
- **Verde con señales sin explicar:** compromisos vencidos, compromisos reprogramados y el avance contra plan. En total son 13 señales.
- **Presupuesto** (informe del 2026-10-12, es declaración tuya): ejecutado 49,1 % y comprometido 30,7 % del aprobado; la proyección queda −4,4 % sobre el aprobado.

### Un riesgo que se dijo y no está anotado
En las notas del 2026-10-16: «el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo». Lo dejé en la ficha con su cita. El informe del 2026-10-12 lista otros dos riesgos (jefes de tienda; fecha de la última entrega del proveedor), distintos de este.

### Qué le falta a tu carpeta
- **Minutas anteriores al 2026-09-04.** Entre el acta de constitución (2026-04-17) y el primer comité no hay nada, y ahí pudo empezar cualquier compromiso.
- **Cronograma vigente.** Solo existe el v1 del 2026-04-17, sin reprogramaciones, mientras el informe habla de una validación que se extendió una semana.
- **Actas de recibo** de los hitos «Ambiente de pruebas certificado», «Integración con el ERP» y «Piloto en tiendas», y de los compromisos que dicen estar entregados (Óscar Ramírez, 7; Natalia Ospina, 10; Beatriz Cuéllar, 11; Carlos Peña, 12). Sin ellas un compromiso cumplido se ve igual que uno incumplido.
- **Un acta de constitución con contenido.** El alcance es «Componente 1, 2, 3», no hay dependencias declaradas ni autoridad del gerente, y el campo producto es «No aplica».
- **La reunión del 2026-10-16 vino como notas informales,** sin la tabla de compromisos abiertos de los comités anteriores: de los que ya venían abiertos, las notas solo tocan uno.

**Cuándo vuelvo:** tu próximo comité es el 2026-10-30 (así lo dicen las notas); la cadencia queda semanal, y vuelvo el 2026-10-29, un día antes.
