## Compromisos — Migración del ERP (PRY-209) · al 2026-10-16

*Sesión sin interfaz: términos ya vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-16), no se pidieron de nuevo. Cifras de `portafolio.py compute`.*

### Se viene reprogramando

> **Natalia Ospina** · Enviar el documento 1
> Prometido para el 2026-11-25, y antes para el 11-11, el 11-03, el 10-19, el 10-08, el 09-29, y la primera promesa fue el 2026-09-20.
> **Seis reprogramaciones, 66 días sobre la promesa original. No es un problema de seguimiento: es un bloqueo que nadie ha nombrado.**
> Fuentes: comités del 09-04 al 10-09 y notas del 2026-10-16 (`2026-10-16-notas-reunion.txt`).

> **Mauricio Pérez** · Cerrar la prueba 2
> Prometido para el 2026-11-28, y antes para el 11-13, el 10-29, el 10-19, el 10-08; la primera promesa fue el 2026-09-30.
> **Cinco reprogramaciones, 59 días sobre la original.** Umbral configurado: 3.
> Fuentes: comités del 09-04 al 10-09.

### Vencidos sin evidencia
| Quién | Qué | Prometido para | Hace |
|---|---|---|---|
| Beatriz Cuéllar | Revisar el anexo 11 | 2026-09-24 | 22 días |
| Javier Hoyos | Actualizar la matriz 14 | 2026-09-30 | 16 días |
| Felipe Arango | Enviar el documento 9 | 2026-10-07 | 9 días |
| Natalia Ospina | Cerrar la prueba 10 | 2026-10-09 | 7 días |
| Carlos Peña | Actualizar la matriz 22 | 2026-10-15 | 1 día |
| Elena Duarte | Confirmar la fecha 23 | 2026-10-15 | 1 día |

**Dijeron que ya lo entregaron; no hay documento en el expediente que lo respalde, así que siguen abiertos:**
- Beatriz Cuéllar (anexo 11), lo dijo el 2026-09-25.
- Natalia Ospina (prueba 10), lo dijo el 2026-10-02.
- Carlos Peña (ambiente 12, sin fecha), lo dijo el 2026-10-02.
- Óscar Ramírez (fecha 7, para el 2026-10-25), lo dijo el 2026-10-09.

Los cuatro salieron de la tabla de abiertos del comité sin acta de recibo.

### Vencen esta semana (hasta el 2026-10-23)
| Quién | Qué | Para cuándo |
|---|---|---|
| Andrés Lozano | Entregar el punto 24 | 2026-10-18 |
| Laura Vélez | Aprobar el diseño 5 (ya movido dos veces: 09-18 → 10-06 → 10-19) | 2026-10-19 |
| Óscar Ramírez | Revisar el anexo 3 (original 2026-09-10, una reprogramación) | 2026-10-21 |

### Sin fecha
| Quién | Qué | Dicho el |
|---|---|---|
| Carlos Peña | Validar el ambiente 12 | 2026-09-18 |
| Javier Hoyos | Validar el ambiente 20 | 2026-10-02 |
| Laura Vélez | Mandar el ajuste del presupuesto («la otra semana», que no es una fecha) | 2026-10-16 |

Son 3. No pueden estar vencidos, y por eso no salen en ningún informe de vencidos.

### Cerrados desde la última revisión
Los cierres con documento en el expediente son cuatro. No hay constancia de la fecha de la revisión anterior, así que van todos los cerrados:
- Ricardo Salas · Entregar el punto 8 → `20-seguimiento/2026-09-25-acta-recibo-8.md`
- Mauricio Pérez · Validar el ambiente 4 → `20-seguimiento/2026-10-02-acta-recibo-4.md`
- Natalia Ospina · Aprobar el diseño 13 → `20-seguimiento/2026-10-09-acta-recibo-13.md`
- Mauricio Pérez · Confirmar la fecha 15 → `20-seguimiento/2026-10-09-acta-recibo-15.md`

### Contexto
El informe de avance del 2026-10-12 declara el proyecto en **verde, 71 %**. El cálculo marca `declared_vs_evidence`: 6 vencidos, 2 compromisos reprogramados sobre el umbral y un avance que el plan sustenta en 25–50 % (1 de 4 hitos cumplido) no están explicados en ese informe.

### Después
- Lo de Natalia Ospina (6 veces) y Mauricio Pérez (5 veces) pasa el umbral de 3 reprogramaciones. Puedo formularlo como decisión para el comité (qué se pide, qué pasa si no se decide, quién tiene la facultad) con `/pm-escalate`. Respuesta sugerida en esta sesión sin interfaz: lo ofrezco y no lo ejecuto.
- Si el estado verde ya no se sostiene, `/pm-publish` deja la ficha a la vista de la PMO.

Este comando no le escribe a nadie ni juzga por qué no se cumplió. No cambié la ficha: ya estaba al día con las notas del 2026-10-16.
