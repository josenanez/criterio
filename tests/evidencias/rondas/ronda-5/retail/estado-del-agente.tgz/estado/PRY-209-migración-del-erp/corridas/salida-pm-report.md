# Migración del ERP (PRY-209) — semana del 2026-10-09 al 2026-10-16

**Declara el gerente:** SIN DECLARACIÓN. La sesión corrió sin interfaz y nadie declaró estado ni avance; la línea queda en blanco a propósito y el sistema no propone una.
**Lo que dice el último documento (no es declaración de hoy):** el informe de avance del 2026-10-12 (hace 4 días) dice verde · 71 %. Se cita como evidencia, no se adopta como declaración.
**Sustento documental:** contradicho, si ese verde se mantuviera. El cálculo marca `declared_vs_evidence`: un verde con tres señales que no explica (compromisos vencidos, compromisos reprogramados y avance contra el plan).
**Lo que el semáforo no explica:** `commitment_overdue` (6), `commitment_rescheduled` (2), `progress_vs_plan`.

## Qué cambió esta semana
No hay corrida anterior contra la cual comparar: este es el primer snapshot del proyecto (2026-10-16) y el diff devolvió 0 cambios. Por eso no se puede decir qué estaba y qué está. Lo que sí se ve en el registro:

| Qué | Estaba | Está |
|---|---|---|
| Compromiso «Enviar el documento 1» (Natalia Ospina) | reprogramado 5 veces, vencía 2026-11-11 | reprogramado 6 veces, vence 2026-11-25 (movido el 2026-10-16) |
| Compromisos sin fecha | 2 | 3: entró «Mandar el ajuste del presupuesto» (Laura Vélez, «la otra semana») |
| Riesgo nuevo sin registrar | — | el proveedor podría no llegar con el equipo completo (se dijo en la reunión del 16, nadie lo registró; sin dueño) |
| Compromiso nuevo | — | «Revisión con el proveedor» (Óscar Ramírez, 2026-10-26) |
| Cumplidos con acta esta semana | — | «Aprobar el diseño 13» y «Confirmar la fecha 15» (actas del 2026-10-09) |

## Lo que sigue igual y sigue mal
| Qué | Desde | Días así |
|---|---|---|
| Revisar el anexo 11 (Beatriz Cuéllar) | vencía 2026-09-24 | 22 |
| Actualizar la matriz 14 (Javier Hoyos) | vencía 2026-09-30 | 16 |
| Enviar el documento 9 (Felipe Arango) | vencía 2026-10-07 | 9 |
| Cerrar la prueba 10 (Natalia Ospina) | vencía 2026-10-09 | 7 |
| Actualizar la matriz 22 (Carlos Peña) | vencía 2026-10-15 | 1 |
| Confirmar la fecha 23 (Elena Duarte) | vencía 2026-10-15 | 1 |
| Validar el ambiente 12 (Carlos Peña) | dicho 2026-09-18, nunca tuvo fecha | 28 |
| Validar el ambiente 20 (Javier Hoyos) | dicho 2026-10-02, nunca tuvo fecha | 14 |

Los «días así» salen de la fecha de vencimiento, o de la fecha en que se dijo si nunca hubo vencimiento. Como no hay corrida anterior, no se puede afirmar cuántos de estos ya estaban en el informe de la semana pasada.

## Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2027-12-02 | 2027-12-02 | 0 días contra ambas |
| Presupuesto | COP 2.400.000.000 | COP 2.400.000.000 | proyección COP 2.294.519.534 (−4,4 %) |

Replanificaciones: 0. Solo existe la versión 1 de la línea base (acta de constitución, 2026-04-17). Una desviación de cero con cronograma sin tocar desde abril no es prueba de que todo va en fecha: es que nadie lo ha movido. Un caso concreto: el hito «Diseño de la experiencia aprobado» tenía fecha 2026-09-03, y su acta de recibo es del 2026-10-04, 31 días después, sin replanificación registrada.

Avance: el informe del 12-oct dice 71 %, pero 1 de 4 hitos está cumplido y el plan sostiene entre 25 y 50 %. Diferencia de 21 puntos por encima de lo que respalda el plan. El avance financiero ejecutado es 49,1 %.

### Hitos de las próximas cuatro semanas (hasta 2026-11-13)
| Hito | Base | Vigente | Evidencia |
|---|---|---|---|
| Ninguno | — | — | El siguiente es «Ambiente de pruebas certificado», 2027-01-11, sin evidencia |

## Las cifras (COP)
| Aprobado | Comprometido | Ejecutado | Proyectado | Disponible real |
|---|---|---|---|---|
| 2.400.000.000 | 737.951.290 (30,7 %) | 1.177.731.702 (49,1 %) | 2.294.519.534 | 1.662.048.710 |

Disponible real = aprobado − comprometido. Hay una incoherencia que revisar: lo ejecutado (1.177,7 M) es mayor que lo comprometido (738,0 M), y no debería serlo. Las tres cifras salen del informe de avance del 12-oct, que es declaración y no evidencia. Hasta que se aclare, el disponible real no es confiable.

## Abierto
**Reprogramados:**
- Natalia Ospina, «Enviar el documento 1»: 6 veces. Original 2026-09-20, hoy 2026-11-25.
- Mauricio Pérez, «Cerrar la prueba 2»: 5 veces. Original 2026-09-30, hoy 2026-11-28.
- Ambos superan el umbral de 3 reprogramaciones.

**Vencidos sin evidencia:** los seis de la tabla anterior. Además, Beatriz Cuéllar, Carlos Peña, Natalia Ospina y Óscar Ramírez dijeron en reunión que ya entregaron, y no hay acta. Sin acta no se da por cumplido.

**RAID sin movimiento:** 3 riesgos y 2 incidencias, todos con dueño «no_identificado». Entre ellos está el hallazgo de seguridad en los medios de pago. Sin dueño ni fecha, el sistema no puede medir los días de inmovilidad.

**Proveedor:** el registro no tiene ninguno cargado (`vendors` sin dato). El riesgo del equipo incompleto del proveedor está sin registrar.

## Lo que necesito de alguien
- **Liliana Torres:** declarar estado y avance con la evidencia de arriba a la vista. Sin esa declaración este informe sale incompleto.
- **Natalia Ospina y Mauricio Pérez:** decidir si «Enviar el documento 1» y «Cerrar la prueba 2» se cierran, se parten o se escalan. Con 6 y 5 reprogramaciones, otra fecha nueva no resuelve nada.
- **Felipe Arango, Beatriz Cuéllar, Javier Hoyos, Carlos Peña, Elena Duarte:** entregar el compromiso vencido o reprogramarlo con fecha.
- **Laura Vélez:** dar fecha al ajuste del presupuesto.
- **Dueño para el hallazgo de seguridad en pagos y para los riesgos del RAID:** quién lo asume. Si excede la autoridad de la gerente, es material de comité (próximo: 2026-10-30).
- **Quien lleve las finanzas:** explicar por qué lo ejecutado supera lo comprometido.

## Lo que no se sabe
**Sin dato:** evidencia de los hitos 2, 3 y 4 (pendientes, sin evidencia, normal a esta fecha); autoridad, producto, fase y proveedores de la ficha; el estado que declara el gerente hoy; la corrida anterior para comparar.
**Silencio:** último documento hace 0 días (notas de reunión del 2026-10-16) · última reunión hace 0 días. No hay silencio, pero sí un hueco: el flujo documental son actas de reunión y un informe de avance (declaración). No hay evidencia independiente de avance más allá de 4 actas de recibo (hito 1 y tres compromisos).

---
Ficha: `estado/PRY-209-migración-del-erp/records/PRY-209.json`, actualizada el 2026-10-16 · corte al 2026-10-16 · campos sin dato: 3 de evidencia de hito y 4 de la ficha (autoridad, producto, fase, proveedores) · términos v1.1 aceptados por José Francisco Ñáñez el 2026-10-16: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.11

Este informe es un borrador de trabajo; la verificación contra los documentos citados es de quien lo use. No declara el estado ni se envía a nadie.
