## Para decisión — Migración del ERP (PRY-209) · 2026-10-16

*Sesión sin interfaz: términos ya vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-16), no se pidieron de nuevo. Sin tema en la invocación: se toma lo ya marcado como escalable (`salida-pm-commitments.md`, `salida-pm-report.md`).*

## Primero: lo que escala antes que todo lo demás

**El acta no declara la autoridad de la gerente.** `identity.authority` está sin dato en la ficha, y el acta del 2026-04-17 no tiene sección de autoridad. Sin eso no puedo decir quién tiene la facultad en ninguno de los puntos de abajo, y la gerente no sabe qué puede decidir sola.

### ¿Se declara por escrito qué puede decidir Liliana Torres sin pasar por comité —fechas de compromisos internos, reasignación de dolientes, movimientos de presupuesto y hasta qué monto— y qué sube al Comité de Arquitectura?

**Quién decide:** Gustavo Neira (patrocinador) / Comité de Arquitectura, que aprobó el acta · **Si no se decide hoy:** nada vence en una fecha que consten los documentos; la consecuencia es que cada punto de abajo se devuelve con un «eso lo decide usted» o se decide sin valer. Próximo comité: 2026-10-30.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Se agrega un anexo al acta con los umbrales de autoridad | Sin cambio | No se puede calcular: depende de cuándo se firme | Sin cifra en los documentos |
| B. Se deja sin declarar | Sin cambio | — | El costo es el que se paga hoy: puntos devueltos |

**Recomiendo:** A. Es la única condición para que los demás puntos tengan a quién dirigirse.

---

## Punto 1 — «Enviar el documento 1» (Natalia Ospina): 6 reprogramaciones

### ¿Se cierra, se parte o se asigna un tercero para destrabar «Enviar el documento 1», o se acepta la nueva fecha del 2026-11-25?

**Quién decide:** no se puede decir. Falta la autoridad declarada (ver arriba). · **Si no se decide hoy:** no hay fecha de vencimiento externa en los documentos. Lo que sí consta: ya se movió en cada comité del 09-04 al 10-16; en el próximo (2026-10-30) será la séptima vez si nadie lo ataca.

Historia: original 2026-09-20 → 09-29 → 10-08 → 10-19 → 11-03 → 11-11 → **11-25**. 66 días sobre la promesa original; umbral configurado: 3.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aceptar el 2026-11-25 | Igual | +66 días sobre la promesa original (ya incurridos) | Sin dato |
| B. Partir el documento y entregar lo que exista | Menor al declarado | **Sin dato** | Sin dato |
| C. Nombrar quién la bloquea y llamarle antes del comité | Igual | **Sin dato** | Sin dato |

**No puedo llenar el costo de las opciones.** Ningún documento dice qué es el «documento 1», quién lo espera, ni qué lo bloquea; el nombre del compromiso es genérico. Una opción sin costo declarado se elige por conveniencia, así que no la pongo como lista: **antes de llevarlo hay que obtener esos tres datos de Natalia Ospina.**

**Recomiendo:** C. La llamada a Natalia Ospina cuesta un día y probablemente resuelve el punto antes del comité; si no revela un bloqueo fuera del proyecto, **esto no escala** y es de la gerente. Es la recomendación que sale de la historia (seis fechas nuevas sin que cambie nada visible), no de un dato sobre el bloqueo, que no tengo.

## Punto 2 — «Cerrar la prueba 2» (Mauricio Pérez): 5 reprogramaciones

### ¿Se cierra con lo que haya, se parte, o se acepta el 2026-11-28?

**Quién decide:** no se puede decir (misma razón). · **Si no se decide hoy:** sin fecha externa en los documentos.

Historia: original 2026-09-30 → 10-08 → 10-19 → 10-29 → 11-13 → **11-28**. 59 días sobre la original.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aceptar el 2026-11-28 | Igual | +59 días ya incurridos | Sin dato |
| B. Cerrar parcial / partir | Sin dato | Sin dato | Sin dato |

Mismo vacío que el punto 1: qué es «la prueba 2» y qué la frena no está en ningún documento. **Recomiendo** la misma llamada previa a Mauricio Pérez; hasta tenerla, el punto no está listo para comité.

---

## Lo que no escala (y por qué)

- **Los seis vencidos sin evidencia** (anexo 11, matriz 14, documento 9, prueba 10, matriz 22, fecha 23): se destraban con una llamada a cada doliente. Es de la gerente. Cuatro dijeron «ya lo entregué» sin acta: pedir el acta.
- **Los tres compromisos sin fecha** (ambiente 12, ambiente 20, ajuste del presupuesto de Laura Vélez, «la otra semana»): ponerles fecha es de la gerente.

## Lo que sí podría escalar y no está listo

- **Hallazgo de seguridad en medios de pago**, sin dueño (`no_identificado`) en el informe del 2026-10-12. Si el dueño debe estar fuera del proyecto o el arreglo excede el presupuesto, es de comité. Hoy no sé ni quién lo lleva ni cuánto cuesta: falta ese dato para formularlo como decisión.
- **Proveedor que podría no llegar con equipo completo** (dicho el 2026-10-16, sin registrar) y su fecha de última entrega sin confirmar. No hay proveedor cargado en la ficha. Primero va registrado y con dueño.
- **Ejecutado (1.177,7 M) mayor que comprometido (738,0 M)** en el informe del 12-oct: incoherencia de finanzas, pregunta para quien las lleve, no decisión del comité.

---

### A quién alcanza
| Proyecto | Gerente | ¿Sostiene su fecha? | Dependencia confirmada |
|---|---|---|---|
| Ninguno cargado | — | — | El acta declara «Ninguna declarada». Eso no prueba que no existan: no se confirmó con nadie. |

### Mis hitos por los que pasa
Cálculo con `portafolio.py impact --days 66`. **Es hipotético:** supone que el atraso del punto 1 (66 días) mueve el proyecto entero, y ningún documento dice que lo haga. Muestra por dónde pasaría; no cuántos días se mueve cada hito, que necesita holgura por actividad y la ficha no la tiene.

| Hito | Fecha vigente | En cuántos días |
|---|---|---|
| Ambiente de pruebas certificado | 2027-01-11 | 87 |
| Integración con el ERP | 2027-05-21 | 217 |
| Piloto en tiendas | 2027-09-28 | 347 |

Si los 66 días se propagaran sin holgura, el cierre pasaría del 2027-12-02 al 2028-02-06.

### De dónde sale esto
- Autoridad no declarada: `00-gobierno/2026-04-17-acta-constitucion.md` (sin sección); `fields_not_found` en `records/PRY-209.json`.
- Reprogramaciones: comités del 09-04, 09-11, 09-18, 09-25, 10-02, 10-09 y `2026-10-16-notas-reunion.txt`.
- Hallazgo de seguridad, riesgos y cifras: `20-seguimiento/2026-10-12-informe-avance.pdf` (declaración, no evidencia).
- Riesgo del proveedor: `2026-10-16-notas-reunion.txt`, línea 7.

Este paquete es un borrador de trabajo; la verificación contra los documentos citados es de quien lo use. No escala solo ni le escribe a nadie: llevarlo al comité (2026-10-30) y llamar a Natalia Ospina y Mauricio Pérez es de la gerente.
