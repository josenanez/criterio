# Plan — Migración del ERP (PRY-209) · borrador del 2026-10-16
**Desde:** acta de constitución del 2026-04-17 (`00-gobierno/2026-04-17-acta-constitucion.md`) · **Criterio de éxito:** «Migración del ERP en producción y medido»; el acta no dice medido contra qué.

**Una advertencia antes de empezar:** el proyecto no está en arranque. Inició el 2026-04-27 y el informe del 2026-10-12 declara 71 % de avance. Este borrador es una descomposición retroactiva sobre un acta que no descompuso nada; no sustituye ni reemplaza la línea base v1 (`10-plan/2026-04-17-cronograma-v1.csv`) y no la modifica.

## Lo que le falta al acta
| Qué | Consecuencia de planificar sin eso |
|---|---|
| **Alcance sin contenido.** Dice «Componente 1, 2, 3» y no los describe. | No hay entregables del acta que descomponer. Cualquier WBS por debajo de los tres componentes sería inventada. Es el vacío más caro. |
| **Criterio de éxito sin métrica.** «En producción y medido» no dice qué se mide, con qué umbral ni quién lo mide. | No se puede decidir cuándo el último nodo está aceptado. «Medido» queda abierto. |
| **Objetivo del negocio tautológico.** «Entregar migración del erp para Comercio electrónico». | No sirve para decidir qué entra y qué no en un cambio de alcance. |
| **Fuera de alcance genérico.** «Lo que otro proyecto cubre», sin decir qué proyecto. | Fronteras con otros proyectos sin dueño; riesgo de trabajo duplicado o de huecos. |
| **Autoridad del gerente no declarada.** El acta nombra patrocinador (Gustavo Neira), gerente (Liliana Torres) y comité (Comité de Arquitectura), pero no dice qué decide cada uno. | No se sabe qué puede decidir Liliana al planificar y qué debe subir. |
| **Dependencias: «Ninguna declarada».** | Un reemplazo de ERP sin dependencias es poco creíble. Puede ser un hueco, no una ausencia. El plan no las supone. |
| **Sin proveedor ni contrato en el acta.** | La ficha no encuentra proveedores. Los riesgos mencionan uno (informe 2026-10-12; notas 2026-10-16), pero ningún documento lo identifica. |

El patrocinador sí está declarado. Se sigue adelante marcando cada hueco; no se rellenó ninguno.

## WBS
Los nodos salen de los cuatro hitos del cronograma v1 y del criterio de éxito. Los componentes 1 a 3 no se descomponen porque el acta no los describe.

| # | Entregable | Quién lo acepta | De dónde sale | Duración |
|---|---|---|---|---|
| 1 | Diseño de la experiencia aprobado | Sin definir | del acta de recibo `20-seguimiento/2026-10-04-acta-recibo-diseño-de-la-experiencia-aprobado.pdf` y del cronograma v1. Hito cerrado. | vacía |
| 2 | Ambiente de pruebas certificado | Sin definir | del cronograma v1 (en curso). Quién certifica y contra qué criterio: sin definir. | vacía |
| 3 | Integración con el ERP | Sin definir | del cronograma v1 (en curso) | vacía |
| 4 | Piloto en tiendas | Sin definir | del cronograma v1 (en curso). Que participan jefes de tienda sale del informe 2026-10-12. | vacía |
| 5 | Migración del ERP en producción y medida | Sin definir (el patrocinador aprobó el acta; el acta no dice que acepte el entregable) | criterio de éxito del acta. No hay hito en el cronograma v1 después del piloto. | vacía |
| 6 | Componentes 1, 2 y 3 | Sin definir | **Sin definir.** El acta los nombra sin contenido. Ni se asocian a los hitos 1-4 ni se descomponen. | vacía |
| 7 | Corrección del hallazgo de seguridad en medios de pago | Sin definir | **Supuesto:** que sea un entregable del proyecto. Aparece como incidencia en el informe 2026-10-12 y no tiene hito ni nodo en el cronograma. | vacía |

Observación sobre el 1: el cronograma v1 lo fecha el 2026-09-03 y su acta de recibo es del 2026-10-04. La columna de fecha vigente del cronograma sigue igual a la de línea base. El borrador lo registra y no lo interpreta.

## Orden
Sin fechas. Lo que el material sostiene:
- 1 (cerrado) precede a lo demás según el orden del cronograma v1. **Supuesto:** que ese orden sea dependencia y no solo secuencia de fechas.
- 2 → 3 → 4 → 5, también por el orden del cronograma v1. **Supuesto:** que el piloto necesite la integración y la integración el ambiente certificado. El acta no declara ninguna dependencia.
- 6 y 7: **sin definir** dónde encajan.

## Supuestos sobre los que está construido
| Supuesto | Qué pasa si resulta falso |
|---|---|
| El orden del cronograma v1 refleja dependencias reales. | Se puede hacer en paralelo lo que aquí está en serie, o al revés, y el camino crítico cambia. |
| Los cuatro hitos del cronograma v1 son los entregables del proyecto. | Hay entregables que no están en ningún documento, y el avance de 71 % no se puede contrastar. |
| El hallazgo de seguridad en pagos es trabajo del proyecto. | Si es de otra área, hay una dependencia externa no registrada. |
| «Medido» (criterio de éxito) es un entregable propio y no una actividad posterior al cierre. | El cierre de 2027-12-02 no incluye la medición. |

Cuando el plan se apruebe, estos pasan al RAID con doliente.

## Sin definir
| Qué | Quién lo define |
|---|---|
| Contenido de los componentes 1, 2 y 3 | Patrocinador (Gustavo Neira), con el gerente |
| Quién acepta cada entregable y con qué evidencia | Patrocinador y Comité de Arquitectura |
| Qué se mide, con qué umbral y quién lo mide | Patrocinador |
| Hitos entre el piloto (2027-09-28) y el cierre (2027-12-02) | Gerente de proyecto, para aprobación del comité |
| Dependencias del proyecto | Gerente de proyecto |
| Proveedor, contrato y entregas | Sin definir en los documentos |
| Qué decide el gerente y qué se sube | Patrocinador |
| Qué proyecto cubre lo «fuera de alcance» | Patrocinador |

## Proyectos análogos
La configuración de PRY-209 no apunta a una carpeta de fichas de la PMO. No hay proyectos análogos a la vista, y es la respuesta correcta: no se trae referencia ni se estima por analogía.

## Preguntas para el equipo
1. ¿Cuánto toma obtener el ambiente de pruebas certificado desde hoy, y quién lo certifica?
2. ¿Cuánto toma la integración con el ERP, y qué necesita antes?
3. ¿Cuánto toma el piloto en tiendas, cuántas tiendas, y cuándo las tiene disponibles?
4. ¿Cuánto toma pasar de piloto a producción, y qué se hace entre 2027-09-28 y 2027-12-02?
5. ¿Cuánto toma medir, y qué se mide?
6. ¿Cuánto toma corregir el hallazgo de seguridad en medios de pago, y quién lo hace?
7. ¿Qué son los componentes 1, 2 y 3, y cuánto toma cada uno?
8. ¿Quién acepta cada uno de los cinco entregables?
9. ¿Qué dependencias existen con otros proyectos o áreas?

## Para comprometer una fecha falta
- La disponibilidad real del equipo: no está en ningún documento.
- La fecha del proveedor: las notas del 2026-10-16 y el informe del 2026-10-12 dicen que no la ha confirmado y que podría no llegar con el equipo completo.
- La ventana de tiendas para el piloto: el informe del 2026-10-12 registra la disponibilidad de los jefes de tienda como riesgo sin doliente.
- Las respuestas a las preguntas anteriores.
- Una aprobación de este plan por quien tenga la autoridad. Mientras tanto, la línea base original sigue siendo la v1.
