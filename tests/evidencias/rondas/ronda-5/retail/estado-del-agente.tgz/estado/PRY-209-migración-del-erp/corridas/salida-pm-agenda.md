## Reunión de seguimiento — Migración del ERP (PRY-209) · 2026-10-30
11 puntos · 41 minutos · 12 personas citadas en la agenda (las 12 que asistieron el 10-16); las que no pueden faltar son Natalia Ospina, Mauricio Pérez y Liliana Torres

*Sesión sin interfaz: términos ya vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-16), no se pidieron de nuevo. Tomé la respuesta sugerida en cada duda:*
- *Fecha 2026-10-30: es `committee_next` de la configuración y coincide con «en dos semanas» de las notas del 10-16. Esas notas contradicen la cadencia semanal configurada; confírmalo.*
- *Duración: la configuración no trae una. Armé la agenda para que quepa en 45 minutos.*
- *Cálculo al 2026-10-16. Es la primera corrida (no hay estado anterior con qué comparar), así que "lo que cambió" sale del historial de compromisos. Vuelve a correr `/pm-agenda` el 10-29 y los vencimientos se actualizan.*

### Lo que no se destraba solo

> **[1] Nombrar qué bloquea «Enviar el documento 1» y quién lo destraba** · 8 min · **Natalia Ospina** (con Liliana Torres)
> Prometido para el 2026-11-25, y antes para el 11-11, y antes para el 11-03, y antes para el 10-19, y antes para el 10-08, y antes para el 09-29. La primera promesa fue el 2026-09-20. Seis reprogramaciones, 66 días sobre la original.
> Fuente: comités del 09-04 al 10-09 y notas del 2026-10-16 (`2026-10-16-notas-reunion.txt`: «no alcanzó»). En ninguna acta aparece el motivo.
> **Si no se resuelve hoy:** la séptima fecha llega sola. Ya no es una fecha, es un bloqueo que nadie ha nombrado. Si lo que se necesita excede la autoridad de Liliana, sale de la reunión como decisión de comité (`/pm-escalate`).

> **[2] Qué impide cerrar «la prueba 2» y si el 2026-11-28 es una fecha o un deseo** · 8 min · **Mauricio Pérez**
> Prometido para el 2026-11-28, y antes para el 11-13, y antes para el 10-29, y antes para el 10-19, y antes para el 10-08. La primera promesa fue el 2026-09-30. Cinco reprogramaciones, 59 días sobre la original. Umbral configurado: 3.
> Fuente: comités del 09-04 al 10-09.
> **Si no se resuelve hoy:** la prueba 2 es la antesala del hito «Ambiente de pruebas certificado» (2027-01-11, pendiente y sin evidencia). Dicho como contexto; el plan no dice que dependa de ella.

### Vencido sin evidencia
Más viejo primero. Los cinco dolientes estuvieron en la sala el 10-16.

| Quién | Qué | Desde | Qué se necesita hoy | Min |
|---|---|---|---|---|
| Javier Hoyos | Actualizar la matriz 14 | 2026-09-30 (16 días al 10-16) | Entrega o nueva fecha con motivo | 2 |
| Felipe Arango | Enviar el documento 9 | 2026-10-07 (9 días) | Ídem | 2 |
| Natalia Ospina | Cerrar la prueba 10 | 2026-10-09 (7 días). Dijo el 10-02 que ya lo entregó; no hay acta | El acta de recibo, o reabrirlo | 2 |
| Carlos Peña | Actualizar la matriz 22 | 2026-10-15 (1 día). Además: «Validar el ambiente 12» sin fecha desde el 09-18, y dijo el 10-02 que ya lo entregó, sin acta | Entrega de la matriz; acta del ambiente 12 o fecha | 2 |
| Elena Duarte | Confirmar la fecha 23 | 2026-10-15 (1 día) | Entrega o nueva fecha | 1 |

Fuentes: comités del 09-18, 09-25 y 10-09.

### Se decide hoy o se atrasa
| Qué | Quién decide | Si no se decide | Min |
|---|---|---|---|
| Fecha para «Mandar el ajuste del presupuesto». Dijo «la otra semana» el 10-16 (notas); eso no es una fecha, no puede vencer y no sale en ningún informe de vencidos | Laura Vélez | Sigue invisible para el seguimiento: no vence nunca y no sale en ningún informe de vencidos | 2 |
| Fecha para «Validar el ambiente 20» (Javier Hoyos, sin fecha desde el 10-02) | Javier Hoyos | Es el tercer compromiso sin fecha del proyecto | 1 |
| Dueño del riesgo «el proveedor podría no llegar con el equipo completo para la siguiente fase». Se dijo el 10-16 y nadie lo anotó; quedó con `owner: no_identificado` (notas 10-16). Existe un riesgo cercano pero distinto en el informe del 10-12: «el proveedor no ha confirmado la fecha de la última entrega», también sin dueño | Liliana Torres | Dos riesgos del proveedor sin dueño; el único movimiento con el proveedor es la «Revisión con el proveedor» del 10-26 | 3 |
| Dueño del hallazgo de seguridad en los medios de pago (informe del 10-12, incidencia, `owner: no_identificado`). Ningún comité del 09-04 al 10-09 lo menciona | Liliana Torres | Una incidencia de seguridad sin dueño ni fecha en el expediente | 4 |

### Vence antes de la próxima
Si hay tiempo sobrante, un minuto cada uno; si no, van en el anexo. En conjunto, 5 minutos.

| Quién | Qué | Para cuándo |
|---|---|---|
| Andrés Lozano | Entregar el punto 24 | 2026-10-18 |
| Laura Vélez | Aprobar el diseño 5 (ya movido dos veces: 09-18 → 10-06 → 10-19) | 2026-10-19 |
| Óscar Ramírez | Revisar el anexo 3 (original 09-10, una reprogramación) | 2026-10-21 |
| Paula Céspedes | Aprobar el diseño 21 | 2026-10-24 |
| Óscar Ramírez | Confirmar la fecha 7 (dijo el 10-09 que ya lo entregó; sin acta; sigue abierto) | 2026-10-25 |
| Óscar Ramírez | Revisión con el proveedor (las notas no dicen qué se revisa; confirmarlo con él antes) | 2026-10-26 |
| Diana Molina | Cerrar la prueba 18 | 2026-10-27 |
| Elena Duarte | Revisar el anexo 19 | 2026-10-27 |
| Óscar Ramírez | Entregar el punto 16 (original 10-21, una reprogramación) | 2026-10-29 |

Óscar Ramírez tiene cuatro vencimientos entre el 10-21 y el 10-29. Ese es el único punto preventivo que sale de aquí: si va a haber un atraso, aparece en su semana.

### No es de esta reunión
| Qué | Por qué | Dónde va |
|---|---|---|
| Beatriz Cuéllar · «Revisar el anexo 11», vencido 22 días (el más viejo) | No estuvo en los comités del 10-02, 10-09 ni en la reunión del 10-16. Dijo el 09-25 que ya lo entregó; no hay acta | Que Liliana la contacte antes: acta o nueva fecha. Si no hay respuesta, `/pm-commitments` para formularlo |
| Estado «verde, 71 %» del informe del 10-12 | El plan sustenta 25–50 % (1 de 4 hitos cumplido). Hay 6 vencidos y 2 reprogramados sobre el umbral que el informe no explica. La declaración es de Liliana, no un tema para el comité | `/pm-report` antes del comité, para que ella declare el estado con eso a la vista |
| Que el bloqueo del punto 1 o 2 exceda la autoridad de Liliana | La ficha no trae la autoridad del proyecto (`identity.authority`: no encontrado), así que no puedo decir qué le toca decidir a ella | `/pm-escalate` si la reunión confirma que no es suyo |

### Anexo — sin cambios desde el 2026-10-16
No se repasa en la reunión.
- Andrés Lozano · Actualizar la matriz 6: 2026-11-13 (reprogramada dos veces: 09-29 → 10-23 → 11-13).
- Elena Duarte · Enviar el documento 17: 2026-11-08 (una reprogramación).
- Cerrados con acta, desde el 09-25: Ricardo Salas (punto 8), Mauricio Pérez (ambiente 4 y fecha 15), Natalia Ospina (diseño 13).
- Presupuesto (declarado en el informe del 10-12, sin respaldo contable): ejecutado 49,1 %, comprometido 30,7 %, proyección 4,4 % por debajo de lo aprobado.

**Quedaron fuera por tiempo:** nada. Los 41 minutos caben en 45.

**No sé:** qué motivó cada reprogramación (las actas no lo dicen), cuánto dura la reunión, qué se revisa con el proveedor, y qué autoridad tiene Liliana.

Esta agenda no convoca a nadie. Cuando termine la reunión, `/pm-minutes` sobre las notas o la transcripción.
