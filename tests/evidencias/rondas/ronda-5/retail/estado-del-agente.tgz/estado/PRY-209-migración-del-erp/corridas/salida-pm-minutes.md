# Acta — Migración del ERP (PRY-209) · 2026-10-16
**Asistieron (12):** Andrés Lozano, Carlos Peña, Diana Molina, Elena Duarte, Felipe Arango, Javier Hoyos, Laura Vélez, Liliana Torres, Mauricio Pérez, Natalia Ospina, Paula Céspedes, Óscar Ramírez · **Fuente:** `2026-10-16-notas-reunion.txt` (notas de 5 líneas, sin transcripción) · **Ausentes con tema en agenda:** no se puede saber; las notas no traen agenda. Coinciden los mismos 12 asistentes del comité del 2026-10-09.

*Condiciones de esta corrida: sesión sin interfaz. Términos ya vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-16), no se pidió aceptarlos de nuevo. Las notas ya habían sido leídas por `/pm-setup` y sus compromisos y el riesgo ya estaban en la ficha; esta corrida los cruzó y recalculó, sin cambiar nada en `estado/`.*

## Compromisos
| Quién | Qué | Para cuándo | |
|---|---|---|---|
| Natalia Ospina | Enviar el documento 1 | 2026-11-25 (dicho como «25/11/2026») | **Reprogramado por 6.ª vez.** Original 2026-09-20 → 09-29 → 10-08 → 10-19 → 11-03 → 11-11 → **11-25**. Son 66 días sobre la promesa original. Supera el umbral de 3 reprogramaciones. La cita: «lo de "enviar el documento 1" no alcanzó» |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-26 | Nuevo. Primera fecha. Ver *Sin resolver*: la nota no dice qué se revisa ni si él la hace o solo asiste |

### Sin fecha
| Quién | Qué |
|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto. Dijo «la otra semana», que no es una fecha: se guarda `due_date: no_declarada` con el texto textual. No puede vencer, y por eso no sale en ningún informe de vencidos |

Ya había otros dos sin fecha de reuniones anteriores, que esta reunión no tocó: Carlos Peña (Validar el ambiente 12, desde 2026-09-18) y Javier Hoyos (Validar el ambiente 20, desde 2026-10-02). Con el de Laura son **3 sin fecha**.

## Decisiones
Ninguna. Las notas no registran que alguien decidiera algo.

## Quedó sin decidir
Las notas no dicen qué quedó abierto. Con lo escrito, lo único que se puede afirmar es que **el presupuesto está pendiente de un ajuste** sin fecha (el de Laura), y que nadie tomó ninguna decisión sobre el proveedor.

## Intenciones sin doliente
Ninguna en estas notas.

## Dicho al pasar y no registrado
| Qué | Quién lo dijo | Categoría | Ya estaba en el RAID |
|---|---|---|---|
| «El proveedor podría no llegar con el equipo completo para la siguiente fase» (las notas: «nadie lo anotó como riesgo») | No dice quién. Las notas dicen «se comentó» | Riesgo (no ha ocurrido; es incierto) | **No como tal.** En el informe de avance del 2026-10-12 hay un riesgo cercano pero distinto: «el proveedor no ha confirmado la fecha de la última entrega». En la ficha ya está la entrada nueva desde las notas, con `owner: no_identificado`. Nadie lo ha aceptado como dueño |

## Cerrado en esta reunión
Nada. Las notas no traen ningún documento que cierre un compromiso, así que no se cierra ninguno.

## Lo que esta reunión contradice
| Campo | Dijo la reunión | Dice el expediente | Fuente y fecha de cada uno |
|---|---|---|---|
| Frecuencia del comité | «próxima reunión en dos semanas» (≈ 2026-10-30) | La configuración dice comité **semanal**; las seis reuniones archivadas (2026-09-04 a 2026-10-09) fueron semanales | Notas 2026-10-16 · `config.json` (`cycle.committee: weekly`). La fecha 2026-10-30 sí coincide con `committee_next` |
| Estado del proyecto | Natalia vuelve a mover un compromiso por 6.ª vez, y 6 compromisos están vencidos | Informe de avance: **verde**, 71 % | Notas 2026-10-16 · informe 2026-10-12. El cálculo marca `declared_vs_evidence`: verde declarado contra tres señales que el informe no explica (vencidos, reprogramados, avance contra plan) |

Sobre el patrocinador, el comité y la fecha de cierre, esta reunión no dice nada distinto del acta de constitución.

## Sin resolver de la transcripción
- «Óscar Ramírez: revisión con el proveedor, queda para el 2026-10-26»: no se entiende qué se revisa ni si Óscar la hace. Se registró a su nombre porque la línea empieza con él. Hay que confirmarlo con él.
- «Laura Vélez queda de mandar el ajuste del presupuesto la otra semana»: puede ser la semana del 10-19 o más adelante; no se eligió una. «Ajuste del presupuesto» tampoco dice de qué proyecto o rubro.
- «se comentó que el proveedor podría…»: no hay quién lo dijo ni qué proveedor ni qué fase. Las notas sólo dicen «el proveedor» y «la siguiente fase».
- «próxima reunión en dos semanas»: sin día ni hora.

## Cifras recalculadas (con `portafolio.py compute`, no a mano)
- Compromisos vencidos: 6 (Beatriz Cuéllar 22 días, Javier Hoyos 16, Felipe Arango 9, Natalia Ospina 7, Carlos Peña 1, Elena Duarte 1). Ninguno de ellos se mencionó en las notas de hoy.
- Reprogramados sobre el umbral: Natalia Ospina (6 veces) y Mauricio Pérez (5 veces; Cerrar la prueba 2, hoy en 2026-11-28).
- Sin fecha: 3.
- Presupuesto: ejecutado 49,1 %, comprometido 30,7 %, proyección 4,4 % por debajo de lo aprobado (cifras del informe del 2026-10-12, declaración, sin evidencia contable).
