# Corrida del 2026-10-16 · portfolio-scan

13 proyectos · 72 documentos, 0 releídos y 72 sin cambio · 275 s · 54 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 13 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 7 |
| `declared_vs_evidence` | 7 |
| `variance_cost` | 5 |
| `commitment_undated` | 5 |
| `milestone_overdue` | 2 |
| `commitment_rescheduled` | 2 |
| `rebaseline_unauthorized` | 1 |
| `variance_time` | 1 |
| `change_without_baseline` | 1 |
| `pm_vs_pmo` | 1 |
| `silent` | 1 |

Se leyeron 48 de 72 documentos (10 proyectos nuevos, 24 documentos sin cambio de PRY-203/208/209). No existe entrada/: nada movido. Sin ilegibles. Mirar: verde contradicho en 7 proyectos, 13 hitos cerrados sin acta, PRY-200 replanteo sin autorizar (CC-01), PRY-207 cronograma v2 anterior a CC-01, compromisos vencidos en 202/204/209, PRY-210 en silencio, 35 citas de pm_record de PRY-209 con ruta relativa a la carpeta del proyecto.

Contra la corrida del 2026-10-16: +33 hallazgos.

## Lo que produjo

Encontré 72 documentos en `documentos/proyectos` (13 carpetas de proyecto). Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-16). Leí 48 y dejé 24 sin tocar por no haber cambiado.

## Barrido — 2026-10-16

**Documentos:** 72 en la carpeta · 48 leídos · 24 sin cambio desde la corrida anterior · 0 ilegibles
**Proyectos:** 13 con ficha · 10 nuevos · 0 sin carpeta propia
**Formatos:** 33 .md, 12 .docx, 11 .pdf, 7 .csv, 7 .xlsx, 1 .txt, 1 .json. Word, Excel y PDF se leyeron por su texto convertido; las citas van a los originales.

El plan se ejecutó tal cual: 1 lote de 10 proyectos, uno tras otro en esta conversación, sin subagentes. No quedó nada diferido.

### Nuevos
| Proyecto | Documentos | Campos encontrados | Campos sin dato |
|---|---|---|---|
| PRY-199 Iluminación LED en bodegas | 6 | 14 | autoridad del gerente, fase |
| PRY-200 Tienda en línea | 6 | 14 | autoridad, fase |
| PRY-201 Programa de fidelización | 2 | 14 | autoridad, fase |
| PRY-202 Centro de distribución norte | 4 | 13 | producto (el acta dice «No aplica»), autoridad, fase |
| PRY-204 Cajas de autopago | 4 | 14 | autoridad, fase |
| PRY-205 Pago con QR en caja | 4 | 14 | autoridad, fase |
| PRY-206 Precios dinámicos | 4 | 13 | producto («No aplica»), autoridad, fase |
| PRY-207 Marca propia de alimentos | 7 | 14 | autoridad, fase |
| PRY-210 Etiquetas electrónicas de precio | 6 | 13 | producto («No aplica»), autoridad, fase |
| PRY-211 Pronóstico de demanda | 5 | 13 | producto («No aplica»), autoridad, fase |

Los diez quedan sellados con los hashes que calculó el script. La autoridad del gerente no aparece en ninguna de las 13 actas.

### Actualizados
| Proyecto | Qué cambió | Fuente |
|---|---|---|
| PRY-203, PRY-208, PRY-209 | Nada: sus 24 documentos no cambiaron, así que no se releyeron y su ficha se conserva. Solo se recalcularon las señales. | `plan-lectura` (hash contra `documents_seen`) |

### No pude leer
| Archivo | Por qué |
|---|---|
| — | Todos los archivos se pudieron leer. |

### Movidos desde entrada/
| Archivo | A qué proyecto | Por qué |
|---|---|---|
| — | — | No existe carpeta `entrada/` en esta instalación; no se movió nada. |

### Pendientes de clasificar
| Archivo | Por qué no pude decidir |
|---|---|
| — | Ninguno. |

## Lo que hay que mirar (calculado por el script sobre las 13 fichas: 54 alertas en 11 proyectos)

**Contradicciones y hallazgos de mayor peso**
- **Verde contradicho por la evidencia en 7 proyectos** (200, 206, 207, 208, 209, 210, 211). Ejemplos de los que leí: PRY-211 reporta verde con 30 % de avance, ejecutado 5.809 M contra comprometido 5.348 M y proyección de 22.675 M sobre 18.000 M aprobados. PRY-206 reporta verde con proyección de 1.014 M sobre 800 M aprobados. PRY-200 reporta verde con proyección de 11.453 M sobre 9.500 M.
- **Hitos declarados cerrados sin acta que lo pruebe** (`milestone_met_without_evidence`, 13 casos): PRY-202 (los 4 hitos), PRY-204, PRY-205, PRY-206 (2), PRY-210 (2), PRY-211, y los de 203 y 208. Lo que corresponde pedir es el acta, no apurar.
- **PRY-200: cronograma v2 (2026-10-13) mueve Integración con el ERP +27 días antes de que el comité vea CC-01**, que figura «pendiente de presentación al comité». Es un replanteo sin autorización (`rebaseline_unauthorized`).
- **PRY-207: CC-01 (+72 días, +144 M COP) está autorizada por el comité, pero el cronograma v2 que ya trae ese corrimiento es del 2026-09-26, doce días antes de la solicitud (2026-10-08)**, y el presupuesto aprobado sigue en 9.500 M. El script marca `change_without_baseline`. Además el despliegue pasa a 2027-10-02, después del cierre del acta (2027-09-06).
- **Compromisos vencidos** (8, de ellos 6 en PRY-209): PRY-202 (Rubén Cárdenas, 2026-10-13) y PRY-204 (Paula Céspedes, 2026-10-13) sin evidencia de cumplimiento. PRY-211 tiene un compromiso sin fecha (Diana Molina, «por definir»).
- **Plazos pasados con proyecto aún abierto:** PRY-201 tenía cierre comprometido el 2026-09-10 y reporta 81 % en verde sin cronograma ni hitos en la carpeta; PRY-202 tenía cierre el 2026-08-17 y reporta 63 % en amarillo. El script no marca el primero porque no hay hitos que medir; lo dejo aquí para que alguien lo mire.
- **Ejecutado mayor que comprometido** en PRY-205, PRY-206 y PRY-211, tal como lo reportan los informes. No lo corrijo; lo registro con su fuente.
- **PRY-210 en silencio:** último documento del 2026-09-26. Contrato CT-941: una factura FV-1941 por 217.654.407 COP, igual al monto del entregable ya recibido (Licenciamiento, acta del 2026-07-01); la factura dice «Entregables del contrato CT-941» en plural, y el segundo entregable (Bolsa de horas, 2026-12-23) sigue en curso. Vale confirmar a qué entregable se imputó.
- **PRY-199, contrato CT-199:** tres entregables de 144 M cada uno, todos pendientes; no hay facturas.
- **PRY-209 `pm_vs_pmo`:** la ficha que publicó el gerente (`ficha-pm.json`) y mi lectura discrepan. No decido quién tiene razón; está en el informe.

**Nota técnica:** el índice reporta 35 citas de PRY-209 que no resuelven contra la raíz de documentación: las rutas del bloque `pm_record` son relativas a la carpeta del proyecto, no a la raíz. Los documentos existen. No lo toqué porque esa ficha es del escritor PM.

**Sin dato en todo el portafolio:** autoridad del gerente (13 de 13) y fase (los 10 proyectos nuevos). Producto: 4 actas dicen «No aplica» (202, 206, 210, 211).

## Después

Hay más de un proyecto, así que puedo armar el informe consolidado (`/portfolio-report`). Con el comité semanal del 2026-10-23 a una semana, las contradicciones de arriba son lo que más conviene llevar.

---
criterio-portfolio 0.3.11 · fichas tocadas: 10 (PRY-199, 200, 201, 202, 204, 205, 206, 207, 210, 211) · campos en `not_found`: 24 en las 10 fichas nuevas (autoridad ×10, fase ×10, producto ×4; detalle en `meta.fields_not_found` de cada ficha) · términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.11
