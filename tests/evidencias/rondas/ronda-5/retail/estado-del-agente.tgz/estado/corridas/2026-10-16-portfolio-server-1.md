# Corrida del 2026-10-16 · portfolio-server

13 proyectos · 54 hallazgos

> El tiempo no se midió: faltó `corrida-inicio` al arrancar. Un tiempo escrito a mano es un recuerdo, no una medición.

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 13 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 7 |
| `declared_vs_evidence` | 7 |
| `variance_cost` | 5 |
| `commitment_undated` | 5 |
| `milestone_overdue` | 2 |
| `commitment_rescheduled` | 2 |
| `rebaseline_unauthorized` | 1 |
| `variance_time` | 1 |
| `change_without_baseline` | 1 |
| `pm_vs_pmo` | 1 |
| `silent` | 1 |

puerto 8787, carpeta reportes, modo rato

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

# /portfolio-server — Rostrum, modo «para mirarlo un rato»

**Términos:** ya vigentes (versión 1.1, familia 0.3.11, aceptados por José Francisco Ñáñez el 2026-10-16). No hubo que volver a pedirlos.

**Forma elegida:** «Para mirarlo un rato» (respuesta sugerida, sin interfaz para preguntar). Cero infraestructura y ninguna conversación con seguridad. Lo que se pierde: el patrocinador no tiene un enlace que funcione mañana.

**Informe:** existe en `reportes/` (13 proyectos PRY-199 a PRY-211, 7 productos, `decisiones.html`, `proyectos.html`, `productos.html`, `index.html`). Rostrum no lo genera, lo sirve.

**Comando:**

```
python3 "/home/claude/banco/criterio/plugins/criterio-portfolio/scripts/servidor.py" --informe reportes --estado estado --config .criterio/portafolio/config.json
```

Escucha en `127.0.0.1:8787`, solo en este equipo. Se para con Ctrl-C. Si el puerto está ocupado, `--puerto 8788`. El portal lleva el nombre «Portafolio retail».

| Ruta | Qué es | Para quién |
|---|---|---|
| `/` | Portada con las tres secciones y el formulario de peticiones | Todos |
| `/pmo` | Cómo va el portafolio: verdes sin sustento, silencios, patrocinadores repetidos | La PMO |
| `/decisiones` | Lo que necesita una decisión, con la consecuencia de no decidirla | Comité y patrocinador |
| `/proyectos` | Listado ordenado por lo que más pide atención | Todos |
| `/p/<código>` | Informe de un proyecto, enlazado a su producto | Quien gerencia |
| `/productos` | Listado de productos y proyectos sin producto declarado | Quien responde por un producto |
| `/producto/<nombre>` | Informe de un producto, enlazado a los proyectos que lo construyen | Quien responde por un producto |
| `/estado.json` | Fecha del informe y peticiones abiertas | Un mecanismo |

**Lo que Rostrum no hace:** no calcula (sirve lo que `informe.py` ya escribió), no escribe fichas (solo crea peticiones en `estado/peticiones/`), no autentica y no manda nada (ni correo ni notificaciones).

**Peticiones:** el formulario de la portada solo deja la petición en `estado/peticiones/`; el servidor no puede correr el agente. `portafolio.py due` las cuenta y una petición abierta rompe el silencio de `/portfolio-wake`. Se cierran con `portafolio.py answered --id <id>`.

**Cierre:** en este modo el enlace `http://127.0.0.1:8787/` solo sirve en este equipo, mientras el proceso esté vivo. Es para mirar, no para pasárselo al patrocinador. El informe es del 2026-10-16 (generado a las 11:49) y se desactualiza en cuanto cambie un documento o corra otro barrido; la portada muestra su fecha. Para un enlace estable hace falta el modo «que quede corriendo» (`--abierto`, detrás del control de acceso de la organización).
