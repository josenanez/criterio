# Corrida del 2026-10-16 · change-control

13 proyectos · 56 s · 54 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 13 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 7 |
| `declared_vs_evidence` | 7 |
| `variance_cost` | 5 |
| `commitment_undated` | 5 |
| `milestone_overdue` | 2 |
| `commitment_rescheduled` | 2 |
| `rebaseline_unauthorized` | 1 |
| `variance_time` | 1 |
| `change_without_baseline` | 1 |
| `pm_vs_pmo` | 1 |
| `silent` | 1 |

Evaluó mover 30 días el despliegue (2027-10-02 a 2027-11-01). Impacto en portafolio: 0, pero PRY-207 no declara dependencias. No supo: motivo, solicitante, impacto en alcance y costo, autoridad (no declarada), quién autorizó CC-01, y cuál es la fecha comprometida (acta 2027-09-06 contra línea base 1 2027-07-22).

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

Sale de la ficha PRY-207 (`estado/records/PRY-207.json`), actualizada el 2026-10-16. Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-16).

## Solicitud de cambio — PRY-207 Marca propia de alimentos — 2026-10-16

**Qué se pide:** mover la salida a producción 30 días. Lo leo como el hito «Despliegue en la cadena» (hoy 2027-10-02 → 2027-11-01); en la ficha no hay un hito llamado «salida a producción».
**Quién lo pide:** no consta en la solicitud; llegó por la invocación, sin nombre.
**Por qué:** no se dio motivo. Sin motivo no hay solicitud completa: la línea base nueva lo exige.

### Impacto
| Dimensión | Hoy | Con el cambio | Diferencia |
|---|---|---|---|
| Alcance | Tres componentes genéricos (acta, 2026-04-13); CC-01 lo amplió sin describir cómo | Sin declarar | Sin declarar |
| Tiempo | Despliegue en la cadena 2027-10-02 (cronograma v2) | 2027-11-01 | +30 días |
| Costo | Aprobado 9.500.000.000 COP; proyección 8.945.455.871 COP (informe del 2026-09-26) | Sin declarar | Sin declarar |

Alcance y costo quedan sin impacto declarado. Eso no significa que sean cero: 30 días más de equipo y de contratos los absorbe alguien, en horas no pagadas, en calidad o en presupuesto. No estimo el costo porque ningún documento da la tarifa del equipo ni los contratos que corren en esos días. Hay que pedírselo a Natalia Ospina.

**Contra tres referencias de fecha** (el cierre aparece distinto en dos documentos):

| Referencia | Fecha de cierre | Hoy | Con +30 días |
|---|---|---|---|
| Línea base 1 del cronograma v1 (2026-04-13) | 2027-07-22 | +72 días | +102 días |
| Acta de constitución (2026-04-13) | 2027-09-06 | +26 días | +56 días |
| Línea base 2 vigente (cronograma v2) | 2027-10-02 | 0 | +30 días |

El acta y el cronograma v1, ambos del mismo día, no coinciden: 46 días entre uno y otro. No sé cuál es la fecha comprometida; el comité tiene que decirlo. En la ficha uso la del cronograma v1.

### Efecto en el portafolio
| Proyecto afectado | Cómo | Gerente |
|---|---|---|
| Ninguno alcanzado | `impact` devolvió 0 directos, 0 indirectos, 0 que no pueden sostener su fecha, 0 dependencias sin confirmar | — |

**Esto no demuestra que no haya efecto.** El acta de PRY-207 dice «Ninguna declarada» en dependencias y la ficha tiene la lista vacía. Es ausencia de declaración, no de dependencia. Un proyecto de marca propia con integración con el ERP y piloto en tiendas, sin una sola dependencia, es raro y merece una pregunta a la gerente. Tampoco sé cuántos días se movería cada hito: eso necesita holgura por actividad y la ficha no la tiene.

Los hitos por los que pasa el cambio (por donde cruza, no necesariamente los que se mueven):
- Ambiente de pruebas certificado — 2026-10-22, dentro de 6 días, pendiente y sin evidencia.
- Integración con el ERP — 2027-01-21.
- Piloto en tiendas — 2027-04-22.
- Despliegue en la cadena — 2027-10-02.

El criterio de éxito del acta es «en producción y medido». Si «medido» exige un periodo después del despliegue, el cierre del proyecto se corre más de 30 días. El acta no lo dice.

### Quién decide
**Autoridad requerida:** no se puede determinar. El acta no declara autoridad (`identity.authority`: no encontrada).
**Según:** acta 2026-04-13: solo dice que el Comité Comercial aprobó el presupuesto. No fija umbrales de días ni de monto para cambios.
**Va a comité:** sí, por defecto. Sin autoridad escrita no hay quién pueda aprobarlo solo. Que falte la autoridad es el hallazgo de fondo, antes que el cambio mismo.

### Lo que ya está torcido antes de este cambio
- **CC-01 está aprobado pero sin línea base propia.** La ficha lo marca `change_without_baseline` y `approved_without_new_baseline`: +72 días, +144.000.000 COP, ampliación de alcance.
  - La solicitud dice «Autorizada por el comité» y no nombra quién decidió ni en qué acta.
  - El cronograma v2 es del 2026-09-26 y CC-01 es del 2026-10-08. La línea base 2 es 12 días anterior a la autorización que la justifica.
  - CC-01 dice «+72 días sobre la línea base vigente», pero 72 días es contra la línea base original (2027-07-22). Contra la vigente no se movió nada. La redacción es ambigua.
  - La reconciliación cuadra en días: 72 movidos, 72 autorizados, 0 sin autorizar. Pero no hay documento que registre quién los autorizó.
- **El presupuesto aprobado sigue en 9.500.000.000 COP.** Los 144.000.000 COP de CC-01 no están reflejados en ninguna línea base de costo.
- **El estado declarado es verde** (informe del 2026-09-26, 37 % de avance) con 72 días de atraso contra la original (15,8 %, umbral 10 %). Un hito de cinco cumplido; el plan sostiene entre 20 % y 40 %, así que el avance declarado es consistente. El verde no lo es.
- Un riesgo sin dueño: el proveedor no ha confirmado la fecha de la última entrega. No hay proveedores en la ficha para contrastarlo.

### Si no se aprueba
El proyecto queda como está: cierre 2027-10-02 contra la línea base 2. Con 72 días de atraso sobre la original y sin autoridad escrita para el cambio anterior. El motivo del movimiento de 30 días no consta, así que no puedo decir qué pasa si no se hace. Sin el cambio, el hito de 2026-10-22 sigue siendo la primera prueba de si el cronograma se sostiene.

### Si se aprueba
Línea base 3 — cierre 2027-11-01 · presupuesto: sin declarar (9.500.000.000 COP vigente + 144.000.000 COP de CC-01 sin registrar) · motivo: sin motivo en la solicitud.
La línea base 2 no se toca. El conteo de replanificaciones pasa de 1 a 2.
**Desviación acumulada contra la línea base original:** tiempo +102 días (hoy +72) · costo: no calculable, no hay línea base de costo posterior a la original y CC-01 no la dejó.
Contra el acta, +56 días.

### Lo que no sé
- Por qué se pide el cambio y quién lo pide.
- Si «salida a producción» es el hito «Despliegue en la cadena».
- Qué pasa con alcance y costo.
- Qué fecha vale: la del acta (2027-09-06) o la de la línea base 1 (2027-07-22).
- Quién autorizó CC-01.
- Si PRY-207 tiene dependencias reales.

## Después
Si el comité lo va a ver, el paquete se prepara con `/steering-pack`. El comité semanal siguiente es el 2026-10-23. Antes de llevarlo hacen falta cuatro cosas: el motivo, la fecha comprometida válida, la autoridad y las dependencias. No se registra línea base nueva: nadie con autoridad la ha aprobado.

*Pie de rigor: borrador de trabajo, no decisión ni asesoría. Cada dato sale de la ficha PRY-207 y de los documentos citados en ella. La verificación es de quien lo lea.*
