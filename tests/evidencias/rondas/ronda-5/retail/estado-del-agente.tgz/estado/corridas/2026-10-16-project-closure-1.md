# Corrida del 2026-10-16 · project-closure

13 proyectos · 38 s · 54 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 13 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 7 |
| `declared_vs_evidence` | 7 |
| `variance_cost` | 5 |
| `commitment_undated` | 5 |
| `milestone_overdue` | 2 |
| `commitment_rescheduled` | 2 |
| `rebaseline_unauthorized` | 1 |
| `variance_time` | 1 |
| `change_without_baseline` | 1 |
| `pm_vs_pmo` | 1 |
| `silent` | 1 |

Cierre de PRY-201 no emitido: sin cierre declarado (81 % verde, incidencia abierta, fecha 2026-09-10 vencida sin replanificación). Criterio de éxito existe pero no se puede determinar; sin hitos, sin dolientes, sin lecciones sustentables.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

**Fuentes de este cierre:** ficha `estado/records/PRY-201.json` (actualizada 2026-10-16) y los dos documentos de los que sale: el acta de constitución `PRY-201-programa-de-fidelización/00-gobierno/2025-11-10-acta-constitucion.docx` y el informe de avance `PRY-201-programa-de-fidelización/20-seguimiento/2026-10-13-informe-avance.md`. Cifras derivadas: salida de `portafolio.py compute` con corte 2026-10-16. Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-16).

## Cierre — PRY-201 Programa de fidelización — 2026-10-16

**Resultado: este proyecto no se puede cerrar contra lo pactado.** La documentación no muestra un proyecto terminado: el último informe (2026-10-13) lo declara en verde con 81 % de avance, con una incidencia abierta y sin ninguna fecha de cierre real. Lo que sigue es lo que sí se puede decir hoy; no es un acta de cierre.

### Contra lo comprometido
**Criterio de éxito:** "Programa de fidelización en producción y medido." (acta de constitución, 2025-11-10).
**Se cumplió:** no se puede determinar. Ningún documento dice que el programa esté en producción ni que se esté midiendo. Lo único cercano es que "la prueba de carga de temporada no alcanzó el umbral pactado y se repite" (informe 2026-10-13), lo que apunta a que aún no está listo para producción.

| Entregable comprometido | Estado | Evidencia |
|---|---|---|
| Componente 1 | Sin dato | El acta lo nombra sin describirlo; ningún documento reporta su estado |
| Componente 2 | Sin dato | Ídem |
| Componente 3 | Sin dato | Ídem |

Hallazgo: el alcance del acta son tres "componentes" sin contenido y la ficha no tiene hitos (`milestones` vacío). El 81 % declarado no tiene contra qué contrastarse.

### Fuera de alcance final
| Qué quedó fuera | Decidido por | Cuándo |
|---|---|---|
| "Lo que otro proyecto cubre" (único ítem fuera de alcance del acta, sin especificar cuál proyecto) | Acta de constitución | 2025-11-10 |

No hay ningún recorte de alcance registrado posterior al acta, ni solicitud de cambio (0 cambios en la ficha).

### Números finales
| | Original | Vigente | Final | Desviación vs original |
|---|---|---|---|---|
| Fecha de cierre | 2026-09-10 | 2026-09-10 | Sin dato: el proyecto no ha cerrado | Sin dato |
| Presupuesto (COP) | 6.800.000.000 | 6.800.000.000 | Proyección al cierre: 6.821.176.777 (no es un valor final) | Proyección: +0,3 % sobre lo aprobado |

Replanificaciones: **0**. La fecha de cierre de la línea base (2026-09-10) es anterior al corte de este cierre (2026-10-16) y no hay replanificación ni nueva fecha registrada; el script no entrega los días de atraso, así que no los cifro.

Presupuesto, informe 2026-10-13 (COP): aprobado 6.800.000.000 · comprometido 4.318.579.944 (63,5 %) · ejecutado 2.579.519.333 (37,9 %) · disponible real 2.481.420.056.

Nota de coherencia: 81 % de avance declarado frente a 37,9 % del presupuesto ejecutado. Es una diferencia que el informe no explica; no la califico porque no hay hitos que digan cuál de los dos números mide qué.

### RAID al cierre
**Materializados:** ninguno confirmado. La incidencia de la prueba de carga ya ocurrió, pero se registró como incidencia, no como riesgo previo.
**No materializados:** no se puede afirmar. Los dos riesgos siguen abiertos en el informe.
**Abiertos, sin doliente (por tanto no cerrables):**
| Qué | Tipo | Doliente |
|---|---|---|
| La prueba de carga de temporada no alcanzó el umbral pactado y se repite (desde 2026-10-13) | Incidencia | Ninguno nombrado |
| Cambio en la regulación de datos personales que puede mover el alcance | Riesgo | Ninguno nombrado |
| Congelamiento de cambios en temporada alta | Riesgo | Ninguno nombrado |

### Lecciones
No entra ninguna. Con dos documentos, sin línea de tiempo de hitos, sin replanificaciones y sin minutas, no hay un hecho con fecha y efecto del que se pueda anclar una lección. Escribir una sería inventarla.

### Sin dato
- Si el programa está en producción y se mide (el criterio de éxito).
- Contenido y estado de los tres componentes.
- Hitos del plan, y por tanto de dónde sale el 81 %.
- Qué pasó con la fecha de cierre 2026-09-10 y quién aceptó pasarla.
- Doliente de cada riesgo y de la incidencia.
- Autoridad de aprobación y fase del proyecto (campos no encontrados en la documentación).
- Los 14 datos de la ficha vienen sin marcar como evidencia o declaración (0 como evidencia, 0 como declaración).

### Qué haría falta para cerrarlo
1. Que Liliana Torres (gerente) o Laura Vélez (patrocinadora) declare si el proyecto terminó, y contra qué evidencia de producción y medición.
2. Un doliente con nombre para la incidencia y para los dos riesgos.
3. Una decisión registrada sobre la fecha de cierre vencida (replanificar o cerrar por decisión).

### Después
No ofrezco mover la carpeta a `archivo/` ni congelar la ficha: un proyecto sin cierre declarado y con una incidencia abierta debe seguir en el barrido diario. Si la persona responsable decide cerrarlo por decisión, se hace entonces.
