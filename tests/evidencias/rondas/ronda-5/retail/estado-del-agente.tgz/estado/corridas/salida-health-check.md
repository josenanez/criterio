Términos vigentes (v0.3.11, aceptados por José Francisco Ñáñez el 2026-10-16); no hizo falta volver a aceptarlos.

## Diagnóstico · PRY-202 Centro de distribución norte · 2026-10-16

**Leí:** 4 documentos en la carpeta del proyecto · del 2025-06-24 al 2026-10-11 · formatos: docx (2), md (1), csv (1). Además busqué el código, el nombre y a las personas en los demás documentos del espacio: ninguna otra minuta ni acta menciona a PRY-202.
**No pude leer:** nada quedó ilegible. Los dos .docx (acta y minuta) los leí por su texto convertido en el caché; las citas apuntan a los originales.

### Dictamen
**Sostenido:** 4 afirmaciones · **Sin sustento:** 10 · **Contradicho:** 2

Desde esta carpeta se puede afirmar quién gobierna el proyecto (patrocinador, gerente y comité con nombre), cuánto se aprobó (4.200.000.000 COP) y qué plan se firmó. No se puede afirmar nada de lo que el proyecto hizo: no hay una sola evidencia de recibo, ni libro de gastos, ni registro de riesgos. El informe de avance (amarillo, 63%) se contradice con el cronograma, que marca los 4 hitos como cerrados (100%), y su propia proyección de costo supera lo aprobado en 23.1%. Con esta carpeta el color amarillo no se sostiene ni se refuta: se queda sin sustento.

### Gobierno
| | Qué dice el documento | Fuente |
|---|---|---|
| Patrocinador | Camilo Beltrán (asiste al comité del 2026-10-10) | 00-gobierno/2025-06-24-acta-constitucion.docx; 30-reuniones/2026-10-10-comite-semanal.docx |
| Gerente | Laura Vélez (el informe y la minuta coinciden) | 00-gobierno/2025-06-24-acta-constitucion.docx; 20-seguimiento/2026-10-11-informe-avance.md |
| Autoridad declarada | No está. El acta no dice qué puede aprobar el gerente en tiempo, costo o alcance | 00-gobierno/2025-06-24-acta-constitucion.docx |
| Comité | Comité de Transformación Digital; aprobó el presupuesto el 2025-06-24 | 00-gobierno/2025-06-24-acta-constitucion.docx |

Otros vacíos del acta: alcance escrito como «Componente 1, 2, 3» y «Lo que otro proyecto cubre», sin contenido; dependencias «Ninguna declarada»; producto asociado «No aplica»; no hay firmas ni fase.

### Contra el plan
- Línea base original: acta del 2025-06-24 con inicio 2025-07-04 y cierre 2026-08-17. Cronograma v1 (mismo día): 4 hitos, el último «Piloto en tiendas» el 2026-07-02.
- Vigente: idéntica a la original en los 4 hitos. Replanificaciones: 0. Desviación contra la original: 0 días. No hay solicitudes de cambio.
- El cronograma no tiene ningún hito para el criterio de éxito del acta («en producción y medido»), y su último hito cae antes de la fecha de cierre del acta.
- La fecha de cierre del acta (2026-08-17) ya pasó, el informe del 2026-10-11 sigue reportando trabajo en curso, y ningún documento replanifica ni explica ese desfase.

### Hitos vencidos sin evidencia
Los 4 hitos están declarados cerrados y los 4 están vencidos sin ningún documento de recibo.
| Hito | Fecha | Días | Qué documento se esperaría |
|---|---|---|---|
| Diseño de la experiencia aprobado | 2025-10-02 | 379 | Acta de recibo o aprobación del diseño |
| Ambiente de pruebas certificado | 2026-01-01 | 288 | Certificado o acta de pruebas |
| Integración con el ERP | 2026-04-02 | 197 | Acta de recibo de la integración |
| Piloto en tiendas | 2026-07-02 | 106 | Acta de cierre del piloto con resultados |

### Dinero
Fuente: informe del 2026-10-11 (declaración); lo aprobado también está en el acta.
| Aprobado | Comprometido | Ejecutado | Proyección | Disponible real |
|---|---|---|---|---|
| 4.200.000.000 | 2.694.656.765 (64.2%) | 2.157.815.149 (51.4%) | 5.168.800.668 (23.1% sobre lo aprobado) | 1.505.343.235 |

Solo la cifra aprobada tiene respaldo documental. Comprometido, ejecutado y proyección son lo que el gerente escribe; no hay contratos, facturas ni ejecución presupuestal. Una proyección 23.1% sobre lo aprobado, sin solicitud de cambio, supera el umbral de 10%.

### Lo que se dijo y nadie registró
- Compromiso: Rubén Cárdenas, «Entregar el punto 21», para 2026-10-13. Vencido hace 3 días, sin evidencia de entrega. La minuta no dice qué es el «punto 21» y Rubén Cárdenas no figura como asistente ni tiene rol en PRY-202.
- La minuta del 2026-10-10 lista «Avance» y «Compromisos» como temas, sin contenido: no registra decisiones ni riesgos.
- Los dos riesgos del informe (regulación de datos personales; disponibilidad de los jefes de tienda para el piloto) no están en ningún registro RAID ni en la minuta. El acta declara «Ninguna» dependencia.

### Contradicho
| Afirmación | Documento A | Documento B |
|---|---|---|
| Avance 63% | Informe 2026-10-11: «63%» | Cronograma v1: 4 de 4 hitos cerrados (el plan sustenta 100%); brecha de 37 puntos |
| Riesgo abierto: «disponibilidad de los jefes de tienda para el piloto» | Informe 2026-10-11: riesgo abierto | Cronograma v1: «Piloto en tiendas» cerrado el 2026-07-02 |

### Sin sustento
- Estado **amarillo**: ningún documento define el criterio, y las propias cifras del informe apuntan a algo peor.
- Comprometido, ejecutado y proyección al cierre (3 cifras).
- Los 4 hitos «cerrados» (sin acta de recibo).
- Riesgo de cambio en la regulación de datos personales.
- «La validación con dos tiendas se extendió una semana por el conteo de inventario»: nada la respalda, y además el piloto en tiendas figura cerrado desde julio.

### Lo que esta carpeta no permite saber
- Si el proyecto avanzó realmente: sin actas de recibo no se puede distinguir un hito cerrado de uno declarado. Consecuencia: el 100% del plan y el 63% del informe son igual de inverificables.
- Cuánto se gastó: sin ejecución presupuestal, la alerta de 23.1% es la cifra del gerente, no un hecho.
- Quién puede aprobar un cambio: sin autoridad declarada, una desviación aprobada no existe, solo fechas escritas.
- Si el cierre del 2026-08-17 fue vencido o replanificado: no hay solicitud de cambio ni acta de comité que lo diga.
- Qué es el «punto 21» y qué papel tiene Rubén Cárdenas: la minuta no lo dice.

### Siguiente paso
No recomiendo continuar, detener ni reestructurar: eso lo decide quien tiene la facultad. Como la carpeta no permite diagnosticar el avance real, ofrezco preparar el punto de comité con la lista de lo que falta. También puedo llevar las 2 contradicciones y el compromiso vencido a Laura Vélez como preguntas, una por una.

---
Pie de rigor: borrador de trabajo basado solo en 4 documentos de la carpeta; no refleja lo hablado fuera de ellos. Las cifras derivadas salen de `portafolio.py compute` (corte 2026-10-16); la verificación y la decisión son de quien lo lea.
