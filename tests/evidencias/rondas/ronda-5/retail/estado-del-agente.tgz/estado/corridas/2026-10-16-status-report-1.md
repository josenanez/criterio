# Corrida del 2026-10-16 · status-report

13 proyectos · 37 s · 54 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 13 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 7 |
| `declared_vs_evidence` | 7 |
| `variance_cost` | 5 |
| `commitment_undated` | 5 |
| `milestone_overdue` | 2 |
| `commitment_rescheduled` | 2 |
| `rebaseline_unauthorized` | 1 |
| `variance_time` | 1 |
| `change_without_baseline` | 1 |
| `pm_vs_pmo` | 1 |
| `silent` | 1 |

Status de PRY-210: verde declarado contradicho por 3 señales (hitos sin evidencia, brecha de avance de 20 puntos, 20 días de silencio). Dije que no sé: producto, autoridad, fase, última reunión, responsables de RAID.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

Informe sale de la ficha `estado/records/PRY-210.json` (registro actualizado el 2026-10-16), con cifras recalculadas por `portafolio.py compute` al 2026-10-16.

## PRY-210 · Etiquetas electrónicas de precio — estado al 2026-10-16

**Declara el gerente (Paula Céspedes):** verde · 20% · al 2026-09-26 (hace 20 días; `declaration_stale` no se activa, el umbral es 30)
**Sustento documental:** contradicho (alerta `declared_vs_evidence`)
**Lo que el semáforo no explica:** `milestone_met_without_evidence`, `progress_vs_plan`, `silent`
**Último documento:** 2026-09-26 (informe de avance) · **Última reunión:** sin dato (no hay minutas ni compromisos en la ficha)

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2027-05-08 | 2027-05-08 | 0 días (original y vigente) |
| Presupuesto aprobado | 2.400.000.000 COP | 2.400.000.000 COP | proyección al cierre 2.283.077.690 COP: −4,9 % (por debajo) |

Replanificaciones: 0. Solicitudes de cambio: 0.
Ejecutado 760.497.920 COP (31,7 %); comprometido 871.665.846 COP (36,3 %); disponible real 1.528.334.154 COP.

### Hitos
| Hito | Base | Vigente | Estado | Evidencia |
|---|---|---|---|---|
| Diseño de la experiencia aprobado | 2026-03-27 | 2026-03-27 | cumplido (declarado) | ninguna — 203 días sin evidencia |
| Ambiente de pruebas certificado | 2026-07-07 | 2026-07-07 | cumplido (declarado) | ninguna — 101 días sin evidencia |
| Integración con el ERP | 2026-10-16 | 2026-10-16 | pendiente | vence hoy; aún no vencido |
| Piloto en tiendas | 2027-01-26 | 2027-01-26 | pendiente | — |
| Despliegue en la cadena | 2027-05-08 | 2027-05-08 | pendiente | — |

### Dónde no coincide
- **Avance:** el gerente declara 20 % (informe 2026-09-26); con 2 de 5 hitos cumplidos el plan sustenta entre 40 % y 60 %. Brecha de 20,0 puntos, en el sentido de ir *por detrás* de lo que dicen los hitos. Ojo: los dos hitos marcados cumplidos no tienen evidencia, así que ni el 20 % ni el 40–60 % están sustentados por un documento.
- **Verde:** el informe de 2026-09-26 reporta verde y el script encuentra tres señales que ese verde no explica (hitos sin evidencia, brecha de avance, 20 días de silencio; umbral 15).
- **Proveedor CT-941 (Logística del Valle Ltda.):** 1 de 2 entregables aceptado, con acta de recibo del 2026-07-01; facturado 217.654.407 COP = monto aceptado, sin factura adelantada. La bolsa de horas (217.654.407 COP) vence 2026-12-23, pendiente.

### Abierto
**Riesgos e incidencias sin movimiento:**
- Incidencia: validación con dos tiendas extendida una semana por el conteo de inventario, desde 2026-09-26 (20 días), sin responsable.
- Riesgo: cambio en la regulación de datos personales que puede mover el alcance; sin responsable ni fecha en la ficha (no se puede calcular días sin movimiento).
**Compromisos vencidos:** ninguno (no hay compromisos registrados; no es lo mismo que ninguno vencido).
**Dependencias sin confirmar:** ninguna registrada. El informe habla de acordar con arquitectura y con seguridad, pero no lo deja como dependencia ni compromiso.

### Sin dato
- `identity.product`, `identity.authority`, `identity.phase` (no encontrados).
- Última reunión; responsables de riesgo e incidencia; evidencia de los dos hitos cumplidos.

### Después
No hay desviación de plazo ni de costo sobre el umbral del 10 %, así que no corresponde ofrecer solicitud de cambio. Sí conviene pedir a la gerente evidencia de los dos hitos y actualizar el informe; ofrezco preparar el punto de comité si lo quieres.

---
**Pie:** Criterio Portfolio 0.3.11 · ficha PRY-210 actualizada el 2026-10-16 · campos inciertos: producto, autoridad, fase · Términos v1.1 aceptados por José Francisco Ñáñez el 2026-10-16: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.11
