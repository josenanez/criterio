**Sale de:** `00-gobierno/2025-12-03-contrato-ct-941.md`, `20-seguimiento/2026-07-01-acta-recibo-ct-941-licenciamiento-de-la-plataforma.pdf`, `20-seguimiento/2026-08-28-factura-ct-941.pdf` y `20-seguimiento/2026-09-26-informe-avance.md` (PRY-210), más la salida de `portafolio.py compute` al 2026-10-16. El acta de constitución no menciona al proveedor.

## Proveedores — PRY-210 Etiquetas electrónicas de precio al 2026-10-16

### Logística del Valle Ltda. — contrato CT-941
**Vigencia:** firmado el 2025-12-03; fecha de terminación no declarada · **Preaviso de no renovación:** no declarado · **Vence el:** sin dato

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento de la plataforma (217.654.407 COP) | 2026-06-20 | accepted | Acta de recibo del 2026-07-01, recibida por Paula Céspedes | 217.654.407 COP (FV-1941, 2026-08-28) |
| Bolsa de horas de desarrollo (217.654.407 COP) | 2026-12-23 | en curso, sin vencer | Ninguna aún, y aún no se espera | Nada |

Cifras del script: 2 entregables, 1 aceptado, `late` vacío, `accepted_without_evidence` vacío, facturado 217.654.407, monto aceptado 217.654.407. No se levantó `vendor_invoiced_without_delivery`.

### Dónde no cuadra
| Qué | Dice el contrato | Dice la evidencia | Fuentes |
|---|---|---|---|
| Fecha de entrega del licenciamiento | Comprometido para 2026-06-20 | Recibido el 2026-07-01, después de la fecha | contrato; acta de recibo |
| Concepto de la factura | Cada entregable se factura contra su propia acta de recibo | La factura FV-1941 dice «Entregables del contrato CT-941», en plural y sin nombrar cuál. Su valor es igual al del licenciamiento, único entregable con acta | contrato; factura; acta |

Los montos cuadran: lo facturado es igual a lo aceptado. Lo que queda abierto es el concepto de la factura. Hay que confirmar con cuentas por pagar que cubre solo el licenciamiento y no un anticipo de la bolsa de horas.

### Sin evidencia de recibo
Ninguno. El único entregable declarado como recibido tiene acta. El acta lleva nombre de quien recibe (Paula Céspedes, gerente del proyecto, que es la figura que el contrato exige) pero no muestra una firma visible en el PDF. Eso se verifica contra el original.

### Compromisos del proveedor vencidos
Ninguno detectado (`commitments_overdue` vacío). La carpeta no tiene minutas ni actas de comité con el proveedor, así que el resultado es silencio y no confirma que no haya promesas.

### Sin dato
- Vigencia, renovación automática y preaviso de CT-941: el contrato no los trae. No puedo decir si hay un preaviso por vencer.
- Monto total del contrato: solo hay montos por entregable.
- Minutas con el proveedor: no están en la carpeta.
- Aceptación del segundo entregable, bolsa de horas: aún no corresponde, vence el 2026-12-23.

### Contexto que importa para comité
El informe de avance del 2026-09-26 declara **verde** y 20 % de avance. El script marca contra eso tres señales: silencio de 20 días (desde 2026-09-26), avance contra plan (el plan sustenta entre 40 y 60 %; brecha de 20,0 puntos) y dos hitos declarados cumplidos sin evidencia («Diseño de la experiencia aprobado» y «Ambiente de pruebas certificado»). Esas señales son del proyecto y no del proveedor. El tramo del proveedor, tal como está documentado, está limpio salvo los dos puntos de arriba.

### Lo que sigue
- Pedir a cuentas por pagar el soporte de FV-1941 para ver qué entregable cubre.
- Pedir al proveedor o al gerente la vigencia y las condiciones de renovación de CT-941.
- No hay entregables facturados sin evidencia, así que no hay nada que llevar a comité por este frente.

---
**Rigor:** cifras copiadas de `compute`. No se calculó ningún conteo de días a mano. Se leyeron 4 documentos del proyecto. Quedaron sin leer el cronograma `10-plan/2025-12-06-cronograma-v1.xlsx` y el acta de constitución más allá de la búsqueda del proveedor. Lo documentado no dice nada de lo hablado fuera de los documentos.
