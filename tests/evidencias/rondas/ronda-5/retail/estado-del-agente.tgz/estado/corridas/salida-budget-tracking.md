Documentos: ficha PRY-202 (acta de constitución 2025-06-24; informe de avance 2026-10-11) y `portafolio.py compute` del 2026-10-16.

## Presupuesto — PRY-202 Centro de distribución norte al 2026-10-16
**Moneda:** COP (única; no hay contratos en otra moneda)

| | Monto (COP) | % del aprobado | Fuente | Fecha |
|---|---|---|---|---|
| Aprobado | 4.200.000.000 | 100 | 00-gobierno/2025-06-24-acta-constitucion.docx | 2025-06-24 |
| Comprometido | 2.694.656.765 | 64.2 | 20-seguimiento/2026-10-11-informe-avance.md | 2026-10-11 |
| Ejecutado | 2.157.815.149 | 51.4 | 20-seguimiento/2026-10-11-informe-avance.md | 2026-10-11 |
| Proyección al cierre | 5.168.800.668 | 23.1 por encima del aprobado | 20-seguimiento/2026-10-11-informe-avance.md | 2026-10-11 |

**Disponible real** (aprobado menos comprometido): 1.505.343.235 COP

### Contra la línea base
| | Original | Vigente | Desviación |
|---|---|---|---|
| Presupuesto aprobado | 4.200.000.000 | 4.200.000.000 | 0 (sin cambios registrados) |

Replanificaciones de presupuesto: 0. Solicitudes de cambio registradas: 0.
La proyección, en cambio, supera el aprobado en 23.1 %, por encima del umbral de 10 %.

### Ejecución frente a avance
Ejecutado 51.4 % · Hitos cumplidos 4 de 4 · Avance declarado 63 % frente a un plan que sustenta 100 % (brecha de 37.0 puntos, hacia atrás).
Lectura: los hitos dicen que todo está cumplido y el avance declarado dice 63 %; las dos cosas no pueden ser ciertas a la vez, y la plata ejecutada (51.4 %) se parece más al avance declarado que al plan.

### Alertas
- **Proyección excede el aprobado:** 23.1 % (umbral 10 %). La proyección es una declaración del informe de avance del 2026-10-11, no un dato duro; tiene 5 días de antigüedad. No hay movimiento de presupuesto posterior.
- **Comprometido:** 64.2 %, por debajo del umbral de 90 %. No hay alerta de agotamiento. Lo comprometido más lo que falta por ejecutar es lo que explica la proyección; no se puede decir más sin el detalle por proveedor.
- **Ejecución desalineada del avance:** los 4 hitos figuran como cumplidos (fechas 2025-10-02, 2026-01-01, 2026-04-02 y 2026-07-02) sin evidencia en ningún documento, y el avance declarado (63 %) contradice el plan (100 %).
- **Dato viejo:** el aprobado sale de un acta de hace 16 meses (umbral 12). No hay documento posterior que lo confirme ni lo cambie.
- Compromiso vencido sin evidencia: Rubén Cárdenas, "Entregar el punto 21", vencía el 2026-10-13 (3 días). No es de presupuesto; se menciona porque sale en la misma corrida.

### Sin dato
- Tasa de cambio: no aplica, una sola moneda.
- Proveedores: la ficha no registra ninguno en PRY-202, así que no hay detalle por proveedor ni facturación para contrastar.
- Fase, producto y autoridad del proyecto no están declarados.

### Después
La proyección excede el aprobado: puedo preparar la solicitud de cambio (`/criterio-portfolio:change-control`). No hay detalle por proveedor que ofrecer, porque no hay proveedores en la ficha.

---
*Pie de rigor: borrador de trabajo, no decisión ni asesoría. Cada cifra sale de `portafolio.py compute` y de la ficha, con la fuente de la tabla; la verificación contra los documentos es de quien lo lee. Los términos v1.1 (criterio-portfolio 0.3.11) están vigentes, aceptados por José Francisco Ñáñez el 2026-10-16.*
