**Sale de:** las 13 fichas de `estado/records/` (lectura del 2026-10-16), la salida de `portafolio.py compute` al 2026-10-16 y las salidas de `/raid-log` y `/change-control` del mismo día. Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-16). Lo hablado fuera de los documentos no lo conozco.

Pregunta de la sesión sin interfaz: ninguna que contestar. Tomo la respuesta sugerida en cada caso y lo digo donde aplica.

# Comité de proyectos — 2026-10-23 (material preparado el 2026-10-16)
6 decisiones · 4 escalamientos sin decisión asociada · 11 de 13 proyectos con alertas (54 alertas en total)

## Decisiones del comité anterior
No hay registro. Ninguna ficha, acta ni minuta de la carpeta recoge decisiones de un comité de portafolio anterior, y no hay `reportes/` con paquetes previos. No sé qué se decidió antes ni qué quedó abierto. Esto es ausencia de documento, no prueba de que no hubo comité.

| Decisión | Fecha | Qué pasó | Estado |
|---|---|---|---|
| (sin registro) | — | — | — |

## Decisiones de hoy

### [1] ¿Quién tiene autoridad escrita para aprobar cambios de tiempo y costo en cada proyecto, y con qué umbrales?
**Proyecto:** los 13 · **Quién decide:** comité (no hay otro por encima en los documentos) · **Si no se decide hoy:** los puntos 2 y 3 no pueden cerrarse con validez; cada cambio seguirá yendo a comité «por defecto».
Hecho: `authority` falta en las 13 fichas (13 de 13 sin autoridad). Las actas dicen quién patrocina y quién gerencia, no quién aprueba cambios ni con qué umbral.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. El comité fija una autoridad y umbrales únicos para el portafolio | Sin efecto | Sin declarar | Sin declarar |
| B. Cada patrocinador declara por escrito la suya, en una semana | Sin efecto | Sin declarar | Sin declarar |
| C. No se define; todo cambio va a comité | Sin efecto | Más carga al comité | Sin declarar |

**Recomendación:** A, con el patrocinador de cada acta como primer candidato. Es la menos cara y desbloquea los puntos 2 y 3. Los umbrales concretos los pone el comité; yo no los propongo porque ningún documento los sugiere.

### [2] ¿Se aprueba CC-01 de PRY-200 (Tienda en línea): ampliación de alcance, +27 días, +54.000.000 COP?
**Proyecto:** PRY-200 · gerente Beatriz Cuéllar, patrocinadora Paula Céspedes · **Quién decide:** sin determinar (ver punto 1) · **Si no se decide hoy:** el cronograma v2 (2026-10-13) ya movió «Integración con el ERP» de 2027-08-31 a 2027-09-27, sin autorización. El plan vigente es el del cambio no decidido.
Hechos: solicitud del 2026-10-05, estado `pending`, sin decisor. `compute`: 27 días movidos, 0 autorizados, señal `rebaseline_unauthorized`. Presupuesto aprobado 9.500.000.000 COP; proyección 11.453.287.850 COP (+20,6 %, umbral 10 %). Avance declarado 79 % con 0 de 3 hitos cumplidos (el plan sostiene entre 0 y 33 %). Estado declarado: verde.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar CC-01 y abrir línea base 3 | Ampliado, sin describir cómo | Cierre 2027-09-27 (+27 días vs la original) | +54.000.000 COP en la solicitud; la proyección ya supera el aprobado en 20,6 % |
| B. Rechazar; volver al cronograma v1 | Sin ampliación | Cierre 2027-08-31; el congelamiento de fin de año sigue sin solución | Sin declarar |
| C. Devolver: pedir motivo, desglose de costo y reconciliar el 79 % de avance | Sin cambio | Sin cambio hasta decidir | Sin cambio |

**Recomendación:** C. La solicitud trae un costo de 54.000.000 COP, pero la proyección del propio informe supera el aprobado en 20,6 %, y el avance declarado (79 %) no cuadra con ningún hito cumplido. Aprobar ahora fijaría una línea base sobre cifras que no se sostienen. B no resuelve el congelamiento que dio origen al cambio.

### [3] PRY-207 (Marca propia): ¿se ratifica CC-01 ya ejecutado y qué fecha de cierre vale?
**Proyecto:** PRY-207 · **Quién decide:** sin determinar (ver punto 1) · **Si no se decide hoy:** la nueva solicitud de mover 30 días el despliegue no puede evaluarse, porque no se sabe contra qué fecha.
Hechos: CC-01 figura aprobado, «autorizada por el comité», sin nombre de decisor ni acta; no tiene línea base propia (`change_without_baseline`): +72 días (15,8 % contra la original, umbral 10 %) y +144.000.000 COP que no están en ninguna línea base de costo. El acta (2027-09-06) y el cronograma v1 (2027-07-22) fijan el cierre en fechas distintas y son del mismo día. Estado declarado: verde.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Ratificar CC-01 con acta, registrar línea base 3 y fijar 2027-10-02 como fecha vigente | Ampliado, por describir | 2027-10-02 | +144.000.000 COP a registrar |
| B. Desconocer CC-01 hasta que se documente quién lo autorizó | Sin ampliación | Vuelve a una fecha original (2027-07-22 o 2027-09-06, a elegir) | Sin declarar |

**Recomendación:** A, condicionada a que quien autorizó CC-01 firme y que la solicitud de +30 días se devuelva hasta traer motivo, solicitante y costo (hoy no los tiene). Alternativa B solo si nadie puede acreditar la autorización original.

### [4] Hallazgo de seguridad en medios de pago: ¿un solo dueño y un solo plan, o uno por proyecto?
**Proyecto:** PRY-200, PRY-209, PRY-211 · **Quién decide:** comité · **Si no se decide hoy:** tres incidencias de seguridad sin dueño, con el mismo texto, en proyectos distintos.
Hecho: aparece idéntico en las tres fichas y en ninguna tiene dueño. No sé si es un hallazgo o tres; para PRY-209 (migración del ERP) y PRY-211 (pronóstico de demanda) no es evidente por qué tocan medios de pago.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Un dueño único que primero confirme si es uno o son tres | Posible ajuste en los afectados | Sin declarar | Sin declarar |
| B. Cada gerente lo resuelve en su proyecto | Sin cambio | Sin declarar | Se puede pagar tres veces lo mismo |

**Recomendación:** A. Una incidencia de seguridad sin dueño no debería esperar a que alguien aclare si son una o tres. Nombrar el dueño es la parte de la decisión; quién, no lo sé.

### [5] Cambio en la regulación de datos personales: ¿un dueño único del riesgo en los cuatro proyectos?
**Proyecto:** PRY-201, PRY-202, PRY-208, PRY-210 · **Quién decide:** comité · **Si no se decide hoy:** cuatro proyectos asumen por separado un factor externo común, sin que ninguno lo haya valorado.
Hecho: mismo riesgo, sin dueño, en cuatro fichas; no hay probabilidad ni impacto en ninguna.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Un dueño central valora el efecto sobre los cuatro | Se sabe cuánto mueve | Sin declarar | Sin declarar |
| B. Cada proyecto lo valora | Valoraciones que pueden diferir | Sin declarar | Sin declarar |

**Recomendación:** A. Es un mismo factor; valorarlo cuatro veces es repetir trabajo y arriesgar respuestas contradictorias.

### [6] Sobrecosto proyectado: ¿se exige solicitud de cambio o plan de contención a los proyectos sobre el umbral de 10 %?
**Proyecto:** PRY-206, PRY-211, PRY-208, PRY-202, PRY-200 · **Quién decide:** comité · **Si no se decide hoy:** cinco proyectos siguen ejecutando contra un aprobado que su propia proyección ya rebasa.

| Proyecto | Aprobado (COP) | Proyección (COP) | Sobre el aprobado | Estado declarado |
|---|---|---|---|---|
| PRY-206 Precios dinámicos | 800.000.000 | 1.014.297.933 | 26,8 % | verde |
| PRY-211 Pronóstico de demanda | 18.000.000.000 | 22.674.610.455 | 26,0 % | verde |
| PRY-208 Domicilios en dos horas | 6.800.000.000 | 8.460.416.780 | 24,4 % | verde |
| PRY-202 Centro de distribución norte | 4.200.000.000 | 5.168.800.668 | 23,1 % | amarillo |
| PRY-200 Tienda en línea | 9.500.000.000 | 11.453.287.850 | 20,6 % | verde |

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Cada gerente presenta solicitud de cambio o plan de contención antes del 2026-10-23 | Se revisa | Sin declarar | Se decide con cifra |
| B. Esperar al próximo informe | Sin cambio | Sin cambio | El sobrecosto sigue sin dueño |

**Recomendación:** A. Cuatro de los cinco reportan verde con una proyección que supera el umbral. La solicitud de cambio es el mecanismo previsto, y sin ella el aprobado deja de ser una referencia.

## Escalamientos sin decisión asociada
| Proyecto | Qué | Desde cuándo | Qué se necesita |
|---|---|---|---|
| PRY-209 | La fecha de cierre difiere entre el cronograma (2027-09-28) y el acta (2027-12-02), ambos del 2026-04-17. Además, un compromiso reprogramado 6 veces y otro 5 veces; avance declarado 71 % contra 25–50 % sostenido por el plan; verde declarado | 2026-04-17 (fechas); 2026-09-20 el primer compromiso | Que el comité diga qué fecha vale; si el punto 1 se decide, entra por change-control |
| Siete proyectos: PRY-199, 200, 202, 203, 204, 206, 209 | Supuesto sin verificar de disponibilidad de jefes de tienda para el piloto | 2026-09-23 a 2026-10-14 | Un dueño que confirme si son las mismas personas; si lo son, los pilotos compiten por ellas |
| PRY-202, 203, 204, 205, 206, 208, 210, 211 | Hitos declarados como cumplidos sin evidencia (en 8 proyectos) | Según cada hito | Que cada gerente adjunte el acta de recibo, o que se reclasifique el hito. No requiere decisión del comité |
| PRY-210 | 20 días sin movimiento (umbral 15), declarado verde con 20 % de avance contra 40–60 % sostenido | 2026-09-26 | Que el gerente responda por el silencio |

## Para conocimiento
- PRY-199 Iluminación LED: sin alertas; ficha sin proveedor facturado ni autoridad.
- PRY-201 Programa de fidelización: sin alertas; fecha de fin 2026-09-10 ya vencida según el plan (declara 81 % de avance). No sé si hay cierre pendiente.
- PRY-203 Reposición automática: amarillo; hito «Integración con el ERP» vencido hace 10 días (2026-10-06).
- PRY-204 Cajas de autopago: amarillo; hito vencido hace 3 días; último informe de hace 23 días.
- PRY-205 Pago con QR: rojo declarado; única alerta es un hito cumplido sin evidencia.
- 7 proyectos declaran verde contra alertas calculadas (PRY-200, 206, 207, 208, 209, 210, 211).
- Todos los proyectos: 13 de 13 sin autoridad en la ficha y 38 ítems RAID sin dueño ni fecha.

## Anexo
**Estado por proyecto** (declarado → alertas de `compute`): PRY-199 verde → 0 · PRY-200 verde → 4 · PRY-201 verde → 0 · PRY-202 amarillo → 7 · PRY-203 amarillo → 3 · PRY-204 amarillo → 4 · PRY-205 rojo → 1 · PRY-206 verde → 4 · PRY-207 verde → 3 · PRY-208 verde → 4 · PRY-209 verde → 14 · PRY-210 verde → 5 · PRY-211 verde → 5.

**Contradicciones abiertas:** PRY-209 fecha de cierre (acta vs cronograma); PRY-207 fecha de cierre (acta vs cronograma v1); PRY-209 compromisos reprogramados hasta el 2026-11-25.

**Vacíos de información:**
- Sin registro del comité anterior; no puedo cerrar el ciclo.
- Autoridad que aprueba cambios: no consta en ninguna de las 13 fichas.
- Dependencias entre proyectos: las 13 actas dicen «Ninguna declarada», así que no puedo cruzar fechas. Sospecha sin probar: PRY-209 (migración del ERP) y el hito «Integración con el ERP» de PRY-203 vencido y de PRY-200, 202 y 207.
- Probabilidad e impacto de los riesgos: ninguna fuente los trae.
- Solicitud de +30 días en PRY-207: sin solicitante ni motivo; por eso no se plantea como decisión.
- PRY-202: la ficha toma su información identitaria de un acta de 2025-06-24 (16 meses); su fecha de fin 2026-07-02 también pasó. No sé si hay replanificación sin documentar.
- Con una sola lectura del portafolio no se puede medir «dos períodos sin movimiento».

---
**Pie:** versión de la familia 0.3.11, plugin criterio-portfolio. Fichas aplicadas: 13 (`estado/records/`, lectura del 2026-10-16); reglas: raid-taxonomy y governance-artifacts. Campos inciertos: autoridad (13 de 13), dueño de los 38 ítems RAID, fecha vigente de cierre de PRY-207 y PRY-209, estado del comité anterior. Cifras derivadas copiadas de `portafolio.py compute`. Borrador de trabajo, no decisión ni asesoría; la verificación es de quien lo lea. Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.11

## Después
Cuando el comité sesione, puedo registrar sus decisiones en las fichas para que el próximo paquete cierre el ciclo.
