# Corrida del 2026-10-16 · document-index

13 proyectos · 34 s · 54 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 13 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 7 |
| `declared_vs_evidence` | 7 |
| `variance_cost` | 5 |
| `commitment_undated` | 5 |
| `milestone_overdue` | 2 |
| `commitment_rescheduled` | 2 |
| `rebaseline_unauthorized` | 1 |
| `variance_time` | 1 |
| `change_without_baseline` | 1 |
| `pm_vs_pmo` | 1 |
| `silent` | 1 |

72 documentos sin cambio, 0 por releer. 35 citas de PRY-209 sin resolver aunque los archivos existen y la ruta coincide byte a byte; causa no determinada, ninguna ficha modificada.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

## Carpeta al 2026-10-16

**Documentos:** 72 · **Sin cambio:** 72 · **Hay que releer:** 0

### Cambió el contenido
Nada. No hay documentos nuevos ni modificados.

### Solo se reguardó
Ninguno.

### Renombrado o movido
Ninguno.

### Ya no está
Ninguno.

### Citas que dejaron de resolver
El índice marca 35 citas de PRY-209 como "fuente ausente". Son todas las citas de ese proyecto:

| Proyecto | Campos | Documento citado |
|---|---|---|
| PRY-209 | identity.* (code, name, business_area, sponsor, manager, committee), plan.start_date, plan.end_date, plan.scope_summary, plan.exclusions, money.currency, money.approved | 00-gobierno/2026-04-17-acta-constitucion.md |
| PRY-209 | declared.status, declared.progress_pct, declared.as_of, money.committed, money.executed, money.projection | 20-seguimiento/2026-10-12-informe-avance.pdf |
| PRY-209 | plan.milestones[0..3] (name, baseline_date, current_date, state) | 10-plan/2026-04-17-cronograma-v1.csv |
| PRY-209 | plan.milestones[0].evidence | 20-seguimiento/2026-10-04-acta-recibo-diseño-de-la-experiencia-aprobado.pdf |

**Lo que no sé:** estos archivos sí existen en la carpeta `PRY-209-migración-del-erp/`, y los bytes de la ruta citada en `estado/records/PRY-209.json` coinciden con los del nombre de la carpeta (ambos con "ó" precompuesta). No encontré por qué el índice no los resuelve. Los otros 12 proyectos no tienen este problema. No corregí ninguna ficha. Hay que mirar cómo `portafolio.py index` resuelve la ruta de PRY-209. Pudo influir la carpeta `estado/PRY-209-migración-del-erp/`, que parece estar de más dentro de `estado`.

### Formatos que no se pudieron leer
Este comando no lee contenido, así que no evaluó formatos.

### Siguiente paso
No hay nada que releer, así que no ofrezco `/portfolio-scan`. Queda pendiente revisar las citas de PRY-209.
