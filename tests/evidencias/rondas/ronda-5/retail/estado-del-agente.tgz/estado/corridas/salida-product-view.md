# Vista por producto: puntos de fidelización

*Sale de las fichas en `estado/records/` y del cálculo `portafolio.py compute` al 2026-10-16. La ficha de PRY-201 se actualizó el 2026-10-16; su informe de avance es del 2026-10-13.*

## Productos al 2026-10-16

| Producto | Proyectos | Con alertas | Fecha más tardía | Aprobado | Comprometido |
|---|---|---|---|---|---|
| puntos de fidelización | 1 (PRY-201) | 0 | 2026-09-10 (PRY-201) | COP 6.800.000.000 | COP 4.318.579.944 |

**Este producto tiene un solo proyecto, PRY-201 «Programa de fidelización». La vista por producto no suma nada sobre la vista de proyecto, así que no armo sección aparte.** Lo que sigue es lo que sí conviene saber.

- **Alertas del cálculo: 0.** No hay silencio (3 días desde el último documento), ni replanificaciones, ni compromisos vencidos, ni cambios.
- **Fecha comprometida: 2026-09-10, ya vencida hace 36 días.** Es la fecha de la línea base v1 (acta del 2025-11-10) y no hay replanificación registrada. El informe declara verde y 81 % de avance (2026-10-13). El script no marca atraso porque la ficha no tiene hitos (`plan.milestones` está vacío): sin hitos no se puede contrastar el avance declarado contra el plan. **El verde no está sustentado ni contradicho: no hay con qué medirlo.** Lo que sí consta es que la fecha pasó con el proyecto declarado al 81 %.
- **Dinero (COP):** aprobado 6.800.000.000; comprometido 4.318.579.944 (63,5 %); ejecutado 2.579.519.333 (37,9 %); proyección 6.821.176.777 (0,3 % sobre lo aprobado, bajo el umbral de 10 %). Las cuatro cifras están, pero las tres que no son el aprobado salen del propio informe de avance, sin otro documento que las corrobore.
- **Incidencia abierta sin dueño:** «La prueba de carga de temporada no alcanzó el umbral pactado y se repite» (desde 2026-10-13). El informe la declara y aun así reporta verde. Los dos riesgos registrados (cambio en la regulación de datos personales; congelamiento de cambios en temporada alta) tampoco tienen dueño.
- **Dependencias internas:** no hay, porque es un solo proyecto. Dependencias declaradas: ninguna.
- **Huecos de la ficha:** no hay autoridad que apruebe (`identity.authority`) ni fase (`identity.phase`). El alcance del acta es genérico («tres componentes genéricos») y el área dueña es Talento humano, algo raro para un programa de puntos de fidelización de clientes. Lo dejo señalado y no lo interpreto.
- **Sin proveedores registrados** (`vendors` vacío), de modo que no hay entregables contractuales que contrastar.

### Proyectos sin producto declarado

Seis de los 13 proyectos del portafolio no declaran producto, y nadie puede responder por el conjunto al que sirven:

| Proyecto | Nombre |
|---|---|
| PRY-202 | Centro de distribución norte |
| PRY-203 | Reposición automática |
| PRY-206 | Precios dinámicos |
| PRY-209 | Migración del ERP |
| PRY-210 | Etiquetas electrónicas de precio |
| PRY-211 | Pronóstico de demanda |

(El cálculo no da el área dueña de estos proyectos; no la invento. Está en cada ficha.)

## Qué no sé

- Si el proyecto realmente va al 81 %: no hay hitos en la ficha ni documentos de evidencia (el cálculo cuenta 0 de evidencia, 0 de declaración y 14 sin marcar).
- Si hay una replanificación posterior al acta: no hay ninguna en los documentos leídos.
- Qué se habló fuera de los documentos.

**Decisión que se desprende:** no hay dependencias internas que llevar al comité de producto. Lo que sí necesita decisión es la fecha vencida de PRY-201 (replanificar con aprobación o explicar el atraso) y quién responde por la incidencia de la prueba de carga.

---
*Pie de rigor: Criterio produce borradores de trabajo, no decisiones ni asesoría. Cada dato sale de las fichas citadas y la verificación es de usted. Términos aceptados: v1.1 (familia 0.3.11), José Francisco Ñáñez, 2026-10-16.*
