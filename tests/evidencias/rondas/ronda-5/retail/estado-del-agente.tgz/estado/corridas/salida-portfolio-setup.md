## Listo — Portafolio retail

**Miré:** 72 documentos en 13 proyectos · formatos: .md (33), .docx (12), .pdf (11), .csv (7), .xlsx (7), .json (1), .txt (1) · más reciente: 2026-10-16
**Eres:** PMO del portafolio (propuesta por defecto: hay 13 proyectos)
**Te aviso:** dos días antes del comité semanal; primer comité tomado como 2026-10-23, así que el informe llega el 2026-10-21 (propuesta por defecto: los documentos son actas de comité semanal)
**En:** presentación (propuesta por defecto)
**Términos:** aceptados por José Francisco Ñáñez para la versión 0.3.11 (términos 1.1) · comprobante en `.criterio/terminos/aceptacion-criterio-portfolio-0.3.11-2026-10-16.md` y `.pdf` · SHA-256 41a739aec7049af3…
**Dónde queda todo:** configuración en `.criterio/portafolio/config.json`, lo que voy encontrando en `estado/`, informes en `reportes/`.

### Probé con tres proyectos
Los de documentación más reciente: PRY-208, PRY-209 y PRY-203.

| Proyecto | Documentos | Qué supe | Qué no está |
|---|---|---|---|
| PRY-208 Domicilios en dos horas | 4 | Gerente Ricardo Salas, patrocinador Liliana Torres. Declara verde, 59 %. Aprobado 6.800 M COP, ejecutado 3.915 M, proyección 8.460 M (informe 2026-10-12). | Facultad del gerente, fase |
| PRY-209 Migración del ERP | 16 | Gerente Liliana Torres, patrocinador Gustavo Neira. Declara verde, 71 %. Aprobado 2.400 M COP, ejecutado 1.178 M. 26 compromisos seguidos en seis comités y unas notas del 2026-10-16. Trae `ficha-pm.json` del gerente, que queda aparte. | Facultad del gerente, fase, producto |
| PRY-203 Reposición automática | 4 | Gerente Mauricio Pérez, patrocinador Óscar Ramírez. Declara amarillo, 38 %. Aprobado 18.000 M COP, ejecutado 10.027 M. | Facultad del gerente, fase, producto («No aplica») |

### Lo que levantó el cálculo (21 señales; en 2 de 3 proyectos el verde declarado queda contradicho)
**PRY-208**
- `declared_vs_evidence`: declara verde, pero la proyección supera lo aprobado en 24,4 % (`variance_cost`) y
- `milestone_met_without_evidence`: «Diseño de la experiencia aprobado» figura cerrado en el cronograma (2026-08-17) sin acta de recibo.
- `commitment_undated`: Javier Hoyos, «Entregar el punto 13», sin fecha (comité del 2026-10-16).

**PRY-209**
- `declared_vs_evidence`: declara verde con 71 %, pero tiene compromisos vencidos y reprogramados, y un avance por encima de lo que respalda el plan.
- `progress_vs_plan`: 71 % declarado frente a 1 de 4 hitos cumplidos (el plan respalda 25–50 %), 21 puntos por delante.
- `commitment_overdue` (6): Felipe Arango «documento 9» (9 días), Natalia Ospina «prueba 10» (7), Beatriz Cuéllar «anexo 11» (22), Javier Hoyos «matriz 14» (16), Carlos Peña «matriz 22» (1), Elena Duarte «fecha 23» (1). Dos de ellos (anexo 11 y prueba 10) los dieron por entregados en comité sin presentar acta; lo mismo con «fecha 7» de Óscar Ramírez, que ya no figura abierto.
- `commitment_rescheduled` (2): Natalia Ospina «documento 1», seis reprogramaciones (del 2026-09-20 al 2026-11-25); Mauricio Pérez «prueba 2», cinco (del 2026-09-30 al 2026-11-28).
- `commitment_undated` (3): Carlos Peña «ambiente 12», Javier Hoyos «ambiente 20», Laura Vélez «ajuste del presupuesto».
- `pm_vs_pmo`: la ficha del gerente da cierre 2027-12-02 (acta); el cronograma v1 termina el 2027-09-28. Las dos citan y no coinciden.
- Un riesgo dicho en reunión y que nadie anotó: el proveedor podría no llegar con el equipo completo (notas del 2026-10-16). Está en la ficha; no lo levantó el cálculo.
- El informe menciona un hallazgo de seguridad en medios de pago; consta como incidencia, sin responsable.

**PRY-203**
- `milestone_overdue`: «Integración con el ERP», vencido hace 10 días (2026-10-06).
- `milestone_met_without_evidence`: «Ambiente de pruebas certificado» figura cerrado (2026-08-06) sin acta. «Diseño de la experiencia aprobado» sí tiene acta (2026-10-15).
- `progress_vs_plan`: declara 38 %, el plan respalda 50–75 %, 12 puntos por detrás. El amarillo está declarado, no oculto.

Ninguno de los tres tiene la facultad del gerente en el acta, así que el control de cambios no sabría si algo la excede.

### El portafolio completo
10 proyectos más (PRY-199 a PRY-202, PRY-204 a PRY-207, PRY-210, PRY-211) y 48 documentos. Un lote de 10 y otro de 1, uno tras otro, sin leer lo que no cambió. Estimo unos 25–30 minutos.

### Lo que le falta a tu carpeta
Ninguno es bloqueante.
- Las actas no traen facultad del gerente ni fase.
- El alcance de las actas leídas es genérico («Componente 1, 2, 3»); no se puede contrastar contra el avance.
- Hitos cerrados sin acta de recibo: en 208 y 203. Cada acta de recibo que exista debe nombrar el hito que cierra.
- Compromisos sin fecha o con «por definir».
- En `estado/` ya existía una carpeta `PRY-209-migración-del-erp` de otra herramienta (criterio-project). No la toqué: las fichas del portafolio viven en `estado/records/`.
- Preguntas que tomé por defecto, sin respuesta de nadie: rol, comité semanal, próxima fecha 2026-10-23, formato presentación.
