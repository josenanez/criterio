# Corrida del 2026-10-16 · portfolio-wake

13 proyectos · 25 s · 54 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 13 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 7 |
| `declared_vs_evidence` | 7 |
| `variance_cost` | 5 |
| `commitment_undated` | 5 |
| `milestone_overdue` | 2 |
| `commitment_rescheduled` | 2 |
| `rebaseline_unauthorized` | 1 |
| `variance_time` | 1 |
| `change_without_baseline` | 1 |
| `pm_vs_pmo` | 1 |
| `silent` | 1 |

Barrido: 72 docs sin cambios, nada que recalcular. 35 citas de PRY-209 sin resolver aunque los archivos existen (causa no determinada). Confirmación no hecha: nadie puede responder.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

## 2026-10-16

**Revisé:** 72 documentos · 0 cambiaron · 0 proyectos recalculados

Términos vigentes (versión 1.1, aceptados el 2026-10-16 por José Francisco Ñáñez); no hubo que volver a registrarlos.

### Lo que cruzó un umbral
Nada por cambio de documentos. Un hallazgo de integridad: el índice reporta 35 citas de PRY-209 (migración del ERP) que no resuelven (`source_missing`): identidad, estado declarado, avance, fechas, hitos y cifras de dinero, citadas a `00-gobierno/2026-04-17-acta-constitucion.md`, `10-plan/2026-04-17-cronograma-v1.csv`, `20-seguimiento/2026-10-12-informe-avance.pdf` y `20-seguimiento/2026-10-04-acta-recibo-diseño-de-la-experiencia-aprobado.pdf`. Esos archivos sí existen en la carpeta del proyecto, así que el problema parece estar en cómo se resuelve la ruta de la ficha de PRY-209 y no en un documento borrado. No lo corregí: no sé la causa. Hasta entonces esos datos de PRY-209 no se pueden dar por sustentados. Además, `estado/` contiene una carpeta anidada `PRY-209-migración-del-erp/` con su propio estado, que no es lo esperado; tampoco la toqué.

### Peticiones atendidas
No se consultaron (`requests` no tocaba hoy).

### Preguntas
La confirmación periódica (5 campos) tocaba, pero no la hice: nadie puede responder en esta sesión, y con las citas de PRY-209 sin resolver el «dato actual» no se puede mostrar con su fuente. Queda pendiente, sin marcar como corrida.

**Vuelvo el 2026-10-17.**
