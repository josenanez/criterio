**Sale de:** las 13 fichas de `estado/records/` (sección `raid`), los 13 informes de avance (`20-seguimiento/`), las 13 actas de constitución (sección «Dependencias declaradas»), las 16 minutas y notas de reunión de la carpeta (`30-reuniones/` y `PRY-209…/2026-10-16-notas-reunion.txt`) y la salida de `portafolio.py compute` al 2026-10-16. Lo hablado fuera de esos documentos no lo conozco.

## RAID — Portafolio retail al 2026-10-16
**En el registro actual:** 22 riesgos · 0 supuestos · 16 incidencias · 0 dependencias (38 ítems)
**Con la clasificación que propongo:** 10 riesgos · 7 supuestos · 16 incidencias · 5 dependencias
38 sin doliente · 38 sin fecha objetivo · 1 no registrado formalmente · 0 con valoración de probabilidad e impacto

Escala: ninguna definida por la organización ni por las fichas. Usaría alta, media y baja; no valoré ninguno porque ninguna fuente trae probabilidad ni impacto, y inventarlos aparentaría una precisión que no hay.

**Lo que este registro no puede decir:** hay una sola lectura del portafolio (`snapshots/2026-10-16.json`). Sin lecturas anteriores no puedo medir «sin movimiento en dos períodos», así que ese conteo queda en «sin dato». La columna «Visto en» da la fecha del informe donde aparece el ítem, que es la primera vez que lo veo y no necesariamente cuándo empezó.

### Necesitan decisión ahora
| Id | Tipo | Qué | Doliente | Visto en | Por qué sube |
|---|---|---|---|---|---|
| PRY-200·I3, PRY-209·I1, PRY-211·I1 | Incidencia | Hallazgo de seguridad en los medios de pago | Sin doliente | 2026-10-13 / 10-12 / 10-07 | Aparece con el mismo texto en tres proyectos. No sé si es un solo hallazgo o tres; para PRY-209 (migración del ERP) y PRY-211 (pronóstico de demanda) llama la atención, y hay que confirmarlo con sus gerentes. Si es uno, afecta a otros proyectos y no tiene dueño. Si son tres, hay tres incidencias de seguridad sin dueño. Las dos lecturas piden una decisión. |
| PRY-201·R1, PRY-202·R1, PRY-208·R1, PRY-210·R1 | Riesgo | Cambio en la regulación de datos personales que puede mover el alcance | Sin doliente | 2026-10-13 / 10-11 / 10-12 / 09-26 | Un mismo factor externo sobre cuatro proyectos, sin que ninguno lo haya valorado ni lo tenga a su cargo. Cumple «afecta a otro proyecto del portafolio». |
| PRY-199·S1, 200·S1, 202·S1, 203·S1, 204·S1, 206·S1, 209·S1 | Supuesto | Disponibilidad de los jefes de tienda para el piloto | Sin doliente | 2026-09-23 a 10-14 | Siete proyectos dan por hecho el mismo recurso y ninguno lo ha verificado. No sé si son las mismas personas, pero si lo son, los pilotos compiten por ellas. Es un supuesto, no un riesgo: nadie lo ha confirmado. |
| PRY-200·I2 | Incidencia | Despliegue reprogramado por el congelamiento de fin de año | Sin doliente | 2026-10-13 | Ya movió la fecha 27 días (cronograma v2 del 2026-10-13) y la solicitud de cambio CC-01 sigue sin decisión. El efecto está en el plan sin que lo autorice nadie. Cumple «excede la autoridad del gerente». |
| PRY-201·I1, PRY-203·I2 | Incidencia | La prueba de carga de temporada no alcanzó el umbral pactado y se repite | Sin doliente | 2026-10-13 / 10-12 | Ya pasó y se repite sin fecha de nueva prueba. Con el congelamiento de cambios encima, una repetición que se corra tarde no tiene dónde desplegar. |
| PRY-209·R3 | Riesgo | El proveedor podría no llegar con el equipo completo para la siguiente fase | Sin doliente | 2026-10-16 (notas) | Dicho en reunión, ver la sección siguiente. El informe del 2026-10-12 no lo trae y el proyecto declara verde. |

### Detectados en reuniones, no registrados
| Qué | Tipo | Dicho en | Fecha |
|---|---|---|---|
| «Se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo» | Riesgo (también podría leerse como dependencia del proveedor; las notas no dicen quién es el proveedor ni cuál es la siguiente fase) | PRY-209, `2026-10-16-notas-reunion.txt` | 2026-10-16 |

Es el único. Leí las otras 15 minutas (una de cada PRY-199, 200, 202, 204, 205, 206, 207, 208 y 211, más las seis de PRY-209) y no traen ningún riesgo, supuesto ni dependencia dicho al pasar: solo compromisos. No inventé ninguno. Este ya está en la ficha de PRY-209 con su nota de origen, pero no en el informe de avance ni en el acta. **Formalizarlo es decisión del gerente (Liliana Torres).**

Fuera del RAID, pero que las minutas de PRY-209 muestran: «Enviar el documento 1» (Natalia Ospina) se ha movido 6 veces, desde 2026-09-20 hasta 2026-11-25, y «Cerrar la prueba 2» (Mauricio Pérez) 5 veces. Nadie lo dijo como riesgo. Es un patrón de los documentos, no un dicho, y es tema de `/pm-commitments`. Lo dejo aquí solo para que no se pierda.

### Reclasificados
Doce ítems, en siete proyectos, vienen en los informes como «riesgo» y la prueba rápida los clasifica distinto. Es una propuesta; la ficha no cambia hasta que el gerente la acepte.

| Qué dice el informe | Proyectos | Hoy | Propongo | Por qué |
|---|---|---|---|---|
| «Disponibilidad de los jefes de tienda para el piloto» | 199, 200, 202, 203, 204, 206, 209 | Riesgo | **Supuesto** | Se da por cierta la disponibilidad de una persona clave sin haberla verificado. Es de los supuestos que más fallan. |
| «El proveedor no ha confirmado la fecha de la última entrega» | 203, 204, 206, 207, 209 | Riesgo | **Dependencia** (declarada, no acordada) | Depende de un tercero fuera del proyecto. La contraparte no confirmó, así que no hay acuerdo. No hay código de proyecto del cual depender: es un proveedor, y en estas cinco carpetas no hay contrato ni nombre de proveedor para citarlo. |
| «Congelamiento de cambios en temporada alta» | 200, 205 | Riesgo | **Ya ocurrió: queda la incidencia** | Esos dos informes dicen además que el despliegue se reprogramó por el congelamiento. El riesgo se materializó y su incidencia ya está registrada, sin doliente. Para 201 y 208 sigue siendo riesgo. |

### Sin doliente o sin fecha
Los 38 ítems del registro, sin excepción: ninguno trae doliente (`owner: null`) y ninguno trae fecha objetivo ni de mitigación. No relleno ninguno. El detalle por proyecto está en el registro completo de abajo.

| Id | Tipo | Qué | Qué falta |
|---|---|---|---|
| Los 38 | Todos | Ver registro completo | Doliente y fecha |
| Los 22 ítems hoy registrados como riesgo | Riesgo / supuesto | Ver registro completo | Además, plan de mitigación o de validación: ninguna fuente lo menciona, así que no puedo decir si hay mitigación vencida sin evidencia. Es ausencia de dato, no ausencia de mitigaciones. |
| Las 16 incidencias | Incidencia | Ver registro completo | Fecha de resolución. La columna «desde» del registro es la fecha del informe, no la del hecho. |

### Dependencias en riesgo
**Ninguna registrada, y no por falta de búsqueda:** las 13 actas de constitución dicen «Ninguna declarada» en «Dependencias declaradas», y `compute` devuelve `dependencies: []` para los 13 proyectos. Por eso **no puedo hacer el cruce entre proyectos**: ningún proyecto declaró depender de otro, así que no hay fecha movida que contrastar.

| Id | Depende de | Confirmada | Qué pasó |
|---|---|---|---|
| (ninguna) | — | — | — |

Lo que sí hay son las cinco dependencias de proveedor que propongo arriba (203, 204, 206, 207, 209), todas sin confirmar. Y hay una pregunta abierta: PRY-209 migra el ERP y PRY-203 tiene un hito «Integración con el ERP» vencido hace 10 días (2026-10-06), igual que PRY-202 lo declara cumplido. Los documentos no dicen que uno dependa del otro. Lo pregunto, no lo afirmo: si el gerente de PRY-203 depende de PRY-209, esa dependencia está sin declarar.

### Registro completo
Ids provisionales (el registro no trae ninguno): proyecto + tipo + número. Tipo propuesto entre paréntesis cuando difiere del actual. Prob. e Impacto: «—» = sin valorar, ninguna fuente lo trae. Doliente: «sin doliente» en todos. Fecha objetivo: ninguna en todos. «Visto en» = fecha del informe (o de las notas) donde aparece; sin lecturas anteriores no puedo decir «último movimiento».

| Id | Tipo (actual → propuesto) | Qué | Prob. | Impacto | Doliente | Fecha | Visto en |
|---|---|---|---|---|---|---|---|
| 199·S1 | Riesgo → Supuesto | Disponibilidad de los jefes de tienda para el piloto | — | — | sin doliente | — | 2026-10-14 |
| 199·I1 | Incidencia | La validación con dos tiendas se extendió una semana por el conteo de inventario | — | — | sin doliente | — | 2026-10-14 |
| 200·R1 | Riesgo | Congelamiento de cambios en temporada alta (ya ocurrió: ver 200·I2) | — | — | sin doliente | — | 2026-10-13 |
| 200·S1 | Riesgo → Supuesto | Disponibilidad de los jefes de tienda para el piloto | — | — | sin doliente | — | 2026-10-13 |
| 200·I1 | Incidencia | La validación con dos tiendas se extendió una semana por el conteo de inventario | — | — | sin doliente | — | 2026-10-13 |
| 200·I2 | Incidencia | Despliegue reprogramado por el congelamiento de temporada de fin de año | — | — | sin doliente | — | 2026-10-13 |
| 200·I3 | Incidencia | Hallazgo de seguridad en los medios de pago | — | — | sin doliente | — | 2026-10-13 |
| 201·R1 | Riesgo | Cambio en la regulación de datos personales que puede mover el alcance | — | — | sin doliente | — | 2026-10-13 |
| 201·R2 | Riesgo | Congelamiento de cambios en temporada alta | — | — | sin doliente | — | 2026-10-13 |
| 201·I1 | Incidencia | La prueba de carga de temporada no alcanzó el umbral pactado y se repite | — | — | sin doliente | — | 2026-10-13 |
| 202·R1 | Riesgo | Cambio en la regulación de datos personales que puede mover el alcance | — | — | sin doliente | — | 2026-10-11 |
| 202·S1 | Riesgo → Supuesto | Disponibilidad de los jefes de tienda para el piloto | — | — | sin doliente | — | 2026-10-11 |
| 202·I1 | Incidencia | La validación con dos tiendas se extendió una semana por el conteo de inventario | — | — | sin doliente | — | 2026-10-11 |
| 203·D1 | Riesgo → Dependencia | El proveedor no ha confirmado la fecha de la última entrega | — | — | sin doliente | — | 2026-10-12 |
| 203·S1 | Riesgo → Supuesto | Disponibilidad de los jefes de tienda para el piloto | — | — | sin doliente | — | 2026-10-12 |
| 203·I1 | Incidencia | Pérdida de dos semanas por rotación de un desarrollador clave | — | — | sin doliente | — | 2026-10-12 |
| 203·I2 | Incidencia | La prueba de carga de temporada no alcanzó el umbral pactado y se repite | — | — | sin doliente | — | 2026-10-12 |
| 204·D1 | Riesgo → Dependencia | El proveedor no ha confirmado la fecha de la última entrega | — | — | sin doliente | — | 2026-09-23 |
| 204·S1 | Riesgo → Supuesto | Disponibilidad de los jefes de tienda para el piloto | — | — | sin doliente | — | 2026-09-23 |
| 204·I1 | Incidencia | Despliegue reprogramado por el congelamiento de temporada de fin de año | — | — | sin doliente | — | 2026-09-23 |
| 205·R1 | Riesgo | Congelamiento de cambios en temporada alta (ya ocurrió: ver 205·I1) | — | — | sin doliente | — | 2026-10-12 |
| 205·I1 | Incidencia | Despliegue reprogramado por el congelamiento de temporada de fin de año | — | — | sin doliente | — | 2026-10-12 |
| 206·S1 | Riesgo → Supuesto | Disponibilidad de los jefes de tienda para el piloto | — | — | sin doliente | — | 2026-10-04 |
| 206·D1 | Riesgo → Dependencia | El proveedor no ha confirmado la fecha de la última entrega | — | — | sin doliente | — | 2026-10-04 |
| 206·I1 | Incidencia | Despliegue reprogramado por el congelamiento de temporada de fin de año | — | — | sin doliente | — | 2026-10-04 |
| 207·D1 | Riesgo → Dependencia | El proveedor no ha confirmado la fecha de la última entrega | — | — | sin doliente | — | 2026-09-26 |
| 208·R1 | Riesgo | Cambio en la regulación de datos personales que puede mover el alcance | — | — | sin doliente | — | 2026-10-12 |
| 208·R2 | Riesgo | Congelamiento de cambios en temporada alta | — | — | sin doliente | — | 2026-10-12 |
| 209·S1 | Riesgo → Supuesto | Disponibilidad de los jefes de tienda para el piloto | — | — | sin doliente | — | 2026-10-12 |
| 209·D1 | Riesgo → Dependencia | El proveedor no ha confirmado la fecha de la última entrega | — | — | sin doliente | — | 2026-10-12 |
| 209·R3 | Riesgo (no registrado formalmente) | El proveedor podría no llegar con el equipo completo para la siguiente fase | — | — | sin doliente | — | 2026-10-16 |
| 209·I1 | Incidencia | Hallazgo de seguridad en los medios de pago | — | — | sin doliente | — | 2026-10-12 |
| 209·I2 | Incidencia | La validación con dos tiendas se extendió una semana por el conteo de inventario | — | — | sin doliente | — | 2026-10-12 |
| 210·R1 | Riesgo | Cambio en la regulación de datos personales que puede mover el alcance | — | — | sin doliente | — | 2026-09-26 |
| 210·I1 | Incidencia | La validación con dos tiendas se extendió una semana por el conteo de inventario | — | — | sin doliente | — | 2026-09-26 |
| 211·R1 | Riesgo | Concentración del conocimiento en una sola persona (la rotación ya ocurrió: ver 211·I2) | — | — | sin doliente | — | 2026-10-07 |
| 211·I1 | Incidencia | Hallazgo de seguridad en los medios de pago | — | — | sin doliente | — | 2026-10-07 |
| 211·I2 | Incidencia | El equipo perdió dos semanas por rotación de un desarrollador clave | — | — | sin doliente | — | 2026-10-07 |

### Después
- **Subir a comité** (próximo: 2026-10-23): los cinco primeros de «Necesitan decisión ahora», cada uno como decisión formulada y no como problema. Por ejemplo: «¿un solo dueño para la regulación de datos personales en los cuatro proyectos, sí o no, y quién?». Si quiere, los armo con `/steering-pack`.
- **Doliente: propongo, no asigno.** Para los ítems que viven en un solo proyecto, el candidato natural es su gerente según el acta; está en la ficha de cada uno. Para los que cruzan proyectos (seguridad de pagos, datos personales, jefes de tienda) no hay candidato evidente en los documentos, y elegirlo es de la PMO o del comité.
- Confirmar con los gerentes de PRY-200, PRY-209 y PRY-211 si el hallazgo de seguridad es uno o son tres.
- Pedir a cada patrocinador que declare dependencias entre proyectos: hoy las 13 actas dicen «Ninguna declarada», y sin eso este registro no puede cruzar nada.

---
**Rigor:** conteos copiados de las fichas y de `compute`, no recalculados a mano. Se leyeron las 13 fichas, 13 informes de avance, 13 actas de constitución (solo su sección de dependencias) y las 16 minutas y notas de reunión. No se leyeron los cronogramas, contratos ni actas de recibo más allá de lo que `compute` ya extrajo. La clasificación de 12 ítems es propuesta mía y no la validó nadie; ningún ítem tiene probabilidad, impacto, doliente ni fecha, porque las fuentes no los traen. Con una sola lectura no se puede medir movimiento. Todo lo que no está en los documentos, en particular lo hablado fuera de ellos, queda sin conocer.
