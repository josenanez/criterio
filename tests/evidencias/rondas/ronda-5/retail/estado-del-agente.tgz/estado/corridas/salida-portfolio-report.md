# Portafolio — 2026-10-16
13 proyectos · 11 con hallazgos (54 señales) · 7 productos · último barrido 2026-10-16 (fichas en `estado/records/`, todas con barrido de hoy; el silencio más largo es de 20 días).
Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-16).

## Qué cambió desde la corrida anterior
Sin cambios desde la corrida anterior (la instantánea 2026-10-16 es la única; el diff dio 0 cambios).

## Contradicciones abiertas
| Proyecto | Campo | Dice | Fuente | Dice también | Fuente |
|---|---|---|---|---|---|
| PRY-209 Migración del ERP | plan.end_date | 2027-09-28 | 10-plan/2026-04-17-cronograma-v1.csv (2026-04-17) | 2027-12-02 | 00-gobierno/2026-04-17-acta-constitucion.md (2026-04-17) |

## Hitos vencidos sin evidencia
| Proyecto | Hito | Fecha | Días | Última mención |
|---|---|---|---|---|
| PRY-203 | Integración con el ERP | 2026-10-06 | 10 | sin evidencia de cumplimiento |
| PRY-204 | Ambiente de pruebas certificado | 2026-10-13 | 3 | sin evidencia de cumplimiento |

Además, 13 hitos declarados "cumplidos" sin documento que lo respalde (ver "Sin sustento").
Compromisos vencidos: PRY-202 (1), PRY-204 (1), PRY-209 (6; el más viejo, 22 días: Beatriz Cuéllar, "Revisar el anexo 11"). PRY-209 tiene además dos compromisos reprogramados 6 y 5 veces (Natalia Ospina, "Enviar el documento 1"; Mauricio Pérez, "Cerrar la prueba 2") y tres sin fecha. Sin fecha también: PRY-208 (1), PRY-211 (1).

## Proyectos en silencio
| Proyecto | Días | Último documento |
|---|---|---|
| PRY-210 Etiquetas electrónicas de precio | 20 | 2026-09-26 (informe de avance) |

Umbral: 15 días. PRY-206 lleva 11, bajo el umbral.

## Dependencias en riesgo
Vacía: el script no detectó dependencias declaradas por código en riesgo.

## Sin sustento
Siete proyectos declaran verde y las señales lo contradicen:
| Proyecto | Declara | Qué lo respalda |
|---|---|---|
| PRY-200 Tienda en línea | verde (2026-10-13) | Nada: avance declarado 79% con 0 de 3 hitos cumplidos (el plan sostiene 0–33%); proyección +20,6% sobre 9.500 M COP; línea base movida 27 días sin cambio autorizado |
| PRY-206 Precios dinámicos | verde (2026-10-04) | 2 hitos "cumplidos" sin evidencia; proyección +26,8% |
| PRY-207 Marca propia | verde (2026-09-26) | Atraso de 72 días (15,8%) contra la original; CC-01 sin línea base |
| PRY-208 Domicilios en dos horas | verde (2026-10-12) | 1 hito sin evidencia; proyección +24,4% |
| PRY-209 Migración del ERP | verde (2026-10-12) | 6 compromisos vencidos, 2 reprogramados 5–6 veces; avance 71% declarado vs 25–50% sostenido |
| PRY-210 Etiquetas electrónicas | verde (2026-09-26) | 2 hitos sin evidencia; avance 20% vs 40–60% sostenido; 20 días en silencio |
| PRY-211 Pronóstico de demanda | verde (2026-10-07) | 1 hito sin evidencia; avance 30% vs 50–75%; proyección +26,0% |

Hitos declarados cumplidos sin evidencia: PRY-202 (4), PRY-203 (1), PRY-204 (1), PRY-205 (1), PRY-206 (2), PRY-208 (1), PRY-210 (2), PRY-211 (1).
Avance declarado por encima de lo que sostiene el plan: PRY-200, PRY-204, PRY-209. Por debajo: PRY-202 (63% con 4 de 4 hitos), PRY-203, PRY-210, PRY-211.

## Vacíos de información
| Proyecto | Qué falta |
|---|---|
| Los 13 | Sin autoridad (patrocinador/decisor) registrada |
| PRY-202, 203, 206, 209, 210, 211 | Sin producto asociado |

## Estado general
| Proyecto | Declarado | Sustento | Desviación vs original | vs vigente | Replanificaciones |
|---|---|---|---|---|---|
| PRY-199 | — | Sin hallazgos | 0 d | 0 d | 0 |
| PRY-200 | verde | Contradicho | 27 d | 0 d | 1 |
| PRY-201 | — | Sin hallazgos (fin previsto 2026-09-10, ya pasado) | 0 d | 0 d | 0 |
| PRY-202 | — | Hitos sin evidencia; +23,1% costo; fin previsto 2026-07-02 ya pasado | 0 d | 0 d | 0 |
| PRY-203 | — | Hito vencido; avance atrás | 0 d | 0 d | 0 |
| PRY-204 | — | Hito vencido; compromiso vencido | 0 d | 0 d | 0 |
| PRY-205 | — | 1 hito sin evidencia | 0 d | 0 d | 0 |
| PRY-206 | verde | Contradicho | 0 d | 0 d | 0 |
| PRY-207 | verde | Contradicho | 72 d | 0 d | 1 |
| PRY-208 | verde | Contradicho | 0 d | 0 d | 0 |
| PRY-209 | verde | Contradicho | 0 d | 0 d | 0 |
| PRY-210 | verde | Contradicho | 0 d | 0 d | 0 |
| PRY-211 | verde | Contradicho | 0 d | 0 d | 0 |

Costo sobre el umbral del 10%: PRY-200 (+20,6%), PRY-202 (+23,1%), PRY-206 (+26,8%), PRY-208 (+24,4%), PRY-211 (+26,0%).

## Necesito que confirmes
Los criterios de selección de los cinco campos más viejos no salieron del script en esta corrida; dejo una sola pregunta cerrada, la que tiene evidencia:
1. PRY-209: ¿la fecha de fin vigente es 2027-09-28 (cronograma) o 2027-12-02 (acta de constitución)?

---
Informe HTML (24 páginas) en `reportes/`:
- `reportes/index.html` — por campo, con la cadena de evidencia completa; para quien va a actuar.
- `reportes/decisiones.html` — por decisión; para el patrocinador.
- Una página por proyecto (`PRY-199.html` … `PRY-211.html`), además de productos y proyectos.
Para PDF, imprimir el HTML.

Pie: criterio-portfolio 0.3.11 · fichas de `estado/records/` con barrido 2026-10-16 · campos inciertos: plan.end_date de PRY-209 · términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.11
