# Corrida del 2026-10-16 · project-history

13 proyectos · 54 s · 54 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 13 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 7 |
| `declared_vs_evidence` | 7 |
| `variance_cost` | 5 |
| `commitment_undated` | 5 |
| `milestone_overdue` | 2 |
| `commitment_rescheduled` | 2 |
| `rebaseline_unauthorized` | 1 |
| `variance_time` | 1 |
| `change_without_baseline` | 1 |
| `pm_vs_pmo` | 1 |
| `silent` | 1 |

Historia de PRY-207 con 7 documentos (2026-04-13 a 2026-10-10). Hallazgos: cronograma v2 (09-26) anterior a CC-01 (10-08); verde declarado el 09-26 con +72 dias; CC-01 sin sesion ni autoridad verificable. No supe: cierre original valido (acta 2027-09-06 vs v1 2027-07-22), quien autorizo CC-01, que es el punto 32.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

## Historia · PRY-207 Marca propia de alimentos · 2026-04-13 a 2026-10-10

**Leí:** 7 documentos entre 2026-04-13 y 2026-10-10 (el acta de recibo en PDF no tiene texto extraído; de ella uso solo lo que dice su caché).
**Trimestres sin un solo documento:** ninguno. Pero entre 2026-04-13 y 2026-09-26 no hay ningún documento: en ese hueco cayó la fecha de línea base del primer hito (2026-07-23).

Términos: vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-16); no hubo que registrarlos de nuevo.

### En una línea
El proyecto nació el 2026-04-13 con cierre comprometido y cronograma v1; el 2026-09-26 el gerente declaró **verde, 37 %** en el mismo día en que el cronograma v2 ya corría el despliegue a 2027-10-02; la solicitud CC-01 que justifica ese corrimiento aparece recién el 2026-10-08, y el acta de recibo del primer hito, el 2026-10-04. Lo declarado como verde ya no se sostenía el día que se declaró.

### Las cuatro cifras
| Replanificaciones | Atraso acumulado vs. original | Meses declarando sin sustento | Cambios de gobierno |
|---|---|---|---|
| 1 | 72 días (15.8 %) | No calculable: hay una sola declaración (2026-09-26); sin serie no hay duración | 0 encontrados |

### Línea de tiempo
| Fecha | Documento | Qué cambió |
|---|---|---|
| 2026-04-13 | 00-gobierno/2026-04-13-acta-constitucion.docx | Se constituye el proyecto. Patrocinador Jorge Medina, gerente Natalia Ospina, Comité Comercial. Presupuesto 9.500.000.000 COP. Inicio 2026-04-23, cierre 2027-09-06. |
| 2026-04-13 | 10-plan/2026-04-13-cronograma-v1.xlsx | Línea base v1: 5 hitos, último (Despliegue en la cadena) 2027-07-22. El primer hito ya figura "cerrado" aunque su fecha es 2026-07-23. |
| 2026-09-26 | 10-plan/2026-09-26-cronograma-v2.csv | Despliegue pasa de 2027-07-22 a 2027-10-02. Los demás hitos no cambian. |
| 2026-09-26 | 20-seguimiento/2026-09-26-informe-avance.md | Estado **verde**, 37 %. Ejecutado 3.181.229.120; comprometido 3.421.382.411; proyección 8.945.455.871. Único riesgo: el proveedor no ha confirmado la fecha de la última entrega. No menciona el corrimiento. |
| 2026-10-04 | 20-seguimiento/2026-10-04-acta-recibo-… .pdf | Natalia Ospina recibe a satisfacción "Diseño de la experiencia aprobado". |
| 2026-10-08 | 20-seguimiento/2026-10-08-solicitud-cambio-cc-01.md | CC-01: ampliación de alcance, +72 días, +144.000.000 COP; "Autorizada por el comité". |
| 2026-10-10 | 30-reuniones/2026-10-10-comite-semanal.docx | Comité con Natalia Ospina y Jorge Medina. Temas: avance y compromisos. Un compromiso (Óscar Ramírez). No menciona CC-01. |

### Replanificaciones
| Nº | Fecha | Fecha de cierre nueva | Motivo declarado | Documento que la aprobó |
|---|---|---|---|---|
| 1 | 2026-09-26 (fecha del cronograma v2) | 2027-10-02 | Ninguno en el cronograma ni en el informe. El único motivo escrito es CC-01 (ampliación de alcance), fechada 2026-10-08, posterior al cronograma. | CC-01: "Autorizada por el comité"; el documento no nombra quién ni en qué sesión. El acta del comité del 2026-10-10 no la menciona. |

Hallazgos sobre esta replanificación:
- El cronograma v2 (2026-09-26) precede a la solicitud que lo justifica (2026-10-08). O el cambio se aplicó antes de pedirse, o la fecha del cronograma no es la de su edición. El archivo no permite distinguirlo.
- El `compute` marca CC-01 como **aprobada sin línea base nueva** que la recoja con su fecha de autorización: 72 días.
- El acta fija el cierre en 2027-09-06; la línea base v1 termina el 2027-07-22. Son dos fechas de cierre originales distintas. Las cifras de arriba usan la de v1, que es la que calcula el script. Contra el acta de constitución el atraso sería otro número y el script no lo da.

### Gobierno
| Fecha | Qué cambió | Documento |
|---|---|---|
| — | Ningún cambio de patrocinador, gerente o comité en los documentos. Jorge Medina y Natalia Ospina figuran desde 2026-04-13 hasta 2026-10-10. | acta y acta de comité |

Sin dato: autoridad que aprueba (`identity.authority`) y fase (`identity.phase`). Con eso no se puede decir quién tenía facultad para autorizar CC-01.

### Compromisos que se repitieron
| Doliente | Qué | Veces | Fechas prometidas |
|---|---|---|---|
| Óscar Ramírez | "Entregar el punto 32" | 1 | 2026-11-14 |

Ninguno se repitió. Está abierto y no vencido. "El punto 32" no se identifica en ningún documento leído.

### Desde cuándo lo declarado no se sostiene
**2026-09-26.** El informe de esa fecha declara verde; el cronograma v2 de la misma fecha ya trae +72 días en el despliegue (señal `variance_time`, sin explicar en el informe). Hay una sola declaración, así que no se puede hablar de deslizamiento: solo se puede decir que la primera que existe ya difiere de la evidencia.
Matices:
- Avance 37 % cae dentro de lo que el plan sostiene (20 %–40 %, 1 de 5 hitos cumplido): ese número no está contradicho.
- El primer hito figuraba "cerrado" en el cronograma del 2026-09-26, pero su acta de recibo es del 2026-10-04. Al declarar, el cierre no tenía el acta.
- Qué se siguió reportando después: no hay informe posterior al 2026-09-26 (último dato declarado, de hace 20 días).

### Lecciones ancladas a un hecho
- **Hecho:** cronograma v2 (2026-09-26) mueve el despliegue +72 días y el informe del mismo día declara verde sin mencionarlo. **Efecto:** el color declarado no tuvo el corrimiento; para lo que cuenta como verde, la solicitud de cambio debió existir antes del informe.
- **Hecho:** CC-01 (2026-10-08) dice "autorizada por el comité" sin nombrar sesión, y el acta del comité del 2026-10-10 no la menciona. **Efecto:** la autorización no se puede verificar en documentos.
- **Hecho:** el hito del 2026-07-23 figura "cerrado" desde el cronograma v1 (2026-04-13) y su acta de recibo es del 2026-10-04. **Efecto:** el estado "cerrado" del plan no es evidencia de entrega.

### Lo que no sé
- Si el cronograma v2 se editó antes de CC-01 o si su fecha es la de otro evento.
- Quién autorizó CC-01 y en qué sesión.
- Cuál es el cierre original válido (2027-09-06 del acta o 2027-07-22 de v1).
- Qué es "el punto 32" y quién es Óscar Ramírez en el proyecto.
- Quién es dueño del único riesgo registrado (no tiene responsable).
- Si los 144.000.000 COP de CC-01 están en la proyección de 8.945.455.871 (esa es de 2026-09-26, anterior a CC-01).

Nada de esto atribuye intención: el orden de las fechas tiene explicaciones inocentes posibles (por ejemplo, una autorización verbal previa). Es la conversación que conviene tener con Natalia Ospina y Jorge Medina, con estos documentos en la mesa.

**Pie de rigor:** 7 documentos leídos del caché de texto; cifras copiadas de `portafolio.py compute` (as_of 2026-10-16). Todo lo demás es lectura directa de los documentos citados. Borrador de trabajo: verifique cada dato contra el original.

Siguiente paso posible: llevar esta historia al comité del 2026-10-23, donde hay una decisión que sale de ella (formalizar CC-01 y su línea base).
