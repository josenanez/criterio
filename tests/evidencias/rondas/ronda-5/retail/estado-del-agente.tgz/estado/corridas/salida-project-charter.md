Acta previa: sí, del 2025-11-10 (aprobada por el Comité de Arquitectura). Términos vigentes: v1.1, aceptados por José Francisco Ñáñez el 2026-10-16 (comprobante ya registrado, no se repitió).

## Acta — PRY-201 Programa de fidelización
**Estado:** existe, del 2025-11-10 · `PRY-201-programa-de-fidelización/00-gobierno/2025-11-10-acta-constitucion.docx`

### Qué falta
| Campo | Estado | Consecuencia |
|---|---|---|
| **Autoridad del gerente** | No está | Liliana Torres no tiene declarado hasta qué monto ni qué cambio de alcance o fecha decide sin comité. Cualquier cambio sube al Comité de Arquitectura por defecto. Hoy pesa: la prueba de carga fallida se repite y la fecha de cierre ya pasó, y nadie puede decir si ajustar eso es del gerente o del comité. |
| Objetivo de negocio | Describe la entrega, no el resultado: "Entregar programa de fidelización para Talento humano" | No hay nada contra qué decidir si el proyecto valió la pena ni cuándo parar. Se puede entregar el programa y no lograr ningún efecto de negocio. |
| Alcance | "Componente 1, 2, 3", sin contenido | Alcance sin contenido no se puede defender ni medir. Cualquier solicitud de cambio se discute sin referencia, y el cambio regulatorio que el informe declara como riesgo no tiene contra qué compararse. |
| Exclusiones | Una sola, vacía: "Lo que otro proyecto cubre" | No dice qué proyecto ni qué cubre. Si hay traslape con otro proyecto del portafolio, el acta no lo detecta ni lo impide. |
| Criterio de éxito | "En producción y medido": sin métrica, umbral ni fecha | "Medido" no dice qué se mide. El proyecto no puede cerrarse contra un criterio verificable. |
| Quién mide el éxito | No está | Sin evaluador designado, el éxito lo declara el propio gerente. |
| Patrocinador | Laura Vélez (nombre de persona) | Cumple. Dato a confirmar: el acta pone como área dueña a Talento humano para un programa de puntos de fidelización. Si el programa es de clientes, el patrocinador o el área pueden estar mal asignados. |
| Comité y cadencia | Comité de Arquitectura, sin cadencia | Un comité de arquitectura aprobó 6.800 millones COP de un programa de fidelización. Es dudoso que sea la instancia de gobierno de negocio correcta. Sin cadencia, nadie sabe cuándo se revisa. |
| Supuestos | No están | El informe de 2026-10-13 declara riesgos (regulación de datos personales, congelamiento en temporada alta) que nacen de supuestos nunca escritos. |
| Restricciones | No están | El congelamiento de cambios en temporada alta es una restricción conocida y no consta en el acta. |
| Dependencias | "Ninguna declarada" | Contradice los riesgos del informe, que sí dependen de la regulación y del calendario de temporada. |
| Hitos | No están | Con un único par inicio/cierre, el atraso solo es visible cuando ya venció todo. |

### Contenido
**Objetivo de negocio:** pendiente de definir. El acta dice "Entregar programa de fidelización para Talento humano", que es la solución. (Acta 2025-11-10)
**Alcance:** "Componente 1, Componente 2, Componente 3". Pendiente de definir qué es cada uno. (Acta 2025-11-10)
**Exclusiones:** "Lo que otro proyecto cubre". Pendiente de definir cuál. (Acta 2025-11-10)
**Patrocinador:** Laura Vélez · **Gerente:** Liliana Torres (Acta 2025-11-10)
**Autoridad del gerente:** pendiente de definir. No consta en ningún documento.
**Comité al que reporta:** Comité de Arquitectura (Acta 2025-11-10) · **Cadencia:** pendiente de definir.
**Supuestos:** pendiente de definir · **Restricciones:** pendiente de definir.
**Criterio de éxito:** "Programa de fidelización en producción y medido" (Acta 2025-11-10); falta métrica y umbral · **Lo mide:** pendiente de definir.
**Hitos principales:** pendiente de definir. Solo constan inicio 2025-11-20 y cierre 2026-09-10. Presupuesto aprobado: 6.800.000.000 COP (Acta 2025-11-10).

### Lo que el acta deja ver hoy
- La fecha de cierre comprometida (2026-09-10) venció hace 36 días. El informe del 2026-10-13 declara **verde, 81%** y no menciona la fecha ni una línea base nueva. El acta no da al gerente autoridad para mover la fecha, y la ficha no registra ningún cambio aprobado.
- La proyección (6.821.176.777) supera el aprobado (6.800.000.000) en 21.176.777 COP (0,3%). Sin autoridad declarada, no se sabe si eso lo decide el gerente o el comité.

### Después
- **Autoridad del gerente:** esta definición hay que llevarla al comité. Es una decisión, no un trámite. ¿La preparo con `/steering-pack`?
- **Supuestos:** de la revisión salen dos que el informe da por hechos (la regulación de datos personales no cambia el alcance; no hay congelamiento que mueva el cierre). ¿Los paso al registro RAID con `/raid-log`?

---
Pie de rigor: esta revisión se basa en dos documentos (el acta .docx y el informe de avance del 2026-10-13). No sé lo que se haya hablado fuera de ellos. Nada se completó con lo razonable: lo que no está queda como pendiente de definir. Verificar contra los originales es responsabilidad de quien decide.
