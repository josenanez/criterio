<!-- origen: PRY-211-pronóstico-de-demanda/10-plan/2025-12-28-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la experiencia aprobado | 2026-05-08 | 2026-05-08 | cerrado
Ambiente de pruebas certificado | 2026-09-07 | 2026-09-07 | cerrado
Integración con el ERP | 2027-01-06 | 2027-01-06 | en curso
Piloto en tiendas | 2027-05-08 | 2027-05-08 | en curso
