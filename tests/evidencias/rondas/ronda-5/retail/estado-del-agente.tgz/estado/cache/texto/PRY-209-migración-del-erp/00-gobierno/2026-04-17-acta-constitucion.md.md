<!-- origen: PRY-209-migración-del-erp/00-gobierno/2026-04-17-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Migración del ERP

**Código:** PRY-209
**Área dueña:** Comercio electrónico
**Patrocinador:** Gustavo Neira
**Gerente de proyecto:** Liliana Torres
**Comité:** Comité de Arquitectura
**Producto asociado:** No aplica
**Fecha de aprobación:** 2026-04-17

## Objetivo del negocio

Entregar migración del erp para Comercio electrónico.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**2.400.000.000 COP**, aprobado por Comité de Arquitectura el 2026-04-17.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-04-27 |
| Cierre | 2027-12-02 |

## Criterio de éxito

Migración del ERP en producción y medido.

## Dependencias declaradas

- Ninguna declarada
