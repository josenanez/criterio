<!-- origen: PRY-208-domicilios-en-dos-horas/20-seguimiento/2026-10-12-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Domicilios en dos horas
Código: PRY-208
Fecha de corte: 2026-10-12
Gerente: Ricardo Salas

Estado declarado
Verde
Avance reportado: 59%

Lo que pasó en el periodo
- Se recibió el concepto de Jurídica sobre los términos de uso

Presupuesto
COP
Aprobado 6.800.000.000
Comprometido 3.705.535.176
Ejecutado 3.915.265.504
Proyección al cierre 8.460.416.780

Riesgos abiertos
- Cambio en la regulación de datos personales que puede mover el alcance
- Congelamiento de cambios en temporada alta
