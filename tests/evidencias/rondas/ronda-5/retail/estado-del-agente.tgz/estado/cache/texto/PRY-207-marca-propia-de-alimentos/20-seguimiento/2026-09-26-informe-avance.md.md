<!-- origen: PRY-207-marca-propia-de-alimentos/20-seguimiento/2026-09-26-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Marca propia de alimentos

**Código:** PRY-207
**Fecha de corte:** 2026-09-26
**Gerente:** Natalia Ospina

## Estado declarado

**Verde**

Avance reportado: **37%**

## Lo que pasó en el periodo

- Se acordó con arquitectura cómo se revisan los requisitos no funcionales

## Presupuesto

| | COP |
|---|---|
| Aprobado | 9.500.000.000 |
| Comprometido | 3.421.382.411 |
| Ejecutado | 3.181.229.120 |
| Proyección al cierre | 8.945.455.871 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
