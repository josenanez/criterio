<!-- origen: PRY-203-reposición-automática/20-seguimiento/2026-10-12-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Reposición automática
Código: PRY-203
Fecha de corte: 2026-10-12
Gerente: Mauricio Pérez

Estado declarado
Amarillo
Avance reportado: 38%

Lo que pasó en el periodo
- El equipo perdió dos semanas por rotación de un desarrollador clave
- La prueba de carga de temporada no alcanzó el umbral pactado y se repite
- Se reprogramó el despliegue por el congelamiento de temporada de fin de año

Presupuesto
COP
Aprobado 18.000.000.000
Comprometido 14.815.565.364
Ejecutado 10.027.497.573
Proyección al cierre 16.647.090.536

Riesgos abiertos
- El proveedor no ha confirmado la fecha de la última entrega
- Disponibilidad de los jefes de tienda para el piloto
