<!-- origen: PRY-209-migración-del-erp/30-reuniones/2026-10-02-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Arquitectura · Migración del ERP

**Fecha:** 2026-10-02
**Asistentes:** Andrés Lozano, Diana Molina, Elena Duarte, Felipe Arango, Javier Hoyos, Laura Vélez, Liliana Torres, Mauricio Pérez, Natalia Ospina, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Natalia Ospina | Enviar el documento 1 | 2026-11-03 |
| Mauricio Pérez | Cerrar la prueba 2 | 2026-11-13 |
| Óscar Ramírez | Revisar el anexo 3 | 2026-10-21 |
| Laura Vélez | Aprobar el diseño 5 | 2026-10-19 |
| Andrés Lozano | Actualizar la matriz 6 | 2026-10-23 |
| Óscar Ramírez | Confirmar la fecha 7 | 2026-10-25 |
| Felipe Arango | Enviar el documento 9 | 2026-10-07 |
| Natalia Ospina | Aprobar el diseño 13 | 2026-10-23 |
| Javier Hoyos | Actualizar la matriz 14 | 2026-09-30 |
| Mauricio Pérez | Confirmar la fecha 15 | 2026-10-04 |
| Óscar Ramírez | Entregar el punto 16 | 2026-10-29 |
| Elena Duarte | Enviar el documento 17 | 2026-10-23 |
| Diana Molina | Cerrar la prueba 18 | 2026-10-27 |
| Elena Duarte | Revisar el anexo 19 | 2026-10-27 |
| Javier Hoyos | Validar el ambiente 20 | por definir |

## Cerrados en esta reunión

- Validar el ambiente 4 (Mauricio Pérez): recibido, acta de recibo del 2026-10-02.

## Lo que se dijo

- Natalia Ospina dice que ya entregó «cerrar la prueba 10». No se presentó acta.
- Carlos Peña dice que ya entregó «validar el ambiente 12». No se presentó acta.
