<!-- origen: PRY-202-centro-de-distribución-norte/10-plan/2025-06-24-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño de la experiencia aprobado,2025-10-02,2025-10-02,cerrado
Ambiente de pruebas certificado,2026-01-01,2026-01-01,cerrado
Integración con el ERP,2026-04-02,2026-04-02,cerrado
Piloto en tiendas,2026-07-02,2026-07-02,cerrado
