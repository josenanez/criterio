<!-- origen: PRY-206-precios-dinámicos/30-reuniones/2026-10-05-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Expansión · Precios dinámicos

**Fecha:** 2026-10-05
**Asistentes:** Beatriz Cuéllar, Gustavo Neira

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Jorge Medina | Entregar el punto 17 | 2026-10-28 |
