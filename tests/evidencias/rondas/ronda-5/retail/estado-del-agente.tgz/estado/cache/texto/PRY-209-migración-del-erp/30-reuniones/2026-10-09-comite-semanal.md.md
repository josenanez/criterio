<!-- origen: PRY-209-migración-del-erp/30-reuniones/2026-10-09-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Arquitectura · Migración del ERP

**Fecha:** 2026-10-09
**Asistentes:** Andrés Lozano, Carlos Peña, Diana Molina, Elena Duarte, Felipe Arango, Javier Hoyos, Laura Vélez, Liliana Torres, Mauricio Pérez, Natalia Ospina, Paula Céspedes, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Natalia Ospina | Enviar el documento 1 | 2026-11-11 |
| Mauricio Pérez | Cerrar la prueba 2 | 2026-11-28 |
| Óscar Ramírez | Revisar el anexo 3 | 2026-10-21 |
| Laura Vélez | Aprobar el diseño 5 | 2026-10-19 |
| Andrés Lozano | Actualizar la matriz 6 | 2026-11-13 |
| Felipe Arango | Enviar el documento 9 | 2026-10-07 |
| Javier Hoyos | Actualizar la matriz 14 | 2026-09-30 |
| Óscar Ramírez | Entregar el punto 16 | 2026-10-29 |
| Elena Duarte | Enviar el documento 17 | 2026-11-08 |
| Diana Molina | Cerrar la prueba 18 | 2026-10-27 |
| Elena Duarte | Revisar el anexo 19 | 2026-10-27 |
| Javier Hoyos | Validar el ambiente 20 | por definir |
| Paula Céspedes | Aprobar el diseño 21 | 2026-10-24 |
| Carlos Peña | Actualizar la matriz 22 | 2026-10-15 |
| Elena Duarte | Confirmar la fecha 23 | 2026-10-15 |
| Andrés Lozano | Entregar el punto 24 | 2026-10-18 |

## Cerrados en esta reunión

- Aprobar el diseño 13 (Natalia Ospina): recibido, acta de recibo del 2026-10-09.
- Confirmar la fecha 15 (Mauricio Pérez): recibido, acta de recibo del 2026-10-09.

## Lo que se dijo

- Óscar Ramírez dice que ya entregó «confirmar la fecha 7». No se presentó acta.
