<!-- origen: PRY-205-pago-con-qr-en-caja/20-seguimiento/2026-10-12-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Pago con QR en caja
Código: PRY-205
Fecha de corte: 2026-10-12
Gerente: Sandra Gil

Estado declarado
Rojo
Avance reportado: 73%

Lo que pasó en el periodo
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales
- Se reprogramó el despliegue por el congelamiento de temporada de fin de año

Presupuesto
COP
Aprobado 1.200.000.000
Comprometido 504.620.966
Ejecutado 622.257.246
Proyección al cierre 1.167.795.553

Riesgos abiertos
- Congelamiento de cambios en temporada alta
