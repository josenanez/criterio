<!-- origen: PRY-202-centro-de-distribución-norte/00-gobierno/2025-06-24-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Centro de distribución norte

Código: PRY-202

Área dueña: Comercio electrónico

Patrocinador: Camilo Beltrán

Gerente de proyecto: Laura Vélez

Comité: Comité de Transformación Digital

Producto asociado: No aplica

Fecha de aprobación: 2025-06-24

Objetivo del negocio

Entregar centro de distribución norte para Comercio electrónico.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

4.200.000.000 COP, aprobado por Comité de Transformación Digital el 2025-06-24.

Fechas comprometidas

Fecha

Inicio

2025-07-04

Cierre

2026-08-17

Criterio de éxito

Centro de distribución norte en producción y medido.

Dependencias declaradas

• Ninguna declarada
