<!-- origen: PRY-207-marca-propia-de-alimentos/10-plan/2026-09-26-cronograma-v2.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño de la experiencia aprobado,2026-07-23,2026-07-23,cerrado
Ambiente de pruebas certificado,2026-10-22,2026-10-22,en curso
Integración con el ERP,2027-01-21,2027-01-21,en curso
Piloto en tiendas,2027-04-22,2027-04-22,en curso
Despliegue en la cadena,2027-07-22,2027-10-02,en curso
