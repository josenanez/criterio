<!-- origen: PRY-201-programa-de-fidelización/20-seguimiento/2026-10-13-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Programa de fidelización

**Código:** PRY-201
**Fecha de corte:** 2026-10-13
**Gerente:** Liliana Torres

## Estado declarado

**Verde**

Avance reportado: **81%**

## Lo que pasó en el periodo

- Se acordó con arquitectura cómo se revisan los requisitos no funcionales
- La prueba de carga de temporada no alcanzó el umbral pactado y se repite

## Presupuesto

| | COP |
|---|---|
| Aprobado | 6.800.000.000 |
| Comprometido | 4.318.579.944 |
| Ejecutado | 2.579.519.333 |
| Proyección al cierre | 6.821.176.777 |

## Riesgos abiertos

- Cambio en la regulación de datos personales que puede mover el alcance
- Congelamiento de cambios en temporada alta
