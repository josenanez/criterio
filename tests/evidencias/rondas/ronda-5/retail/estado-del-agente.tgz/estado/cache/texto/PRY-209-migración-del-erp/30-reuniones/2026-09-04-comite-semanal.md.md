<!-- origen: PRY-209-migración-del-erp/30-reuniones/2026-09-04-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Arquitectura · Migración del ERP

**Fecha:** 2026-09-04
**Asistentes:** Liliana Torres, Mauricio Pérez, Natalia Ospina, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Natalia Ospina | Enviar el documento 1 | 2026-09-20 |
| Mauricio Pérez | Cerrar la prueba 2 | 2026-09-30 |
| Óscar Ramírez | Revisar el anexo 3 | 2026-09-10 |
| Mauricio Pérez | Validar el ambiente 4 | 2026-09-27 |
