<!-- origen: PRY-209-migración-del-erp/20-seguimiento/2026-10-12-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Migración del ERP
Código: PRY-209
Fecha de corte: 2026-10-12
Gerente: Liliana Torres

Estado declarado
Verde
Avance reportado: 71%

Lo que pasó en el periodo
- La validación con dos tiendas se extendió una semana por el conteo de inventario
- Se levantó un hallazgo de seguridad en los medios de pago

Presupuesto
COP
Aprobado 2.400.000.000
Comprometido 737.951.290
Ejecutado 1.177.731.702
Proyección al cierre 2.294.519.534

Riesgos abiertos
- Disponibilidad de los jefes de tienda para el piloto
- El proveedor no ha confirmado la fecha de la última entrega
