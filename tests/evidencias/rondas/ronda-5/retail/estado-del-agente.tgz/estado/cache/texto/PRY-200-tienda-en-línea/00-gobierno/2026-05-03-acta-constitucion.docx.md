<!-- origen: PRY-200-tienda-en-línea/00-gobierno/2026-05-03-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Tienda en línea

Código: PRY-200

Área dueña: Servicio al cliente

Patrocinador: Paula Céspedes

Gerente de proyecto: Beatriz Cuéllar

Comité: Comité Comercial

Producto asociado: venta en línea

Fecha de aprobación: 2026-05-03

Objetivo del negocio

Entregar tienda en línea para Servicio al cliente.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

9.500.000.000 COP, aprobado por Comité Comercial el 2026-05-03.

Fechas comprometidas

Fecha

Inicio

2026-05-13

Cierre

2027-11-19

Criterio de éxito

Tienda en línea en producción y medido.

Dependencias declaradas

• Ninguna declarada
