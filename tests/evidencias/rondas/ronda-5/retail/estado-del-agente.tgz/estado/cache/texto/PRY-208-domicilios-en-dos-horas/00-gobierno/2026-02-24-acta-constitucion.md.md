<!-- origen: PRY-208-domicilios-en-dos-horas/00-gobierno/2026-02-24-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Domicilios en dos horas

**Código:** PRY-208
**Área dueña:** Mercadeo
**Patrocinador:** Liliana Torres
**Gerente de proyecto:** Ricardo Salas
**Comité:** Comité de Transformación Digital
**Producto asociado:** entrega rápida
**Fecha de aprobación:** 2026-02-24

## Objetivo del negocio

Entregar domicilios en dos horas para Mercadeo.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**6.800.000.000 COP**, aprobado por Comité de Transformación Digital el 2026-02-24.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-03-06 |
| Cierre | 2027-10-04 |

## Criterio de éxito

Domicilios en dos horas en producción y medido.

## Dependencias declaradas

- Ninguna declarada
