<!-- origen: PRY-210-etiquetas-electrónicas-de-precio/20-seguimiento/2026-09-26-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Etiquetas electrónicas de precio

**Código:** PRY-210
**Fecha de corte:** 2026-09-26
**Gerente:** Paula Céspedes

## Estado declarado

**Verde**

Avance reportado: **20%**

## Lo que pasó en el periodo

- Se ajustó el plan de pruebas con el área de seguridad
- La validación con dos tiendas se extendió una semana por el conteo de inventario
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales

## Presupuesto

| | COP |
|---|---|
| Aprobado | 2.400.000.000 |
| Comprometido | 871.665.846 |
| Ejecutado | 760.497.920 |
| Proyección al cierre | 2.283.077.690 |

## Riesgos abiertos

- Cambio en la regulación de datos personales que puede mover el alcance
