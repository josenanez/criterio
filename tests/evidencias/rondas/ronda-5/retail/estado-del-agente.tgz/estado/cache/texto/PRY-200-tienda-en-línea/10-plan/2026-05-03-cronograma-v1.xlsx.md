<!-- origen: PRY-200-tienda-en-línea/10-plan/2026-05-03-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la experiencia aprobado | 2026-10-18 | 2026-10-18 | en curso
Ambiente de pruebas certificado | 2027-03-26 | 2027-03-26 | en curso
Integración con el ERP | 2027-08-31 | 2027-08-31 | en curso
