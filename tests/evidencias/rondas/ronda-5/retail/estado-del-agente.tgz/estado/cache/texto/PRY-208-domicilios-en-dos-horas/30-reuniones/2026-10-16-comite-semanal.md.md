<!-- origen: PRY-208-domicilios-en-dos-horas/30-reuniones/2026-10-16-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Transformación Digital · Domicilios en dos horas

**Fecha:** 2026-10-16
**Asistentes:** Ricardo Salas, Liliana Torres

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Javier Hoyos | Entregar el punto 13 | por definir |
