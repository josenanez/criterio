<!-- origen: PRY-204-cajas-de-autopago/30-reuniones/2026-10-12-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Transformación Digital · Cajas de autopago

**Fecha:** 2026-10-12
**Asistentes:** Javier Hoyos, María Restrepo

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Paula Céspedes | Entregar el punto 2 | 2026-10-13 |
