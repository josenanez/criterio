<!-- origen: PRY-204-cajas-de-autopago/10-plan/2026-06-02-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la experiencia aprobado | 2026-08-12 | 2026-08-12 | cerrado
Ambiente de pruebas certificado | 2026-10-13 | 2026-10-13 | en curso
Integración con el ERP | 2026-12-13 | 2026-12-13 | en curso
Piloto en tiendas | 2027-02-13 | 2027-02-13 | en curso
