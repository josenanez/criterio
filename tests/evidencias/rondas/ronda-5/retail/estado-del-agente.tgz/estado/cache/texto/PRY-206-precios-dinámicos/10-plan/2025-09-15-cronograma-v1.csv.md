<!-- origen: PRY-206-precios-dinámicos/10-plan/2025-09-15-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño de la experiencia aprobado,2026-02-12,2026-02-12,cerrado
Ambiente de pruebas certificado,2026-07-03,2026-07-03,cerrado
Integración con el ERP,2026-11-21,2026-11-21,en curso
