<!-- origen: PRY-201-programa-de-fidelización/00-gobierno/2025-11-10-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Programa de fidelización

Código: PRY-201

Área dueña: Talento humano

Patrocinador: Laura Vélez

Gerente de proyecto: Liliana Torres

Comité: Comité de Arquitectura

Producto asociado: puntos de fidelización

Fecha de aprobación: 2025-11-10

Objetivo del negocio

Entregar programa de fidelización para Talento humano.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

6.800.000.000 COP, aprobado por Comité de Arquitectura el 2025-11-10.

Fechas comprometidas

Fecha

Inicio

2025-11-20

Cierre

2026-09-10

Criterio de éxito

Programa de fidelización en producción y medido.

Dependencias declaradas

• Ninguna declarada
