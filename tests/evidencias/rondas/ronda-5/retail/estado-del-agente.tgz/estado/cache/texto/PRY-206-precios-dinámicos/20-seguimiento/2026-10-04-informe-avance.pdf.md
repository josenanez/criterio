<!-- origen: PRY-206-precios-dinámicos/20-seguimiento/2026-10-04-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Precios dinámicos
Código: PRY-206
Fecha de corte: 2026-10-04
Gerente: Beatriz Cuéllar

Estado declarado
Verde
Avance reportado: 75%

Lo que pasó en el periodo
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales
- Se reprogramó el despliegue por el congelamiento de temporada de fin de año

Presupuesto
COP
Aprobado 800.000.000
Comprometido 258.147.519
Ejecutado 352.977.116
Proyección al cierre 1.014.297.933

Riesgos abiertos
- Disponibilidad de los jefes de tienda para el piloto
- El proveedor no ha confirmado la fecha de la última entrega
