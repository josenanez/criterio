<!-- origen: PRY-209-migración-del-erp/00-gobierno/ficha-pm.json · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

{
 "schema_version": "0.2",
 "identity": {
 "code": {
 "value": "PRY-209",
 "source": "00-gobierno/2026-04-17-acta-constitucion.md",
 "source_date": "2026-04-17",
 "state": "found"
 },
 "name": {
 "value": "Migración del ERP",
 "source": "00-gobierno/2026-04-17-acta-constitucion.md",
 "source_date": "2026-04-17",
 "state": "found"
 },
 "business_area": {
 "value": "Comercio electrónico",
 "source": "00-gobierno/2026-04-17-acta-constitucion.md",
 "source_date": "2026-04-17",
 "state": "found"
 },
 "sponsor": {
 "value": "Gustavo Neira",
 "source": "00-gobierno/2026-04-17-acta-constitucion.md",
 "source_date": "2026-04-17",
 "state": "found"
 },
 "manager": {
 "value": "Liliana Torres",
 "source": "00-gobierno/2026-04-17-acta-constitucion.md",
 "source_date": "2026-04-17",
 "state": "found"
 },
 "committee": {
 "value": "Comité de Arquitectura",
 "source": "00-gobierno/2026-04-17-acta-constitucion.md",
 "source_date": "2026-04-17",
 "state": "found"
 }
 },
 "declared": {
 "status": {
 "value": "verde",
 "source": "20-seguimiento/2026-10-12-informe-avance.pdf",
 "source_date": "2026-10-12",
 "state": "found",
 "source_kind": "declaration"
 },
 "progress_pct": {
 "value": 71,
 "source": "20-seguimiento/2026-10-12-informe-avance.pdf",
 "source_date": "2026-10-12",
 "state": "found",
 "source_kind": "declaration"
 },
 "as_of": {
 "value": "2026-10-12",
 "source": "20-seguimiento/2026-10-12-informe-avance.pdf",
 "source_date": "2026-10-12",
 "state": "found"
 },
 "source": "20-seguimiento/2026-10-12-informe-avance.pdf"
 },
 "plan": {
 "start_date": {
 "value": "2026-04-27",
 "source": "00-gobierno/2026-04-17-acta-constitucion.md",
 "source_date": "2026-04-17",
 "state": "found"
 },
 "end_date": {
 "value": "2027-12-02",
 "source": "00-gobierno/2026-04-17-acta-constitucion.md",
 "source_date": "2026-04-17",
 "state": "found"
 },
 "baseline": [
 {
 "version": 1,
 "approved_on": "2026-04-17",
 "start_date": "2026-04-27",
 "end_date": "2027-12-02",
 "reason": "Acta de constitución",
 "source": "00-gobierno/2026-04-17-acta-constitucion.md"
 }
 ],
 "milestones": [
 {
 "name": {
 "value": "Diseño de la experiencia aprobado",
 "source": "10-plan/2026-04-17-cronograma-v1.csv",
 "source_date": "2026-04-17",
 "state": "found"
 },
 "baseline_date": {
 "value": "2026-09-03",
 "source": "10-plan/2026-04-17-cronograma-v1.csv",
 "source_date": "2026-04-17",
 "state": "found"
 },
 "current_date": {
 "value": "2026-09-03",
 "source": "10-plan/2026-04-17-cronograma-v1.csv",
 "source_date": "2026-04-17",
 "state": "found"
 },
 "state": {
 "value": "met",
 "source": "10-plan/2026-04-17-cronograma-v1.csv",
 "source_date": "2026-04-17",
 "state": "found"
 },
 "evidence": {
 "value": "20-seguimiento/2026-10-04-acta-recibo-diseño-de-la-experiencia-aprobado.pdf",
 "source": "20-seguimiento/2026-10-04-acta-recibo-diseño-de-la-experiencia-aprobado.pdf",
 "source_date": "2026-10-04",
 "state": "found"
 }
 },
 {
 "name": {
 "value": "Ambiente de pruebas certificado",
 "source": "10-plan/2026-04-17-cronograma-v1.csv",
 "source_date": "2026-04-17",
 "state": "found"
 },
 "baseline_date": {
 "value": "2027-01-11",
 "source": "10-plan/2026-04-17-cronograma-v1.csv",
 "source_date": "2026-04-17",
 "state": "found"
 },
 "current_date": {
 "value": "2027-01-11",
 "source": "10-plan/2026-04-17-cronograma-v1.csv",
 "source_date": "2026-04-17",
 "state": "found"
 },
 "state": {
 "value": "pending",
 "source": "10-plan/2026-04-17-cronograma-v1.csv",
 "source_date": "2026-04-17",
 "state": "found"
 },
 "evidence": {
 "value": null,
 "state": "not_found"
 }
 },
 {
 "name": {
 "value": "Integración con el ERP",
 "source": "10-plan/2026-04-17-cronograma-v1.csv",
 "source_date": "2026-04-17",
 "state": "found"
 },
 "baseline_date": {
 "value": "2027-05-21",
 "source": "10-plan/2026-04-17-cronograma-v1.csv",
 "source_date": "2026-04-17",
 "state": "found"
 },
 "current_date": {
 "value": "2027-05-21",
 "source": "10-plan/2026-04-17-cronograma-v1.csv",
 "source_date": "2026-04-17",
 "state": "found"
 },
 "state": {
 "value": "pending",
 "source": "10-plan/2026-04-17-cronograma-v1.csv",
 "source_date": "2026-04-17",
 "state": "found"
 },
 "evidence": {
 "value": null,
 "state": "not_found"
 }
 },
 {
 "name": {
 "value": "Piloto en tiendas",
 "source": "10-plan/2026-04-17-cronograma-v1.csv",
 "source_date": "2026-04-17",
 "state": "found"
 },
 "baseline_date": {
 "value": "2027-09-28",
 "source": "10-plan/2026-04-17-cronograma-v1.csv",
 "source_date": "2026-04-17",
 "state": "found"
 },
 "current_date": {
 "value": "2027-09-28",
 "source": "10-plan/2026-04-17-cronograma-v1.csv",
 "source_date": "2026-04-17",
 "state": "found"
 },
 "state": {
 "value": "pending",
 "source": "10-plan/2026-04-17-cronograma-v1.csv",
 "source_date": "2026-04-17",
 "state": "found"
 },
 "evidence": {
 "value": null,
 "state": "not_found"
 }
 }
 ],
 "scope_summary": {
 "value": "Componente 1; Componente 2; Componente 3 (el acta no los describe)",
 "source": "00-gobierno/2026-04-17-acta-constitucion.md",
 "source_date": "2026-04-17",
 "state": "found"
 },
 "exclusions": {
 "value": "Lo que otro proyecto cubre",
 "source": "00-gobierno/2026-04-17-acta-constitucion.md",
 "source_date": "2026-04-17",
 "state": "found"
 }
 },
 "money": {
 "currency": {
 "value": "COP",
 "source": "00-gobierno/2026-04-17-acta-constitucion.md",
 "source_date": "2026-04-17",
 "state": "found"
 },
 "approved": {
 "value": 2400000000,
 "source": "00-gobierno/2026-04-17-acta-constitucion.md",
 "source_date": "2026-04-17",
 "state": "found"
 },
 "committed": {
 "value": 737951290,
 "source": "20-seguimiento/2026-10-12-informe-avance.pdf",
 "source_date": "2026-10-12",
 "state": "found",
 "source_kind": "declaration"
 },
 "executed": {
 "value": 1177731702,
 "source": "20-seguimiento/2026-10-12-informe-avance.pdf",
 "source_date": "2026-10-12",
 "state": "found",
 "source_kind": "declaration"
 },
 "projection": {
 "value": 2294519534,
 "source": "20-seguimiento/2026-10-12-informe-avance.pdf",
 "source_date": "2026-10-12",
 "state": "found",
 "source_kind": "declaration"
 }
 },
 "raid": {
 "risks": [
 {
 "what": "Disponibilidad de los jefes de tienda para el piloto",
 "owner": "no_identificado",
 "source": "20-seguimiento/2026-10-12-informe-avance.pdf"
 },
 {
 "what": "El proveedor no ha confirmado la fecha de la última entrega",
 "owner": "no_identificado",
 "source": "20-seguimiento/2026-10-12-informe-avance.pdf"
 },
 {
 "what": "El proveedor podría no llegar con el equipo completo para la siguiente fase (se comentó en la reunión; nadie lo registró como riesgo)",
 "owner": "no_identificado",
 "source": "2026-10-16-notas-reunion.txt"
 }
 ],
 "assumptions": [],
 "issues": [
 {
 "what": "Hallazgo de seguridad en los medios de pago",
 "owner": "no_identificado",
 "source": "20-seguimiento/2026-10-12-informe-avance.pdf"
 },
 {
 "what": "La validación con dos tiendas se extendió una semana por el conteo de inventario",
 "owner": "no_identificado",
 "source": "20-seguimiento/2026-10-12-informe-avance.pdf"
 }
 ],
 "dependencies": []
 },
 "changes": [],
 "commitments": [
 {
 "who": "Natalia Ospina",
 "what": "Enviar el documento 1",
 "due_date": "2026-11-25",
 "original_due_date": "2026-09-20",
 "stated_on": "2026-09-04",
 "source": "30-reuniones/2026-09-04-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-09-29",
 "stated_on": "2026-09-11",
 "source": "30-reuniones/2026-09-11-comite-semanal.md"
 },
 {
 "due_date": "2026-10-08",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md"
 },
 {
 "due_date": "2026-10-19",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md"
 },
 {
 "due_date": "2026-11-03",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md"
 },
 {
 "due_date": "2026-11-11",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md"
 },
 {
 "due_date": "2026-11-25",
 "stated_on": "2026-10-16",
 "source": "2026-10-16-notas-reunion.txt"
 }
 ]
 },
 {
 "who": "Mauricio Pérez",
 "what": "Cerrar la prueba 2",
 "due_date": "2026-11-28",
 "original_due_date": "2026-09-30",
 "stated_on": "2026-09-04",
 "source": "30-reuniones/2026-09-04-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-08",
 "stated_on": "2026-09-11",
 "source": "30-reuniones/2026-09-11-comite-semanal.md"
 },
 {
 "due_date": "2026-10-19",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md"
 },
 {
 "due_date": "2026-10-29",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md"
 },
 {
 "due_date": "2026-11-13",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md"
 },
 {
 "due_date": "2026-11-28",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Óscar Ramírez",
 "what": "Revisar el anexo 3",
 "due_date": "2026-10-21",
 "original_due_date": "2026-09-10",
 "stated_on": "2026-09-04",
 "source": "30-reuniones/2026-09-04-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-21",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Mauricio Pérez",
 "what": "Validar el ambiente 4",
 "due_date": "2026-10-04",
 "original_due_date": "2026-09-27",
 "stated_on": "2026-09-04",
 "source": "30-reuniones/2026-09-04-comite-semanal.md",
 "state": "met",
 "reschedules": [
 {
 "due_date": "2026-10-04",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md"
 }
 ],
 "evidence": "20-seguimiento/2026-10-02-acta-recibo-4.md"
 },
 {
 "who": "Laura Vélez",
 "what": "Aprobar el diseño 5",
 "due_date": "2026-10-19",
 "original_due_date": "2026-09-18",
 "stated_on": "2026-09-11",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-06",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md"
 },
 {
 "due_date": "2026-10-19",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Andrés Lozano",
 "what": "Actualizar la matriz 6",
 "due_date": "2026-11-13",
 "original_due_date": "2026-09-29",
 "stated_on": "2026-09-11",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-23",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md"
 },
 {
 "due_date": "2026-11-13",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Óscar Ramírez",
 "what": "Confirmar la fecha 7",
 "due_date": "2026-10-25",
 "original_due_date": "2026-10-03",
 "stated_on": "2026-09-11",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "state": "open",
 "nota": "El 2026-10-09 dijo que ya lo entregó; no se presentó acta y desde esa reunión salió de la tabla de abiertos. Sin acta no se da por cumplido.",
 "reschedules": [
 {
 "due_date": "2026-10-12",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md"
 },
 {
 "due_date": "2026-10-25",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Ricardo Salas",
 "what": "Entregar el punto 8",
 "due_date": "2026-09-25",
 "original_due_date": "2026-09-25",
 "stated_on": "2026-09-11",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-09-25-acta-recibo-8.md"
 },
 {
 "who": "Felipe Arango",
 "what": "Enviar el documento 9",
 "due_date": "2026-10-07",
 "original_due_date": "2026-10-07",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "state": "overdue",
 "reschedules": []
 },
 {
 "who": "Natalia Ospina",
 "what": "Cerrar la prueba 10",
 "due_date": "2026-10-09",
 "original_due_date": "no_declarada",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "state": "overdue",
 "nota": "El 2026-10-02 dijo que ya lo entregó; no se presentó acta. Salió de la tabla de abiertos sin acta.",
 "reschedules": [
 {
 "due_date": "2026-10-09",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Beatriz Cuéllar",
 "what": "Revisar el anexo 11",
 "due_date": "2026-09-24",
 "original_due_date": "2026-09-24",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "state": "overdue",
 "nota": "El 2026-09-25 dijo que ya lo entregó; no se presentó acta. Salió de la tabla de abiertos sin acta.",
 "reschedules": []
 },
 {
 "who": "Carlos Peña",
 "what": "Validar el ambiente 12",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "state": "open",
 "nota": "El 2026-10-02 dijo que ya lo entregó; no se presentó acta. Salió de la tabla de abiertos sin acta. Nunca tuvo fecha.",
 "reschedules": []
 },
 {
 "who": "Natalia Ospina",
 "what": "Aprobar el diseño 13",
 "due_date": "2026-10-23",
 "original_due_date": "2026-10-16",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "state": "met",
 "reschedules": [
 {
 "due_date": "2026-10-23",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md"
 }
 ],
 "evidence": "20-seguimiento/2026-10-09-acta-recibo-13.md"
 },
 {
 "who": "Javier Hoyos",
 "what": "Actualizar la matriz 14",
 "due_date": "2026-09-30",
 "original_due_date": "2026-09-30",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "state": "overdue",
 "reschedules": []
 },
 {
 "who": "Mauricio Pérez",
 "what": "Confirmar la fecha 15",
 "due_date": "2026-10-04",
 "original_due_date": "2026-10-04",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-10-09-acta-recibo-15.md"
 },
 {
 "who": "Óscar Ramírez",
 "what": "Entregar el punto 16",
 "due_date": "2026-10-29",
 "original_due_date": "2026-10-21",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-29",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Elena Duarte",
 "what": "Enviar el documento 17",
 "due_date": "2026-11-08",
 "original_due_date": "2026-10-23",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-11-08",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Diana Molina",
 "what": "Cerrar la prueba 18",
 "due_date": "2026-10-27",
 "original_due_date": "2026-10-27",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Elena Duarte",
 "what": "Revisar el anexo 19",
 "due_date": "2026-10-27",
 "original_due_date": "2026-10-27",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Javier Hoyos",
 "what": "Validar el ambiente 20",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Paula Céspedes",
 "what": "Aprobar el diseño 21",
 "due_date": "2026-10-24",
 "original_due_date": "2026-10-24",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Carlos Peña",
 "what": "Actualizar la matriz 22",
 "due_date": "2026-10-15",
 "original_due_date": "2026-10-15",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "state": "overdue",
 "reschedules": []
 },
 {
 "who": "Elena Duarte",
 "what": "Confirmar la fecha 23",
 "due_date": "2026-10-15",
 "original_due_date": "2026-10-15",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "state": "overdue",
 "reschedules": []
 },
 {
 "who": "Andrés Lozano",
 "what": "Entregar el punto 24",
 "due_date": "2026-10-18",
 "original_due_date": "2026-10-18",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Laura Vélez",
 "what": "Mandar el ajuste del presupuesto",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-10-16",
 "source": "2026-10-16-notas-reunion.txt",
 "state": "open",
 "due_text": "la otra semana",
 "reschedules": []
 },
 {
 "who": "Óscar Ramírez",
 "what": "Revisión con el proveedor",
 "due_date": "2026-10-26",
 "original_due_date": "2026-10-26",
 "stated_on": "2026-10-16",
 "source": "2026-10-16-notas-reunion.txt",
 "state": "open",
 "reschedules": []
 }
 ],
 "meta": {
 "record_updated": "2026-10-16",
 "documents_seen": [
 {
 "path": "00-gobierno/2026-04-17-acta-constitucion.md",
 "hash": "8fff781ac2fcb2ddbf79b2371f25ac3525e15a1c7d1585ddffa98fa7a602306b",
 "text_hash": null,
 "date": "2026-04-17"
 },
 {
 "path": "10-plan/2026-04-17-cronograma-v1.csv",
 "hash": "b3b3ae2f96eff69d43701a23e24698db01592eb76706499df02c5be5009074de",
 "text_hash": null,
 "date": "2026-04-17"
 },
 {
 "path": "20-seguimiento/2026-09-25-acta-recibo-8.md",
 "hash": "cfd892dbee9952f2fb53d73b225f233c26208118bb373f42353a7354e6b824ea",
 "text_hash": null,
 "date": "2026-09-25"
 },
 {
 "path": "20-seguimiento/2026-10-02-acta-recibo-4.md",
 "hash": "647f947b18974d28152c4662a045006c6f5b17221c50be82287310235f27beb4",
 "text_hash": null,
 "date": "2026-10-02"
 },
 {
 "path": "20-seguimiento/2026-10-04-acta-recibo-diseño-de-la-experiencia-aprobado.pdf",
 "hash": "384f287dcb8ed895f30f309828fadc47fe39680f1a4390e87198fd5489dafb69",
 "text_hash": null,
 "date": "2026-10-04"
 },
 {
 "path": "20-seguimiento/2026-10-09-acta-recibo-13.md",
 "hash": "c68bd19ca8b99d0ac5a4cf9159f4c6ccf94f02d896d3573fdb9fc2bb612e333f",
 "text_hash": null,
 "date": "2026-10-09"
 },
 {
 "path": "20-seguimiento/2026-10-09-acta-recibo-15.md",
 "hash": "c1926c6b09666c226a3d619f5026efa2831297fc72448bec5ef379954d88d04f",
 "text_hash": null,
 "date": "2026-10-09"
 },
 {
 "path": "20-seguimiento/2026-10-12-informe-avance.pdf",
 "hash": "36370cab4d8503d3f03723cfea34e7abbf09c1f621d2ed7d1ebf50b3aa745f66",
 "text_hash": null,
 "date": "2026-10-12"
 },
 {
 "path": "2026-10-16-notas-reunion.txt",
 "hash": "793e98c3be66bc1a7a0f0f11c58199ca1ac500044435ff025703812a7cc1b974",
 "text_hash": null,
 "date": "2026-10-16"
 },
 {
 "path": "30-reuniones/2026-09-04-comite-semanal.md",
 "hash": "c590725cd4cd2418ec2d4e465be05714a0a8480a24a10e5821c71f0193e2fc76",
 "text_hash": null,
 "date": "2026-09-04"
 },
 {
 "path": "30-reuniones/2026-09-11-comite-semanal.md",
 "hash": "3dea179915166519d714c2c404d074e931a8a30727776635692c03be59351a6a",
 "text_hash": null,
 "date": "2026-09-11"
 },
 {
 "path": "30-reuniones/2026-09-18-comite-semanal.md",
 "hash": "bedfc2be251c26d0790b37abb0d4f6d4a5da2bf3ef861f19595d6e3d369cd588",
 "text_hash": null,
 "date": "2026-09-18"
 },
 {
 "path": "30-reuniones/2026-09-25-comite-semanal.md",
 "hash": "07b8b0f938c33e9d85b18c54b8c6a2bc74d875925ed6810290dd58cf1a89bd04",
 "text_hash": null,
 "date": "2026-09-25"
 },
 {
 "path": "30-reuniones/2026-10-02-comite-semanal.md",
 "hash": "b003d3db930a04cbe7a97d99ab1c3db021dbf860be81db1bde75c956e97e0d87",
 "text_hash": null,
 "date": "2026-10-02"
 },
 {
 "path": "30-reuniones/2026-10-09-comite-semanal.md",
 "hash": "5c0e54b42c6c0dee2c87b43f1d67bc7f667d56d7efb6bdfd3d6598dd876a19c7",
 "text_hash": null,
 "date": "2026-10-09"
 }
 ],
 "fields_not_found": [
 "identity.authority",
 "identity.product",
 "identity.phase",
 "vendors"
 ],
 "open_conflicts": []
 }
}
