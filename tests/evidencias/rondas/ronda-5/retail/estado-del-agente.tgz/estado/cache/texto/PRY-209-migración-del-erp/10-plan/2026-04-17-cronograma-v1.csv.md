<!-- origen: PRY-209-migración-del-erp/10-plan/2026-04-17-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño de la experiencia aprobado,2026-09-03,2026-09-03,cerrado
Ambiente de pruebas certificado,2027-01-11,2027-01-11,en curso
Integración con el ERP,2027-05-21,2027-05-21,en curso
Piloto en tiendas,2027-09-28,2027-09-28,en curso
