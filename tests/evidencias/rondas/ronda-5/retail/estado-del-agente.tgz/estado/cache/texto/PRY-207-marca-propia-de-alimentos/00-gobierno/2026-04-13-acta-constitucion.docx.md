<!-- origen: PRY-207-marca-propia-de-alimentos/00-gobierno/2026-04-13-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Marca propia de alimentos

Código: PRY-207

Área dueña: Comercial

Patrocinador: Jorge Medina

Gerente de proyecto: Natalia Ospina

Comité: Comité Comercial

Producto asociado: marca propia

Fecha de aprobación: 2026-04-13

Objetivo del negocio

Entregar marca propia de alimentos para Comercial.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

9.500.000.000 COP, aprobado por Comité Comercial el 2026-04-13.

Fechas comprometidas

Fecha

Inicio

2026-04-23

Cierre

2027-09-06

Criterio de éxito

Marca propia de alimentos en producción y medido.

Dependencias declaradas

• Ninguna declarada
