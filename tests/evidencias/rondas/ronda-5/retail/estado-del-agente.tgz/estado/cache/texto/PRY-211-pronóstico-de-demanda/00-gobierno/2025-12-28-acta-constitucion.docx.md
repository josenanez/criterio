<!-- origen: PRY-211-pronóstico-de-demanda/00-gobierno/2025-12-28-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Pronóstico de demanda

Código: PRY-211

Área dueña: Abastecimiento

Patrocinador: Laura Vélez

Gerente de proyecto: Liliana Torres

Comité: Comité Comercial

Producto asociado: No aplica

Fecha de aprobación: 2025-12-28

Objetivo del negocio

Entregar pronóstico de demanda para Abastecimiento.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

18.000.000.000 COP, aprobado por Comité Comercial el 2025-12-28.

Fechas comprometidas

Fecha

Inicio

2026-01-07

Cierre

2027-07-08

Criterio de éxito

Pronóstico de demanda en producción y medido.

Dependencias declaradas

• Ninguna declarada
