<!-- origen: PRY-205-pago-con-qr-en-caja/00-gobierno/2026-03-17-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Pago con QR en caja

Código: PRY-205

Área dueña: Finanzas

Patrocinador: Laura Vélez

Gerente de proyecto: Sandra Gil

Comité: Comité de Cadena de Abastecimiento

Producto asociado: pago con QR

Fecha de aprobación: 2026-03-17

Objetivo del negocio

Entregar pago con qr en caja para Finanzas.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

1.200.000.000 COP, aprobado por Comité de Cadena de Abastecimiento el 2026-03-17.

Fechas comprometidas

Fecha

Inicio

2026-03-27

Cierre

2027-03-27

Criterio de éxito

Pago con QR en caja en producción y medido.

Dependencias declaradas

• Ninguna declarada
