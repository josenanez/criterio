<!-- origen: PRY-205-pago-con-qr-en-caja/10-plan/2026-03-17-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño de la experiencia aprobado,2026-07-09,2026-07-09,cerrado
Ambiente de pruebas certificado,2026-10-21,2026-10-21,en curso
Integración con el ERP,2027-02-02,2027-02-02,en curso
