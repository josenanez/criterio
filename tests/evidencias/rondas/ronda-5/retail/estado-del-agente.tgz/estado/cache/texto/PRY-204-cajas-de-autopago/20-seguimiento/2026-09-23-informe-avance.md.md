<!-- origen: PRY-204-cajas-de-autopago/20-seguimiento/2026-09-23-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Cajas de autopago

**Código:** PRY-204
**Fecha de corte:** 2026-09-23
**Gerente:** Javier Hoyos

## Estado declarado

**Amarillo**

Avance reportado: **65%**

## Lo que pasó en el periodo

- Se reprogramó el despliegue por el congelamiento de temporada de fin de año

## Presupuesto

| | COP |
|---|---|
| Aprobado | 800.000.000 |
| Comprometido | 428.059.186 |
| Ejecutado | 302.454.730 |
| Proyección al cierre | 767.550.051 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
- Disponibilidad de los jefes de tienda para el piloto
