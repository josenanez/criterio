<!-- origen: PRY-208-domicilios-en-dos-horas/10-plan/2026-02-24-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño de la experiencia aprobado,2026-08-17,2026-08-17,cerrado
Ambiente de pruebas certificado,2027-01-29,2027-01-29,en curso
Integración con el ERP,2027-07-13,2027-07-13,en curso
