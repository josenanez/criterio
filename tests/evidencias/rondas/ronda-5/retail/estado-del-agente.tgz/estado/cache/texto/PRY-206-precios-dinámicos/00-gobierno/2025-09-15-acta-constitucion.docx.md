<!-- origen: PRY-206-precios-dinámicos/00-gobierno/2025-09-15-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Precios dinámicos

Código: PRY-206

Área dueña: Finanzas

Patrocinador: Gustavo Neira

Gerente de proyecto: Beatriz Cuéllar

Comité: Comité de Expansión

Producto asociado: No aplica

Fecha de aprobación: 2025-09-15

Objetivo del negocio

Entregar precios dinámicos para Finanzas.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

800.000.000 COP, aprobado por Comité de Expansión el 2025-09-15.

Fechas comprometidas

Fecha

Inicio

2025-09-25

Cierre

2027-01-31

Criterio de éxito

Precios dinámicos en producción y medido.

Dependencias declaradas

• Ninguna declarada
