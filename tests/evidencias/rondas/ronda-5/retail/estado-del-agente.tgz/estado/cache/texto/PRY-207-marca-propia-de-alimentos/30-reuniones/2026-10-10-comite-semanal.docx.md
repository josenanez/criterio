<!-- origen: PRY-207-marca-propia-de-alimentos/30-reuniones/2026-10-10-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité Comercial · Marca propia de alimentos

Fecha: 2026-10-10

Asistentes: Natalia Ospina, Jorge Medina

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Óscar Ramírez

Entregar el punto 32

2026-11-14
