# Corrida · 2026-10-16-project-charter-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-charter PRY-201 revisar

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-201

**Inicio:** 2026-10-16T11:43:28 · **Fin:** 2026-10-16T11:44:26 · **Duración:** 58 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-charter` | 13 | — | 39 | 54 | Revisó el acta de PRY-201 (2025-11-10): falta autoridad del gerente, cadencia, supuestos, restricciones, hitos, métrica de éxito y quién la mide; objetivo y alcance describen la solución. Señaló cierre vencido (2026-09-10) con informe en verde 81%. No sabe lo hablado fuera de los dos documentos leídos. |

Por señal (`project-charter`): `milestone_met_without_evidence` 13, `commitment_overdue` 8, `progress_vs_plan` 7, `declared_vs_evidence` 7, `variance_cost` 5, `commitment_undated` 5, `milestone_overdue` 2, `commitment_rescheduled` 2, `rebaseline_unauthorized` 1, `variance_time` 1, `change_without_baseline` 1, `pm_vs_pmo` 1, `silent` 1

## Lo que el agente mostró

**Acta de PRY-201 revisada.** Existe una del 2025-11-10, aprobada por el Comité de Arquitectura, y está incompleta. Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-16), así que no hubo nada que registrar.

**Qué falta y qué consecuencia tiene:**
- **Autoridad del gerente:** no está. Liliana Torres no tiene declarado hasta qué monto ni qué cambios puede decidir sin comité, así que todo sube al comité. Hoy pesa porque la prueba de carga fallida se repite y el cierre ya venció.
- **Objetivo, alcance y exclusiones:** el objetivo es "Entregar programa de fidelización para Talento humano", que describe la solución y no el resultado de negocio. El alcance es "Componente 1, 2, 3", sin contenido. La única exclusión es "Lo que otro proyecto cubre", sin decir cuál.
- **Criterio de éxito:** "En producción y medido", sin métrica ni umbral. Tampoco dice quién lo mide.
- **Supuestos, restricciones, hitos y cadencia:** no están. El informe declara riesgos (regulación de datos personales, congelamiento en temporada alta) que salen de supuestos y restricciones nunca escritos.
- **Dependencias:** el acta dice "Ninguna declarada", lo que contradice esos riesgos.
- **Patrocinador:** Laura Vélez, con nombre de persona. Hay que confirmar que Talento humano sea el área dueña de un programa de fidelización, porque suena a un programa de clientes.
- **Comité:** que el Comité de Arquitectura haya aprobado 6.800 millones COP de un programa de fidelización es dudoso como instancia de gobierno.

**Lo que el acta deja ver hoy:**
- El cierre comprometido (2026-09-10) venció hace 36 días, y el informe del 2026-10-13 declara verde con 81%.
- La proyección (6.821.176.777 COP) supera el aprobado (6.800.000.000 COP) en 21.176.777 COP (0,3%).

En el acta de la salida, todo lo que no consta en los documentos quedó como pendiente de definir.

**Ofrecí dos pasos:**
- Llevar la definición de la autoridad del gerente al comité con `/steering-pack`.
- Pasar al registro RAID los dos supuestos que el informe da por hechos, con `/raid-log`.

**Limitación:** solo leí el acta y el informe del 2026-10-13. No sé lo que se haya hablado fuera de esos documentos.

La corrida quedó registrada con id `2026-10-16-project-charter-1`.

Archivos están en `/home/claude/banco/ronda-5/retail/espacio/estado/corridas/`:
- `salida-project-charter.md`
- `2026-10-16-project-charter-1.md`
