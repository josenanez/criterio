# Corrida · 2026-10-16-product-setup-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-setup documentos/productos/PRD-306

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRD-306

**Inicio:** 2026-10-16T11:01:41 · **Fin:** 2026-10-16T11:03:47 · **Duración:** 127 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-setup` | 16 | — | 31 | 39 | 0 preguntas a la persona (sesión sin interfaz, respuestas sugeridas); primer resultado en unos 10 minutos. 4 documentos, 16 requerimientos levantados, 38 señales: 15 sin proyecto, 14 con evidencia vieja (12 meses), 5 sin criterio de aceptación, 2 sin evidencia, 1 sin doliente, 1 sin decidir, 1 supuesto sin verificar. Sin criterio de éxito ni serie medida. Nota: sellar exigió corrida-inicio pese a que el comando dice que no va. |

Por señal (`product-setup`): `requirement_untraced` 15, `evidence_stale` 14, `requirement_without_acceptance` 5, `requirement_accepted_without_evidence` 2, `requirement_undecided` 1, `requirement_without_owner` 1, `assumption_unverified` 1

## Lo que el agente mostró

Dejé a Alba lista sobre PRD-306 (App de clientes). Tomé la respuesta sugerida en cada pregunta, porque nadie iba a responder.

**Dónde quedó**
- **Configuración:** `.criterio/producto/PRD-306/config.json`. La verificación con `config` dio ok.
- **Estado:** `estado-producto/PRD-306/`, con la ficha del producto y 16 requerimientos, uno por cada fila del acta del comité del 2026-10-16.
- **Términos:** aceptados por José Francisco Ñáñez para la versión 0.3.11 (términos 1.1). El comprobante en Markdown y PDF está en `.criterio/terminos/`, con SHA-256 `f969d4f658630df3…`.
- **Corrida registrada:** `2026-10-16-product-setup-1`.

**Lo que miré:** 4 documentos, de los cuales 1 es de descubrimiento: una entrevista del 2025-09-29, de un cliente sin nombre. No hay transcripciones, tickets, encuestas ni serie medida de ninguna métrica.

**Lo que no está dicho en ninguna parte**
- El criterio de éxito del producto.
- De dónde sale el volumen mensual de 67.794, y que alguien lo mida.
- La cifra del retorno esperado en 24 meses.
- La propuesta: la definición solo dice «Propuesta principal».
- Quién decide qué se construye. Puse Comité de producto porque el acta es suya, pero ningún documento lo dice.
- Un proyecto que construya el producto: «Ninguno declarado».
- Qué pidió cada requerimiento. Los 16 citan «Cliente entrevistado», pero la única entrevista no nombra ninguno.

**Señales sobre los requerimientos (39 en total)**
- 15 no tienen proyecto que los ejecute.
- 14 tienen su evidencia vieja: la entrevista tiene 12 meses.
- 5 aceptados no tienen criterio de aceptación (REQ-4603, 4604, 4608, 4609, 4613).
- 2 aceptados no tienen evidencia de demanda (REQ-4608 y REQ-2028).
- REQ-4607 no tiene doliente.
- REQ-4600 lleva 120 días propuesto sin decidirse.
- El único supuesto declarado, «La demanda se sostiene sin descuento», lleva 196 días sin verificar.

**Dos defectos**
- `sellar` exigió abrir la corrida con `corrida-inicio` y que la ficha se escribiera después, aunque el comando dice que aquí no va. Lo hice así y reescribí la ficha para que contara como de esta corrida.
- La nota de la corrida dice «38 señales» y «unos 10 minutos». Lo que cuenta el script es 39 hallazgos y 31 segundos. Esa nota ya quedó registrada y no la corregí.

El siguiente paso es `/product-discovery` sobre las entrevistas. El resultado completo está en `estado-producto/PRD-306/corridas/salida-product-setup.md`.
