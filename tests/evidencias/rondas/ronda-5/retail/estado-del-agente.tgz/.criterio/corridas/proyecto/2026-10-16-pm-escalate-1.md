# Corrida · 2026-10-16-pm-escalate-1

**Agente:** Samuel (proyecto) · **Comando:** `/criterio-project:pm-escalate (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-16T11:20:14 · **Fin:** 2026-10-16T11:21:21 · **Duración:** 67 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `pm-escalate` | 1 | — | 44 | 13 | Paquete con 3 puntos: autoridad no declarada en el acta, documento 1 (6 reprogramaciones) y prueba 2 (5). No se pudo costear las opciones: ningún documento dice qué son ni qué las bloquea. Impacto de 66 días calculado como hipótesis; sin dependencias cargadas ni proveedores en la ficha. |

Por señal (`pm-escalate`): `commitment_overdue` 6, `commitment_undated` 3, `commitment_rescheduled` 2, `progress_vs_plan` 1, `declared_vs_evidence` 1

## Lo que el agente mostró

Armé el paquete de escalamiento de PRY-209 (Migración del ERP) con tres puntos, pero ninguno está listo para llevar al comité del 2026-10-30. Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-16), así que no los pedí otra vez.

**Los tres puntos**
1. **La autoridad de la gerente no está declarada.** El acta del 2026-04-17 no tiene sección de autoridad y la ficha lo marca sin dato. Es el primer punto: sin eso no puedo decir quién tiene la facultad en los demás. La pregunta cerrada es si se declara por escrito qué puede decidir Liliana Torres sola y qué sube al Comité de Arquitectura. Recomiendo que sí, con un anexo al acta.
2. **«Enviar el documento 1» (Natalia Ospina).** Tiene 6 reprogramaciones y va a 2026-11-25, 66 días sobre la promesa original (2026-09-20). El umbral es 3.
3. **«Cerrar la prueba 2» (Mauricio Pérez).** Tiene 5 reprogramaciones y va a 2026-11-28, 59 días sobre la original (2026-09-30).

**Lo que no pude llenar**
- Para los puntos 2 y 3 no pude costear las opciones. Ningún documento dice qué son esos compromisos, quién los espera ni qué los bloquea, y no lo inventé. Recomiendo llamar antes a Natalia Ospina y a Mauricio Pérez. Si no aparece un bloqueo fuera del proyecto, el punto no escala y es de la gerente.
- Tampoco puedo decir quién tiene la facultad en esos dos puntos, por el vacío del punto 1.
- No hay fecha externa de vencimiento que obligue a decidir hoy; lo único que consta es que cada comité sin decisión suma una reprogramación.
- El cálculo de impacto con 66 días es hipotético. Ningún documento dice que ese atraso mueva el proyecto. Si se propagara sin holgura, el cierre pasaría del 2027-12-02 al 2028-02-06 y pasaría por los tres hitos pendientes (2027-01-11, 2027-05-21 y 2027-09-28). No se sabe cuántos días se mueve cada uno, y no hay otros proyectos alcanzados porque no hay dependencias cargadas.

**Lo que dejé fuera**
- **No escalan:** los seis vencidos sin evidencia y los tres compromisos sin fecha. Se destraban con una llamada a cada responsable.
- **Aún no están listos para formularse:**
  - El hallazgo de seguridad en medios de pago, que no tiene dueño.
  - El riesgo del proveedor, que nadie registró.
  - La cifra ejecutada mayor que la comprometida, que es una pregunta para finanzas.

**Archivos**
- Paquete completo: `/home/claude/banco/ronda-5/retail/espacio/estado/PRY-209-migración-del-erp/corridas/salida-pm-escalate.md`
- Corrida registrada como `2026-10-16-pm-escalate-1`, de 44 segundos.
