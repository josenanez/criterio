# Corrida · 2026-10-16-portfolio-server-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-server rato

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-16T11:51:13 · **Fin:** 2026-10-16T11:52:18 · **Duración:** 65 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-server` | 13 | — | — | 54 | puerto 8787, carpeta reportes, modo rato |

Por señal (`portfolio-server`): `milestone_met_without_evidence` 13, `commitment_overdue` 8, `progress_vs_plan` 7, `declared_vs_evidence` 7, `variance_cost` 5, `commitment_undated` 5, `milestone_overdue` 2, `commitment_rescheduled` 2, `rebaseline_unauthorized` 1, `variance_time` 1, `change_without_baseline` 1, `pm_vs_pmo` 1, `silent` 1

## Lo que el agente mostró

Rostrum arrancó bien en `http://127.0.0.1:8787/`, pero el comando que lo lanzó venció a los 8 segundos y el servidor ya no está corriendo. Para volver a levantarlo, corre esto en una terminal y déjala abierta:

```
python3 "/home/claude/banco/criterio/plugins/criterio-portfolio/scripts/servidor.py" --informe reportes --estado estado --config .criterio/portafolio/config.json
```

- **Términos:** ya estaban vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-16), así que no volví a pedirlos.
- **Modo:** «para mirarlo un rato», que es la respuesta sugerida. El servidor escucha solo en este equipo y se para con Ctrl-C. Si el puerto está ocupado, añade `--puerto 8788`.
- **Qué sirve:** el informe de `reportes/` (13 proyectos, 7 productos, 32 corridas), con el nombre «Portafolio retail».
  - `/pmo`: cómo va el portafolio.
  - `/decisiones`: lo que necesita una decisión.
  - `/proyectos` y `/p/<código>`: el listado y el informe de cada proyecto.
  - `/productos` y `/producto/<nombre>`: el listado y el informe de cada producto.
  - `/corridas`: las corridas registradas.
  - `/estado.json`: de cuándo es el informe y cuántas peticiones hay abiertas.
- **Qué no hace:**
  - No calcula nada: sirve lo que el informe ya escribió.
  - No escribe fichas: solo crea las peticiones del formulario, en `estado/peticiones/`.
  - No autentica.
  - No manda nada.
- **Qué enlace pasar a quién:** ninguno todavía. Este enlace solo funciona en este equipo y mientras el proceso esté vivo, así que sirve para mirar, no para mandárselo al patrocinador. Para un enlace estable hace falta el modo «que quede corriendo» (`--abierto`, detrás del control de acceso de la organización).
- **Cuándo se desactualiza:** el informe es del 2026-10-16 (generado a las 11:49). Queda viejo en cuanto cambie un documento o corra otro barrido, y la portada muestra su fecha.
- **Corrida:** quedó registrada como `2026-10-16-portfolio-server-1`, con su salida en `estado/corridas/salida-portfolio-server.md`.
