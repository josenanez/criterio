# Corrida · 2026-10-16-product-definition-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-definition (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-16T11:05:52 · **Fin:** 2026-10-16T11:06:47 · **Duración:** 55 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-definition` | 16 | — | 31 | 39 | Sin contradicciones; la cifra de volumen no tiene serie; un supuesto de 196 días; falta criterio de éxito; evidencia de demanda de 12 meses y de una sola entrevista |

Por señal (`product-definition`): `requirement_untraced` 15, `evidence_stale` 14, `requirement_without_acceptance` 5, `requirement_accepted_without_evidence` 2, `requirement_undecided` 1, `requirement_without_owner` 1, `assumption_unverified` 1

## Lo que el agente mostró

## Definición de App de clientes (PRD-306), contrastada al 2026-10-16

La definición no se puede cerrar: falta el criterio de éxito y lo que la sostiene es una sola entrevista de hace 12 meses.

Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-16), así que no los registré de nuevo. Revisé 6 afirmaciones de la definición y del caso de negocio, ambos del 2026-03-16.

- **Lo que la evidencia contradice:** nada. Ninguna fuente dice lo contrario de lo que afirma la definición.
- **Cifra sin medir:** el volumen mensual de 67.794 no tiene ninguna serie medida. No es una contradicción: nadie está midiendo esa cifra. El documento tampoco dice qué cuenta ese volumen.
- **No está dicho en ninguna parte:**
  - el criterio de éxito;
  - qué es la propuesta (solo dice «Propuesta principal»);
  - qué significa «Jóvenes» o cuántos son;
  - la cifra del retorno esperado;
  - qué proyecto lo construye;
  - quién decide (el «Comité de producto» es una inferencia, no algo escrito);
  - si el entrevistado es del segmento.
- **Sostenida por un supuesto:** «La demanda se sostiene sin descuento» lleva 196 días sin verificar (el umbral es 30). Para verificarlo haría falta ver compra o uso a precio pleno, o un piloto con y sin descuento, y definir qué significa «se sostiene».
- **Sostenida por evidencia, débil:** la afirmación de que Jóvenes no tiene app descansa en un solo cliente que dijo «Lo necesito y hoy no lo tengo» (2025-09-29). No nombra la app y esa evidencia ya cumple 12 meses, el umbral para considerarla envejecida.
- **Normativo:** no tengo la norma a la vista. Una app de clientes probablemente maneja datos personales, pero los documentos no dicen país ni qué datos recoge. Eso va a revisión jurídica.

También quedaron hallazgos del registro de requerimientos, que son de `/product-requirements`: 15 de 16 requerimientos aceptados sin proyecto que los ejecute, 5 sin criterio de aceptación, 2 sin evidencia, 1 sin doliente y 1 propuesto hace 120 días sin decidir.

Conviene convertir el supuesto en riesgo con doliente. No corresponde `/product-charter` mientras falte el criterio de éxito.

La corrida quedó registrada como `2026-10-16-product-definition-1`: 39 hallazgos y 31 segundos.

Archivos en `/home/claude/banco/ronda-5/retail/espacio/estado-producto/PRD-306/corridas/`:
- `salida-product-definition.md`
