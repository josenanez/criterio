# Corrida · 2026-10-16-change-control-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:change-control PRY-207 mover la salida a producción 30 días

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-207

**Inicio:** 2026-10-16T11:37:03 · **Fin:** 2026-10-16T11:38:23 · **Duración:** 81 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `change-control` | 13 | — | 56 | 54 | Evaluó mover 30 días el despliegue (2027-10-02 a 2027-11-01). Impacto en portafolio: 0, pero PRY-207 no declara dependencias. No supo: motivo, solicitante, impacto en alcance y costo, autoridad (no declarada), quién autorizó CC-01, y cuál es la fecha comprometida (acta 2027-09-06 contra línea base 1 2027-07-22). |

Por señal (`change-control`): `milestone_met_without_evidence` 13, `commitment_overdue` 8, `progress_vs_plan` 7, `declared_vs_evidence` 7, `variance_cost` 5, `commitment_undated` 5, `milestone_overdue` 2, `commitment_rescheduled` 2, `rebaseline_unauthorized` 1, `variance_time` 1, `change_without_baseline` 1, `pm_vs_pmo` 1, `silent` 1

## Lo que el agente mostró

Evalué mover 30 días la salida a producción de PRY-207, del 2027-10-02 al 2027-11-01, y no se puede aprobar todavía. La solicitud no trae motivo ni solicitante, y el acta no declara quién tiene autoridad para decidir. Por defecto el cambio va a comité.

Tomé «salida a producción» como el hito «Despliegue en la cadena». La ficha no tiene un hito con ese nombre.

- **Tiempo:** el cierre pasa a +102 días contra la línea base original (hoy +72). Alcance y costo quedan sin impacto declarado, y no lo estimé porque ningún documento da tarifas ni contratos.
- **Fecha comprometida dudosa:** el acta dice cierre 2027-09-06 y el cronograma v1, del mismo día, dice 2027-07-22. Contra el acta, el cambio sería +56 días.
- **Portafolio:** el cálculo no alcanza a ningún otro proyecto. Pero el acta dice «Ninguna declarada» en dependencias, así que eso es ausencia de declaración y no prueba de que no haya efecto.
- **CC-01 sin línea base propia:** la solicitud anterior (+72 días, +144.000.000 COP) está aprobada «por el comité» sin nombrar quién. El cronograma v2 es del 2026-09-26, anterior a esa autorización del 2026-10-08. El presupuesto aprobado sigue en 9.500.000.000 COP.
- **Estado declarado:** el informe lo da en verde con 72 días de atraso (15,8 %, umbral 10 %).
- **Línea base nueva:** no registré ninguna, porque nadie con autoridad la aprobó. Si se aprobara, sería la línea base 3 y las replanificaciones pasarían de 1 a 2.

Antes de llevarlo al comité del 2026-10-23 faltan cuatro cosas: el motivo, cuál fecha comprometida vale, la autoridad y las dependencias reales. Si lo quiere en paquete de comité, se prepara con `/steering-pack`.

Los términos ya estaban vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-16), así que no registré un comprobante nuevo.

La corrida quedó registrada como `2026-10-16-change-control-1`. La salida completa está en `/home/claude/banco/ronda-5/retail/espacio/estado/corridas/salida-change-control.md`.
