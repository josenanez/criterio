# Corrida · 2026-10-16-product-business-case-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-business-case (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-16T11:06:52 · **Fin:** 2026-10-16T11:07:58 · **Duración:** 66 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-business-case` | 16 | — | 41 | 39 | Caso de negocio armado: 1 cifra declarada (volumen_mensual 67.794) sin base ni serie medida; sin costos, sin criterio de exito, sin cifra de retorno; 15 requerimientos aceptados sin proyecto; supuesto de demanda sin verificar. No se produjeron cifras. |

Por señal (`product-business-case`): `requirement_untraced` 15, `evidence_stale` 14, `requirement_without_acceptance` 5, `requirement_accepted_without_evidence` 2, `requirement_undecided` 1, `requirement_without_owner` 1, `assumption_unverified` 1

## Lo que el agente mostró

Armé el caso de negocio de PRD-306 (App de clientes), y no se sostiene todavía: tiene una sola cifra, sin costos, sin criterio de éxito y sin cifra de retorno.

Los términos ya estaban aceptados por José Francisco Ñáñez el 2026-10-16, así que no los registré de nuevo. No produje ninguna cifra.

- **Cifras:** solo hay una, `volumen_mensual` = 67.794, declarada por Felipe Arango el 2026-03-16. El documento no dice qué cuenta ni de dónde sale, y la fuente que cita es el propio caso. No hay serie medida, así que no se puede contrastar.
- **Costos:** no hay ninguno en ningún documento. Es el primer vacío.
- **Éxito y retorno:** "Retorno esperado en 24 meses" no trae un valor, y el criterio de éxito no está escrito. Tampoco dice qué pasa si no se hace ni qué alternativas se consideraron.
- **Requerimientos:** hay 15 aceptados y ninguno tiene proyecto que lo ejecute. La demanda se apoya en una sola entrevista del 2025-09-29 que no nombra ningún requerimiento y ya pasó el umbral de 12 meses. REQ-4608 y REQ-2028 figuran sin quién los pidió, y REQ-4607 no tiene doliente. REQ-4603, REQ-4604, REQ-4608, REQ-4609 y REQ-4613 no tienen criterio de aceptación.
- **Supuesto:** "La demanda se sostiene sin descuento" lleva 196 días sin verificar, con un umbral de 30. Lo ofrezco para assumption-tracking.
- **Otros productos:** no hay fichas publicadas ni otro producto que repita la cifra, así que no vi solapamiento. Eso no descarta que aparezca cuando se publiquen.

No recomiendo pasar a `/product-charter` todavía.

La corrida quedó registrada como `2026-10-16-product-business-case-1`. El documento completo está en `estado-producto/PRD-306/corridas/salida-product-business-case.md`.
