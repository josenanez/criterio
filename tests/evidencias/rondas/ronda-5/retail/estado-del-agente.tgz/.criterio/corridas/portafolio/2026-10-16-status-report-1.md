# Corrida · 2026-10-16-status-report-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:status-report PRY-210

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-210

**Inicio:** 2026-10-16T11:31:55 · **Fin:** 2026-10-16T11:32:58 · **Duración:** 63 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `status-report` | 13 | — | 37 | 54 | Status de PRY-210: verde declarado contradicho por 3 señales (hitos sin evidencia, brecha de avance de 20 puntos, 20 días de silencio). Dije que no sé: producto, autoridad, fase, última reunión, responsables de RAID. |

Por señal (`status-report`): `milestone_met_without_evidence` 13, `commitment_overdue` 8, `progress_vs_plan` 7, `declared_vs_evidence` 7, `variance_cost` 5, `commitment_undated` 5, `milestone_overdue` 2, `commitment_rescheduled` 2, `rebaseline_unauthorized` 1, `variance_time` 1, `change_without_baseline` 1, `pm_vs_pmo` 1, `silent` 1

## Lo que el agente mostró

## PRY-210 · Etiquetas electrónicas de precio — estado al 2026-10-16

Sale de la ficha `estado/records/PRY-210.json` (actualizada el 2026-10-16) y de las cifras recalculadas por `compute` hoy. Los términos v1.1 ya estaban aceptados por José Francisco Ñáñez el 2026-10-16.

**Declara el gerente (Paula Céspedes):** verde · 20 % · al 2026-09-26, hace 20 días.
**Sustento documental:** contradicho.
**Lo que el semáforo no explica:** hitos cumplidos sin evidencia, brecha de avance contra el plan y silencio de 20 días (el umbral es 15).
**Último documento:** 2026-09-26 (informe de avance). **Última reunión:** sin dato.

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2027-05-08 | 2027-05-08 | 0 días |
| Presupuesto aprobado | 2.400.000.000 COP | 2.400.000.000 COP | la proyección de cierre, 2.283.077.690 COP, queda 4,9 % por debajo |

No hay replanificaciones ni solicitudes de cambio. Se ha ejecutado el 31,7 % (760.497.920 COP) y comprometido el 36,3 % (871.665.846 COP).

### Hitos
| Hito | Base y vigente | Estado | Evidencia |
|---|---|---|---|
| Diseño de la experiencia aprobado | 2026-03-27 | cumplido (declarado) | ninguna, hace 203 días |
| Ambiente de pruebas certificado | 2026-07-07 | cumplido (declarado) | ninguna, hace 101 días |
| Integración con el ERP | 2026-10-16 | pendiente | vence hoy, aún no vencido |
| Piloto en tiendas | 2027-01-26 | pendiente | — |
| Despliegue en la cadena | 2027-05-08 | pendiente | — |

### Dónde no coincide
- **Avance:** el gerente declara 20 %. Con 2 de 5 hitos cumplidos, el plan sustenta entre 40 % y 60 %, una brecha de 20,0 puntos. Como esos dos hitos no tienen evidencia, ninguna de las dos cifras está sustentada por un documento.
- **Verde:** el informe del 2026-09-26 dice verde, y las tres señales de arriba no caben en ese verde.
- **Proveedor CT-941 (Logística del Valle):** 1 de 2 entregables está aceptado, con acta del 2026-07-01. Lo facturado, 217.654.407 COP, es igual a lo aceptado. La bolsa de horas vence el 2026-12-23 y sigue pendiente.

### Abierto
- **Incidencia:** la validación con dos tiendas se extendió una semana por el conteo de inventario. Está abierta desde el 2026-09-26 (20 días) y no tiene responsable.
- **Riesgo:** un cambio en la regulación de datos personales podría mover el alcance. No tiene responsable ni fecha, así que no se pueden calcular días sin movimiento.
- **Compromisos vencidos:** no hay compromisos registrados.
- **Dependencias:** ninguna registrada.

### Sin dato
Producto, autoridad y fase del proyecto. Tampoco hay última reunión, responsables de riesgo e incidencia ni evidencia de los dos hitos cumplidos.

### Después
No hay desviación de plazo ni de costo sobre el umbral del 10 %, así que no corresponde una solicitud de cambio. Sí conviene pedir a la gerente la evidencia de los dos hitos y un informe actualizado. Puedo preparar el punto de comité si lo quieres.

---
Criterio Portfolio 0.3.11 · ficha del 2026-10-16 · campos inciertos: producto, autoridad, fase · [Términos y nota legal](https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.11)

La corrida quedó registrada como `2026-10-16-status-report-1`, con el texto completo en `estado/corridas/salida-status-report.md`.
