# Corrida · 2026-10-16-steering-pack-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:steering-pack (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-16T11:45:41 · **Fin:** 2026-10-16T11:47:44 · **Duración:** 123 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `steering-pack` | 13 | — | 101 | 54 | Paquete para el comité del 2026-10-23: 6 decisiones, 4 escalamientos. No hay registro del comité anterior ni autoridad en las 13 fichas; no se planteó como decisión el +30 días de PRY-207 (sin solicitante ni motivo). |

Por señal (`steering-pack`): `milestone_met_without_evidence` 13, `commitment_overdue` 8, `progress_vs_plan` 7, `declared_vs_evidence` 7, `variance_cost` 5, `commitment_undated` 5, `milestone_overdue` 2, `commitment_rescheduled` 2, `rebaseline_unauthorized` 1, `variance_time` 1, `change_without_baseline` 1, `pm_vs_pmo` 1, `silent` 1

## Lo que el agente mostró

El paquete para el comité del 2026-10-23 está listo y la corrida quedó registrada. El texto completo está en `estado/corridas/salida-steering-pack.md`. La corrida tomó 101 segundos sobre 13 proyectos.

Los términos ya estaban vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-16), así que no hubo que registrarlos de nuevo. Como nadie podía responder, tomé la respuesta sugerida en cada duda y la dejé dicha en el texto.

El paquete trae **6 decisiones** y **4 escalamientos sin decisión asociada**:
1. **Autoridad para aprobar cambios.** Ninguna de las 13 fichas la declara. Es el primer punto porque bloquea los puntos 2 y 3.
2. **CC-01 de PRY-200 (Tienda en línea).** Pide +27 días y +54.000.000 COP. El cronograma v2 ya movió la fecha sin autorización. Recomiendo devolverlo: su proyección supera el aprobado en 20,6 % y declara 79 % de avance sin ningún hito cumplido.
3. **CC-01 de PRY-207 (Marca propia).** Está aprobado sin acta ni línea base propia (+72 días, +144.000.000 COP). El acta y el cronograma v1 fijan fechas de cierre distintas, así que hay que decidir cuál vale.
4. **Hallazgo de seguridad en medios de pago.** Aparece idéntico en PRY-200, 209 y 211, sin dueño. No sé si es un solo hallazgo o tres.
5. **Riesgo de regulación de datos personales.** Afecta a cuatro proyectos y ninguno tiene dueño.
6. **Sobrecosto proyectado.** Cinco proyectos superan el umbral de 10 %. Cuatro de ellos declaran verde.

Los 4 escalamientos son: PRY-209 (fechas de cierre que no coinciden y compromisos reprogramados), la disponibilidad de los jefes de tienda para el piloto (siete proyectos), los hitos cumplidos sin evidencia (ocho proyectos) y PRY-210 (20 días en silencio).

- **Ciclo anterior sin cerrar:** no existe ningún registro del comité anterior, así que esa sección dice que no hay documento. No lo inventé.
- **Solicitud de +30 días de PRY-207:** no la planteé como decisión, porque no tiene solicitante ni motivo.
- **Pie de la versión 0.3.11:** incluye las fichas aplicadas y los campos inciertos.
