# Corrida · 2026-10-16-document-index-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:document-index (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-16T11:30:56 · **Fin:** 2026-10-16T11:31:50 · **Duración:** 55 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `document-index` | 13 | — | 34 | 54 | 72 documentos sin cambio, 0 por releer. 35 citas de PRY-209 sin resolver aunque los archivos existen y la ruta coincide byte a byte; causa no determinada, ninguna ficha modificada. |

Por señal (`document-index`): `milestone_met_without_evidence` 13, `commitment_overdue` 8, `progress_vs_plan` 7, `declared_vs_evidence` 7, `variance_cost` 5, `commitment_undated` 5, `milestone_overdue` 2, `commitment_rescheduled` 2, `rebaseline_unauthorized` 1, `variance_time` 1, `change_without_baseline` 1, `pm_vs_pmo` 1, `silent` 1

## Lo que el agente mostró

## Carpeta al 2026-10-16

**Documentos:** 72 · **Sin cambio:** 72 · **Hay que releer:** 0

Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-16), así que no los registré de nuevo.

No hay documentos nuevos, modificados, reguardados, renombrados ni borrados. No hay nada que releer, así que no ofrezco `/portfolio-scan`.

**Citas que dejaron de resolver:** el índice marca 35 citas, todas de PRY-209. Se reparten así:
- **Acta de constitución:** identidad, fechas de plan, alcance y moneda.
- **Informe de avance (PDF):** estado, avance y cifras de dinero.
- **Cronograma:** los hitos 0 a 3.
- **Acta de recibo del diseño:** evidencia del hito 0.

**Lo que no sé:** por qué el índice no las resuelve.
- Los archivos citados sí existen en `PRY-209-migración-del-erp/`.
- Los bytes de la ruta en `estado/records/PRY-209.json` coinciden con los del nombre de la carpeta.
- Los otros 12 proyectos no tienen el problema.
- Existe además una carpeta `estado/PRY-209-migración-del-erp/` que parece estar de más.

No toqué ninguna ficha. Hay que revisar cómo `portafolio.py index` resuelve la ruta de PRY-209.

**Formatos que no se pudieron leer:** este comando no lee contenido, así que no evaluó formatos.

Dejé la salida en `/home/claude/banco/ronda-5/retail/espacio/estado/corridas/salida-document-index.md` y registré la corrida con la nota correspondiente.
