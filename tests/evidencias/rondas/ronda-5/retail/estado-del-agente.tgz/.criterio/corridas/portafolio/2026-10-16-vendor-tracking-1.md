# Corrida · 2026-10-16-vendor-tracking-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:vendor-tracking PRY-210

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-210

**Inicio:** 2026-10-16T11:35:53 · **Fin:** 2026-10-16T11:36:57 · **Duración:** 64 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `vendor-tracking` | 13 | — | 40 | 54 | Proveedor CT-941 de PRY-210: 1 de 2 entregables aceptado con acta, facturado igual a aceptado. Señaló concepto genérico de la factura y entrega 11 días tarde sin días calculados. No supo vigencia, preaviso ni minutas con el proveedor. |

Por señal (`vendor-tracking`): `milestone_met_without_evidence` 13, `commitment_overdue` 8, `progress_vs_plan` 7, `declared_vs_evidence` 7, `variance_cost` 5, `commitment_undated` 5, `milestone_overdue` 2, `commitment_rescheduled` 2, `rebaseline_unauthorized` 1, `variance_time` 1, `change_without_baseline` 1, `pm_vs_pmo` 1, `silent` 1

## Lo que el agente mostró

El tramo del proveedor de PRY-210 está limpio: no hay entregables facturados sin evidencia, así que no hay nada que llevar a comité por este frente.

**Proveedor (Logística del Valle Ltda., contrato CT-941)**
- **Licenciamiento de la plataforma:** tiene acta de recibo del 2026-07-01, firmada por Paula Céspedes, que es quien el contrato exige. Está facturado por 217.654.407 COP, igual a lo aceptado. El contrato lo comprometía para el 2026-06-20, así que se recibió después de esa fecha.
- **Bolsa de horas de desarrollo:** vence el 2026-12-23. Sigue en curso, sin factura ni acta, y todavía no corresponde esperarlas.

**Dónde no cuadra**
- **Concepto de la factura:** FV-1941 dice «Entregables del contrato CT-941», en plural y sin nombrar cuál. Hay que pedir a cuentas por pagar su soporte, para confirmar que cubre solo el licenciamiento y no un anticipo de la bolsa de horas.
- **Firma del acta:** el PDF del acta muestra el nombre de quien recibe, pero no una firma visible. Eso se verifica contra el original.

**Sin dato**
- **Contrato:** no trae vigencia, renovación ni preaviso, así que no puedo decir si hay un preaviso por vencer.
- **Compromisos:** la carpeta no tiene minutas con el proveedor, así que no hay compromisos vencidos que reportar, pero eso es silencio y no confirma que no existan.

**Estado del proyecto**
- **Señales abiertas:** el informe del 2026-09-26 declara verde y 20 % de avance. Las señales abiertas son silencio de 20 días y avance contra plan con 20,0 puntos de brecha. Hay además dos hitos declarados cumplidos sin evidencia. Son señales del proyecto, no del proveedor.

**Una corrección a la corrida registrada:** la `--nota` dice «entrega 11 días tarde», pero no usé ese conteo en el informe porque el script no lo calcula. En el informe solo figuran las dos fechas.

**Registro:** los términos ya estaban vigentes (v1.1, aceptada por José Francisco Ñáñez el 2026-10-16), así que no los registré de nuevo. La corrida quedó registrada como `2026-10-16-vendor-tracking-1`. Lo que mostré está en `/home/claude/banco/ronda-5/retail/espacio/estado/corridas/salida-vendor-tracking.md`.
