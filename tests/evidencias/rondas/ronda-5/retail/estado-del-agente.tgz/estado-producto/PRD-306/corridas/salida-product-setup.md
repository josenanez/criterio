Soy Alba. Trabajo antes de que haya proyecto: miro qué sostiene tu definición y qué se sostiene solo.

Sin interfaz: tomé la respuesta sugerida en cada pregunta (gerente: Felipe Arango, del caso de negocio; decide: Comité de producto, porque el acta es suya y ningún documento lo dice; estado en `estado-producto/PRD-306`).

## Listo — App de clientes (PRD-306)

**Lo que miré:** 4 documentos · 1 de descubrimiento (una entrevista, del 2025-09-29) · la definición y el caso de negocio del 2026-03-16 · lo más reciente, el acta del comité del 2026-10-16 · formatos que no pude leer: ninguno. No hay transcripciones, ni tickets, ni encuestas, ni serie medida de ninguna métrica.
**Términos:** aceptados por José Francisco Ñáñez para la versión 0.3.11 (términos 1.1) · comprobante en `.criterio/terminos/aceptacion-criterio-product-0.3.11-2026-10-16.md` y `.pdf` · SHA-256 f969d4f658630df3…

### Lo que tu definición afirma, y qué lo sostiene
| Afirmación | Sostenida por | De cuándo |
|---|---|---|
| El segmento Jóvenes no tiene app de clientes | Una entrevista de un «cliente entrevistado»: «Lo necesito y hoy no lo tengo.» No dice que sea de Jóvenes ni de qué app habla | 2025-09-29 (12 meses) |
| Volumen mensual de 67.794 | Solo el propio caso de negocio; no hay ninguna serie medida con la que contrastarlo | 2026-03-16 |
| La demanda se sostiene sin descuento | Un supuesto declarado, sin verificar (196 días) | 2026-04-03 |
| Retorno esperado en 24 meses | Nada: sin cifra, sin base de cálculo | — |

### Lo que no está dicho en ninguna parte
- **El criterio de éxito del producto.** Ni la definición ni el caso de negocio lo escriben.
- **De dónde sale 67.794 al mes**, y que alguien lo esté midiendo. Nadie mide lo que el negocio afirmó.
- **Cuánto es el retorno esperado en 24 meses.**
- **Que Jóvenes sea el segmento de la entrevista.** La entrevista no identifica al cliente.
- **Qué propuesta se hace:** la definición dice «Propuesta principal» y nada más.
- **Quién decide qué se construye.** Lo anoté como Comité de producto porque el acta es suya, pero ningún documento lo dice.
- **Ningún proyecto construye este producto** («Ninguno declarado»): sin proyecto no hay traza.
- **Qué pidió cada uno de los 16 requerimientos.** Todos citan «Cliente entrevistado» y solo hay una entrevista, general, que no nombra ninguno.

En el registro de requerimientos (16: 15 aceptados, 1 propuesto):
- 14 tienen su única evidencia con 12 meses de antigüedad (la entrevista del 2025-09-29).
- 15 están sin proyecto que los ejecute.
- 5 aceptados sin criterio de aceptación: REQ-4603, 4604, 4608, 4609, 4613.
- 2 aceptados sin evidencia de demanda: REQ-4608 y REQ-2028 (el acta no dice quién los pidió).
- 1 sin doliente: REQ-4607 («sin asignar»).
- 1 propuesto sin decidir hace 120 días: REQ-4600.
- El acta del comité solo dice «Se mantiene el plan». Quién decidió cada aceptación no está escrito.

### Supuestos sobre los que está escrita
Uno declarado: «La demanda se sostiene sin descuento», del 2026-04-03, sin verificar, 196 días.

### Qué le falta a tu carpeta
- Las transcripciones de las entrevistas (hoy hay una sola, de un cliente sin nombre) y qué pidió cada quien.
- La serie medida de volumen mensual, con su fuente.
- Las decisiones del comité con quién decidió, para distinguir un requerimiento descartado de uno que nadie miró.

**Siguiente paso:** `/product-discovery` sobre el material de entrevistas, para convertir los temas en requerimientos con la cita de quién lo pidió.
