Términos: ya vigentes (v0.3.11, aceptados por José Francisco Ñáñez el 2026-10-16); no se registraron de nuevo.

**Antes de redactar: verificación del requerimiento (REQ-4601).** Faltan tres de los cuatro puntos y uno se cumple a medias. No hay nadie que responda, así que tomo la respuesta sugerida: sigo sin ellos, marcados como vacíos del acta y sin rellenarlos.

| Punto | Resultado | Por qué |
|---|---|---|
| Aceptado, no propuesto | **Sí, pero sin decisor** | Estado «aceptado» desde 2026-08-21 (`30-decisiones/2026-10-16-comite-producto.md`). El registro no dice quién lo aceptó (`decision.who` vacío). El único asistente del comité es Felipe Arango. |
| Criterios de aceptación verificables | **Vacío en la práctica** | El único criterio es «se verifica en producción». No dice qué se mide, con qué umbral ni cuándo. Sin eso el cierre no se puede juzgar. |
| Evidencia de demanda con cita | **Vacío** | La única evidencia es una entrevista del 2025-09-29: «Lo necesito y hoy no lo tengo.» No nombra el requerimiento. Es la misma entrevista que respalda a 14 de los 16 requerimientos. Tiene más de 12 meses (umbral `evidence_stale_months`: 12). |
| Autoridad del gerente declarada | **Vacío** | La definición no la declara. «Comité de producto» es inferido de que el acta de decisiones es del comité (`producto.json`, `identity.authority.note`). |

---

# Acta de constitución — Proyecto sin nombre (App de clientes) · borrador del 2026-10-16
**Producto:** PRD-306 · App de clientes · **Requerimientos:** REQ-4601

## Qué problema resuelve
«El segmento Jóvenes no tiene app de clientes.» (`00-definicion/2026-03-16-definicion-producto.md` · El problema). El problema no tiene medida de tamaño y el segmento «Jóvenes» no está definido (edad, canal, tamaño).
**Lo que dice REQ-4601 en sí:** nada. Su título es «Requerimiento REQ-4601» y su necesidad no está en ningún documento (`need`: no encontrado). Este acta no sabe qué se va a construir para resolver el problema. La propuesta de la definición es solo «Propuesta principal».

## Criterio de éxito
| Criterio | Cómo se verifica | Fuente |
|---|---|---|
| «se verifica en producción» (REQ-4601) | **No está dicho.** Falta qué se mide, el umbral y la fecha. | `30-decisiones/2026-10-16-comite-producto.md` |
| Éxito del producto | **No declarado.** La definición no tiene criterio de éxito. | `producto.json` · `definition.success` |

El único valor numérico del caso (volumen_mensual = 67.794) no trae fecha en la que debería alcanzarse ni dice qué cuenta (usuarios, sesiones, transacciones). No lo uso como criterio de éxito. Se lo dejo al gerente.

## Alcance
### Entra
| REQ | Título | Evidencia que lo sostiene |
|---|---|---|
| REQ-4601 | Requerimiento REQ-4601 (doliente: Diana Molina) | Entrevista «Cliente entrevistado», 2025-09-29, `10-descubrimiento/2025-09-29-entrevistas.md` · Necesidad principal. **No nombra este requerimiento**: es evidencia genérica, no demanda de REQ-4601. |

### No entra
| REQ | Título | Por qué no |
|---|---|---|
| REQ-4600 | Requerimiento REQ-4600 | Está en estado «propuesto», no aceptado. |
| REQ-4602, 4603, 4604, 4605, 4606, 4607, 4608, 4609, 4610, 4611, 4612, 4613, 2028, 2036 | Requerimientos aceptados del mismo producto | No se pidieron para este acta. Nadie ha dicho que vayan a otro proyecto: la columna «Proyecto que lo ejecuta» está en «—» para los 16. Quien arme el acta debe decidir si alguno entra. |

Tampoco entra, por no estar dicho en ningún lado: cualquier funcionalidad concreta de la app, el país y los datos que recoge, y el retorno esperado («Retorno esperado en 24 meses», sin cifra).

## Gobierno
**Patrocinador:** no dicho en ningún documento.
**Gerente propuesto:** no dicho. El gerente de producto es Felipe Arango (`00-definicion/2026-03-16-definicion-producto.md`), pero eso no lo hace gerente del proyecto. Asignarlo es de quien tiene la autoridad.
**Comité:** «Comité de producto», inferido (`producto.json`). Asistió Felipe Arango. Ningún documento lo constituye.
**Autoridad del gerente:** no dicho. Sin ella el gerente del proyecto no sabrá qué puede decidir y escalará todo o nada.
**Doliente del requerimiento:** Diana Molina (`30-decisiones/2026-10-16-comite-producto.md`).
**Quién aceptó REQ-4601:** no registrado.

## Supuestos que se llevan al proyecto
| Supuesto | Verificado | Se convierte en riesgo de |
|---|---|---|
| La demanda se sostiene sin descuento (declarado el 2026-04-03) | **No.** Lleva más de 30 días sin verificar (`assumption_unverified_days`: 30). | **Sin doliente.** Se registra como riesgo del proyecto y el acta no puede nombrar a quién. Lo propongo para el gerente del proyecto. |
| Implícito: el volumen de 67.794 al mes se alcanza | No afirmado por nadie | Sin doliente. El negocio debe decir de dónde sale la cifra. |
| Implícito: la entrevista del 2025-09-29 vale como demanda de REQ-4601 | No | Sin doliente. Hoy no hay otra evidencia. |

## Restricciones normativas sin resolver
| Qué toca | Obligación | Norma | Estado |
|---|---|---|---|
| Una app de clientes probablemente maneja datos personales | No declarada | — | **Sin resolver.** Los documentos no dicen país ni qué datos recoge. No tengo la norma a la vista. Esto no dice que cumpla ni que no cumpla: va a revisión jurídica. |

## Vacíos de este acta
| Qué falta | Consecuencia de firmar sin eso | Quién lo cierra |
|---|---|---|
| Quién aceptó REQ-4601 | La decisión de construir no tiene un decisor al que preguntar | Comité de producto / Felipe Arango |
| Qué es REQ-4601 (título, necesidad) | Se firma un proyecto sin saber qué se construye | Diana Molina (doliente) |
| Criterio de aceptación verificable | El cierre no se puede juzgar meses después | Diana Molina con Felipe Arango |
| Evidencia de demanda específica | Se construye sobre una frase genérica de hace más de 12 meses | Felipe Arango (nueva ronda de descubrimiento) |
| Criterio de éxito y fecha de corte del producto | Nada contra qué medir ni cerrar | Felipe Arango / negocio |
| Autoridad del gerente del proyecto | Escala todo o no escala nada | Comité de producto |
| Patrocinador y gerente del proyecto | Sin firmante ni dueño de la ficha | Quien tenga autoridad sobre el producto |
| Presupuesto e hitos | La ficha nace sin ellos; el acta no declara ninguno | Patrocinador |
| País y datos que recoge la app | Obligaciones normativas sin evaluar | Revisión jurídica |

---
**Esto es un borrador.** Lo firma el patrocinador, que no está nombrado en ningún documento. La ficha del proyecto no se creó y se crea después de la firma.

**Qué sigue y para quién:** cuando alguien firme, el gerente del proyecto instala `criterio-project` y corre `/pm-setup`. Cuando publique su ficha con `/pm-publish`, `/product-trace` podrá confirmar la traza contra ella y Alba sabrá si el producto se está construyendo sin preguntarle a nadie. Hoy el comité dice «Se mantiene el plan», pero ninguno de los 16 requerimientos tiene proyecto asignado.
