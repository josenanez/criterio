# Caso de negocio — App de clientes (PRD-306) · borrador del 2026-10-16
**Desde:** la definición de producto y el caso de negocio, ambos del 2026-03-16 · **Cifras con fuente:** 1 de 1 (y esa 1 es declarada; ninguna es medida)

> Aviso: las cifras son del negocio. Este borrador no proyecta ingresos, retorno ni ahorro, ni recomienda aprobar o rechazar.

## Qué problema resuelve, y para quién
"El segmento Jóvenes no tiene app de clientes." — `00-definicion/2026-03-16-definicion-producto.md` · El problema (2026-03-16). Segmento: Jóvenes, mismo documento.

Propuesta: la definición solo dice "Propuesta principal"; no describe qué se construye. Va a vacíos.

## Qué se construye
Entran los requerimientos decididos (estado *aceptado*) según el acta del comité del 2026-10-16. REQ-4600 sigue *propuesto* y queda fuera. Los 15 aceptados no tienen proyecto que los ejecute (la definición dice "Ninguno declarado").

| Requerimiento | Estado | Evidencia de demanda |
|---|---|---|
| REQ-4601 | aceptado (desde 2026-08-21) | "Cliente entrevistado" |
| REQ-4602 | aceptado (2026-04-20) | "Cliente entrevistado" |
| REQ-4603 | aceptado (2026-06-03) | "Cliente entrevistado"; sin criterio de aceptación |
| REQ-4604 | aceptado (2026-07-24) | "Cliente entrevistado"; sin criterio de aceptación |
| REQ-4605 | aceptado (2026-03-26) | "Cliente entrevistado" |
| REQ-4606 | aceptado (2026-07-23) | "Cliente entrevistado" |
| REQ-4607 | aceptado (2026-08-23) | "Cliente entrevistado"; **sin doliente** |
| REQ-4608 | aceptado (2026-08-05) | **Nadie lo pidió según el acta**; sin criterio de aceptación |
| REQ-4609 | aceptado (2026-08-27) | "Cliente entrevistado"; sin criterio de aceptación |
| REQ-4610 | aceptado (2026-06-22) | "Cliente entrevistado" |
| REQ-4611 | aceptado (2026-05-18) | "Cliente entrevistado" |
| REQ-4612 | aceptado (2026-06-15) | "Cliente entrevistado" |
| REQ-4613 | aceptado (2026-06-02) | "Cliente entrevistado"; sin criterio de aceptación |
| REQ-2028 | aceptado (2026-09-19) | **Nadie lo pidió según el acta** |
| REQ-2036 | aceptado (2026-10-04) | "Cliente entrevistado" |

Fuente de todas las filas: `30-decisiones/2026-10-16-comite-producto.md`. La única evidencia de demanda disponible es una entrevista del 2025-09-29 con una frase general: "Lo necesito y hoy no lo tengo" (`10-descubrimiento/2025-09-29-entrevistas.md`). No nombra ningún requerimiento, y tiene más de 12 meses (umbral de antigüedad configurado: 12 meses). Nada la liga a un REQ concreto.

## Las cifras
| Cifra | Valor | Clase | De dónde sale | De cuándo |
|---|---|---|---|---|
| volumen_mensual | 67.794 | **Declarada** | `00-definicion/2026-03-16-caso-de-negocio.md` · Cifras que sostienen el caso (preparado por Felipe Arango) | 2026-03-16 |

El documento no dice qué cuenta ese volumen (transacciones, usuarios, descargas) ni de qué cálculo sale. La fuente declarada es el propio caso de negocio, es decir, la cifra se cita a sí misma. Mientras no haya una base, trátala como declarada sin sustento verificable.

### Donde la cifra declarada y la medida no coinciden
| Métrica | Declarada | Medida | Las dos fuentes y fechas |
|---|---|---|---|
| volumen_mensual | 67.794 (2026-03-16) | **No hay serie medida** | No se puede contrastar: no existe ningún documento con la serie. El producto no tiene app hoy, así que quien mide sería el sistema donde viva. |

## Los costos
| Concepto | Valor | De dónde sale |
|---|---|---|
| Costo de construir | — | **No está en ningún documento** |
| Costo de operar | — | No está en ningún documento |

No hay contratos, cotizaciones ni costo declarado del equipo. Es el primer vacío: sin él lo que hay es una propuesta, no un caso de negocio evaluable.

## Supuestos sobre los que se sostiene
| Supuesto | Qué pasa si resulta falso | Quién lo verificaría |
|---|---|---|
| La demanda se sostiene sin descuento (declarado 2026-04-03, **sin verificar**, 196 días; umbral 30) | El volumen declarado depende de descuentos que el caso no cuenta como costo | Sin asignar; la definición no nombra a nadie |
| *Supuesta, implícita:* el volumen de 67.794 al mes se alcanza | Cae el retorno esperado, que ya es una frase sin cifra | Nadie la ha afirmado; el negocio debe decir de qué sale |
| *Supuesta, implícita:* el segmento Jóvenes adoptará una app (la entrevista de 2025-09-29 es una sola voz) | El problema declarado no es el problema de la demanda | Descubrimiento de producto |

Nota: el supuesto está fechado 2026-04-03, posterior a la fecha de la definición (2026-03-16); se registra tal cual está en el documento.

## Vacíos
| Qué falta | Por qué importa | Quién lo produce |
|---|---|---|
| Costo de construir y de operar | Sin él no hay caso que evaluar | Quien tenga el presupuesto o las cotizaciones; sin asignar |
| Base de la cifra volumen_mensual (qué mide, de qué sale) | La única cifra del caso se cita a sí misma | Felipe Arango (autor del caso) |
| Cifra de retorno ("Retorno esperado en 24 meses" no tiene valor) | No hay número que sustentar ni contradecir | El negocio |
| Criterio de éxito (no está en la definición) | Sin él no se puede cerrar el producto meses después | Felipe Arango / Comité de producto |
| Qué pasa si no se hace | El caso no compara contra nada | El negocio |
| Alternativas consideradas | No se sabe qué más se evaluó | El negocio |
| Qué se construye ("Propuesta principal" sin contenido) | La propuesta no se puede evaluar | Felipe Arango |
| Proyecto que ejecute los requerimientos | 15 requerimientos aceptados sin quién los construya | Comité de producto |
| Demanda ligada a cada requerimiento; REQ-4608 y REQ-2028 sin quién los pidió; REQ-4607 sin doliente | Aceptados sin sustento de demanda o de responsable | Doliente de cada uno / comité |
| Serie medida del producto | Impide contrastar lo declarado | Sistema donde viva el producto |

## Cómo se sabrá si funcionó
**No está declarado.** La definición no tiene criterio de éxito, ni métrica, ni fecha de corte. El único valor numérico (67.794 al mes) no trae fecha en la que debería alcanzarse. Sin esto el producto no se puede cerrar meses después.

## Si hay otros productos publicados
No hay fichas publicadas de otros productos a la vista (existen carpetas de documentos PRD-299 a PRD-309, pero ninguna ficha publicada con `/product-publish`), y ninguna repite la cifra 67.794 en los documentos revisados. No se detectó solapamiento; esto no descarta que exista cuando se publiquen.

## Después
- Pasar los supuestos al seguimiento con **assumption-tracking** (el de la demanda sin descuento lleva 196 días sin verificar).
- `/product-charter` no corresponde todavía: el caso no tiene costos, éxito ni retorno cifrado.
