# Corrida del 2026-10-16 · product-definition

PRD-306 · 16 requerimientos · 31 s · 39 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 15 |
| `evidence_stale` | 14 |
| `requirement_without_acceptance` | 5 |
| `requirement_accepted_without_evidence` | 2 |
| `requirement_undecided` | 1 |
| `requirement_without_owner` | 1 |
| `assumption_unverified` | 1 |

Sin contradicciones; la cifra de volumen no tiene serie; un supuesto de 196 días; falta criterio de éxito; evidencia de demanda de 12 meses y de una sola entrevista

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

## Definición — App de clientes (PRD-306) · contrastada al 2026-10-16
**Documento:** 00-definicion/2026-03-16-definicion-producto.md y 00-definicion/2026-03-16-caso-de-negocio.md · **del** 2026-03-16 · 6 afirmaciones

Nota de la prueba: sesión sin interfaz; los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-16), no se registraron de nuevo.

### Lo que la evidencia contradice
Nada. Ninguna fuente dice lo contrario de lo que la definición afirma. Eso no es lo mismo que que esté sostenida: ver más abajo.

### El negocio y los datos
Ninguna métrica pasa del umbral (20 %), porque ninguna tiene serie medida con qué compararse.

### Afirmaciones numéricas que nadie mide
| Afirma | De qué documento | No hay serie |
|---|---|---|
| volumen_mensual = 67.794 | 00-definicion/2026-03-16-caso-de-negocio.md · Cifras que sostienen el caso (2026-03-16) | No hay ninguna serie medida de volumen_mensual en el estado del producto. No es contradicción: nadie está midiendo lo que el caso de negocio afirmó. El documento tampoco dice qué cuenta ese volumen (usuarios, sesiones, transacciones). |

### No está dicho en ninguna parte
- **El criterio de éxito.** Ningún documento lo declara.
- **Qué es la propuesta.** La sección «La propuesta» contiene solo «Propuesta principal», sin contenido.
- **Cuántos son «Jóvenes».** El segmento se nombra pero no se define (edad, canal, tamaño); la cifra de 67.794 no se ata a él.
- **Cuánto pagaría o qué retornaría.** «Retorno esperado en 24 meses» no trae cifra, base ni cálculo.
- **Qué proyecto lo construye.** La definición dice «Ninguno declarado»; ninguno de los 16 requerimientos está trazado a un proyecto.
- **Quién decide.** Ningún documento lo dice; «Comité de producto» está inferido de que el acta es del comité.
- **Si el entrevistado es del segmento Jóvenes.** La entrevista no lo dice.

### Sostenida por un supuesto
| Supuesto | Días sin verificar | Qué haría falta para verificarlo |
|---|---|---|
| La demanda se sostiene sin descuento (declarado 2026-04-03) | 196 (umbral 30) | Una observación de compra o uso a precio pleno, es decir alguien que ya usó o pagó sin incentivo, o un piloto con y sin descuento. Hoy el supuesto no tiene definido qué es «se sostiene» (cuánta demanda, por cuánto tiempo); sin ese umbral no se puede desmentir. |

### Sostenida por evidencia
| Afirmación | Sostenida por | De cuándo | Qué tan fuerte |
|---|---|---|---|
| El segmento Jóvenes no tiene app de clientes | 10-descubrimiento/2025-09-29-entrevistas.md · un cliente: «Lo necesito y hoy no lo tengo.» (Tema: Necesidad principal) | 2025-09-29 | Débil. Es una sola persona que dijo que lo necesitaría (lo más bajo de la jerarquía de demanda: alguien dijo, nadie pagó ni usó). No nombra la app ni dice si es del segmento. |

### Evidencia que ya envejeció
| Afirmación | Lo más nuevo que la sostiene | Hace |
|---|---|---|
| El segmento Jóvenes no tiene app de clientes | Entrevista del 2025-09-29 | 12 meses (umbral 12) |

Esa misma entrevista es la única evidencia de 14 de los 16 requerimientos, y para ninguno nombra el requerimiento.

### Lo normativo que toca
| Qué toca | País | Obligación | Norma | Estado |
|---|---|---|---|---|
| Una app de clientes probablemente maneja datos personales de los clientes | No declarado en la definición | — | — | No tengo la norma a la vista. Los documentos no dicen país ni qué datos recoge la app, y no hay ninguna norma entre ellos. Esto no dice que cumpla ni que no cumpla; va a revisión jurídica. |

### Lo que falta para cerrar la definición
- **Criterio de éxito:** no declarado. Sin él el producto no se puede cerrar, porque el cierre se juzga contra él meses después.
- **Quién decide:** no declarado; solo inferido.
- **Problema y para quién:** están escritos (una línea cada uno), pero el problema no tiene medida de tamaño ni el segmento una definición.

Otros hallazgos del registro que tocan la definición (no son de este comando, quedan para `/product-requirements`): 15 de 16 requerimientos aceptados sin proyecto que los ejecute; 5 aceptados sin criterio de aceptación; 2 aceptados sin evidencia; 1 sin doliente; 1 propuesto hace 120 días sin decidir.

### Después
El supuesto lleva 196 días sin verificar: conviene convertirlo en riesgo con doliente (raid-taxonomy). La definición no está cerrada (falta criterio de éxito), así que no corresponde `/product-charter`.
