# Corrida del 2026-10-16 · product-wake

PRD-306 · 16 requerimientos · 66 s · 39 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 15 |
| `evidence_stale` | 14 |
| `requirement_without_acceptance` | 5 |
| `requirement_accepted_without_evidence` | 2 |
| `requirement_undecided` | 1 |
| `requirement_without_owner` | 1 |
| `assumption_unverified` | 1 |

Primera revisión, sin corte anterior: reporta el estado de partida y no 'crossed'. 16 REQ, 1 sin decidir 120 días, 1 supuesto 196 días, 14 con evidencia vencida, 15 aceptados sin traza. No pudo confirmar trazas porque ninguna ficha nombra PRD-306. Avisa de una discrepancia de rutas en plan-lectura sin verificarla.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

## App de clientes (PRD-306) · 2026-10-16

**Primera revisión del registro: no hay corte anterior**, así que no puedo decir qué cruzó un umbral desde entonces. Lo de abajo es el estado de partida, y desde la próxima corrida solo se reportará lo nuevo.

**Términos:** ya estaban vigentes (v1.1, familia 0.3.11), aceptados por José Francisco Ñáñez el 2026-10-16. No se pidió ni registró nada nuevo.

**Registro:** 16 requerimientos (15 aceptados, 1 propuesto). Los 4 documentos de la carpeta no cambiaron, así que no se releyó nada.

### Lo que necesita decisión
| Qué | REQ | Cuánto lleva | Qué se necesita | Quién |
|---|---|---|---|---|
| Sin decidir (umbral 60 días) | REQ-4600 | 120 días, desde 2026-06-18 | Que alguien con la facultad lo acepte o lo descarte. El doliente es Camilo Beltrán, y ningún documento dice quién decide: el Comité de producto figura como autoridad por inferencia. | Comité de producto (por confirmar) |
| Supuesto sin verificar (umbral 30 días) | «La demanda se sostiene sin descuento» | 196 días, desde 2026-04-03 | Definir qué dato la verificaría. Ya pasó el punto en que conviene tratarla como riesgo registrado. | Felipe Arango |
| Aceptados sin evidencia de demanda | REQ-2028 (Sandra Gil), REQ-4608 (María Restrepo) | Aceptados el 2026-09-19 y el 2026-08-05 | Quién lo pidió. REQ-4608 tampoco tiene criterio de aceptación. | Dolientes |
| Aceptados que nadie está construyendo | Los 15 aceptados | Ninguno nombra un proyecto | Ninguna de las 13 fichas de proyecto nombra PRD-306. Falta un proyecto, o falta que las fichas lo digan. | Felipe Arango |

### Qué afirmación se queda sin sustento
- **Evidencia vencida (umbral 12 meses):** 14 requerimientos se apoyan solo en las entrevistas del 2025-09-29, que ya cumplieron 12 meses. El hallazgo es que la afirmación de que los Jóvenes necesitan la app depende de una sola ronda de entrevistas. Esa ronda tiene además una limitación: la cita no nombra qué requerimiento sustenta.
- **Cifra del caso de negocio:** declara 67.794 de volumen mensual, y no hay ninguna medición contra la cual contrastarla (sin carpeta de métricas).
- **Criterio de éxito:** no está en ningún documento.

### Vacíos menores
- REQ-4607 está aceptado y no tiene doliente.
- Cinco aceptados no tienen criterio de aceptación: REQ-4603, REQ-4604, REQ-4608, REQ-4609 y REQ-4613.

### Las trazas
Con la carpeta de fichas a la vista (`estado/records`, 13 proyectos): ninguna ficha nombra PRD-306 y ningún requerimiento declara proyecto, por lo que no hay traza que confirmar ni una que se haya perdido.

### Del descubrimiento
No hay documentos nuevos. Hay una discrepancia de rutas que revisar: `plan-lectura` marca como «fuente no encontrada» las citas de la ficha de producto, aunque los archivos existen. Parece un problema del prefijo de la ruta y no de los documentos, pero no lo verifiqué.

**Vuelvo el 2026-11-15.**
