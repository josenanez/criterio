# Corrida del 2026-10-16 · product-spec

PRD-306 · 16 requerimientos · 49 s · 39 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 15 |
| `evidence_stale` | 14 |
| `requirement_without_acceptance` | 5 |
| `requirement_accepted_without_evidence` | 2 |
| `requirement_undecided` | 1 |
| `requirement_without_owner` | 1 |
| `assumption_unverified` | 1 |

Borrador sin comportamiento: 15 aceptados, 0 con necesidad; 10 criterios genéricos y 5 ausentes; REQ-4607 sin doliente; supuesto de demanda sin verificar 196 días; sin proyecto constructor ni base para barrido normativo.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

> **Borrador para el gerente de producto, Felipe Arango, que es quien lo cierra. Este agente no lo aprueba ni lo firma.**

# Especificación — App de clientes (PRD-306) · borrador del 2026-10-16

**Resultado en una línea:** el registro no alcanza para especificar comportamiento. Los 15 requerimientos aceptados llegan sin necesidad, sin título propio y sin prioridad, así que **ninguna sección de comportamiento se pudo escribir sin inventarla**. Lo que sigue deja los huecos a la vista y no los rellena.

## Qué problema resuelve

«El segmento Jóvenes no tiene app de clientes.» (definición, 2026-03-16, «El problema»). La definición no dice criterio de éxito, no declara proyecto que la construya y su propuesta es solo «Propuesta principal». Ninguno de los 15 requerimientos dice qué parte de ese problema resuelve.

## Alcance

### Entra
Los 15 requerimientos en `aceptado`, tal como están registrados, **sin contenido que especificar**: REQ-2028, REQ-2036, REQ-4601 a REQ-4613. Todos se titulan «Requerimiento REQ-xxxx» y tienen `need` sin encontrar (fuente: acta del comité, 2026-10-16).

### No entra
- **REQ-4600**: está en `propuesto` (desde 2026-06-18, doliente Camilo Beltrán). Nadie lo ha decidido; especificarlo es escribir el documento dos veces.
- Todo lo que el registro no dice: funciones de la app, canales, autenticación, pagos o datos del cliente. Ningún documento lo menciona, y este borrador no lo propone.
- Diseño técnico, estimación de esfuerzo, costo y fecha (no son de este comando).

## Comportamiento

**Sin secciones.** Escribir qué hace cada requerimiento exigiría inventar la necesidad que ninguno declara. Cobertura de comportamiento: **0 de 15**.

## Criterios de aceptación

Diez requerimientos traen el mismo criterio, «se verifica en producción». **No pasa la prueba:** dos personas mirando lo construido no tienen cómo llegar a la misma respuesta, porque no dice qué se observa ni con qué umbral. Cinco no traen criterio.

| Criterio | Requerimiento | Cómo se verifica | ¿Se puede medir hoy? |
|---|---|---|---|
| «se verifica en producción» | REQ-2028, 2036, 4601, 4602, 4605, 4606, 4607, 4610, 4611, 4612 | No definido: no dice qué se mide ni el umbral | **No verificable todavía.** Tampoco hay métricas registradas (`metrics/` está vacío) |
| Sin criterio | REQ-4603, 4604, 4608, 4609, 4613 | — | — |

No reescribo un criterio mejor: sería adivinar el comportamiento esperado.

## Supuestos sobre los que está escrita

| Supuesto | Verificado | Quién lo verificaría |
|---|---|---|
| La demanda se sostiene sin descuento (declarado 2026-04-03) | No. Lleva 196 días sin verificar; el umbral es 30 | Sin nombrar. Propongo a Felipe Arango, quien firma la definición |
| El volumen mensual de 67.794 (caso de negocio, 2026-03-16) es la demanda real | Sin contraste: no hay serie medida | Sin nombrar. Propongo a Felipe Arango |

## Vacíos

| Qué falta decidir | Consecuencia de no decidirlo | Quién lo cierra |
|---|---|---|
| Qué necesita cada requerimiento (los 15 sin `need`) | No hay nada que construir ni probar | Cada doliente (ver abajo); Felipe Arango consolida |
| Criterio de aceptación verificable en los 15 (10 genérico, 5 ausente) | Se discute si quedó bien después de construirlo | Cada doliente; Felipe Arango valida |
| REQ-4607 no tiene doliente | Nadie responde por él ni lo cierra | Felipe Arango asigna |
| Quién decidió la aceptación (`decision.who` vacío en los 15; el acta dice solo «Se mantiene el plan») | Aceptaciones sin autor; la autoridad («Comité de producto») es inferida, ningún documento la declara | Comité de producto / Felipe Arango |
| Origen de la demanda: una sola cita genérica («Lo necesito y hoy no lo tengo») está asignada a 13 requerimientos, y no nombra ninguno. REQ-2028 y REQ-4608 no tienen ni eso | Se acepta algo que nadie ha pedido de forma comprobable | Felipe Arango |
| Casos borde (sin conexión, operación duplicada, abandono a mitad de flujo) | Cada equipo los decide por su cuenta | Dolientes, con quien construya |
| Criterio de éxito del producto: no está en la definición | No hay contra qué medir si la app funcionó | Felipe Arango |
| Prioridad: no registrada en ninguno de los 15 | No hay orden de construcción | Comité de producto |
| Qué otro equipo debe hacer algo: no consta ninguno, y **la definición dice «Ninguno declarado» de proyectos que construyen el producto**. Los 15 tienen «—» en Proyecto que lo ejecuta | Lo aceptado no tiene quien lo construya | Felipe Arango, con quien dirija el equipo constructor |
| Obligaciones normativas: la definición no dice qué datos maneja la app, así que no hay base para hacer el barrido. No afirmo que aplique ni que no | Un criterio como «cumple la normativa» quedaría sin sustento | Felipe Arango define los datos; el área legal o de cumplimiento (sin nombrar) revisa |

**Dolientes de los requerimientos:** Sandra Gil (REQ-2028, 4612), Javier Hoyos (2036), Diana Molina (4601), Jorge Medina (4602), Camilo Beltrán (4603), Mauricio Pérez (4604, 4613), Paula Céspedes (4605), Andrés Lozano (4606), María Restrepo (4608), Natalia Ospina (4609), Elena Duarte (4610), Liliana Torres (4611).

## Requerimientos aceptados que esta especificación no cubre

Ninguna sección cubre comportamiento, así que los 15 aparecen aquí.

| REQ | Título | Por qué no |
|---|---|---|
| REQ-2028 | Requerimiento REQ-2028 | Sin necesidad, sin evidencia, criterio genérico |
| REQ-2036 | Requerimiento REQ-2036 | Sin necesidad, criterio genérico |
| REQ-4601 | Requerimiento REQ-4601 | Sin necesidad, criterio genérico |
| REQ-4602 | Requerimiento REQ-4602 | Sin necesidad, criterio genérico |
| REQ-4603 | Requerimiento REQ-4603 | Sin necesidad, sin criterio |
| REQ-4604 | Requerimiento REQ-4604 | Sin necesidad, sin criterio |
| REQ-4605 | Requerimiento REQ-4605 | Sin necesidad, criterio genérico |
| REQ-4606 | Requerimiento REQ-4606 | Sin necesidad, criterio genérico |
| REQ-4607 | Requerimiento REQ-4607 | Sin necesidad, sin doliente, criterio genérico |
| REQ-4608 | Requerimiento REQ-4608 | Sin necesidad, sin evidencia, sin criterio |
| REQ-4609 | Requerimiento REQ-4609 | Sin necesidad, sin criterio |
| REQ-4610 | Requerimiento REQ-4610 | Sin necesidad, criterio genérico |
| REQ-4611 | Requerimiento REQ-4611 | Sin necesidad, criterio genérico |
| REQ-4612 | Requerimiento REQ-4612 | Sin necesidad, criterio genérico |
| REQ-4613 | Requerimiento REQ-4613 | Sin necesidad, sin criterio |

## Después

**No ofrezco `/product-charter` todavía.** Faltan necesidades, criterios y criterio de éxito. Cuando se cierren, este borrador se puede rehacer.

---
*Sale del registro de requerimientos de PRD-306 (16 requerimientos; 15 aceptados cubiertos por el alcance, 0 con comportamiento especificado), actualizado el 2026-10-16, y de la definición y el caso de negocio del 2026-03-16. Términos aceptados por José Francisco Ñáñez el 2026-10-16: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.11*
