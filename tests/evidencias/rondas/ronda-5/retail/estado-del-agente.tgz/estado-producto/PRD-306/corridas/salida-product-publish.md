No publiqué la ficha de PRD-306 (App de clientes). Corte: 2026-10-16.

**Motivo:** la configuración no define una carpeta de productos publicados (no hay `productos/publicados/` ni ruta equivalente en `config.json`). Sin un sitio común acordado, publicar no sirve; acordarlo es una conversación de la organización, no un comando. No creé ninguna carpeta ni inventé una ruta.

**Lo que habría llevado la ficha (calculado, no escrito en ningún sitio):**
- 16 requerimientos (15 aceptados, 1 propuesto) · 0 proyectos · 1 métrica afirmada
- Segmento declarado: Jóvenes
- Métrica: volumen_mensual = 67794, de documentos/productos/PRD-306/00-definicion/2026-03-16-caso-de-negocio.md · Cifras que sostienen el caso (2026-03-16)

**Dato a tener en cuenta al publicar:** ningún requerimiento está ligado a un proyecto (0 de 16 trazados).

**Para continuar:** indica la carpeta de productos publicados y corre de nuevo /product-publish.
