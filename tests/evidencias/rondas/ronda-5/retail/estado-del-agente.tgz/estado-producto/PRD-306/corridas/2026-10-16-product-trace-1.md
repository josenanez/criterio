# Corrida del 2026-10-16 · product-trace

PRD-306 · 16 requerimientos · 44 s · 39 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 15 |
| `evidence_stale` | 14 |
| `requirement_without_acceptance` | 5 |
| `requirement_accepted_without_evidence` | 2 |
| `requirement_undecided` | 1 |
| `requirement_without_owner` | 1 |
| `assumption_unverified` | 1 |

15 aceptados decididos y ninguno con proyecto; ninguna ficha declara PRD-306

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

## Trazabilidad — App de clientes (PRD-306) · al 2026-10-16
15 decididos · 0 con proyecto · 0 confirmados contra la ficha · 0 entregados

### Decidido y nadie lo está construyendo
Los 15 requerimientos aceptados tienen «Proyecto que lo ejecuta: —» en el comité del 2026-10-16 (documentos/productos/PRD-306/30-decisiones/2026-10-16-comite-producto.md). Decide el Comité de producto; el acta lista como único asistente a Felipe Arango. La decisión del acta es «Se mantiene el plan», que no nombra proyecto.

| REQ | Doliente | Decidido el |
|---|---|---|
| REQ-4602 | Jorge Medina | 2026-04-20 |
| REQ-4611 | Liliana Torres | 2026-05-18 |
| REQ-4613 | Mauricio Pérez | 2026-06-02 |
| REQ-4603 | Camilo Beltrán | 2026-06-03 |
| REQ-4612 | Sandra Gil | 2026-06-15 |
| REQ-4610 | Elena Duarte | 2026-06-22 |
| REQ-4605 | Paula Céspedes | 2026-03-26 |
| REQ-4606 | Andrés Lozano | 2026-07-23 |
| REQ-4604 | Mauricio Pérez | 2026-07-24 |
| REQ-4608 | María Restrepo | 2026-08-05 |
| REQ-4601 | Diana Molina | 2026-08-21 |
| REQ-4607 | sin asignar | 2026-08-23 |
| REQ-4609 | Natalia Ospina | 2026-08-27 |
| REQ-2028 | Sandra Gil | 2026-09-19 |
| REQ-2036 | Javier Hoyos | 2026-10-04 |

(La columna «Decidido el» es la fecha «Desde» del acta de comité.) El más antiguo lleva sin proyecto casi siete meses (REQ-4605, desde 2026-03-26).
REQ-4600 sigue «propuesto» (120 días sin decidir, desde 2026-06-18); no cuenta como decidido.

### La traza no se confirma
Ninguna: ningún requerimiento declara un proyecto, así que no hay traza que confirmar ni desmentir.

### Lo que un proyecto construye y el registro no tiene
No se encontró ninguna ficha que diga ejecutar PRD-306. Las fichas leídas (estado/records, 13): PRY-199 declara PRD-299 (otro producto); PRY-200, 201, 205, 207, 204 y 208 declaran una descripción de producto en texto libre («venta en línea», «puntos de fidelización», «pago con QR», «marca propia», «autopago en tienda», «entrega rápida») que no es un código de producto; PRY-202, 203, 206, 209, 210 y 211 tienen el campo vacío. Estos últimos son un hallazgo del lado de esas fichas: no se puede descartar que alguno construya la app.

### La cadena completa
| REQ | Estado | Decisión | Proyecto | Confirmado | Entregables |
|---|---|---|---|---|---|
| 15 aceptados (REQ-2028, 2036, 4601–4613) | aceptado | Comité 2026-10-16 («Se mantiene el plan») | — | no | — |
| REQ-4600 | propuesto | sin decidir | — | no | — |

La cadena se rompe en el segundo eslabón: de decisión a proyecto no hay cita en ningún caso.

### Sin fichas a la vista
Ningún REQ nombra proyecto, así que no se pidió ninguna ficha en concreto. Las fichas de la carpeta tienen el campo de producto vacío o con texto libre en 12 de 13 casos, de modo que tampoco servirían para confirmar una traza si existiera.

Después: 15 decididos sin proyecto → `/product-charter` para el que ya esté listo para serlo (candidatos con doliente, criterio de aceptación y evidencia: REQ-4602, 4605, 4606, 4610, 4611, 4612; REQ-2036 tiene los tres pero con evidencia de 2025-09-29). Las fichas con producto vacío (PRY-202, 203, 206, 209, 210, 211) son una conversación con sus gerentes de proyecto, no un comando.
