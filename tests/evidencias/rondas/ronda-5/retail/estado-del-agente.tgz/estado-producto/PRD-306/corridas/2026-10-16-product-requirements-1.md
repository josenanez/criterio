# Corrida del 2026-10-16 · product-requirements

PRD-306 · 16 requerimientos · 32 s · 39 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 15 |
| `evidence_stale` | 14 |
| `requirement_without_acceptance` | 5 |
| `requirement_accepted_without_evidence` | 2 |
| `requirement_undecided` | 1 |
| `requirement_without_owner` | 1 |
| `assumption_unverified` | 1 |

REQ-2028 y REQ-4608 aceptados sin evidencia; REQ-4600 propuesto hace 120 días; 14 con evidencia vieja de una sola entrevista; 15 aceptados sin proyecto

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

## Registro — App de clientes (PRD-306) · al 2026-10-16
16 requerimientos · 15 decididos · 86.7% con evidencia · 0% con proyecto que lo ejecuta

*Nota: no hay carpeta de fichas de proyecto en este espacio, así que el 0% es «ninguno trazado», no «ninguno existe». Los términos (v1.1) ya estaban vigentes, aceptados por José Francisco Ñáñez el 2026-10-16.*

### Se va a construir y nadie lo pidió
| REQ | Título | Estado | Doliente |
|---|---|---|---|
| REQ-2028 | Requerimiento REQ-2028 | aceptado el 2026-09-19 | Sandra Gil |
| REQ-4608 | Requerimiento REQ-4608 | aceptado el 2026-08-05 | María Restrepo |

Ninguno tiene una sola cita de quien lo pidió. REQ-4608 además no tiene criterio de aceptación.

### Decidido y nadie lo está construyendo
Los 15 aceptados no tienen proyecto asociado (`project: null`). Los más antiguos:
| REQ | Título | Decidido el |
|---|---|---|
| REQ-4605 | Requerimiento REQ-4605 | 2026-03-26 |
| REQ-4602 | Requerimiento REQ-4602 | 2026-04-20 |
| REQ-4611 | Requerimiento REQ-4611 | 2026-05-18 |
| REQ-4613 | Requerimiento REQ-4613 | 2026-06-02 |
| REQ-4603 | Requerimiento REQ-4603 | 2026-06-03 |
| REQ-4612 | Requerimiento REQ-4612 | 2026-06-15 |
| REQ-4610 | Requerimiento REQ-4610 | 2026-06-22 |

Siguen REQ-4606 (07-23), REQ-4604 (07-24), REQ-4608 (08-05), REQ-4601 (08-21), REQ-4607 (08-23), REQ-4609 (08-27), REQ-2028 (09-19) y REQ-2036 (10-04). `/product-trace` confirma si realmente no hay proyecto.

### Sin doliente, o con un área en vez de una persona
| REQ | Título | Dice |
|---|---|---|
| REQ-4607 | Requerimiento REQ-4607 | Doliente no encontrado en el acta del comité. Lo cerraría Felipe Arango (gerente de producto), nombrando a una persona. |

### Sin criterio de aceptación
| REQ | Título | Estado |
|---|---|---|
| REQ-4603 | Requerimiento REQ-4603 | aceptado |
| REQ-4604 | Requerimiento REQ-4604 | aceptado |
| REQ-4608 | Requerimiento REQ-4608 | aceptado |
| REQ-4609 | Requerimiento REQ-4609 | aceptado |
| REQ-4613 | Requerimiento REQ-4613 | aceptado |

Cada doliente (Camilo Beltrán, Mauricio Pérez ×2, María Restrepo, Natalia Ospina) los cerraría escribiendo el criterio.

### Decidido sin documento que lo respalde
Los 15 aceptados citan el acta `30-decisiones/2026-10-16-comite-producto.md`, pero **ninguno registra quién decidió** (`who: null`). El acta es del 2026-10-16 y las decisiones que recoge van de marzo a octubre, así que es un acta que consolida; no hay documento fechado en el momento de cada decisión. Lo cerraría el Comité de producto, anotando quién decidió cada una.

### Lleva meses y nadie lo decide
| REQ | Título | Propuesto hace | Quién tiene la facultad |
|---|---|---|---|
| REQ-4600 | Requerimiento REQ-4600 | 120 días (desde 2026-06-18; umbral 60) | Comité de producto (Felipe Arango, gerente) |

Doliente: Camilo Beltrán. Se propone decidirlo —aceptar o descartar con su documento—, no cerrarlo por viejo.

### Evidencia vieja
14 requerimientos (todos los que tienen evidencia) se sostienen en la misma cita: un cliente entrevistado, «Lo necesito y hoy no lo tengo.», del **2025-09-29**, hace más de 12 meses (umbral 12). Además es un tema general («Necesidad principal») que **no nombra qué requerimiento** sustenta. Afecta a REQ-2036, 4600 (propuesto), 4601, 4602, 4603, 4604, 4605, 4606, 4607, 4609, 4610, 4611, 4612 y 4613. Una sola entrevista vieja es lo que hoy respalda casi todo el registro.

### De la definición del producto (fuera del registro, pero salió en el cálculo)
- Supuesto sin verificar hace 196 días: «La demanda se sostiene sin descuento».
- Criterio de éxito del producto: no está dicho.
- Cifra declarada en el caso de negocio (volumen mensual 67 794, 2026-03-16): sin medición contra la que contrastarla.

## Por estado
| propuesto | aceptado | en construcción | entregado | descartado |
|---|---|---|---|---|
| 1 | 15 | 0 | 0 | 0 |

Cero descartados: ningún requerimiento ha sido rechazado con su documento, lo que sugiere un registro que solo crece.

**Siguiente paso:** `/product-trace` para los 15 decididos sin proyecto. Ninguno está listo para `/product-charter`: los que tienen criterio y evidencia dependen de una sola entrevista de hace más de un año.
