# Consejo de Administración · Pagos con QR

**Fecha:** 2026-10-16
**Asistentes:** Sandra Gil, Laura Vélez

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Gustavo Neira | Entregar el punto 6 | 2026-10-01 |
| Liliana Torres | Entregar el punto 2 | 2026-10-15 |
