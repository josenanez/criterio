# Consejo de Administración · Cobranza digital

**Fecha:** 2026-09-04
**Asistentes:** Beatriz Cuéllar, Mauricio Pérez, Paula Céspedes, Ricardo Salas, Sandra Gil

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Mauricio Pérez | Enviar el documento 1 | 2026-09-15 |
| Paula Céspedes | Cerrar la prueba 2 | 2026-09-09 |
| Sandra Gil | Revisar el anexo 3 | por definir |
| Beatriz Cuéllar | Validar el ambiente 4 | 2026-09-16 |
