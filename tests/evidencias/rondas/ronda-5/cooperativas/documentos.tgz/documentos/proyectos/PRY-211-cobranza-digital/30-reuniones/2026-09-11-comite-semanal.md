# Consejo de Administración · Cobranza digital

**Fecha:** 2026-09-11
**Asistentes:** Felipe Arango, Jorge Medina, Mauricio Pérez, Paula Céspedes, Ricardo Salas, Sandra Gil

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Mauricio Pérez | Enviar el documento 1 | 2026-09-24 |
| Paula Céspedes | Cerrar la prueba 2 | 2026-09-20 |
| Sandra Gil | Revisar el anexo 3 | por definir |
| Sandra Gil | Aprobar el diseño 5 | 2026-09-30 |
| Felipe Arango | Actualizar la matriz 6 | 2026-09-24 |
| Jorge Medina | Confirmar la fecha 7 | 2026-10-07 |
| Mauricio Pérez | Entregar el punto 8 | 2026-10-08 |

## Lo que se dijo

- Beatriz Cuéllar dice que ya entregó «validar el ambiente 4». No se presentó acta.
