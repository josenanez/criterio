# Acta de constitución · Aportes sociales en línea

**Código:** PRY-203
**Área dueña:** Cartera y cobranza
**Patrocinador:** Rubén Cárdenas
**Gerente de proyecto:** Laura Vélez
**Comité:** Comité de Riesgos
**Producto asociado:** aportes sociales
**Fecha de aprobación:** 2026-05-01

## Objetivo del negocio

Entregar aportes sociales en línea para Cartera y cobranza.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**800.000.000 COP**, aprobado por Comité de Riesgos el 2026-05-01.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-05-11 |
| Cierre | 2027-09-05 |

## Criterio de éxito

Aportes sociales en línea en producción y medido.

## Dependencias declaradas

- Ninguna declarada
