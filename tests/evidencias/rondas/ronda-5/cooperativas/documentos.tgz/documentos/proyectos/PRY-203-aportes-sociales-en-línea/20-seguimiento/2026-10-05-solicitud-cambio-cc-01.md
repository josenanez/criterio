# Solicitud de cambio CC-01

**Proyecto:** PRY-203 · Aportes sociales en línea
**Fecha:** 2026-10-05
**Solicitante:** Laura Vélez

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +78 días sobre la línea base vigente |
| Costo | 156.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
