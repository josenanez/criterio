# Acta de constitución · Corresponsales rurales

**Código:** PRY-210
**Área dueña:** Crédito
**Patrocinador:** Javier Hoyos
**Gerente de proyecto:** Felipe Arango
**Comité:** Comité de Tecnología
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-11-28

## Objetivo del negocio

Entregar corresponsales rurales para Crédito.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**3.300.000.000 COP**, aprobado por Comité de Tecnología el 2025-11-28.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-12-08 |
| Cierre | 2026-10-06 |

## Criterio de éxito

Corresponsales rurales en producción y medido.

## Dependencias declaradas

- Ninguna declarada
