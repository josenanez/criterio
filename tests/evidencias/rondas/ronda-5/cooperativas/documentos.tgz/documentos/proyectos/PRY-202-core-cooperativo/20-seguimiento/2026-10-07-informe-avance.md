# Informe de avance · Core cooperativo

**Código:** PRY-202
**Fecha de corte:** 2026-10-07
**Gerente:** Andrés Lozano

## Estado declarado

**Verde**

Avance reportado: **82%**

## Lo que pasó en el periodo

- Se ajustó el plan de pruebas con el área de seguridad

## Presupuesto

| | COP |
|---|---|
| Aprobado | 1.200.000.000 |
| Comprometido | 682.170.649 |
| Ejecutado | 684.558.632 |
| Proyección al cierre | 1.216.326.136 |

## Riesgos abiertos

- Aprobación del reglamento por el Consejo de Administración
