# Informe de avance · Cambio de mobiliario de agencias

**Código:** PRY-199
**Fecha de corte:** 2026-10-14
**Gerente:** Andrés Lozano

## Estado declarado

**Verde**

Avance reportado: **20%**

## Lo que pasó en el periodo

- Se ajustó el plan de pruebas con el área de seguridad
- El Consejo de Administración pidió ajustar el reglamento antes del piloto
- El equipo perdió dos semanas por rotación de un desarrollador clave

## Presupuesto

| | COP |
|---|---|
| Aprobado | 2.400.000.000 |
| Comprometido | 1.080.000.000 |
| Ejecutado | 720.000.000 |
| Proyección al cierre | 2.400.000.000 |

## Riesgos abiertos

- Dependencia del proveedor del core cooperativo
