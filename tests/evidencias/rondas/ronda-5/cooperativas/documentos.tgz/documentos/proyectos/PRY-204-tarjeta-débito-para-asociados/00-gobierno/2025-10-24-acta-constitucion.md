# Acta de constitución · Tarjeta débito para asociados

**Código:** PRY-204
**Área dueña:** Tesorería
**Patrocinador:** Ricardo Salas
**Gerente de proyecto:** Diana Molina
**Comité:** Comité de Riesgos
**Producto asociado:** tarjeta débito
**Fecha de aprobación:** 2025-10-24

## Objetivo del negocio

Entregar tarjeta débito para asociados para Tesorería.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**18.000.000.000 COP**, aprobado por Comité de Riesgos el 2025-10-24.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-11-03 |
| Cierre | 2026-10-18 |

## Criterio de éxito

Tarjeta débito para asociados en producción y medido.

## Dependencias declaradas

- Ninguna declarada
