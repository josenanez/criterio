# Solicitud de cambio CC-01

**Proyecto:** PRY-208 · Motor de crédito
**Fecha:** 2026-10-16
**Solicitante:** Diana Molina

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +38 días sobre la línea base vigente |
| Costo | 76.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
