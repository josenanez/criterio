# Comité de Educación · Core cooperativo

**Fecha:** 2026-10-09
**Asistentes:** Andrés Lozano, Ricardo Salas

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Elena Duarte | Entregar el punto 16 | 2026-10-29 |
