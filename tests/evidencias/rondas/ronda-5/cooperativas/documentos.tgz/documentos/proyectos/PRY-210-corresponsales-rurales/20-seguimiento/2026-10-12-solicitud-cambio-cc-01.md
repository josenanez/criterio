# Solicitud de cambio CC-01

**Proyecto:** PRY-210 · Corresponsales rurales
**Fecha:** 2026-10-12
**Solicitante:** Felipe Arango

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +65 días sobre la línea base vigente |
| Costo | 130.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
