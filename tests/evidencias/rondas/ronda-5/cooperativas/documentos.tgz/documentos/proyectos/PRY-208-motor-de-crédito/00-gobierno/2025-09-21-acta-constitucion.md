# Acta de constitución · Motor de crédito

**Código:** PRY-208
**Área dueña:** Ahorro y aportes
**Patrocinador:** María Restrepo
**Gerente de proyecto:** Diana Molina
**Comité:** Comité de Riesgos
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-09-21

## Objetivo del negocio

Entregar motor de crédito para Ahorro y aportes.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**3.300.000.000 COP**, aprobado por Comité de Riesgos el 2025-09-21.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-10-01 |
| Cierre | 2027-03-30 |

## Criterio de éxito

Motor de crédito en producción y medido.

## Dependencias declaradas

- Ninguna declarada
