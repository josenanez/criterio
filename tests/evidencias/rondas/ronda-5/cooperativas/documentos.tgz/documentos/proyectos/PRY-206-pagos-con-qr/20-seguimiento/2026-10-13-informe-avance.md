# Informe de avance · Pagos con QR

**Código:** PRY-206
**Fecha de corte:** 2026-10-13
**Gerente:** Sandra Gil

## Estado declarado

**Verde**

Avance reportado: **53%**

## Lo que pasó en el periodo

- Se acordó con arquitectura cómo se revisan los requisitos no funcionales
- La prueba de carga no alcanzó el umbral pactado y se repite
- El Consejo de Administración pidió ajustar el reglamento antes del piloto

## Presupuesto

| | COP |
|---|---|
| Aprobado | 18.000.000.000 |
| Comprometido | 5.462.768.122 |
| Ejecutado | 11.358.454.708 |
| Proyección al cierre | 20.909.731.906 |

## Riesgos abiertos

- Dependencia del proveedor del core cooperativo
- Concentración del conocimiento en una sola persona
