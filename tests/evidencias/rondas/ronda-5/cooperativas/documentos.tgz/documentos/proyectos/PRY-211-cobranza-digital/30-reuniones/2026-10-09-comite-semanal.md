# Consejo de Administración · Cobranza digital

**Fecha:** 2026-10-09
**Asistentes:** Carlos Peña, Diana Molina, Elena Duarte, Gustavo Neira, Jorge Medina, Laura Vélez, Mauricio Pérez, Natalia Ospina, Paula Céspedes, Ricardo Salas, Sandra Gil, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Mauricio Pérez | Enviar el documento 1 | 2026-11-13 |
| Paula Céspedes | Cerrar la prueba 2 | 2026-11-03 |
| Sandra Gil | Revisar el anexo 3 | 2026-10-30 |
| Mauricio Pérez | Entregar el punto 8 | 2026-10-25 |
| Natalia Ospina | Enviar el documento 9 | 2026-10-25 |
| Óscar Ramírez | Validar el ambiente 12 | 2026-09-22 |
| Jorge Medina | Confirmar la fecha 15 | 2026-10-18 |
| Paula Céspedes | Entregar el punto 16 | 2026-10-20 |
| Elena Duarte | Enviar el documento 17 | 2026-10-20 |
| Gustavo Neira | Cerrar la prueba 18 | 2026-10-18 |
| Carlos Peña | Aprobar el diseño 21 | 2026-11-05 |
| Laura Vélez | Actualizar la matriz 22 | 2026-10-16 |
| Diana Molina | Confirmar la fecha 23 | 2026-10-16 |
| Sandra Gil | Entregar el punto 24 | 2026-10-20 |

## Cerrados en esta reunión

- Revisar el anexo 19 (Javier Hoyos): recibido, acta de recibo del 2026-10-09.

## Lo que se dijo

- Jorge Medina dice que ya entregó «aprobar el diseño 13». No se presentó acta.
- Carlos Peña dice que ya entregó «validar el ambiente 20». No se presentó acta.
