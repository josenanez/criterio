# Informe de avance · Apertura de ahorro en línea

**Código:** PRY-201
**Fecha de corte:** 2026-10-11
**Gerente:** Rubén Cárdenas

## Estado declarado

**Rojo**

Avance reportado: **78%**

## Lo que pasó en el periodo

- Se levantó un hallazgo de seguridad en la revisión de arquitectura

## Presupuesto

| | COP |
|---|---|
| Aprobado | 3.300.000.000 |
| Comprometido | 1.994.133.809 |
| Ejecutado | 629.512.425 |
| Proyección al cierre | 3.199.017.869 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
