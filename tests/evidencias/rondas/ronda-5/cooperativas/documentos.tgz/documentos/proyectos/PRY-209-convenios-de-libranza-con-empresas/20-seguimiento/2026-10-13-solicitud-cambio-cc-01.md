# Solicitud de cambio CC-01

**Proyecto:** PRY-209 · Convenios de libranza con empresas
**Fecha:** 2026-10-13
**Solicitante:** Liliana Torres

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +68 días sobre la línea base vigente |
| Costo | 136.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
