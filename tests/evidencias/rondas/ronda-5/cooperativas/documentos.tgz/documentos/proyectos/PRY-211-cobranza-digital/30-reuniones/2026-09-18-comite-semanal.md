# Consejo de Administración · Cobranza digital

**Fecha:** 2026-09-18
**Asistentes:** Felipe Arango, María Restrepo, Mauricio Pérez, Natalia Ospina, Paula Céspedes, Ricardo Salas, Sandra Gil, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Mauricio Pérez | Enviar el documento 1 | 2026-10-03 |
| Paula Céspedes | Cerrar la prueba 2 | 2026-09-29 |
| Sandra Gil | Revisar el anexo 3 | por definir |
| Sandra Gil | Aprobar el diseño 5 | 2026-09-30 |
| Felipe Arango | Actualizar la matriz 6 | 2026-09-24 |
| Mauricio Pérez | Entregar el punto 8 | 2026-10-08 |
| Natalia Ospina | Enviar el documento 9 | 2026-10-15 |
| María Restrepo | Cerrar la prueba 10 | 2026-09-24 |
| Felipe Arango | Revisar el anexo 11 | 2026-10-13 |
| Óscar Ramírez | Validar el ambiente 12 | 2026-09-22 |

## Lo que se dijo

- Jorge Medina dice que ya entregó «confirmar la fecha 7». No se presentó acta.
