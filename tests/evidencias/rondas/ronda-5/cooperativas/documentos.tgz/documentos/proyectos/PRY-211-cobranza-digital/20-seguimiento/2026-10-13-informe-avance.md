# Informe de avance · Cobranza digital

**Código:** PRY-211
**Fecha de corte:** 2026-10-13
**Gerente:** Ricardo Salas

## Estado declarado

**Rojo**

Avance reportado: **56%**

## Lo que pasó en el periodo

- Se levantó un hallazgo de seguridad en la revisión de arquitectura
- El equipo perdió dos semanas por rotación de un desarrollador clave
- Se recibió el concepto pendiente del ente supervisor

## Presupuesto

| | COP |
|---|---|
| Aprobado | 1.200.000.000 |
| Comprometido | 1.061.366.978 |
| Ejecutado | 433.137.984 |
| Proyección al cierre | 1.108.924.777 |

## Riesgos abiertos

- Dependencia del proveedor del core cooperativo
- Cambio normativo del supervisor que puede mover el alcance
