# Definición de producto · Recaudos

**Código:** PRD-306
**Gerente de producto:** Óscar Ramírez
**Segmento:** Pensionados
**Fecha de la definición:** 2025-12-04

## El problema

El segmento Pensionados no tiene recaudos.

## La propuesta

- Propuesta principal

## Supuestos

- **El reglamento vigente lo permite** · declarado el 2026-06-01 · verificado

## Proyectos que lo construyen

- Ninguno declarado
