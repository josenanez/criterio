# Caso de negocio · Ahorro a la vista

**Código:** PRD-301
**Fecha:** 2026-03-05
**Preparado por:** Elena Duarte

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 53.440 | Caso de negocio, 2026-03-05 |

## Retorno esperado

Retorno esperado en 24 meses.
