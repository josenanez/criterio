# Definición de producto · Auxilios de solidaridad

**Código:** PRD-307
**Gerente de producto:** Andrés Lozano
**Segmento:** Jóvenes
**Fecha de la definición:** 2026-04-16

## El problema

El segmento Jóvenes no tiene auxilios de solidaridad.

## La propuesta

- Propuesta principal

## Supuestos

- **Los asociados usan el canal digital** · declarado el 2026-07-20 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
