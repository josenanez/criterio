# Tablero de métricas · Ahorro a la vista

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-06

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 51.585 | 2026-10-06 |
