# Definición de producto · Remesas familiares

**Código:** PRD-308
**Gerente de producto:** María Restrepo
**Segmento:** Asociados urbanos
**Fecha de la definición:** 2026-04-23

## El problema

El segmento Asociados urbanos no tiene remesas familiares.

## La propuesta

- Propuesta principal

## Supuestos

- **La demanda se sostiene sin campaña** · declarado el 2026-04-17 · verificado

## Proyectos que lo construyen

- Ninguno declarado
