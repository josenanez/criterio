# Caso de negocio · Tarjeta débito

**Código:** PRD-303
**Fecha:** 2025-11-22
**Preparado por:** Andrés Lozano

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 238.065 | Caso de negocio, 2025-11-22 |

## Retorno esperado

Retorno esperado en 24 meses.
