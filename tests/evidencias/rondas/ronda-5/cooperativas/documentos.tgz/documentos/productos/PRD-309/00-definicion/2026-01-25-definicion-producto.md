# Definición de producto · Microseguros

**Código:** PRD-309
**Gerente de producto:** Beatriz Cuéllar
**Segmento:** Pensionados
**Fecha de la definición:** 2026-01-25

## El problema

El segmento Pensionados no tiene microseguros.

## La propuesta

- Propuesta principal

## Supuestos

- **El proveedor cumple el tiempo pactado** · declarado el 2026-03-30 · verificado

## Proyectos que lo construyen

- Ninguno declarado
