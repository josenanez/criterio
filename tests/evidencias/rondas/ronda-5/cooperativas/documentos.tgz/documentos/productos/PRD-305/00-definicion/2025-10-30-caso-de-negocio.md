# Caso de negocio · Microcrédito

**Código:** PRD-305
**Fecha:** 2025-10-30
**Preparado por:** Ricardo Salas

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 269.856 | Caso de negocio, 2025-10-30 |

## Retorno esperado

Retorno esperado en 24 meses.
