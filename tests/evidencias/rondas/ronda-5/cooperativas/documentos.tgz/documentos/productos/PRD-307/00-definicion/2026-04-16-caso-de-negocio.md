# Caso de negocio · Auxilios de solidaridad

**Código:** PRD-307
**Fecha:** 2026-04-16
**Preparado por:** Andrés Lozano

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 94.165 | Caso de negocio, 2026-04-16 |

## Retorno esperado

Retorno esperado en 24 meses.
