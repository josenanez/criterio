# Comité de producto · Aportes sociales

**Fecha:** 2026-10-16
**Asistentes:** Rubén Cárdenas

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4200 | Requerimiento REQ-4200 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-11 | — |
| REQ-4201 | Requerimiento REQ-4201 | Laura Vélez | se verifica en producción | — | aceptado | 2026-08-21 | — |
| REQ-4202 | Requerimiento REQ-4202 | sin asignar | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-14 | — |
| REQ-4203 | Requerimiento REQ-4203 | María Restrepo | — | Cliente entrevistado | aceptado | 2026-07-19 | — |
| REQ-4204 | Requerimiento REQ-4204 | Paula Céspedes | se verifica en producción | — | propuesto | 2026-06-20 | — |
| REQ-4205 | Requerimiento REQ-4205 | Gustavo Neira | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-23 | — |
| REQ-4206 | Requerimiento REQ-4206 | Óscar Ramírez | se verifica en producción | Cliente entrevistado | propuesto | 2026-08-06 | — |
| REQ-4207 | Requerimiento REQ-4207 | María Restrepo | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-25 | — |
| REQ-4208 | Requerimiento REQ-4208 | Jorge Medina | — | Cliente entrevistado | aceptado | 2026-07-15 | — |
| REQ-4209 | Requerimiento REQ-4209 | Andrés Lozano | se verifica en producción | — | propuesto | 2026-04-24 | — |
| REQ-4210 | Requerimiento REQ-4210 | Mauricio Pérez | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-24 | — |
| REQ-4211 | Requerimiento REQ-4211 | Rubén Cárdenas | — | Cliente entrevistado | aceptado | 2026-05-30 | — |
| REQ-4212 | Requerimiento REQ-4212 | Paula Céspedes | se verifica en producción | Cliente entrevistado | propuesto | 2026-05-06 | — |
| REQ-4213 | Requerimiento REQ-4213 | Natalia Ospina | se verifica en producción | Cliente entrevistado | propuesto | 2026-04-10 | — |
| REQ-2035 | Requerimiento REQ-2035 | Andrés Lozano | se verifica en producción | Cliente entrevistado | aceptado | 2026-10-06 | — |

## Decisiones

- Se mantiene el plan
