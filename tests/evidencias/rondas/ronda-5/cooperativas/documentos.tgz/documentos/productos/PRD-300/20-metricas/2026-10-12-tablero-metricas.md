# Tablero de métricas · Crédito de libranza

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-12

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 139.983 | 2026-10-12 |
