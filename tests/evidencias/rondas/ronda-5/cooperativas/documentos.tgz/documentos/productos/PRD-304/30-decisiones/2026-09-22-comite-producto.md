# Comité de producto · Pagos QR

**Fecha:** 2026-09-22
**Asistentes:** Ricardo Salas

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4400 | Requerimiento REQ-4400 | sin asignar | se verifica en producción | — | aceptado | 2026-03-19 | — |
| REQ-4401 | Requerimiento REQ-4401 | Sandra Gil | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-27 | — |
| REQ-4402 | Requerimiento REQ-4402 | sin asignar | se verifica en producción | Cliente entrevistado | propuesto | 2026-04-30 | — |
| REQ-4403 | Requerimiento REQ-4403 | Carlos Peña | se verifica en producción | — | propuesto | 2026-06-19 | — |
| REQ-4404 | Requerimiento REQ-4404 | Beatriz Cuéllar | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-17 | — |
| REQ-4405 | Requerimiento REQ-4405 | Andrés Lozano | se verifica en producción | — | aceptado | 2026-07-20 | — |
| REQ-4406 | Requerimiento REQ-4406 | Javier Hoyos | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-12 | — |
| REQ-4407 | Requerimiento REQ-4407 | Diana Molina | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-14 | — |
| REQ-4408 | Requerimiento REQ-4408 | Natalia Ospina | — | Cliente entrevistado | aceptado | 2026-04-06 | — |
| REQ-4409 | Requerimiento REQ-4409 | sin asignar | — | Cliente entrevistado | aceptado | 2026-07-02 | — |
| REQ-4410 | Requerimiento REQ-4410 | Andrés Lozano | se verifica en producción | Cliente entrevistado | propuesto | 2026-06-14 | — |
| REQ-4411 | Requerimiento REQ-4411 | Óscar Ramírez | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-20 | — |
| REQ-4412 | Requerimiento REQ-4412 | Jorge Medina | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-24 | — |
| REQ-4413 | Requerimiento REQ-4413 | Ricardo Salas | — | Cliente entrevistado | propuesto | 2026-04-18 | — |
| REQ-4414 | Requerimiento REQ-4414 | Elena Duarte | se verifica en producción | Cliente entrevistado | propuesto | 2026-08-14 | — |
| REQ-4415 | Requerimiento REQ-4415 | Diana Molina | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-20 | — |

## Decisiones

- Se mantiene el plan
