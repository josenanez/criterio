# Caso de negocio · Remesas familiares

**Código:** PRD-308
**Fecha:** 2026-04-23
**Preparado por:** María Restrepo

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 106.970 | Caso de negocio, 2026-04-23 |

## Retorno esperado

Retorno esperado en 24 meses.
