# Definición de producto · Crédito de libranza

**Código:** PRD-300
**Gerente de producto:** Óscar Ramírez
**Segmento:** Asociados urbanos
**Fecha de la definición:** 2026-06-10

## El problema

El segmento Asociados urbanos no tiene crédito de libranza.

## La propuesta

- Propuesta principal

## Supuestos

- **Los asociados usan el canal digital** · declarado el 2026-07-20 · verificado

## Proyectos que lo construyen

- Ninguno declarado
