# Definición de producto · Ahorro a la vista

**Código:** PRD-301
**Gerente de producto:** Elena Duarte
**Segmento:** Pensionados
**Fecha de la definición:** 2026-03-05

## El problema

El segmento Pensionados no tiene ahorro a la vista.

## La propuesta

- Propuesta principal

## Supuestos

- **La demanda se sostiene sin campaña** · declarado el 2026-05-12 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
