# Tablero de métricas · Recaudos

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-05

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 213.736 | 2026-10-05 |
