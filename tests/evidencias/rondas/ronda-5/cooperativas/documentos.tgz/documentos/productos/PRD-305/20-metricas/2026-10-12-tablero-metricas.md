# Tablero de métricas · Microcrédito

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-12

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 213.496 | 2026-10-12 |
