# Caso de negocio · Microseguros

**Código:** PRD-309
**Fecha:** 2026-01-25
**Preparado por:** Beatriz Cuéllar

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 276.481 | Caso de negocio, 2026-01-25 |

## Retorno esperado

Retorno esperado en 24 meses.
