# Caso de negocio · Crédito de libranza

**Código:** PRD-300
**Fecha:** 2026-06-10
**Preparado por:** Óscar Ramírez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 138.026 | Caso de negocio, 2026-06-10 |

## Retorno esperado

Retorno esperado en 24 meses.
