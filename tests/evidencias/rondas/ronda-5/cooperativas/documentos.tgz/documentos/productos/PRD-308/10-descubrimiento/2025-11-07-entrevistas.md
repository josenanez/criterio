# Entrevistas · Remesas familiares

**Ronda:** Ronda · 2025-11-07
**Realizadas por:** María Restrepo

### Cliente entrevistado · 2025-11-07

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
