# Definición de producto · Microcrédito

**Código:** PRD-305
**Gerente de producto:** Ricardo Salas
**Segmento:** Asociados rurales
**Fecha de la definición:** 2025-10-30

## El problema

El segmento Asociados rurales no tiene microcrédito.

## La propuesta

- Propuesta principal

## Supuestos

- **La demanda se sostiene sin campaña** · declarado el 2026-05-10 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
