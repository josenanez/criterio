# Tablero de métricas · Remesas familiares

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-07

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 66.587 | 2026-10-07 |
