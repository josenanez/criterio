# Comité de producto · Microseguros

**Fecha:** 2026-10-12
**Asistentes:** Beatriz Cuéllar

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4900 | Requerimiento REQ-4900 | Camilo Beltrán | se verifica en producción | — | aceptado | 2026-08-19 | — |
| REQ-4901 | Requerimiento REQ-4901 | Laura Vélez | se verifica en producción | Cliente entrevistado | propuesto | 2026-05-28 | — |
| REQ-4902 | Requerimiento REQ-4902 | Rubén Cárdenas | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-25 | — |
| REQ-4903 | Requerimiento REQ-4903 | Sandra Gil | se verifica en producción | — | aceptado | 2026-04-08 | — |
| REQ-4904 | Requerimiento REQ-4904 | Camilo Beltrán | — | Cliente entrevistado | propuesto | 2026-08-08 | — |
| REQ-4905 | Requerimiento REQ-4905 | Felipe Arango | — | — | aceptado | 2026-05-16 | — |
| REQ-4906 | Requerimiento REQ-4906 | Rubén Cárdenas | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-17 | — |
| REQ-4907 | Requerimiento REQ-4907 | Liliana Torres | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-27 | — |
| REQ-4908 | Requerimiento REQ-4908 | Sandra Gil | se verifica en producción | — | aceptado | 2026-04-12 | — |
| REQ-4909 | Requerimiento REQ-4909 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-16 | — |
| REQ-4910 | Requerimiento REQ-4910 | Óscar Ramírez | se verifica en producción | — | propuesto | 2026-04-27 | — |
| REQ-4911 | Requerimiento REQ-4911 | Andrés Lozano | se verifica en producción | — | aceptado | 2026-05-01 | — |
| REQ-4912 | Requerimiento REQ-4912 | sin asignar | se verifica en producción | Cliente entrevistado | propuesto | 2026-06-28 | — |
| REQ-4913 | Requerimiento REQ-4913 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-05 | — |
| REQ-2028 | Requerimiento REQ-2028 | Óscar Ramírez | se verifica en producción | Cliente entrevistado | aceptado | 2026-09-25 | — |
| REQ-2036 | Requerimiento REQ-2036 | Liliana Torres | se verifica en producción | Cliente entrevistado | aceptado | 2026-10-15 | — |

## Decisiones

- Se mantiene el plan
