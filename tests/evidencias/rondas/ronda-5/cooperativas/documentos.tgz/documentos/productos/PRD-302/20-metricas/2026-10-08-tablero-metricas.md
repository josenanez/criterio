# Tablero de métricas · Aportes sociales

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-08

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 82.280 | 2026-10-08 |
