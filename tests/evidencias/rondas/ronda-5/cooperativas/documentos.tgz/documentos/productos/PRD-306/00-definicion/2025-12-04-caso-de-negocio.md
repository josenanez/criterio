# Caso de negocio · Recaudos

**Código:** PRD-306
**Fecha:** 2025-12-04
**Preparado por:** Óscar Ramírez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 238.261 | Caso de negocio, 2025-12-04 |

## Retorno esperado

Retorno esperado en 24 meses.
