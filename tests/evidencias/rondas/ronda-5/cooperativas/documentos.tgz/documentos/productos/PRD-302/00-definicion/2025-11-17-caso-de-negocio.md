# Caso de negocio · Aportes sociales

**Código:** PRD-302
**Fecha:** 2025-11-17
**Preparado por:** Rubén Cárdenas

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 128.502 | Caso de negocio, 2025-11-17 |

## Retorno esperado

Retorno esperado en 24 meses.
