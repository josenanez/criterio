# Corrida del 2026-10-16 · product-trace

PRD-309 · 16 requerimientos · 55 s · 36 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 12 |
| `evidence_stale` | 10 |
| `requirement_accepted_without_evidence` | 5 |
| `requirement_undecided` | 4 |
| `requirement_without_owner` | 3 |
| `requirement_without_acceptance` | 1 |
| `claim_vs_metric` | 1 |

12 requerimientos decididos y ninguno tiene proyecto; ninguna de las 13 fichas declara ejecutar Microseguros

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

## Trazabilidad — Microseguros (PRD-309) · al 2026-10-16
12 decididos · 0 con proyecto · 0 confirmados contra la ficha · 0 entregados

Fuente de las decisiones: `documentos/productos/PRD-309/30-decisiones/2026-10-12-comite-producto.md` (cada REQ trae «—» en «Proyecto que lo ejecuta»). Fichas leídas: las 13 de `estado/records` (PRY-199 a PRY-211).

### Decidido y nadie lo está construyendo
Los 12 requerimientos aceptados están en esta tabla: ninguno nombra proyecto, y ninguna de las 13 fichas declara ejecutar Microseguros. «Por quién» queda vacío en todos: el acta no dice quién decidió (`decision.who` = no encontrado).

| REQ | Título | Decidido el | Por quién |
|---|---|---|---|
| REQ-4902 | Requerimiento REQ-4902 | 2026-03-25 | no consta en el acta |
| REQ-4906 | Requerimiento REQ-4906 | 2026-03-17 | no consta en el acta |
| REQ-4903 | Requerimiento REQ-4903 | 2026-04-08 | no consta en el acta |
| REQ-4908 | Requerimiento REQ-4908 | 2026-04-12 | no consta en el acta |
| REQ-4909 | Requerimiento REQ-4909 | 2026-04-16 | no consta en el acta |
| REQ-4911 | Requerimiento REQ-4911 | 2026-05-01 | no consta en el acta |
| REQ-4905 | Requerimiento REQ-4905 | 2026-05-16 | no consta en el acta |
| REQ-4913 | Requerimiento REQ-4913 | 2026-07-05 | no consta en el acta |
| REQ-4900 | Requerimiento REQ-4900 | 2026-08-19 | no consta en el acta |
| REQ-4907 | Requerimiento REQ-4907 | 2026-08-27 | no consta en el acta |
| REQ-2028 | Requerimiento REQ-2028 | 2026-09-25 | no consta en el acta |
| REQ-2036 | Requerimiento REQ-2036 | 2026-10-15 | no consta en el acta |

Los títulos son genéricos porque el acta solo lleva el código, no el problema; la cadena se rompe ya en el primer eslabón después de la decisión: no hay proyecto. Los más viejos sin proyecto: REQ-4906 (213 días) y REQ-4902 (205 días).

Dato a revisar: REQ-2036 figura decidido el 2026-10-15, tres días después de la fecha del acta que lo cita (2026-10-12). La fecha de decisión y el documento no cuadran; conviene revisar el acta antes de usarla.

### La traza no se confirma
Ninguna: no hay trazas declaradas que confirmar (`traced` = 0 de 12). No hay desacuerdo entre registro y ficha, porque el registro no afirma ningún proyecto.

### Lo que un proyecto construye y el registro no tiene
Ninguno detectado. Ninguna ficha declara ejecutar PRD-309 ni Microseguros. Las que declaran producto dicen otro: PRY-199 → PRD-299; PRY-200 → crédito de libranza; PRY-201 → ahorro a la vista; PRY-203 → aportes sociales; PRY-204 → tarjeta débito; PRY-206 → pagos QR; PRY-207 → microcrédito; PRY-211 → recaudos. PRY-202, PRY-205, PRY-208, PRY-209 y PRY-210 tienen el campo producto vacío: es un hallazgo de esas fichas, y no se puede descartar desde aquí que alguna construya algo de Microseguros.

### La cadena completa
| REQ | Estado | Decisión | Proyecto | Confirmado | Entregables |
|---|---|---|---|---|---|
| REQ-2028 | aceptado | 2026-09-25 | — | no | — |
| REQ-2036 | aceptado | 2026-10-15 | — | no | — |
| REQ-4900 | aceptado | 2026-08-19 | — | no | — |
| REQ-4902 | aceptado | 2026-03-25 | — | no | — |
| REQ-4903 | aceptado | 2026-04-08 | — | no | — |
| REQ-4905 | aceptado | 2026-05-16 | — | no | — |
| REQ-4906 | aceptado | 2026-03-17 | — | no | — |
| REQ-4907 | aceptado | 2026-08-27 | — | no | — |
| REQ-4908 | aceptado | 2026-04-12 | — | no | — |
| REQ-4909 | aceptado | 2026-04-16 | — | no | — |
| REQ-4911 | aceptado | 2026-05-01 | — | no | — |
| REQ-4913 | aceptado | 2026-07-05 | — | no | — |
| REQ-4901, 4904, 4910, 4912 | propuesto | sin decidir | — | no aplica (aún no decididos) | — |

### Sin fichas a la vista
Las fichas de los 13 proyectos estaban disponibles. Ninguna cubre Microseguros, así que no hay traza que confirmar ni desmentir.
