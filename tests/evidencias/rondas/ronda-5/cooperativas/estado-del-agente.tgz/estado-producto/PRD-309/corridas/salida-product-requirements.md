## Registro — Microseguros (PRD-309) · al 2026-10-16
16 requerimientos · 12 decididos · 58.3% con evidencia · 0% con proyecto que lo ejecuta

Nota de lectura: el 58.3% es generoso. Los 7 decididos «con evidencia» descansan en una sola entrevista (2025-08-16, «Cliente entrevistado») que, según el registro, no nombra ninguno de esos requerimientos. Además, la carpeta de fichas de proyecto (`estado/`) está vacía, así que ninguna traza pudo confirmarse; las actas dicen «—» en «Proyecto que lo ejecuta».

### Se va a construir y nadie lo pidió
| REQ | Título | Estado | Doliente |
|---|---|---|---|
| REQ-4900 | Requerimiento REQ-4900 | aceptado (2026-08-19) | Camilo Beltrán |
| REQ-4903 | Requerimiento REQ-4903 | aceptado (2026-04-08) | Sandra Gil |
| REQ-4905 | Requerimiento REQ-4905 | aceptado (2026-05-16) | Felipe Arango |
| REQ-4908 | Requerimiento REQ-4908 | aceptado (2026-04-12) | Sandra Gil |
| REQ-4911 | Requerimiento REQ-4911 | aceptado (2026-05-01) | Andrés Lozano |

Ninguno tiene una sola cita de quien lo pidió; el acta dice «—». Quien cierra el vacío es el doliente de cada uno, buscando a quien lo pidió o llevándolo de nuevo al Comité de producto.

### Decidido y nadie lo está construyendo
Los 12 aceptados, sin proyecto que los ejecute: REQ-2028, REQ-2036, REQ-4900, REQ-4902, REQ-4903, REQ-4905, REQ-4906, REQ-4907, REQ-4908, REQ-4909, REQ-4911, REQ-4913.

Los más antiguos: REQ-4902 (decidido 2026-03-25), REQ-4906 (2026-03-17), REQ-4903 (2026-04-08), REQ-4908 (2026-04-12), REQ-4909 (2026-04-16). Quien cierra el vacío es la gerente de producto, Beatriz Cuéllar: confirmar si hay proyecto y publicar su ficha, o llevar el requerimiento al acta de constitución.

### Sin doliente, o con un área en vez de una persona
| REQ | Título | Estado | Dice |
|---|---|---|---|
| REQ-4909 | Requerimiento REQ-4909 | aceptado | sin doliente |
| REQ-4912 | Requerimiento REQ-4912 | propuesto | sin doliente |
| REQ-4913 | Requerimiento REQ-4913 | aceptado | sin doliente |

Quien lo cierra: Beatriz Cuéllar, asignando una persona. No hay ningún caso de un área puesta en lugar de una persona.

### Sin criterio de aceptación
| REQ | Título | Estado |
|---|---|---|
| REQ-4905 | Requerimiento REQ-4905 | aceptado |

(REQ-4904 tampoco lo tiene, pero está propuesto y no se le exige.) Los demás tienen un criterio, pero casi todos dicen solo «se verifica en producción», lo que no se puede medir. Eso es una observación de lectura, no un conteo del cálculo.

### Decidido sin documento que lo respalde
Las 12 decisiones constan en el acta del comité del 2026-10-12, pero en las que revisé uno a uno (REQ-4900, REQ-2028, REQ-4905, REQ-4909) el acta no dice quién decidió. Además, las fechas de decisión van de 2026-03-17 a 2026-10-15, y el acta es posterior a casi todas. No revisé ese campo en los otros 8; el cálculo no lo señala.

### Lleva meses y nadie lo decide
Umbral configurado: 60 días.

| REQ | Título | Propuesto hace | Quién tiene la facultad |
|---|---|---|---|
| REQ-4910 | Requerimiento REQ-4910 | 172 días (desde 2026-04-27) | Comité de producto |
| REQ-4901 | Requerimiento REQ-4901 | 141 días (desde 2026-05-28) | Comité de producto |
| REQ-4912 | Requerimiento REQ-4912 | 110 días (desde 2026-06-28) | Comité de producto |
| REQ-4904 | Requerimiento REQ-4904 | 69 días (desde 2026-08-08) | Comité de producto |

La facultad es del Comité de producto, según la configuración. Se propone decidirlos en el próximo comité (aceptar, descartar o pedir evidencia). No se cierran por viejos.

### Evidencia vieja
Umbral configurado: 12 meses.

| REQ | Lo más nuevo que lo sostiene | Hace |
|---|---|---|
| REQ-2028, REQ-2036, REQ-4901, REQ-4902, REQ-4904, REQ-4906, REQ-4907, REQ-4909, REQ-4912, REQ-4913 | Entrevista 2025-08-16, «Cliente entrevistado»: «Lo necesito y hoy no lo tengo.» | 14 meses |

Es la misma y única entrevista del producto para los diez.

### Aparte: la definición
Casi 30 puntos de diferencia entre el caso de negocio y el tablero: el volumen mensual declarado es 276,481 (caso de negocio, 2026-01-25) y el medido es 194,582 (tablero de métricas, 2026-10-14). Eso es 29.6%, con el dato declarado por encima y el umbral en 20%. El criterio de éxito de la definición no está dicho en ningún documento.

## Por estado
| propuesto | aceptado | en construcción | entregado | descartado |
|---|---|---|---|---|
| 4 | 12 | 0 | 0 | 0 |

Después: hay 12 requerimientos decididos que nadie está construyendo, así que corresponde `/product-trace`. Hay aceptados con evidencia y con criterio (p. ej. REQ-2036, REQ-4902), pero su evidencia es la entrevista genérica, así que antes de `/product-charter` conviene sustentarlos.
