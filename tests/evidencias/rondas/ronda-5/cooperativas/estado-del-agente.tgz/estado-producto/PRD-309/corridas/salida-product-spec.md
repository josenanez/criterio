> **Borrador del agente, sin firma.** Lo cierra Beatriz Cuéllar (gerente de producto) con el Comité de producto como autoridad. Este agente no aprueba ni decide alcance.

# Especificación — Microseguros (PRD-309) · borrador del 2026-10-16

## Lo primero: esta especificación casi no se puede escribir

El registro tiene 16 requerimientos (12 `aceptado`, 4 `propuesto`). **En ninguno de los 16 está escrito qué problema resuelve**: el acta del 2026-10-12 trae solo el código (`Requerimiento REQ-49xx`) y el registro lo declara `not_found` (`need` y título genérico). Sin problema no hay comportamiento que especificar, y inventarlo sería decidir por el comité. Por eso la sección «Comportamiento» queda vacía a propósito y casi todo el documento son vacíos con dueño.

## Qué problema resuelve
«El segmento Pensionados no tiene microseguros.» (definición, 2026-01-25). Es todo lo que la definición dice: la «propuesta» es el texto de relleno «Propuesta principal», no hay criterio de éxito y el caso de negocio dice «Retorno esperado en 24 meses» sin cifra. País: no está dicho en ninguna parte.

## Alcance
### Entra
Nada que se pueda describir hoy. Candidatos que salen del registro (aceptados el 2026-10-12, sin problema escrito): REQ-4900, 4902, 4903, 4905, 4906, 4907, 4908, 4909, 4911, 4913, 2028, 2036.

### No entra
- Los 4 requerimientos en `propuesto` (REQ-4901, 4904, 4910, 4912): nadie decidió que se hagan.
- Cualquier solución, arquitectura, estimación, costo o fecha: este comando no las propone.
- Lo que la definición no menciona (coberturas, precio, canal de venta, proveedor, país): no está dicho en ninguna parte, no se infiere.

## Comportamiento
Sin contenido. Ninguna sección puede citar un requerimiento porque ninguno dice qué necesita quien lo pidió.

## Criterios de aceptación
| Criterio | Requerimiento | Cómo se verifica | ¿Se puede medir hoy? |
|---|---|---|---|
| «se verifica en producción» (texto idéntico) | REQ-4900, 4902, 4903, 4906, 4907, 4908, 4909, 4911, 4913, 2028, 2036 | No pasa la prueba: dos personas no llegan a la misma respuesta, no hay umbral ni medida | No es un criterio todavía |
| — (ninguno) | REQ-4905 | — | — |

Hallazgo: los 12 aceptados carecen de un criterio verificable. Lo único medido en el producto es `volumen_mensual` (194.582 al 2026-10-14, tablero de la bodega de datos); ningún criterio lo usa. Percentiles, tiempos, tasas: nadie los mide hoy según los documentos.

## Supuestos sobre los que está escrita
| Supuesto | Verificado | Quién lo verificaría |
|---|---|---|
| «El proveedor cumple el tiempo pactado» (definición; fechado 2026-03-30, posterior a la definición del 2026-01-25) | Dice «verificado» sin citar con qué; no se puede aceptar como verificado. No hay proveedor ni tiempo pactado en ningún documento | Beatriz Cuéllar |
| Sin supuestos declarados en ninguno de los 16 requerimientos | — | Beatriz Cuéllar decide si hay supuestos que declarar; este agente no los inventa |

Dato relacionado (no es supuesto declarado): `volumen_mensual` declarado en el caso de negocio 276.481 (2026-01-25) frente a 194.582 medido (2026-10-14): 29,6 % por debajo, sobre el umbral de 20 %. Cualquier criterio de volumen que se escriba debe elegir cuál de las dos cifras usa; eso decide la gerente de producto.

## Vacíos
| Qué falta decidir | Consecuencia de no decidirlo | Quién lo cierra |
|---|---|---|
| Qué problema resuelve cada uno de los 16 requerimientos (el acta solo trae el código) | No hay qué especificar ni construir | Cada doliente: Camilo Beltrán (4900, 4904), Rubén Cárdenas (4902, 4906), Sandra Gil (4903, 4908), Felipe Arango (4905), Liliana Torres (4907, 2036), Andrés Lozano (4911), Óscar Ramírez (2028, 4910), Laura Vélez (4901) |
| Doliente de REQ-4909, 4913 (y 4912, propuesto): «sin asignar» | Aceptados sin doliente: nadie responde por ellos | Beatriz Cuéllar / Comité de producto |
| Criterio de aceptación verificable en los 12 aceptados; REQ-4905 no tiene ninguno | Imposible saber cuándo quedó bien | Dolientes con Beatriz Cuéllar |
| Proyecto que ejecuta cada requerimiento: el acta dice «—» en los 16, y la definición dice «Ninguno declarado» | «Se mantiene el plan» (acta) sin plan ni proyecto que lo sostenga; sin traza no hay acta de constitución | Beatriz Cuéllar |
| Evidencia de demanda: REQ-4900, 4903, 4905, 4908, 4911 no tienen ninguna. Los demás citan la misma única entrevista (2025-08-16, «Cliente entrevistado»: «Lo necesito y hoy no lo tengo.»), que no nombra ningún requerimiento y tiene 14 meses (umbral 12) | Aceptados sin sustento de demanda vigente | Beatriz Cuéllar |
| Quién decidió la aceptación: el acta no lo dice (`decision.who` vacío en los 12) | Decisión sin autor registrado | Comité de producto |
| Fecha de REQ-2036 («desde 2026-10-15») es posterior al acta (2026-10-12) | Inconsistencia: o la fecha o la aceptación están mal | Beatriz Cuéllar |
| Casos borde (pago duplicado, falta de conexión, cliente que se va antes de confirmar, rechazo de cobertura): no definidos en ningún documento | Cada equipo los decidirá por su cuenta | Beatriz Cuéllar con los dolientes |
| Lo que otro equipo debe hacer (proveedor/aseguradora, cobro, atención): no se nombra ningún equipo ni acuerdo | No se sabe de quién depende | Beatriz Cuéllar |
| Criterio de éxito del producto y retorno con cifra | No hay contra qué medir el cierre | Beatriz Cuéllar / Comité de producto |
| Obligaciones normativas (abajo) | Se descubren con el producto construido | Beatriz Cuéllar con revisión jurídica |

### Barrido normativo (primer barrido, nombra y cita; no dice si se cumple)
El país no está dicho en ninguna parte de la documentación; sin país no cito normas.

| Qué toca la definición | País | Obligación | Norma citada | Estado |
|---|---|---|---|---|
| Vende un seguro (microseguro) a un segmento de consumidores | no declarado | Obligaciones de la actividad aseguradora y de información previa al consumidor | — | no tengo la norma a la vista |
| Segmento Pensionados (posible dato de edad, pensión, salud para suscribir) | no declarado | Tratamiento de datos personales, posiblemente sensibles; autorización y finalidad | — | no tengo la norma a la vista |
| Cobro de prima (medio de pago no definido) | no declarado | Medios de pago y reportes | — | no tengo la norma a la vista |
| Aceptación de póliza/condiciones | no declarado | Prueba del consentimiento, reclamos, retención | — | no tengo la norma a la vista |

Ningún documento de la organización resuelve alguno de estos puntos. Deben entrar al registro como restricción o como riesgo con doliente (**raid-taxonomy**).

## Requerimientos aceptados que esta especificación no cubre
| REQ | Título | Por qué no |
|---|---|---|
| REQ-4900 | (sin título; solo el código) | Sin problema escrito; sin evidencia; sin criterio verificable; sin proyecto |
| REQ-4902 | ídem | Sin problema escrito; evidencia no lo nombra y tiene 14 meses; criterio no verificable; sin proyecto |
| REQ-4903 | ídem | Sin problema escrito; sin evidencia; criterio no verificable; sin proyecto |
| REQ-4905 | ídem | Sin problema escrito; sin evidencia; sin criterio de aceptación; sin proyecto |
| REQ-4906 | ídem | Igual que REQ-4902 |
| REQ-4907 | ídem | Igual que REQ-4902 |
| REQ-4908 | ídem | Sin problema escrito; sin evidencia; criterio no verificable; sin proyecto |
| REQ-4909 | ídem | Igual que REQ-4902, y sin doliente («sin asignar») |
| REQ-4911 | ídem | Sin problema escrito; sin evidencia; criterio no verificable; sin proyecto |
| REQ-4913 | ídem | Igual que REQ-4902, y sin doliente («sin asignar») |
| REQ-2028 | ídem | Igual que REQ-4902 |
| REQ-2036 | ídem | Igual que REQ-4902, y con fecha posterior al acta |

Cobertura: 0 de 12 requerimientos aceptados con comportamiento especificado.

## Después
No se ofrece `/product-charter`: faltan problema, criterio de éxito, criterio de aceptación verificable y proyecto. Primer paso sugerido: que cada doliente escriba en una frase qué necesita quien lo pidió.

---
Pie: sale del registro `estado-producto/PRD-309/requirements` (16 requerimientos; 12 aceptados, 4 propuestos), basado en el acta del comité del 2026-10-12, la definición y el caso de negocio del 2026-01-25 y el tablero del 2026-10-14. Cubre 0 requerimientos con comportamiento. Términos v1.1 aceptados por José Francisco Ñáñez el 2026-10-16: https://www.josenanez.com/es/agents/criterio-pmo/legal
