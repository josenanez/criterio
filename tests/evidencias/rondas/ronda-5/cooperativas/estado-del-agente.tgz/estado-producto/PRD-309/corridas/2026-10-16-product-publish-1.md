# Corrida del 2026-10-16 · product-publish

PRD-309 · 16 requerimientos · 17 s · 36 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 12 |
| `evidence_stale` | 10 |
| `requirement_accepted_without_evidence` | 5 |
| `requirement_undecided` | 4 |
| `requirement_without_owner` | 3 |
| `requirement_without_acceptance` | 1 |
| `claim_vs_metric` | 1 |

No se publicó: la configuración no define carpeta de productos publicados

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

**No publiqué la ficha de PRD-309 (Microseguros): la configuración no tiene carpeta de productos publicados.**

`.criterio/producto/PRD-309/config.json` solo define `paths.documents` y `paths.state`. Sin un sitio común acordado, este comando no tiene dónde escribir `PRD-309.json`. Acordar ese sitio es una conversación de la organización, no un comando, y no lo inventé.

Términos: ya vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-16), sin registro nuevo.

**Lo que habría llevado la ficha, con corte al 2026-10-16:**
- **Requerimientos:** 16 (12 aceptados, 4 propuestos), con id, título y estado.
- **Proyectos:** 0. Ningún requerimiento tiene proyecto asociado, así que hoy no hay nada que cruzar por proyecto.
- **Métricas afirmadas:** 1.
  - `volumen_mensual` = 276481, tomada de `documentos/productos/PRD-309/00-definicion/2026-01-25-caso-de-negocio.md` (2026-01-25).
  - Nota: el tablero del 2026-10-14 mide 194582, un 29.6 % por debajo. La ficha publica solo la cifra afirmada, no la medida.
- **Segmento declarado:** Pensionados.
- **Gerente:** Beatriz Cuéllar.

**Para publicar:** definir en la configuración la carpeta común de fichas publicadas, o confirmar que se cree, y volver a correr `/product-publish`.
