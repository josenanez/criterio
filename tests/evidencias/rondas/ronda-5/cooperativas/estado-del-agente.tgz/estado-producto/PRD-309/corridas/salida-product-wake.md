## Microseguros (PRD-309) · 2026-10-16

**Primera revisión del registro: no existía corte anterior**, así que no hay "señales nuevas desde el corte" que separar. Lo que sigue es la línea base: de aquí en adelante solo se reportará lo que cruce un umbral después de hoy. Tocó `review` (nunca se había corrido). No tocan `report` ni `crossed`.

Registro: 16 requerimientos (12 aceptados, 4 propuestos). 7 con evidencia (58,3 %), 0 con traza a un proyecto (0 %).

### Lo que lleva tiempo sin decidirse (umbral 60 días)
| Qué | REQ | Cuánto lleva | Qué se necesita | Quién |
|---|---|---|---|---|
| Propuesto sin decidir | REQ-4910 | 172 días (desde 2026-04-27) | Decisión del comité; además no tiene evidencia | Doliente: Óscar Ramírez. Decide: Comité de producto |
| Propuesto sin decidir | REQ-4901 | 141 días (desde 2026-05-28) | Decisión del comité; su única evidencia tiene 14 meses | Doliente: Laura Vélez. Decide: Comité de producto |
| Propuesto sin decidir | REQ-4912 | 110 días (desde 2026-06-28) | **Primero un doliente**: no tiene ninguno | Sin doliente. Beatriz Cuéllar asigna; luego decide el Comité |
| Propuesto sin decidir | REQ-4904 | 69 días (desde 2026-08-08) | Decisión del comité; falta criterio de aceptación | Doliente: Camilo Beltrán. Decide: Comité de producto |

Ofrezco llevar estos cuatro al próximo comité de producto.

### Aceptado sin sustento
- **Sin evidencia de demanda (5):** REQ-4900, 4903, 4905, 4908, 4911. REQ-4905 además no tiene criterio de aceptación.
- **Evidencia vencida (>12 meses, 10 requerimientos):** toda la demanda documentada del producto es una sola entrevista del 2025-08-16 a un «Cliente entrevistado», que no nombra ningún requerimiento («Lo necesito y hoy no lo tengo»). Con esa entrevista envejecida, la definición se queda sin sustento fechado para la demanda de Pensionados.
- **Sin doliente (3):** REQ-4909, 4912, 4913.

### Lo aceptado que nadie está construyendo
Los 12 aceptados están sin traza a proyecto. Ninguna ficha de proyecto de la carpeta `estado/records` nombra PRD-309. Con las fichas a la vista, **ninguna traza se confirma**: no hay ninguna que confirmar ni ninguna que se haya roto. Las aceptaciones más viejas: REQ-4902 (205 días), REQ-4906 (213), REQ-4903 (191), REQ-4908 (187).

### Lo que el negocio declara contra lo que los datos miden
| Métrica | Declarado (caso de negocio, 2026-01-25) | Medido (tablero, 2026-10-14) | Brecha |
|---|---|---|---|
| Volumen mensual | 276.481 | 194.582 | 29,6 % por debajo de lo declarado (umbral 20 %) |

### Lo que no se sabe
- El criterio de éxito de la definición **no está dicho** en ningún documento.
- No hay supuestos registrados como no verificados; esto significa que ninguno está declarado, no que no existan.

Este comando no decidió nada ni le escribió a nadie.

**Vuelvo el 2026-11-15.**
