# Corrida del 2026-10-16 · product-business-case

PRD-309 · 16 requerimientos · 39 s · 36 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 12 |
| `evidence_stale` | 10 |
| `requirement_accepted_without_evidence` | 5 |
| `requirement_undecided` | 4 |
| `requirement_without_owner` | 3 |
| `requirement_without_acceptance` | 1 |
| `claim_vs_metric` | 1 |

Caso de negocio armado: 1 cifra declarada (276.481) contra 1 medida (194.582), 29,6 % de diferencia; costos, criterio de éxito, retorno, propuesta y país sin fuente; sin productos publicados para cruzar.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

# Caso de negocio — Microseguros (PRD-309) · borrador del 2026-10-16
**Desde:** la definición y el caso de negocio, ambos del 2026-01-25 · **Cifras con fuente:** 1 de 2

Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-16). Este es un borrador de estructura y trazabilidad: las cifras son del negocio y la verificación es de quien lo lee.

## Qué problema resuelve, y para quién
«El segmento Pensionados no tiene microseguros.» Segmento: Pensionados. (Definición, 2026-01-25.) Ningún documento sostiene ni niega la afirmación; la única entrevista (2025-08-16, «Cliente entrevistado», sin nombre) dice «Lo necesito y hoy no lo tengo» y no nombra el producto ni el segmento.

## Qué se construye
La propuesta de la definición es el texto de relleno «Propuesta principal»: no describe qué se ofrece. Lo decidido está en el acta del comité del 2026-10-12: 12 requerimientos aceptados, ninguno con proyecto que lo ejecute.

| Requerimiento | Estado | Evidencia de demanda |
|---|---|---|
| REQ-2028, REQ-2036, REQ-4902, REQ-4906, REQ-4907, REQ-4909, REQ-4913 | aceptado | «Cliente entrevistado» (entrevista 2025-08-16, genérica, 14 meses; no nombra ninguno de ellos) |
| REQ-4900, REQ-4903, REQ-4905, REQ-4908, REQ-4911 | aceptado | Ninguna: el acta dice «—» en «Quién lo pidió» |

Fuera del caso, por no estar decididos: REQ-4901, REQ-4904, REQ-4910 y REQ-4912 (propuestos). REQ-4909 y REQ-4913 no tienen doliente; REQ-4905 no tiene criterio de aceptación.

## Las cifras
| Cifra | Valor | Clase | De dónde sale | De cuándo |
|---|---|---|---|---|
| volumen_mensual | 276.481 | Declarada | Caso de negocio (Beatriz Cuéllar) | 2026-01-25 |
| volumen_mensual | 194.582 | Medida | Tablero de métricas, bodega de datos | corte 2026-10-14 |
| «Retorno esperado en 24 meses» | sin valor | Supuesta | Implícita; el caso no trae número ni fuente | — |

La medida tiene un solo punto y el tablero no define qué cuenta el «volumen». No se sabe si ambas cifras cuentan lo mismo.

### Donde la cifra declarada y la medida no coinciden
| Métrica | Declarada | Medida | Las dos fuentes y fechas |
|---|---|---|---|
| volumen_mensual | 276.481 | 194.582 | Caso de negocio 2026-01-25 / Tablero de métricas, corte 2026-10-14 |

La declarada está 29,6 % por encima de la medida (umbral configurado: 20 %). El caso se apoya en la cifra que su propia métrica no confirma.

## Los costos
| Concepto | Valor | De dónde sale |
|---|---|---|
| Costo de construir | **No hay** | Ningún documento. Sin contrato, cotización ni costo declarado del equipo |
| Costo de operar | **No hay** | Ningún documento |
| Proveedor | **No hay** | El supuesto menciona un proveedor y un «tiempo pactado», pero no hay contrato ni nombre |

El costo de construir es el primer vacío: sin él no hay caso de negocio que evaluar, hay una propuesta.

## Supuestos sobre los que se sostiene
| Supuesto | Qué pasa si resulta falso | Quién lo verificaría |
|---|---|---|
| El proveedor cumple el tiempo pactado (declarado 2026-03-30, marcado «verificado» sin citar con qué; la fecha es posterior a la de la definición) | Se mueve la fecha de entrega y, con ella, el momento del retorno; hoy no hay fecha contra la cual medirlo | Beatriz Cuéllar, con el contrato o plan que fija el tiempo pactado |
| Los pensionados no tienen microseguros y los quieren | No hay demanda que justifique las cifras | Quien produzca evidencia de demanda del segmento (hoy una frase de una persona sin nombre) |
| El volumen mensual de 276.481 es alcanzable | El retorno se calcularía sobre una base inexistente | El negocio: de dónde sale esa cifra |
| Retorno en 24 meses | El horizonte no es verificable | El negocio: sin cifra no hay qué verificar |

## Vacíos
| Qué falta | Por qué importa | Quién lo produce |
|---|---|---|
| Costo de construir y de operar | Sin él no hay caso que evaluar | Beatriz Cuéllar / finanzas |
| Cifra y fecha del retorno esperado | «Retorno esperado en 24 meses» no se puede medir | El negocio |
| Origen del volumen 276.481 y qué cuenta el «volumen» | La declarada y la medida no son comparables | Beatriz Cuéllar y el dueño del tablero |
| Propuesta real | Hoy es «Propuesta principal» | Beatriz Cuéllar |
| Tamaño del segmento Pensionados y evidencia de demanda | Una entrevista sin nombre, de hace 14 meses | Producto |
| País | Sin él no se puede decir qué normas aplican (seguros, datos personales, cobro de primas) | Beatriz Cuéllar; revisión jurídica |
| Qué alternativas se consideraron y qué pasa si no se hace | No está en ningún documento | El negocio |
| Proyecto que lo construye | «Ninguno declarado»; el acta no lo nombra | Beatriz Cuéllar |
| Quién decide | Ningún documento lo nombra; «Comité de producto» es el valor por defecto de la instalación | Beatriz Cuéllar |

## Cómo se sabrá si funcionó
**No está declarado.** Ni la definición ni el caso de negocio escriben criterio de éxito, y «Retorno esperado en 24 meses» no trae métrica ni cifra. Sin esto el producto no se puede cerrar meses después. Lo único medido que existe es `volumen_mensual`, y no hay meta ni fecha de corte contra la cual leerla.

## Si hay otros productos publicados
No hay ninguno publicado: la carpeta `estado/` está vacía, así que el cruce de `/product-overlap` no se puede hacer. Otros productos (PRD-299, 300, 302, 305, 307, 308…) tienen también una métrica llamada `volumen_mensual`, pero el nombre solo no dice si cuentan las mismas transacciones. Cuando estén publicados, conviene cruzarlos.

## Después
- Los supuestos pueden pasar al seguimiento con **assumption-tracking**, en particular el del proveedor, que dice «verificado» sin fuente.
- No corresponde `/product-charter`: el caso no tiene costos, criterio de éxito ni propuesta, y esa decisión es de quien tiene la autoridad.
