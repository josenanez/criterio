## Listo — Microseguros (PRD-309)

**Lo que miré:** 5 documentos · 1 de descubrimiento (una entrevista, 2025-08-16) · la definición y el caso de negocio del 2026-01-25 · lo más reciente es el tablero del 2026-10-14. Todos los formatos se pudieron leer.
**Términos:** aceptados para la versión 0.3.11 (términos 1.1) por José Francisco Ñáñez, 2026-10-16 · comprobante en `.criterio/terminos/aceptacion-criterio-product-0.3.11-2026-10-16.md` y `.pdf` · SHA-256 f969d4f658630df3… (md) y 064270343bd7a374… (pdf)

**Configuración:** `.criterio/producto/PRD-309/config.json` · estado en `estado-producto/PRD-309` (no uso `estado/`, que es de otro agente). Gerente: Beatriz Cuéllar. Quién decide: Comité de producto, respuesta sugerida; ningún documento lo nombra.

**Sesión sin interfaz:** tomé la respuesta sugerida en cada pregunta. No se pudo sellar la lectura: `sellar` exige una corrida abierta y este comando no abre ninguna.

### Lo que tu definición afirma, y qué lo sostiene
| Afirmación | Sostenida por | De cuándo |
|---|---|---|
| El segmento Pensionados no tiene microseguros | Una entrevista a un «Cliente entrevistado»: «Lo necesito y hoy no lo tengo.» No dice que sea pensionado. Sostenida solo en parte | 2025-08-16 |
| El volumen mensual será de 276.481 | Nada. Es una cifra del caso de negocio; el tablero mide 194.582 al 2026-10-14, **29.6 %** por debajo de lo declarado | 2026-01-25 |
| El proveedor cumple el tiempo pactado | Un supuesto que el documento marca «verificado», sin decir con qué | declarado 2026-03-30 |
| Retorno esperado en 24 meses | Nada: no hay cifra de retorno ni de dónde sale | 2026-01-25 |

### Lo que no está dicho en ninguna parte
- **El criterio de éxito.** Ni la definición ni el caso de negocio dicen qué tiene que pasar para decir que funcionó.
- **La propuesta.** Dice «Propuesta principal»; no describe qué se ofrece.
- **Que los Pensionados lo pidan.** La única entrevista no dice quién es el entrevistado ni su segmento.
- **De dónde sale 276.481**, y qué cuenta el «volumen» (el tablero tampoco lo define).
- **Qué proyecto construye esto.** La definición dice «Ninguno declarado» y el acta no pone ninguno en los 16 requerimientos: 0 con proyecto.
- **El problema de cada requerimiento.** El acta solo trae códigos («Requerimiento REQ-4900»), sin el problema que resuelven.
- **Quién decidió cada aceptación.** El acta lista como único asistente a Beatriz Cuéllar y no dice quién aceptó.
- **Con qué se verificó el supuesto del proveedor**, y por qué su fecha (2026-03-30) es posterior a la de la definición (2026-01-25).

### Lo que el registro muestra (16 requerimientos: 12 aceptados, 4 propuestos)
- **12 aceptados sin proyecto** (0 % trazados).
- **5 aceptados sin evidencia de demanda:** REQ-4900, 4903, 4905, 4908, 4911. Solo 7 de 12 aceptados traen evidencia (58.3 %).
- **10 con evidencia vencida:** la única entrevista tiene 14 meses (umbral: 12), y es la que sostiene a todos los que citan «Cliente entrevistado». No nombra ninguno de los requerimientos.
- **4 propuestos sin decidir** desde hace 69 a 172 días (umbral: 60): REQ-4901 (141), REQ-4904 (69), REQ-4910 (172), REQ-4912 (110).
- **3 sin doliente** («sin asignar»): REQ-4909, 4912, 4913.
- **1 aceptado sin criterio de aceptación:** REQ-4905, que además no tiene evidencia.
- **La decisión del comité del 2026-10-12 fue «Se mantiene el plan»**, con 12 aceptados sin proyecto.

### Supuestos sobre los que está escrita
Uno: «El proveedor cumple el tiempo pactado», declarado el 2026-03-30 y marcado «verificado». Lo registré como verificado porque el documento lo dice, pero sin fuente de la verificación. Es una afirmación que no puedo comprobar.

### Qué le falta a tu carpeta
- **Las transcripciones de las entrevistas.** Hay una sola, de 14 meses, anónima y de una frase.
- **El origen de la cifra de 276.481** y la definición de «volumen mensual», con una serie y no un solo punto: el tablero trae un único dato.
- **El criterio de éxito y el retorno** en cifras.
- **Quién aceptó y por qué**, en el acta del comité de producto.

Después: `/product-discovery` sobre el material de entrevistas, donde los temas se vuelven requerimientos con la cita de quién los pidió.
