# Corrida del 2026-10-16 · product-charter

PRD-309 · 16 requerimientos · 33 s · 36 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 12 |
| `evidence_stale` | 10 |
| `requirement_accepted_without_evidence` | 5 |
| `requirement_undecided` | 4 |
| `requirement_without_owner` | 3 |
| `requirement_without_acceptance` | 1 |
| `claim_vs_metric` | 1 |

Borrador de acta para REQ-4900 sin firma ni ficha. Faltan problema, evidencia de demanda, criterio de éxito medible, autoridad, patrocinador y gerente. Brecha de volumen_mensual 29,6 % contra el umbral de 20 %. Barrido normativo sin hacer.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-16); no se pidió nuevo registro.

**Verificación previa (requirement-record) para REQ-4900:**
- Aceptado, no propuesto: **sí** (acta del comité 2026-10-12; desde 2026-08-19). Pero el acta no dice quién lo decidió (`decision.who` vacío).
- Criterios de aceptación verificables: **no de verdad**. El único es «se verifica en producción», que no dice qué se mide ni con qué umbral.
- Evidencia de demanda con cita: **falta**. «Quién lo pidió» es «—» y `evidence` está vacío.
- Autoridad declarada en la definición: **falta**. Ningún documento nombra quién decide; «Comité de producto» es la propuesta por defecto de la instalación, no un dato del documento.

Respuesta sugerida tomada (sesión sin interfaz): seguir sin ellos, marcándolos como vacíos del acta, sin rellenarlos.

---

# Acta de constitución — Microseguros / REQ-4900 · borrador del 2026-10-16
**Producto:** PRD-309 Microseguros · **Requerimientos:** REQ-4900

## Qué problema resuelve
**No está dicho.** El registro de REQ-4900 no tiene la necesidad: el acta del comité solo trae el código («Requerimiento REQ-4900») (`documentos/productos/PRD-309/30-decisiones/2026-10-12-comite-producto.md`).
El problema del producto, por contexto, es: «El segmento Pensionados no tiene microseguros» (`documentos/productos/PRD-309/00-definicion/2026-01-25-definicion-producto.md`). Ningún documento une REQ-4900 a ese problema.

## Criterio de éxito
| Criterio | Cómo se verifica | Fuente |
|---|---|---|
| «se verifica en producción» | **No definido**: sin métrica, umbral ni fecha | acta del comité 2026-10-12 |

La definición del producto no escribe criterio de éxito. El caso de negocio solo dice «Retorno esperado en 24 meses», sin cifra (`2026-01-25-caso-de-negocio.md`).

## Alcance
### Entra
| REQ | Título | Evidencia que lo sostiene |
|---|---|---|
| REQ-4900 | Requerimiento REQ-4900 (título genérico; el problema no está escrito) | **Ninguna.** Doliente: Camilo Beltrán. Aceptado el 2026-08-19 |

### No entra
Sin requerimientos adicionales: el acta se pidió solo para REQ-4900. Los otros 15 requerimientos del registro no entran en esta acta porque no se pidieron. No hay una razón de exclusión por requerimiento en los documentos, y no la invento.

## Gobierno
- **Patrocinador:** no dicho en ningún documento.
- **Gerente propuesto:** no nombrado. Beatriz Cuéllar es gerente de *producto* (definición); ningún documento la designa gerente de *proyecto*. Asignarlo le corresponde a quien tiene la autoridad.
- **Comité:** el acta registra un «Comité de producto» con Beatriz Cuéllar como única asistente. No hay otra composición documentada.
- **Autoridad del gerente:** no dicha. «Comité de producto» es un valor por defecto de la instalación, marcado como supuesto.
- **Quién decidió aceptar REQ-4900:** no dicho.

## Supuestos que se llevan al proyecto
| Supuesto | Verificado | Se convierte en riesgo de |
|---|---|---|
| «El proveedor cumple el tiempo pactado» (declarado 2026-03-30) | Dice «verificado» sin citar con qué; la fecha declarada es posterior a la de la definición (2026-01-25) | Gerente del proyecto (por nombrar). Se registra como riesgo con doliente, no como hecho |

No hay supuestos propios en el registro de REQ-4900.

## Restricciones normativas sin resolver
| Qué toca | Obligación | Norma | Estado |
|---|---|---|---|
| Microseguros para pensionados (producto de seguros, consumidor financiero, datos personales) | No levantada | No barrido | **Sin barrer.** Esta corrida no hizo el barrido normativo (regulatory-sweep) y no cita normas sin fuente. Hay que hacerlo antes de firmar |

## Vacíos de este acta
| Qué falta | Consecuencia de firmar sin eso | Quién lo cierra |
|---|---|---|
| Problema/necesidad de REQ-4900 | Se aprueba un proyecto sin saber qué resuelve | Camilo Beltrán (doliente) |
| Evidencia de demanda (quién lo pidió) | Se construye sin sustento de que alguien lo pidió | Gerente de producto (Beatriz Cuéllar) |
| Criterio de éxito medible | El cierre no se podrá juzgar | Gerente de producto + doliente |
| Autoridad del gerente | El proyecto escala todo o no escala nada | Quien tenga la autoridad sobre el producto |
| Patrocinador y gerente de proyecto | Nadie firma ni es dueño de la ficha | Comité de producto |
| Quién decidió aceptar REQ-4900 | La aceptación no es trazable | Comité de producto |
| Barrido normativo | Obligaciones aún no identificadas | Gerente de producto / área legal |
| **Cifra del caso de negocio contra datos**: volumen_mensual declarado 276.481 vs medido 194.582 (2026-10-14), brecha de 29,6 %, sobre el umbral configurado de 20 % | El proyecto arranca sobre una cifra que los datos no sostienen. Además el tablero no define qué cuenta el volumen | Gerente de producto |
| Contexto: la definición solo trae «Propuesta principal» (texto de relleno) y «Ninguno declarado» en proyectos | La propuesta de valor no está escrita | Gerente de producto |

---
**Esto es un borrador.** Lo firma quien tenga la autoridad sobre el producto (sin nombrar en los documentos). **La ficha del proyecto no se creó:** nadie ha firmado el acta, y la ficha se crea después de la firma. Con ocho vacíos abiertos, firmar hoy sería firmar un acta a medias.

## Después
Una vez firmada, el gerente del proyecto instala `criterio-project` y corre `/pm-setup`. Cuando publique su ficha con `/pm-publish`, `/product-trace` podrá confirmar la traza contra ella, y desde ahí Alba sabrá si el producto se está construyendo sin preguntarle a nadie.
