## Definición — Microseguros (PRD-309) · contrastada al 2026-10-16
**Documento:** `00-definicion/2026-01-25-definicion-producto.md` y `00-definicion/2026-01-25-caso-de-negocio.md` · **del** 2026-01-25 · 6 afirmaciones

Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-16). Este contraste es un borrador de trabajo: la verificación es de quien lo lee.

### Lo que la evidencia contradice
| Afirma | Dice la evidencia | Las dos fuentes y sus fechas |
|---|---|---|
| `volumen_mensual` = 276.481 | 194.582 medido; el declarado está 29,6 % por encima (umbral 20 %) | Caso de negocio, 2026-01-25 → Tablero de métricas (bodega de datos), corte 2026-10-14 |

La serie medida tiene un solo punto y el tablero no define qué cuenta el volumen (`metrics/volumen_mensual.json`). La diferencia está citada; qué se contó en cada lado no se puede saber con estos documentos.

### El negocio y los datos
| Métrica | Declarado | Medido | Diferencia | Las dos fuentes y fechas |
|---|---|---|---|---|
| volumen_mensual | 276.481 | 194.582 | 29,6 % (declarado por encima) | caso-de-negocio 2026-01-25 / tablero-metricas 2026-10-14 |

### Afirmaciones numéricas que nadie mide
| Afirma | De qué documento | No hay serie |
|---|---|---|
| «Retorno esperado en 24 meses» | caso-de-negocio 2026-01-25 | Sin cifra, sin serie, sin fuente: no hay nada que medir |

### No está dicho en ninguna parte
- **Criterio de éxito:** ni la definición ni el caso de negocio lo escriben. «Retorno esperado en 24 meses» no trae número.
- **Que los pensionados carezcan de microseguros:** la definición lo afirma («El segmento Pensionados no tiene microseguros») y ningún documento lo sostiene ni lo niega. La única entrevista (2025-08-16, «Cliente entrevistado», sin nombre) dice «Lo necesito y hoy no lo tengo»: no dice qué, ni que sea pensionado.
- **Tamaño del segmento Pensionados** y de dónde sale el volumen de 276.481.
- **La propuesta:** el texto es «Propuesta principal», relleno; no describe qué se ofrece.
- **Quién decide:** ningún documento lo nombra. «Comité de producto» es la propuesta por defecto de la instalación; el acta de 2026-10-12 solo lista como asistente a Beatriz Cuéllar.
- **Qué proyecto lo construye:** «Ninguno declarado».
- **Qué cuenta el «volumen mensual»** (el tablero no lo define).
- **Cuánto pagaría el cliente, o si alguien ya pagó:** no hay evidencia de pago ni de compromiso.

### Sostenida por un supuesto
| Supuesto | Días sin verificar | Qué haría falta para verificarlo |
|---|---|---|
| El proveedor cumple el tiempo pactado | 0 contados: el documento lo marca «verificado» (declarado el 2026-03-30) | Citar con qué: el contrato o plan con el tiempo pactado, nombre del proveedor y el entregable que lo muestre. Hoy no hay ninguno en la carpeta. La fecha declarada es posterior a la de la definición. |

El cálculo no lo cuenta como sin verificar (`assumptions_unverified` vacío), pero la verificación no tiene fuente. Se deja aquí, no en «sostenida por evidencia».

### Sostenida por evidencia
| Afirmación | Sostenida por | De cuándo | Qué tan fuerte |
|---|---|---|---|
| Existe una necesidad no atendida | Entrevista a «Cliente entrevistado»: «Lo necesito y hoy no lo tengo.» | 2025-08-16 | Débil: una persona, sin nombre, una frase, no nombra el producto ni el segmento. Es lo que alguien dijo, no lo que alguien pagó. |

### Evidencia que ya envejeció
| Afirmación | Lo más nuevo que la sostiene | Hace |
|---|---|---|
| La necesidad (única entrevista, usada en 10 requerimientos) | 2025-08-16 | 14 meses (umbral 12) |

### Lo normativo que toca
Barrido sin país: ningún documento dice en qué país se ofrece el producto. Se nombra lo que toca; no se dice si cumple, y va a revisión jurídica.

| Qué toca | País | Obligación | Norma | Estado |
|---|---|---|---|---|
| Venta de seguros / microseguros a personas | no declarado | Regulación de la actividad aseguradora, información previa y condiciones al asegurado | — | no tengo la norma a la vista |
| Datos personales de pensionados (identificación, edad, probable dato de salud para asegurar) | no declarado | Autorización y finalidad; tratamiento especial de datos sensibles | — | no tengo la norma a la vista |
| Proveedor que ejecuta parte del producto (supuesto del proveedor) | no declarado | Obligaciones de quien encarga el tratamiento o la operación a un tercero | — | no tengo la norma a la vista |
| Cobro de primas | no declarado | Medios de pago y protección al consumidor financiero | — | no tengo la norma a la vista |
| Reclamos y siniestros; conservación de la trazabilidad | no declarado | Atención de reclamos, retención de información | — | no tengo la norma a la vista |
| Público pensionado (adultos mayores) | no declarado | Accesibilidad e información clara al consumidor | — | no tengo la norma a la vista |

### Lo que falta para cerrar la definición
- **Criterio de éxito** (no declarado): sin él la definición no se puede cerrar; el cierre se juzgaría contra algo que no existe.
- **Quién decide** (no confirmado por documento).
- **Problema, para quién:** están escritos («El segmento Pensionados no tiene microseguros» / Pensionados), pero sin evidencia que los sostenga.
- Además: propuesta real, país, proyecto que lo construye, y la definición del volumen.

### Después
El supuesto del proveedor y la ausencia de criterio de éxito son candidatos a riesgo con doliente (raid-taxonomy). La definición no está cerrada, así que no corresponde ofrecer `/product-charter`.
