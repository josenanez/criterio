Sale de: la ficha `estado/records/PRY-200.json`, la salida de `portafolio.py compute` (corte 2026-10-16) y, en `documentos/proyectos/PRY-200-crédito-de-libranza-digital/`, los contratos CT-802 y CT-395, el acta de recibo de CT-802 (2025-12-01) y el informe de avance del 2026-09-26. Los dos PDF de factura (2026-09-03 y 2026-09-06) no tienen texto extraíble: sus montos salen de la ficha y no los pude contrastar con el documento.

## Proveedores — PRY-200 Crédito de libranza digital al 2026-10-16

**Resumen:** CT-802 cuadra. CT-395 tiene 207.643.011 COP facturados con cero entregables aceptados (`vendor_invoiced_without_delivery`). El informe declara verde y 25 %, pero el plan marca 5 de 5 hitos cumplidos sin evidencia de ninguno.

### Talento Solidario Ltda. — contrato CT-802
**Vigencia:** no dice (el contrato solo trae fecha de firma, 2025-06-10) · **Preaviso de no renovación:** no dice · **Vence el:** no dice

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento del módulo | 2025-11-13 | accepted | Acta de recibo 2025-12-01, firmada por Ricardo Salas (`20-seguimiento/2025-12-01-acta-recibo-ct-802-licenciamiento-del-módulo.md`) | 148.158.298 COP en total, factura 2026-09-03 |
| Bolsa de horas de desarrollo | 2026-04-04 | pending, 195 días de atraso | ninguna | no consta |

Facturado 148.158.298 COP; aceptado con acta 148.158.298 COP. Coinciden (`compute`: `invoiced` = `amount_accepted`).

### Soluciones Solidarias S.A.S. — contrato CT-395
**Vigencia:** no dice (el contrato solo trae fecha de firma, 2025-06-13) · **Preaviso de no renovación:** no dice · **Vence el:** no dice

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento del módulo | 2025-09-18 | pending, 393 días de atraso | ninguna | |
| Bolsa de horas de desarrollo | 2025-12-12 | pending, 308 días de atraso | ninguna | |
| Parametrización de líneas de crédito | 2026-03-07 | pending, 223 días de atraso | ninguna | |
| Mesa de ayuda del primer trimestre | 2026-05-31 | pending, 138 días de atraso | ninguna | |

Facturado en total: 207.643.011 COP (factura 2026-09-06). Aceptado con evidencia: 0 de 4 entregables (`amount_accepted` = 0).

### Dónde no cuadra
| Qué | Dice el contrato | Dice la evidencia | Fuentes |
|---|---|---|---|
| CT-395 facturado sin entrega | "Cada entregable se factura contra acta de recibo firmada por el gerente del proyecto" | No hay ningún acta de recibo de CT-395. Los 4 entregables están `pending`, y se facturaron 207.643.011 COP el 2026-09-06 (señal `vendor_invoiced_without_delivery`) | `00-gobierno/2025-06-13-contrato-ct-395.docx`; `20-seguimiento/2026-09-06-factura-ct-395.pdf` |
| Hitos del plan vs. proveedores | El cronograma marca como cumplidos "Integración con el core cooperativo", "Piloto con asociados" y "Salida a producción" | Con el licenciamiento, la parametrización y la mesa de ayuda de CT-395 sin recibir, esos hitos no tienen sustento en la entrega de proveedores | `10-plan/2025-06-15-cronograma-v1.xlsx`; contrato CT-395 |
| Estado declarado | Informe: verde, 25 % | El plan da 100 % (5 de 5 hitos, brecha de 75,0 puntos); 5 señales abiertas (silencio, avance, hitos sin evidencia, entregables tarde, factura sin entrega) | `20-seguimiento/2026-09-26-informe-avance.md`; `compute` |

### Sin evidencia de recibo
| Entregable | Marcado como | Desde |
|---|---|---|
| CT-395 · Licenciamiento del módulo | pending (el contrato dice "pendiente") | 2025-09-18, 393 días |
| CT-395 · Bolsa de horas de desarrollo | pending (el contrato dice "en curso") | 2025-12-12, 308 días |
| CT-395 · Parametrización de líneas de crédito | pending | 2026-03-07, 223 días |
| CT-395 · Mesa de ayuda del primer trimestre | pending | 2026-05-31, 138 días |
| CT-802 · Bolsa de horas de desarrollo | pending (el contrato dice "en curso") | 2026-04-04, 195 días |
| Hitos del plan: Diseño funcional aprobado, Ambiente de pruebas certificado, Integración con el core cooperativo, Piloto con asociados, Salida a producción | met, sin evidencia en ninguno | 401, 324, 247, 169 y 92 días |

Ningún entregable aparece como "aceptado sin evidencia" (`accepted_without_evidence` está vacío en ambos proveedores). El problema es el otro: entregables sin recibir que ya se facturaron (CT-395) y hitos del plan marcados como cumplidos sin acta.

### Compromisos del proveedor vencidos
No hay compromisos de proveedor en la ficha (`commitments`: vacío) y la carpeta no tiene minutas ni actas de comité. Lo más cercano es un riesgo del informe del 2026-09-26: "El proveedor no ha confirmado la fecha de la última entrega". No tiene dueño, fecha ni probabilidad, así que no es un compromiso fechable. Sin dato.

### Sin dato
- **Vigencia, renovación automática y preaviso de CT-802 y CT-395:** los contratos que están en la carpeta solo traen fecha de firma, entregables, montos y condición de pago. No puedo decir si algún preaviso vence antes del cierre. Pendiente: las cláusulas de vigencia.
- **Facturas (PDF):** sin texto extraíble. El monto facturado sale de la ficha y no está contrastado con el documento. Pendiente: leer las dos facturas.
- **Fechas de facturación por entregable:** hay un solo total por contrato. En CT-395 no puedo saber contra qué entregable se facturó.
- **Fase del proyecto y autoridad:** no constan en la documentación.
- **El proyecto lleva 20 días en silencio** (último documento 2026-09-26; umbral 15).

## Después
No hay un preaviso por vencer que pueda afirmar, porque ningún contrato trae vigencia. Hay un hallazgo para llevar a comité: CT-395, 207.643.011 COP facturados sin un solo entregable aceptado y sin acta de recibo, contra una condición de pago que exige el acta. Puedo preparar ese punto para el comité del 2026-10-23 si lo pides.

---
**Pie de rigor:** borrador de trabajo, no decisión ni asesoría. Las cifras de días, sumas y conteos están copiadas de `portafolio.py compute`; cada dato remite al documento citado y la verificación es suya. No sé lo que se haya hablado fuera de estos documentos.
