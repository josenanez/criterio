# Corrida del 2026-10-16 · project-history

13 proyectos · 46 s · 66 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `commitment_overdue` | 9 |
| `progress_vs_plan` | 7 |
| `declared_vs_evidence` | 7 |
| `vendor_deliverable_late` | 5 |
| `variance_cost` | 4 |
| `commitment_undated` | 3 |
| `silent` | 2 |
| `vendor_invoiced_without_delivery` | 2 |
| `variance_time` | 2 |
| `commitment_rescheduled` | 2 |
| `change_without_baseline` | 1 |
| `rebaseline_unauthorized` | 1 |
| `pm_vs_pmo` | 1 |

Historia de PRY-204 sobre 6 documentos (2025-10-24 a 2026-10-15). Un solo estado declarado, así que no se pudo fechar el deslizamiento ni calcular meses sin sustento. Sin minutas ni actas de comité: no se puede decir nada de compromisos repetidos ni de cambios de gobierno. La aprobación de CC-01 no se puede verificar.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

## Historia · PRY-204 Tarjeta débito para asociados · 2025-10-24 a 2026-10-15

**Leí:** 6 documentos entre 2025-10-24 y 2026-10-15 (acta de constitución, cronograma v1, cronograma v2, informe de avance, solicitud de cambio CC-01, acta de recibo del piloto). No hay actas de comité, minutas ni correos de este proyecto en la carpeta.
**Trimestres sin un solo documento:** 2026 T1, 2026 T2 y 2026 T3. Entre 2025-10-24 y 2026-10-12 hay 353 días sin ningún documento; los cuatro documentos siguientes caen en 4 días (12 a 15 de octubre de 2026).

### En una línea
El proyecto se constituyó el 2025-10-24 con cierre comprometido el 2026-10-18 y 18.000 millones COP, y no volvió a dejar rastro escrito hasta el 2026-10-12, cuando aparecen de golpe un cronograma v2 que mueve el piloto del 2026-09-09 al 2027-01-02, un informe de avance en Verde con 83 %, una solicitud de cambio CC-01 (2026-10-13) que dice justificar los 115 días, y un acta de recibo del piloto (2026-10-15). El atraso quedó escrito cuatro días antes del cierre comprometido, no cuando ocurrió.

### Las cuatro cifras
| Replanificaciones | Atraso acumulado vs. original | Meses declarando sin sustento | Cambios de gobierno |
|---|---|---|---|
| 1 | 115 días (37.1 %); contra la línea vigente, 0 | No calculable: hay una sola declaración (2026-10-12) y el script no da esta cifra. Lo que sí se mide: el primer hito dado por cumplido sin evidencia venció hace 270 días | 0 documentados (con un solo documento de gobierno, no hay contra qué comparar; ver Gobierno) |

### Línea de tiempo
| Fecha | Documento | Qué cambió |
|---|---|---|
| 2025-10-24 | 00-gobierno/acta-constitucion.md | Nace el proyecto. Patrocinador Ricardo Salas, gerente Diana Molina, Comité de Riesgos. 18.000.000.000 COP. Inicio 2025-11-03, cierre 2026-10-18. Alcance: "Componente 1/2/3". Dependencias: ninguna declarada |
| 2025-10-24 | 10-plan/cronograma-v1.xlsx | Línea base original: 4 hitos, el último (Piloto con asociados) el 2026-09-09. Todos aparecen "cerrado" en un archivo fechado en 2025: el estado no es de esa fecha |
| 2026-10-12 | 10-plan/cronograma-v2.csv | El piloto pasa de 2026-09-09 a 2027-01-02 (+115 días). Los otros tres hitos no cambian. Los cuatro "cerrado" |
| 2026-10-12 | 20-seguimiento/informe-avance.pdf | Estado declarado Verde, 83 %. Proyección al cierre 20.519.654.277 COP contra 18.000.000.000 aprobados. Riesgo abierto: dependencia del proveedor del core. No menciona replanificación ni atraso |
| 2026-10-13 | 20-seguimiento/solicitud-cambio-cc-01.md | CC-01, "Ampliación de alcance": +115 días y +230.000.000 COP. "Autorizada por el comité", sin fecha de decisión ni acta |
| 2026-10-15 | 20-seguimiento/acta-recibo-piloto.pdf | Diana Molina recibe "a satisfacción" el piloto. Recibe la propia gerente; no hay firma de otra parte |

### Replanificaciones
| Nº | Fecha | Fecha de cierre nueva | Motivo declarado | Documento que la aprobó |
|---|---|---|---|---|
| 1 | 2026-10-12 (fecha del cronograma v2) | 2027-01-02 | Ninguno en el cronograma ni en el informe. La CC-01, un día después, lo atribuye a "ampliación de alcance" sin decir qué se amplía | CC-01 (2026-10-13): "autorizada por el comité", sin acta ni fecha de aprobación. El cronograma v2 es anterior a la solicitud que lo respalda |

Atraso acumulado contra la línea base original: 115 días (37.1 %). El script marca además `change_without_baseline`: la CC-01 está aprobada de palabra, pero la línea base no quedó con una versión nueva que la registre (la columna `fecha_linea_base` del v2 sigue mostrando 2026-09-09 y la vigente 2027-01-02, lo cual es correcto como registro del movimiento, pero no hay documento de línea base nueva).

### Gobierno
| Fecha | Qué cambió | Documento |
|---|---|---|
| — | Ningún cambio de patrocinador, gerente o comité en los documentos leídos | Solo existe el acta de 2025-10-24 como fuente de gobierno; después, el informe y la CC-01 mantienen a Diana Molina. "Ninguno" aquí significa "ninguno documentado", no "ninguno ocurrió" |

### Compromisos que se repitieron
No hay minutas ni transcripciones de este proyecto; el script no registra compromisos vencidos, sin fecha ni reprogramados. No puedo decir si hubo compromisos repetidos: faltan los documentos donde se dirían.

### Desde cuándo lo declarado no se sostiene
- **Primer hito sin evidencia:** "Diseño funcional aprobado", vencimiento 2026-01-19 (hace 270 días), marcado cumplido sin ningún documento que lo pruebe. Le siguen "Ambiente de pruebas certificado" (2026-04-07, 192 días) e "Integración con el core cooperativo" (2026-06-23, 115 días). Los tres hitos cumplidos carecen de evidencia en la carpeta.
- **Qué se reportó:** el único estado declarado que existe es Verde, 83 % (2026-10-12), con los cuatro hitos "cerrados" (el plan sostiene 100 %, brecha de 17 puntos), un atraso de 115 días (37.1 %) y una proyección 14.0 % sobre el presupuesto aprobado (20.519.654.277 contra 18.000.000.000). Ninguna de esas cuatro señales aparece reconocida en el informe.
- **Lo que no puedo fechar:** con una sola declaración no se ve el deslizamiento ni cuándo empezó el Verde sin sustento. Solo se puede decir que a 2026-10-12 no se sostenía, y que entre 2025-10-24 y esa fecha no hay un solo documento que lo contraste.
- **Además:** el piloto figura "cerrado" y con acta de recibo del 2026-10-15, pero su fecha vigente es 2027-01-02; recibido casi 11 semanas antes de su propia fecha vigente, sin explicación. La CC-01 pide 230.000.000 COP adicionales, pero la proyección supera lo aprobado en 2.519.654.277 COP; el documento no explica la diferencia. El acta declara "Ninguna" dependencia y el informe abre un riesgo por dependencia del proveedor del core.

### Lecciones ancladas a un hecho
1. **Hecho:** el atraso de 115 días en el piloto quedó escrito el 2026-10-12, cuatro días antes del cierre comprometido (2026-10-18) y 353 días después del último documento de planeación. **Efecto:** el comité no tuvo en ese tramo una versión escrita contra la cual medir; la desviación apareció completa y de una vez.
2. **Hecho:** el cronograma v2 (2026-10-12) mueve el piloto un día antes de que exista la CC-01 (2026-10-13) que lo justifica, y la CC-01 no trae fecha de decisión ni acta. **Efecto:** la aprobación no se puede verificar desde los documentos; hay que pedirla al comité.
3. **Hecho:** tres hitos con fecha de 2026-01-19, 2026-04-07 y 2026-06-23 se dan por cumplidos sin acta ni evidencia. **Efecto:** el 83 % y el "100 %" del plan descansan en declaración, no en documentos.
4. **Hecho:** el acta de recibo del piloto (2026-10-15) la firma quien gestiona el proyecto. **Efecto:** el recibo no demuestra aceptación de otra parte.

*Esto no atribuye intención: que el atraso apareciera tarde no dice que alguien lo ocultara. Sirve para llevar la conversación con Diana Molina, el patrocinador y el comité con fechas en vez de memorias. Puedo llevar esta historia al cierre del proyecto o al comité del 2026-10-23, donde hay una decisión pendiente: ratificar o no la CC-01 con su acta.*

**Pie de rigor:** cifras copiadas de `portafolio.py compute` (as_of 2026-10-16). La verificación de cada dato contra el documento citado es suya. Criterio produce borradores de trabajo, no decisiones ni asesoría.
