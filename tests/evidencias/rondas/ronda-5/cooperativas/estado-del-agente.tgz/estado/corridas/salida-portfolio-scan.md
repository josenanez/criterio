## Barrido — 2026-10-16

**Antes de leer:** la carpeta tiene 75 documentos en 13 carpetas de proyecto (.md 38, .docx 12, .xlsx 10, .pdf 9, .csv 4, .json 1, .txt 1). Plan de lectura: **58 por leer de 75** (los otros 17 no cambiaron y son de PRY-206, PRY-208 y PRY-209, cuyas fichas se conservan). Un lote de 10 proyectos, uno tras otro en esta conversación; sin subagentes. Ningún archivo ilegible.

**Términos:** vigentes desde antes del barrido (v1.1, plugin 0.3.11), aceptados por José Francisco Ñáñez el 2026-10-16; no hizo falta registrarlos otra vez.

**Documentos:** 75 en la carpeta · 58 leídos · 17 sin cambio desde la corrida anterior · 0 ilegibles
**Proyectos:** 13 con ficha · 10 nuevos (PRY-199, 200, 201, 202, 203, 204, 205, 207, 210, 211) · 0 sin carpeta propia

### Nuevos
| Proyecto | Documentos | Campos encontrados | Campos sin dato |
|---|---|---|---|
| PRY-199 Cambio de mobiliario de agencias | 6 | identidad, plan, 5 hitos, presupuesto, contrato CT-199 (3 entregables), 2 riesgos/incidencias, 1 compromiso | autoridad, fase, cambios |
| PRY-200 Crédito de libranza digital | 8 | identidad, plan, 5 hitos, presupuesto, contratos CT-802 y CT-395 (6 entregables), 2 facturas, riesgos e incidencias | autoridad, fase, cambios |
| PRY-201 Apertura de ahorro en línea | 3 | identidad, plan, 4 hitos, presupuesto, riesgo e incidencia | autoridad, fase, proveedores, cambios |
| PRY-202 Core cooperativo | 7 | identidad, plan, 5 hitos, presupuesto, contrato CT-362 (2 entregables), 1 factura, 1 compromiso | autoridad, fase, producto («No aplica»), cambios |
| PRY-203 Aportes sociales en línea | 3 | identidad, plan, presupuesto, CC-01, riesgos | autoridad, fase, proveedores, hitos (no hay cronograma) |
| PRY-204 Tarjeta débito para asociados | 6 | identidad, plan con 2 líneas base (v1 y v2), 4 hitos, presupuesto, CC-01 | autoridad, fase, proveedores |
| PRY-205 Prevención de lavado de activos | 4 | identidad, plan, 3 hitos, presupuesto, 1 compromiso | autoridad, fase, producto («No aplica»), proveedores, cambios |
| PRY-207 Microcrédito rural | 3 | identidad, plan, 4 hitos, presupuesto, riesgo e incidencia | autoridad, fase, proveedores, cambios |
| PRY-210 Corresponsales rurales | 3 | identidad, plan, presupuesto, CC-01, riesgo e incidencias | autoridad, fase, producto («No aplica»), proveedores, hitos (no hay cronograma) |
| PRY-211 Cobranza digital | 15 | identidad, plan, 4 hitos, presupuesto, 26 compromisos de 6 minutas y las notas, 3 riesgos, 2 incidencias, ficha del gerente (`pm_record`) | autoridad, fase, proveedores, cambios |

### Actualizados
Ninguno. Las fichas de PRY-206, PRY-208 y PRY-209 no se tocaron: sus documentos no cambiaron.

### No pude leer
Ninguno.

### Movidos desde entrada/
Ninguno: la carpeta no tiene `entrada/`.

### Pendientes de clasificar
Ninguno.

### Lo que hay que mirar ya
- **PRY-211 — compromisos.** De 26 compromisos extraídos de las minutas del 09-04 al 10-09 y de las notas del 10-16: 3 cumplidos con acta de recibo, 6 vencidos sin acta y 17 abiertos. Cinco de los vencidos fueron dichos como entregados en una reunión posterior sin que se presentara acta (validar el ambiente 4, aprobar el diseño 5, actualizar la matriz 6, confirmar la fecha 7 y validar el ambiente 20); el sexto, validar el ambiente 12, se repite con la misma fecha (2026-09-22) en cuatro minutas sin cerrarse. «Enviar el documento 1» se ha reprogramado 6 veces (de 2026-09-15 a 2026-11-27) y «Cerrar la prueba 2» 5 veces (de 2026-09-09 a 2026-11-03): es el patrón de un bloqueo que nadie ha nombrado, no de compromisos sueltos. Dos compromisos vencen hoy (matriz 22 y fecha 23) y las notas de hoy no los mencionan.
- **Hitos declarados cerrados sin un acta que lo pruebe:** PRY-200 (5 de 5), PRY-201 (4 de 4), PRY-204 (3 de 4), PRY-205 (2 de 3), PRY-207 (1 de 4). Se registró la declaración del cronograma tal cual; la prueba queda vacía. PRY-199, PRY-202 y PRY-211 sí tienen acta de «Diseño funcional aprobado».
- **PRY-200:** el informe del 2026-09-26 declara verde y 25 % de avance, mientras el cronograma da por cerrado también «Salida a producción» (2026-07-16) y el cierre del acta era 2026-08-24. Ambas facturas (FV-2802, 148.158.298 COP; FV-1395, 207.643.011 COP) están radicadas; el contrato CT-395 no tiene ningún acta de recibo.
- **PRY-202:** la factura FV-1362 (2026-09-08, 49.161.899 COP) está radicada contra un entregable que el contrato da «en curso», con fecha 2026-10-17 y sin acta de recibo.
- **Fechas de cierre ya pasadas:** PRY-201 (2026-08-31, informe en rojo), PRY-210 (2026-10-06, informe en rojo, CC-01 pendiente de presentación al comité) y PRY-200 (2026-08-24). PRY-204 cierra el 2026-10-18 según el acta, pero su cronograma v2 (2026-10-12) mueve el piloto al 2027-01-02 sin declarar motivo ni nueva fecha de cierre; el CC-01 (+115 días) figura autorizado por «el comité» sin decir cuál.
- **PRY-203** tiene una solicitud de cambio pendiente (+78 días, 156.000.000 COP) y **PRY-210** otra (+65 días, 130.000.000 COP); ninguno de los dos tiene cronograma.
- **PRY-205:** un compromiso sin fecha («por definir»).
- **Citas de la ficha del gerente (PRY-211):** `ficha-pm.json` cita sus fuentes relativas a la carpeta del proyecto y no a la raíz de documentación, así que el índice no las puede resolver (35 campos de `pm_record`). No la corregí: es lo que publicó el gerente.
- Todo lo declarado por los gerentes (estado, avance) está marcado como declaración, no como evidencia. El cálculo de señales y contradicciones lo hace el script; esta lectura no lo reemplaza.

### Después
Hay más de un proyecto: puedo preparar el informe consolidado (`/criterio-portfolio:portfolio-report`).

---
**Pie.** criterio-portfolio 0.3.11 · fichas tocadas: 10 (PRY-199, 200, 201, 202, 203, 204, 205, 207, 210, 211) · campos en `not_found`: autoridad y fase en las 10; producto en 3 (202, 205, 210, que dicen «No aplica»); proveedores en 7 (201, 203, 204, 205, 207, 210, 211: sin contrato en la carpeta); cambios en 7 (199, 200, 201, 202, 205, 207, 211); hitos en 2 (203, 210) · Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal
