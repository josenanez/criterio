## RAID — portafolio (13 proyectos, PRY-199 a PRY-211) al 2026-10-16

**De qué documentos sale:** el bloque RAID de las 13 fichas (`estado/records/PRY-*.json`), sus informes de avance, las 13 actas de constitución (sección «Dependencias declaradas») y las actas y notas de reunión de 30-reuniones (PRY-199, 202, 205, 206, 209, 211 y las notas del 2026-10-16 de PRY-211). Los .docx y .pdf se leyeron por su texto extraído, no por el original. No hay minutas de PRY-200, 201, 203, 204, 207, 208 ni 210, así que de esos proyectos solo se leyeron los informes de avance.

**Escala:** el registro no trae probabilidad ni impacto en ningún ítem. No inventé una escala; esas columnas quedan «no registrado».

**Cifras tras clasificar** (el registro actual trae 18 riesgos, 0 supuestos, 16 incidencias, 0 dependencias):
**5 riesgos · 0 supuestos · 16 incidencias · 13 dependencias**, más 1 riesgo detectado en reunión y no registrado formalmente.
**35 de 35 sin doliente** · **35 de 35 sin fecha de gestión** · 0 con probabilidad e impacto · 1 no registrado formalmente.
«Sin movimiento en dos períodos»: no se puede decir. Solo hay una fotografía por proyecto y el «último movimiento» de cada ítem es la fecha del informe donde aparece, no un movimiento verificado.

**Referencias:** los ítems no traen id en la ficha. Las referencias `PRY-xxx/R1` (riesgo), `/I1` (incidencia) y `/D1` (dependencia) las pongo yo, por orden de aparición. No existen en las fuentes.

### Necesitan decisión ahora
| Id | Tipo | Qué | Doliente | Desde | Por qué sube |
|---|---|---|---|---|---|
| Grupo A: PRY-199, 200, 204, 205, 206, 211 /D1 | Dependencia (estaba como riesgo) | «Dependencia del proveedor del core cooperativo» | No registrado | 2026-09-25 (PRY-205) al 2026-10-13 (PRY-211) | Afecta a otros proyectos: está en 6 de 13 informes. Nadie es doliente y ninguna acta de constitución declara dependencias. Falta decidir quién coordina con el proveedor del core y si esto se gestiona una vez para el portafolio. PRY-211 está en Rojo y PRY-199 es de mobiliario, lo que merece una pregunta de por qué lo declara. |
| Grupo B: PRY-202, 208, 209, 210 /D1 | Dependencia (estaba como riesgo) | «Aprobación del reglamento por el Consejo de Administración» | No registrado | 2026-10-04 (PRY-210) al 2026-10-16 (PRY-209) | Es una decisión de un órgano fuera de los proyectos y afecta a 4 proyectos. Además, 5 informes (PRY-199, 200, 205, 206, 210) reportan como incidencia que el Consejo pidió ajustar el reglamento antes del piloto. Falta una sola decisión sobre fecha y responsable ante el Consejo. |
| PRY-211/R3 | Riesgo, no registrado | El proveedor podría no llegar con el equipo completo para la siguiente fase | No registrado | 2026-10-16 | PRY-211 está en Rojo (56 %). Se dijo en reunión y nadie lo anotó. Hay que decidir si se formaliza y quién responde ante el proveedor. |

### Detectados en reuniones, no registrados formalmente
| Qué | Tipo | Dicho en | Fecha |
|---|---|---|---|
| «Se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo» | Riesgo (futuro, incierto). También es una dependencia del proveedor. | `PRY-211-cobranza-digital/2026-10-16-notas-reunion.txt` | 2026-10-16 |

Lo que ya aparece en la ficha de PRY-211 como riesgo (PRY-211/R3) viene de esta misma nota. Revisé las otras 10 actas y notas y no encontré otros riesgos, supuestos ni dependencias dichos al pasar. Esas actas solo traen compromisos. No inventé ninguno. Las notas del 2026-10-16 mencionan además «revisión con el proveedor, queda para el 2026-10-26» (Óscar Ramírez), que es un compromiso y no un riesgo. Va a seguimiento de compromisos.

### Reclasificados (el registro los traía como riesgo)
| Texto en el registro | Proyectos | Pasa a | Por qué (prueba rápida) |
|---|---|---|---|
| Dependencia del proveedor del core cooperativo | 199, 200, 204, 205, 206, 211 | Dependencia | Depende de alguien fuera del proyecto. Ya se llama dependencia en el propio texto. |
| Aprobación del reglamento por el Consejo de Administración | 202, 208, 209, 210 | Dependencia | Depende de una decisión del Consejo, fuera del proyecto. |
| El proveedor no ha confirmado la fecha de la última entrega | 200, 201, 208 | Dependencia | Depende de un tercero y está sin confirmar. |

Se quedan como riesgo: «Concentración del conocimiento en una sola persona» (PRY-203, 206, 207) y «Cambio normativo del supervisor que puede mover el alcance» (PRY-203, 211).

Dudosas sin reclasificar: «Se ajustó el plan de pruebas con el área de seguridad» (PRY-202, 204) está registrada como incidencia, pero describe un ajuste hecho y no dice qué daño causa. Si no afecta el plan, no es incidencia. Lo dejo donde está y se lo señalo a quien lo revise.

### Sin doliente o sin fecha
No rellené nada. Todos los ítems están en esta situación:
| Id | Tipo | Qué | Qué falta |
|---|---|---|---|
| 5 riesgos (PRY-203/R1-R2, 206/R2, 207/R1, 211/R2) y PRY-211/R3 | Riesgo | Ver registro completo | Doliente, fecha, probabilidad, impacto |
| 13 dependencias reclasificadas | Dependencia | Ver registro completo | Doliente, fecha, proyecto o actor del que depende, confirmación de la contraparte |
| 16 incidencias | Incidencia | Ver registro completo | Doliente y fecha de resolución. Sí traen fecha de inicio. |

Supuestos: ninguno registrado ni dicho en los documentos leídos. Los que más fallan (persona clave, ambiente o licencia listo, aprobación que sea trámite, equipo completo) aparecen de hecho como incidencias o dependencias. Por ejemplo, la rotación de un desarrollador clave en PRY-199, 210 y 211. No levanto supuestos que nadie dijo.

### Dependencias en riesgo
| Id | Depende de | Confirmada | Qué pasó |
|---|---|---|---|
| Grupo A (6 proyectos) /D1 | «Proveedor del core cooperativo», sin código de proyecto | No | No se puede cruzar. Las actas dicen «Ninguna declarada» y el texto no trae código. PRY-202 se llama «Core cooperativo» y su contrato CT-362 es con Integración Financiera del Sur, pero ningún documento dice que el proveedor del core de los seis proyectos sea ese ni que dependan de PRY-202. Es una hipótesis para confirmar con los gerentes. No la doy por hecha. |
| Grupo B (4 proyectos) /D1 | Consejo de Administración, órgano externo | No | PRY-209 reporta el riesgo con fecha 2026-10-16 y su cronograma v2 es del mismo día. Los informes no dicen si el Consejo movió su fecha. |
| PRY-200, 201, 208 /D | Proveedor de la última entrega | No: «no ha confirmado la fecha» | Declarada, no acordada. |

Cruce por fechas movidas: PRY-204, 208 y 209 tienen cronograma v2, pero sin una dependencia con código de proyecto no hay contra qué contrastar. Así que hoy no se puede afirmar que ninguna dependencia esté en riesgo por una fecha movida. Tampoco se puede afirmar lo contrario.

### Registro completo
Prob., Impacto, Doliente y Fecha de gestión: «no registrado» en todas las filas. «Último mov.» es la fecha del informe fuente.

| Ref. | Tipo | Qué | Proyecto | Último mov. |
|---|---|---|---|---|
| 199/D1 | Dependencia | Proveedor del core cooperativo | PRY-199 | 2026-10-14 |
| 199/I1 | Incidencia | El Consejo pidió ajustar el reglamento antes del piloto | PRY-199 | 2026-10-14 |
| 199/I2 | Incidencia | Dos semanas perdidas por rotación de un desarrollador clave | PRY-199 | 2026-10-14 |
| 200/D1 | Dependencia | Proveedor no ha confirmado la fecha de la última entrega | PRY-200 | 2026-09-26 |
| 200/D2 | Dependencia | Proveedor del core cooperativo | PRY-200 | 2026-09-26 |
| 200/I1 | Incidencia | Salida reprogramada por el cierre contable de fin de mes | PRY-200 | 2026-09-26 |
| 200/I2 | Incidencia | El Consejo pidió ajustar el reglamento antes del piloto | PRY-200 | 2026-09-26 |
| 201/D1 | Dependencia | Proveedor no ha confirmado la fecha de la última entrega | PRY-201 | 2026-10-11 |
| 201/I1 | Incidencia | Hallazgo de seguridad en la revisión de arquitectura | PRY-201 | 2026-10-11 |
| 202/D1 | Dependencia | Aprobación del reglamento por el Consejo | PRY-202 | 2026-10-07 |
| 202/I1 | Incidencia (dudosa) | Se ajustó el plan de pruebas con el área de seguridad | PRY-202 | 2026-10-07 |
| 203/R1 | Riesgo | Concentración del conocimiento en una sola persona | PRY-203 | 2026-10-05 |
| 203/R2 | Riesgo | Cambio normativo del supervisor que puede mover el alcance | PRY-203 | 2026-10-05 |
| 203/I1 | Incidencia | Hallazgo de seguridad en la revisión de arquitectura | PRY-203 | 2026-10-05 |
| 204/D1 | Dependencia | Proveedor del core cooperativo | PRY-204 | 2026-10-12 |
| 204/I1 | Incidencia (dudosa) | Se ajustó el plan de pruebas con el área de seguridad | PRY-204 | 2026-10-12 |
| 205/D1 | Dependencia | Proveedor del core cooperativo | PRY-205 | 2026-09-25 |
| 205/I1 | Incidencia | El Consejo pidió ajustar el reglamento antes del piloto | PRY-205 | 2026-09-25 |
| 206/D1 | Dependencia | Proveedor del core cooperativo | PRY-206 | 2026-10-13 |
| 206/R1 | Riesgo | Concentración del conocimiento en una sola persona | PRY-206 | 2026-10-13 |
| 206/I1 | Incidencia | La prueba de carga no alcanzó el umbral y se repite | PRY-206 | 2026-10-13 |
| 206/I2 | Incidencia | El Consejo pidió ajustar el reglamento antes del piloto | PRY-206 | 2026-10-13 |
| 207/R1 | Riesgo | Concentración del conocimiento en una sola persona | PRY-207 | 2026-09-28 |
| 207/I1 | Incidencia | La prueba de carga no alcanzó el umbral y se repite | PRY-207 | 2026-09-28 |
| 208/D1 | Dependencia | Proveedor no ha confirmado la fecha de la última entrega | PRY-208 | 2026-10-09 |
| 208/D2 | Dependencia | Aprobación del reglamento por el Consejo | PRY-208 | 2026-10-09 |
| 209/D1 | Dependencia | Aprobación del reglamento por el Consejo | PRY-209 | 2026-10-16 |
| 210/D1 | Dependencia | Aprobación del reglamento por el Consejo | PRY-210 | 2026-10-04 |
| 210/I1 | Incidencia | El Consejo pidió ajustar el reglamento antes del piloto | PRY-210 | 2026-10-04 |
| 210/I2 | Incidencia | Dos semanas perdidas por rotación de un desarrollador clave | PRY-210 | 2026-10-04 |
| 211/D1 | Dependencia | Proveedor del core cooperativo | PRY-211 | 2026-10-13 |
| 211/R2 | Riesgo | Cambio normativo del supervisor que puede mover el alcance | PRY-211 | 2026-10-13 |
| 211/R3 | Riesgo, no registrado formalmente | El proveedor podría no llegar con el equipo completo para la siguiente fase | PRY-211 | 2026-10-16 |
| 211/I1 | Incidencia | Hallazgo de seguridad en la revisión de arquitectura | PRY-211 | 2026-10-13 |
| 211/I2 | Incidencia | Dos semanas perdidas por rotación de un desarrollador clave | PRY-211 | 2026-10-13 |

(Las referencias de dependencia y de riesgo se numeran por proyecto en orden de aparición.)

**Una observación sobre el registro.** El mismo texto aparece idéntico en proyectos que no tienen nada que ver entre sí («Dependencia del proveedor del core cooperativo» en mobiliario, cobranza y tarjeta débito, por ejemplo). No sé si es una dependencia real compartida o una plantilla copiada. Habría que preguntárselo a los gerentes antes de escalar el Grupo A.

### Después
- **Subir a comité** (próximo, 2026-10-23): Grupo A, Grupo B y PRY-211/R3, cada uno con la decisión formulada. Grupo A: quién coordina con el proveedor del core para los seis proyectos. Grupo B: fecha del Consejo y quién la lleva. PRY-211/R3: formalizar o no, y con quién del proveedor se habla. La decisión es del comité. No la tomo yo.
- **Doliente:** propongo, no asigno. Para Grupo B, el gerente de PRY-202 (Andrés Lozano, según su informe de avance), o la PMO. Ningún documento dice quién lleva el reglamento ante el Consejo. Para PRY-211/R3, Ricardo Salas, gerente de PRY-211. Para Grupo A, nadie se puede proponer con los documentos: no consta quién maneja al proveedor del core. Son sugerencias para que el comité las confirme.
- **Pendiente de los gerentes:** probabilidad e impacto de los 6 riesgos; confirmar si el «proveedor del core» es el de PRY-202; confirmar con el Consejo la fecha de aprobación del reglamento.

---
*Rigor:* lo leído son borradores de trabajo con cita al documento; la verificación es suya. La clasificación sigue la prueba rápida de raid-taxonomy y la apliqué a lo que dice el texto, no a lo que el gerente declara. No sé lo que se habló fuera de estos documentos. No hay historial de movimiento de los ítems, no hay escala de valoración de la organización, y los PDF y DOCX se leyeron por texto extraído.
