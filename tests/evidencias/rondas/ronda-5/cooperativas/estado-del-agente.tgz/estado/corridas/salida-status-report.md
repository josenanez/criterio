Sale de la ficha `estado/records/PRY-200.json` (actualizada el 2026-10-16), recalculada con `portafolio.py compute` al 2026-10-16. Términos vigentes: v1.1, aceptados por José Francisco Ñáñez el 2026-10-16.

## PRY-200 · Crédito de libranza digital — estado al 2026-10-16

**Declara el gerente (Ricardo Salas):** verde · 25% · al 2026-09-26 (20 días de antigüedad; no está vencida: el umbral es 30)
**Sustento documental:** contradicho. La ficha tiene 0 datos marcados como evidencia, 3 como declaración y 71 sin marcar.
**Lo que el semáforo no explica:** `milestone_met_without_evidence` (5 hitos), `progress_vs_plan`, `silent`, `vendor_deliverable_late` (5 entregables), `vendor_invoiced_without_delivery`
**Último documento:** 2026-09-26 (20 días de silencio; umbral 15) · **Última reunión:** sin dato; la ficha no registra ninguna.

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2026-07-16 | 2026-07-16 | 0 días contra la original y contra la vigente |
| Presupuesto (COP) | 2.400.000.000 aprobado | proyección 2.452.918.540 | +2,2% sobre lo aprobado |

Replanificaciones: 0. La ficha no trae ninguna fecha ni motivo de replanificación. Pero ver «Dónde no coincide»: el informe del 26 de septiembre habla de una salida reprogramada.

Dinero (COP): comprometido 922.156.949 (38,4%), ejecutado 1.111.419.946 (46,3%), disponible real 1.477.843.051. El ejecutado supera al comprometido en la ficha; los documentos no explican por qué.

La fecha de cierre ya pasó (2026-07-16), y la ficha no tiene una fecha vigente posterior.

### Hitos
Los cinco aparecen como «cumplido» en el cronograma v1, fechado el 2025-06-15. Es anterior a todos los hitos, y ninguno tiene evidencia de cumplimiento.

| Hito | Base | Vigente | Estado | Evidencia |
|---|---|---|---|---|
| Diseño funcional aprobado | 2025-09-10 | 2025-09-10 | cumplido (declarado) | sin dato · 401 días de vencido |
| Ambiente de pruebas certificado | 2025-11-26 | 2025-11-26 | cumplido (declarado) | sin dato · 324 días |
| Integración con el core cooperativo | 2026-02-11 | 2026-02-11 | cumplido (declarado) | sin dato · 247 días |
| Piloto con asociados | 2026-04-30 | 2026-04-30 | cumplido (declarado) | sin dato · 169 días |
| Salida a producción | 2026-07-16 | 2026-07-16 | cumplido (declarado) | sin dato · 92 días |

### Dónde no coincide
- **Avance:** el gerente declara 25% (informe de avance, 2026-09-26). El plan, con 5 de 5 hitos en «cumplido», sostiene 100%. La diferencia es de 75 puntos, y los dos datos no pueden ser ciertos a la vez. Falta saber cuál de los dos está mal.
- **Semáforo:** verde (informe de avance, 2026-09-26) frente a las cinco señales de arriba, ninguna cubierta por ese verde.
- **Salida a producción:** el cronograma la da por cumplida con fecha 2026-07-16 y sin replanificaciones. La incidencia registrada en el informe del 2026-09-26 dice «Se reprogramó la salida por el cierre contable de fin de mes». Una de las dos fuentes está equivocada.
- **Proveedores:**
  - Soluciones Solidarias S.A.S. (CT-395): 0 de 4 entregables aceptados, los 4 vencidos (138 a 393 días) y sin evidencia de recibo. La factura del 2026-09-06 es por 207.643.011 COP. Es una factura sin entrega que la respalde.
  - Talento Solidario Ltda. (CT-802): 1 de 2 entregables aceptado, con acta de recibo del 2025-12-01 y factura del 2026-09-03 por 148.158.298 COP, igual al monto aceptado. La «Bolsa de horas de desarrollo» (vence 2026-04-04) sigue pendiente, 195 días.

### Abierto
**Riesgos e incidencias sin movimiento:** los cuatro se movieron por última vez el 2026-09-26, hace 20 días, por encima del umbral de 15. Ninguno tiene responsable.
- Riesgo: el proveedor no ha confirmado la fecha de la última entrega. Sin probabilidad, impacto, responsable ni fecha.
- Riesgo: dependencia del proveedor del core cooperativo. Sin probabilidad, impacto, responsable ni fecha.
- Incidencia: se reprogramó la salida por el cierre contable de fin de mes. Sin responsable.
- Incidencia: el Consejo de Administración pidió ajustar el reglamento antes del piloto. Sin responsable.

**Compromisos vencidos:** ninguno. La ficha no registra compromisos; eso no es lo mismo que no haberlos.
**Dependencias sin confirmar:** ninguna registrada. El riesgo de dependencia del core cooperativo no está registrado como dependencia de otro proyecto.

### Sin dato
- Autoridad del proyecto y fase.
- Evidencia de los 5 hitos y de 5 entregables de proveedores.
- Probabilidad, impacto, responsable y fecha de los 2 riesgos; responsable de las 2 incidencias.
- Última reunión y cambios formales (`changes` vacío).
- Los campos de identidad, plan y proveedores vienen de documentos de junio de 2025, con 16 meses (umbral: 12), es decir, vencidos.

### Siguiente paso
Hay señales por encima del umbral y un proveedor facturado sin entrega. Puedo preparar el punto para el comité del 2026-10-23 (`/steering-pack`). La reprogramación de la salida, si es real, no tiene solicitud de cambio: puedo preparar esa solicitud.

---
Criterio Portfolio v0.3.11 · ficha PRY-200 aplicada, actualizada el 2026-10-16, con cálculo al 2026-10-16 · campos inciertos: los listados en «Sin dato», más los campos vencidos por antigüedad · Términos v1.1: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.11
