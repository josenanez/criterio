# Corrida del 2026-10-16 · project-closure

13 proyectos · 63 s · 66 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `commitment_overdue` | 9 |
| `progress_vs_plan` | 7 |
| `declared_vs_evidence` | 7 |
| `vendor_deliverable_late` | 5 |
| `variance_cost` | 4 |
| `commitment_undated` | 3 |
| `silent` | 2 |
| `vendor_invoiced_without_delivery` | 2 |
| `variance_time` | 2 |
| `commitment_rescheduled` | 2 |
| `change_without_baseline` | 1 |
| `rebaseline_unauthorized` | 1 |
| `pm_vs_pmo` | 1 |

Acta de cierre de PRY-200: no cerrable por cumplimiento; criterio de éxito sin verificar, 5 hitos cerrados sin evidencia, CT-395 facturado sin entregables aceptados. Dijo que no sabía: si hay producción, si se hizo el piloto, fecha de cierre válida (2026-07-16 vs 2026-08-24), por qué ejecutado supera comprometido, doliente del RAID.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

**Fuente:** ficha `estado/records/PRY-200.json` y estos documentos de `documentos/proyectos/PRY-200-crédito-de-libranza-digital/`: acta de constitución (2025-06-15), contratos CT-802 y CT-395, cronograma v1, acta de recibo CT-802 (2025-12-01), facturas FV-2802 y FV-1395, informe de avance (2026-09-26). Cifras de `portafolio.py compute` con corte 2026-10-16. Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-16); no se registraron de nuevo.

## Cierre — PRY-200 Crédito de libranza digital — 2026-10-16

**Veredicto: este proyecto no se puede cerrar por cumplimiento. Hoy solo podría cerrarse por decisión, y esa decisión la tiene que tomar el Comité de Crédito.** Ningún documento sostiene que el criterio de éxito se haya cumplido. El único informe de avance dice verde con 25 % de avance, y su propio gerente no declara el proyecto terminado.

### Contra lo comprometido
**Criterio de éxito:** "Crédito de libranza digital en producción y medido." (acta de constitución, 2025-06-15).
**Se cumplió:** no se puede determinar. No hay un solo documento que muestre producción ni medición.

| Entregable comprometido | Estado | Evidencia |
|---|---|---|
| Hito: Diseño funcional aprobado (2025-09-10) | El cronograma dice "cerrado" | Ninguna |
| Hito: Ambiente de pruebas certificado (2025-11-26) | El cronograma dice "cerrado" | Ninguna |
| Hito: Integración con el core cooperativo (2026-02-11) | El cronograma dice "cerrado" | Ninguna |
| Hito: Piloto con asociados (2026-04-30) | El cronograma dice "cerrado". El informe del 2026-09-26 dice que el Consejo pidió ajustar el reglamento *antes del piloto*. | Ninguna, y contradicho por el informe |
| Hito: Salida a producción (2026-07-16) | El cronograma dice "cerrado". El informe del 2026-09-26 dice que se reprogramó la salida. | Ninguna, y contradicho por el informe |
| CT-802 · Licenciamiento del módulo (Talento Solidario, 2025-11-13) | Recibido | Acta de recibo 2025-12-01, firmada por Ricardo Salas |
| CT-802 · Bolsa de horas de desarrollo (2026-04-04) | Pendiente, vencido hace 195 días | Ninguna |
| CT-395 · Licenciamiento del módulo (Soluciones Solidarias, 2025-09-18) | Pendiente, vencido hace 393 días | Ninguna |
| CT-395 · Bolsa de horas de desarrollo (2025-12-12) | Pendiente, vencido hace 308 días | Ninguna |
| CT-395 · Parametrización de líneas de crédito (2026-03-07) | Pendiente, vencido hace 223 días | Ninguna |
| CT-395 · Mesa de ayuda del primer trimestre (2026-05-31) | Pendiente, vencido hace 138 días | Ninguna |

El cronograma v1 es de 2025-06-15 y nadie lo ha tocado desde entonces. Marca los cinco hitos como cerrados, pero ninguno tiene acta, certificación ni otro documento que lo respalde. Las 5 señales de "hito cumplido sin evidencia" salen de ahí. El avance declarado (25 %) contra lo que el plan sostiene (100 %) deja una brecha de 75.0 puntos.

### Fuera de alcance final
| Qué quedó fuera | Decidido por | Cuándo |
|---|---|---|
| Ninguna decisión de recorte registrada (no hay solicitudes de cambio, 0 cambios en la ficha). | — | — |
| El acta excluye solo "lo que otro proyecto cubre", sin especificar qué. | Acta de constitución | 2025-06-15 |

Del alcance ("Componente 1; Componente 2; Componente 3") no se sabe qué se entregó, porque los componentes no tienen nombre ni vínculo con los hitos. Esa brecha es un hallazgo.

### Números finales
| | Original | Vigente | Final | Desviación vs original |
|---|---|---|---|---|
| Fecha de cierre (cronograma) | 2026-07-16 | 2026-07-16 | No hay fecha real de fin | 0 días contra la línea base. No es fiable, porque la línea base nunca se movió aunque el informe habla de una salida reprogramada. |
| Fecha de cierre (acta de constitución) | 2026-08-24 | — | — | El acta y el cronograma no coinciden en la fecha de cierre. No hay documento que explique la diferencia. |
| Presupuesto aprobado | 2.400.000.000 COP | 2.400.000.000 COP | — | — |
| Ejecutado | — | — | 1.111.419.946 COP (46.3 % del aprobado) | — |
| Comprometido | — | — | 922.156.949 COP (38.4 %) | — |
| Proyección al cierre | — | — | 2.452.918.540 COP | 2.2 % por encima del aprobado |

Replanificaciones: 0.

Cifras que no cuadran:
- El ejecutado (1.111.419.946) es mayor que el comprometido (922.156.949). Ningún documento lo explica.
- Hay dos facturas radicadas en cuentas por pagar: FV-2802 por 148.158.298 COP (CT-802) y FV-1395 por 207.643.011 COP (CT-395).
- **Facturado sin entrega:** a Soluciones Solidarias (CT-395) se le facturó 207.643.011 COP, con 0 de 4 entregables aceptados y ninguna acta de recibo.
- La factura de Talento Solidario (CT-802) es por 148.158.298 COP, el monto del único entregable con acta (el licenciamiento). Su concepto dice "entregables del contrato" sin especificar cuál; el monto cuadra con el aceptado.

### RAID al cierre
**Materializados:**
- La salida se reprogramó "por el cierre contable de fin de mes" (informe 2026-09-26). No hay fecha nueva ni cambio aprobado.
- El Consejo de Administración pidió ajustar el reglamento antes del piloto (mismo informe). No hay solicitud de cambio.
- Vencimientos de proveedor: CT-802 tiene 1 entregable vencido y CT-395 tiene 4.

**No materializados:** no se puede determinar. Ningún riesgo tiene probabilidad, impacto ni fecha.

**Abiertos, con doliente:** ninguno tiene doliente con nombre. Por tanto, **no están cerrados**.
- Riesgo: "El proveedor no ha confirmado la fecha de la última entrega". Sin responsable.
- Riesgo: "Dependencia del proveedor del core cooperativo". Sin responsable. El acta de constitución declara "ninguna dependencia", así que esta no estaba prevista.
- Incidencia: reprogramación de la salida. Sin responsable.
- Incidencia: ajuste del reglamento pedido por el Consejo. Sin responsable.
- Los 5 entregables vencidos de proveedor y las 2 facturas radicadas sin acta no figuran en el RAID.

### Lecciones
Solo entran las que se pueden anclar a un hecho documentado.

| Qué pasó | Cuándo | Efecto | Qué haríamos distinto |
|---|---|---|---|
| Se radicó la factura FV-1395 de CT-395 (207.643.011 COP) con 0 de 4 entregables aceptados y el más antiguo vencido desde 2025-09-18. | 2026-09-06 | Factura radicada sin acta de recibo. La condición de pago de CT-802 exige acta firmada; del contrato CT-395 no se verificó una condición equivalente. | No radicar facturas sin acta de recibo firmada. Verificarlo antes de aprobar el pago. |
| El cronograma v1 (2025-06-15) marca los 5 hitos como "cerrado" sin evidencia, y el informe del 2026-09-26 contradice dos de ellos (piloto y salida). | Cronograma 2025-06-15, informe 2026-09-26 | El 25 % declarado y el 100 % del plan no se pueden conciliar. Hay una brecha de 75.0 puntos. | Cada hito cerrado necesita un documento citable. Sin él no se marca como cumplido. |
| El informe declara "verde" mientras dice que la salida se reprogramó y hay 5 entregables vencidos. | 2026-09-26 | El color no refleja el estado del proyecto. | Un verde se sostiene con evidencia, no con el color declarado. |

No se escribe ninguna lección sobre causas (por qué se atrasaron los proveedores, por qué se pidió el ajuste del reglamento), porque ningún documento lo dice.

### Sin dato
- Si el producto está en producción y se mide. Es el criterio de éxito y no hay evidencia en ningún sentido.
- Si el piloto se hizo. El cronograma dice que sí y el informe sugiere que no.
- Qué son los Componentes 1, 2 y 3 del alcance y cuál se entregó.
- Cuál es la fecha de cierre válida (2026-07-16 o 2026-08-24).
- Por qué el ejecutado supera al comprometido.
- Qué cubren las facturas y si hay actas de recibo (solo hay una acta de recibo en todo el proyecto).
- Quién responde por los 4 ítems abiertos del RAID.
- Autoridad de aprobación y fase del proyecto: no están en la documentación.
- Ningún dato tiene como fuente un documento de evidencia: 0 evidencia, 3 declaraciones y 71 sin marcar, todos con 16 meses de antigüedad en los campos de gobierno y plan.
- El proyecto lleva 20 días en silencio (último informe 2026-09-26; el umbral es 15).

### Para que el cierre sea posible
1. Ricardo Salas aporta evidencia de cada hito, o corrige el cronograma.
2. El Comité de Crédito decide: o cierra por decisión, dejando constancia de que el criterio no se verificó, o lo mantiene abierto.
3. Quien apruebe pagos revisa FV-1395 (sin acta de recibo) antes de pagarla.
4. Se nombra un doliente para cada ítem abierto del RAID.

### Después
Mover la carpeta a `archivo/` y congelar la ficha **no se hizo y no se recomienda ahora**: el proyecto no cumple las condiciones de cierre, tiene pagos pendientes y RAID sin doliente. Si el comité decide cerrarlo por decisión, se archiva con esta acta como constancia.

*Pie de rigor: borrador de trabajo de Criterio, no decisión ni asesoría. Cada dato sale de los documentos citados arriba. La verificación es de quien lo lee.*
