# Corrida del 2026-10-16 · health-check

13 proyectos · 69 s · 66 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `commitment_overdue` | 9 |
| `progress_vs_plan` | 7 |
| `declared_vs_evidence` | 7 |
| `vendor_deliverable_late` | 5 |
| `variance_cost` | 4 |
| `commitment_undated` | 3 |
| `silent` | 2 |
| `vendor_invoiced_without_delivery` | 2 |
| `variance_time` | 2 |
| `commitment_rescheduled` | 2 |
| `change_without_baseline` | 1 |
| `rebaseline_unauthorized` | 1 |
| `pm_vs_pmo` | 1 |

Diagnóstico de PRY-204 desde 6 documentos: dictamen 4 sostenidas, 6 sin sustento, 5 contradichas. Declarado verde contra proyección +14.0 %, 115 días de desviación, 3 hitos sin acta y CC-01 sin acta de comité. Dijo que no sabe: alcance real, autorización del desvío, gasto efectivo, motivo del movimiento del piloto.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

## Diagnóstico · PRY-204 Tarjeta débito para asociados · 2026-10-16

**Leí:** 6 documentos · de 2025-10-24 a 2026-10-15 · formatos: md (2), pdf (2), xlsx (1), csv (1). Además busqué el código y «tarjeta» en los textos de los otros 12 proyectos del portafolio: ninguna otra minuta ni documento menciona a PRY-204.
**No pude leer:** nada quedó sin leer. El xlsx (cronograma v1) lo leí por su conversión a texto en el caché, no abriendo el binario; las citas apuntan al original.

Términos: vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-16), no hizo falta registrarlos de nuevo.

### Dictamen
**Sostenido:** 4 afirmaciones · **Sin sustento:** 6 · **Contradicho:** 5 (15 en total, listadas abajo)

La carpeta permite afirmar quién gobierna el proyecto, cuánto se aprobó y que el piloto tiene acta de recibo. No permite afirmar que el proyecto esté en verde: el propio informe del gerente declara verde con una proyección 14.0 % sobre el presupuesto aprobado y un plan que ya se movió 115 días contra la línea base original. Tres de los cuatro hitos «cerrados» no tienen ningún documento de recibo, y la solicitud de cambio que justifica el desvío dice «autorizada por el comité» sin que exista acta de comité. Quien evalúa el proyecto no tiene hoy un documento independiente del gerente que sustente el avance.

Afirmaciones dictaminadas:
- Sostenidas (4): presupuesto aprobado 18.000.000.000 COP (acta e informe coinciden); patrocinador, gerente y comité nombrados en el acta; piloto con asociados recibido (acta del 2026-10-15); +115 días de CC-01 (coincide con el cronograma v2: del 2026-09-09 al 2027-01-02).
- Sin sustento (6): Diseño funcional aprobado «cerrado»; Ambiente de pruebas certificado «cerrado»; Integración con el core «cerrada»; comprometido y ejecutado (no hay contrato, factura ni acta de proveedor en la carpeta); proyección al cierre; «autorizada por el comité» de CC-01.
- Contradichas (5): estado «verde»; avance 83 %; fecha vigente del piloto (2027-01-02 en el cronograma v2, pero recibido el 2026-10-15); «Dependencias: ninguna» frente al riesgo abierto «dependencia del proveedor del core»; cierre comprometido 2026-10-18 frente a un plan v2 con un hito en 2027-01-02.

### Gobierno
| | Qué dice el documento | Fuente |
|---|---|---|
| Patrocinador | Ricardo Salas | 00-gobierno/2025-10-24-acta-constitucion.md |
| Gerente | Diana Molina | 00-gobierno/2025-10-24-acta-constitucion.md |
| Autoridad declarada | **No declarada.** El acta no dice qué puede aprobar el gerente ni hasta qué monto o días | 00-gobierno/2025-10-24-acta-constitucion.md |
| Comité | Comité de Riesgos (aprobó el presupuesto el 2025-10-24). No hay ninguna minuta suya en la carpeta | 00-gobierno/2025-10-24-acta-constitucion.md |

Más: el alcance del acta son tres líneas «Componente 1, 2, 3» y el fuera de alcance es «Lo que otro proyecto cubre»; el alcance no está definido, así que «ampliación de alcance» (CC-01) no tiene contra qué medirse. Sin autoridad declarada no hay desviación aprobada: hay fechas que alguien escribió.

### Contra el plan
- **Línea base original (v1, 2025-10-24):** último hito, Piloto con asociados, 2026-09-09; cierre del acta 2026-10-18. (10-plan/2025-10-24-cronograma-v1.xlsx; 00-gobierno/…acta-constitucion.md)
- **Vigente (v2, 2026-10-12):** el Piloto pasa a 2027-01-02. El documento no declara motivo ni nueva fecha de cierre. (10-plan/2026-10-12-cronograma-v2.csv)
- **Replanificaciones:** 1. Desviación contra la original: 115 días (37.1 %). Contra la vigente: 0 días.
- **CC-01 (2026-10-13):** «Ampliación de alcance», +115 días y +230.000.000 COP, «Autorizada por el comité», sin fecha de autorización ni acta. El cronograma v2 es del 2026-10-12, un día antes de la solicitud que lo justifica. La línea base nueva queda sin documento de aprobación.
- **Contradicción interna del plan v2:** marca el piloto como «cerrado» con fecha vigente 2027-01-02, es decir futura, y el acta de recibo es del 2026-10-15.

### Hitos vencidos sin evidencia
Los cuatro hitos figuran «cerrados» en el cronograma. Tres no tienen documento de recibo.

| Hito | Fecha | Días desde la fecha | Qué documento se esperaría |
|---|---|---|---|
| Diseño funcional aprobado | 2026-01-19 | 270 | Acta de recibo / aprobación del diseño funcional |
| Ambiente de pruebas certificado | 2026-04-07 | 192 | Certificado o acta de recibo del ambiente de pruebas |
| Integración con el core cooperativo | 2026-06-23 | 115 | Acta de recibo o pruebas de integración con el proveedor del core |

El cuarto hito, Piloto con asociados (base 2026-09-09), tiene acta de recibo del 2026-10-15, firmada solo por la gerente («Recibido por: Diana Molina»), sin resultados del piloto ni aceptación del patrocinador o de Tesorería.

### Dinero
| Aprobado | Comprometido | Ejecutado | Proyección | Disponible real |
|---|---|---|---|---|
| 18.000.000.000 | 12.906.403.597 (71.7 %) | 4.779.778.113 (26.6 %) | 20.519.654.277 (14.0 % sobre lo aprobado) | 5.093.596.403 |

COP. Cifras del informe de avance del 2026-10-12 (declaración del gerente); el cálculo de porcentajes y del disponible es del script. Ningún documento de la carpeta (contrato, factura, acta de proveedor) las respalda. CC-01 pide 230.000.000 COP adicionales, pero ningún documento muestra un presupuesto aprobado modificado, y el script no da una cifra que reconcilie ese monto con la proyección; no la escribo.

### Lo que se dijo y nadie registró
No hay minutas del proyecto, así que no puedo extraer compromisos ni riesgos dichos en reunión. Lo registrado vs. lo que otros documentos implican:
- Riesgo «Dependencia del proveedor del core cooperativo» (informe 2026-10-12): sin probabilidad, impacto, responsable ni fecha. El acta dice «Dependencias: ninguna declarada».
- Incidencia implícita: un hito movido 115 días sin motivo escrito.
- Supuesto sin registrar: que el comité autorizó CC-01.
- Compromisos: ninguno con responsable y fecha en la carpeta.

### Contradicho
| Afirmación | Documento A | Documento B |
|---|---|---|
| Estado verde | Informe 2026-10-12: «Verde» | Mismo informe: proyección 20.519.654.277 vs aprobado 18.000.000.000 (14.0 %); cronograma v2: +115 días (37.1 %) |
| Avance 83 % | Informe 2026-10-12: 83 % | Cronograma: 4 de 4 hitos «cerrados» (el plan sostendría 100 %); brecha de 17.0 puntos |
| Piloto: fecha vigente 2027-01-02 y «cerrado» | Cronograma v2 (2026-10-12) | Acta de recibo del piloto, 2026-10-15 |
| Dependencias: ninguna | Acta de constitución | Informe 2026-10-12: riesgo abierto de dependencia del proveedor del core; hito «Integración con el core cooperativo» |
| Cierre 2026-10-18 | Acta de constitución | Cronograma v2: Piloto 2027-01-02, y el informe no menciona el cambio |

El informe del 2026-10-12 no menciona ni el movimiento del piloto ni CC-01, que son de las mismas fechas (10-12 y 10-13).

### Sin sustento
- Los tres hitos «cerrados» sin acta (arriba).
- Comprometido y ejecutado: no hay contratos, facturas ni actas de proveedor; 12.906.403.597 comprometidos no tienen un solo contrato en la carpeta.
- La proyección de 20.519.654.277: ningún documento muestra cómo se calculó.
- «Autorizada por el comité» de CC-01: sin acta, sin fecha, sin firmante.
- «83 %» como medida de avance: el informe no dice cómo se mide.
- Criterio de éxito («en producción y medido»): ningún documento muestra producción ni medición.

### Lo que esta carpeta no permite saber
- **Si el diseño, el ambiente de pruebas y la integración se entregaron.** Sin actas, 3 de los 4 hitos son solo una palabra en un cronograma: no se puede decir cuánto avance real hay.
- **Qué se amplió en el alcance.** El acta no define el alcance y CC-01 no lo describe: no se puede evaluar si 115 días y 230.000.000 COP son razonables.
- **Quién autorizó el desvío.** Sin autoridad declarada ni acta de comité, no se puede afirmar que el nuevo plan sea una línea base aprobada.
- **En qué se ha gastado el dinero.** Sin contratos ni facturas, el comprometido y el ejecutado son una declaración.
- **Por qué se movió el piloto**, y cuál es la fecha real de cierre.
- **Si el piloto funcionó.** El acta solo dice «se recibe a satisfacción».

Debajo de todo esto, el dictamen es que **esta carpeta no permite diagnosticar el proyecto como verde**: permite diagnosticar que su estado declarado no está sustentado. No recomiendo detener, continuar ni reestructurar; eso lo decide quien tiene la facultad.

Puedo preparar el punto de comité con la lista de lo que falta (actas de los 3 hitos, acta del comité que autorizó CC-01, contratos y facturas, descripción del alcance ampliado, motivo del movimiento del piloto), y llevarle a la gerente las cinco contradicciones como preguntas, una por una.

---
**Pie de rigor:** las cifras derivadas (días, porcentajes, disponible, brecha) salen de `portafolio.py compute` del 2026-10-16; las demás son transcripción de los documentos citados. Lo declarado por el gerente (informe de avance) y lo probado por documentos de recibo se han mantenido separados: de lo declarado, lo probado es el piloto y nada más. Criterio produce borradores de trabajo; la verificación es de quien lee.
