# Corrida del 2026-10-16 · product-view

13 proyectos · 24 s · 66 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `commitment_overdue` | 9 |
| `progress_vs_plan` | 7 |
| `declared_vs_evidence` | 7 |
| `vendor_deliverable_late` | 5 |
| `variance_cost` | 4 |
| `commitment_undated` | 3 |
| `silent` | 2 |
| `vendor_invoiced_without_delivery` | 2 |
| `variance_time` | 2 |
| `commitment_rescheduled` | 2 |
| `change_without_baseline` | 1 |
| `rebaseline_unauthorized` | 1 |
| `pm_vs_pmo` | 1 |

Producto con un solo proyecto (PRY-201): sin sección de producto, 5 alertas reportadas. Reporté 5 proyectos sin producto. No supe: el área dueña de esos 5, ni si los hitos de PRY-201 están cumplidos de verdad.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

**Vista por producto: «ahorro a la vista».** Sale de las fichas en `estado/`, calculadas al 2026-10-16. Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-16).

## Productos al 2026-10-16 (el pedido: ahorro a la vista)

| Producto | Proyectos | Con alertas | Fecha más tardía | Aprobado | Comprometido |
|---|---|---|---|---|---|
| ahorro a la vista | 1 (PRY-201) | 1 (5 alertas) | 2026-07-23 (ya pasó, hace 85 días) | COP 3.300.000.000 | COP 1.994.133.809 |

**«Ahorro a la vista» tiene un solo proyecto: PRY-201 «Apertura de ahorro en línea».** La vista por producto no aporta más que la ficha del proyecto, así que no armo sección de producto. Lo que sigue es lo que el cálculo dice de ese único proyecto.

- **Dependencias internas:** no hay. Un solo proyecto no puede tener dependencias con otro del mismo producto, y la ficha de PRY-201 no declara ninguna dependencia.
- **Fecha del producto:** 2026-07-23, la del único proyecto. Sin atraso contra la línea base (0 días contra la original y contra la vigente, 0 replanificaciones). Ya está vencida: los cuatro hitos figuran como cumplidos, pero el avance declarado es 78 %.
- **Señales (5):**
  - `progress_vs_plan`: el gerente declara 78 % y el plan sostiene 100 % (4 de 4 hitos cumplidos). Diferencia: 22 puntos, hacia atrás.
  - `milestone_met_without_evidence`, cuatro hitos declarados cumplidos sin evidencia de cumplimiento en los documentos:
    - Diseño funcional aprobado (fecha 2025-12-01, hace 319 días).
    - Ambiente de pruebas certificado (2026-02-17, 241 días).
    - Integración con el core cooperativo (2026-05-06, 163 días).
    - Piloto con asociados (2026-07-23, 85 días).
- **Lo declarado:** el informe de avance del 2026-10-11 pone el estado en **rojo**. Las dos señales anteriores no quedan explicadas en ese informe. Silencio: 5 días, bajo el umbral de 15.
- **Dinero (las cuatro cifras están):** aprobado COP 3.300.000.000; comprometido COP 1.994.133.809 (60,4 %); ejecutado COP 629.512.425 (19,1 %); proyección COP 3.199.017.869 (−3,1 % frente a lo aprobado). Disponible real: COP 1.305.866.191.
- **Evidencia:** la ficha no tiene ningún dato con fuente de evidencia (0 de 37; 3 son declaraciones y 34 sin marcar). Los datos de identidad y plan tienen 13 meses de antigüedad (fuente del 2025-09-04), por encima del umbral de 12.
- **Datos que faltan:** autoridad y fase del proyecto; la evidencia de los cuatro hitos; en el riesgo registrado, probabilidad, impacto, responsable y fecha; en la incidencia registrada, el responsable.

## Proyectos sin producto declarado

Son cinco. Un proyecto que nadie sabe a qué producto sirve es un hallazgo de gobierno: nadie puede responder por el conjunto al que sirve.

| Proyecto | Área dueña |
|---|---|
| PRY-202 Core cooperativo | el cálculo no la entrega |
| PRY-205 Prevención de lavado de activos | el cálculo no la entrega |
| PRY-208 Motor de crédito | el cálculo no la entrega |
| PRY-209 Convenios de libranza con empresas | el cálculo no la entrega |
| PRY-210 Corresponsales rurales | el cálculo no la entrega |

Dato que falta para completar la columna: el área dueña de cada ficha.

Una observación que no puedo cerrar: PRY-201 declara como hito la «Integración con el core cooperativo», y PRY-202 es el «Core cooperativo» sin producto. Es una posible dependencia entre ambos, pero ninguna ficha la declara (`dependencies` está vacío). No la afirmo. La dejo para confirmarla con los gerentes.

## Pie de rigor

Cifras copiadas de la salida de `portafolio.py compute`, al 2026-10-16. Lo que no sé: si los hitos están cumplidos de verdad (no hay evidencia en los documentos), qué pasó entre el informe del 2026-10-11 y hoy, y el área dueña de los cinco proyectos sin producto. Es un borrador de trabajo. La verificación contra los documentos citados es de quien lo lea.
