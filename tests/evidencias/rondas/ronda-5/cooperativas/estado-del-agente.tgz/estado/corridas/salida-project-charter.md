Hay acta previa: acta de constitución de PRY-203, aprobada el 2026-05-01. Términos vigentes (aceptados por José Francisco Ñáñez el 2026-10-16, versión 0.3.11), no hizo falta registrarlos de nuevo.

## Acta — PRY-203 · Aportes sociales en línea
**Estado:** existe, del 2026-05-01 (`00-gobierno/2026-05-01-acta-constitucion.md`)

### Qué falta
| Campo | Estado | Consecuencia |
|---|---|---|
| Autoridad del gerente | **No está** | No se sabe si Laura Vélez puede decidir algo por sí misma. Prueba: CC-01 (+156.000.000 COP, +78 días, ampliación de alcance) quedó "pendiente de presentación al comité" porque no hay umbral que diga si le corresponde a ella o al Comité de Riesgos. Todo sube al comité. |
| Objetivo de negocio | Presente pero es la solución: "Entregar aportes sociales en línea para Cartera y cobranza" | Sin resultado medible (qué cambia para la cooperativa), el comité no puede juzgar si la ampliación CC-01 aporta o solo agrega. |
| Alcance | Marcador vacío: "Componente 1, 2, 3" | No hay línea base de alcance. CC-01 pide "ampliación de alcance" y no se puede decir qué amplía ni contra qué. |
| Exclusiones | Marcador vacío: "Lo que otro proyecto cubre" (no dice cuál ni qué) | No se puede detectar traslape con otros proyectos ni discutir si lo del cambio normativo del supervisor entra o no. |
| Patrocinador | Rubén Cárdenas (persona con nombre) | Cumple. |
| Supuestos y restricciones | **No están** | El riesgo "cambio normativo del supervisor que puede mover el alcance" (informe 2026-10-05) es un supuesto que nunca se declaró en el acta. |
| Criterio de éxito | "En producción y medido": sin métrica, umbral ni fecha | "Medido" no dice qué. No se puede cerrar el proyecto contra algo comprobable. |
| Quién mide el éxito | **No está** | Nadie responde por declarar el éxito. |
| Cadencia del comité | **No está** (comité nombrado: Comité de Riesgos) | No hay ritmo de reporte pactado. |
| Hitos principales | **No están** (solo inicio 2026-05-11 y cierre 2027-09-05) | La ficha tiene 0 hitos; el 36 % de avance reportado no se puede contrastar con nada. |
| Dependencias | "Ninguna declarada" | Afirmación sin sustento para un proyecto con hallazgo de seguridad de arquitectura abierto. |
| Presupuesto y fechas | Presentes (800.000.000 COP; 2026-05-11 a 2027-09-05) | Cumple. |

### Contenido
**Objetivo de negocio:** pendiente de definir como resultado medible. El acta solo dice "Entregar aportes sociales en línea para Cartera y cobranza".
**Alcance:** pendiente de definir ("Componente 1, 2, 3" no es alcance).
**Exclusiones:** pendiente de definir (el acta dice "Lo que otro proyecto cubre" sin nombrar el proyecto).
**Patrocinador:** Rubén Cárdenas · **Gerente:** Laura Vélez
**Autoridad del gerente:** pendiente de definir: hasta qué monto y qué cambios sin comité.
**Comité al que reporta:** Comité de Riesgos · **Cadencia:** pendiente de definir.
**Supuestos:** pendiente de definir · **Restricciones:** pendiente de definir.
**Criterio de éxito:** "Aportes sociales en línea en producción y medido" (sin métrica) · **Lo mide:** pendiente de definir.
**Hitos principales:** pendiente de definir.
Presupuesto aprobado: 800.000.000 COP, Comité de Riesgos, 2026-05-01. Fechas: 2026-05-11 a 2027-09-05.

### Lo que otros documentos muestran y el acta no puede absorber
- **Estado verde con señales en contra** (informe 2026-10-05): ejecutado 367.668.535 COP = 46 % del aprobado, con 36 % de avance reportado; proyección al cierre 839.491.040 COP, 4,9 % sobre el aprobado (por debajo del umbral de 10 %); con CC-01 sería 995.491.040 COP, 24 % sobre el aprobado. El informe además reporta un hallazgo de seguridad sin responsable y dos riesgos sin dueño, probabilidad ni fecha.
- **Cifra a verificar:** el comprometido (235.653.597) es menor que el ejecutado (367.668.535). Lo normal es lo contrario o que el comprometido sea solo lo pendiente; el informe no lo aclara.
- **CC-01** (2026-10-05): +78 días sobre la línea base vigente llevaría el cierre del 2027-09-05 al 2027-11-22 (cálculo mío, no está en el documento). La decisión sigue pendiente.

(Aviso: la proyección 995.491.040 COP suma la proyección del informe y los 156.000.000 del cambio; asume que la proyección no los incluye ya. El informe no lo dice.)

### Después
El acta quedó sin autoridad del gerente declarada: te ofrezco llevar esa definición al Comité de Riesgos (monto y tipo de cambio que Laura Vélez puede decidir sin comité). Es una decisión, no un trámite, y conviene que se tome junto con CC-01.
Los supuestos que salieron de la revisión (cambio normativo del supervisor; que no hay dependencias) se pueden pasar al registro RAID.

---
**Pie de rigor:** revisión hecha sobre 3 documentos de PRY-203 (acta, informe de avance, solicitud CC-01) y su ficha. No sé qué se habló fuera de esos documentos; si existe un acta más completa o un acuerdo de autoridad, no está en la carpeta. Los 995.491.040 COP y la fecha 2027-11-22 son cálculos propios. La verificación de las citas es suya.
