# Corrida del 2026-10-16 · steering-pack

13 proyectos · 144 s · 66 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `commitment_overdue` | 9 |
| `progress_vs_plan` | 7 |
| `declared_vs_evidence` | 7 |
| `vendor_deliverable_late` | 5 |
| `variance_cost` | 4 |
| `commitment_undated` | 3 |
| `silent` | 2 |
| `vendor_invoiced_without_delivery` | 2 |
| `variance_time` | 2 |
| `commitment_rescheduled` | 2 |
| `change_without_baseline` | 1 |
| `rebaseline_unauthorized` | 1 |
| `pm_vs_pmo` | 1 |

Paquete de comité 2026-10-23: 10 decisiones, 5 escalamientos, 11 de 13 proyectos con hallazgos. Dijo que no sabe: quién tiene la facultad de aprobar (autoridad no encontrada en 13/13), si los costos de cada CC ya están en la proyección, el acta de CC-01 de PRY-204 y PRY-209, y que no hay registro de comité anterior.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

Cargué las 13 fichas del portafolio (PRY-199 a PRY-211, `estado/records/`), con corte al 2026-10-16, y las cifras de `portafolio.py compute` de hoy. Términos vigentes: versión 0.3.11, aceptados por José Francisco Ñáñez el 2026-10-16 (no se registraron de nuevo). Sesión sin interfaz: sin fecha en la invocación tomé la del próximo comité de la configuración, 2026-10-23, y lo dejo dicho.

# Comité de proyectos — 2026-10-23
10 decisiones · 5 escalamientos sin decisión asociada · 11 de 13 proyectos con hallazgos

**Antes de las decisiones, un hecho que las condiciona:** en las 13 fichas la autoridad de cambios figura como no encontrada (`identity.authority`). Por eso el punto 1 es quién decide. Los puntos 2 a 6 llevan un campo «Quién decide» que dice «no determinable» y proponen al comité por defecto; esa propuesta es mía, no una regla hallada en los documentos.

## Decisiones del comité anterior
No hay registro de un comité anterior en las fichas ni en las corridas de esta carpeta, así que no puedo cerrar el ciclo anterior. Lo más cercano: PRY-204 y PRY-209 dicen que su CC-01 lo aprobó «el comité» sin nombrar cuál ni citar acta (puntos 2 y 3).

| Decisión | Fecha | Qué pasó | Estado |
|---|---|---|---|
| Ninguna registrada | — | — | Sin datos |

## Decisiones de hoy

### [1] ¿Aprueba el comité un cuadro de autoridad escrito (qué decide el gerente, la patrocinadora, el comité y el Consejo, y hasta qué tope en fechas y presupuesto) para los 13 proyectos?
**Proyecto:** todo el portafolio (13 de 13 sin autoridad declarada) · **Quién decide:** no determinable; en PRY-211 el acta la aprobó el Consejo de Administración (2026-03-24), así que es probable que el cuadro necesite al Consejo. Este es el primer punto del comité. · **Si no se decide hoy:** los puntos 2 a 6 se deciden sin que conste que quien decide pueda hacerlo, y una decisión sin facultad se devuelve. Ya hay dos cambios aprobados por «el comité» sin nombrar cuál (PRY-204, PRY-209).

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Seguir sin autoridad escrita | Ninguno declarado; cada caso discute si excede o no | Cada punto agrega una ronda para averiguar quién decide | Ninguno directo; el riesgo es que lo decidido no valga |
| B. Un cuadro único para el portafolio, aprobado por el Consejo | Gerente decide dentro de topes; lo demás sube | Una sesión del Consejo o firma de la patrocinadora; no sé cuánto tarda, ningún documento lo dice | Ninguno de presupuesto; los topes los fija el Consejo y no propongo cifras |
| C. Adenda al acta de cada proyecto | Igual que B, proyecto por proyecto | 13 trámites | Ninguno directo |

**Recomendación:** B. Un solo cuadro evita 13 adendas, y los umbrales de 10 % en tiempo y costo de la configuración sirven para detectar, no para autorizar. Es mi lectura.

### [2] ¿Ratifica el comité el CC-01 de PRY-204 (ampliación de alcance, +115 días, COP 230.000.000 adicionales) que consta como aprobado el 2026-10-13 por «el comité (sin nombrar cuál)», y ordena registrar la línea base nueva con el acta que lo respalde?
**Proyecto:** PRY-204 Tarjeta débito para asociados · **Quién decide:** no determinable; por defecto el comité, con el patrocinador Ricardo Salas presente · **Si no se decide hoy:** el cambio sigue vigente sin acta y sin línea base nueva registrada (el cálculo lo marca «aprobado sin línea base»), mientras el proyecto reporta verde.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Ratificar y registrar línea base 2 contra el acta | Ampliación ya pedida | Fin vigente 2027-01-02; +115 días contra la original (37,1 %) | Proyección COP 20.519.654.277 contra aprobado 18.000.000.000: +14,0 %, sobre el umbral de 10 % |
| B. No ratificar hasta ver el acta | Se trabaja sin la ampliación | El atraso de 115 días queda sin autorizar | La proyección sigue +14,0 %; sin cifra de cuánto se evita |
| C. Ratificar y exigir que el estado deje de ser verde | Igual que A | Igual que A | Igual que A |

**Recomendación:** C. El informe del 2026-10-12 declara verde con cuatro señales sin explicar (hitos cumplidos sin evidencia, avance 83 % contra 100 % que sostiene el plan, desviación de costo, desviación de tiempo). No sé si los COP 230.000.000 ya están dentro de la proyección.

### [3] ¿Ratifica el comité el CC-01 de PRY-209 (ampliación de alcance, +68 días, COP 136.000.000 adicionales), aprobado por «el comité (sin nombrar cuál, ni fecha del acta que la autoriza)»?
**Proyecto:** PRY-209 Convenios de libranza con empresas · **Quién decide:** no determinable; por defecto el comité · **Si no se decide hoy:** línea base movida 68 días con una aprobación que no se puede citar. Hoy reporta verde con 13,0 % de atraso contra la original (umbral 10 %) y un compromiso vencido hace 17 días (Diana Molina, «Entregar el punto 21», vencía el 2026-09-29).

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Ratificar con el acta aportada | Ampliación ya pedida | Fin vigente 2027-10-27; +68 días | Proyección COP 9.611.254.152 contra aprobado 9.500.000.000: +1,2 % |
| B. No ratificar | Sin la ampliación | Vuelve a la fecha original; el equipo ya trabaja con la nueva | Sin cifra |
| C. Ratificar y exigir estado ámbar o rojo mientras haya atraso sobre umbral | Igual que A | Igual que A | Igual que A |

**Recomendación:** A, condicionada a que el gerente entregue el acta; sin acta pasa a B. El costo ya está casi dentro de lo aprobado.

### [4] ¿Aprueba el comité el CC-01 de PRY-208 (ampliación de alcance, +38 días, COP 76.000.000 adicionales), pedido hoy?
**Proyecto:** PRY-208 Motor de crédito · **Quién decide:** no determinable; por defecto el comité · **Si no se decide hoy:** la línea base ya se movió 38 días sin autorización (`rebaseline_unauthorized`: movidos 38, autorizados 0); el proyecto trabaja con una fecha que nadie aprobó.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar y registrar línea base 2 | Ampliación pedida | Fin vigente 2027-03-07 (+38 días, 7,9 % contra la original) | Proyección COP 3.914.489.109 contra aprobado 3.300.000.000: +18,6 % |
| B. Rechazar | Sin ampliación | Se vuelve 38 días atrás; el trabajo hecho con la fecha nueva queda sin respaldo | Sin cifra |
| C. Aprobar condicionado a una reestimación de costo | Igual que A | Igual que A, más el tiempo de reestimar (no sé cuánto) | Se aclara si los COP 76.000.000 están en la proyección |

**Recomendación:** C. La desviación de costo ya supera el umbral y no sé si el cambio está incluido. El proyecto se declara rojo, cosa que se agradece.

### [5] ¿Aprueba el comité el CC-01 de PRY-210 (ampliación de alcance, +65 días, COP 130.000.000 adicionales), pendiente desde el 2026-10-12?
**Proyecto:** PRY-210 Corresponsales rurales · **Quién decide:** no determinable; por defecto el comité · **Si no se decide hoy:** el fin vigente de la ficha es 2026-10-06, fecha ya pasada, sin cambio aprobado que la mueva; el cálculo no marca ningún hito vencido porque la ficha no trae hitos, así que no puedo decir qué falta para cerrar.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar y registrar línea base 2 | Ampliación pedida | +65 días sobre la línea base vigente | Proyección COP 3.884.263.243 contra aprobado 3.300.000.000: +17,7 % |
| B. Rechazar y exigir cierre dentro de lo aprobado | Sin ampliación | Cierre ya vencido | Sin cifra |
| C. Diferir una semana hasta tener hitos y reestimación | Sin decidir | Una semana más sin fecha vigente | Sin cifra |

**Recomendación:** C. Declara 85 % de avance en rojo y no hay hitos contra los cuales verificarlo. Aprobar +65 días sin saber qué falta es aprobar a ciegas. Si el comité prefiere decidir ya, A es la opción menos mala, porque la fecha ya pasó.

### [6] ¿Aprueba el comité el CC-01 de PRY-203 (ampliación de alcance, +78 días, COP 156.000.000 adicionales), pendiente desde el 2026-10-05?
**Proyecto:** PRY-203 Aportes sociales en línea · **Quién decide:** no determinable (`changes[0].decided_by` no encontrado); por defecto el comité · **Si no se decide hoy:** lleva 11 días pendiente; el proyecto sigue con fin 2027-09-05.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar y registrar línea base 2 | Ampliación pedida | +78 días | Proyección COP 839.491.040 contra aprobado 800.000.000: +4,9 % antes del cambio, sin saber si lo incluye |
| B. Rechazar | Sin ampliación | Sin cambio | Sin cifra |
| C. Diferir una semana hasta aclarar la ficha | Sin decidir | Una semana | Sin cifra |

**Recomendación:** C, con motivo concreto: la ficha trae ejecutado COP 367.668.535 (46,0 %) mayor que comprometido COP 235.653.597 (29,5 %), lo cual no es coherente, y no tiene hitos para medir el avance (declara 36 %). No lo resuelvo; es pregunta al gerente.

### [7] ¿Suspende el comité todo pago adicional a Soluciones Solidarias S.A.S. en PRY-200 hasta que haya entregables aceptados con evidencia?
**Proyecto:** PRY-200 Crédito de libranza digital · **Quién decide:** no determinable; por defecto el comité, con la patrocinadora Beatriz Cuéllar presente · **Si no se decide hoy:** el contrato CT-395 sigue con COP 207.643.011 facturados y 0 de 4 entregables aceptados, los 4 vencidos (entre 138 y 393 días).

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Suspender pagos hasta aceptación | Sin cambio | Puede frenar al proveedor; no sé cuánto | Se detiene la exposición; lo ya facturado no se recupera con esto |
| B. Seguir pagando y exigir fechas por escrito | Sin cambio | Depende de que el proveedor cumpla | Exposición abierta |
| C. Pedir primero la evidencia de recibo y decidir en el próximo comité | Sin cambio | Una semana | Exposición sin cambio esa semana |

**Recomendación:** A. Facturado sin ningún entregable aceptado es el patrón que el criterio de proveedores manda frenar. Eso no dice que el proveedor no haya entregado: dice que ningún documento lo acredita.

### [8] ¿Autoriza el comité que PRY-206 continúe con proyección de COP 20.909.731.906 contra aprobado de COP 18.000.000.000 (+16,2 %), o ordena primero un diagnóstico desde cero?
**Proyecto:** PRY-206 Pagos con QR · **Quién decide:** no determinable; por defecto el comité · **Si no se decide hoy:** el proyecto, con fin vigente 2026-02-12 ya pasado, sigue gastando (ejecutado 63,1 %) contra un avance declarado de 53 %, sin cambio aprobado ni fecha nueva.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Continuar y pedir ampliación formal de presupuesto | Sin cambio | Sin fecha nueva todavía | Hasta la proyección: +16,2 % sobre lo aprobado |
| B. Continuar sin ampliar y recortar alcance a lo que cubre lo aprobado | Se recorta; no sé qué | Sin fecha nueva | Tope en lo aprobado |
| C. Diagnóstico desde cero (`/health-check`) antes de decidir | Sin cambio | Una semana | Sin costo adicional declarado |

**Recomendación:** C. El plan marca los 3 hitos como cumplidos sin evidencia (la fecha de 2 de ellos es de 2025) y el informe dice 53 %: ambas cosas no pueden ser ciertas, y decidir dinero sobre esa contradicción es decidir sin saber. Dos compromisos vencidos (Gustavo Neira, 15 días; Liliana Torres, 1 día).

### [9] ¿Designa el comité una sola persona responsable de la relación con el «proveedor del core cooperativo» para los seis proyectos que lo reportan como dependencia (PRY-199, 200, 204, 205, 206 y 211)?
**Proyecto:** PRY-199, 200, 204, 205, 206, 211 · **Quién decide:** el comité (afecta a varios proyectos; ningún gerente puede por sí solo) · **Si no se decide hoy:** la dependencia sigue sin doliente, reportada desde el 2026-09-25 (PRY-205); ninguna acta de constitución la declara.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Designar ya un responsable único | Una coordinación para los seis | Inmediato | Horas de esa persona; sin cifra |
| B. Pedir a los seis gerentes que confirmen primero si la dependencia es real | Sin cambio | Una semana | Ninguno |
| C. Que cada gerente la gestione | Sin cambio | Igual que hoy | Duplicación; sin cifra |

**Recomendación:** B y luego A. El texto es idéntico en proyectos sin relación entre sí (mobiliario, cobranza, tarjeta débito): puede ser una dependencia compartida o una plantilla copiada. Nadie documentó que dependan de PRY-202 Core cooperativo; es una hipótesis. Con los documentos no puedo proponer a nadie: no consta quién maneja al proveedor del core.

### [10] ¿Designa el comité un responsable único ante el Consejo de Administración para el ajuste del reglamento y pide una fecha de aprobación?
**Proyecto:** PRY-202, 208, 209 y 210 lo declaran como dependencia; PRY-199, 200, 205, 206 y 210 reportan como incidencia que el Consejo pidió ajustar el reglamento antes del piloto (8 proyectos distintos en total: 199, 200, 202, 205, 206, 208, 209, 210) · **Quién decide:** el comité · **Si no se decide hoy:** nadie lleva el reglamento al Consejo y cada informe repite la misma incidencia sin fecha.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. El gerente de PRY-202 (Andrés Lozano, según su informe de avance) | Una gestión para 8 proyectos | Inmediato | Horas; sin cifra |
| B. La PMO | Igual | Inmediato | Horas de la PMO; sin cifra |
| C. Cada gerente por su cuenta | Sin cambio | Igual que hoy | Duplicación |

**Recomendación:** B. El tema cruza 8 proyectos y A recarga a un gerente con la gestión de los otros. Ningún documento dice quién lleva hoy el reglamento ante el Consejo. Los informes no dicen si el Consejo ya fijó fecha.

## Escalamientos sin decisión asociada
| Proyecto | Qué | Desde cuándo | Qué se necesita |
|---|---|---|---|
| PRY-211 Cobranza digital | Declara rojo con 56 % de avance. 6 compromisos vencidos (entre 9 y 30 días) y 2 sin fecha. «Enviar el documento 1» reprogramado 6 veces (original 2026-09-15, última 2026-11-27) y «Cerrar la prueba 2» 5 veces (original 2026-09-09, última 2026-11-03). Dos fechas de fin: 2027-05-31 (cronograma) contra 2027-07-23 (acta) | Compromisos vencidos desde 2026-09-16; reprogramaciones desde 2026-09-15 | Que Ricardo Salas diga qué fecha rige y quién reasigna lo reprogramado; depende del punto 1 |
| PRY-211/R3 | Riesgo dicho en reunión el 2026-10-16: el proveedor podría no llegar con el equipo completo. Sin doliente ni registro formal | 2026-10-16 | Decidir si se formaliza y quién responde ante el proveedor |
| PRY-200 | Línea base vencida: salida a producción 2026-07-16 (acta dice cierre 2026-08-24). Los 5 hitos figuran «cumplidos» sin evidencia, avance declarado 25 %, verde, sin informe nuevo en 20 días. Sin solicitud de cambio en la ficha | Salida vencida desde 2026-07-16 (92 días) | Solicitud de cambio formal con fecha nueva y motivo; ver `salida-change-control.md` |
| PRY-202 Core cooperativo | Declara 82 % y verde; el plan sostiene entre 20 y 40 %. COP 49.161.899 facturados por Integración Financiera del Sur (CT-362) y 0 de 2 entregables aceptados | Informe del 2026-10-07 | Evidencia de recibo o retención, igual que el punto 7. Además es el proyecto que más podría estar detrás de los puntos 9 y 10 |
| PRY-207 Microcrédito rural | 18 días sin movimiento (último informe 2026-09-28; umbral 15). Hito «Diseño funcional aprobado» cumplido sin evidencia | 2026-09-28 | Que el gerente reporte; si no responde, el comité pregunta a la patrocinadora |

## Para conocimiento
- **PRY-199** Cambio de mobiliario de agencias: sin alertas. Verde, 20 % declarado, el plan sostiene 20–40 %.
- **PRY-201** Apertura de ahorro en línea: se declara rojo, 78 % contra 100 % que sostiene el plan (4 de 4 hitos cumplidos sin evidencia). Proyección −3,1 % bajo lo aprobado.
- **PRY-205** Prevención de lavado de activos: verde, 46 % declarado contra 67–100 % del plan; informe de hace 21 días; un compromiso sin fecha (Sandra Gil, «Entregar el punto 19»).

## Anexo
### Estado de cada proyecto (cifras de `compute`, 2026-10-16)
| Proyecto | Declarado | Avance declarado | Lo que sostiene el plan | Fin vigente | Ejecutado | Proyección sobre aprobado |
|---|---|---|---|---|---|---|
| PRY-199 | verde | 20 % | 20–40 % | 2027-12-15 | 30,0 % | 0,0 % |
| PRY-200 | verde | 25 % | 100 % | 2026-07-16 | 46,3 % | +2,2 % |
| PRY-201 | rojo | 78 % | 100 % | 2026-07-23 | 19,1 % | −3,1 % |
| PRY-202 | verde | 82 % | 20–40 % | 2027-05-03 | 57,0 % | +1,4 % |
| PRY-203 | verde | 36 % | no calculable (sin hitos) | 2027-09-05 | 46,0 % | +4,9 % |
| PRY-204 | verde | 83 % | 100 % | 2027-01-02 | 26,6 % | +14,0 % |
| PRY-205 | verde | 46 % | 67–100 % | 2026-12-10 | 38,9 % | +0,4 % |
| PRY-206 | verde | 53 % | 100 % | 2026-02-12 | 63,1 % | +16,2 % |
| PRY-207 | verde | 39 % | 25–50 % | 2027-06-22 | 44,8 % | −7,8 % |
| PRY-208 | rojo | 45 % | 75–100 % | 2027-03-07 | 22,3 % | +18,6 % |
| PRY-209 | verde | 26 % | 25–50 % | 2027-10-27 | 44,5 % | +1,2 % |
| PRY-210 | rojo | 85 % | no calculable (sin hitos) | 2026-10-06 | 52,6 % | +17,7 % |
| PRY-211 | rojo | 56 % | 25–50 % | 2027-05-31 | 36,1 % | −7,6 % |

### Contradicciones abiertas
- **Verde contradicho por la evidencia: 7 proyectos** (PRY-200, 202, 204, 205, 206, 207, 209), cada uno con las señales indicadas en los puntos y escalamientos anteriores.
- **PRY-211:** fin 2027-05-31 (cronograma, PMO) contra 2027-07-23 (acta, gerente), ambos del 2026-03-24; ninguno es más nuevo.
- **PRY-200:** cronograma salida 2026-07-16 contra acta cierre 2026-08-24 (de `salida-change-control.md`).
- **PRY-200 y PRY-203:** ejecutado mayor que comprometido, sin explicación.

### Vacíos de información
- Autoridad de cambios: no encontrada en 13 de 13.
- Evidencia de cumplimiento de hitos: 0 fuentes marcadas como evidencia en las 13 fichas.
- Registro RAID: 35 de 35 ítems sin doliente y sin fecha de gestión; ninguno con probabilidad ni impacto (de `salida-raid-log.md`).
- Campos con más de 12 meses de antigüedad en PRY-200 (16 meses), 201 (13), 204 (12), 205 (12), 206 (17) y 208 (13).
- Sin minutas de reunión de PRY-200, 201, 203, 204, 207, 208 ni 210.

---
**Pie.** criterio-portfolio 0.3.11 · términos v1.1 aceptados por José Francisco Ñáñez, 2026-10-16 · fichas aplicadas: 13 (`estado/records`) al 2026-10-16 · criterios aplicados: raid-taxonomy (escalamiento), governance-artifacts (decisión con cuatro partes, quién decide, cierre del ciclo anterior). **Campos inciertos:** quién tiene la facultad en cada punto; si los COP de cada solicitud de cambio ya están en la proyección; si el «proveedor del core» es el de PRY-202; el acta que respalda los CC-01 de PRY-204 y PRY-209; si el Consejo ya fijó fecha para el reglamento; el avance real de todos los proyectos, que solo se conoce por declaración. Las recomendaciones son mi lectura. Borrador de trabajo: la verificación y la decisión son suyas. Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.11
