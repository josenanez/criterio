Sale de la ficha PRY-200 (`estado/records/PRY-200.json`, actualizada 2026-10-16) y del cálculo `portafolio.py impact --code PRY-200 --days 30`.

## Solicitud de cambio — PRY-200 Crédito de libranza digital — 2026-10-16

**Qué se pide:** mover 30 días la «Salida a producción». **Quién lo pide:** no consta en los documentos (la sesión no lo dice). **Por qué:** no consta. El único rastro es la línea del informe de avance del 2026-09-26: «Se reprogramó la salida por el cierre contable de fin de mes», sin documento de cambio ni fecha nueva.

### Antes de evaluar: la solicitud no se puede leer tal cual
- La línea base vigente es una sola (v1, 2025-06-15): salida a producción **2026-07-16**, según el cronograma v1. Sumarle 30 días da **2026-08-15, una fecha que ya pasó** (hoy es 2026-10-16).
- El acta de constitución dice cierre **2026-08-24**; el cronograma v1 dice 2026-07-16. Son 39 días de diferencia entre dos documentos de la misma fecha. No sé cuál rige; ninguno lo aclara.
- El cronograma marca «Salida a producción» como `met` (cumplido), sin evidencia, mientras el informe del 2026-09-26 reporta 25 % de avance y el piloto con asociados aún por hacerse (el Consejo pidió ajustar el reglamento antes del piloto). El criterio de éxito del acta es «en producción y medido». Esas dos cosas no pueden ser ciertas a la vez.
- Dos lecturas posibles de «30 días», y es quien pide quien debe decir cuál:
  - **A.** +30 sobre la línea base: 2026-08-15. Ya vencida; no es un cambio, es un reconocimiento tardío.
  - **B.** +30 desde hoy: **2026-11-15**, es decir 122 días de atraso contra el cronograma v1 (92 hasta hoy + 30) y 83 contra el acta (53 + 30).

El resto usa la lectura B como referencia; es mi suposición, no un dato.

### Impacto
| Dimensión | Hoy | Con el cambio | Diferencia |
| Alcance | Componentes 1, 2 y 3 (acta) | Sin cambio declarado | 0 declarado |
| Tiempo | Salida 2026-07-16 (cronograma) / cierre 2026-08-24 (acta) | 2026-11-15 (lectura B) | +30 días del pedido; +122 contra el cronograma v1 |
| Costo | Aprobado COP 2.400.000.000; ejecutado 1.111.419.946; proyección 2.452.918.540 | No declarado | Sin cifra. La proyección ya supera lo aprobado en COP 52.918.540 (2,2 %, bajo el umbral del 10 %) |

**Quién absorbe lo que no se declara.** Mover la fecha sin costo declarado significa que 30 días más de equipo y de contratos corren dentro de un presupuesto que ya está proyectado por encima; alguien lo absorbe en horas no presupuestadas o en alcance recortado, y nadie lo ha dicho. Tampoco hay impacto declarado en alcance, que sería lo primero que se recorta.

Dato de contexto sobre el costo: la ficha tiene ejecutado (1.111 M) mayor que comprometido (922 M), lo cual no es coherente con lo normal (lo ejecutado suele estar dentro de lo comprometido). No lo resuelvo; queda como pregunta al gerente.

### Efecto en el portafolio
| Proyecto afectado | Cómo | Gerente |
| Ninguno calculado | El cálculo devolvió 0 alcanzados (0 directos, 0 indirectos, 0 que no puedan sostener su fecha, 0 sin confirmar) | — |

**Esto no significa que no haya efecto.** Significa que PRY-200 no declara ninguna dependencia (el acta dice «Ninguna declarada» y la ficha tiene `dependencies: []`). Sin embargo, el propio informe lista como riesgo la «Dependencia del proveedor del core cooperativo», y existe PRY-202 «Core cooperativo» en el portafolio. Es una dependencia real que nadie declaró, así que el cálculo no la puede recorrer. Hasta que Ricardo Salas la declare y se confirme con el otro lado, el efecto en el portafolio es **desconocido, no nulo**. Tampoco puedo decir cuántos días se movería cada proyecto afectado: eso requiere holgura por actividad, que la ficha no tiene.

### Quién decide
**Autoridad requerida:** no determinable. La ficha marca `identity.authority` como no encontrada: el acta no declara quién puede aprobar cambios de fecha o de presupuesto. Ese es el hallazgo de fondo. **Según:** acta de constitución 2025-06-15, sin cláusula de autoridad de cambios. Lo único que consta es que el Comité de Crédito aprobó el presupuesto y la línea base, y que la patrocinadora es Beatriz Cuéllar. **Va a comité:** sí, por defecto. Sin autoridad declarada, lo prudente es que lo decida el órgano que aprobó la línea base (Comité de Crédito), con la patrocinadora presente. Es una recomendación mía, no una regla encontrada.

### Si no se aprueba
El proyecto sigue con una línea base cuya fecha de salida ya pasó hace 92 días, un hito marcado «cumplido» sin evidencia, estado verde con 25 % de avance, y una reprogramación («se reprogramó la salida») que ya ocurrió de hecho sin ningún documento que la autorice. No aprobar no devuelve el proyecto al plan: deja un plan que ya no describe la realidad.

### Si se aprueba
**No se crea línea base nueva en esta corrida:** no hay aprobación documentada, y una línea base se registra con el documento que la aprobó. Cuando exista, sería:

Línea base 2 — salida [fecha que decida el comité; lectura B: 2026-11-15] · presupuesto [monto, hoy sin cambio declarado: 2.400.000.000 COP, proyección 2.452.918.540] · motivo: [el que diga el acta del comité; el informe solo menciona el cierre contable de fin de mes y el ajuste de reglamento pedido por el Consejo de Administración]. La línea base 1 (2025-06-15) no se toca.

Desviación acumulada contra la línea base original: **tiempo +122 días en la salida a producción** (lectura B; 92 ya acumulados + 30) · **costo +COP 52.918.540 (+2,2 %) proyectados** sobre el aprobado, sin incluir costo de los 30 días adicionales.

Nota: el registro de cambios de la ficha está vacío (`changes: []`). Hoy hay 92 días de atraso respecto del cronograma que ningún documento autoriza.

### Qué falta para cerrar esta solicitud
1. Quién pide el cambio, por qué, y la fecha nueva concreta (lectura A o B).
2. Cuál de las dos fechas rige: cronograma v1 (2026-07-16) o acta (2026-08-24).
3. Evidencia de «Salida a producción» o corrección del estado `met`.
4. Declarar la dependencia con el core cooperativo (¿PRY-202?) y confirmarla con su gerente.
5. La autoridad de cambios, que el acta no define.
6. El costo de los 30 días y por qué ejecutado supera comprometido.

**Después:** llevar el paquete a comité (`/criterio-portfolio:steering-pack`), porque no hay autoridad declarada que permita cerrarlo por otra vía. No registro línea base nueva: nadie con autoridad la ha aprobado.

---
**Pie de rigor.** Hechos citados: ficha PRY-200 (acta de constitución 2025-06-15, cronograma v1 2025-06-15, informe de avance 2026-09-26). Interpretaciones mías: la lectura B de «30 días» y la recomendación de comité. No sé: quién pide el cambio, el motivo real, la fecha rectora entre acta y cronograma, si hay dependencia con PRY-202, cuántos días se movería cualquier otro proyecto (falta holgura por actividad) ni el costo de los 30 días. Sesión de prueba sin interfaz: las preguntas se resolvieron con la respuesta sugerida (lectura B) y se dejó dicho.
