# Corrida del 2026-10-16 · portfolio-wake

13 proyectos · 46 s · 66 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `commitment_overdue` | 9 |
| `progress_vs_plan` | 7 |
| `declared_vs_evidence` | 7 |
| `vendor_deliverable_late` | 5 |
| `variance_cost` | 4 |
| `commitment_undated` | 3 |
| `silent` | 2 |
| `vendor_invoiced_without_delivery` | 2 |
| `variance_time` | 2 |
| `commitment_rescheduled` | 2 |
| `change_without_baseline` | 1 |
| `rebaseline_unauthorized` | 1 |
| `pm_vs_pmo` | 1 |

Barrido: 75 documentos sin cambios, nada que releer. Confirmación: 5 preguntas formuladas sin respuesta (sesión desatendida). 35 citas de PRY-211 no resuelven por ruta sin carpeta del proyecto; sin verificar. No consulté requests (no tocaban). No revisé campos de más de 12 meses.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

## 2026-10-16

**Revisé:** 75 documentos · 0 cambiaron · 0 proyectos recalculados

### Lo que cruzó un umbral
Nada nuevo por cambio de documentos: el barrido no encontró documentos nuevos, cambiados, renombrados ni borrados. El recálculo de la ficha muestra, sin embargo, señales abiertas que ya estaban (no las produjo este barrido):
- PRY-200: en silencio 20 días (umbral 15).
- PRY-207: en silencio 18 días (umbral 15).
- PRY-202: proveedor facturado sin entrega.
- PRY-208: replanificación sin autorización.
- PRY-204: desviación en tiempo y en costo sobre el 10 %.
- PRY-211: 6 o más compromisos vencidos (11 señales abiertas en total).

Citas rotas: el índice reporta 35 campos de PRY-211 cuya fuente "no resuelve" (acta de constitución, cronograma v1, informe de avance del 13-oct, acta de recibo del 8-oct). Los archivos sí existen en la carpeta del proyecto; la ruta citada en la ficha no incluye la carpeta `PRY-211-cobranza-digital/`. Parece un problema de ruta en la cita, no un documento perdido; no lo corregí y queda por verificar.

### Peticiones atendidas
Ninguna: `requests` no tocaba hoy y no las consulté.

### Preguntas
Nadie responde en esta corrida, así que quedan formuladas sin respuesta (primera vez que se preguntan):
1. PRY-200: ¿cuál es el estado real? Sin movimiento hace 20 días.
2. PRY-207: ¿cuál es el estado real? Sin movimiento hace 18 días.
3. PRY-202: ¿hay acta de recibo de lo facturado al proveedor?
4. PRY-208: ¿quién autorizó el cambio de línea base?
5. PRY-211: ¿qué compromisos vencidos siguen vigentes y con qué nueva fecha?

Estas cinco salen de las señales abiertas, elegidas por importancia; no cuentan campos de más de 12 meses de antigüedad, que no revisé.

**Vuelvo el 2026-10-17.**
