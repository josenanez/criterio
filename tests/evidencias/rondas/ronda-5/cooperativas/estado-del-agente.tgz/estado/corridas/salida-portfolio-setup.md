## Listo — Cooperativa

**Miré:** 75 documentos en 13 proyectos · formatos: .md (38), .docx (12), .xlsx (10), .pdf (9), .csv (4), .json (1), .txt (1) · más reciente: 2026-10-16
**Eres:** PMO del portafolio (propuesto: hay varios proyectos)
**Te aviso:** dos días antes del comité semanal (primer comité propuesto: 2026-10-23)
**En:** presentación
**Términos:** aceptados por José Francisco Ñáñez para la versión 0.3.11 (términos 1.1) · comprobante en `.criterio/terminos/aceptacion-criterio-portfolio-0.3.11-2026-10-16.md` y `.pdf` · SHA-256 del .md 41a739aec7049af3…

Estado en `estado/`, informes en `reportes/`. Preguntas hechas: 0; nadie podía responder, tomé lo propuesto en cada una.

### Probé con tres proyectos (los de documentación más reciente)

| Proyecto | Documentos | Qué supe | Qué no está |
|---|---|---|---|
| PRY-209 Convenios de libranza con empresas | 7 | Gerente Liliana Torres, patrocinador Paula Céspedes, Comité de Tecnología. Presupuesto 9.500 M COP (proyección 9.611 M). Declara verde, 26%. CC-01 (+68 días, 136 M COP) autorizada por «el comité». | Facultad del gerente, etapa, producto (el acta dice «No aplica»), evidencia de 3 hitos abiertos, probabilidad/impacto/dueño del riesgo |
| PRY-206 Pagos con QR | 4 | Gerente Sandra Gil, patrocinadora Laura Vélez, Consejo de Administración. Presupuesto 18.000 M COP (proyección 20.910 M). Declara verde, 53%. Cierre comprometido 2026-03-27. | Facultad del gerente, etapa, acta de cualquiera de los 3 hitos cerrados, dueño de las dos incidencias |
| PRY-208 Motor de crédito | 6 | Gerente Diana Molina, patrocinadora María Restrepo, Comité de Riesgos. Presupuesto 3.300 M COP (proyección 3.914 M). Declara rojo, 45%. CC-01 (+38 días, 76 M COP) pendiente de comité. | Facultad del gerente, etapa, producto, acta de 2 de los 3 hitos cerrados (solo está la del ambiente de pruebas) |

### Hallazgos (las señales que levantó el cálculo, no mi lectura)

**PRY-206 · Pagos con QR — declara verde**
- `progress_vs_plan`: declara 53% y el cronograma tiene los 3 hitos cerrados (el plan sostiene 100%); 47 puntos de diferencia.
- `milestone_met_without_evidence`: los 3 hitos figuran cerrados (hace 416, 331 y 246 días) sin un acta que lo pruebe.
- `variance_cost`: la proyección al cierre es 16,2 % sobre lo aprobado.
- `commitment_overdue`: Gustavo Neira, «Entregar el punto 6», 15 días vencido; Liliana Torres, «Entregar el punto 2», 1 día. Ambos figuran en el comité del 2026-10-16.
- `declared_vs_evidence`: el verde declarado el 2026-10-13 convive con las cuatro señales anteriores.

**PRY-208 · Motor de crédito — declara rojo**
- `progress_vs_plan`: declara 45%; el plan sostiene entre 75 y 100% (30 puntos).
- `milestone_met_without_evidence`: «Diseño funcional aprobado» (259 días) e «Integración con el core cooperativo» (17 días) sin acta. El ambiente de pruebas sí tiene la suya (2026-10-10).
- `variance_cost`: proyección 18,6 % sobre lo aprobado.
- `rebaseline_unauthorized`: el cronograma v2 mueve el piloto 38 días y la CC-01 que lo justificaría sigue pendiente (autorizados: 0).

**PRY-209 · Convenios de libranza — declara verde**
- `variance_time`: 68 días contra la línea base original (13,0 %).
- `commitment_overdue`: Diana Molina, «Entregar el punto 21», 17 días vencido (comité del 2026-10-14).
- `declared_vs_evidence`: el verde declarado el 2026-10-16 convive con esas dos señales.
- La CC-01 de +68 días sí cuadra con lo que se movió la línea base (68 días autorizados, 0 sin autorizar).

### El portafolio completo
10 proyectos más (PRY-199 a PRY-205, PRY-207, PRY-210 y PRY-211), 65 documentos, en lotes de diez, uno tras otro. Con lo que vi, unos 30 minutos.

### Lo que le falta a tu carpeta
- Ninguna acta de constitución dice hasta qué monto decide el gerente ni en qué etapa está el proyecto: sin eso el control de cambios no puede saber si algo excede su facultad.
- Las actas de recibo son escasas: hitos cerrados sin acta en 2 de los 3 proyectos leídos.
- La autorización de la CC-01 de PRY-209 dice «el comité» sin nombrar cuál ni citar el acta.
- Los riesgos no traen dueño, probabilidad ni fecha.
- Las actas de constitución de estos tres proyectos tienen 13 a 17 meses sin confirmación posterior (patrocinador, gerente, comité).
- Ninguno es bloqueante.
