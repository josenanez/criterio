# Corrida del 2026-10-16 · portfolio-report

13 proyectos · 75 documentos, 0 releídos y 75 sin cambio · 57 s · 66 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `commitment_overdue` | 9 |
| `progress_vs_plan` | 7 |
| `declared_vs_evidence` | 7 |
| `vendor_deliverable_late` | 5 |
| `variance_cost` | 4 |
| `commitment_undated` | 3 |
| `silent` | 2 |
| `vendor_invoiced_without_delivery` | 2 |
| `variance_time` | 2 |
| `commitment_rescheduled` | 2 |
| `change_without_baseline` | 1 |
| `rebaseline_unauthorized` | 1 |
| `pm_vs_pmo` | 1 |

El informe quedó en `reportes/index.html`.

Primera corrida del informe: 7 verdes contradichos; revisar PRY-200, PRY-211 y la contradicción de fecha de fin de PRY-211

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

# Portafolio — 2026-10-16
13 proyectos · 11 con hallazgos (66 señales) · 7 en verde contradichos por la evidencia · último barrido: fichas de 2026-10-16 (`estado/records/`, PRY-199 a PRY-211; todas de hoy, ninguna con más de una semana).

**Términos:** vigentes, aceptados por José Francisco Ñáñez el 2026-10-16 (términos 1.1, familia 0.3.11). Resumen: Criterio produce borradores de trabajo, no decisiones ni asesoría; procesa los documentos que se le indican y dice lo que muestran, no lo que se habló fuera de ellos; puede equivocarse, por eso cada dato lleva la cita del documento y la verificación es suya; los documentos se procesan en la infraestructura de la plataforma de IA; garantía y responsabilidad según Apache 2.0. Nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal

**Informe en HTML** (25 páginas, `reportes/`):
- `reportes/index.html` — vista por campo, con la cadena de evidencia completa. Para quien va a actuar (PMO, gerentes).
- `reportes/decisiones.html` — vista por decisión, para el patrocinador/comité: solo lo que excede la facultad del gerente, como pregunta cerrada y con la consecuencia de no decidir.
- Una página por proyecto. El PDF sale de imprimir el HTML.

## Qué cambió desde la corrida anterior
No hay instantánea previa distinta de la de hoy (`estado/snapshots/2026-10-16.json`): este es el punto de partida, no hay delta. El diff devolvió 0 cambios.

## Contradicciones abiertas
| Proyecto | Campo | Dice | Fuente | Dice también | Fuente |
|---|---|---|---|---|---|
| PRY-211 Cobranza digital | Fecha de fin del plan | 2027-05-31 | `10-plan/2026-03-24-cronograma-v1.csv` | 2027-07-23 | `00-gobierno/2026-03-24-acta-constitucion.docx` |

Ninguna de las dos fuentes es más reciente (misma fecha, 2026-03-24): no se puede decir cuál manda. Además, 7 proyectos declaran verde y la evidencia lo contradice (ver Estado general).

## Hitos vencidos sin evidencia
Sin hitos vencidos sin cumplir. Sí hay 20 hitos declarados "cumplidos" sin documento que lo respalde (ver "Sin sustento").

## Proyectos en silencio
Umbral: 15 días.
| Proyecto | Días | Último documento |
|---|---|---|
| PRY-200 Crédito de libranza digital | 20 | 2026-09-26 |
| PRY-207 Microcrédito rural | 18 | 2026-09-28 |

## Dependencias en riesgo
Vacía: ningún proyecto declara dependencias por código que hayan movido fecha. Vigilar PRY-208 (línea base movida 38 días sin autorización) y PRY-204 (cambio CC-01 sin línea base, 115 días) por si otros dependen de ellos.

## Sin sustento
| Proyecto | Declara | Qué lo respalda |
|---|---|---|
| PRY-200 | Verde, 25 %; 5 de 5 hitos cumplidos | Nada: los 5 hitos sin evidencia (hasta 401 días). El plan sostiene 100 %, el avance declarado es 25 %. Proveedores: 5 entregables vencidos (hasta 393 días) y 207,6 M COP facturados sin entrega (Soluciones Solidarias); 59 campos viejos |
| PRY-201 | Rojo, 78 %; 4 de 4 hitos cumplidos | 4 hitos sin evidencia (85 a 319 días) |
| PRY-202 Core cooperativo | Verde, 82 % | El plan sostiene 20–40 % (1 de 5 hitos). Integración Financiera del Sur facturó 49,2 M COP sin entregables |
| PRY-204 Tarjeta débito | Verde, 83 % | 3 hitos sin evidencia; sobrecosto proyectado 14 % (20.519 M vs 18.000 M); atraso 115 días vs original (37,1 %); cambio CC-01 sin línea base |
| PRY-205 PLA | Verde, 46 % | 2 hitos sin evidencia; el plan sostiene 67–100 % |
| PRY-206 Pagos QR | Verde, 53 % | 3 hitos sin evidencia; sobrecosto proyectado 16,2 %; 2 compromisos vencidos |
| PRY-207 Microcrédito rural | Verde | 1 hito sin evidencia y 18 días de silencio |
| PRY-208 Motor de crédito | Rojo, 45 % | 2 hitos sin evidencia; sobrecosto 18,6 %; línea base movida 38 días sin autorización |
| PRY-209 Convenios de libranza | Verde, 26 % | Atraso 68 días vs original (13 %); compromiso vencido 17 días |

## Vacíos de información
Todos los proyectos tienen campos faltantes (10 a 22 por ficha) y ninguno tiene autoridad de aprobación identificada (13 de 13). Más faltantes: PRY-200 (22), PRY-211 (21), PRY-199 (16), PRY-206 (15). Campos viejos (más de 12 meses): PRY-200 (59), PRY-201 (27), PRY-206 (23), PRY-205 (22). 5 proyectos no tienen producto asociado: PRY-202, 205, 208, 209, 210.

Compromisos: PRY-211 tiene 6 vencidos (hasta 30 días) y 2 con 5–6 reprogramaciones (Mauricio Pérez, "Enviar el documento 1", original 2026-09-15 → 2026-11-27; Paula Céspedes, "Cerrar la prueba 2", original 2026-09-09 → 2026-11-03), más 2 sin fecha. PRY-205 tiene 1 compromiso sin fecha (Sandra Gil). PRY-206: 2 vencidos (Gustavo Neira, 15 días). PRY-209: 1 vencido (Diana Molina, 17 días).

## Estado general
| Proyecto | Declarado | Sustento | Desviación vs original | vs vigente | Replanificaciones |
|---|---|---|---|---|---|
| PRY-199 Mobiliario agencias | Verde | Sustentado (sin señales) | 0 d | 0 d | 0 |
| PRY-200 Libranza digital | Verde | Contradicho | 0 d | 0 d | 0 |
| PRY-201 Ahorro en línea | Rojo | Hitos sin evidencia | 0 d | 0 d | 0 |
| PRY-202 Core cooperativo | Verde | Contradicho | 0 d | 0 d | 0 |
| PRY-203 Aportes sociales | Verde | Sin señales | 0 d | 0 d | 0 |
| PRY-204 Tarjeta débito | Verde | Contradicho | 115 d (37,1 %) | 0 d | 1 |
| PRY-205 PLA | Verde | Contradicho | 0 d | 0 d | 0 |
| PRY-206 Pagos QR | Verde | Contradicho | 0 d | 0 d | 0 |
| PRY-207 Microcrédito rural | Verde | Contradicho | 0 d | 0 d | 0 |
| PRY-208 Motor de crédito | Rojo | Rojo confirmado | 38 d | 0 d | 1 |
| PRY-209 Convenios libranza | Verde | Contradicho | 68 d (13 %) | 0 d | 1 |
| PRY-210 Corresponsales rurales | Rojo | Rojo confirmado (sobrecosto 17,7 %) | 0 d | 0 d | 0 |
| PRY-211 Cobranza digital | Rojo | Rojo confirmado (compromisos) | 0 d | 0 d | 0 |

Por producto: crédito de libranza (PRY-200) acumula 14 señales; recaudos (PRY-211) 11; pagos QR y tarjeta débito 8 cada uno.

## Necesito que confirmes
Sesión de prueba sin interfaz: nadie responde, y la confirmación periódica es mensual y no hay una anterior contra la cual tocar. Se dejan como preguntas para la próxima corrida (cinco campos, los más viejos que importan):
1. PRY-200: ¿sigue vigente el diseño funcional aprobado y existe el acta que lo respalda?
2. PRY-211: ¿la fecha de fin vigente es 2027-05-31 (cronograma) o 2027-07-23 (acta)?
3. PRY-208: ¿existe autorización escrita para mover la línea base 38 días?
4. PRY-204: ¿CC-01 fue aprobado y por quién?
5. ¿Quién es la autoridad de aprobación de los proyectos (hoy 13 de 13 sin identificar)?

---
Pie: criterio-portfolio 0.3.11 · términos 1.1 aceptados 2026-10-16 · fichas aplicadas: PRY-199 a PRY-211 con fecha 2026-10-16 · campos inciertos: ver Vacíos de información y la contradicción de PRY-211 · términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal
