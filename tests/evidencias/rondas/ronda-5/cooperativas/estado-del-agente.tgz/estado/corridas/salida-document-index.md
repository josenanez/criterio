## Carpeta al 2026-10-16

**Documentos:** 75 · **Sin cambio:** 75 · **Hay que releer:** 0

### Cambió el contenido
Ninguno.

### Solo se reguardó
Ninguno.

### Renombrado o movido
Ninguno.

### Ya no está
Ninguno.

### Citas que dejaron de resolver
Todas son de PRY-211 (35 campos de la ficha, 5 documentos citados). El índice las marca como no resueltas, pero los cinco documentos sí existen en `documentos/proyectos/PRY-211-cobranza-digital/` y el índice no los reporta como borrados ni renombrados. Lo más probable es que la ficha cite la ruta relativa a la carpeta del proyecto y el índice no la resuelva; no lo he verificado.

| Proyecto | Campos | Documento citado |
|---|---|---|
| PRY-211 | identity.* (code, name, business_area, product, sponsor, manager, committee), plan.start_date, plan.end_date, plan.scope_summary, plan.exclusions, money.currency, money.approved (14 campos) | 00-gobierno/2026-03-24-acta-constitucion.docx |
| PRY-211 | declared.status, declared.progress_pct, money.committed, money.executed, money.projection (5 campos) | 20-seguimiento/2026-10-13-informe-avance.md |
| PRY-211 | plan.milestones[0..3].name, baseline_date, current_date, state (16 campos) | 10-plan/2026-03-24-cronograma-v1.csv |
| PRY-211 | plan.milestones[0].evidence (1 campo) | 20-seguimiento/2026-10-08-acta-recibo-diseño-funcional-aprobado.md |

### Formatos que no se pudieron leer
Ninguno. Este comando no lee documentos, solo los cuenta y los compara.

### Qué sigue
No hay nada que releer: no hace falta `/portfolio-scan`. Queda por revisar a mano por qué esas citas de PRY-211 no resuelven. No se corrigió ninguna ficha.
