# /portfolio-server — Rostrum (modo: para mirarlo un rato)

**Términos:** ya vigentes (v1.1, familia 0.3.11), aceptados por José Francisco Ñáñez el 2026-10-16. Comprobante en `.criterio/terminos/aceptacion-criterio-portfolio-0.3.11-2026-10-16.md` y `.pdf`.

**Forma elegida:** «para mirarlo un rato» (el argumento fue `rato`). Se levanta, se mira y se apaga con Ctrl-C. Quien lo mira no se queda con un enlace que funcione mañana.

**Informe encontrado:** `reportes/` (13 proyectos PRY-199 a PRY-211, 8 productos, `decisiones.html`, `proyectos.html`, `productos.html`, `index.html`). Nota: no hay `pmo.html`, así que `/pmo` puede no tener contenido hasta que `/portfolio-report html` lo genere.

**Comando:**

```
python3 "/home/claude/banco/criterio/plugins/criterio-portfolio/scripts/servidor.py" --informe /home/claude/banco/ronda-5/cooperativas/espacio/reportes --estado /home/claude/banco/ronda-5/cooperativas/espacio/estado --config /home/claude/banco/ronda-5/cooperativas/espacio/.criterio/portafolio/config.json
```

Escucha en `127.0.0.1:8787`, solo en este equipo. Si el puerto está ocupado, `--puerto 8788`.

| Ruta | Qué es | Para quién |
|---|---|---|
| `/` | Portada y formulario de peticiones | Todos |
| `/pmo` | Cómo va el portafolio | La PMO |
| `/decisiones` | Lo que necesita una decisión | Comité y patrocinador |
| `/proyectos` | Listado por urgencia | Todos |
| `/p/<código>` | Informe de un proyecto, con enlace a su producto | Quien gerencia o pregunta |
| `/productos` | Productos y proyectos sin producto declarado | Quien responde por un producto |
| `/producto/<nombre>` | Informe de un producto, con enlace a sus proyectos | Quien responde por un producto |
| `/estado.json` | Fecha del informe y peticiones abiertas | Un mecanismo |

**Lo que Rostrum no hace:** no calcula (sirve lo que `informe.py` escribió), no escribe fichas (solo crea peticiones en `estado/peticiones/`), no autentica, no manda correos. El servidor no puede correr el agente: las peticiones esperan a que `due` las cuente.

**Cierre:** en este modo el enlace es `http://127.0.0.1:8787/`, y solo lo ve quien esté en este equipo. Para el patrocinador hace falta «que quede corriendo» (`--abierto`, detrás del control de acceso de la organización). El informe es del 2026-10-16 y queda desactualizado en cuanto cambie un documento o corra otro barrido; la portada muestra su fecha.
