**Fuentes:** ficha PRY-204 (estado/records/PRY-204.json), recalculada con `portafolio.py compute` al 2026-10-16. Documentos: informe de avance 2026-10-12, acta de constitución 2025-10-24, cronograma v2 2026-10-12, solicitud de cambio CC-01 2026-10-13, acta de recibo del piloto 2026-10-15.

## Presupuesto — PRY-204 Tarjeta débito para asociados, al 2026-10-16
**Moneda:** COP (única; no hay contratos en otra moneda ni conversión)

| | Monto (COP) | % del aprobado | Fuente | Fecha |
|---|---|---|---|---|
| Aprobado | 18.000.000.000 | 100 % | Acta de constitución (Comité de Riesgos) e informe de avance | 2025-10-24 / 2026-10-12 |
| Comprometido | 12.906.403.597 | 71,7 % | Informe de avance 2026-10-12 | 2026-10-12 |
| Ejecutado | 4.779.778.113 | 26,6 % | Informe de avance 2026-10-12 | 2026-10-12 |
| Proyección al cierre | 20.519.654.277 | 114,0 % (14,0 % sobre el aprobado) | Informe de avance 2026-10-12 | 2026-10-12 |

**Disponible real** (aprobado menos comprometido): 5.093.596.403 COP

### Contra la línea base
| | Original | Vigente | Desviación |
|---|---|---|---|
| Presupuesto | 18.000.000.000 | 18.000.000.000 (ningún documento registra otro) | 0 declarada |
| Fecha de cierre | 2026-09-09 | 2027-01-02 | +115 días (37,1 %) contra la original; 0 contra la vigente |

Replanificaciones de presupuesto: 0 registradas. (La única replanificación, 1, es de cronograma: cronograma v2.)

CC-01 (solicitud 2026-10-13) declara +230.000.000 COP de costo y +115 días, con decisión "approved" por "el comité (sin nombrar cuál)". El presupuesto aprobado no se actualizó en ningún documento, así que no hay una línea base de costo vigente distinta de la original.

### Ejecución frente a avance
Ejecutado 26,6 % · Hitos cumplidos 4 de 4 (3 sin evidencia de recibo) · Avance declarado 83 % · Lectura: la ejecución está muy por debajo de lo que el avance y los hitos declaran. O los hitos están marcados como cumplidos sin sustento, o hay trabajo hecho y no facturado que aparecerá de golpe. Con la evidencia que hay no puedo decidir cuál; hay que preguntarlo.

### Alertas
- **Proyección excede el aprobado:** 20.519.654.277 contra 18.000.000.000, 14,0 % por encima (umbral 10 %).
- **Proyección anterior al último movimiento de presupuesto:** es del 2026-10-12 y CC-01 (+230.000.000 COP) es del 2026-10-13. No se sabe si la proyección ya lo incluye; el documento no lo dice.
- **Comprometido 71,7 %:** por debajo del umbral de 90 %, sin alerta. El disponible real (5.093.596.403) es el que importa, no lo que falta por ejecutar.
- **Ejecución desalineada del avance:** 26,6 % ejecutado contra 83 % declarado y 4 de 4 hitos.
- **Desviación de tiempo:** +115 días (37,1 %) contra la línea base original. CC-01 aprobado sin línea base nueva.
- **Estado declarado "verde"** (informe del 2026-10-12) con cuatro señales abiertas que el informe no recoge: hitos sin evidencia, avance contra plan, desviación de costo y de tiempo.

### Sin dato
- Motivo de la replanificación de cronograma v2 y fecha de cierre nueva: el documento no los declara.
- Presupuesto vigente tras CC-01: no declarado.
- Comité que aprobó CC-01: no nombrado.
- Evidencia de recibo de los hitos "Diseño funcional aprobado", "Ambiente de pruebas certificado" e "Integración con el core cooperativo": `not_found`.
- Desglose por proveedor: no hay proveedores registrados en la ficha.

**Siguiente paso que ofrezco:** preparar la solicitud de cambio de presupuesto, porque la proyección excede el aprobado.

---
Pie de rigor: borrador de trabajo, no decisión ni asesoría. Cada cifra sale de la ficha y del cálculo de `compute`; la verificación contra los documentos es de quien lo lea. Ninguna cifra tiene evidencia de recibo: las cuatro son declaraciones del informe de avance.
