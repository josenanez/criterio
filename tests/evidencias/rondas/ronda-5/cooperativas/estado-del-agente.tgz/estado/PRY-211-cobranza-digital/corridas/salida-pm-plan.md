# Plan — Cobranza digital (PRY-211) · borrador del 2026-10-16
**Desde:** acta de constitución del 2026-03-24 (`00-gobierno/2026-03-24-acta-constitucion.docx`) · **Criterio de éxito:** «Cobranza digital en producción y medido.» (acta). No dice qué es «medido», con qué indicador ni quién lo mide.

Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-16). Este borrador **no compromete ninguna fecha**; las fechas que aparecen abajo son las que ya existían en el acta y en el cronograma v1, citadas, no nuevas.

## Lo que le falta al acta
| Qué | Consecuencia de planificar sin eso |
|---|---|
| **Alcance vacío de contenido:** «Componente 1, Componente 2, Componente 3» | No se puede descomponer por entregable: no sé qué es cada componente. La WBS de abajo no puede tener nodos reales para ellos y los deja «sin definir». |
| **Fuera de alcance:** «Lo que otro proyecto cubre» | No dice qué proyecto ni qué cubre. Cualquier pedido nuevo puede caer a cualquiera de los dos lados sin que nadie lo vea. |
| **Objetivo genérico:** «Entregar cobranza digital para Bienestar social» | No distingue qué cobranza, para quién, ni con qué cobertura. |
| **Criterio de éxito sin indicador:** «en producción y medido» | No hay umbral que permita saber cuándo el proyecto terminó. Es el vacío más caro: define qué entra en el alcance. |
| **Sin autoridad declarada** (la ficha lo registra como no encontrado) | No sé qué puede decidir el gerente al planificar y qué debe subir al patrocinador o al Consejo de Administración. |
| **Dependencias: «Ninguna declarada»** | Contradice el informe del 2026-10-13, que lista como riesgo abierto la «dependencia del proveedor del core cooperativo», y el hito «Integración con el core cooperativo». El plan hereda una dependencia que el acta no reconoce. |
| Patrocinador: María Restrepo — **presente** | Hay a quién llevarle las excepciones. |

No relleno estos huecos. Se siguen marcando abajo.

## WBS
Descomposición por entregable. Los cuatro nodos con nombre salen de los hitos del cronograma v1, que es un documento distinto del acta; por eso van como supuesto y no como «del acta».

| # | Entregable | Quién lo acepta | De dónde sale | Duración |
|---|---|---|---|---|
| 1 | Diseño funcional aprobado | Recibido por Ricardo Salas (acta de recibo 2026-10-08) | Hito del cronograma v1, **ya recibido** — supuesto de que es un entregable de la WBS | cerrada, no aplica |
| 2 | Ambiente de pruebas certificado | Sin definir | Hito del cronograma v1 — supuesto | vacía |
| 3 | Integración con el core cooperativo | Sin definir | Hito del cronograma v1 — supuesto | vacía |
| 4 | Piloto con asociados | Sin definir | Hito del cronograma v1 — supuesto | vacía |
| 5 | Componente 1 | Sin definir | Del acta, pero solo el nombre: **sin definir** qué es | vacía |
| 6 | Componente 2 | Sin definir | Del acta, pero solo el nombre: **sin definir** | vacía |
| 7 | Componente 3 | Sin definir | Del acta, pero solo el nombre: **sin definir** | vacía |
| 8 | Cobranza digital en producción | Sin definir | Del acta (criterio de éxito) | vacía |
| 9 | Medición de la cobranza digital | Sin definir | Del acta («y medido»): **sin definir** indicador y responsable | vacía |

No sé si los hitos 2–4 corresponden a los Componentes 1–3 o son otra cosa. No los emparejo.

Nodos que **no** incluyo porque nadie los ha dicho: capacitación, migración de datos, plan de contingencia, cierre. Si hacen falta, que los diga quien tenga la autoridad.

## Orden
Sin fechas. Qué necesita qué:
- 1 (cerrado) precede a todo lo demás: es el diseño sobre el que se construye.
- 2 (ambiente certificado) precede a 3 y 4: **supuesto**, el cronograma v1 los pone en ese orden pero no declara la dependencia.
- 3 (integración con el core) precede a 4 (piloto con asociados): **supuesto**, mismo motivo.
- 4 precede a 8 (producción), y 8 a 9 (medición): se deduce del criterio de éxito.
- 5, 6 y 7: **no se puede ordenar** sin saber qué son.
- 3 depende del proveedor del core cooperativo (informe 2026-10-13, riesgo abierto). El acta no lo declara.

## Supuestos sobre los que está construido
| Supuesto | Qué pasa si resulta falso |
|---|---|
| Los cuatro hitos del cronograma v1 son entregables de esta WBS | Faltan o sobran nodos; el plan se aprueba incompleto. |
| Los Componentes 1–3 son distintos de los hitos | Si coinciden, la WBS duplica trabajo; si no, hay trabajo sin hito. |
| El orden 2 → 3 → 4 es el real | Si el piloto no necesita la integración, hay holgura; si 2 no precede a 3, el orden cambia. |
| El presupuesto aprobado (1.200.000.000 COP, acta) cubre toda la WBS | El informe 2026-10-13 proyecta 1.108.924.777 COP al cierre y tiene comprometidos 1.061.366.978, con tres componentes y un piloto aún sin definir; el margen puede no alcanzar. |
| «Medido» significa algo que se puede medir con lo que existe | Si exige instrumentación nueva, aparece un entregable que hoy no está. |

Estos pasan al RAID con doliente en cuanto el plan se apruebe.

## Sin definir
| Qué | Quién lo define |
|---|---|
| Contenido de los Componentes 1, 2 y 3 | Sin dato en el acta; corresponde al patrocinador (María Restrepo) o a quien ella designe |
| Qué proyecto cubre lo que queda fuera de alcance | Patrocinador |
| Indicador y umbral de «medido» | Patrocinador / área dueña (Bienestar social) |
| Quién acepta cada entregable (salvo el diseño funcional) | Patrocinador |
| Autoridad del gerente al planificar | Patrocinador / Consejo de Administración |
| Dependencias formales (core cooperativo, supervisor) | Gerente de proyecto, para llevarlas al acta |
| Fase actual del proyecto | Sin dato en ningún documento |

## Proyectos análogos
No hay ninguno a la vista: la configuración de PRY-211 no apunta a una carpeta de fichas de la PMO, y no busqué fuera de ella. Es la respuesta correcta y evita una falsa precisión.

Referencia del propio proyecto, no analogía: el hito «Diseño funcional aprobado» tenía fecha de línea base 2026-07-17 (cronograma v1) y su acta de recibo es del 2026-10-08. El cronograma sigue mostrando la fecha vigente igual a la de línea base, es decir, nunca se replanificó formalmente. Dato, no estimación.

## Preguntas para el equipo
Una por cada duración vacía:
1. ¿Cuánto toma certificar el ambiente de pruebas, y qué lo certifica? (nodo 2)
2. ¿Cuánto toma la integración con el core, y cuál es el compromiso de fecha del proveedor? (nodo 3)
3. ¿Cuánto dura el piloto y con cuántos asociados? (nodo 4)
4. ¿Qué es el Componente 1, y cuánto toma? (nodo 5)
5. ¿Qué es el Componente 2, y cuánto toma? (nodo 6)
6. ¿Qué es el Componente 3, y cuánto toma? (nodo 7)
7. ¿Cuánto toma pasar a producción después del piloto? (nodo 8)
8. ¿Qué se mide, cómo, y durante cuánto tiempo antes de dar el proyecto por cumplido? (nodo 9)
9. ¿Quién acepta cada uno de los nodos 2–9?

## Para comprometer una fecha falta
- Disponibilidad real del equipo (el informe del 2026-10-13 reporta dos semanas perdidas por rotación de un desarrollador clave, y las notas del 2026-10-16 mencionan que el proveedor podría no llegar con el equipo completo).
- La fecha del proveedor del core cooperativo.
- La ventana del ambiente de pruebas y de producción.
- El concepto del ente supervisor: el informe dice que se recibió, pero no está entre los documentos y puede mover el alcance.

Ninguna de las cuatro está en un documento.

## Antes de aprobar
Cuando el plan se apruebe, puedo registrarlo como **línea base original** y pasar los supuestos al RAID con doliente. Hoy no lo hago: la línea base nace cuando alguien aprueba el plan.
