# Cobranza digital (PRY-211) — corte al 2026-10-16

**Declaración:** en esta sesión nadie respondió la pregunta de declaración, y el agente no declara ni propone estado. El informe usa la **última declaración que consta en documento**: el informe de avance del 2026-10-13 (hace 3 días, vigente). No es una declaración nueva.
**Declara el gerente (Ricardo Salas, informe del 13-oct):** rojo · 56 % · al 2026-10-13
**Sustento documental:** rojo declarado; no hay contradicción por verde (`declared_vs_evidence` no aparece). Pero ninguna fuente está marcada como evidencia (0 de 35; 2 son declaración, 33 sin marcar).
**Lo que el semáforo no explica:** `commitment_overdue` (6 compromisos vencidos) y `commitment_rescheduled` (2 compromisos reprogramados 5 y 6 veces).

## Qué cambió esta semana
No hay corrida anterior con la que comparar: esta es la primera instantánea (snapshots/2026-10-16.json) y el diff sale vacío (0 cambios). Esto es una línea de partida, no una semana sin cambios. La próxima corrida podrá decir qué se movió.

## Lo que sigue igual y sigue mal
Compromisos vencidos sin evidencia, de más a menos días:
| Qué | Responsable | Vencía | Días así |
|---|---|---|---|
| Validar el ambiente 4 | Beatriz Cuéllar | 2026-09-16 | 30 |
| Validar el ambiente 12 | Óscar Ramírez | 2026-09-22 | 24 |
| Actualizar la matriz 6 | Felipe Arango | 2026-09-24 | 22 |
| Aprobar el diseño 5 | Sandra Gil | 2026-09-30 | 16 |
| Validar el ambiente 20 | Carlos Peña | 2026-10-05 | 11 |
| Confirmar la fecha 7 | Jorge Medina | 2026-10-07 | 9 |

Tres de los seis son «validar el ambiente», y el hito «Ambiente de pruebas certificado» vence el 2026-10-31.

## Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2027-07-23 | 2027-07-23 | 0 días |
| Presupuesto | COP 1.200.000.000 | COP 1.200.000.000 | 0 (proyección COP 1.108.924.777, −7,6 %) |

Replanificaciones: 0. Hay una sola versión de línea base (aprobada el 2026-03-24 en el acta de constitución). Cambios formales: 0.

Avance: el plan sustenta entre 25 % y 50 % (1 de 4 hitos cumplidos); lo declarado es 56 %, 6 puntos por encima del techo. Está bajo el umbral de 10 puntos, así que no es señal, pero conviene mirarlo.

### Hitos de las próximas cuatro semanas
| Hito | Base | Vigente | Evidencia |
|---|---|---|---|
| Ambiente de pruebas certificado | 2026-10-31 | 2026-10-31 | ninguna (pendiente) |

Los siguientes quedan fuera de la ventana: Integración con el core cooperativo (2027-02-14) y Piloto con asociados (2027-05-31). «Diseño funcional aprobado» (2026-07-17) figura cumplido con acta de recibo del 2026-10-08, es decir, casi tres meses después de la fecha base.

## Las cifras (COP)
| Aprobado | Comprometido | Ejecutado | Proyectado | Disponible real |
|---|---|---|---|---|
| 1.200.000.000 | 1.061.366.978 (88,4 %) | 433.137.984 (36,1 %) | 1.108.924.777 | 138.633.022 |

El disponible real es aprobado menos comprometido, no menos ejecutado. El comprometido está a 1,6 puntos del umbral de 90 %. Todas las cifras salen del informe de avance del 13-oct, es decir, son declaradas, no verificadas contra contabilidad.

## Abierto
**Reprogramados:**
- Mauricio Pérez, «Enviar el documento 1»: 6 veces. Original 2026-09-15; hoy 2026-11-27.
- Paula Céspedes, «Cerrar la prueba 2»: 5 veces. Original 2026-09-09; hoy 2026-11-03.

Ambos superan el umbral de 3 reprogramaciones.

**Vencidos sin evidencia:** los seis de la tabla anterior.
**Sin fecha:** Jorge Medina, «Aprobar el diseño 13» (comité 2026-09-25); Laura Vélez, «Mandar el ajuste del presupuesto» (notas del 2026-10-16).
**RAID sin movimiento:** 3 riesgos y 2 incidencias, todos sin responsable (`no_identificado`). Riesgos: dependencia del proveedor del core; cambio normativo del supervisor; proveedor que podría no llegar con el equipo completo (dicho en reunión, no registrado hasta ahora). Incidencias: hallazgo de seguridad en la revisión de arquitectura; dos semanas perdidas por la rotación de un desarrollador clave. No hay fechas de apertura, así que los días sin movimiento no se pueden calcular.
**Proveedor:** la ficha no registra entregables de proveedor (`vendors` vacío). No se puede decir nada sobre vencidos, aceptados sin documento ni facturado sin entrega.

## Lo que necesito de alguien
- **Ricardo Salas:** declarar estado y avance para esta semana (la declaración vigente es del 13-oct).
- **Mauricio Pérez y Paula Céspedes:** fecha firme o decisión de qué hacer con su compromiso. Llevan 6 y 5 reprogramaciones.
- **Beatriz Cuéllar, Óscar Ramírez, Carlos Peña:** evidencia de la validación de ambientes, o nueva fecha, antes del 2026-10-31.
- **Jorge Medina y Laura Vélez:** fecha para sus compromisos sin fecha.
- **Quien corresponda:** dueño para los 5 riesgos e incidencias sin responsable.
- La autoridad de aprobación no consta (`identity.authority`). Por eso no se puede marcar qué excede al gerente.

## Lo que no se sabe
**Sin dato:** `identity.authority`, `identity.phase`; responsable de los 5 ítems RAID; fecha de los 2 compromisos sin fecha; entregables de proveedor.
**Silencio:** último documento hace 0 días (notas del 2026-10-16) · última reunión hace 0 días (notas del 2026-10-16); último comité semanal documentado, 2026-10-02 (14 días).

---
Fuente: ficha PRY-211 (estado/PRY-211-cobranza-digital/records/PRY-211.json), actualizada el 2026-10-16; declaración del 2026-10-13. 2 campos sin dato. Términos v1.1 (criterio-project 0.3.11), aceptados por José Francisco Ñáñez el 2026-10-16: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.11

Siguiente paso posible: armar el punto de comité con `/pm-escalate` para los dos compromisos reprogramados más de 3 veces. La declaración no queda contradicha por la evidencia, así que `/pm-publish` no es urgente por esa razón.
