Soy Samuel. Leo lo que pasa en tu proyecto y me acuerdo de lo que se prometió en cada reunión.

Prueba sin interfaz: en las cuatro preguntas tomé la respuesta sugerida. Proyecto PRY-211 · Cobranza digital, gerente Ricardo Salas (del acta de constitución); reunión de seguimiento los viernes (las seis minutas son de viernes), próxima el 2026-10-30 (las notas del 16 dicen «en dos semanas»); estado guardado en `estado/PRY-211-cobranza-digital`, fuera de la carpeta de documentación y de `.criterio/`.

## Listo — Cobranza digital (PRY-211)

**Lo que miré:** 14 documentos · 6 minutas de comité (2026-09-04 a 2026-10-09) más las notas de la reunión del 2026-10-16 · la más reciente es del 2026-10-16. Leí todas, de la más vieja a la más nueva, y las 4 actas de recibo. Formatos que no pude leer: ninguno (el `.docx` lo leí extrayendo su texto).
**Términos:** aceptados por José Francisco Ñáñez el 2026-10-16 (términos 1.1, familia 0.3.11) · comprobante en `.criterio/terminos/aceptacion-criterio-project-0.3.11-2026-10-16.md` y `.pdf` · SHA-256 del comprobante `042a62265e2a038b…`

Texto de los términos, tal cual: «Criterio produce borradores de trabajo, no decisiones ni asesoría. Procesa los documentos que usted le indique y dice lo que muestran; no sabe lo que se habló fuera de ellos. Puede equivocarse, y por eso cada dato viene con la cita del documento de donde salió: la verificación es suya. Sus documentos se procesan en la infraestructura de la plataforma de IA, no solo en su equipo. Cada versión se certifica antes de publicarse; garantía y responsabilidad: licencia Apache 2.0. Cada versión se acepta de nuevo y deja un comprobante en Markdown y PDF con su huella SHA-256. Términos completos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal»

En esta prueba el sí lo dio por escrito el encargo, no una persona en la conversación.

### Lo que está abierto, y cuántas veces se ha movido

Hay 26 compromisos en las minutas y notas: 3 cumplidos con acta, 6 vencidos sin acta, 2 sin fecha y 15 vigentes.

**Los que se han movido (el hallazgo):**

| Quién | Qué | Primera promesa → fecha vigente | Veces movido |
|---|---|---|---|
| Mauricio Pérez | Enviar el documento 1 | 2026-09-15 → 2026-11-27 (09-24, 10-03, 10-23, 11-05, 11-13, 11-27) | 6 |
| Paula Céspedes | Cerrar la prueba 2 | 2026-09-09 → 2026-11-03 (09-20, 09-29, 10-06, 10-15, 11-03) | 5 |

Citas: minutas del 09-04, 09-11, 09-18, 09-25, 10-02 y 10-09 (`30-reuniones/`) y `2026-10-16-notas-reunion.txt` («lo de "enviar el documento 1" no alcanzó, se compromete para el 27/11/2026»). Ninguno de los dos ha cumplido nunca la fecha que dio: eso se parece más a un bloqueo que nadie ha nombrado que a un descuido.

**Vencidos sin acta (6).** Cuatro de ellos aparecieron como «ya entregó» en una reunión, pero ningún acta lo prueba, y decirlo en la reunión no lo cierra:

| Quién | Qué | Venció | Días | Cita |
|---|---|---|---|---|
| Beatriz Cuéllar | Validar el ambiente 4 | 2026-09-16 | 30 | minuta 09-04; «ya entregó» en la del 09-11 |
| Óscar Ramírez | Validar el ambiente 12 | 2026-09-22 | 24 | minuta 09-18; misma fecha en 09-25, 10-02 y 10-09; nunca se movió ni se cerró |
| Felipe Arango | Actualizar la matriz 6 | 2026-09-24 | 22 | minuta 09-11; «ya entregó» en la del 09-25 |
| Sandra Gil | Aprobar el diseño 5 | 2026-09-30 | 16 | minuta 09-11; «ya entregó» en la del 09-25 |
| Carlos Peña | Validar el ambiente 20 | 2026-10-05 | 11 | minuta 10-02; «ya entregó» en la del 10-09 |
| Jorge Medina | Confirmar la fecha 7 | 2026-10-07 | 9 | minuta 09-11; «ya entregó» en la del 09-18 |

Una duda: existe el acta de recibo del «Diseño funcional aprobado» (2026-10-08), pero no nombra «Aprobar el diseño 5», así que no lo cierro.

**Cumplidos con acta (3):** Cerrar la prueba 10 (María Restrepo) y Revisar el anexo 11 (Felipe Arango), con acta de recibo del 2026-10-02; Revisar el anexo 19 (Javier Hoyos), acta del 2026-10-09. «Cerrar la prueba 10» se cerró después de su fecha (2026-09-24); «Revisar el anexo 11» y «Revisar el anexo 19» se cerraron antes de la suya (2026-10-13).

**Vigentes que ya se movieron una vez (4):** Entregar el punto 8 (Mauricio Pérez; 10-08 → 10-25), Enviar el documento 9 (Natalia Ospina; 10-15 → 10-25), Entregar el punto 16 (Paula Céspedes; 10-03 → 10-20) y Revisar el anexo 3 (Sandra Gil; sin fecha hasta el 10-02, luego 10-18, luego 10-30: se movió una vez desde que tuvo fecha).

**Vencen pronto:** hoy 2026-10-16, Actualizar la matriz 22 (Laura Vélez) y Confirmar la fecha 23 (Diana Molina); las notas de hoy no las mencionan. Antes del 2026-10-18, Confirmar la fecha 15 (Jorge Medina) y Cerrar la prueba 18 (Gustavo Neira).

### Sin fecha

Nadie los fechó, así que no pueden estar vencidos y por eso se pierden:

- Jorge Medina · Aprobar el diseño 13 — nunca tuvo fecha («por definir», minutas 09-25 y 10-02); en la del 10-09 dijo que ya lo entregó, sin acta.
- Laura Vélez · Mandar el ajuste del presupuesto — «la otra semana» (notas 2026-10-16). No calculé fecha.

### Otros hallazgos

- **El estado declarado no cuadra con lo que dicen las reuniones.** El informe del 2026-10-13 declara rojo y 56%. El cronograma sostiene 25–50% (1 de 4 hitos cerrado: «Diseño funcional aprobado»). El informe no menciona ninguno de los 6 compromisos vencidos ni los dos reprogramados 5 y 6 veces.
- **Un riesgo que nadie registró:** en la reunión de hoy se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase; «nadie lo anotó como riesgo». Lo dejé en la ficha. Se parece al riesgo del informe «Dependencia del proveedor del core cooperativo», pero no lo doy por el mismo.
- **El acta de constitución dice «Ninguna declarada» en dependencias**, y el informe ya declara una (el proveedor del core).
- **Presupuesto (informe del 2026-10-13, cifras de `compute`):** aprobado 1.200.000.000 COP; comprometido 1.061.366.978 (88,4%); ejecutado 433.137.984 (36,1%); proyección al cierre 1.108.924.777 (−7,6% sobre lo aprobado).
- Óscar Ramírez quedó hoy con «revisión con el proveedor» para el 2026-10-26; no sé si es lo mismo que «Validar el ambiente 12», que lleva 24 días vencido. Los dejé como dos.

### Qué le falta a tu carpeta

- Actas de recibo de lo que dicen haber entregado (Beatriz Cuéllar, Sandra Gil, Felipe Arango, Jorge Medina, Carlos Peña, Rubén Cárdenas): sin ellas, un compromiso entregado se ve igual que uno incumplido.
- El cronograma vigente: solo hay la v1 del 2026-03-24, y marca el «Diseño funcional aprobado» como cerrado el 2026-07-17 mientras su acta de recibo es del 2026-10-08.
- Autoridad del gerente y fase del proyecto: no están en el acta de constitución.
- Las minutas no traen fecha de la próxima reunión ni acuerdos; solo la lista de compromisos y lo que «se dijo».

La ficha quedó sin sellar: leí las minutas y notas, no todo el proyecto. Sin proveedores, contratos ni solicitudes de cambio en la carpeta.

**Cuándo vuelvo:** cada viernes, un día antes de tu reunión; la próxima es el 2026-10-30, así que el 2026-10-29.
