## Reunión de seguimiento — Cobranza digital (PRY-211) · 2026-10-30
6 puntos · 45 minutos de 45 · 8 personas requeridas (más 2 condicionadas)

**Supuestos que tomé, porque nadie los respondió:** la fecha es 2026-10-30 (`committee_next` de la configuración; las notas del 10-16 dicen «próxima reunión en dos semanas», pero la cadencia configurada es semanal, así que **si hay reunión el 10-23 esta agenda no es para esa**). La duración es de 45 minutos: ni la configuración ni usted la dan. No hay corrida anterior para comparar (`diff` marca línea de partida), así que «lo que cambió» se mide contra la minuta del 10-09 y las notas del 10-16. **La agenda está armada con lo que se sabe al 10-16; vuelva a correrla el 10-29 con lo que pase esta semana y la próxima.**

### Lo que no se destraba solo

> **[1] Decidir qué pasa con «Enviar el documento 1»: reasignar, partir o nombrar el bloqueo** · 8 min · **Mauricio Pérez y Ricardo Salas**
> Prometido para el 2026-09-15, y antes para el 09-24, 10-03, 10-23, 11-05, 11-13, y ahora 11-27: seis reprogramaciones, 73 días después de la original.
> Fuente: minutas del comité 09-04, 09-11, 09-18, 09-25, 10-02 y 10-09; notas del 10-16 («no alcanzó, se compromete para el 27/11/2026»). El acta del 10-16 ya lo dejó «sin decidir».
> **Si no se resuelve hoy:** se vuelve a fechar por séptima vez; con las seis anteriores, lo único que se sabe es que la fecha no es información.

> **[2] Decidir qué pasa con «Cerrar la prueba 2»** · 8 min · **Paula Céspedes y Ricardo Salas**
> Prometido para el 2026-09-09, y antes para el 09-20, 09-29, 10-06, 10-15, y ahora 11-03: cinco reprogramaciones. La nueva fecha cae cuatro días después de la reunión.
> Fuente: minutas del 09-04 al 10-09. Las notas del 10-16 no la mencionan.
> **Si no se resuelve hoy:** el 11-03 llega sin que nadie haya dicho qué la frena.

### Vencido sin evidencia — punto [3]
Más viejo primero. Al corte del 10-30 sumarán 14 días más cada uno; las cifras de abajo son al 10-16.

| Quién | Qué | Desde | Qué se necesita hoy | Min |
|---|---|---|---|---|
| Beatriz Cuéllar* | Validar el ambiente 4 | 2026-09-16 (30 días) | Acta de recibo; dijo «ya entregué» el 09-11, sin acta (minuta 09-11) | 2 |
| Óscar Ramírez | Validar el ambiente 12 | 2026-09-22 (24 días) | Misma fecha en cuatro minutas seguidas (09-18 a 10-09), nunca movida ni cerrada. Aclarar si «Revisión con el proveedor, 10-26» (notas 10-16) es lo mismo: si lo es, es una reprogramación de 09-22 a 10-26 | 4 |
| Felipe Arango* | Actualizar la matriz 6 | 2026-09-24 (22 días) | Acta de recibo; dijo «ya entregué» el 09-25 (minuta 09-25) | 2 |
| Sandra Gil | Aprobar el diseño 5 | 2026-09-30 (16 días) | Acta; dijo «ya entregué» el 09-25. El acta del 10-08 es de «Diseño funcional aprobado» y no nombra el diseño 5 | 2 |
| Carlos Peña | Validar el ambiente 20 | 2026-10-05 (11 días) | Acta; dijo «ya entregué» el 10-09 (minuta 10-09) | 2 |
| Jorge Medina | Confirmar la fecha 7 (y «Aprobar el diseño 13», sin fecha) | 2026-10-07 (9 días) | Acta de ambos; dijo «ya entregué» la fecha 7 el 09-18 y el diseño 13 el 10-09, sin acta | 2 |

\* Ausentes el 10-16; no consta que vayan a estar el 10-30. Si no van, la acta se pide antes por escrito y estos dos minutos se devuelven. Para los demás, la regla es una sola: acta en la mesa o el compromiso se reabre con fecha nueva. Subtotal de la tabla: 14 min.

### Se decide hoy o se atrasa

| Qué | Quién decide | Si no se decide | Min |
|---|---|---|---|
| **[5] Quién es el doliente del riesgo «el proveedor podría no llegar con el equipo completo para la siguiente fase»** y si se registra | Ricardo Salas | Sigue siendo algo que «se comentó» (notas 10-16, línea 7). Hoy está en la ficha con doliente `no_identificado` | 5 |
| **[6] Fecha del «ajuste del presupuesto» de Laura Vélez y si toca el aprobado** (COP 1.200.000.000) | Laura Vélez dice cuándo; Salas, si pasa a control de cambios | «La otra semana» (notas 10-16) no dice si es la del 10-19 o la del 10-26, ni si cambia el monto aprobado | 4 |

### Vence antes de la próxima
Para la hora de la reunión, lo que tenga acta no se revisa de palabra; lo que no, pasa al bloque de vencidos.

| Quién | Qué | Para cuándo |
|---|---|---|
| Laura Vélez | Actualizar la matriz 22 | 2026-10-16 (hoy; las notas de hoy no la mencionan) |
| Diana Molina | Confirmar la fecha 23 | 2026-10-16 (hoy; las notas de hoy no la mencionan) |
| Jorge Medina | Confirmar la fecha 15 | 2026-10-18 |
| Gustavo Neira | Cerrar la prueba 18 | 2026-10-18 |
| Rubén Cárdenas | Actualizar la matriz 14 | 2026-10-20 (dijo el 10-02 que ya entregó; sin acta) |
| Elena Duarte | Enviar el documento 17 | 2026-10-20 |
| Sandra Gil | Entregar el punto 24 | 2026-10-20 |
| Paula Céspedes | Entregar el punto 16 | 2026-10-20 (ya reprogramado una vez, desde el 10-03) |
| Mauricio Pérez | Entregar el punto 8 | 2026-10-25 (ya reprogramado una vez, desde el 10-08) |
| Natalia Ospina | Enviar el documento 9 | 2026-10-25 (ya reprogramado una vez, desde el 10-15) |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-26 |
| Sandra Gil | Revisar el anexo 3 | 2026-10-30 (el mismo día; reprogramado dos veces) |

> **[4] Hito «Ambiente de pruebas certificado»: vence el 2026-10-31, el día siguiente, sin evidencia** · 6 min · **Ricardo Salas** (y quien responda por los ambientes)
> Fecha base y vigente: 2026-10-31, estado pendiente, sin acta (cronograma v1, 03-24). Hay tres compromisos de «Validar el ambiente» vencidos (4, 12 y 20) y «Cerrar la prueba 2» va para el 11-03. **Que estén ligados no consta en ningún documento**; el punto es preguntar si el hito se sostiene, no afirmarlo.
> **Si no se resuelve hoy:** el hito vence al otro día sin que nadie haya dicho si llega; es el único punto preventivo de la lista.

**Orden de tratamiento y suma:** [1] 8 + [2] 8 + [3] vencidos 14 + [4] hito 6 + [5] 5 + [6] 4 = **45 min**. Con los dos ausentes en la tabla, 41.

### No es de esta reunión

| Qué | Por qué | Dónde va |
|---|---|---|
| Quién puede reasignar o quitar a Pérez y a Céspedes de lo que tienen | La autoridad del proyecto no está declarada en la ficha (`identity.authority`: no encontrada). La patrocinadora, María Restrepo, faltó el 10-16 | Si en el punto 1 o 2 resulta que excede a Salas: `/pm-escalate` y material de comité |
| Dependencia del proveedor del core; cambio normativo del supervisor; hallazgo de seguridad; dos semanas perdidas por rotación | Están en el informe del 10-13 sin doliente y sin fecha. No hay nada que diga que alguien en la sala pueda moverlos hoy, y no hay corrida previa para saber si se movieron | Anexo de abajo; `/pm-escalate` si Salas los quiere formular |
| Si el «ajuste del presupuesto» cambia el aprobado | No se sabe si lo cambia (notas 10-16); si lo cambia es control de cambios, no minuta | `/pm-commitments` o control de cambios, según lo que diga Vélez en el punto 6 |

### Anexo — sin cambios desde el 2026-10-09
Medido contra la minuta del 10-09; no hay corrida previa. No se repasa.
- Carlos Peña · Aprobar el diseño 21 · 2026-11-05.
- Cerrados con acta, no se discuten: María Restrepo · Cerrar la prueba 10 (acta 10-02); Felipe Arango · Revisar el anexo 11 (acta 10-02); Javier Hoyos · Revisar el anexo 19 (acta 10-09).
- Informe de avance del 10-13: estado **rojo**, 56%, ejecutado COP 433.137.984 de 1.200.000.000 aprobados; no da cuenta de los vencidos ni de las reprogramaciones.

### Lo que no sé
- Quién asiste el 10-30 y cuánto dura la reunión: lo segundo lo supuse en 45 min.
- Si la reunión es el 10-23 o el 10-30.
- Si «Revisión con el proveedor» de Ramírez es «Validar el ambiente 12».
- Si el rojo del informe tiene que ver con los bloqueos de arriba: el informe no lo dice.

### Después
No convoco a nadie: la citación es de Ricardo Salas. Cuando la reunión termine, `/pm-minutes` sobre las notas o la transcripción, y los compromisos que salgan entran a `/pm-commitments`.
