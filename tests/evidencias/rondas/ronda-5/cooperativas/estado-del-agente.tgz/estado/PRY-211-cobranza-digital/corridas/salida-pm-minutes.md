# Acta — Cobranza digital (PRY-211) · 2026-10-16
**Asistieron:** Carlos Peña, Diana Molina, Elena Duarte, Gustavo Neira, Jorge Medina, Laura Vélez, Mauricio Pérez, Natalia Ospina, Paula Céspedes, Ricardo Salas, Sandra Gil, Óscar Ramírez · **Fuente:** `2026-10-16-notas-reunion.txt` (notas, 5 líneas de contenido) · **Ausentes con tema en agenda:** las notas no traen agenda, no se puede decir. Sí faltaron cuatro personas con compromisos abiertos o vencidos: Beatriz Cuéllar, Felipe Arango, Rubén Cárdenas y María Restrepo (patrocinadora).

## Compromisos
| Quién | Qué | Para cuándo | |
|---|---|---|---|
| Mauricio Pérez | Enviar el documento 1 | 2026-11-27 | **Reprogramado por 6.ª vez.** Promesa original 2026-09-15; fechas siguientes 09-24, 10-03, 10-23, 11-05, 11-13 y ahora 11-27 (73 días después de la original). Cita: «lo de "enviar el documento 1" no alcanzó, se compromete para el 27/11/2026» (línea 4). |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-26 | Nuevo. Cita: «revisión con el proveedor, queda para el 2026-10-26» (línea 6). Ver *Sin resolver*: puede ser el mismo compromiso que «Validar el ambiente 12». |

### Sin fecha
| Quién | Qué |
|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto. Dijo «la otra semana» (línea 5). Es una referencia relativa, no una fecha, y no se convierte en una. |

## Decisiones
| Qué se decidió | Quién | Qué se descartó |
|---|---|---|
| Ninguna. Las notas no registran ninguna decisión. | | |

## Quedó sin decidir
| Qué | Por qué | Quién tiene la facultad |
|---|---|---|
| Qué hacer con el compromiso «Enviar el documento 1», reprogramado 6 veces | Solo se volvió a fechar; nadie lo escaló ni lo reasignó | No consta en los documentos (la autoridad del proyecto está sin identificar en la ficha) |

## Intenciones sin doliente
| Qué se dijo | Quién lo dijo |
|---|---|
| Ninguna en estas notas. | |

## Dicho al pasar y no registrado
| Qué | Quién lo dijo | Categoría | Ya estaba en el RAID |
|---|---|---|---|
| «Se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo» (línea 7) | No atribuido: las notas dicen «se comentó» | Riesgo | **No.** La ficha trae otros dos riesgos del informe del 2026-10-13 (dependencia del proveedor del core; cambio normativo del supervisor), pero este no. Queda en la ficha sin doliente (`no_identificado`). |

## Cerrado en esta reunión
Se omite: ninguna cosa se cerró con documento.

## Lo que esta reunión contradice
Nada. Las notas no tocan patrocinador, fechas de cierre, comité ni presupuesto aprobado. Dos observaciones menores, no contradicciones: «próxima reunión en dos semanas» (≈ 2026-10-30) coincide con `committee_next` de la configuración, pero la cadencia configurada es semanal; y «el ajuste del presupuesto» de Laura Vélez no dice si cambia el aprobado (COP 1.200.000.000).

## Sin resolver de la transcripción
- «Óscar Ramírez: revisión con el proveedor, queda para el 2026-10-26»: no se entiende si es el mismo compromiso que «Validar el ambiente 12» (vencido desde 2026-09-22, 24 días, nunca movido). Se registra aparte; si es el mismo, sería una reprogramación de 09-22 a 10-26.
- «Laura Vélez queda de mandar el ajuste del presupuesto la otra semana»: no queda claro si «la otra semana» es la del 10-19 o la del 10-26.
- Dos compromisos vencían hoy y las notas no los mencionan: Laura Vélez, «Actualizar la matriz 22», y Diana Molina, «Confirmar la fecha 23». Ambos estaban en la sala. No se cierran ni se reprograman.

## Cifras recalculadas (`portafolio.py compute`)
- Vencidos sin evidencia: 6 (Beatriz Cuéllar 30 días, Óscar Ramírez 24, Felipe Arango 22, Sandra Gil 16, Carlos Peña 11, Jorge Medina 9). Cuatro de ellos ya dicen «entregado» sin acta presentada.
- Sin fecha: 2 (Laura Vélez, Jorge Medina «Aprobar el diseño 13»).
- Reprogramados 3 o más veces: 2 (Mauricio Pérez, 6 veces; Paula Céspedes, «Cerrar la prueba 2», 5 veces).
- El informe del 2026-10-13 declara estado **rojo**; `compute` marca que no da cuenta de los compromisos vencidos ni de las reprogramaciones.
