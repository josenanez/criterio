# Corrida del 2026-10-16 · pm-escalate

1 proyectos · 39 s · 10 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_overdue` | 6 |
| `commitment_undated` | 2 |
| `commitment_rescheduled` | 2 |

Paquete de escalamiento: la autoridad del gerente no está declarada en el acta (primer punto). No se corrió impact: nadie dio días de cambio. No sé quién modifica el acta ni los topes.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

Sesión sin interfaz: los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-16, comprobante en `.criterio/terminos/`); no se registraron de nuevo. No había argumento de qué escalar, así que tomé «lo que ya está marcado como escalable», que es lo que la agenda del 10-30 dejó para `/pm-escalate`.

## Para decisión — Cobranza digital (PRY-211) · 2026-10-16

### ¿Declara el Consejo de Administración por escrito qué puede decidir Ricardo Salas sin subir al comité —reasignar o quitar responsables, mover fechas de hitos, ajustar presupuesto—, con qué tope cada una (opción B), o todo cambio de esos tipos pasa por el Consejo (opción C)?

**Por qué este es el primer punto:** el acta de constitución del 2026-03-24 **no declara la autoridad del gerente** (la ficha lo marca `identity.authority: not_found`). Según el criterio, ese vacío escala antes que cualquier otro tema: sin él no se sabe qué de lo demás excede a Salas y qué no.

**Quién decide:** el Consejo de Administración, que aprobó el acta el 2026-03-24. El acta no dice quién puede modificarla; la patrocinadora es María Restrepo, que no figura entre los asistentes de las notas del 10-16. **Si no se decide hoy:** el comité del **2026-10-30** (`committee_next`) trata «Enviar el documento 1» (siete fechas, seis reprogramaciones) y «Cerrar la prueba 2» (cinco reprogramaciones) sin que conste quién puede reasignarlas; y el **2026-10-31** vence el hito «Ambiente de pruebas certificado», sin acta. Una decisión tomada ahí por quien no tenga la facultad se devuelve.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Dejar el acta como está | Ninguno declarado: cada tema se discute si excede o no | Cada punto agrega una ronda para averiguar quién decide | Ninguno directo; el costo es que lo decidido pueda no valer |
| B. Adenda al acta con autoridad y topes por tipo | Gerente decide dentro de topes; lo demás sube | Una sesión del Consejo o firma de la patrocinadora; **no sé cuánto tarda, no hay documento que lo diga** | Ninguno de presupuesto; los topes los fija el Consejo, **no los propongo con cifras inventadas** |
| C. Todo cambio de reasignación, fecha de hito o presupuesto va al Consejo | Gerente no decide estos tipos | Cada caso espera al Consejo | Ninguno directo; el 10-31 el hito vence antes de cualquier respuesta posible si el Consejo no se reúne antes |

**Recomiendo:** B — el acta ya fija presupuesto y fechas aprobadas por el Consejo, y sin topes declarados Salas o escala todo o no escala nada; B deja escrito qué se sabía hoy. (Es mi lectura, no un dato de los documentos.)

### A quién alcanza
No calculé el efecto con `portafolio.py impact`: esto no mueve ninguna fecha todavía, y el comando necesita los días del cambio, que nadie dio; inventarlos sería falsear el cálculo. Cuando el Consejo o Salas decidan mover algún hito, se corre con esos días. Lo que sí consta: el acta dice «Dependencias declaradas: ninguna», mientras el informe del 10-13 lista como riesgo la «dependencia del proveedor del core cooperativo» y el hito «Integración con el core cooperativo» es del 2027-02-14. Ninguna dependencia con otro proyecto está confirmada en los documentos.

### Mis hitos por los que pasa
Sin días de cambio no hay cálculo. Hitos vigentes (cronograma v1): Ambiente de pruebas certificado 2026-10-31 (pendiente, sin evidencia); Integración con el core cooperativo 2027-02-14; Piloto con asociados 2027-05-31. Cierre del proyecto: 2027-07-23.

### Qué no escala (y por qué no armé paquete)
- **Cobrar los vencidos sin acta** (ambientes 4, 12 y 20, matriz 6, diseño 5, fecha 7): es seguimiento del gerente, no excede su autoridad.
- **Riesgo del proveedor sin doliente** («podría no llegar con el equipo completo», notas 10-16): lo registra y asigna Salas.
- **Hito del 10-31:** hoy es una pregunta para el equipo; escala solo si resulta que moverlo excede lo que el Consejo le dé en la opción B.
- **«Ajuste del presupuesto» de Laura Vélez:** no se sabe si cambia el aprobado (COP 1.200.000.000). Si lo cambia es control de cambios, no escalamiento; la línea base anterior no se toca.

### De dónde sale esto
- Autoridad no declarada y datos del acta (aprobación por el Consejo el 2026-03-24, patrocinadora, comité, presupuesto, «Dependencias: ninguna»): `00-gobierno/2026-03-24-acta-constitucion.docx`; ficha `estado/PRY-211-cobranza-digital/records/PRY-211.json`, campo `identity.authority`.
- Reprogramaciones y fechas: minutas del comité 2026-09-04 a 2026-10-09 y `2026-10-16-notas-reunion.txt`.
- Asistentes del 10-16 (sin María Restrepo): `2026-10-16-notas-reunion.txt`, línea 2.
- Hito 10-31 y fechas de hitos: `10-plan/2026-03-24-cronograma-v1.csv`.
- Riesgos y dependencia del core: `20-seguimiento/2026-10-13-informe-avance.md`.
- Próximo comité 2026-10-30: `.criterio/proyecto/PRY-211/config.json`; la agenda advierte que las notas dicen «dos semanas» y la cadencia configurada es semanal.

### Lo que no sé
- Quién, además del Consejo, puede modificar el acta, y cuándo sesiona.
- Los topes razonables: son decisión del Consejo.
- Cuántos días se moverían hitos u otros proyectos: no hay cambio planteado.

Esto es un borrador de trabajo: el paquete lo lleva usted al comité; yo no escalo ni decido.
