Términos vigentes (v0.3.11, aceptados por José Francisco Ñáñez el 2026-10-16): no hubo que registrar nada nuevo.

Recalculé antes de publicar (`compute`, corte 2026-10-16). Antes de escribir, esto es lo que iba a publicar: 35 campos con dato, 2 sin decir en ninguna parte (`identity.authority`, `identity.phase`), el más viejo del 2026-03-24 (acta de constitución), y el estado declarado: **rojo** al 2026-10-13, declarado por el gerente en `20-seguimiento/2026-10-13-informe-avance.md`.

Publiqué la ficha en `/home/claude/banco/ronda-5/cooperativas/espacio/documentos/proyectos/PRY-211-cobranza-digital/00-gobierno/ficha-pm.json`, con corte al 2026-10-16.

**Lleva:** 35 campos con dato · 2 sin decir en ninguna parte · declara **rojo** al 2026-10-13

**Lo más viejo que va ahí:** los campos de identidad, plan y dinero aprobado, del 2026-03-24 (acta de constitución y cronograma v1), 206 días; no pasa de un año.

Notas:
- La carpeta de gobierno ya existía; no creé nada. No toqué ningún otro archivo de la documentación.
- Es la ficha de `estado/.../records/PRY-211.json` tal cual, que sigue el esquema project-record 0.2. Meta de la ficha: "Ficha sin sellar".
- No avisé a nadie; Vera la leerá en su próximo barrido.
- Los 35 y 2 cuentan los campos con estado de `identity`, `declared`, `plan` y `money`. Los riesgos y compromisos van en la ficha pero no entran en esa cuenta.
