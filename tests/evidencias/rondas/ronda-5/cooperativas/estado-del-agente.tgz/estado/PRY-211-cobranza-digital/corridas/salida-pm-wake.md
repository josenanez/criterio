## Cobranza digital (PRY-211) · 2026-10-16

**Revisé:** 15 documentos · 1 cambió (nuevo: `00-gobierno/ficha-pm.json`, la ficha publicada hoy; no es una minuta) · 0 minutas nuevas. No hubo extracción de compromisos: las notas del 2026-10-16 ya estaban procesadas.

### Lo que se venció solo
Es la primera corrida del barrido (no hay corrida anterior contra la cual comparar), así que esto es el estado a hoy, no solo lo que cruzó:
- **Vencen hoy y las notas de hoy no los mencionan:** Laura Vélez, «Actualizar la matriz 22»; Diana Molina, «Confirmar la fecha 23» (`30-reuniones/2026-10-09-comite-semanal.md`).
- **Vencen en 2 días (2026-10-18):** Jorge Medina, «Confirmar la fecha 15»; Gustavo Neira, «Cerrar la prueba 18».
- **Siguen vencidos sin acta (6):** Beatriz Cuéllar (ambiente 4, 09-16), Felipe Arango (matriz 6, 09-24), Sandra Gil (diseño 5, 09-30), Jorge Medina (fecha 7, 10-07), Carlos Peña (ambiente 20, 10-05) y Óscar Ramírez (ambiente 12, 09-22, sin moverse en cuatro comités). Cinco de ellos dicen haber entregado; ningún acta lo prueba.
- **Reprogramados:** Mauricio Pérez, «Enviar el documento 1», va por 6 reprogramaciones (de 2026-09-15 a 2026-11-27, `2026-10-16-notas-reunion.txt`); Paula Céspedes, «Cerrar la prueba 2», por 5 (de 2026-09-09 a 2026-11-03).
- **Hitos:** ninguno vencido. «Ambiente de pruebas certificado» vence el 2026-10-31, sin evidencia todavía.

### La reunión
Hoy hubo reunión y sus notas ya están procesadas. El siguiente comité según la configuración es el 2026-10-30 (faltan 14 días); no toca agenda todavía ni informe (le toca el 2026-10-29). Una observación: la configuración dice comité semanal pero la fecha siguiente salta dos semanas; vale confirmarla.

### Tu ficha publicada
Al día: se publicó hoy y coincide con la ficha de trabajo.

**Vuelvo el 2026-10-17.**
