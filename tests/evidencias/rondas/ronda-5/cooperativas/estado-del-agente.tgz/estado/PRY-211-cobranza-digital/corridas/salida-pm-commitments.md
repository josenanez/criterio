## Compromisos — PRY-211 Cobranza digital · al 2026-10-16

Cifras de `portafolio.py compute`: 6 vencidos sin evidencia, 2 sin fecha, 2 reprogramados. El informe de avance del 2026-10-13 declara rojo y no da cuenta de los vencidos ni de las reprogramaciones.

### Se viene reprogramando

> **Mauricio Pérez** · Enviar el documento 1
> Prometido para el 2026-09-15, y antes para el 09-24, 10-03, 10-23, 11-05, 11-13 y ahora 11-27 (6 reprogramaciones; la última, en las notas del 10-16: «no alcanzó, se compromete para el 27/11/2026»).
> **Seis veces no es un problema de seguimiento: es un bloqueo que nadie ha nombrado.**

> **Paula Céspedes** · Cerrar la prueba 2
> Prometido para el 2026-09-09, y antes para el 09-20, 09-29, 10-06, 10-15 y ahora 11-03 (5 reprogramaciones).
> **Cinco veces no es un problema de seguimiento: es un bloqueo que nadie ha nombrado.**

Fuentes: minutas del comité semanal 09-04 a 10-09 y notas del 10-16.

### Vencidos sin evidencia
| Quién | Qué | Prometido para | Hace |
|---|---|---|---|
| Beatriz Cuéllar | Validar el ambiente 4 | 2026-09-16 | 30 días |
| Óscar Ramírez | Validar el ambiente 12 | 2026-09-22 | 24 días |
| Felipe Arango | Actualizar la matriz 6 | 2026-09-24 | 22 días |
| Sandra Gil | Aprobar el diseño 5 | 2026-09-30 | 16 días |
| Carlos Peña | Validar el ambiente 20 | 2026-10-05 | 11 días |
| Jorge Medina | Confirmar la fecha 7 | 2026-10-07 | 9 días |

- Cuéllar, Gil, Arango, Medina y Peña dijeron en comité que ya entregaron; **no hay acta ni documento en el expediente que lo respalde**, así que siguen abiertos. El acta de recibo del 10-08 es de «Diseño funcional aprobado» y no nombra el diseño 5 de Gil.
- Óscar Ramírez: figura con la misma fecha (09-22) en cuatro minutas seguidas, sin cerrarse ni moverse. Además, las notas del 10-16 registran una «Revisión con el proveedor» (para el 10-26); no se sabe si es la misma cosa, y se deja aparte.

### Vencen esta semana
| Quién | Qué | Para cuándo |
|---|---|---|
| Laura Vélez | Actualizar la matriz 22 | 2026-10-16 (hoy; las notas de hoy no la mencionan) |
| Diana Molina | Confirmar la fecha 23 | 2026-10-16 (hoy; las notas de hoy no la mencionan) |
| Jorge Medina | Confirmar la fecha 15 | 2026-10-18 |
| Gustavo Neira | Cerrar la prueba 18 | 2026-10-18 |
| Rubén Cárdenas | Actualizar la matriz 14 | 2026-10-20 (dijo el 10-02 que ya entregó; sin acta) |
| Elena Duarte | Enviar el documento 17 | 2026-10-20 |
| Sandra Gil | Entregar el punto 24 | 2026-10-20 |
| Paula Céspedes | Entregar el punto 16 | 2026-10-20 (ya reprogramado una vez, desde el 10-03) |

### Sin fecha
| Quién | Qué | Dicho el |
|---|---|---|
| Jorge Medina | Aprobar el diseño 13 | 2026-09-25 (el 10-09 dijo que ya lo entregó; sin acta) |
| Laura Vélez | Mandar el ajuste del presupuesto | 2026-10-16 («la otra semana», sin día) |

No pueden estar vencidos, por eso se cuentan aparte.

### Cerrados desde la última revisión
Los tres cierres tienen acta de recibo; ninguno es posterior a la corrida anterior de este comando (no hubo una), así que se listan como cerrados con evidencia:
- María Restrepo · Cerrar la prueba 10 — `20-seguimiento/2026-10-02-acta-recibo-10.md`
- Felipe Arango · Revisar el anexo 11 — `20-seguimiento/2026-10-02-acta-recibo-11.md`
- Javier Hoyos · Revisar el anexo 19 — `20-seguimiento/2026-10-09-acta-recibo-19.md`

### Otros abiertos con reprogramación menor (bajo el umbral de 3)
Sandra Gil · Revisar el anexo 3 (sin fecha hasta el 10-02; luego 10-18 y 10-30), Mauricio Pérez · Entregar el punto 8, Natalia Ospina · Enviar el documento 9 (ambos corridos al 10-25).

### Después
- Hay dos compromisos reprogramados más de tres veces (Pérez, Céspedes). **Ofrezco formularlos como decisión para el comité** (qué se pide, qué pasa si no se decide, quién tiene la facultad), con `/pm-escalate`. Cabe notar que la autoridad del proyecto no está declarada en la ficha (`identity.authority` falta).
- El informe de avance del 10-13 no da cuenta de los vencidos ni de las reprogramaciones; si quiere que la PMO lo vea, `/pm-publish`.
