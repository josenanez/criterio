<!-- origen: PRY-201-apertura-de-ahorro-en-línea/10-plan/2025-09-04-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2025-12-01,2025-12-01,cerrado
Ambiente de pruebas certificado,2026-02-17,2026-02-17,cerrado
Integración con el core cooperativo,2026-05-06,2026-05-06,cerrado
Piloto con asociados,2026-07-23,2026-07-23,cerrado
