<!-- origen: PRY-209-convenios-de-libranza-con-empresas/20-seguimiento/2026-10-16-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Convenios de libranza con empresas
Código: PRY-209
Fecha de corte: 2026-10-16
Gerente: Liliana Torres

Estado declarado
Verde
Avance reportado: 26%

Lo que pasó en el periodo
- Se reprogramó la salida por el cierre contable de fin de mes

Presupuesto
COP
Aprobado 9.500.000.000
Comprometido 7.440.131.748
Ejecutado 4.227.799.887
Proyección al cierre 9.611.254.152

Riesgos abiertos
- Aprobación del reglamento por el Consejo de Administración
