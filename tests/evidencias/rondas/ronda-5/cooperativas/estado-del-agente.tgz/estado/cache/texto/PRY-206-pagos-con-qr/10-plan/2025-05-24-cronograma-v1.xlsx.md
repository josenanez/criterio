<!-- origen: PRY-206-pagos-con-qr/10-plan/2025-05-24-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2025-08-26 | 2025-08-26 | cerrado
Ambiente de pruebas certificado | 2025-11-19 | 2025-11-19 | cerrado
Integración con el core cooperativo | 2026-02-12 | 2026-02-12 | cerrado
