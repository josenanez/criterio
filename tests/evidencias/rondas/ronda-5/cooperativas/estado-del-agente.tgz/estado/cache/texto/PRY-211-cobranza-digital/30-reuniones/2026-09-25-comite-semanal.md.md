<!-- origen: PRY-211-cobranza-digital/30-reuniones/2026-09-25-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Consejo de Administración · Cobranza digital

**Fecha:** 2026-09-25
**Asistentes:** Felipe Arango, Jorge Medina, María Restrepo, Mauricio Pérez, Natalia Ospina, Paula Céspedes, Ricardo Salas, Rubén Cárdenas, Sandra Gil, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Mauricio Pérez | Enviar el documento 1 | 2026-10-23 |
| Paula Céspedes | Cerrar la prueba 2 | 2026-10-06 |
| Sandra Gil | Revisar el anexo 3 | por definir |
| Mauricio Pérez | Entregar el punto 8 | 2026-10-08 |
| Natalia Ospina | Enviar el documento 9 | 2026-10-15 |
| María Restrepo | Cerrar la prueba 10 | 2026-09-24 |
| Felipe Arango | Revisar el anexo 11 | 2026-10-13 |
| Óscar Ramírez | Validar el ambiente 12 | 2026-09-22 |
| Jorge Medina | Aprobar el diseño 13 | por definir |
| Rubén Cárdenas | Actualizar la matriz 14 | 2026-10-20 |
| Jorge Medina | Confirmar la fecha 15 | 2026-10-18 |
| Paula Céspedes | Entregar el punto 16 | 2026-10-03 |

## Lo que se dijo

- Sandra Gil dice que ya entregó «aprobar el diseño 5». No se presentó acta.
- Felipe Arango dice que ya entregó «actualizar la matriz 6». No se presentó acta.
