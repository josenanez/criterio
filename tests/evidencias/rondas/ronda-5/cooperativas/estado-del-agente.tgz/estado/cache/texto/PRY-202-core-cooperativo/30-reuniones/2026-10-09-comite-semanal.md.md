<!-- origen: PRY-202-core-cooperativo/30-reuniones/2026-10-09-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Educación · Core cooperativo

**Fecha:** 2026-10-09
**Asistentes:** Andrés Lozano, Ricardo Salas

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Elena Duarte | Entregar el punto 16 | 2026-10-29 |
