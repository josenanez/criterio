<!-- origen: PRY-202-core-cooperativo/10-plan/2026-06-15-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-08-26 | 2026-08-26 | cerrado
Ambiente de pruebas certificado | 2026-10-28 | 2026-10-28 | en curso
Integración con el core cooperativo | 2026-12-29 | 2026-12-29 | en curso
Piloto con asociados | 2027-03-02 | 2027-03-02 | en curso
Salida a producción | 2027-05-03 | 2027-05-03 | en curso
