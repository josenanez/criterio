<!-- origen: PRY-207-microcrédito-rural/10-plan/2026-05-03-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-08-22 | 2026-08-22 | cerrado
Ambiente de pruebas certificado | 2026-12-01 | 2026-12-01 | en curso
Integración con el core cooperativo | 2027-03-13 | 2027-03-13 | en curso
Piloto con asociados | 2027-06-22 | 2027-06-22 | en curso
