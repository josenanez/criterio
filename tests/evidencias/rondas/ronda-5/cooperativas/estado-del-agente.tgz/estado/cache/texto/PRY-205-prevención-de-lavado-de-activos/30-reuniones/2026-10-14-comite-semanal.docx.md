<!-- origen: PRY-205-prevención-de-lavado-de-activos/30-reuniones/2026-10-14-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Consejo de Administración · Prevención de lavado de activos

Fecha: 2026-10-14

Asistentes: Ricardo Salas, Camilo Beltrán

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Sandra Gil

Entregar el punto 19

por definir
