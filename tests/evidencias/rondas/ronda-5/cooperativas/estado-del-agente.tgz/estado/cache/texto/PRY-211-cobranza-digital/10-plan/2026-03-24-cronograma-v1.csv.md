<!-- origen: PRY-211-cobranza-digital/10-plan/2026-03-24-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2026-07-17,2026-07-17,cerrado
Ambiente de pruebas certificado,2026-10-31,2026-10-31,en curso
Integración con el core cooperativo,2027-02-14,2027-02-14,en curso
Piloto con asociados,2027-05-31,2027-05-31,en curso
