<!-- origen: PRY-211-cobranza-digital/00-gobierno/ficha-pm.json · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

{
 "schema_version": "0.2",
 "identity": {
 "code": {
 "value": "PRY-211",
 "source": "00-gobierno/2026-03-24-acta-constitucion.docx",
 "source_date": "2026-03-24",
 "state": "found"
 },
 "name": {
 "value": "Cobranza digital",
 "source": "00-gobierno/2026-03-24-acta-constitucion.docx",
 "source_date": "2026-03-24",
 "state": "found"
 },
 "business_area": {
 "value": "Bienestar social",
 "source": "00-gobierno/2026-03-24-acta-constitucion.docx",
 "source_date": "2026-03-24",
 "state": "found"
 },
 "product": {
 "value": "recaudos",
 "source": "00-gobierno/2026-03-24-acta-constitucion.docx",
 "source_date": "2026-03-24",
 "state": "found"
 },
 "authority": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "sponsor": {
 "value": "María Restrepo",
 "source": "00-gobierno/2026-03-24-acta-constitucion.docx",
 "source_date": "2026-03-24",
 "state": "found"
 },
 "manager": {
 "value": "Ricardo Salas",
 "source": "00-gobierno/2026-03-24-acta-constitucion.docx",
 "source_date": "2026-03-24",
 "state": "found"
 },
 "committee": {
 "value": "Consejo de Administración",
 "source": "00-gobierno/2026-03-24-acta-constitucion.docx",
 "source_date": "2026-03-24",
 "state": "found"
 },
 "phase": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 }
 },
 "declared": {
 "status": {
 "value": "rojo",
 "source": "20-seguimiento/2026-10-13-informe-avance.md",
 "source_date": "2026-10-13",
 "state": "found",
 "source_kind": "declaration"
 },
 "progress_pct": {
 "value": 56,
 "source": "20-seguimiento/2026-10-13-informe-avance.md",
 "source_date": "2026-10-13",
 "state": "found",
 "source_kind": "declaration"
 },
 "as_of": "2026-10-13",
 "source": "20-seguimiento/2026-10-13-informe-avance.md"
 },
 "plan": {
 "start_date": {
 "value": "2026-04-03",
 "source": "00-gobierno/2026-03-24-acta-constitucion.docx",
 "source_date": "2026-03-24",
 "state": "found"
 },
 "end_date": {
 "value": "2027-07-23",
 "source": "00-gobierno/2026-03-24-acta-constitucion.docx",
 "source_date": "2026-03-24",
 "state": "found"
 },
 "baseline": [
 {
 "version": 1,
 "approved_on": "2026-03-24",
 "start_date": "2026-04-03",
 "end_date": "2027-07-23",
 "reason": "Aprobación inicial en el acta de constitución",
 "source": "00-gobierno/2026-03-24-acta-constitucion.docx"
 }
 ],
 "milestones": [
 {
 "name": {
 "value": "Diseño funcional aprobado",
 "source": "10-plan/2026-03-24-cronograma-v1.csv",
 "source_date": "2026-03-24",
 "state": "found"
 },
 "baseline_date": {
 "value": "2026-07-17",
 "source": "10-plan/2026-03-24-cronograma-v1.csv",
 "source_date": "2026-03-24",
 "state": "found"
 },
 "current_date": {
 "value": "2026-07-17",
 "source": "10-plan/2026-03-24-cronograma-v1.csv",
 "source_date": "2026-03-24",
 "state": "found"
 },
 "state": {
 "value": "met",
 "source": "10-plan/2026-03-24-cronograma-v1.csv",
 "source_date": "2026-03-24",
 "state": "found"
 },
 "evidence": {
 "value": "20-seguimiento/2026-10-08-acta-recibo-diseño-funcional-aprobado.md",
 "source": "20-seguimiento/2026-10-08-acta-recibo-diseño-funcional-aprobado.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "source": "10-plan/2026-03-24-cronograma-v1.csv"
 },
 {
 "name": {
 "value": "Ambiente de pruebas certificado",
 "source": "10-plan/2026-03-24-cronograma-v1.csv",
 "source_date": "2026-03-24",
 "state": "found"
 },
 "baseline_date": {
 "value": "2026-10-31",
 "source": "10-plan/2026-03-24-cronograma-v1.csv",
 "source_date": "2026-03-24",
 "state": "found"
 },
 "current_date": {
 "value": "2026-10-31",
 "source": "10-plan/2026-03-24-cronograma-v1.csv",
 "source_date": "2026-03-24",
 "state": "found"
 },
 "state": {
 "value": "pending",
 "source": "10-plan/2026-03-24-cronograma-v1.csv",
 "source_date": "2026-03-24",
 "state": "found"
 },
 "evidence": {
 "value": null
 },
 "source": "10-plan/2026-03-24-cronograma-v1.csv"
 },
 {
 "name": {
 "value": "Integración con el core cooperativo",
 "source": "10-plan/2026-03-24-cronograma-v1.csv",
 "source_date": "2026-03-24",
 "state": "found"
 },
 "baseline_date": {
 "value": "2027-02-14",
 "source": "10-plan/2026-03-24-cronograma-v1.csv",
 "source_date": "2026-03-24",
 "state": "found"
 },
 "current_date": {
 "value": "2027-02-14",
 "source": "10-plan/2026-03-24-cronograma-v1.csv",
 "source_date": "2026-03-24",
 "state": "found"
 },
 "state": {
 "value": "pending",
 "source": "10-plan/2026-03-24-cronograma-v1.csv",
 "source_date": "2026-03-24",
 "state": "found"
 },
 "evidence": {
 "value": null
 },
 "source": "10-plan/2026-03-24-cronograma-v1.csv"
 },
 {
 "name": {
 "value": "Piloto con asociados",
 "source": "10-plan/2026-03-24-cronograma-v1.csv",
 "source_date": "2026-03-24",
 "state": "found"
 },
 "baseline_date": {
 "value": "2027-05-31",
 "source": "10-plan/2026-03-24-cronograma-v1.csv",
 "source_date": "2026-03-24",
 "state": "found"
 },
 "current_date": {
 "value": "2027-05-31",
 "source": "10-plan/2026-03-24-cronograma-v1.csv",
 "source_date": "2026-03-24",
 "state": "found"
 },
 "state": {
 "value": "pending",
 "source": "10-plan/2026-03-24-cronograma-v1.csv",
 "source_date": "2026-03-24",
 "state": "found"
 },
 "evidence": {
 "value": null
 },
 "source": "10-plan/2026-03-24-cronograma-v1.csv"
 }
 ],
 "scope_summary": {
 "value": "Componente 1, Componente 2, Componente 3",
 "source": "00-gobierno/2026-03-24-acta-constitucion.docx",
 "source_date": "2026-03-24",
 "state": "found"
 },
 "exclusions": {
 "value": "Lo que otro proyecto cubre",
 "source": "00-gobierno/2026-03-24-acta-constitucion.docx",
 "source_date": "2026-03-24",
 "state": "found"
 }
 },
 "money": {
 "currency": {
 "value": "COP",
 "source": "00-gobierno/2026-03-24-acta-constitucion.docx",
 "source_date": "2026-03-24",
 "state": "found"
 },
 "approved": {
 "value": 1200000000,
 "source": "00-gobierno/2026-03-24-acta-constitucion.docx",
 "source_date": "2026-03-24",
 "state": "found"
 },
 "committed": {
 "value": 1061366978,
 "source": "20-seguimiento/2026-10-13-informe-avance.md",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "executed": {
 "value": 433137984,
 "source": "20-seguimiento/2026-10-13-informe-avance.md",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "projection": {
 "value": 1108924777,
 "source": "20-seguimiento/2026-10-13-informe-avance.md",
 "source_date": "2026-10-13",
 "state": "found"
 }
 },
 "raid": {
 "risks": [
 {
 "what": "Dependencia del proveedor del core cooperativo",
 "owner": "no_identificado",
 "source": "20-seguimiento/2026-10-13-informe-avance.md"
 },
 {
 "what": "Cambio normativo del supervisor que puede mover el alcance",
 "owner": "no_identificado",
 "source": "20-seguimiento/2026-10-13-informe-avance.md"
 },
 {
 "what": "El proveedor podría no llegar con el equipo completo para la siguiente fase (se comentó en la reunión; nadie lo registró como riesgo)",
 "owner": "no_identificado",
 "source": "2026-10-16-notas-reunion.txt"
 }
 ],
 "assumptions": [],
 "issues": [
 {
 "what": "Hallazgo de seguridad levantado en la revisión de arquitectura",
 "owner": "no_identificado",
 "source": "20-seguimiento/2026-10-13-informe-avance.md"
 },
 {
 "what": "El equipo perdió dos semanas por rotación de un desarrollador clave",
 "owner": "no_identificado",
 "source": "20-seguimiento/2026-10-13-informe-avance.md"
 }
 ],
 "dependencies": []
 },
 "changes": [],
 "commitments": [
 {
 "who": "Mauricio Pérez",
 "what": "Enviar el documento 1",
 "due_date": "2026-11-27",
 "original_due_date": "2026-09-15",
 "stated_on": "2026-09-04",
 "source": "30-reuniones/2026-09-04-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-09-24",
 "stated_on": "2026-09-11",
 "source": "30-reuniones/2026-09-11-comite-semanal.md"
 },
 {
 "due_date": "2026-10-03",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md"
 },
 {
 "due_date": "2026-10-23",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md"
 },
 {
 "due_date": "2026-11-05",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md"
 },
 {
 "due_date": "2026-11-13",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md"
 },
 {
 "due_date": "2026-11-27",
 "stated_on": "2026-10-16",
 "source": "2026-10-16-notas-reunion.txt"
 }
 ],
 "note": "En las notas del 2026-10-16: «no alcanzó, se compromete para el 27/11/2026»."
 },
 {
 "who": "Paula Céspedes",
 "what": "Cerrar la prueba 2",
 "due_date": "2026-11-03",
 "original_due_date": "2026-09-09",
 "stated_on": "2026-09-04",
 "source": "30-reuniones/2026-09-04-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-09-20",
 "stated_on": "2026-09-11",
 "source": "30-reuniones/2026-09-11-comite-semanal.md"
 },
 {
 "due_date": "2026-09-29",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md"
 },
 {
 "due_date": "2026-10-06",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md"
 },
 {
 "due_date": "2026-10-15",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md"
 },
 {
 "due_date": "2026-11-03",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Sandra Gil",
 "what": "Revisar el anexo 3",
 "due_date": "2026-10-30",
 "original_due_date": "no_declarada",
 "stated_on": "2026-09-04",
 "source": "30-reuniones/2026-09-04-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-18",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md"
 },
 {
 "due_date": "2026-10-30",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md"
 }
 ],
 "note": "Sin fecha en las minutas del 09-04, 09-11, 09-18 y 09-25 («por definir»); la primera fecha se puso el 10-02."
 },
 {
 "who": "Beatriz Cuéllar",
 "what": "Validar el ambiente 4",
 "due_date": "2026-09-16",
 "original_due_date": "2026-09-16",
 "stated_on": "2026-09-04",
 "source": "30-reuniones/2026-09-04-comite-semanal.md",
 "state": "overdue",
 "reschedules": [],
 "claimed_delivered": {
 "on": "2026-09-11",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "text": "Beatriz Cuéllar dice que ya entregó «validar el ambiente 4». No se presentó acta."
 },
 "note": "Dejó de aparecer en la lista desde el 09-11; ningún acta lo prueba."
 },
 {
 "who": "Sandra Gil",
 "what": "Aprobar el diseño 5",
 "due_date": "2026-09-30",
 "original_due_date": "2026-09-30",
 "stated_on": "2026-09-11",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "state": "overdue",
 "reschedules": [],
 "claimed_delivered": {
 "on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "text": "Sandra Gil dice que ya entregó «aprobar el diseño 5». No se presentó acta."
 },
 "note": "El acta de recibo del 2026-10-08 es del entregable «Diseño funcional aprobado» y no nombra este compromiso."
 },
 {
 "who": "Felipe Arango",
 "what": "Actualizar la matriz 6",
 "due_date": "2026-09-24",
 "original_due_date": "2026-09-24",
 "stated_on": "2026-09-11",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "state": "overdue",
 "reschedules": [],
 "claimed_delivered": {
 "on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "text": "Felipe Arango dice que ya entregó «actualizar la matriz 6». No se presentó acta."
 }
 },
 {
 "who": "Jorge Medina",
 "what": "Confirmar la fecha 7",
 "due_date": "2026-10-07",
 "original_due_date": "2026-10-07",
 "stated_on": "2026-09-11",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "state": "overdue",
 "reschedules": [],
 "claimed_delivered": {
 "on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "text": "Jorge Medina dice que ya entregó «confirmar la fecha 7». No se presentó acta."
 }
 },
 {
 "who": "Mauricio Pérez",
 "what": "Entregar el punto 8",
 "due_date": "2026-10-25",
 "original_due_date": "2026-10-08",
 "stated_on": "2026-09-11",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-25",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Natalia Ospina",
 "what": "Enviar el documento 9",
 "due_date": "2026-10-25",
 "original_due_date": "2026-10-15",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-25",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md"
 }
 ]
 },
 {
 "who": "María Restrepo",
 "what": "Cerrar la prueba 10",
 "due_date": "2026-09-24",
 "original_due_date": "2026-09-24",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-10-02-acta-recibo-10.md",
 "closed_on": "2026-10-02",
 "closed_source": "30-reuniones/2026-10-02-comite-semanal.md"
 },
 {
 "who": "Felipe Arango",
 "what": "Revisar el anexo 11",
 "due_date": "2026-10-13",
 "original_due_date": "2026-10-13",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-10-02-acta-recibo-11.md",
 "closed_on": "2026-10-02",
 "closed_source": "30-reuniones/2026-10-02-comite-semanal.md"
 },
 {
 "who": "Óscar Ramírez",
 "what": "Validar el ambiente 12",
 "due_date": "2026-09-22",
 "original_due_date": "2026-09-22",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "state": "overdue",
 "reschedules": [],
 "note": "Aparece con la misma fecha (2026-09-22) en las minutas del 09-18, 09-25, 10-02 y 10-09; no se cerró ni se movió."
 },
 {
 "who": "Jorge Medina",
 "what": "Aprobar el diseño 13",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "state": "open",
 "reschedules": [],
 "claimed_delivered": {
 "on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "text": "Jorge Medina dice que ya entregó «aprobar el diseño 13». No se presentó acta."
 },
 "note": "Nunca tuvo fecha; dicho como entregado sin acta."
 },
 {
 "who": "Rubén Cárdenas",
 "what": "Actualizar la matriz 14",
 "due_date": "2026-10-20",
 "original_due_date": "2026-10-20",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "state": "open",
 "reschedules": [],
 "claimed_delivered": {
 "on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "text": "Rubén Cárdenas dice que ya entregó «actualizar la matriz 14». No se presentó acta."
 },
 "note": "Su fecha (2026-10-20) aún no llega."
 },
 {
 "who": "Jorge Medina",
 "what": "Confirmar la fecha 15",
 "due_date": "2026-10-18",
 "original_due_date": "2026-10-18",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Paula Céspedes",
 "what": "Entregar el punto 16",
 "due_date": "2026-10-20",
 "original_due_date": "2026-10-03",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-20",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Elena Duarte",
 "what": "Enviar el documento 17",
 "due_date": "2026-10-20",
 "original_due_date": "2026-10-20",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Gustavo Neira",
 "what": "Cerrar la prueba 18",
 "due_date": "2026-10-18",
 "original_due_date": "2026-10-18",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Javier Hoyos",
 "what": "Revisar el anexo 19",
 "due_date": "2026-10-13",
 "original_due_date": "2026-10-13",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-10-09-acta-recibo-19.md",
 "closed_on": "2026-10-09",
 "closed_source": "30-reuniones/2026-10-09-comite-semanal.md"
 },
 {
 "who": "Carlos Peña",
 "what": "Validar el ambiente 20",
 "due_date": "2026-10-05",
 "original_due_date": "2026-10-05",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "state": "overdue",
 "reschedules": [],
 "claimed_delivered": {
 "on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "text": "Carlos Peña dice que ya entregó «validar el ambiente 20». No se presentó acta."
 }
 },
 {
 "who": "Carlos Peña",
 "what": "Aprobar el diseño 21",
 "due_date": "2026-11-05",
 "original_due_date": "2026-11-05",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Laura Vélez",
 "what": "Actualizar la matriz 22",
 "due_date": "2026-10-16",
 "original_due_date": "2026-10-16",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "state": "open",
 "reschedules": [],
 "note": "Vence hoy; las notas del 2026-10-16 no la mencionan."
 },
 {
 "who": "Diana Molina",
 "what": "Confirmar la fecha 23",
 "due_date": "2026-10-16",
 "original_due_date": "2026-10-16",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "state": "open",
 "reschedules": [],
 "note": "Vence hoy; las notas del 2026-10-16 no la mencionan."
 },
 {
 "who": "Sandra Gil",
 "what": "Entregar el punto 24",
 "due_date": "2026-10-20",
 "original_due_date": "2026-10-20",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Laura Vélez",
 "what": "Mandar el ajuste del presupuesto",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-10-16",
 "source": "2026-10-16-notas-reunion.txt",
 "state": "open",
 "reschedules": [],
 "due_text": "la otra semana"
 },
 {
 "who": "Óscar Ramírez",
 "what": "Revisión con el proveedor",
 "due_date": "2026-10-26",
 "original_due_date": "2026-10-26",
 "stated_on": "2026-10-16",
 "source": "2026-10-16-notas-reunion.txt",
 "state": "open",
 "reschedules": [],
 "note": "No se sabe si es la misma cosa que «Validar el ambiente 12»; se registra aparte."
 }
 ],
 "meta": {
 "record_updated": "2026-10-16",
 "documents_seen": [
 {
 "path": "00-gobierno/2026-03-24-acta-constitucion.docx",
 "hash": "6689be8498f5cf06f7391f658d69217e4f29a62d4573ac48120628d0f8417886",
 "text_hash": null,
 "date": "2026-03-24"
 },
 {
 "path": "10-plan/2026-03-24-cronograma-v1.csv",
 "hash": "0639b0af473a37df883d7a2ca2b5f9bcbd372602c2e411f80ac31f0745253497",
 "text_hash": null,
 "date": "2026-03-24"
 },
 {
 "path": "20-seguimiento/2026-10-02-acta-recibo-10.md",
 "hash": "d79d4cc969bd8cedebcba47c67dab6562945d01a57d40d0b0591ced60bbda50b",
 "text_hash": null,
 "date": "2026-10-02"
 },
 {
 "path": "20-seguimiento/2026-10-02-acta-recibo-11.md",
 "hash": "6718a99568088dd25c923557099035676f56d8618dee1b9125886eb630c965b6",
 "text_hash": null,
 "date": "2026-10-02"
 },
 {
 "path": "20-seguimiento/2026-10-08-acta-recibo-diseño-funcional-aprobado.md",
 "hash": "6aec16570d58b7da5b8cb2bd1bae209e500e007c7585a3676bf511198f2fd689",
 "text_hash": null,
 "date": "2026-10-08"
 },
 {
 "path": "20-seguimiento/2026-10-09-acta-recibo-19.md",
 "hash": "c00b520c085f52a1a4ece778e99da9f6c3fc7fb2e9dd1dc36f740a3d5eb08c6c",
 "text_hash": null,
 "date": "2026-10-09"
 },
 {
 "path": "20-seguimiento/2026-10-13-informe-avance.md",
 "hash": "f15232e28014846edc4ba03dbd544ba8b05e50435ce6242a6ed3f606734b340c",
 "text_hash": null,
 "date": "2026-10-13"
 },
 {
 "path": "2026-10-16-notas-reunion.txt",
 "hash": "da471b7af56c9d70c2effa6534484ec4f9401602fe04ea692734270c70762b3d",
 "text_hash": null,
 "date": "2026-10-16"
 },
 {
 "path": "30-reuniones/2026-09-04-comite-semanal.md",
 "hash": "17d678b36b6375ef3a110609428017d3d59acb41f8a1649ea23d2a7c52e11e99",
 "text_hash": null,
 "date": "2026-09-04"
 },
 {
 "path": "30-reuniones/2026-09-11-comite-semanal.md",
 "hash": "1f46fce0084b7d0ff565567e49abd3460a0b977db55c283c7990a2dedd8093ae",
 "text_hash": null,
 "date": "2026-09-11"
 },
 {
 "path": "30-reuniones/2026-09-18-comite-semanal.md",
 "hash": "c44051030dd22620976e77e111f08c9c5894dc2e60cb1351f08b9fcbe6a72738",
 "text_hash": null,
 "date": "2026-09-18"
 },
 {
 "path": "30-reuniones/2026-09-25-comite-semanal.md",
 "hash": "889b9ee8cb765c2d0737e9846330137860be059923c6f252bf5b3ee9d0353750",
 "text_hash": null,
 "date": "2026-09-25"
 },
 {
 "path": "30-reuniones/2026-10-02-comite-semanal.md",
 "hash": "089ee27f1b219e7be2272d0ac50ee98ec5f8a270385569315e789e35cda13a6e",
 "text_hash": null,
 "date": "2026-10-02"
 },
 {
 "path": "30-reuniones/2026-10-09-comite-semanal.md",
 "hash": "a845b8c2f0b570fb9835a8deb1a58f7c93f9e6d320841d040ce02ceb064cc2da",
 "text_hash": null,
 "date": "2026-10-09"
 }
 ],
 "fields_not_found": [
 "identity.authority",
 "identity.phase",
 "vendors",
 "changes"
 ],
 "open_conflicts": [],
 "reading": "14 de 14 documentos leídos; 6 minutas de comité (2026-09-04 a 2026-10-09) y las notas del 2026-10-16, de la más vieja a la más nueva. Ficha sin sellar."
 }
}
