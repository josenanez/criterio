<!-- origen: PRY-203-aportes-sociales-en-línea/20-seguimiento/2026-10-05-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Aportes sociales en línea
Código: PRY-203
Fecha de corte: 2026-10-05
Gerente: Laura Vélez

Estado declarado
Verde
Avance reportado: 36%

Lo que pasó en el periodo
- Se levantó un hallazgo de seguridad en la revisión de arquitectura

Presupuesto
COP
Aprobado 800.000.000
Comprometido 235.653.597
Ejecutado 367.668.535
Proyección al cierre 839.491.040

Riesgos abiertos
- Concentración del conocimiento en una sola persona
- Cambio normativo del supervisor que puede mover el alcance
