<!-- origen: PRY-208-motor-de-crédito/20-seguimiento/2026-10-09-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Motor de crédito

**Código:** PRY-208
**Fecha de corte:** 2026-10-09
**Gerente:** Diana Molina

## Estado declarado

**Rojo**

Avance reportado: **45%**

## Lo que pasó en el periodo

- Se acordó con arquitectura cómo se revisan los requisitos no funcionales

## Presupuesto

| | COP |
|---|---|
| Aprobado | 3.300.000.000 |
| Comprometido | 2.022.787.050 |
| Ejecutado | 735.553.247 |
| Proyección al cierre | 3.914.489.109 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
- Aprobación del reglamento por el Consejo de Administración
