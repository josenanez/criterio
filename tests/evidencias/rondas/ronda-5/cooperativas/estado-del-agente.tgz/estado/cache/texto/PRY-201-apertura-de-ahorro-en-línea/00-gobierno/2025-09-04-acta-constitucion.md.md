<!-- origen: PRY-201-apertura-de-ahorro-en-línea/00-gobierno/2025-09-04-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Apertura de ahorro en línea

**Código:** PRY-201
**Área dueña:** Cartera y cobranza
**Patrocinador:** Gustavo Neira
**Gerente de proyecto:** Rubén Cárdenas
**Comité:** Consejo de Administración
**Producto asociado:** ahorro a la vista
**Fecha de aprobación:** 2025-09-04

## Objetivo del negocio

Entregar apertura de ahorro en línea para Cartera y cobranza.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**3.300.000.000 COP**, aprobado por Consejo de Administración el 2025-09-04.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-09-14 |
| Cierre | 2026-08-31 |

## Criterio de éxito

Apertura de ahorro en línea en producción y medido.

## Dependencias declaradas

- Ninguna declarada
