<!-- origen: PRY-210-corresponsales-rurales/20-seguimiento/2026-10-04-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Corresponsales rurales
Código: PRY-210
Fecha de corte: 2026-10-04
Gerente: Felipe Arango

Estado declarado
Rojo
Avance reportado: 85%

Lo que pasó en el periodo
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales
- El Consejo de Administración pidió ajustar el reglamento antes del piloto
- El equipo perdió dos semanas por rotación de un desarrollador clave

Presupuesto
COP
Aprobado 3.300.000.000
Comprometido 2.000.231.981
Ejecutado 1.737.257.854
Proyección al cierre 3.884.263.243

Riesgos abiertos
- Aprobación del reglamento por el Consejo de Administración
