<!-- origen: PRY-207-microcrédito-rural/00-gobierno/2026-05-03-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Microcrédito rural

Código: PRY-207

Área dueña: Canales digitales

Patrocinador: Diana Molina

Gerente de proyecto: Camilo Beltrán

Comité: Comité de Educación

Producto asociado: microcrédito

Fecha de aprobación: 2026-05-03

Objetivo del negocio

Entregar microcrédito rural para Canales digitales.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

18.000.000.000 COP, aprobado por Comité de Educación el 2026-05-03.

Fechas comprometidas

Fecha

Inicio

2026-05-13

Cierre

2027-08-12

Criterio de éxito

Microcrédito rural en producción y medido.

Dependencias declaradas

• Ninguna declarada
