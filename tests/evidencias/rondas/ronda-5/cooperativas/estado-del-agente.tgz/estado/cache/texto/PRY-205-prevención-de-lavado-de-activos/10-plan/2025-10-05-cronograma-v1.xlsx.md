<!-- origen: PRY-205-prevención-de-lavado-de-activos/10-plan/2025-10-05-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-03-04 | 2026-03-04 | cerrado
Ambiente de pruebas certificado | 2026-07-23 | 2026-07-23 | cerrado
Integración con el core cooperativo | 2026-12-10 | 2026-12-10 | en curso
