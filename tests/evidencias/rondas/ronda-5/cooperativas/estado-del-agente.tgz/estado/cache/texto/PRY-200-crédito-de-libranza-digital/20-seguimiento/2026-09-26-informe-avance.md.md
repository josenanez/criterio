<!-- origen: PRY-200-crédito-de-libranza-digital/20-seguimiento/2026-09-26-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Crédito de libranza digital

**Código:** PRY-200
**Fecha de corte:** 2026-09-26
**Gerente:** Ricardo Salas

## Estado declarado

**Verde**

Avance reportado: **25%**

## Lo que pasó en el periodo

- Se reprogramó la salida por el cierre contable de fin de mes
- El Consejo de Administración pidió ajustar el reglamento antes del piloto

## Presupuesto

| | COP |
|---|---|
| Aprobado | 2.400.000.000 |
| Comprometido | 922.156.949 |
| Ejecutado | 1.111.419.946 |
| Proyección al cierre | 2.452.918.540 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
- Dependencia del proveedor del core cooperativo
