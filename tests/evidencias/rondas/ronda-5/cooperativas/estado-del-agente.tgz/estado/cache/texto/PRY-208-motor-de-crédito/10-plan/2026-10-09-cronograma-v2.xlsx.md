<!-- origen: PRY-208-motor-de-crédito/10-plan/2026-10-09-cronograma-v2.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-01-30 | 2026-01-30 | cerrado
Ambiente de pruebas certificado | 2026-05-31 | 2026-05-31 | cerrado
Integración con el core cooperativo | 2026-09-29 | 2026-09-29 | cerrado
Piloto con asociados | 2027-01-28 | 2027-03-07 | en curso
