<!-- origen: PRY-209-convenios-de-libranza-con-empresas/10-plan/2026-03-06-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-07-24 | 2026-07-24 | cerrado
Ambiente de pruebas certificado | 2026-12-02 | 2026-12-02 | en curso
Integración con el core cooperativo | 2027-04-12 | 2027-04-12 | en curso
Piloto con asociados | 2027-08-20 | 2027-08-20 | en curso
