<!-- origen: PRY-211-cobranza-digital/00-gobierno/2026-03-24-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Cobranza digital

Código: PRY-211

Área dueña: Bienestar social

Patrocinador: María Restrepo

Gerente de proyecto: Ricardo Salas

Comité: Consejo de Administración

Producto asociado: recaudos

Fecha de aprobación: 2026-03-24

Objetivo del negocio

Entregar cobranza digital para Bienestar social.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

1.200.000.000 COP, aprobado por Consejo de Administración el 2026-03-24.

Fechas comprometidas

Fecha

Inicio

2026-04-03

Cierre

2027-07-23

Criterio de éxito

Cobranza digital en producción y medido.

Dependencias declaradas

• Ninguna declarada
