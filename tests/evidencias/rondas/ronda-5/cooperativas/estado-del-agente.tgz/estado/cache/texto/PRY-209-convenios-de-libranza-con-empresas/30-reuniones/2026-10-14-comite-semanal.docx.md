<!-- origen: PRY-209-convenios-de-libranza-con-empresas/30-reuniones/2026-10-14-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Tecnología · Convenios de libranza con empresas

Fecha: 2026-10-14

Asistentes: Liliana Torres, Paula Céspedes

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Diana Molina

Entregar el punto 21

2026-09-29

Carlos Peña

Entregar el punto 15

2026-11-13
