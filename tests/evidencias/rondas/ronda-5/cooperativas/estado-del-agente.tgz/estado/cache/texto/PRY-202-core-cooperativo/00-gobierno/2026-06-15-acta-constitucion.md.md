<!-- origen: PRY-202-core-cooperativo/00-gobierno/2026-06-15-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Core cooperativo

**Código:** PRY-202
**Área dueña:** Ahorro y aportes
**Patrocinador:** Ricardo Salas
**Gerente de proyecto:** Andrés Lozano
**Comité:** Comité de Educación
**Producto asociado:** No aplica
**Fecha de aprobación:** 2026-06-15

## Objetivo del negocio

Entregar core cooperativo para Ahorro y aportes.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**1.200.000.000 COP**, aprobado por Comité de Educación el 2026-06-15.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-06-25 |
| Cierre | 2027-06-04 |

## Criterio de éxito

Core cooperativo en producción y medido.

## Dependencias declaradas

- Ninguna declarada
