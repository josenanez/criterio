<!-- origen: PRY-207-microcrédito-rural/20-seguimiento/2026-09-28-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Microcrédito rural
Código: PRY-207
Fecha de corte: 2026-09-28
Gerente: Camilo Beltrán

Estado declarado
Verde
Avance reportado: 39%

Lo que pasó en el periodo
- La prueba de carga no alcanzó el umbral pactado y se repite

Presupuesto
COP
Aprobado 18.000.000.000
Comprometido 11.220.110.576
Ejecutado 8.069.391.803
Proyección al cierre 16.589.464.488

Riesgos abiertos
- Concentración del conocimiento en una sola persona
