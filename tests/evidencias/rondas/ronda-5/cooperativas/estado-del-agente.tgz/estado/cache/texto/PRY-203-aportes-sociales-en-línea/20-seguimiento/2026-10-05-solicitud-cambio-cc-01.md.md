<!-- origen: PRY-203-aportes-sociales-en-línea/20-seguimiento/2026-10-05-solicitud-cambio-cc-01.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-01

**Proyecto:** PRY-203 · Aportes sociales en línea
**Fecha:** 2026-10-05
**Solicitante:** Laura Vélez

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +78 días sobre la línea base vigente |
| Costo | 156.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
