<!-- origen: PRY-205-prevención-de-lavado-de-activos/20-seguimiento/2026-09-25-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Prevención de lavado de activos
Código: PRY-205
Fecha de corte: 2026-09-25
Gerente: Ricardo Salas

Estado declarado
Verde
Avance reportado: 46%

Lo que pasó en el periodo
- El Consejo de Administración pidió ajustar el reglamento antes del piloto

Presupuesto
COP
Aprobado 9.500.000.000
Comprometido 3.651.302.880
Ejecutado 3.699.807.086
Proyección al cierre 9.542.211.571

Riesgos abiertos
- Dependencia del proveedor del core cooperativo
