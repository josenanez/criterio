<!-- origen: PRY-200-crédito-de-libranza-digital/10-plan/2025-06-15-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2025-09-10 | 2025-09-10 | cerrado
Ambiente de pruebas certificado | 2025-11-26 | 2025-11-26 | cerrado
Integración con el core cooperativo | 2026-02-11 | 2026-02-11 | cerrado
Piloto con asociados | 2026-04-30 | 2026-04-30 | cerrado
Salida a producción | 2026-07-16 | 2026-07-16 | cerrado
