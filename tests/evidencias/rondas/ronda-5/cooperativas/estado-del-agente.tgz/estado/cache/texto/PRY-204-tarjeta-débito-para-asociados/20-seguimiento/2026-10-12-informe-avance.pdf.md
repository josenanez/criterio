<!-- origen: PRY-204-tarjeta-débito-para-asociados/20-seguimiento/2026-10-12-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Tarjeta débito para asociados
Código: PRY-204
Fecha de corte: 2026-10-12
Gerente: Diana Molina

Estado declarado
Verde
Avance reportado: 83%

Lo que pasó en el periodo
- Se ajustó el plan de pruebas con el área de seguridad
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales

Presupuesto
COP
Aprobado 18.000.000.000
Comprometido 12.906.403.597
Ejecutado 4.779.778.113
Proyección al cierre 20.519.654.277

Riesgos abiertos
- Dependencia del proveedor del core cooperativo
