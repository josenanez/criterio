<!-- origen: PRY-211-cobranza-digital/30-reuniones/2026-10-02-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Consejo de Administración · Cobranza digital

**Fecha:** 2026-10-02
**Asistentes:** Carlos Peña, Elena Duarte, Gustavo Neira, Javier Hoyos, Jorge Medina, Mauricio Pérez, Natalia Ospina, Paula Céspedes, Ricardo Salas, Sandra Gil, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Mauricio Pérez | Enviar el documento 1 | 2026-11-05 |
| Paula Céspedes | Cerrar la prueba 2 | 2026-10-15 |
| Sandra Gil | Revisar el anexo 3 | 2026-10-18 |
| Mauricio Pérez | Entregar el punto 8 | 2026-10-08 |
| Natalia Ospina | Enviar el documento 9 | 2026-10-25 |
| Óscar Ramírez | Validar el ambiente 12 | 2026-09-22 |
| Jorge Medina | Aprobar el diseño 13 | por definir |
| Jorge Medina | Confirmar la fecha 15 | 2026-10-18 |
| Paula Céspedes | Entregar el punto 16 | 2026-10-20 |
| Elena Duarte | Enviar el documento 17 | 2026-10-20 |
| Gustavo Neira | Cerrar la prueba 18 | 2026-10-18 |
| Javier Hoyos | Revisar el anexo 19 | 2026-10-13 |
| Carlos Peña | Validar el ambiente 20 | 2026-10-05 |

## Cerrados en esta reunión

- Cerrar la prueba 10 (María Restrepo): recibido, acta de recibo del 2026-10-02.
- Revisar el anexo 11 (Felipe Arango): recibido, acta de recibo del 2026-10-02.

## Lo que se dijo

- Rubén Cárdenas dice que ya entregó «actualizar la matriz 14». No se presentó acta.
