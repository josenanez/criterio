<!-- origen: PRY-209-convenios-de-libranza-con-empresas/00-gobierno/2026-03-06-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Convenios de libranza con empresas

Código: PRY-209

Área dueña: Riesgo y Cumplimiento

Patrocinador: Paula Céspedes

Gerente de proyecto: Liliana Torres

Comité: Comité de Tecnología

Producto asociado: No aplica

Fecha de aprobación: 2026-03-06

Objetivo del negocio

Entregar convenios de libranza con empresas para Riesgo y Cumplimiento.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

9.500.000.000 COP, aprobado por Comité de Tecnología el 2026-03-06.

Fechas comprometidas

Fecha

Inicio

2026-03-16

Cierre

2027-10-25

Criterio de éxito

Convenios de libranza con empresas en producción y medido.

Dependencias declaradas

• Ninguna declarada
