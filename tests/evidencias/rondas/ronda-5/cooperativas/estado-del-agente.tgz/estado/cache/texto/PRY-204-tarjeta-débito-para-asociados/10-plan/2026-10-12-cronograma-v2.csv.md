<!-- origen: PRY-204-tarjeta-débito-para-asociados/10-plan/2026-10-12-cronograma-v2.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2026-01-19,2026-01-19,cerrado
Ambiente de pruebas certificado,2026-04-07,2026-04-07,cerrado
Integración con el core cooperativo,2026-06-23,2026-06-23,cerrado
Piloto con asociados,2026-09-09,2027-01-02,cerrado
