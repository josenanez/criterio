<!-- origen: PRY-205-prevención-de-lavado-de-activos/00-gobierno/2025-10-05-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Prevención de lavado de activos

Código: PRY-205

Área dueña: Cartera y cobranza

Patrocinador: Camilo Beltrán

Gerente de proyecto: Ricardo Salas

Comité: Consejo de Administración

Producto asociado: No aplica

Fecha de aprobación: 2025-10-05

Objetivo del negocio

Entregar prevención de lavado de activos para Cartera y cobranza.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

9.500.000.000 COP, aprobado por Consejo de Administración el 2025-10-05.

Fechas comprometidas

Fecha

Inicio

2025-10-15

Cierre

2027-02-19

Criterio de éxito

Prevención de lavado de activos en producción y medido.

Dependencias declaradas

• Ninguna declarada
