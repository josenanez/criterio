# Corrida · 2026-10-16-product-definition-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-definition (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-16T10:07:56 · **Fin:** 2026-10-16T10:09:01 · **Duración:** 65 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-definition` | 16 | — | 39 | 36 | La evidencia no sostiene la definición: una sola entrevista de hace 14 meses, volumen declarado 29,6 % sobre lo medido, sin criterio de éxito |

Por señal (`product-definition`): `requirement_untraced` 12, `evidence_stale` 10, `requirement_accepted_without_evidence` 5, `requirement_undecided` 4, `requirement_without_owner` 3, `requirement_without_acceptance` 1, `claim_vs_metric` 1

## Lo que el agente mostró

La evidencia no sostiene la definición de PRD-309 (Microseguros). El contraste está hecho y la corrida quedó registrada como `2026-10-16-product-definition-1`. Los términos ya estaban vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-16), así que no hubo que aceptarlos otra vez.

- **Lo que la evidencia contradice:** el caso de negocio declara un volumen mensual de 276.481 (2026-01-25). El tablero mide 194.582 (corte 2026-10-14), así que lo declarado está 29,6 % por encima, sobre un umbral de 20 %. El tablero tiene un solo punto y no define qué cuenta el volumen.
- **Cifra que nadie mide:** «Retorno esperado en 24 meses» no trae número ni fuente.
- **No está dicho en ninguna parte:**
  - El criterio de éxito.
  - Que los pensionados carezcan de microseguros, que es el problema que la definición afirma.
  - La propuesta, que es solo texto de relleno.
  - Quién decide.
  - El proyecto que lo construye («Ninguno declarado»).
  - El país en que se ofrece.
- **Evidencia:** hay una sola entrevista, del 2025-08-16, a un cliente sin nombre: «Lo necesito y hoy no lo tengo». Tiene 14 meses (el umbral es 12) y no nombra el producto ni el segmento.
- **Supuesto:** «El proveedor cumple el tiempo pactado» figura como «verificado» el 2026-03-30, sin citar con qué. Para verificarlo hace falta el contrato o plan, el nombre del proveedor y el entregable.
- **Normativo:** como ningún documento dice el país, los seis temas que toca (seguros, datos personales, proveedor, cobro de primas, reclamos y retención, accesibilidad) quedaron como «no tengo la norma a la vista». No se cita ninguna norma.
- **Cierre:** la definición no está cerrada, así que no corresponde ofrecer `/product-charter`. El supuesto del proveedor y la falta de criterio de éxito podrían pasar a riesgo con doliente.

Además, el cálculo marcó 36 hallazgos en los 16 requerimientos; el detalle está en el registro de la corrida. La salida completa quedó en `estado-producto/PRD-309/corridas/salida-product-definition.md`.
