# Corrida · 2026-10-16-product-business-case-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-business-case (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-16T10:09:07 · **Fin:** 2026-10-16T10:10:11 · **Duración:** 64 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-business-case` | 16 | — | 39 | 36 | Caso de negocio armado: 1 cifra declarada (276.481) contra 1 medida (194.582), 29,6 % de diferencia; costos, criterio de éxito, retorno, propuesta y país sin fuente; sin productos publicados para cruzar. |

Por señal (`product-business-case`): `requirement_untraced` 12, `evidence_stale` 10, `requirement_accepted_without_evidence` 5, `requirement_undecided` 4, `requirement_without_owner` 3, `requirement_without_acceptance` 1, `claim_vs_metric` 1

## Lo que el agente mostró

Armé el caso de negocio de Microseguros (PRD-309) y dejé la corrida registrada. Su cifra clave no coincide con lo medido y le faltan los costos.

Los términos ya estaban vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-16), así que no los registré otra vez.

- **Cifras:** solo 1 de 2 tiene fuente. El volumen mensual declarado es 276.481 (caso de negocio, 2026-01-25) y el medido es 194.582 (tablero, corte 2026-10-14). La diferencia es de 29,6 %, con el umbral configurado en 20 %. El «Retorno esperado en 24 meses» no trae cifra, así que quedó como supuesto.
- **Costos:** ningún documento da el costo de construir ni de operar. Ese es el primer vacío: sin él hay una propuesta, no un caso de negocio.
- **Éxito y propuesta:** no hay criterio de éxito declarado. La propuesta es el texto de relleno «Propuesta principal».
- **Demanda:** la única evidencia es una entrevista de hace 14 meses a una persona sin nombre.
- **Otros vacíos:** el supuesto del proveedor dice «verificado» sin citar con qué. Tampoco están el país, las alternativas consideradas, el proyecto que lo construye ni quién decide.
- **Cruce con otros productos:** no se pudo hacer, porque no hay ninguno publicado (`estado/` está vacío).

No di ninguna recomendación de aprobar o rechazar.

El texto completo está en `/home/claude/banco/ronda-5/cooperativas/espacio/estado-producto/PRD-309/corridas/salida-product-business-case.md`. La corrida quedó como `2026-10-16-product-business-case-1`, con 39 segundos y 36 hallazgos.
