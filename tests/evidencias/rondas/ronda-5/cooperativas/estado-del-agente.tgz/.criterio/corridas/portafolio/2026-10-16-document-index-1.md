# Corrida · 2026-10-16-document-index-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:document-index (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-16T10:36:09 · **Fin:** 2026-10-16T10:36:52 · **Duración:** 43 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `document-index` | 13 | — | 27 | 66 | 75 documentos sin cambio, 0 por releer. 35 citas de PRY-211 sin resolver aunque los 5 documentos existen en disco; causa probable ruta relativa, no verificada. No se corrigió ninguna ficha. |

Por señal (`document-index`): `milestone_met_without_evidence` 20, `commitment_overdue` 9, `progress_vs_plan` 7, `declared_vs_evidence` 7, `vendor_deliverable_late` 5, `variance_cost` 4, `commitment_undated` 3, `silent` 2, `vendor_invoiced_without_delivery` 2, `variance_time` 2, `commitment_rescheduled` 2, `change_without_baseline` 1, `rebaseline_unauthorized` 1, `pm_vs_pmo` 1

## Lo que el agente mostró

Ya terminé el índice de la carpeta y dejé la corrida registrada.

**Carpeta al 2026-10-16:** son 75 documentos, ninguno cambió y no hay nada que releer. No hay renombrados, borrados ni formatos ilegibles. Por eso no hace falta correr `/portfolio-scan`.

**Citas rotas:** el índice marca 35 campos de la ficha de PRY-211 como no resueltos. Apuntan a 5 documentos: el acta de constitución, el cronograma v1, el informe de avance del 13 de octubre, el acta de recibo del diseño funcional y la ficha de PM. Los 5 existen en `documentos/proyectos/PRY-211-cobranza-digital/`. Mi hipótesis es que la ficha cita rutas relativas a la carpeta del proyecto y el índice no las resuelve. No lo verifiqué ni corregí ninguna ficha.

**Términos:** ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-16), así que no los registré de nuevo.

**Registro:** la salida está en `estado/corridas/salida-document-index.md` y la corrida quedó como `2026-10-16-document-index-1`, con 27 segundos medidos.

El registro de la corrida también lista 66 hallazgos de señales sobre los 13 proyectos, 11 de ellos en PRY-211. No los revisé: este comando no lee documentos, solo los cuenta y los compara.
