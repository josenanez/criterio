# Corrida · 2026-10-16-portfolio-server-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-server rato

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-16T10:57:14 · **Fin:** 2026-10-16T10:58:19 · **Duración:** 65 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-server` | 13 | — | — | 66 | puerto 8787, informe en reportes/, modo rato |

Por señal (`portfolio-server`): `milestone_met_without_evidence` 20, `commitment_overdue` 9, `progress_vs_plan` 7, `declared_vs_evidence` 7, `vendor_deliverable_late` 5, `variance_cost` 4, `commitment_undated` 3, `silent` 2, `vendor_invoiced_without_delivery` 2, `variance_time` 2, `commitment_rescheduled` 2, `change_without_baseline` 1, `rebaseline_unauthorized` 1, `pm_vs_pmo` 1

## Lo que el agente mostró

Rostrum arrancó bien en `http://127.0.0.1:8787/`, pero lo corté a los 15 segundos porque lo lancé en primer plano. Ahora mismo no está corriendo.

- **Términos:** ya estaban vigentes (v1.1), aceptados por José Francisco Ñáñez el 2026-10-16. No hubo que pedir nada.
- **Forma elegida:** «para mirarlo un rato», como indicaba el argumento `rato`. Escucha solo en este equipo.
- **Informe servido:** `reportes/`, con 13 proyectos, 8 productos, `decisiones.html` y el listado de proyectos.
- **Falta `pmo.html`:** no está en `reportes/`, así que `/pmo` puede salir vacío hasta que corras `/portfolio-report html`. Rostrum no lo genera.
- **Corrida registrada:** `2026-10-16-portfolio-server-1`, con lo que te mostré en `estado/corridas/salida-portfolio-server.md`.

Para levantarlo y dejarlo corriendo (se apaga con Ctrl-C, o con `--puerto 8788` si el 8787 está ocupado), usa este comando:
```
python3 "/home/claude/banco/criterio/plugins/criterio-portfolio/scripts/servidor.py" --informe /home/claude/banco/ronda-5/cooperativas/espacio/reportes --estado /home/claude/banco/ronda-5/cooperativas/espacio/estado --config /home/claude/banco/ronda-5/cooperativas/espacio/.criterio/portafolio/config.json
```

**Qué enlace pasar a quién:** `http://127.0.0.1:8787/` solo lo abre quien esté en este equipo. El patrocinador no puede entrar con él, y para que tenga un enlace estable hay que elegir «que quede corriendo» (`--abierto`, detrás del control de acceso de la organización, porque Rostrum no autentica).

**Cuándo queda desactualizado:** el informe es del 2026-10-16. Deja de estar al día cuando cambie un documento o corra otro barrido; la portada muestra su fecha.
