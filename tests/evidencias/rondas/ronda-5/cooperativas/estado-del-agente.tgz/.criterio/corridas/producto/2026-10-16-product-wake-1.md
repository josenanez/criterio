# Corrida · 2026-10-16-product-wake-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-wake (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-16T11:00:24 · **Fin:** 2026-10-16T11:01:34 · **Duración:** 70 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-wake` | 16 | — | 47 | 36 | Primera revisión, sin corte previo: línea base de 16 REQ. 4 sin decidir (60+ días), 5 aceptados sin evidencia, 10 con evidencia vencida, 12 sin traza (ninguna ficha nombra PRD-309), brecha de volumen 29,6 %. Criterio de éxito no dicho en ningún documento. |

Por señal (`product-wake`): `requirement_untraced` 12, `evidence_stale` 10, `requirement_accepted_without_evidence` 5, `requirement_undecided` 4, `requirement_without_owner` 3, `requirement_without_acceptance` 1, `claim_vs_metric` 1

## Lo que el agente mostró

## Microseguros (PRD-309) · 2026-10-16

Esta fue la primera revisión del registro y no había corte anterior. Por eso no hay señales nuevas que separar de las viejas: lo de abajo es la línea base. De aquí en adelante solo reportaré lo que cruce un umbral después de hoy. Los términos ya estaban aceptados desde hoy a nombre de José Francisco Ñáñez, así que no los volví a registrar. Solo tocaba la revisión; el informe de comité y las señales cruzadas no tocaban.

El registro tiene 16 requerimientos: 12 aceptados y 4 propuestos. Siete tienen evidencia (58,3 %) y ninguno tiene traza a un proyecto (0 %).

**Lo que lleva más de 60 días sin decidirse** (decide el Comité de producto):

| REQ | Días | Qué falta |
|---|---|---|
| REQ-4910 | 172 | Decisión del comité; tampoco tiene evidencia. Doliente: Óscar Ramírez. |
| REQ-4901 | 141 | Decisión del comité; su única evidencia tiene 14 meses. Doliente: Laura Vélez. |
| REQ-4912 | 110 | Un doliente, porque no tiene ninguno. Después decide el comité. |
| REQ-4904 | 69 | Decisión del comité y criterio de aceptación. Doliente: Camilo Beltrán. |

Puedo llevar estos cuatro al próximo comité.

**Aceptados sin sustento:**
- **Sin evidencia de demanda (5):** REQ-4900, 4903, 4905, 4908 y 4911. REQ-4905 tampoco tiene criterio de aceptación.
- **Evidencia vencida (10):** toda la demanda documentada es una sola entrevista del 2025-08-16 que no nombra ningún requerimiento. Con ella vencida, la definición queda sin sustento fechado para Pensionados.
- **Sin doliente (3):** REQ-4909, 4912 y 4913.

**Aceptados que nadie construye:** los 12 aceptados no tienen proyecto. Ninguna ficha de `estado/records` nombra PRD-309, así que no hay ninguna traza que confirmar. Las aceptaciones más viejas son REQ-4906 (213 días), REQ-4902 (205), REQ-4903 (191) y REQ-4908 (187).

**Lo declarado contra lo medido:**

| Métrica | Declarado (2026-01-25) | Medido (2026-10-14) | Brecha |
|---|---|---|---|
| Volumen mensual | 276.481 | 194.582 | 29,6 % por debajo de lo declarado (umbral 20 %) |

**Lo que no se sabe:** el criterio de éxito de la definición no está dicho en ningún documento. No hay supuestos registrados; eso significa que ninguno está declarado, no que no existan.

El comando no decidió nada ni le escribió a nadie. Guardé el corte y dejé la corrida registrada en `estado-producto/PRD-309/corridas/2026-10-16-product-wake-1.md`. La salida completa está en `salida-product-wake.md`, en la misma carpeta.

**Vuelvo el 2026-11-15.**
