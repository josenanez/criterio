# Corrida · 2026-10-16-steering-pack-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:steering-pack (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-16T10:50:51 · **Fin:** 2026-10-16T10:53:48 · **Duración:** 178 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `steering-pack` | 13 | — | 144 | 66 | Paquete de comité 2026-10-23: 10 decisiones, 5 escalamientos, 11 de 13 proyectos con hallazgos. Dijo que no sabe: quién tiene la facultad de aprobar (autoridad no encontrada en 13/13), si los costos de cada CC ya están en la proyección, el acta de CC-01 de PRY-204 y PRY-209, y que no hay registro de comité anterior. |

Por señal (`steering-pack`): `milestone_met_without_evidence` 20, `commitment_overdue` 9, `progress_vs_plan` 7, `declared_vs_evidence` 7, `vendor_deliverable_late` 5, `variance_cost` 4, `commitment_undated` 3, `silent` 2, `vendor_invoiced_without_delivery` 2, `variance_time` 2, `commitment_rescheduled` 2, `change_without_baseline` 1, `rebaseline_unauthorized` 1, `pm_vs_pmo` 1

## Lo que el agente mostró

Armé el paquete de comité para el 2026-10-23 y quedó registrado como la corrida `2026-10-16-steering-pack-1`, que midió 144 segundos y 66 hallazgos. Sin fecha en la invocación tomé la del próximo comité de la configuración. Los términos ya estaban vigentes (v0.3.11, aceptados por José Francisco Ñáñez el 2026-10-16) y no los registré de nuevo.

El paquete trae 10 decisiones, 5 escalamientos sin decisión asociada, y hallazgos en 11 de los 13 proyectos.

**Decisiones**
1. **Autoridad.** La autoridad de cambios no aparece en ninguna de las 13 fichas, así que el primer punto es un cuadro de autoridad escrito para el portafolio. Recomiendo un cuadro único.
2. **PRY-204, CC-01** (+115 días, COP 230.000.000): consta como aprobado por «el comité» sin nombrar cuál. Recomiendo ratificarlo y exigir que el estado deje de ser verde.
3. **PRY-209, CC-01** (+68 días, COP 136.000.000): también aprobado sin acta citada. Recomiendo ratificar, con la condición de que el gerente entregue el acta.
4. **PRY-208, CC-01** (+38 días, COP 76.000.000): la línea base ya se movió esos 38 días sin autorización. Recomiendo aprobar solo con una reestimación de costo.
5. **PRY-210, CC-01** (+65 días, COP 130.000.000): su fecha de fin, 2026-10-06, ya pasó. Recomiendo diferir una semana.
6. **PRY-203, CC-01** (+78 días, COP 156.000.000): la ficha trae ejecutado mayor que comprometido. Recomiendo diferir una semana.
7. **PRY-200:** hay COP 207.643.011 facturados por Soluciones Solidarias S.A.S. y ningún entregable aceptado. Recomiendo suspender pagos hasta que haya aceptación con evidencia.
8. **PRY-206:** la proyección supera lo aprobado en 16,2 % y su fecha de fin ya pasó. Recomiendo un diagnóstico desde cero antes de aprobar más presupuesto.
9. **Proveedor del core** (seis proyectos): recomiendo que los gerentes confirmen primero si la dependencia es real, y después nombrar un responsable único.
10. **Reglamento ante el Consejo** (8 proyectos afectados): recomiendo que la PMO sea la responsable única.

**Escalamientos:** PRY-211, el riesgo del proveedor PRY-211/R3, PRY-200 (línea base vencida), PRY-202 (facturado sin entrega) y PRY-207 (18 días sin movimiento).

**Lo que no sé**
- No hay registro de un comité anterior, así que la tabla de decisiones previas queda vacía.
- Quién tiene la facultad en cada punto: en el paquete lo marco como no determinable y propongo al comité por defecto.
- Si los costos de cada solicitud de cambio ya están dentro de la proyección.
- Si el «proveedor del core» es PRY-202.

Las cifras derivadas salen de `portafolio.py compute`. Las recomendaciones son mi lectura, y el pie del documento lo dice.

El texto completo está en `/home/claude/banco/ronda-5/cooperativas/espacio/estado/corridas/salida-steering-pack.md`. Falta ofrecer registrar las decisiones en las fichas cuando el comité sesione; eso es posterior a la reunión.
