# Corrida · 2026-10-16-project-charter-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-charter PRY-203 revisar

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-203

**Inicio:** 2026-10-16T10:48:15 · **Fin:** 2026-10-16T10:49:09 · **Duración:** 55 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-charter` | 13 | — | 32 | 66 | Revisó el acta de PRY-203: sin autoridad del gerente, alcance y exclusiones con marcadores vacíos, sin supuestos, hitos, cadencia ni quién mide el éxito. No supo qué se acordó fuera de los 3 documentos; dejó marcada la cifra comprometido<ejecutado y los cálculos propios (995.491.040 COP, cierre 2027-11-22). |

Por señal (`project-charter`): `milestone_met_without_evidence` 20, `commitment_overdue` 9, `progress_vs_plan` 7, `declared_vs_evidence` 7, `vendor_deliverable_late` 5, `variance_cost` 4, `commitment_undated` 3, `silent` 2, `vendor_invoiced_without_delivery` 2, `variance_time` 2, `commitment_rescheduled` 2, `change_without_baseline` 1, `rebaseline_unauthorized` 1, `pm_vs_pmo` 1

## Lo que el agente mostró

**Acta de PRY-203 (Aportes sociales en línea): existe, aprobada el 2026-05-01, pero está incompleta.**

Los términos ya estaban vigentes a nombre de José Francisco Ñáñez (2026-10-16), así que no registré nada nuevo.

**Qué falta y qué consecuencia tiene**
- **Autoridad del gerente:** no está. Por eso CC-01 (+156.000.000 COP, +78 días, ampliación de alcance) quedó pendiente del comité: no hay umbral que diga si Laura Vélez puede decidirlo sola.
- **Objetivo de negocio:** describe la solución ("Entregar aportes sociales en línea…"), no un resultado medible.
- **Alcance y exclusiones:** son marcadores vacíos ("Componente 1, 2, 3" y "Lo que otro proyecto cubre"). No hay línea base de alcance contra la cual evaluar CC-01.
- **Supuestos y restricciones:** no están. El riesgo del cambio normativo del supervisor es un supuesto que nunca se declaró.
- **Criterio de éxito:** "En producción y medido" no tiene métrica ni quién lo mide.
- **Hitos y cadencia del comité:** no están. Sin hitos no se puede contrastar el 36 % de avance reportado.
- **Dependencias:** dice "Ninguna declarada", pero hay un hallazgo de seguridad de arquitectura abierto.
- **Patrocinador, presupuesto y fechas:** cumplen (Rubén Cárdenas; 800.000.000 COP; 2026-05-11 a 2027-09-05).

**Otros hallazgos, de los otros documentos de la carpeta**
- El informe de avance declara verde, pero se ha ejecutado el 46 % del presupuesto con un 36 % de avance.
- La proyección al cierre ya supera el aprobado (839.491.040 COP). Sumando CC-01 llegaría a unos 995.491.040 COP, un 24 % sobre el aprobado. Ese total es cálculo mío y asume que la proyección no incluye ya el cambio.
- El comprometido (235.653.597 COP) es menor que el ejecutado (367.668.535 COP). El informe no lo explica.
- CC-01 llevaría el cierre al 2027-11-22 (también cálculo mío).
- No sé qué se acordó fuera de estos tres documentos.

**Siguiente paso:** como el acta no declara la autoridad del gerente, ofrezco llevar esa definición al Comité de Riesgos junto con CC-01. También puedo pasar los supuestos al registro RAID.

La salida completa quedó en `estado/corridas/salida-project-charter.md` y la corrida está registrada con id `2026-10-16-project-charter-1`.
