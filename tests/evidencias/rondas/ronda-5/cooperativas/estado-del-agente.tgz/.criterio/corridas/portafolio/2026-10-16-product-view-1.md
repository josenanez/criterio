# Corrida · 2026-10-16-product-view-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:product-view ahorro a la vista

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-16T10:53:54 · **Fin:** 2026-10-16T10:54:33 · **Duración:** 40 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-view` | 13 | — | 24 | 66 | Producto con un solo proyecto (PRY-201): sin sección de producto, 5 alertas reportadas. Reporté 5 proyectos sin producto. No supe: el área dueña de esos 5, ni si los hitos de PRY-201 están cumplidos de verdad. |

Por señal (`product-view`): `milestone_met_without_evidence` 20, `commitment_overdue` 9, `progress_vs_plan` 7, `declared_vs_evidence` 7, `vendor_deliverable_late` 5, `variance_cost` 4, `commitment_undated` 3, `silent` 2, `vendor_invoiced_without_delivery` 2, `variance_time` 2, `commitment_rescheduled` 2, `change_without_baseline` 1, `rebaseline_unauthorized` 1, `pm_vs_pmo` 1

## Lo que el agente mostró

**Vista por producto: «ahorro a la vista».** Sale de las fichas en `estado/`, calculadas al 2026-10-16. Los términos estaban vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-16), así que no hubo que registrarlos de nuevo.

«Ahorro a la vista» tiene un solo proyecto: PRY-201 «Apertura de ahorro en línea». La vista por producto no aporta más que la ficha del proyecto, así que no armé sección de producto.

| Producto | Proyectos | Con alertas | Fecha más tardía | Aprobado | Comprometido |
|---|---|---|---|---|---|
| ahorro a la vista | 1 (PRY-201) | 1 (5 alertas) | 2026-07-23 (vencida hace 85 días) | COP 3.300.000.000 | COP 1.994.133.809 |

- **Dependencias internas:** no hay. Un solo proyecto no puede tener dependencias con otro del mismo producto, y la ficha no declara ninguna.
- **Fecha del producto:** 2026-07-23, la del único proyecto. No hay atraso contra la línea base ni replanificaciones, pero la fecha ya pasó.
- **Avance:** el gerente declara 78 % y el plan sostiene 100 % (4 de 4 hitos cumplidos). Son 22 puntos de diferencia.
- **Hitos sin evidencia:** los cuatro hitos figuran como cumplidos, pero ningún documento lo prueba.
  - Diseño funcional aprobado (fecha 2025-12-01, hace 319 días).
  - Ambiente de pruebas certificado (2026-02-17, 241 días).
  - Integración con el core cooperativo (2026-05-06, 163 días).
  - Piloto con asociados (2026-07-23, 85 días).
- **Estado declarado:** el informe del 2026-10-11 pone el proyecto en rojo y no explica esas dos señales.
- **Dinero:** las cuatro cifras están.
  - Ejecutado: COP 629.512.425 (19,1 %).
  - Comprometido: 60,4 %.
  - Proyección: COP 3.199.017.869 (−3,1 % frente a lo aprobado).
- **Evidencia:** la ficha no tiene ningún dato con fuente de evidencia. Los datos de identidad y plan tienen 13 meses de antigüedad, por encima del umbral de 12.

**Cinco proyectos no tienen producto declarado:** PRY-202, PRY-205, PRY-208, PRY-209 y PRY-210. Nadie puede responder por el conjunto al que sirven. El cálculo no entrega el área dueña de ninguno, así que no la inventé.

Hay una posible dependencia que ninguna ficha declara. PRY-201 tiene como hito la «Integración con el core cooperativo», y PRY-202 es el «Core cooperativo», sin producto. Hay que confirmarla con los gerentes antes de afirmarla.

No sé si los hitos de PRY-201 están cumplidos de verdad, qué pasó desde el informe del 2026-10-11, ni el área dueña de esos cinco proyectos. Es un borrador de trabajo; la verificación contra los documentos es de quien lo lea.

La corrida quedó registrada como `2026-10-16-product-view-1`, con 66 hallazgos en el portafolio, 5 de ellos de este producto. La salida completa está en `estado/corridas/salida-product-view.md`.
