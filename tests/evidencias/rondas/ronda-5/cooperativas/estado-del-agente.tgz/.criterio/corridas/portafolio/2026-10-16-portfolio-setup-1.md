# Corrida · 2026-10-16-portfolio-setup-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-setup documentos/proyectos

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-16T10:27:34 · **Fin:** 2026-10-16T10:29:52 · **Duración:** 139 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-setup` | 3 | 75 | 101 | 16 | 0 preguntas (sesión sin interfaz, se tomaron los valores propuestos). Primer resultado en una sola pasada. Se leyeron PRY-209, PRY-206 y PRY-208: 14 señales, la más grave el verde de PRY-206 con 3 hitos sin acta, 47 puntos de avance contra plan, +16 % de costo y 2 compromisos vencidos. |

Por señal (`portfolio-setup`): `milestone_met_without_evidence` 5, `commitment_overdue` 3, `progress_vs_plan` 2, `variance_cost` 2, `declared_vs_evidence` 2, `rebaseline_unauthorized` 1, `variance_time` 1

## Lo que el agente mostró

Dejé la instalación lista y probé con tres proyectos: PRY-209, PRY-206 y PRY-208. La mayor señal es el verde de PRY-206, que contradice sus propios documentos. Nadie podía responder, así que tomé el valor propuesto en cada decisión y no hice ninguna pregunta.

**Qué configuré**
- **Documentos:** miré 75 documentos en 13 proyectos, de los que 3 pasaron por la prueba. El más reciente es del 2026-10-16.
- **Rol:** PMO del portafolio.
- **Comité:** semanal, con el primero propuesto para el 2026-10-23. El informe llega dos días antes, en presentación.
- **Rutas:** el estado queda en `estado/` y los informes en `reportes/`.
- **Términos:** aceptados a nombre de José Francisco Ñáñez para la versión 0.3.11 (términos 1.1). El comprobante está en `.criterio/terminos/aceptacion-criterio-portfolio-0.3.11-2026-10-16.md` y `.pdf`.
- **Verificación:** `config` pasó sin problemas.

**Lo que encontró el cálculo** (16 señales en total; por error, la nota de la corrida registrada dice 14):

| Proyecto | Declara | Señales |
|---|---|---|
| PRY-206 Pagos con QR | verde, 53 % | 8: los 3 hitos figuran cerrados sin ningún acta; el avance declarado queda 47 puntos por debajo de lo que sostiene el plan; la proyección de costo sube 16,2 % sobre lo aprobado; 2 compromisos vencidos |
| PRY-208 Motor de crédito | rojo, 45 % | 5: 2 hitos cerrados sin acta; el avance declarado queda 30 puntos por debajo del plan; la proyección de costo sube 18,6 %; el cronograma v2 mueve el piloto 38 días mientras la CC-01 sigue pendiente de comité |
| PRY-209 Convenios de libranza | verde, 26 % | 3: 68 días de atraso contra la línea base original (13 %); 1 compromiso vencido |

**Lo que le falta a la carpeta**
- Ninguna acta de constitución dice hasta qué monto decide el gerente ni en qué etapa está el proyecto.
- Hay pocas actas de recibo.
- La CC-01 de PRY-209 dice «autorizada por el comité» sin nombrar cuál.
- Los riesgos no traen dueño, probabilidad ni fecha.

**El portafolio completo.** Quedan 10 proyectos y 65 documentos, que tomarían unos 30 minutos.

**Una salvedad.** Hay una carpeta previa `estado/PRY-211-cobranza-digital` de otra corrida. No la toqué.

Todo quedó en `estado/corridas/`: el resultado completo en `salida-portfolio-setup.md` y la corrida registrada como `2026-10-16-portfolio-setup-1`.
