# Corrida · 2026-10-16-portfolio-wake-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-wake (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-16T10:56:03 · **Fin:** 2026-10-16T10:57:08 · **Duración:** 65 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-wake` | 13 | — | 46 | 66 | Barrido: 75 documentos sin cambios, nada que releer. Confirmación: 5 preguntas formuladas sin respuesta (sesión desatendida). 35 citas de PRY-211 no resuelven por ruta sin carpeta del proyecto; sin verificar. No consulté requests (no tocaban). No revisé campos de más de 12 meses. |

Por señal (`portfolio-wake`): `milestone_met_without_evidence` 20, `commitment_overdue` 9, `progress_vs_plan` 7, `declared_vs_evidence` 7, `vendor_deliverable_late` 5, `variance_cost` 4, `commitment_undated` 3, `silent` 2, `vendor_invoiced_without_delivery` 2, `variance_time` 2, `commitment_rescheduled` 2, `change_without_baseline` 1, `rebaseline_unauthorized` 1, `pm_vs_pmo` 1

## Lo que el agente mostró

Hoy tocaban el barrido diario y la confirmación periódica, y ambos están hechos y registrados. Los términos estaban vigentes (aceptados por José Francisco Ñáñez el 2026-10-16), así que no hubo que pedirlos de nuevo.

- **Barrido:** revisé 75 documentos y ninguno cambió, así que no recalculé ningún proyecto.
- **Citas rotas:** el índice marca 35 campos de PRY-211 cuya fuente no resuelve. Los archivos sí existen; la ruta citada en la ficha no incluye la carpeta `PRY-211-cobranza-digital/`. Parece un problema de ruta en la cita, no un documento perdido. No lo corregí y queda por verificar.
- **Señales abiertas (ya estaban, no las produjo el barrido):**
  - PRY-200 lleva 20 días en silencio y PRY-207, 18; el umbral es 15.
  - PRY-202 tiene un proveedor facturado sin entrega.
  - PRY-208 tiene una replanificación sin autorización.
  - PRY-204 supera el 10 % de desviación en tiempo y en costo.
  - PRY-211 tiene 6 compromisos vencidos.
- **Confirmación:** formulé cinco preguntas, una por cada una de las cinco señales anteriores (PRY-200, PRY-207, PRY-202, PRY-208, PRY-211). Quedan sin respuesta porque la sesión es desatendida; es la primera vez que se preguntan. Las elegí por importancia entre las señales abiertas. No revisé campos de más de 12 meses de antigüedad.
- **Peticiones:** `requests` no tocaba hoy y no las consulté.

La salida completa quedó en `estado/corridas/salida-portfolio-wake.md`, y la corrida quedó registrada como `2026-10-16-portfolio-wake-1`. No programé el reloj: esta sesión era de prueba. Vuelvo el 2026-10-17.
