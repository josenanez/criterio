# Corrida · 2026-10-16-project-closure-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-closure PRY-200

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-200

**Inicio:** 2026-10-16T10:49:15 · **Fin:** 2026-10-16T10:50:45 · **Duración:** 89 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-closure` | 13 | — | 63 | 66 | Acta de cierre de PRY-200: no cerrable por cumplimiento; criterio de éxito sin verificar, 5 hitos cerrados sin evidencia, CT-395 facturado sin entregables aceptados. Dijo que no sabía: si hay producción, si se hizo el piloto, fecha de cierre válida (2026-07-16 vs 2026-08-24), por qué ejecutado supera comprometido, doliente del RAID. |

Por señal (`project-closure`): `milestone_met_without_evidence` 20, `commitment_overdue` 9, `progress_vs_plan` 7, `declared_vs_evidence` 7, `vendor_deliverable_late` 5, `variance_cost` 4, `commitment_undated` 3, `silent` 2, `vendor_invoiced_without_delivery` 2, `variance_time` 2, `commitment_rescheduled` 2, `change_without_baseline` 1, `rebaseline_unauthorized` 1, `pm_vs_pmo` 1

## Lo que el agente mostró

## Cierre de PRY-200 (Crédito de libranza digital), 2026-10-16

Hice el cierre desde la ficha de PRY-200 y los documentos del proyecto. Su conclusión es que no se puede cerrar por cumplimiento: ningún documento muestra que se haya cumplido el criterio de éxito, "Crédito de libranza digital en producción y medido". Solo podría cerrarse por decisión del Comité de Crédito.

- **Términos:** ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-16), así que no los registré de nuevo.
- **Hitos:** el cronograma marca los 5 hitos como cerrados, pero ninguno tiene evidencia. El informe del 2026-09-26 contradice dos de ellos: dice que el piloto sigue pendiente y que la salida se reprogramó. Ese informe declara verde con 25 % de avance, frente al 100 % que sostiene el plan.
- **Proveedores:** de los 6 entregables de proveedor, solo se recibió uno, el licenciamiento de CT-802, con acta del 2025-12-01. Los otros 5 están vencidos.
- **Facturación:** a Soluciones Solidarias (CT-395) se le facturó 207.643.011 COP con 0 de 4 entregables aceptados y sin ninguna acta de recibo.
- **Presupuesto:**
  - Ejecutado: 1.111.419.946 COP, el 46.3 % del aprobado.
  - Comprometido: 922.156.949 COP. El ejecutado supera al comprometido y ningún documento lo explica.
  - Proyección al cierre: 2.452.918.540 COP, 2.2 % sobre el aprobado.
- **Fechas:** el acta fija el cierre en 2026-08-24 y el cronograma en 2026-07-16. No hay documento que explique la diferencia.
- **RAID:** 2 riesgos y 2 incidencias abiertos, ninguno con responsable. Por eso no se pueden dar por cerrados.
- **Lecciones:** solo dejé las 3 que se anclan a hechos documentados.
- **Silencio:** el proyecto lleva 20 días sin reporte, y el umbral configurado es 15.
- **Archivo:** no moví la carpeta a `archivo/` porque el proyecto no cumple las condiciones de cierre.

Las cifras salen todas del script `compute`.

La salida completa quedó en `estado/corridas/salida-project-closure.md` y la corrida quedó registrada como `2026-10-16-project-closure-1`.
