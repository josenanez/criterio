# Definición de producto · Crédito de libre inversión

**Código:** PRD-309
**Gerente de producto:** Camilo Beltrán
**Segmento:** Empresas
**Fecha de la definición:** 2026-03-23

## El problema

El segmento Empresas no tiene crédito de libre inversión.

## La propuesta

- Propuesta principal

## Supuestos

- **La regulación vigente lo permite** · declarado el 2026-05-22 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
