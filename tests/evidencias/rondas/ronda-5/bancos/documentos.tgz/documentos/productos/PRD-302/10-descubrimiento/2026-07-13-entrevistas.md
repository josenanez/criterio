# Entrevistas · Crédito hipotecario digital

**Ronda:** Ronda · 2026-07-13
**Realizadas por:** Mauricio Pérez

### Cliente entrevistado · 2026-07-13

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
