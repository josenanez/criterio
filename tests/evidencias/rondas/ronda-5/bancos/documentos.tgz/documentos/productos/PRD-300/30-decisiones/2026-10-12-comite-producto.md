# Comité de producto · Pagos QR comercios

**Fecha:** 2026-10-12
**Asistentes:** Felipe Arango

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4000 | Requerimiento REQ-4000 | Felipe Arango | se verifica en producción | — | aceptado | 2026-04-14 | — |
| REQ-4001 | Requerimiento REQ-4001 | sin asignar | se verifica en producción | — | aceptado | 2026-03-18 | — |
| REQ-4002 | Requerimiento REQ-4002 | Javier Hoyos | — | — | aceptado | 2026-07-01 | — |
| REQ-4003 | Requerimiento REQ-4003 | Laura Vélez | se verifica en producción | — | aceptado | 2026-07-25 | — |
| REQ-4004 | Requerimiento REQ-4004 | Beatriz Cuéllar | se verifica en producción | — | aceptado | 2026-07-20 | — |
| REQ-4005 | Requerimiento REQ-4005 | Beatriz Cuéllar | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-22 | — |
| REQ-4006 | Requerimiento REQ-4006 | Laura Vélez | se verifica en producción | Cliente entrevistado | propuesto | 2026-03-24 | — |
| REQ-4007 | Requerimiento REQ-4007 | Felipe Arango | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-13 | — |
| REQ-4008 | Requerimiento REQ-4008 | María Restrepo | se verifica en producción | Cliente entrevistado | propuesto | 2026-03-24 | — |
| REQ-4009 | Requerimiento REQ-4009 | Andrés Lozano | se verifica en producción | — | propuesto | 2026-07-07 | — |
| REQ-4010 | Requerimiento REQ-4010 | Andrés Lozano | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-15 | — |
| REQ-4011 | Requerimiento REQ-4011 | Javier Hoyos | se verifica en producción | — | propuesto | 2026-06-16 | — |
| REQ-4012 | Requerimiento REQ-4012 | sin asignar | se verifica en producción | — | aceptado | 2026-08-16 | — |
| REQ-4013 | Requerimiento REQ-4013 | Rubén Cárdenas | se verifica en producción | — | aceptado | 2026-08-13 | — |
| REQ-2035 | Requerimiento REQ-2035 | Ricardo Salas | — | — | aceptado | 2026-10-07 | — |

## Decisiones

- Se mantiene el plan
