# Caso de negocio · Crédito de libre inversión

**Código:** PRD-309
**Fecha:** 2026-03-23
**Preparado por:** Camilo Beltrán

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 226.432 | Caso de negocio, 2026-03-23 |

## Retorno esperado

Retorno esperado en 24 meses.
