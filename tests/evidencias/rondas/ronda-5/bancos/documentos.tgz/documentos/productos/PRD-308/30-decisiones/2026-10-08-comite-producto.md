# Comité de producto · Cuenta de ahorros joven

**Fecha:** 2026-10-08
**Asistentes:** Óscar Ramírez

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4800 | Requerimiento REQ-4800 | Laura Vélez | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-28 | — |
| REQ-4801 | Requerimiento REQ-4801 | Rubén Cárdenas | — | Cliente entrevistado | aceptado | 2026-04-12 | — |
| REQ-4802 | Requerimiento REQ-4802 | sin asignar | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-16 | — |
| REQ-4803 | Requerimiento REQ-4803 | Elena Duarte | se verifica en producción | — | aceptado | 2026-04-22 | — |
| REQ-4804 | Requerimiento REQ-4804 | Diana Molina | se verifica en producción | — | aceptado | 2026-05-14 | — |
| REQ-4805 | Requerimiento REQ-4805 | Javier Hoyos | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-13 | — |
| REQ-4806 | Requerimiento REQ-4806 | Felipe Arango | — | — | propuesto | 2026-04-19 | — |
| REQ-4807 | Requerimiento REQ-4807 | Elena Duarte | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-25 | — |
| REQ-4808 | Requerimiento REQ-4808 | Felipe Arango | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-21 | — |
| REQ-4809 | Requerimiento REQ-4809 | Javier Hoyos | se verifica en producción | — | propuesto | 2026-07-26 | — |
| REQ-4810 | Requerimiento REQ-4810 | Natalia Ospina | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-12 | — |
| REQ-4811 | Requerimiento REQ-4811 | Jorge Medina | se verifica en producción | — | aceptado | 2026-04-30 | — |
| REQ-4812 | Requerimiento REQ-4812 | Paula Céspedes | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-11 | — |
| REQ-4813 | Requerimiento REQ-4813 | Beatriz Cuéllar | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-22 | — |
| REQ-2028 | Requerimiento REQ-2028 | Natalia Ospina | se verifica en producción | Cliente entrevistado | aceptado | 2026-09-28 | — |

## Decisiones

- Se mantiene el plan
