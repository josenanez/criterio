# Caso de negocio · Recaudos y cobros

**Código:** PRD-305
**Fecha:** 2026-02-20
**Preparado por:** Mauricio Pérez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 249.061 | Caso de negocio, 2026-02-20 |

## Retorno esperado

Retorno esperado en 24 meses.
