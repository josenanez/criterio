# Caso de negocio · Cuenta PyME

**Código:** PRD-303
**Fecha:** 2026-07-16
**Preparado por:** Javier Hoyos

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 149.630 | Caso de negocio, 2026-07-16 |

## Retorno esperado

Retorno esperado en 24 meses.
