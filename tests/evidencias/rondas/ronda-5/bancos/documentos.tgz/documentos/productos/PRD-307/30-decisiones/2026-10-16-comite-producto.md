# Comité de producto · Remesas familiares

**Fecha:** 2026-10-16
**Asistentes:** Mauricio Pérez

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4700 | Requerimiento REQ-4700 | Elena Duarte | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-16 | — |
| REQ-4701 | Requerimiento REQ-4701 | Camilo Beltrán | se verifica en producción | Cliente entrevistado | propuesto | 2026-06-27 | — |
| REQ-4702 | Requerimiento REQ-4702 | Felipe Arango | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-01 | — |
| REQ-4703 | Requerimiento REQ-4703 | Javier Hoyos | — | Cliente entrevistado | propuesto | 2026-07-06 | — |
| REQ-4704 | Requerimiento REQ-4704 | Mauricio Pérez | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-25 | — |
| REQ-4705 | Requerimiento REQ-4705 | Sandra Gil | — | Cliente entrevistado | propuesto | 2026-07-07 | — |
| REQ-4706 | Requerimiento REQ-4706 | Paula Céspedes | — | — | aceptado | 2026-06-02 | — |
| REQ-4707 | Requerimiento REQ-4707 | Elena Duarte | se verifica en producción | — | aceptado | 2026-05-30 | — |
| REQ-4708 | Requerimiento REQ-4708 | Liliana Torres | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-11 | — |
| REQ-4709 | Requerimiento REQ-4709 | Sandra Gil | se verifica en producción | Cliente entrevistado | propuesto | 2026-05-05 | — |
| REQ-4710 | Requerimiento REQ-4710 | Sandra Gil | se verifica en producción | Cliente entrevistado | propuesto | 2026-04-28 | — |
| REQ-4711 | Requerimiento REQ-4711 | Natalia Ospina | se verifica en producción | — | aceptado | 2026-03-23 | — |
| REQ-4712 | Requerimiento REQ-4712 | Elena Duarte | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-21 | — |
| REQ-4713 | Requerimiento REQ-4713 | Sandra Gil | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-28 | — |
| REQ-2028 | Requerimiento REQ-2028 | Sandra Gil | — | — | aceptado | 2026-09-24 | — |
| REQ-2036 | Requerimiento REQ-2036 | Óscar Ramírez | se verifica en producción | — | aceptado | 2026-10-05 | — |

## Decisiones

- Se mantiene el plan
