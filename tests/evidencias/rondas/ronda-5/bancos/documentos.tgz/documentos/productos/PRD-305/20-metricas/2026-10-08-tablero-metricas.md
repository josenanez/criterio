# Tablero de métricas · Recaudos y cobros

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-08

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 178.950 | 2026-10-08 |
