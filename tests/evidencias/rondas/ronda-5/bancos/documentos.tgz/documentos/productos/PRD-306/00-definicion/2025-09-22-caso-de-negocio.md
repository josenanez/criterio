# Caso de negocio · Microseguros

**Código:** PRD-306
**Fecha:** 2025-09-22
**Preparado por:** Liliana Torres

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 86.842 | Caso de negocio, 2025-09-22 |

## Retorno esperado

Retorno esperado en 24 meses.
