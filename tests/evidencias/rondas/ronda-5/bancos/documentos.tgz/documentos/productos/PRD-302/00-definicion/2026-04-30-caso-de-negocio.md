# Caso de negocio · Crédito hipotecario digital

**Código:** PRD-302
**Fecha:** 2026-04-30
**Preparado por:** Mauricio Pérez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 91.207 | Caso de negocio, 2026-04-30 |

## Retorno esperado

Retorno esperado en 24 meses.
