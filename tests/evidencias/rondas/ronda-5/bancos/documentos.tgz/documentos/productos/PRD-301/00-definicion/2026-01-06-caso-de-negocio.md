# Caso de negocio · Nómina empresarial

**Código:** PRD-301
**Fecha:** 2026-01-06
**Preparado por:** Felipe Arango

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 234.143 | Caso de negocio, 2026-01-06 |

## Retorno esperado

Retorno esperado en 24 meses.
