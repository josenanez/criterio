# Tablero de métricas · Tarjeta de crédito digital

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-11

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 100.879 | 2026-10-11 |
