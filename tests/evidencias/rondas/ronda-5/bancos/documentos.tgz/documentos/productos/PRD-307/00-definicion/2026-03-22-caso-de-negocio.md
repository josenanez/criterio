# Caso de negocio · Remesas familiares

**Código:** PRD-307
**Fecha:** 2026-03-22
**Preparado por:** Mauricio Pérez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 123.536 | Caso de negocio, 2026-03-22 |

## Retorno esperado

Retorno esperado en 24 meses.
