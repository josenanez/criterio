# Comité de producto · Recaudos y cobros

**Fecha:** 2026-10-16
**Asistentes:** Mauricio Pérez

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4500 | Requerimiento REQ-4500 | Gustavo Neira | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-13 | — |
| REQ-4501 | Requerimiento REQ-4501 | Ricardo Salas | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-12 | — |
| REQ-4502 | Requerimiento REQ-4502 | Diana Molina | se verifica en producción | — | propuesto | 2026-06-29 | — |
| REQ-4503 | Requerimiento REQ-4503 | Beatriz Cuéllar | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-17 | — |
| REQ-4504 | Requerimiento REQ-4504 | Diana Molina | se verifica en producción | — | aceptado | 2026-08-23 | — |
| REQ-4505 | Requerimiento REQ-4505 | sin asignar | se verifica en producción | Cliente entrevistado | propuesto | 2026-05-09 | — |
| REQ-4506 | Requerimiento REQ-4506 | Sandra Gil | — | Cliente entrevistado | aceptado | 2026-04-24 | — |
| REQ-4507 | Requerimiento REQ-4507 | Camilo Beltrán | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-14 | — |
| REQ-4508 | Requerimiento REQ-4508 | Camilo Beltrán | se verifica en producción | — | aceptado | 2026-06-12 | — |
| REQ-4509 | Requerimiento REQ-4509 | Javier Hoyos | se verifica en producción | — | aceptado | 2026-04-09 | — |
| REQ-4510 | Requerimiento REQ-4510 | Felipe Arango | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-29 | — |
| REQ-4511 | Requerimiento REQ-4511 | Jorge Medina | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-08 | — |

## Decisiones

- Se mantiene el plan
