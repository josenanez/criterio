# Caso de negocio · Cuenta de ahorros joven

**Código:** PRD-308
**Fecha:** 2026-03-01
**Preparado por:** Óscar Ramírez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 84.794 | Caso de negocio, 2026-03-01 |

## Retorno esperado

Retorno esperado en 24 meses.
