# Definición de producto · Recaudos y cobros

**Código:** PRD-305
**Gerente de producto:** Mauricio Pérez
**Segmento:** Base de la pirámide
**Fecha de la definición:** 2026-02-20

## El problema

El segmento Base de la pirámide no tiene recaudos y cobros.

## La propuesta

- Propuesta principal

## Supuestos

- **El segmento paga por esto** · declarado el 2026-08-21 · verificado

## Proyectos que lo construyen

- Ninguno declarado
