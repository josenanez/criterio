# Comité de producto · Nómina empresarial

**Fecha:** 2026-10-16
**Asistentes:** Felipe Arango

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4100 | Requerimiento REQ-4100 | Mauricio Pérez | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-13 | — |
| REQ-4101 | Requerimiento REQ-4101 | Mauricio Pérez | — | — | aceptado | 2026-05-26 | — |
| REQ-4102 | Requerimiento REQ-4102 | Ricardo Salas | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-21 | — |
| REQ-4103 | Requerimiento REQ-4103 | Camilo Beltrán | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-25 | — |
| REQ-4104 | Requerimiento REQ-4104 | Óscar Ramírez | — | Cliente entrevistado | aceptado | 2026-05-29 | — |
| REQ-4105 | Requerimiento REQ-4105 | Diana Molina | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-21 | — |
| REQ-4106 | Requerimiento REQ-4106 | sin asignar | se verifica en producción | — | aceptado | 2026-07-13 | — |
| REQ-4107 | Requerimiento REQ-4107 | Paula Céspedes | se verifica en producción | Cliente entrevistado | propuesto | 2026-08-31 | — |
| REQ-4108 | Requerimiento REQ-4108 | Camilo Beltrán | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-14 | — |
| REQ-4109 | Requerimiento REQ-4109 | sin asignar | se verifica en producción | — | aceptado | 2026-06-24 | — |
| REQ-4110 | Requerimiento REQ-4110 | Laura Vélez | — | Cliente entrevistado | aceptado | 2026-04-20 | — |
| REQ-4111 | Requerimiento REQ-4111 | Diana Molina | se verifica en producción | Cliente entrevistado | propuesto | 2026-05-06 | — |
| REQ-4112 | Requerimiento REQ-4112 | Mauricio Pérez | se verifica en producción | — | propuesto | 2026-07-11 | — |
| REQ-4113 | Requerimiento REQ-4113 | Elena Duarte | — | Cliente entrevistado | aceptado | 2026-08-11 | — |
| REQ-2035 | Requerimiento REQ-2035 | Liliana Torres | se verifica en producción | Cliente entrevistado | aceptado | 2026-10-13 | — |

## Decisiones

- Se mantiene el plan
