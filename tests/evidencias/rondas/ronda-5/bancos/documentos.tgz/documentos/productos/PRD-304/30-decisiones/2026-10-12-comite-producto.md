# Comité de producto · Tarjeta de crédito digital

**Fecha:** 2026-10-12
**Asistentes:** Laura Vélez

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4400 | Requerimiento REQ-4400 | Gustavo Neira | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-05 | — |
| REQ-4401 | Requerimiento REQ-4401 | sin asignar | se verifica en producción | Cliente entrevistado | propuesto | 2026-04-25 | — |
| REQ-4402 | Requerimiento REQ-4402 | María Restrepo | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-06 | — |
| REQ-4403 | Requerimiento REQ-4403 | Felipe Arango | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-24 | — |
| REQ-4404 | Requerimiento REQ-4404 | sin asignar | se verifica en producción | Cliente entrevistado | propuesto | 2026-04-02 | — |
| REQ-4405 | Requerimiento REQ-4405 | Carlos Peña | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-31 | — |
| REQ-4406 | Requerimiento REQ-4406 | Camilo Beltrán | — | — | aceptado | 2026-05-02 | — |
| REQ-4407 | Requerimiento REQ-4407 | Javier Hoyos | se verifica en producción | — | aceptado | 2026-08-26 | — |
| REQ-4408 | Requerimiento REQ-4408 | Óscar Ramírez | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-23 | — |
| REQ-4409 | Requerimiento REQ-4409 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-01 | — |
| REQ-4410 | Requerimiento REQ-4410 | sin asignar | se verifica en producción | — | propuesto | 2026-06-20 | — |
| REQ-4411 | Requerimiento REQ-4411 | Paula Céspedes | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-02 | — |

## Decisiones

- Se mantiene el plan
