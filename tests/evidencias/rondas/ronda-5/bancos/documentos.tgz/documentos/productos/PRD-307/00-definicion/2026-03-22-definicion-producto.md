# Definición de producto · Remesas familiares

**Código:** PRD-307
**Gerente de producto:** Mauricio Pérez
**Segmento:** PyME
**Fecha de la definición:** 2026-03-22

## El problema

El segmento PyME no tiene remesas familiares.

## La propuesta

- Propuesta principal

## Supuestos

- **El canal actual soporta el volumen** · declarado el 2026-08-10 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
