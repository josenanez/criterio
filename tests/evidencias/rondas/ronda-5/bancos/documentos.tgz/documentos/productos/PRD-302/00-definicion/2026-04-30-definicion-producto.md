# Definición de producto · Crédito hipotecario digital

**Código:** PRD-302
**Gerente de producto:** Mauricio Pérez
**Segmento:** PyME
**Fecha de la definición:** 2026-04-30

## El problema

El segmento PyME no tiene crédito hipotecario digital.

## La propuesta

- Propuesta principal

## Supuestos

- **La demanda declarada se sostiene sin campaña** · declarado el 2026-07-21 · verificado

## Proyectos que lo construyen

- Ninguno declarado
