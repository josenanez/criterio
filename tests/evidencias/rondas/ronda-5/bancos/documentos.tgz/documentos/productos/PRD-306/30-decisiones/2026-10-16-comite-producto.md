# Comité de producto · Microseguros

**Fecha:** 2026-10-16
**Asistentes:** Liliana Torres

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4600 | Requerimiento REQ-4600 | Beatriz Cuéllar | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-09 | — |
| REQ-4601 | Requerimiento REQ-4601 | Sandra Gil | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-03 | — |
| REQ-4602 | Requerimiento REQ-4602 | Gustavo Neira | — | Cliente entrevistado | propuesto | 2026-08-25 | — |
| REQ-4603 | Requerimiento REQ-4603 | Natalia Ospina | — | Cliente entrevistado | aceptado | 2026-07-15 | — |
| REQ-4604 | Requerimiento REQ-4604 | Rubén Cárdenas | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-18 | — |
| REQ-4605 | Requerimiento REQ-4605 | María Restrepo | se verifica en producción | Cliente entrevistado | propuesto | 2026-08-09 | — |
| REQ-4606 | Requerimiento REQ-4606 | Jorge Medina | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-22 | — |
| REQ-4607 | Requerimiento REQ-4607 | Carlos Peña | se verifica en producción | Cliente entrevistado | propuesto | 2026-05-01 | — |
| REQ-4608 | Requerimiento REQ-4608 | Ricardo Salas | se verifica en producción | Cliente entrevistado | propuesto | 2026-08-05 | — |
| REQ-4609 | Requerimiento REQ-4609 | Ricardo Salas | se verifica en producción | — | aceptado | 2026-04-07 | — |
| REQ-4610 | Requerimiento REQ-4610 | Gustavo Neira | se verifica en producción | — | aceptado | 2026-05-08 | — |
| REQ-4611 | Requerimiento REQ-4611 | sin asignar | — | — | propuesto | 2026-04-26 | — |
| REQ-4612 | Requerimiento REQ-4612 | Liliana Torres | se verifica en producción | — | propuesto | 2026-04-03 | — |
| REQ-4613 | Requerimiento REQ-4613 | Óscar Ramírez | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-20 | — |

## Decisiones

- Se mantiene el plan
