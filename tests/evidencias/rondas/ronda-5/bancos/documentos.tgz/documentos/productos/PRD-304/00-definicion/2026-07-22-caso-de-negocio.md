# Caso de negocio · Tarjeta de crédito digital

**Código:** PRD-304
**Fecha:** 2026-07-22
**Preparado por:** Laura Vélez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 132.517 | Caso de negocio, 2026-07-22 |

## Retorno esperado

Retorno esperado en 24 meses.
