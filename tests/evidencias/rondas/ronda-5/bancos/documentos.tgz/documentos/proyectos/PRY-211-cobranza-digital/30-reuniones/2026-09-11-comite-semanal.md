# Comité de Riesgos · Cobranza digital

**Fecha:** 2026-09-11
**Asistentes:** Beatriz Cuéllar, Camilo Beltrán, Felipe Arango, Jorge Medina, María Restrepo, Ricardo Salas, Sandra Gil

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Ricardo Salas | Enviar el documento 1 | 2026-09-25 |
| María Restrepo | Cerrar la prueba 2 | 2026-10-08 |
| Camilo Beltrán | Validar el ambiente 4 | 2026-09-13 |
| Ricardo Salas | Aprobar el diseño 5 | 2026-09-29 |
| Felipe Arango | Actualizar la matriz 6 | 2026-09-16 |
| Sandra Gil | Confirmar la fecha 7 | 2026-09-26 |
| Jorge Medina | Entregar el punto 8 | 2026-09-21 |

## Cerrados en esta reunión

- Revisar el anexo 3 (Camilo Beltrán): recibido, acta de recibo del 2026-09-11.
