# Comité de Medios de Pago · Débito contactless

**Fecha:** 2026-10-12
**Asistentes:** María Restrepo, Natalia Ospina

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Rubén Cárdenas | Entregar el punto 18 | 2026-10-03 |
