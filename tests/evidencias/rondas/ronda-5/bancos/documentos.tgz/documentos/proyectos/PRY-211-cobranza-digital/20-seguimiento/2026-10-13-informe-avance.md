# Informe de avance · Cobranza digital

**Código:** PRY-211
**Fecha de corte:** 2026-10-13
**Gerente:** Beatriz Cuéllar

## Estado declarado

**Verde**

Avance reportado: **89%**

## Lo que pasó en el periodo

- La prueba de carga no alcanzó el umbral pactado y se repite

## Presupuesto

| | COP |
|---|---|
| Aprobado | 2.400.000.000 |
| Comprometido | 1.243.793.744 |
| Ejecutado | 949.227.038 |
| Proyección al cierre | 2.771.140.444 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
- Disponibilidad del equipo de seguridad para la revisión final
