# Informe de avance · Débito contactless

**Código:** PRY-204
**Fecha de corte:** 2026-10-07
**Gerente:** María Restrepo

## Estado declarado

**Verde**

Avance reportado: **71%**

## Lo que pasó en el periodo

- La prueba de carga no alcanzó el umbral pactado y se repite
- El equipo perdió dos semanas por rotación de un desarrollador clave
- Se recibió la aprobación regulatoria pendiente desde el trimestre anterior

## Presupuesto

| | COP |
|---|---|
| Aprobado | 9.500.000.000 |
| Comprometido | 4.993.617.766 |
| Ejecutado | 2.541.292.498 |
| Proyección al cierre | 9.687.255.229 |

## Riesgos abiertos

- Disponibilidad del equipo de seguridad para la revisión final
