# Comité de Riesgos · Migración a la nube

**Fecha:** 2026-10-12
**Asistentes:** Laura Vélez, Natalia Ospina

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Liliana Torres | Entregar el punto 27 | por definir |
