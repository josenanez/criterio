# Informe de avance · Billetera y QR

**Código:** PRY-206
**Fecha de corte:** 2026-09-26
**Gerente:** María Restrepo

## Estado declarado

**Verde**

Avance reportado: **62%**

## Lo que pasó en el periodo

- Se ajustó el plan de pruebas con el área de seguridad
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales

## Presupuesto

| | COP |
|---|---|
| Aprobado | 3.300.000.000 |
| Comprometido | 1.760.419.940 |
| Ejecutado | 1.138.791.991 |
| Proyección al cierre | 3.462.552.511 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
- Disponibilidad del equipo de seguridad para la revisión final
