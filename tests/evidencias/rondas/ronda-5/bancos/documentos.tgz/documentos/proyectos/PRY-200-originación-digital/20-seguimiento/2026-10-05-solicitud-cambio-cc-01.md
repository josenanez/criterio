# Solicitud de cambio CC-01

**Proyecto:** PRY-200 · Originación digital
**Fecha:** 2026-10-05
**Solicitante:** Paula Céspedes

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +99 días sobre la línea base vigente |
| Costo | 198.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
