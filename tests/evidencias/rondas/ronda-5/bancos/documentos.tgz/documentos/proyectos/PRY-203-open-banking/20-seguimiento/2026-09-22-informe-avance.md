# Informe de avance · Open Banking

**Código:** PRY-203
**Fecha de corte:** 2026-09-22
**Gerente:** Gustavo Neira

## Estado declarado

**Amarillo**

Avance reportado: **79%**

## Lo que pasó en el periodo

- Se reprogramó la salida por ventana de cambio del área de operaciones

## Presupuesto

| | COP |
|---|---|
| Aprobado | 1.200.000.000 |
| Comprometido | 835.650.697 |
| Ejecutado | 419.562.994 |
| Proyección al cierre | 1.521.476.148 |

## Riesgos abiertos

- Dependencia del calendario de liberaciones del core
