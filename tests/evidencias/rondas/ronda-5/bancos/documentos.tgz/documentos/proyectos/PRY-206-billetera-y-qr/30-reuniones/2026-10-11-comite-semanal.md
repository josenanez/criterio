# Comité de Transformación Digital · Billetera y QR

**Fecha:** 2026-10-11
**Asistentes:** María Restrepo, Diana Molina

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Laura Vélez | Entregar el punto 22 | 2026-10-19 |
