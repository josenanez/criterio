# Comité de Riesgos · Cobranza digital

**Fecha:** 2026-10-09
**Asistentes:** Andrés Lozano, Beatriz Cuéllar, Camilo Beltrán, Carlos Peña, Felipe Arango, Javier Hoyos, Jorge Medina, Laura Vélez, Liliana Torres, María Restrepo, Mauricio Pérez, Natalia Ospina, Paula Céspedes, Ricardo Salas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Ricardo Salas | Enviar el documento 1 | 2026-11-29 |
| María Restrepo | Cerrar la prueba 2 | 2026-11-25 |
| Camilo Beltrán | Validar el ambiente 4 | 2026-09-13 |
| Ricardo Salas | Aprobar el diseño 5 | 2026-10-12 |
| Jorge Medina | Entregar el punto 8 | 2026-10-22 |
| Mauricio Pérez | Enviar el documento 9 | 2026-10-21 |
| Andrés Lozano | Cerrar la prueba 10 | 2026-10-22 |
| Paula Céspedes | Revisar el anexo 11 | 2026-11-08 |
| María Restrepo | Actualizar la matriz 14 | 2026-10-18 |
| Liliana Torres | Confirmar la fecha 15 | 2026-10-20 |
| Ricardo Salas | Enviar el documento 17 | 2026-10-23 |
| Laura Vélez | Revisar el anexo 19 | 2026-10-05 |
| Andrés Lozano | Validar el ambiente 20 | por definir |
| Natalia Ospina | Aprobar el diseño 21 | 2026-11-01 |
| Javier Hoyos | Actualizar la matriz 22 | 2026-11-01 |
| Felipe Arango | Confirmar la fecha 23 | 2026-10-14 |
| Carlos Peña | Entregar el punto 24 | por definir |

## Cerrados en esta reunión

- Aprobar el diseño 13 (Natalia Ospina): recibido, acta de recibo del 2026-10-09.
- Cerrar la prueba 18 (Laura Vélez): recibido, acta de recibo del 2026-10-09.

## Lo que se dijo

- Diana Molina dice que ya entregó «entregar el punto 16». No se presentó acta.
