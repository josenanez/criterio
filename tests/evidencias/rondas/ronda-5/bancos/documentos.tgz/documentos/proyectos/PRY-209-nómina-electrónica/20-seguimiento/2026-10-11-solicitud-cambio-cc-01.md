# Solicitud de cambio CC-01

**Proyecto:** PRY-209 · Nómina electrónica
**Fecha:** 2026-10-11
**Solicitante:** María Restrepo

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +44 días sobre la línea base vigente |
| Costo | 88.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
