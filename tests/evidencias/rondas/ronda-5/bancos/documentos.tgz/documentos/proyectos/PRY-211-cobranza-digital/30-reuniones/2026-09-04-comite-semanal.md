# Comité de Riesgos · Cobranza digital

**Fecha:** 2026-09-04
**Asistentes:** Beatriz Cuéllar, Camilo Beltrán, María Restrepo, Ricardo Salas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Ricardo Salas | Enviar el documento 1 | por definir |
| María Restrepo | Cerrar la prueba 2 | 2026-10-01 |
| Camilo Beltrán | Revisar el anexo 3 | 2026-09-09 |
| Camilo Beltrán | Validar el ambiente 4 | 2026-09-13 |
