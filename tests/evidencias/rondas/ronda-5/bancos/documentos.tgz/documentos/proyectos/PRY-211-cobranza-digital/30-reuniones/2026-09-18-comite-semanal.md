# Comité de Riesgos · Cobranza digital

**Fecha:** 2026-09-18
**Asistentes:** Andrés Lozano, Beatriz Cuéllar, Camilo Beltrán, Felipe Arango, Jorge Medina, María Restrepo, Mauricio Pérez, Natalia Ospina, Paula Céspedes, Ricardo Salas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Ricardo Salas | Enviar el documento 1 | 2026-10-16 |
| María Restrepo | Cerrar la prueba 2 | 2026-10-16 |
| Camilo Beltrán | Validar el ambiente 4 | 2026-09-13 |
| Ricardo Salas | Aprobar el diseño 5 | 2026-09-29 |
| Felipe Arango | Actualizar la matriz 6 | 2026-10-04 |
| Jorge Medina | Entregar el punto 8 | 2026-09-21 |
| Mauricio Pérez | Enviar el documento 9 | 2026-10-12 |
| Andrés Lozano | Cerrar la prueba 10 | 2026-09-26 |
| Paula Céspedes | Revisar el anexo 11 | 2026-10-03 |
| Natalia Ospina | Validar el ambiente 12 | 2026-10-06 |

## Lo que se dijo

- Sandra Gil dice que ya entregó «confirmar la fecha 7». No se presentó acta.
