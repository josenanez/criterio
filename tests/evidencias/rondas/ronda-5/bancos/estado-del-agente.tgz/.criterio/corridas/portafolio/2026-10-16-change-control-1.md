# Corrida · 2026-10-16-change-control-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:change-control PRY-201 mover la salida a producción 30 días

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-201

**Inicio:** 2026-10-16T09:44:58 · **Fin:** 2026-10-16T09:46:20 · **Duración:** 81 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `change-control` | 13 | — | 65 | 50 | Solicitud: mover 30 días la salida a producción de PRY-201. La salida a producción no es hito del plan y el fin vigente (2026-08-20) ya venció, así que no se registró línea base 3. impact: 0 proyectos alcanzados, pero hay una dependencia con el core sin nombrar. Autoridad no declarada; CC-01 sin acta ni nombre. Va a comité. No sé quién pide ni por qué, ni la fecha real de producción. |

Por señal (`change-control`): `milestone_met_without_evidence` 13, `commitment_overdue` 9, `declared_vs_evidence` 6, `commitment_undated` 5, `variance_cost` 4, `progress_vs_plan` 4, `variance_time` 3, `commitment_rescheduled` 2, `rebaseline_unauthorized` 1, `milestone_overdue` 1, `silent` 1, `pm_vs_pmo` 1

## Lo que el agente mostró

Evalué el cambio de PRY-201, pero no registré una línea base nueva: la fecha que se movería ya venció y falta quién autoriza. Sale de la ficha PRY-201 del 2026-10-16. Los términos 1.1 ya estaban aceptados a nombre de José Francisco Ñáñez, así que no los registré otra vez.

- **La «salida a producción» no es un hito del plan.** El cronograma v2 termina en «Piloto con usuarios internos». Usé como referencia el fin vigente, 2026-08-20.
- **Esa fecha ya pasó.** Sumarle 30 días da 2026-09-19, que tampoco es futura. El proyecto está en rojo con 55% declarado, mientras el plan marca 100%. Hace falta una fecha futura real, y nadie la ha propuesto.
- **Impacto en el portafolio:** el cálculo no alcanza a ningún proyecto. Eso no prueba que no haya efecto. El informe habla de una dependencia con el core que no nombra ningún proyecto, y el cálculo no puede recorrerla.
- **Quién decide:** no hay autoridad declarada en la ficha ni cláusula de cambios en el acta, y ese es el hallazgo de fondo. El cambio va al Comité de Riesgos. CC-01 (+43 días, +86 M COP) dice «autorizada por el comité» sin nombre ni acta. La línea base v2 no tiene motivo registrado. El acta fija el cierre en 2026-08-24 y la línea base v1 en 2026-07-08, sin explicación.
- **Desviación:** hoy +43 días (11,6%) contra la línea base original. Con los 30 días serían +73 (≈19,7%) y una segunda replanificación.
- **Costo:** el costo de esos 30 días no está estimado en ningún documento, y no lo inventé.
- **Lo que no sé:** quién pide el cambio y por qué, la fecha real de producción y de qué proyecto depende PRY-201.

Dejé la corrida registrada. Guardé la salida completa en `estado/corridas/salida-change-control.md` y el resumen en `estado/corridas/2026-10-16-change-control-1.md`.
