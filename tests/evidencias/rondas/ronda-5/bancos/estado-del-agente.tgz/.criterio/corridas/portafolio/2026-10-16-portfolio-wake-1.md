# Corrida · 2026-10-16-portfolio-wake-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-wake (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-16T09:57:04 · **Fin:** 2026-10-16T09:58:17 · **Duración:** 72 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-wake` | 13 | — | 49 | 50 | Barrido: 72 documentos, ninguno cambió, sin recálculo. Hallazgo: 17 citas de PRY-211 marcadas como rotas por una copia anidada vieja de la ficha; la vigente resuelve. Confirmación: 5 preguntas sin responder (sin interfaz). No consulté peticiones (no tocaban). No sé quién autorizó el movimiento de PRY-200 ni cuál fecha rige en PRY-211. |

Por señal (`portfolio-wake`): `milestone_met_without_evidence` 13, `commitment_overdue` 9, `declared_vs_evidence` 6, `commitment_undated` 5, `variance_cost` 4, `progress_vs_plan` 4, `variance_time` 3, `commitment_rescheduled` 2, `rebaseline_unauthorized` 1, `milestone_overdue` 1, `silent` 1, `pm_vs_pmo` 1

## Lo que el agente mostró

## 2026-10-16

**Revisé:** 72 documentos · 0 cambiaron · 0 proyectos recalculados. Hoy tocaban el barrido y la confirmación mensual.

### Lo que cruzó un umbral
Nada nuevo, porque ningún documento cambió y no hubo recálculo. Sigue abierto el estado anterior: 13 proyectos, 10 con alertas, 50 alertas en total y 6 proyectos en verde que la evidencia contradice.

Sí hay un hallazgo del barrido, y no es de documentos: el índice marca 17 citas de PRY-211 como rotas, pero los archivos existen. Hay dos copias de la ficha de PRY-211. La vigente (`estado/records/PRY-211.json`) resuelve sus citas. La otra, más vieja y anidada (`estado/PRY-211-cobranza-digital/records/PRY-211.json`), cita con ruta relativa a la carpeta del proyecto. No toqué ninguna de las dos. Falta decidir si se retira la copia anidada.

### Peticiones atendidas
No tocaban, así que no las consulté.

### Preguntas
Nadie las respondió porque la sesión no tiene interfaz. Quedan preguntadas el 16 de octubre, sin respuesta. No las repito.
1. **PRY-200, fecha de fin:** se movió 139 días (36 %) sin cambio autorizado. ¿Quién lo autorizó?
2. **PRY-207, estado:** declarado verde el 24 de septiembre y en silencio 22 días desde entonces. ¿Cuál es el estado hoy?
3. **PRY-211, fecha de fin:** la PMO tiene 2026-12-25 y el gerente 2027-03-01, ambas del 2025-07-08. ¿Cuál rige?
4. **PRY-202, estado:** verde el 15 de octubre, con 24 % de avance declarado frente a 50-75 % que sustenta el plan, y "Integración con el core" vencido hace 3 días. ¿Se mantiene el verde?
5. **PRY-203, proyección de costo:** 1.521 M frente a 1.200 M aprobados, 26,8 % por encima. ¿Hay solicitud de cambio o adición presupuestal?

Aparte, los 13 proyectos aparecen sin autoridad de aprobación declarada.

**Términos:** ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-16), así que no los registré otra vez.

**Corrida registrada:** la salida quedó en `estado/corridas/salida-portfolio-wake.md` y la corrida tardó 49 segundos.

**Vuelvo el 17 de octubre.**
