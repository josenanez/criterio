# Corrida · 2026-10-16-pm-escalate-1

**Agente:** Samuel (proyecto) · **Comando:** `/criterio-project:pm-escalate (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-16T09:27:01 · **Fin:** 2026-10-16T09:28:07 · **Duración:** 66 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `pm-escalate` | 1 | — | 44 | 16 | Paquete de dos decisiones: autoridad no declarada en el acta y sobrecosto de 371.140.444 COP (15,5 %). No corrí impact porque no se mueve ninguna fecha. No sé qué desglosa la proyección, ni qué alcance recortaría la opción B, ni por qué 89 % de avance convive con 39,6 % ejecutado. |

Por señal (`pm-escalate`): `commitment_overdue` 7, `commitment_undated` 3, `milestone_met_without_evidence` 2, `commitment_rescheduled` 2, `variance_cost` 1, `declared_vs_evidence` 1

## Lo que el agente mostró

Armé el paquete de escalamiento de Cobranza digital (PRY-211) con dos decisiones y dejé la corrida registrada. La orden no traía un tema, así que tomé lo que la agenda del 2026-10-30 ya había marcado como escalable.

Los términos ya estaban vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-16), así que no registré nada nuevo.

**1. ¿Quién puede aprobar un gasto por encima de los 2.400.000.000 COP aprobados?**
- El acta no declara la autoridad de la gerente, ni un margen de tolerancia, ni quién aprueba excesos. Por eso este punto va primero.
- Recomiendo que Paula Céspedes (patrocinadora) responda por escrito antes del 2026-10-30 si lo decide ella o el Comité de Riesgos. Que lo decida el comité es una inferencia mía, no un dato del acta.
- No hay una fecha documentada que venza si no se decide hoy. Lo que consta es que el siguiente comité es el 2026-10-30, y lo dije así en el paquete.

**2. ¿Se amplía el presupuesto, se recorta alcance o se espera el ajuste?**
- La proyección declarada es 2.771.140.444 COP, es decir 371.140.444 COP (15,5 %) por encima de lo aprobado.
- Las tres opciones van con su costo: ampliar, recortar o esperar el ajuste.
- Recomiendo esperar el ajuste de Laura Vélez, pero con una fecha: el 2026-10-23 como tarde, para que el comité del 10-30 elija entre ampliar y recortar con la cifra revisada. Esa fecha es mi propuesta y falta acordarla con ella.
- Las notas dicen que Laura mandaría el ajuste «la otra semana», que no es una fecha.

El informe del 2026-10-13 no cuadra consigo mismo. Declara estado verde y 89 % de avance, pero lo ejecutado es solo el 39,6 % del presupuesto y la proyección pasa del 100 %. No sé cuál de las cifras está mal.

- **Qué no calculé:** no corrí `impact` porque ninguna de las dos decisiones mueve una fecha, y el acta declara «Ninguna declarada» en dependencias. No hay otros proyectos alcanzados que pueda nombrar con sustento.
- **Qué no sé:** qué desglosa la proyección, qué alcance recortaría la opción de recorte ni cuánto movería el tiempo.
- **Otros que cumplen el criterio de escalar:** «Cerrar la prueba 2» (seis reprogramaciones) y «Enviar el documento 1» (cuatro). No armé su paquete, porque nadie ha dicho qué los bloquea y sin eso no hay pregunta cerrada que formular. Los dejé listados en el paquete.
- **Qué falta:** llevar el paquete al comité es tuyo, y no le escribí a nadie.

La salida completa está en `/home/claude/banco/ronda-5/bancos/espacio/estado/PRY-211-cobranza-digital/corridas/salida-pm-escalate.md`. La corrida quedó registrada con el id `2026-10-16-pm-escalate-1`.
