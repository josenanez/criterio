# Corrida · 2026-10-16-document-index-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:document-index (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-16T09:37:51 · **Fin:** 2026-10-16T09:38:36 · **Duración:** 45 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `document-index` | 13 | — | 26 | 50 | 72 documentos sin cambio, 0 por releer. 17 citas de PRY-211 no resuelven (ruta sin carpeta del proyecto; los archivos existen). No verifiqué la causa contra la ficha. |

Por señal (`document-index`): `milestone_met_without_evidence` 13, `commitment_overdue` 9, `declared_vs_evidence` 6, `commitment_undated` 5, `variance_cost` 4, `progress_vs_plan` 4, `variance_time` 3, `commitment_rescheduled` 2, `rebaseline_unauthorized` 1, `milestone_overdue` 1, `silent` 1, `pm_vs_pmo` 1

## Lo que el agente mostró

El índice está hecho y la corrida quedó registrada. Falta solo darte el resumen.

## Carpeta al 2026-10-16

**Documentos:** 72 · **Sin cambio:** 72 · **Hay que releer:** 0

- **Cambió el contenido, se reguardó, renombrado o movido, ya no está:** ninguno.
- **Citas que dejaron de resolver:** 17, todas de PRY-211. Apuntan a `00-gobierno/2025-07-08-acta-constitucion.md` (identidad, plan y presupuesto aprobado) y a `20-seguimiento/2026-10-13-informe-avance.md` (estado declarado, avance y dinero). Los dos archivos existen dentro de `PRY-211-cobranza-digital/`. Lo que no resuelve es la ruta de la cita, que está escrita sin la carpeta del proyecto. Es probable que la causa sea ese prefijo, pero no lo verifiqué contra la ficha. No toqué `ficha-pm.json`, que escribe el gerente.
- **Formatos que no se pudieron leer:** ninguno. Este comando no lee contenido.
- **Términos:** ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-16), así que no registré nada nuevo.

No hay documentos por releer, así que no ofrezco `/portfolio-scan`. Lo pendiente es corregir el prefijo de ruta de esas 17 citas, y eso lo decide el dueño de la ficha.

La salida completa quedó en `/home/claude/banco/ronda-5/bancos/espacio/estado/corridas/salida-document-index.md` y la corrida en `estado/corridas/2026-10-16-document-index-1`. La corrida tardó 26 segundos. Registró además 50 hallazgos abiertos sobre 13 proyectos, que vienen de corridas anteriores y no de este índice.
