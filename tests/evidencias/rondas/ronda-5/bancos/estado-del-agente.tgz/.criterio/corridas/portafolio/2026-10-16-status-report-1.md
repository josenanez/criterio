# Corrida · 2026-10-16-status-report-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:status-report PRY-207

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-207

**Inicio:** 2026-10-16T09:38:41 · **Fin:** 2026-10-16T09:39:40 · **Duración:** 59 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `status-report` | 13 | — | 29 | 50 | Informe de PRY-207: verde declarado al 2026-09-24 sin sustento (22 días en silencio, alerta declared_vs_evidence). Fecha de cierre 2026-06-19 ya pasada sin replanificación, el script no la marca. Dije que no sé: hitos, última reunión, autoridad, fase. |

Por señal (`status-report`): `milestone_met_without_evidence` 13, `commitment_overdue` 9, `declared_vs_evidence` 6, `commitment_undated` 5, `variance_cost` 4, `progress_vs_plan` 4, `variance_time` 3, `commitment_rescheduled` 2, `rebaseline_unauthorized` 1, `milestone_overdue` 1, `silent` 1, `pm_vs_pmo` 1

## Lo que el agente mostró

## PRY-207 Onboarding PyME — estado al 2026-10-16

Este informe sale de la ficha `PRY-207.json`, actualizada el 2026-10-16. Las cifras vienen de `portafolio.py compute`. Los términos están vigentes: José Francisco Ñáñez los aceptó el 2026-10-16 para la versión 0.3.11.

**Declara el gerente:** Rubén Cárdenas declara verde y 37% de avance, al 2026-09-24. La declaración tiene 22 días, dentro del límite de 30.
**Sustento documental:** sin sustento. De los datos de la ficha, 0 están marcados como evidencia y 2 como declaración. Los únicos documentos leídos son el acta (2025-06-27) y ese mismo informe de avance.
**Lo que el semáforo no explica:** el silencio. Salta la alerta `declared_vs_evidence`: reporta verde y lleva 22 días sin un documento nuevo, con un umbral de 15.
**Último documento:** 2026-09-24. **Última reunión:** sin dato.

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2026-06-19 | 2026-06-19 | 0 días contra ambas |
| Presupuesto (COP) | 6.800.000.000 | 6.800.000.000 | Proyección 6.389.554.656, que es −6.0% sobre lo aprobado |

- **Gasto:** el ejecutado es 2.689.278.690 (39.5%) y el comprometido 2.965.251.105 (43.6%). El disponible real es 3.834.748.895.
- **Replanificaciones:** 0, y no hay solicitudes de cambio.
- **Cierre ya vencido:** la desviación de 0 días solo dice que nadie movió la fecha. La fecha de cierre (2026-06-19) es anterior a la de hoy y el proyecto declara 37%. El script no lo marca como alerta, pero ningún documento explica el desfase.

### Hitos
Sin dato. La ficha no tiene hitos, así que no se puede decir si alguno se cumplió o venció.

### Dónde no coincide
- El informe del 2026-09-24 declara verde y 37%, y en ese mismo documento reporta dos incidencias: la salida se reprogramó por una ventana de cambio de operaciones, y se perdieron dos semanas por la rotación de un desarrollador clave.
- Ningún documento posterior sostiene ni contradice esa declaración.

### Abierto
- **Riesgo sin valorar:** un cambio regulatorio en discusión puede mover el alcance. No tiene probabilidad, impacto, dueño ni fecha.
- **Incidencias sin dueño, desde 2026-09-24:** la reprogramación de la salida y las dos semanas perdidas por la rotación.
- **Compromisos vencidos y dependencias:** no hay ninguno registrado.

### Sin dato
- **Gobierno y plan:** autoridad, fase, hitos, última reunión, compromisos y dependencias.
- **Datos con 16 meses de antigüedad (más de 12):** 12 campos del acta del 2025-06-27, entre ellos las fechas, el alcance y el presupuesto aprobado.

### Siguiente paso
El silencio supera el umbral y la fecha de cierre está vencida sin replanificar. Puedo preparar el punto de comité, o la solicitud de cambio si se confirma que la fecha cambió sin formalizarse.

---
*Criterio Portafolio v0.3.11 · ficha de PRY-207 del 2026-10-16 · campos inciertos: autoridad, fase, hitos y los 12 campos antiguos · términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.11*

La corrida quedó registrada como `2026-10-16-status-report-1`. El texto completo está en `estado/corridas/salida-status-report.md`.
