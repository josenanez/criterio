# Corrida · 2026-10-16-product-trace-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-trace (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-16T09:59:32 · **Fin:** 2026-10-16T10:00:50 · **Duración:** 77 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-trace` | 17 | — | 50 | 36 | 12 requerimientos decididos el 2026-10-15 y ninguno tiene proyecto; PRY-207 declara cuenta PyME y ningún REQ lo nombra |

Por señal (`product-trace`): `evidence_stale` 14, `requirement_untraced` 12, `requirement_undecided` 5, `requirement_accepted_without_evidence` 2, `requirement_without_owner` 2, `assumption_unverified` 1

## Lo que el agente mostró

## Trazabilidad — Cuenta PyME (PRD-303) · al 2026-10-16
12 decididos · 0 con proyecto · 0 confirmados contra la ficha · 0 entregados

Los términos ya estaban vigentes a nombre de José Francisco Ñáñez (2026-10-16), así que no hubo que registrar nada. Cotejé contra las 13 fichas del portafolio (`estado/records`, PRY-199 a PRY-211).

### Decidido y nadie lo está construyendo
Son los 12 requerimientos aceptados en el comité del 2026-10-15. Ninguno nombra un proyecto. El acta cierra con «Se mantiene el plan» y en ninguno consta quién decidió.

| REQ | Responsable |
|---|---|
| REQ-2030 | Liliana Torres |
| REQ-4301 | Carlos Peña |
| REQ-4302 | Diana Molina |
| REQ-4303 | Camilo Beltrán |
| REQ-4304 | Camilo Beltrán |
| REQ-4305 | Felipe Arango |
| REQ-4306 | sin responsable |
| REQ-4309 | Ricardo Salas |
| REQ-4310 | Natalia Ospina |
| REQ-4312 | Paula Céspedes |
| REQ-4313 | María Restrepo |
| REQ-4314 | Sandra Gil |

- REQ-4305 y REQ-4309 se aceptaron sin evidencia de demanda.
- La evidencia de los otros 10 es de 2025-10-09, con 12 meses de antigüedad.
- Los 5 requerimientos en estado `propuesto` (REQ-4300, 4307, 4308, 4311, 4315) llevan entre 124 y 213 días sin decisión. No cuentan como decididos.

### La traza no se confirma
No aplica. Ningún requerimiento dice que lo ejecute un proyecto, así que no hay nada que contrastar con una ficha.

### Lo que un proyecto construye y el registro no tiene
La ficha de **PRY-207 Onboarding PyME** dice que ejecuta «cuenta PyME», según su acta de constitución del 2025-06-27. Ninguno de los 17 requerimientos lo nombra.

Es probablemente donde se está construyendo lo decidido. La ficha lo nombra por el texto «cuenta PyME», no por el código PRD-303. Alguien tiene que confirmar si es el mismo producto y a qué requerimiento corresponde cada entregable. No lo asumí.

Las otras fichas declaran un producto distinto o ninguno (PRY-202, 205, 208 y 210).

### La cadena completa
La cadena se rompe entre la decisión y el proyecto en los 12 aceptados. Los 5 propuestos no tienen decisión.

### Qué sigue
- Hay 12 requerimientos decididos sin proyecto. `/product-charter` sirve para el que ya esté listo para serlo.
- Antes de eso, conviene una conversación con el gerente de PRY-207 para saber si construye estos requerimientos.

### Corrida registrada
El texto completo quedó en `estado-producto/PRD-303/corridas/salida-product-trace.md`, y la corrida en `2026-10-16-product-trace-1`. Encontró 36 hallazgos y tardó 50 segundos.
