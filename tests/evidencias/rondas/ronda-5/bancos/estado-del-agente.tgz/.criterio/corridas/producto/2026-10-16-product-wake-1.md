# Corrida · 2026-10-16-product-wake-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-wake (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-16T10:01:19 · **Fin:** 2026-10-16T10:03:07 · **Duración:** 108 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-wake` | 17 | — | 74 | 36 | Primera revisión sin corte previo: línea base de 17 requerimientos (35 señales). No verifiqué trazas por código: solo PRY-207 nombra 'cuenta PyME' y queda sin confirmar. Dije que no sé quién decide en el comité ni contrastar el volumen declarado (sin serie medida). Rutas de fuente del registro no resuelven en plan-lectura. |

Por señal (`product-wake`): `evidence_stale` 14, `requirement_untraced` 12, `requirement_undecided` 5, `requirement_accepted_without_evidence` 2, `requirement_without_owner` 2, `assumption_unverified` 1

## Lo que el agente mostró

**Cuenta PyME (PRD-303) · 2026-10-16.** Esta fue la primera revisión del producto y no había un corte anterior. Lo que sigue es la línea base: de aquí en adelante solo reportaré lo que cruce un umbral después de hoy.

Los términos ya estaban vigentes (versión 1.1, aceptados hoy por José Francisco Ñáñez), así que no los volví a pedir. La carpeta tiene 4 documentos y ninguno es nuevo ni cambió, así que no releí nada.

El registro tiene 17 requerimientos: 12 aceptados y 5 propuestos. Ninguno de los 12 aceptados tiene proyecto asignado.

**Lo que necesita decisión**
- **Cinco requerimientos llevan más de 60 días sin decidirse:**
  - REQ-4308 lleva 213 días.
  - REQ-4311 lleva 151 días y además no tiene doliente.
  - REQ-4300 lleva 138 días.
  - REQ-4307 lleva 138 días.
  - REQ-4315 lleva 124 días.
- **No hay nadie nombrado que decida.** El acta del comité del 15 de octubre solo lista a Javier Hoyos como asistente. Ofrezco llevar los cinco al comité.
- **REQ-4305 y REQ-4309 están aceptados sin evidencia** de que alguien los pidiera. REQ-4306 está aceptado y no tiene doliente.
- **El supuesto «El segmento paga por esto» lleva 90 días sin verificarse** (el umbral es 30). Haría falta una prueba de disposición a pagar con clientes del segmento, y ya conviene tratarlo como riesgo registrado.
- **14 requerimientos se apoyan en la entrevista del 9 de octubre de 2025**, que ya cumple 12 meses. La definición pierde sustento hasta que haya descubrimiento nuevo.

**Las trazas**
- La ficha de PRY-207 «Onboarding PyME» dice que ejecuta «cuenta PyME», pero ningún requerimiento apunta a ese proyecto. La coincidencia es solo por nombre, no por código. No la di por confirmada.

**Lo que no pude saber**
- La definición no tiene criterio de éxito.
- El caso de negocio declara un volumen mensual de 149.630 y no hay datos medidos para contrastarlo.
- El plan de lectura no encontró las fuentes de 10 datos del registro, porque las rutas están escritas desde `documentos/…`. Los 4 documentos existen y no cambiaron. Conviene revisar esas rutas.

Dejé hecho el registro de la revisión y el corte del 16 de octubre.

La salida completa quedó en `estado-producto/PRD-303/corridas/salida-product-wake.md`, y la corrida quedó registrada como `2026-10-16-product-wake-1`. Tardó 74 segundos y registró 36 hallazgos. En la nota de la corrida escribí 35 señales, pero la cifra correcta es 36.

**Vuelvo el 2026-11-15.**
