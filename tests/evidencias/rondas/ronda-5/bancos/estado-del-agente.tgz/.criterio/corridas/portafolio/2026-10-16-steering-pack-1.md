# Corrida · 2026-10-16-steering-pack-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:steering-pack (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-16T09:53:23 · **Fin:** 2026-10-16T09:54:50 · **Duración:** 87 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `steering-pack` | 13 | — | 64 | 50 | Paquete de 6 decisiones y 2 escalamientos sobre 13 fichas. Dijo que no sabe: autoridad de decisión (13 de 13 sin dato), comité anterior (sin registro), qué es el core, contenido de CC de PRY-200 y PRY-209. |

Por señal (`steering-pack`): `milestone_met_without_evidence` 13, `commitment_overdue` 9, `declared_vs_evidence` 6, `commitment_undated` 5, `variance_cost` 4, `progress_vs_plan` 4, `variance_time` 3, `commitment_rescheduled` 2, `rebaseline_unauthorized` 1, `milestone_overdue` 1, `silent` 1, `pm_vs_pmo` 1

## Lo que el agente mostró

El paquete de comité está listo para el 2026-10-21. Tiene 6 decisiones y 2 escalamientos sin decisión asociada, sobre las 13 fichas (PRY-199 a PRY-211) con corte 2026-10-16. Los términos v1.1 ya estaban aceptados por José Francisco Ñáñez el 2026-10-16, así que no repetí el registro. Las cifras salen de `compute`.

**Lo que más pesa:** ninguna de las 13 fichas declara quién tiene autoridad para decidir. Por eso el punto 1 es quién decide, y los demás indican quién decide según el acta de cada proyecto, sin verificarlo.

**Las 6 decisiones:**
1. Quién tiene facultad para aprobar cambios de línea base en el portafolio.
2. PRY-201: si se ratifica o se revierte la solicitud de cambio CC-01 (+43 días, +86.000.000 COP). Dice «autorizada por el comité» sin nombre ni acta. Se recomienda no ratificar y exigir una línea base nueva.
3. PRY-200: CC-01 (+99 días) y CC-02 (+40 días) siguen pendientes, y la línea base ya se movió 139 días sin autorización. La v3 salta de v1 a v3 sin motivo registrado.
4. PRY-209: si se aprueba su CC-01 (+44 días, +88.000.000 COP) con el proveedor sin fecha confirmada.
5. Quién es «el core» y quién responde por él. Esa dependencia afecta a PRY-200, 202, 203, 210 y al propio PRY-201.
6. PRY-211: qué fecha de fin rige (2026-12-25 o 2027-03-01) y qué se hace con el sobrecosto del 15,5 %.

**Escalamientos sin decisión asociada:** PRY-208 (sobrecosto proyectado del 23,0 %) y PRY-203 (26,8 %, con un compromiso vencido hace 16 días).

**Lo que el paquete dice que no sabe:**
- Qué se decidió en el comité anterior: no hay registro.
- Qué proyecto es «el core»: es una hipótesis de la PMO, no un dato.
- Qué sustenta las proyecciones de costo de PRY-203 y PRY-208.
- El contenido de las solicitudes de cambio de PRY-200 y PRY-209, más allá de lo que guarda la ficha.

La salida completa está en `estado/corridas/salida-steering-pack.md` y la corrida quedó registrada como `2026-10-16-steering-pack-1`, con 64 segundos medidos y 50 hallazgos. No registré decisiones en las fichas, porque el comité aún no ha sesionado.
