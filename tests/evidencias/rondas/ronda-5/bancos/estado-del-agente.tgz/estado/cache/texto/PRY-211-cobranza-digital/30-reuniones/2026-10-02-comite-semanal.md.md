<!-- origen: PRY-211-cobranza-digital/30-reuniones/2026-10-02-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Riesgos · Cobranza digital

**Fecha:** 2026-10-02
**Asistentes:** Andrés Lozano, Beatriz Cuéllar, Camilo Beltrán, Diana Molina, Jorge Medina, Laura Vélez, Liliana Torres, María Restrepo, Mauricio Pérez, Natalia Ospina, Paula Céspedes, Ricardo Salas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Ricardo Salas | Enviar el documento 1 | 2026-11-20 |
| María Restrepo | Cerrar la prueba 2 | 2026-11-16 |
| Camilo Beltrán | Validar el ambiente 4 | 2026-09-13 |
| Ricardo Salas | Aprobar el diseño 5 | 2026-10-12 |
| Jorge Medina | Entregar el punto 8 | 2026-10-03 |
| Mauricio Pérez | Enviar el documento 9 | 2026-10-12 |
| Andrés Lozano | Cerrar la prueba 10 | 2026-10-07 |
| Paula Céspedes | Revisar el anexo 11 | 2026-11-08 |
| Natalia Ospina | Aprobar el diseño 13 | 2026-10-22 |
| María Restrepo | Actualizar la matriz 14 | 2026-10-18 |
| Liliana Torres | Confirmar la fecha 15 | 2026-10-20 |
| Diana Molina | Entregar el punto 16 | 2026-10-03 |
| Ricardo Salas | Enviar el documento 17 | por definir |
| Laura Vélez | Cerrar la prueba 18 | 2026-10-07 |
| Laura Vélez | Revisar el anexo 19 | 2026-10-05 |
| Andrés Lozano | Validar el ambiente 20 | por definir |

## Lo que se dijo

- Felipe Arango dice que ya entregó «actualizar la matriz 6». No se presentó acta.
