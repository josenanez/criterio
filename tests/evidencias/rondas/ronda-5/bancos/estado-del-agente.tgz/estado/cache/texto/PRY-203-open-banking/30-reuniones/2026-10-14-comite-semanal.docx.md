<!-- origen: PRY-203-open-banking/30-reuniones/2026-10-14-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Arquitectura · Open Banking

Fecha: 2026-10-14

Asistentes: Gustavo Neira, Paula Céspedes

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Beatriz Cuéllar

Entregar el punto 13

2026-09-30
