<!-- origen: PRY-202-migración-a-la-nube/20-seguimiento/2026-10-15-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Migración a la nube
Código: PRY-202
Fecha de corte: 2026-10-15
Gerente: Laura Vélez

Estado declarado
Verde
Avance reportado: 24%

Lo que pasó en el periodo
- Se recibió la aprobación regulatoria pendiente desde el trimestre anterior

Presupuesto
COP
Aprobado 1.200.000.000
Comprometido 702.851.144
Ejecutado 227.406.175
Proyección al cierre 1.230.887.711

Riesgos abiertos
- Concentración del conocimiento en una sola persona
- Cambio regulatorio en discusión que puede mover el alcance
