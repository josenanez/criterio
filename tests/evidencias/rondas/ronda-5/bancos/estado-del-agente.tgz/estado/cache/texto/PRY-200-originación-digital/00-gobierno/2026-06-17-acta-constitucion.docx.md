<!-- origen: PRY-200-originación-digital/00-gobierno/2026-06-17-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Originación digital

Código: PRY-200

Área dueña: Banca de Personas

Patrocinador: Laura Vélez

Gerente de proyecto: Paula Céspedes

Comité: Comité de Transformación Digital

Producto asociado: crédito de consumo

Fecha de aprobación: 2026-06-17

Objetivo del negocio

Entregar originación digital para Banca de Personas.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

4.200.000.000 COP, aprobado por Comité de Transformación Digital el 2026-06-17.

Fechas comprometidas

Fecha

Inicio

2026-06-27

Cierre

2027-09-21

Criterio de éxito

Originación digital en producción y medido.

Dependencias declaradas

• Ninguna declarada
