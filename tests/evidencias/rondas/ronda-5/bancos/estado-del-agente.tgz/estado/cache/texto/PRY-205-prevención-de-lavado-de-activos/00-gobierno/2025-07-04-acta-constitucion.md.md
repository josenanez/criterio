<!-- origen: PRY-205-prevención-de-lavado-de-activos/00-gobierno/2025-07-04-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Prevención de lavado de activos

**Código:** PRY-205
**Área dueña:** Tesorería
**Patrocinador:** Andrés Lozano
**Gerente de proyecto:** Diana Molina
**Comité:** Comité de Transformación Digital
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-07-04

## Objetivo del negocio

Entregar prevención de lavado de activos para Tesorería.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**18.000.000.000 COP**, aprobado por Comité de Transformación Digital el 2025-07-04.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-07-14 |
| Cierre | 2026-08-24 |

## Criterio de éxito

Prevención de lavado de activos en producción y medido.

## Dependencias declaradas

- Ninguna declarada
