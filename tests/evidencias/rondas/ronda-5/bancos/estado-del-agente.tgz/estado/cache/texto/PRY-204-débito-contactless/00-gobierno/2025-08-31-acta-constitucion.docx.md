<!-- origen: PRY-204-débito-contactless/00-gobierno/2025-08-31-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Débito contactless

Código: PRY-204

Área dueña: Tecnología

Patrocinador: Natalia Ospina

Gerente de proyecto: María Restrepo

Comité: Comité de Medios de Pago

Producto asociado: tarjeta débito

Fecha de aprobación: 2025-08-31

Objetivo del negocio

Entregar débito contactless para Tecnología.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

9.500.000.000 COP, aprobado por Comité de Medios de Pago el 2025-08-31.

Fechas comprometidas

Fecha

Inicio

2025-09-10

Cierre

2026-05-20

Criterio de éxito

Débito contactless en producción y medido.

Dependencias declaradas

• Ninguna declarada
