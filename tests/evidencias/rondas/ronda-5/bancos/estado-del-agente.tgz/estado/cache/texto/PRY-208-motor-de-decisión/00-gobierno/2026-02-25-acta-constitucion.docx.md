<!-- origen: PRY-208-motor-de-decisión/00-gobierno/2026-02-25-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Motor de decisión

Código: PRY-208

Área dueña: Banca Hipotecaria

Patrocinador: Javier Hoyos

Gerente de proyecto: Jorge Medina

Comité: Comité de Medios de Pago

Producto asociado: No aplica

Fecha de aprobación: 2026-02-25

Objetivo del negocio

Entregar motor de decisión para Banca Hipotecaria.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

800.000.000 COP, aprobado por Comité de Medios de Pago el 2026-02-25.

Fechas comprometidas

Fecha

Inicio

2026-03-07

Cierre

2027-07-24

Criterio de éxito

Motor de decisión en producción y medido.

Dependencias declaradas

• Ninguna declarada
