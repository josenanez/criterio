<!-- origen: PRY-204-débito-contactless/10-plan/2025-08-31-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2025-11-05,2025-11-05,cerrado
Ambiente de pruebas certificado,2025-12-31,2025-12-31,cerrado
Integración con el core,2026-02-25,2026-02-25,cerrado
Piloto con usuarios internos,2026-04-22,2026-04-22,cerrado
