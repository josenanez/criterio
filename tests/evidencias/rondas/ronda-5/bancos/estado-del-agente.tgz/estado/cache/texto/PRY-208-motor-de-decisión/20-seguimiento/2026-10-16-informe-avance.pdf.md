<!-- origen: PRY-208-motor-de-decisión/20-seguimiento/2026-10-16-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Motor de decisión
Código: PRY-208
Fecha de corte: 2026-10-16
Gerente: Jorge Medina

Estado declarado
Rojo
Avance reportado: 41%

Lo que pasó en el periodo
- Se ajustó el plan de pruebas con el área de seguridad

Presupuesto
COP
Aprobado 800.000.000
Comprometido 674.456.575
Ejecutado 229.794.937
Proyección al cierre 984.226.926

Riesgos abiertos
- Concentración del conocimiento en una sola persona
- El proveedor no ha confirmado la fecha de la última entrega
