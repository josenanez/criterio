<!-- origen: PRY-211-cobranza-digital/30-reuniones/2026-09-04-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Riesgos · Cobranza digital

**Fecha:** 2026-09-04
**Asistentes:** Beatriz Cuéllar, Camilo Beltrán, María Restrepo, Ricardo Salas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Ricardo Salas | Enviar el documento 1 | por definir |
| María Restrepo | Cerrar la prueba 2 | 2026-10-01 |
| Camilo Beltrán | Revisar el anexo 3 | 2026-09-09 |
| Camilo Beltrán | Validar el ambiente 4 | 2026-09-13 |
