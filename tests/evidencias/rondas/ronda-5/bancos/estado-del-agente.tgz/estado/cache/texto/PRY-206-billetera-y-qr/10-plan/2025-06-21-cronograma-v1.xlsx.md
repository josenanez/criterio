<!-- origen: PRY-206-billetera-y-qr/10-plan/2025-06-21-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2025-08-19 | 2025-08-19 | cerrado
Ambiente de pruebas certificado | 2025-10-08 | 2025-10-08 | cerrado
Integración con el core | 2025-11-26 | 2025-11-26 | cerrado
Piloto con usuarios internos | 2026-01-15 | 2026-01-15 | cerrado
