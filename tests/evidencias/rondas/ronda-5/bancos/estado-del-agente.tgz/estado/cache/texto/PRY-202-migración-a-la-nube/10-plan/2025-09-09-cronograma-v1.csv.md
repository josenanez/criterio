<!-- origen: PRY-202-migración-a-la-nube/10-plan/2025-09-09-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2026-01-26,2026-01-26,cerrado
Ambiente de pruebas certificado,2026-06-05,2026-06-05,cerrado
Integración con el core,2026-10-13,2026-10-13,en curso
Piloto con usuarios internos,2027-02-20,2027-02-20,en curso
