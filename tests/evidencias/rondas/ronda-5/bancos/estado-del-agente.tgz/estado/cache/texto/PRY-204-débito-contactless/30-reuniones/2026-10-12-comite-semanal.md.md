<!-- origen: PRY-204-débito-contactless/30-reuniones/2026-10-12-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Medios de Pago · Débito contactless

**Fecha:** 2026-10-12
**Asistentes:** María Restrepo, Natalia Ospina

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Rubén Cárdenas | Entregar el punto 18 | 2026-10-03 |
