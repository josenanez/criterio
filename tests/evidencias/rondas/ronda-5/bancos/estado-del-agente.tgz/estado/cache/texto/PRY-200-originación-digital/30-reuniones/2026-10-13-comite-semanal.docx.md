<!-- origen: PRY-200-originación-digital/30-reuniones/2026-10-13-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Transformación Digital · Originación digital

Fecha: 2026-10-13

Asistentes: Paula Céspedes, Laura Vélez

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Javier Hoyos

Entregar el punto 38

2026-11-10
