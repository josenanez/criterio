<!-- origen: PRY-209-nómina-electrónica/00-gobierno/2025-08-07-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Nómina electrónica

Código: PRY-209

Área dueña: Banca de Personas

Patrocinador: Jorge Medina

Gerente de proyecto: María Restrepo

Comité: Comité de Arquitectura

Producto asociado: nómina empresarial

Fecha de aprobación: 2025-08-07

Objetivo del negocio

Entregar nómina electrónica para Banca de Personas.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

18.000.000.000 COP, aprobado por Comité de Arquitectura el 2025-08-07.

Fechas comprometidas

Fecha

Inicio

2025-08-17

Cierre

2027-03-07

Criterio de éxito

Nómina electrónica en producción y medido.

Dependencias declaradas

• Ninguna declarada
