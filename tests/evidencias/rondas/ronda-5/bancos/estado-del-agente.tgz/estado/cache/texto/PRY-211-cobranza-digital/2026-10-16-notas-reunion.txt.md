<!-- origen: PRY-211-cobranza-digital/2026-10-16-notas-reunion.txt · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

notas reunión cobranza digital — 2026-10-16
estuvieron: Andrés Lozano, Beatriz Cuéllar, Camilo Beltrán, Felipe Arango, Javier Hoyos, Jorge Medina, Laura Vélez, Liliana Torres, María Restrepo, Mauricio Pérez, Natalia Ospina, Paula Céspedes, Ricardo Salas, Óscar Ramírez

- María Restrepo dice que lo de «cerrar la prueba 2» no alcanzó, se compromete para el 09/12/2026
- Laura Vélez queda de mandar el ajuste del presupuesto la otra semana
- Óscar Ramírez: revisión con el proveedor, queda para el 2026-10-26
- se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo
- próxima reunión en dos semanas
