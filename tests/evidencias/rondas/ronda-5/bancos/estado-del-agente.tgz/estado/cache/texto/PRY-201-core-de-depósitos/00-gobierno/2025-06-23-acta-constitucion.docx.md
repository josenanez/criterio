<!-- origen: PRY-201-core-de-depósitos/00-gobierno/2025-06-23-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Core de depósitos

Código: PRY-201

Área dueña: Medios de Pago

Patrocinador: Elena Duarte

Gerente de proyecto: Mauricio Pérez

Comité: Comité de Riesgos

Producto asociado: cuenta de ahorros

Fecha de aprobación: 2025-06-23

Objetivo del negocio

Entregar core de depósitos para Medios de Pago.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

4.200.000.000 COP, aprobado por Comité de Riesgos el 2025-06-23.

Fechas comprometidas

Fecha

Inicio

2025-07-03

Cierre

2026-08-24

Criterio de éxito

Core de depósitos en producción y medido.

Dependencias declaradas

• Ninguna declarada
