<!-- origen: PRY-203-open-banking/00-gobierno/2026-04-08-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Open Banking

Código: PRY-203

Área dueña: Tesorería

Patrocinador: Paula Céspedes

Gerente de proyecto: Gustavo Neira

Comité: Comité de Arquitectura

Producto asociado: APIs de datos

Fecha de aprobación: 2026-04-08

Objetivo del negocio

Entregar open banking para Tesorería.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

1.200.000.000 COP, aprobado por Comité de Arquitectura el 2026-04-08.

Fechas comprometidas

Fecha

Inicio

2026-04-18

Cierre

2027-01-30

Criterio de éxito

Open Banking en producción y medido.

Dependencias declaradas

• Ninguna declarada
