<!-- origen: PRY-210-portal-de-proveedores/20-seguimiento/2026-10-12-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Portal de proveedores
Código: PRY-210
Fecha de corte: 2026-10-12
Gerente: Felipe Arango

Estado declarado
Verde
Avance reportado: 54%

Lo que pasó en el periodo
- La prueba de carga no alcanzó el umbral pactado y se repite
- Dos historias quedaron fuera del alcance del sprint por dependencia con el core

Presupuesto
COP
Aprobado 6.800.000.000
Comprometido 3.599.266.548
Ejecutado 3.386.079.479
Proyección al cierre 6.578.077.871

Riesgos abiertos
- Disponibilidad del equipo de seguridad para la revisión final
