<!-- origen: PRY-207-onboarding-pyme/20-seguimiento/2026-09-24-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Onboarding PyME
Código: PRY-207
Fecha de corte: 2026-09-24
Gerente: Rubén Cárdenas

Estado declarado
Verde
Avance reportado: 37%

Lo que pasó en el periodo
- Se reprogramó la salida por ventana de cambio del área de operaciones
- El equipo perdió dos semanas por rotación de un desarrollador clave

Presupuesto
COP
Aprobado 6.800.000.000
Comprometido 2.965.251.105
Ejecutado 2.689.278.690
Proyección al cierre 6.389.554.656

Riesgos abiertos
- Cambio regulatorio en discusión que puede mover el alcance
