<!-- origen: PRY-200-originación-digital/10-plan/2026-10-04-cronograma-v3.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-11-02 | 2026-11-02 | en curso
Ambiente de pruebas certificado | 2027-03-11 | 2027-03-11 | en curso
Integración con el core | 2027-07-18 | 2027-12-04 | en curso
