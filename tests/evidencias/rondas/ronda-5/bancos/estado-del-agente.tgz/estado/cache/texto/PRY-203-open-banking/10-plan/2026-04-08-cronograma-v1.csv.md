<!-- origen: PRY-203-open-banking/10-plan/2026-04-08-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2026-06-20,2026-06-20,cerrado
Ambiente de pruebas certificado,2026-08-23,2026-08-23,cerrado
Integración con el core,2026-10-26,2026-10-26,en curso
Piloto con usuarios internos,2026-12-29,2026-12-29,en curso
