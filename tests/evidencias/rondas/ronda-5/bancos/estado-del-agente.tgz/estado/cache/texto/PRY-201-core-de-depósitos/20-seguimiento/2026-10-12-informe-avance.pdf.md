<!-- origen: PRY-201-core-de-depósitos/20-seguimiento/2026-10-12-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Core de depósitos
Código: PRY-201
Fecha de corte: 2026-10-12
Gerente: Mauricio Pérez

Estado declarado
Rojo
Avance reportado: 55%

Lo que pasó en el periodo
- El equipo perdió dos semanas por rotación de un desarrollador clave
- Dos historias quedaron fuera del alcance del sprint por dependencia con el core
- La prueba de carga no alcanzó el umbral pactado y se repite

Presupuesto
COP
Aprobado 4.200.000.000
Comprometido 1.271.847.231
Ejecutado 1.977.957.330
Proyección al cierre 4.024.199.525

Riesgos abiertos
- Concentración del conocimiento en una sola persona
