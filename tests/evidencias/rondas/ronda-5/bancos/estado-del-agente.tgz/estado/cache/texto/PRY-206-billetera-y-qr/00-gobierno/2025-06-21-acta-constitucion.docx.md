<!-- origen: PRY-206-billetera-y-qr/00-gobierno/2025-06-21-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Billetera y QR

Código: PRY-206

Área dueña: Operaciones

Patrocinador: Diana Molina

Gerente de proyecto: María Restrepo

Comité: Comité de Transformación Digital

Producto asociado: pagos QR

Fecha de aprobación: 2025-06-21

Objetivo del negocio

Entregar billetera y qr para Operaciones.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

3.300.000.000 COP, aprobado por Comité de Transformación Digital el 2025-06-21.

Fechas comprometidas

Fecha

Inicio

2025-07-01

Cierre

2026-02-09

Criterio de éxito

Billetera y QR en producción y medido.

Dependencias declaradas

• Ninguna declarada
