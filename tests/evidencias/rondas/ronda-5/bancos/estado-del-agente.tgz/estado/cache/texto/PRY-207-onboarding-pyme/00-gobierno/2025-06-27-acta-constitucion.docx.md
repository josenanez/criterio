<!-- origen: PRY-207-onboarding-pyme/00-gobierno/2025-06-27-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Onboarding PyME

Código: PRY-207

Área dueña: Riesgo y Cumplimiento

Patrocinador: Felipe Arango

Gerente de proyecto: Rubén Cárdenas

Comité: Comité de Riesgos

Producto asociado: cuenta PyME

Fecha de aprobación: 2025-06-27

Objetivo del negocio

Entregar onboarding pyme para Riesgo y Cumplimiento.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

6.800.000.000 COP, aprobado por Comité de Riesgos el 2025-06-27.

Fechas comprometidas

Fecha

Inicio

2025-07-07

Cierre

2026-06-19

Criterio de éxito

Onboarding PyME en producción y medido.

Dependencias declaradas

• Ninguna declarada
