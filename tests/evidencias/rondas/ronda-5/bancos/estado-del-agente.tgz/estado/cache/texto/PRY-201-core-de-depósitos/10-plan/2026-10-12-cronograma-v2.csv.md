<!-- origen: PRY-201-core-de-depósitos/10-plan/2026-10-12-cronograma-v2.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2025-10-03,2025-10-03,cerrado
Ambiente de pruebas certificado,2026-01-04,2026-01-04,cerrado
Integración con el core,2026-04-07,2026-04-07,cerrado
Piloto con usuarios internos,2026-07-08,2026-08-20,cerrado
