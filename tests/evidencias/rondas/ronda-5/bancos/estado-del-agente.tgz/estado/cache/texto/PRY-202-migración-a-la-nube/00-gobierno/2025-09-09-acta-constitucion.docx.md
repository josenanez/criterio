<!-- origen: PRY-202-migración-a-la-nube/00-gobierno/2025-09-09-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Migración a la nube

Código: PRY-202

Área dueña: Tecnología

Patrocinador: Natalia Ospina

Gerente de proyecto: Laura Vélez

Comité: Comité de Riesgos

Producto asociado: No aplica

Fecha de aprobación: 2025-09-09

Objetivo del negocio

Entregar migración a la nube para Tecnología.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

1.200.000.000 COP, aprobado por Comité de Riesgos el 2025-09-09.

Fechas comprometidas

Fecha

Inicio

2025-09-19

Cierre

2027-04-26

Criterio de éxito

Migración a la nube en producción y medido.

Dependencias declaradas

• Ninguna declarada
