<!-- origen: PRY-200-originación-digital/20-seguimiento/2026-10-04-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Originación digital
Código: PRY-200
Fecha de corte: 2026-10-04
Gerente: Paula Céspedes

Estado declarado
Rojo
Avance reportado: 24%

Lo que pasó en el periodo
- Se levantó un hallazgo de seguridad en la revisión de arquitectura
- Dos historias quedaron fuera del alcance del sprint por dependencia con el core

Presupuesto
COP
Aprobado 4.200.000.000
Comprometido 1.745.461.657
Ejecutado 1.470.873.795
Proyección al cierre 4.643.424.770

Riesgos abiertos
- Disponibilidad del equipo de seguridad para la revisión final
