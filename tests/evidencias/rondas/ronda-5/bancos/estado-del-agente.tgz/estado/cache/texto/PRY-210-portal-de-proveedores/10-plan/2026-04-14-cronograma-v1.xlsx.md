<!-- origen: PRY-210-portal-de-proveedores/10-plan/2026-04-14-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-06-23 | 2026-06-23 | cerrado
Ambiente de pruebas certificado | 2026-08-22 | 2026-08-22 | cerrado
Integración con el core | 2026-10-21 | 2026-10-21 | en curso
Piloto con usuarios internos | 2026-12-20 | 2026-12-20 | en curso
