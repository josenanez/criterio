<!-- origen: PRY-202-migración-a-la-nube/30-reuniones/2026-10-12-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Riesgos · Migración a la nube

**Fecha:** 2026-10-12
**Asistentes:** Laura Vélez, Natalia Ospina

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Liliana Torres | Entregar el punto 27 | por definir |
