<!-- origen: PRY-205-prevención-de-lavado-de-activos/20-seguimiento/2026-10-14-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Prevención de lavado de activos

**Código:** PRY-205
**Fecha de corte:** 2026-10-14
**Gerente:** Diana Molina

## Estado declarado

**Amarillo**

Avance reportado: **77%**

## Lo que pasó en el periodo

- Se recibió la aprobación regulatoria pendiente desde el trimestre anterior

## Presupuesto

| | COP |
|---|---|
| Aprobado | 18.000.000.000 |
| Comprometido | 12.133.711.642 |
| Ejecutado | 4.201.895.790 |
| Proyección al cierre | 16.628.242.018 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
