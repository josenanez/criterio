<!-- origen: PRY-209-nómina-electrónica/20-seguimiento/2026-10-15-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Nómina electrónica
Código: PRY-209
Fecha de corte: 2026-10-15
Gerente: María Restrepo

Estado declarado
Amarillo
Avance reportado: 43%

Lo que pasó en el periodo
- Se recibió la aprobación regulatoria pendiente desde el trimestre anterior
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales
- Se ajustó el plan de pruebas con el área de seguridad

Presupuesto
COP
Aprobado 18.000.000.000
Comprometido 10.618.314.215
Ejecutado 8.999.767.611
Proyección al cierre 16.894.433.848

Riesgos abiertos
- El proveedor no ha confirmado la fecha de la última entrega
