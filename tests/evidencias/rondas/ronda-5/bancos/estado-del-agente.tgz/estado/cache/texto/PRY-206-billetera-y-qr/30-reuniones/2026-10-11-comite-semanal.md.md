<!-- origen: PRY-206-billetera-y-qr/30-reuniones/2026-10-11-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Transformación Digital · Billetera y QR

**Fecha:** 2026-10-11
**Asistentes:** María Restrepo, Diana Molina

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Laura Vélez | Entregar el punto 22 | 2026-10-19 |
