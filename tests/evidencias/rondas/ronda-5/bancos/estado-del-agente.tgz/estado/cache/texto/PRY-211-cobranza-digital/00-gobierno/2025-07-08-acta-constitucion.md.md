<!-- origen: PRY-211-cobranza-digital/00-gobierno/2025-07-08-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Cobranza digital

**Código:** PRY-211
**Área dueña:** Canales Digitales
**Patrocinador:** Paula Céspedes
**Gerente de proyecto:** Beatriz Cuéllar
**Comité:** Comité de Riesgos
**Producto asociado:** recaudos
**Fecha de aprobación:** 2025-07-08

## Objetivo del negocio

Entregar cobranza digital para Canales Digitales.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**2.400.000.000 COP**, aprobado por Comité de Riesgos el 2025-07-08.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-07-18 |
| Cierre | 2027-03-01 |

## Criterio de éxito

Cobranza digital en producción y medido.

## Dependencias declaradas

- Ninguna declarada
