<!-- origen: PRY-200-originación-digital/20-seguimiento/2026-10-11-solicitud-cambio-cc-02.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-02

**Proyecto:** PRY-200 · Originación digital
**Fecha:** 2026-10-11
**Solicitante:** Paula Céspedes

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +40 días sobre la línea base vigente |
| Costo | 80.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
