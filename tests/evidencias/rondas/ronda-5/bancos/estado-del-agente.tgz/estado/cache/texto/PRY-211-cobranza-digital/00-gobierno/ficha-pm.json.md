<!-- origen: PRY-211-cobranza-digital/00-gobierno/ficha-pm.json · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

{
 "schema_version": "0.2",
 "identity": {
 "code": {
 "value": "PRY-211",
 "source": "00-gobierno/2025-07-08-acta-constitucion.md",
 "source_date": "2025-07-08",
 "state": "found"
 },
 "name": {
 "value": "Cobranza digital",
 "source": "00-gobierno/2025-07-08-acta-constitucion.md",
 "source_date": "2025-07-08",
 "state": "found"
 },
 "aliases": [],
 "business_area": {
 "value": "Canales Digitales",
 "source": "00-gobierno/2025-07-08-acta-constitucion.md",
 "source_date": "2025-07-08",
 "state": "found"
 },
 "product": {
 "value": "recaudos",
 "source": "00-gobierno/2025-07-08-acta-constitucion.md",
 "source_date": "2025-07-08",
 "state": "found"
 },
 "authority": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "sponsor": {
 "value": "Paula Céspedes",
 "source": "00-gobierno/2025-07-08-acta-constitucion.md",
 "source_date": "2025-07-08",
 "state": "found"
 },
 "manager": {
 "value": "Beatriz Cuéllar",
 "source": "00-gobierno/2025-07-08-acta-constitucion.md",
 "source_date": "2025-07-08",
 "state": "found"
 },
 "committee": {
 "value": "Comité de Riesgos",
 "source": "00-gobierno/2025-07-08-acta-constitucion.md",
 "source_date": "2025-07-08",
 "state": "found"
 },
 "phase": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 }
 },
 "declared": {
 "status": {
 "value": "verde",
 "source": "20-seguimiento/2026-10-13-informe-avance.md",
 "source_date": "2026-10-13",
 "state": "found",
 "source_kind": "declaration"
 },
 "progress_pct": {
 "value": 89,
 "source": "20-seguimiento/2026-10-13-informe-avance.md",
 "source_date": "2026-10-13",
 "state": "found",
 "source_kind": "declaration"
 },
 "as_of": "2026-10-13",
 "source": "20-seguimiento/2026-10-13-informe-avance.md"
 },
 "plan": {
 "start_date": {
 "value": "2025-07-18",
 "source": "00-gobierno/2025-07-08-acta-constitucion.md",
 "source_date": "2025-07-08",
 "state": "found"
 },
 "end_date": {
 "value": "2027-03-01",
 "source": "00-gobierno/2025-07-08-acta-constitucion.md",
 "source_date": "2025-07-08",
 "state": "found"
 },
 "baseline": [
 {
 "version": 1,
 "approved_on": "2025-07-08",
 "start_date": "2025-07-18",
 "end_date": "2027-03-01",
 "reason": "Aprobación inicial del Comité de Riesgos",
 "source": "00-gobierno/2025-07-08-acta-constitucion.md"
 }
 ],
 "milestones": [
 {
 "name": "Diseño funcional aprobado",
 "baseline_date": "2025-11-26",
 "current_date": "2025-11-26",
 "state": "met",
 "evidence": null,
 "source": "10-plan/2025-07-08-cronograma-v1.xlsx"
 },
 {
 "name": "Ambiente de pruebas certificado",
 "baseline_date": "2026-04-06",
 "current_date": "2026-04-06",
 "state": "met",
 "evidence": null,
 "source": "10-plan/2025-07-08-cronograma-v1.xlsx"
 },
 {
 "name": "Integración con el core",
 "baseline_date": "2026-08-16",
 "current_date": "2026-08-16",
 "state": "met",
 "evidence": "20-seguimiento/2026-10-14-acta-recibo-integración-con-el-core.md",
 "source": "10-plan/2025-07-08-cronograma-v1.xlsx"
 },
 {
 "name": "Piloto con usuarios internos",
 "baseline_date": "2026-12-25",
 "current_date": "2026-12-25",
 "state": "pending",
 "evidence": null,
 "source": "10-plan/2025-07-08-cronograma-v1.xlsx"
 }
 ],
 "scope_summary": {
 "value": "Componente 1, Componente 2, Componente 3 (el acta no los describe)",
 "source": "00-gobierno/2025-07-08-acta-constitucion.md",
 "source_date": "2025-07-08",
 "state": "found"
 },
 "exclusions": {
 "value": "Lo que otro proyecto cubre",
 "source": "00-gobierno/2025-07-08-acta-constitucion.md",
 "source_date": "2025-07-08",
 "state": "found"
 }
 },
 "money": {
 "currency": "COP",
 "approved": {
 "value": 2400000000,
 "source": "00-gobierno/2025-07-08-acta-constitucion.md",
 "source_date": "2025-07-08",
 "state": "found"
 },
 "committed": {
 "value": 1243793744,
 "source": "20-seguimiento/2026-10-13-informe-avance.md",
 "source_date": "2026-10-13",
 "state": "found",
 "source_kind": "declaration"
 },
 "executed": {
 "value": 949227038,
 "source": "20-seguimiento/2026-10-13-informe-avance.md",
 "source_date": "2026-10-13",
 "state": "found",
 "source_kind": "declaration"
 },
 "projection": {
 "value": 2771140444,
 "source": "20-seguimiento/2026-10-13-informe-avance.md",
 "source_date": "2026-10-13",
 "state": "found",
 "source_kind": "declaration"
 }
 },
 "vendors": [],
 "raid": {
 "risks": [
 {
 "what": "El proveedor no ha confirmado la fecha de la última entrega",
 "owner": "no_identificado",
 "probability": "no_declarada",
 "impact": "no_declarada",
 "due_date": "no_declarada",
 "last_moved": "2026-10-13",
 "source": "20-seguimiento/2026-10-13-informe-avance.md"
 },
 {
 "what": "Disponibilidad del equipo de seguridad para la revisión final",
 "owner": "no_identificado",
 "probability": "no_declarada",
 "impact": "no_declarada",
 "due_date": "no_declarada",
 "last_moved": "2026-10-13",
 "source": "20-seguimiento/2026-10-13-informe-avance.md"
 },
 {
 "what": "El proveedor podría no llegar con el equipo completo para la siguiente fase (dicho en la reunión; nadie lo anotó como riesgo)",
 "owner": "no_identificado",
 "probability": "no_declarada",
 "impact": "no_declarada",
 "due_date": "no_declarada",
 "last_moved": "2026-10-16",
 "source": "2026-10-16-notas-reunion.txt"
 }
 ],
 "assumptions": [],
 "issues": [
 {
 "what": "La prueba de carga no alcanzó el umbral pactado y se repite",
 "since": "2026-10-13",
 "owner": "no_identificado",
 "source": "20-seguimiento/2026-10-13-informe-avance.md"
 }
 ],
 "dependencies": []
 },
 "changes": [],
 "commitments": [
 {
 "who": "Ricardo Salas",
 "what": "Enviar el documento 1",
 "due_date": "2026-11-29",
 "original_due_date": "2026-09-25",
 "stated_on": "2026-09-04",
 "source": "30-reuniones/2026-09-04-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-16",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md"
 },
 {
 "due_date": "2026-11-01",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md"
 },
 {
 "due_date": "2026-11-20",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md"
 },
 {
 "due_date": "2026-11-29",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md"
 }
 ],
 "note": "Se prometió «por definir» el 2026-09-04; la primera fecha (2026-09-25) la puso la minuta del 2026-09-11 y no cuenta como reprogramación."
 },
 {
 "who": "María Restrepo",
 "what": "Cerrar la prueba 2",
 "due_date": "2026-12-09",
 "original_due_date": "2026-10-01",
 "stated_on": "2026-09-04",
 "source": "30-reuniones/2026-09-04-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-08",
 "stated_on": "2026-09-11",
 "source": "30-reuniones/2026-09-11-comite-semanal.md"
 },
 {
 "due_date": "2026-10-16",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md"
 },
 {
 "due_date": "2026-10-27",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md"
 },
 {
 "due_date": "2026-11-16",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md"
 },
 {
 "due_date": "2026-11-25",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md"
 },
 {
 "due_date": "2026-12-09",
 "stated_on": "2026-10-16",
 "source": "2026-10-16-notas-reunion.txt"
 }
 ],
 "note": "Las notas del 2026-10-16 dicen «09/12/2026»; se lee día/mes (9 de diciembre) porque 12 de septiembre ya pasó y no tendría sentido como nueva promesa. Confirmar con ella."
 },
 {
 "who": "Camilo Beltrán",
 "what": "Revisar el anexo 3",
 "due_date": "2026-09-09",
 "original_due_date": "2026-09-09",
 "stated_on": "2026-09-04",
 "source": "30-reuniones/2026-09-04-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-09-11-acta-recibo-3.md",
 "note": "Recibido el 2026-09-11, dos días después de la fecha prometida."
 },
 {
 "who": "Camilo Beltrán",
 "what": "Validar el ambiente 4",
 "due_date": "2026-09-13",
 "original_due_date": "2026-09-13",
 "stated_on": "2026-09-04",
 "source": "30-reuniones/2026-09-04-comite-semanal.md",
 "state": "overdue",
 "reschedules": [],
 "note": "La misma fecha aparece sin cambio en las seis minutas del 2026-09-04 al 2026-10-09; nadie la reprogramó ni la cerró. No se menciona en las notas del 2026-10-16."
 },
 {
 "who": "Ricardo Salas",
 "what": "Aprobar el diseño 5",
 "due_date": "2026-10-12",
 "original_due_date": "2026-09-29",
 "stated_on": "2026-09-11",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "state": "overdue",
 "reschedules": [
 {
 "due_date": "2026-10-12",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md"
 }
 ],
 "note": "Sin acta de recibo. No se menciona en las notas del 2026-10-16."
 },
 {
 "who": "Felipe Arango",
 "what": "Actualizar la matriz 6",
 "due_date": "2026-10-04",
 "original_due_date": "2026-09-16",
 "stated_on": "2026-09-11",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "state": "overdue",
 "reschedules": [
 {
 "due_date": "2026-10-04",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md"
 }
 ],
 "note": "El 2026-10-02 la minuta dice «Felipe Arango dice que ya entregó. No se presentó acta»; sin acta no se cierra. Desde el 2026-10-09 ya no figura en la tabla."
 },
 {
 "who": "Sandra Gil",
 "what": "Confirmar la fecha 7",
 "due_date": "2026-09-26",
 "original_due_date": "2026-09-26",
 "stated_on": "2026-09-11",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "state": "overdue",
 "reschedules": [],
 "note": "El 2026-09-18 la minuta dice «Sandra Gil dice que ya entregó. No se presentó acta»; sin acta no se cierra. Desde el 2026-09-25 ya no figura en la tabla ni entre los asistentes."
 },
 {
 "who": "Jorge Medina",
 "what": "Entregar el punto 8",
 "due_date": "2026-10-22",
 "original_due_date": "2026-09-21",
 "stated_on": "2026-09-11",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-03",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md"
 },
 {
 "due_date": "2026-10-22",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Mauricio Pérez",
 "what": "Enviar el documento 9",
 "due_date": "2026-10-21",
 "original_due_date": "2026-10-12",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-21",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Andrés Lozano",
 "what": "Cerrar la prueba 10",
 "due_date": "2026-10-22",
 "original_due_date": "2026-09-26",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-07",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md"
 },
 {
 "due_date": "2026-10-22",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Paula Céspedes",
 "what": "Revisar el anexo 11",
 "due_date": "2026-11-08",
 "original_due_date": "2026-10-03",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-18",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md"
 },
 {
 "due_date": "2026-11-08",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Natalia Ospina",
 "what": "Validar el ambiente 12",
 "due_date": "2026-10-06",
 "original_due_date": "2026-10-06",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-09-25-acta-recibo-12.md"
 },
 {
 "who": "Natalia Ospina",
 "what": "Aprobar el diseño 13",
 "due_date": "2026-10-22",
 "original_due_date": "2026-10-22",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-10-09-acta-recibo-13.md"
 },
 {
 "who": "María Restrepo",
 "what": "Actualizar la matriz 14",
 "due_date": "2026-10-18",
 "original_due_date": "2026-10-18",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "state": "open",
 "reschedules": [],
 "note": "No se menciona en las notas del 2026-10-16."
 },
 {
 "who": "Liliana Torres",
 "what": "Confirmar la fecha 15",
 "due_date": "2026-10-20",
 "original_due_date": "2026-10-10",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-20",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Diana Molina",
 "what": "Entregar el punto 16",
 "due_date": "2026-10-03",
 "original_due_date": "2026-10-03",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "state": "overdue",
 "reschedules": [],
 "note": "El 2026-10-09 la minuta dice «Diana Molina dice que ya entregó. No se presentó acta»; sin acta no se cierra. Ya no figura en la tabla."
 },
 {
 "who": "Ricardo Salas",
 "what": "Enviar el documento 17",
 "due_date": "2026-10-23",
 "original_due_date": "2026-10-23",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "state": "open",
 "reschedules": [],
 "note": "Se prometió «por definir» el 2026-10-02; la fecha la puso la minuta del 2026-10-09 y es la primera, no una reprogramación."
 },
 {
 "who": "Laura Vélez",
 "what": "Cerrar la prueba 18",
 "due_date": "2026-10-07",
 "original_due_date": "2026-10-07",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-10-09-acta-recibo-18.md"
 },
 {
 "who": "Laura Vélez",
 "what": "Revisar el anexo 19",
 "due_date": "2026-10-05",
 "original_due_date": "2026-10-05",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "state": "overdue",
 "reschedules": [],
 "note": "Sin acta de recibo. No se menciona en las notas del 2026-10-16."
 },
 {
 "who": "Andrés Lozano",
 "what": "Validar el ambiente 20",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "state": "open",
 "reschedules": [],
 "note": "«Por definir» en las minutas del 2026-10-02 y del 2026-10-09."
 },
 {
 "who": "Natalia Ospina",
 "what": "Aprobar el diseño 21",
 "due_date": "2026-11-01",
 "original_due_date": "2026-11-01",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Javier Hoyos",
 "what": "Actualizar la matriz 22",
 "due_date": "2026-11-01",
 "original_due_date": "2026-11-01",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Felipe Arango",
 "what": "Confirmar la fecha 23",
 "due_date": "2026-10-14",
 "original_due_date": "2026-10-14",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "state": "overdue",
 "reschedules": [],
 "note": "Sin acta de recibo. No se menciona en las notas del 2026-10-16."
 },
 {
 "who": "Carlos Peña",
 "what": "Entregar el punto 24",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "state": "open",
 "reschedules": [],
 "note": "«Por definir» el 2026-10-09. Carlos Peña no aparece entre los asistentes del 2026-10-16."
 },
 {
 "who": "Laura Vélez",
 "what": "Mandar el ajuste del presupuesto",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-10-16",
 "source": "2026-10-16-notas-reunion.txt",
 "state": "open",
 "reschedules": [],
 "note": "Las notas dicen «la otra semana»: no es una fecha, y no se calcula."
 },
 {
 "who": "Óscar Ramírez",
 "what": "Revisión con el proveedor",
 "due_date": "2026-10-26",
 "original_due_date": "2026-10-26",
 "stated_on": "2026-10-16",
 "source": "2026-10-16-notas-reunion.txt",
 "state": "open",
 "reschedules": []
 }
 ],
 "activity": {},
 "meta": {
 "record_updated": "2026-10-16",
 "documents_seen": [
 {
 "path": "00-gobierno/2025-07-08-acta-constitucion.md",
 "hash": "e9f694b99dbd991518a3bb591bb796074928d3402879f36606a5c7281c126cd1",
 "text_hash": "",
 "date": "2025-07-08"
 },
 {
 "path": "10-plan/2025-07-08-cronograma-v1.xlsx",
 "hash": "935752a8faa5f2470a5fe6cecd5cef8729818f17703584edf728d09258226ec3",
 "text_hash": "",
 "date": "2025-07-08"
 },
 {
 "path": "20-seguimiento/2026-09-11-acta-recibo-3.md",
 "hash": "c0bee656143d4dea58feab826c2f2b3e90fbc5999354c71e84f82f1b2735ad52",
 "text_hash": "",
 "date": "2026-09-11"
 },
 {
 "path": "20-seguimiento/2026-09-25-acta-recibo-12.md",
 "hash": "fc4f6ab134ab5b765ed087f57b5ea304eb3f3530b6b00e709c8e7ae18c383f95",
 "text_hash": "",
 "date": "2026-09-25"
 },
 {
 "path": "20-seguimiento/2026-10-09-acta-recibo-13.md",
 "hash": "98562ba82dc73d693d108ff36759ba88ebaf64964bd06ac259d5a6a6915c339c",
 "text_hash": "",
 "date": "2026-10-09"
 },
 {
 "path": "20-seguimiento/2026-10-09-acta-recibo-18.md",
 "hash": "802809986bc3fc15905a4631c972e1452698e914a768a957a339ebf740bd8b99",
 "text_hash": "",
 "date": "2026-10-09"
 },
 {
 "path": "20-seguimiento/2026-10-13-informe-avance.md",
 "hash": "542977416569717c707a6db8219f55ec1a68aed611123bde605afcaad7231639",
 "text_hash": "",
 "date": "2026-10-13"
 },
 {
 "path": "20-seguimiento/2026-10-14-acta-recibo-integración-con-el-core.md",
 "hash": "35f277d86bbe5d8fe099592e62125a60c6128aecab5808ece8d9eea20422a96a",
 "text_hash": "",
 "date": "2026-10-14"
 },
 {
 "path": "2026-10-16-notas-reunion.txt",
 "hash": "a9cb12504f1dc950aba704051e09e06b2812e2df073ed04b698a9e5228c53aa4",
 "text_hash": "",
 "date": "2026-10-16"
 },
 {
 "path": "30-reuniones/2026-09-04-comite-semanal.md",
 "hash": "edefcfd03ab8c5ba52383134f574d1b26fc1ad73004ea12417df24a51e222eab",
 "text_hash": "",
 "date": "2026-09-04"
 },
 {
 "path": "30-reuniones/2026-09-11-comite-semanal.md",
 "hash": "26de4bba8f3d82c6d735268cb6a184e847cd6fd60ceeacdd48cbba78c1a7527f",
 "text_hash": "",
 "date": "2026-09-11"
 },
 {
 "path": "30-reuniones/2026-09-18-comite-semanal.md",
 "hash": "f0705797935eb8abef101759cf1d12232df5c353e84f65edb7dcfad4f943697b",
 "text_hash": "",
 "date": "2026-09-18"
 },
 {
 "path": "30-reuniones/2026-09-25-comite-semanal.md",
 "hash": "6d19a4d8c9d0b57f1aeffbc25968375854f9a6bdb0c388e8fe93f97d80f3799d",
 "text_hash": "",
 "date": "2026-09-25"
 },
 {
 "path": "30-reuniones/2026-10-02-comite-semanal.md",
 "hash": "f29733980bcdc7ffff86c70615bbc7c9faa314ee26e6afc92a4a4f975889de59",
 "text_hash": "",
 "date": "2026-10-02"
 },
 {
 "path": "30-reuniones/2026-10-09-comite-semanal.md",
 "hash": "e75b0144a80ea5e89fbab9d1d84503d9630e976fb2b478a1af83d9cc4ac50cf3",
 "text_hash": "",
 "date": "2026-10-09"
 }
 ],
 "fields_not_found": [
 "identity.authority",
 "identity.phase",
 "vendors",
 "changes"
 ],
 "open_conflicts": [],
 "note": "Lectura de pm-setup: todas las minutas (6 comités y las notas del 2026-10-16), las 5 actas de recibo, el informe, el acta de constitución y el cronograma. Sin sellar."
 }
}
