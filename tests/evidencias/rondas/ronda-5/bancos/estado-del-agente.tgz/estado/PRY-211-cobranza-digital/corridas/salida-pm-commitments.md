## Compromisos — Cobranza digital (PRY-211) · al 2026-10-16

**Términos:** vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-16); no hizo falta registrarlos de nuevo. Resumen y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal

Los números salen de `compute`: 7 vencidos sin evidencia, 2 reprogramados 3 o más veces, 3 sin fecha.

### Se viene reprogramando

> **María Restrepo** · Cerrar la prueba 2
> Prometido para el 2026-12-09, y antes para el 11-25, el 11-16, el 10-27, el 10-16 y el 10-08. La primera promesa fue el 2026-10-01. **Seis reprogramaciones.**
> Fuentes: comités del 09-11, 09-18, 09-25, 10-02, 10-09 y notas del 2026-10-16.
> Ojo: las notas del 10-16 dicen «09/12/2026»; se leyó día/mes (9 de diciembre). Falta confirmarlo con ella. Además, las notas dicen que «no alcanzó» y la fecha vigente era el 11-25, que aún no llegaba: no se sabe qué fue lo que no alcanzó.

> **Ricardo Salas** · Enviar el documento 1
> Prometido para el 2026-11-29, y antes para el 11-20, el 11-01 y el 10-16. La primera promesa fue el 2026-09-25 (dicho el 09-04 como «por definir»; esa fecha no cuenta como reprogramación). **Cuatro reprogramaciones.** Fuentes: comités del 09-18, 09-25, 10-02 y 10-09.
> Ricardo Salas además tiene vencido «Aprobar el diseño 5» (ver abajo).

**Tres o más veces no es un problema de seguimiento: es un bloqueo que nadie ha nombrado.** Los dos casos están en el mismo patrón, y la fecha nueva siempre se corrió un poco más de lo que quedaba.

### Vencidos sin evidencia
| Quién | Qué | Prometido para | Hace |
|---|---|---|---|
| Camilo Beltrán | Validar el ambiente 4 | 2026-09-13 | 33 días |
| Sandra Gil | Confirmar la fecha 7 | 2026-09-26 | 20 días |
| Diana Molina | Entregar el punto 16 | 2026-10-03 | 13 días |
| Felipe Arango | Actualizar la matriz 6 | 2026-10-04 | 12 días |
| Laura Vélez | Revisar el anexo 19 | 2026-10-05 | 11 días |
| Ricardo Salas | Aprobar el diseño 5 | 2026-10-12 (antes 09-29) | 4 días |
| Felipe Arango | Confirmar la fecha 23 | 2026-10-14 | 2 días |

Sobre la evidencia:
- **Camilo Beltrán:** la fecha 09-13 aparece igual en las seis minutas del 09-04 al 10-09; nadie la reprogramó ni la cerró. No se mencionó el 10-16.
- **Sandra Gil, Diana Molina y Felipe Arango (matriz 6):** las minutas dicen «dice que ya entregó. No se presentó acta». Sin acta de recibo no se cierran: lo que hay es la palabra de cada uno, no un documento. Ninguno figura ya en las tablas de las minutas posteriores, así que se están saliendo del seguimiento sin haberse cerrado.
- **Sandra Gil, Diana Molina y Carlos Peña** no estuvieron en la reunión del 10-16.

### Vencen esta semana (hasta el 2026-10-23)
| Quién | Qué | Para cuándo |
|---|---|---|
| María Restrepo | Actualizar la matriz 14 | 2026-10-18 |
| Liliana Torres | Confirmar la fecha 15 (antes 10-10, reprogramada una vez) | 2026-10-20 |
| Mauricio Pérez | Enviar el documento 9 (antes 10-12, reprogramado una vez) | 2026-10-21 |
| Jorge Medina | Entregar el punto 8 (antes 09-21, reprogramado dos veces) | 2026-10-22 |
| Andrés Lozano | Cerrar la prueba 10 (antes 09-26, reprogramado dos veces) | 2026-10-22 |
| Ricardo Salas | Enviar el documento 17 (primera fecha) | 2026-10-23 |

Dos con dos reprogramaciones (Jorge Medina y Andrés Lozano) están a una más del umbral de bloqueo. Otros abiertos con fecha posterior: Óscar Ramírez, revisión con el proveedor (10-26); Paula Céspedes, revisar el anexo 11 (11-08, reprogramado dos veces); Natalia Ospina, aprobar el diseño 21 (11-01); Javier Hoyos, actualizar la matriz 22 (11-01).

### Sin fecha
| Quién | Qué | Dicho el |
|---|---|---|
| Andrés Lozano | Validar el ambiente 20 («por definir» el 10-02 y el 10-09) | 2026-10-02 |
| Carlos Peña | Entregar el punto 24 («por definir»; no estuvo el 10-16) | 2026-10-09 |
| Laura Vélez | Mandar el ajuste del presupuesto («la otra semana», que no es una fecha y no se calcula) | 2026-10-16 |

Estos no pueden estar vencidos y por eso mismo son los que desaparecen. Dos de ellos llevan 7 días y 14 días sin fecha.

### Cerrados con evidencia
| Quién | Qué | Documento |
|---|---|---|
| Camilo Beltrán | Revisar el anexo 3 (entregado el 09-11, dos días tarde) | 20-seguimiento/2026-09-11-acta-recibo-3.md |
| Natalia Ospina | Validar el ambiente 12 | 20-seguimiento/2026-09-25-acta-recibo-12.md |
| Natalia Ospina | Aprobar el diseño 13 | 20-seguimiento/2026-10-09-acta-recibo-13.md |
| Laura Vélez | Cerrar la prueba 18 | 20-seguimiento/2026-10-09-acta-recibo-18.md |

Es la primera revisión de seguimiento de esta corrida, así que se listan todos los cerrados con acta.

### Contexto
El informe del 2026-10-13 declara **verde**. Los compromisos vencidos y reprogramados son dos de las cuatro señales que `compute` marca como no sostenidas (las otras: hitos «cumplidos» sin evidencia y proyección 15,5 % sobre el presupuesto).

### Después
- **Ofrezco formular como decisión para el comité** lo de María Restrepo (prueba 2, seis veces) y Ricardo Salas (documento 1, cuatro veces): qué se pide, qué pasa si no se decide y quién tiene la facultad. Excede la autoridad de la gerente y por eso sube. Para eso, `/pm-escalate`.
- Si quieres que la PMO vea esto en la ficha, `/pm-publish`.
