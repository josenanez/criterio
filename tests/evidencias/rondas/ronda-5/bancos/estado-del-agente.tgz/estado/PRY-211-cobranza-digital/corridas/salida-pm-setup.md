## Listo — PRY-211 · Cobranza digital

Soy Samuel. Leo lo que pasa en tu proyecto y me acuerdo de lo que se prometió en cada reunión.

**Lo que miré:** 15 documentos · 7 minutas (6 comités semanales del 2026-09-04 al 2026-10-09 y las notas de la reunión del 2026-10-16) · la última del 2026-10-16. Leí las 7 en orden, de la más vieja a la más nueva, más las 5 actas de recibo, el informe de avance del 2026-10-13, el acta de constitución y el cronograma. Todos los formatos se pudieron leer.
**Términos:** aceptados para la versión 0.3.11 (términos 1.1), por José Francisco Ñáñez el 2026-10-16 · comprobante en `.criterio/terminos/aceptacion-criterio-project-0.3.11-2026-10-16.md` y `.pdf` · SHA-256 042a62265e2a038b…

**Cómo se configuró (esta sesión no tuvo interfaz, así que tomé la respuesta sugerida en cada pregunta):**
- Quién eres y qué proyecto es: Beatriz Cuéllar, gerente de PRY-211 Cobranza digital, según el acta de constitución del 2025-07-08.
- Reunión de seguimiento: los viernes (las seis minutas son de viernes). Las notas del 2026-10-16 dicen «próxima reunión en dos semanas»; dejé la próxima el 2026-10-30.
- Dónde guardo lo que encuentro: `estado/PRY-211-cobranza-digital`, junto a `documentos/proyectos/`, no dentro de la carpeta de documentación ni de `.criterio/`.
- Términos: el sí y el nombre vienen en tu instrucción; los mostré tal cual antes de registrarlos.

### Lo que está abierto, y cuántas veces se ha movido

Son 26 compromisos en las 7 minutas. 4 están cerrados con acta de recibo (anexo 3, ambiente 12, diseño 13, prueba 18). Que alguien diga en la reunión «ya lo entregué» no cierra nada: 3 compromisos están en ese caso y siguen abiertos.

**Se han movido más de una vez**

| Quién | Qué | Para cuándo | Movimientos |
|---|---|---|---|
| María Restrepo | Cerrar la prueba 2 | 2026-12-09 (prometido primero para 2026-10-01) | 6 reprogramaciones: 10-08, 10-16, 10-27, 11-16, 11-25, 12-09. Fuente: `30-reuniones/2026-09-04-comite-semanal.md` y `2026-10-16-notas-reunion.txt` |
| Ricardo Salas | Enviar el documento 1 | 2026-11-29 (primera fecha: 2026-09-25) | 4 reprogramaciones: 10-16, 11-01, 11-20, 11-29. Fuente: `30-reuniones/2026-09-11-comite-semanal.md` |

Nadie ha nombrado qué está bloqueando estos dos. En las notas del 2026-10-16, María Restrepo dice que «cerrar la prueba 2» no alcanzó y se compromete para «09/12/2026»; lo leí como 9 de diciembre (12 de septiembre ya pasó), y conviene confirmarlo con ella. El informe del 2026-10-13 dice que la prueba de carga no alcanzó el umbral pactado y se repite.

**Vencidos sin evidencia** (7; ninguno tiene acta de recibo)

| Quién | Qué | Venció | Días | Cita |
|---|---|---|---|---|
| Camilo Beltrán | Validar el ambiente 4 | 2026-09-13 | 33 | `30-reuniones/2026-09-04-comite-semanal.md` |
| Sandra Gil | Confirmar la fecha 7 | 2026-09-26 | 20 | `30-reuniones/2026-09-11-comite-semanal.md` |
| Diana Molina | Entregar el punto 16 | 2026-10-03 | 13 | `30-reuniones/2026-09-25-comite-semanal.md` |
| Felipe Arango | Actualizar la matriz 6 | 2026-10-04 | 12 | `30-reuniones/2026-09-11-comite-semanal.md` |
| Laura Vélez | Revisar el anexo 19 | 2026-10-05 | 11 | `30-reuniones/2026-10-02-comite-semanal.md` |
| Ricardo Salas | Aprobar el diseño 5 | 2026-10-12 | 4 | `30-reuniones/2026-09-11-comite-semanal.md` |
| Felipe Arango | Confirmar la fecha 23 | 2026-10-14 | 2 | `30-reuniones/2026-10-09-comite-semanal.md` |

- «Validar el ambiente 4» lleva la misma fecha, sin cambio, en las seis minutas del 2026-09-04 al 2026-10-09: nunca se reprogramó ni se cerró.
- Sandra Gil (2026-09-18), Felipe Arango (2026-10-02) y Diana Molina (2026-10-09) dijeron en la reunión que ya habían entregado; «No se presentó acta». Los tres compromisos salieron de la tabla de compromisos abiertos desde esa misma minuta, sin que ningún acta los cerrara.
- Ninguno de estos siete se menciona en las notas del 2026-10-16.

**Vigentes, con fecha** (resumen; el detalle está en la ficha)

| Quién | Qué | Para cuándo | Movimientos |
|---|---|---|---|
| Jorge Medina | Entregar el punto 8 | 2026-10-22 | 2 (primera fecha 2026-09-21) |
| Andrés Lozano | Cerrar la prueba 10 | 2026-10-22 | 2 (primera fecha 2026-09-26) |
| Paula Céspedes | Revisar el anexo 11 | 2026-11-08 | 2 (primera fecha 2026-10-03) |
| Mauricio Pérez | Enviar el documento 9 | 2026-10-21 | 1 |
| Liliana Torres | Confirmar la fecha 15 | 2026-10-20 | 1 |
| María Restrepo | Actualizar la matriz 14 | 2026-10-18 | 0 |
| Ricardo Salas | Enviar el documento 17 | 2026-10-23 | 0 (se prometió «por definir» y la fecha vino después) |
| Natalia Ospina | Aprobar el diseño 21 | 2026-11-01 | 0 |
| Javier Hoyos | Actualizar la matriz 22 | 2026-11-01 | 0 |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-26 | 0 (nuevo, notas del 2026-10-16) |

### Sin fecha
No pueden estar vencidos, y por eso son los que desaparecen de los informes:
- Andrés Lozano — Validar el ambiente 20: «por definir» en las minutas del 2026-10-02 y del 2026-10-09.
- Carlos Peña — Entregar el punto 24: «por definir» el 2026-10-09; no estuvo en la reunión del 2026-10-16.
- Laura Vélez — Mandar el ajuste del presupuesto: «la otra semana» (notas del 2026-10-16). No es una fecha y no la calculé.

### Otras señales que levantó el cálculo
- **Estado declarado contra evidencia:** el informe del 2026-10-13 declara **verde** con 89% de avance, y el cálculo lo contrasta con cuatro señales: compromisos vencidos, compromisos reprogramados, hitos cerrados sin acta y desviación de costo. La declaración es tuya; esto es contra qué se mide.
- **Costo:** la proyección al cierre del informe (2.771.140.444 COP) supera el presupuesto aprobado (2.400.000.000 COP) en 15,5%. Está ejecutado el 39,6% y comprometido el 51,8%.
- **Hitos declarados cerrados sin acta:** «Diseño funcional aprobado» (2025-11-26, hace 324 días) y «Ambiente de pruebas certificado» (2026-04-06, hace 193 días). «Integración con el core» (prevista para 2026-08-16) sí tiene acta de recibo, del 2026-10-14.
- **Riesgo dicho y no registrado:** en las notas del 2026-10-16 se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, y nadie lo anotó como riesgo. Lo dejé en la ficha, sin dueño. Es una lectura mía de las notas, no una señal calculada.
- En total el cálculo levantó 16 señales. Todas salen de lo que leí; no hay ninguna que no tenga cita.

### Qué le falta a tu carpeta
- Actas de recibo de «Diseño funcional aprobado» y «Ambiente de pruebas certificado»: sin ellas un hito cerrado se ve igual que uno que no se cerró.
- Actas de recibo (o su ausencia aclarada) de los tres compromisos que se dieron por entregados en la reunión.
- El cronograma vigente: el único que hay es el v1 del 2025-07-08, y las fechas vigentes y de línea base son iguales en los cuatro hitos.
- Quién es el dueño de los riesgos del informe, y una fecha para los tres compromisos sin fecha.
- El acta de constitución no trae atribuciones del gerente ni etapa, y el alcance está descrito solo como «Componente 1, 2, 3».

**Cuándo vuelvo:** la próxima reunión de seguimiento es el 2026-10-30 (viernes, dos semanas después según las notas). Vuelvo ese día con la minuta que se guarde, para ver cuáles de estos compromisos se movieron otra vez.
