Términos: ya vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-16); no hubo que registrarlos de nuevo.

Recalculé antes de publicar (`compute`, corte 2026-10-16). Antes de escribir, esto es lo que iba a la ficha:

- **Con dato:** 19 campos (identidad 7, declarado 2, plan 4, dinero 4, más los hitos y compromisos).
- **Sin decir en ninguna parte:** `identity.authority` e `identity.phase`; además `vendors` y `changes` están vacíos.
- **Lo más viejo:** 12 campos del acta de constitución, del 2025-07-08 (15 meses; pasa de un año). Entre ellos están patrocinador, gerente, comité, producto, fecha de fin y presupuesto aprobado, que son seis de los ocho que la PMO contrasta.
- **Estado declarado:** **verde** al 2026-10-13 (89 % de avance), según `20-seguimiento/2026-10-13-informe-avance.md`. El cálculo lo contradice con 16 alertas: 2 hitos "cumplidos" sin evidencia, proyección de costo +15,5 % sobre lo aprobado, 7 compromisos vencidos, 3 sin fecha y 2 reprogramados 4 y 6 veces.

Publiqué la ficha en `documentos/proyectos/PRY-211-cobranza-digital/00-gobierno/ficha-pm.json`, con corte al 2026-10-16. La carpeta de gobierno ya existía. Es copia exacta de `estado/PRY-211-cobranza-digital/records/PRY-211.json` y es JSON válido. No toqué ningún otro archivo ni avisé a nadie.

**Lleva:** 19 campos con dato · 2 sin decir en ninguna parte · declara **verde** al 2026-10-13

**Lo más viejo que va ahí:** `identity.code` y el resto del acta de constitución, del 2025-07-08 — tienen más de un año (15 meses).

Nota: la ficha lleva `meta.note` "Sin sellar", es decir, no está sellada; este comando no la sella.
