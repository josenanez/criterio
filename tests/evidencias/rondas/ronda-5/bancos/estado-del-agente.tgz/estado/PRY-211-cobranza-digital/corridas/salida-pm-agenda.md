## Reunión de seguimiento — Cobranza digital (PRY-211) · 2026-10-30
6 puntos · 48 minutos · 9 personas requeridas

**Términos:** vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-16); no hizo falta registrarlos de nuevo. Resumen y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal

**Supuestos que tomé (nadie contestó):** la fecha es el 2026-10-30 porque las notas del 10-16 dicen «próxima reunión en dos semanas» y coincide con `committee_next`; ojo, la configuración dice comité semanal y las seis reuniones anteriores fueron semanales, y nadie explicó el cambio. No diste duración: armé la agenda para ~50 minutos. Es la primera corrida, no hay foto anterior: «lo que cambió» se mide contra la minuta del 2026-10-16. La agenda se calcula hoy (10-16); los vencimientos del 10-18 al 10-26 se conocerán el 10-30, así que conviene volver a correr `/pm-agenda` el 10-29.

### Lo que no se destraba solo

> **[1] Que quede dicho qué bloquea «Cerrar la prueba 2» y una fecha que alguien sostenga** · 10 min · **María Restrepo**
> Prometido para el 2026-12-09, y antes para el 11-25, el 11-16, el 10-27, el 10-16 y el 10-08. La primera promesa fue el 2026-10-01. **Seis reprogramaciones.**
> Fuente: comités del 09-11, 09-18, 09-25, 10-02, 10-09 y notas del 2026-10-16.
> **Qué tiene que salir de aquí:** el bloqueo con nombre (las notas dicen «no alcanzó» pero la fecha vigente era el 11-25, que no había llegado: no se sabe qué fue lo que no alcanzó), quién lo puede mover, y confirmar que «09/12/2026» es 9 de diciembre y no 12 de septiembre.
> **Si no se resuelve hoy:** se promete otra fecha sin causa y la sexta se vuelve séptima. El piloto con usuarios internos está en 2026-12-25 (16 días después del 12-09); la fuente no dice si la prueba 2 lo condiciona, y esa pregunta es parte del punto.

> **[2] Que el documento 1 salga o se diga quién lo bloquea; y cerrar o fechar el diseño 5** · 10 min · **Ricardo Salas**
> «Enviar el documento 1»: prometido para el 2026-11-29, y antes para el 11-20, el 11-01 y el 10-16. Primera fecha 2026-09-25. **Cuatro reprogramaciones.** Fuentes: comités del 09-18, 09-25, 10-02 y 10-09.
> Además: «Aprobar el diseño 5» vencido el 10-12 (antes 09-29), sin acta de recibo (comités del 09-11 y 09-25), y «Enviar el documento 17» vence el 10-23.
> **Si no se resuelve hoy:** son tres compromisos de la misma persona, uno con cuatro corridas de fecha, otro vencido y otro por vencer; nadie los mencionó en la reunión del 10-16.

### Vencido sin evidencia
| Quién | Qué | Desde | Qué se necesita hoy | Min |
|---|---|---|---|---|
| Camilo Beltrán | Validar el ambiente 4 | 2026-09-13 (33 días al 10-16; nunca se reprogramó, igual en seis minutas) | Acta de recibo, o una fecha nueva dicha en voz alta | 5 |
| Felipe Arango | Actualizar la matriz 6 (04-oct) y Confirmar la fecha 23 (14-oct) | 12 y 2 días al 10-16 | Dijo el 10-02 que la matriz 6 «ya entregó»; sin acta no cierra. Acta o fecha | 3 |
| Laura Vélez | Revisar el anexo 19 | 2026-10-05 (11 días al 10-16) | Acta o fecha | 2 |

Fuentes: minutas del 09-04 al 10-09 y notas del 10-16; ninguno de estos cinco se mencionó el 10-16.

### Se decide hoy o se atrasa
| Qué | Quién decide | Si no se decide | Min |
|---|---|---|---|
| **[5] Dueño y fecha de los riesgos e incidencia abiertos.** Cuatro sin dueño ni valoración: proveedor sin fecha de la última entrega; equipo de seguridad para la revisión final; proveedor sin el equipo completo para la siguiente fase (dicho el 10-16, «nadie lo anotó como riesgo»); prueba de carga que no alcanzó el umbral y se repite. Fuentes: informe 10-13, notas 10-16 | Beatriz Cuéllar, con Óscar Ramírez (revisión con el proveedor, 10-26) | Siguen sin dueño y el informe sigue en verde sobre una prueba de carga fallida | 10 |
| **[6] Presupuesto:** proyección declarada 2.771.140.444 COP contra 2.400.000.000 aprobados (15,5 % sobre lo aprobado). Fuente: informe 10-13. Laura Vélez quedó de «mandar el ajuste del presupuesto la otra semana» (no es una fecha) | Paula Céspedes (patrocinadora); quién aprueba el exceso no está documentado (`authority` no encontrada) | El ajuste sigue sin fecha y el sobrecosto sin decisión. Si excede lo que esta sala puede aprobar, formularlo con `/pm-escalate` | 5 |
| **Fechas faltantes:** Laura Vélez (ajuste del presupuesto), Andrés Lozano (validar el ambiente 20, «por definir» desde el 10-02) | Cada uno | Siguen en el grupo que no puede vencer y por eso desaparece | 3 |

### Vence antes de la próxima
| Quién | Qué | Para cuándo |
|---|---|---|
| María Restrepo | Actualizar la matriz 14 | 2026-10-18 |
| Liliana Torres | Confirmar la fecha 15 (antes 10-10, reprogramado 1 vez) | 2026-10-20 |
| Mauricio Pérez | Enviar el documento 9 (antes 10-12, reprogramado 1 vez) | 2026-10-21 |
| Jorge Medina | Entregar el punto 8 (antes 09-21, reprogramado 2 veces: a una del umbral) | 2026-10-22 |
| Andrés Lozano | Cerrar la prueba 10 (antes 09-26, reprogramado 2 veces: a una del umbral) | 2026-10-22 |
| Ricardo Salas | Enviar el documento 17 | 2026-10-23 |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-26 |

No consumen tiempo de reunión salvo que alguno llegue vencido el 10-30 (entonces entra arriba).

### No es de esta reunión
| Qué | Por qué | Dónde va |
|---|---|---|
| Sandra Gil · Confirmar la fecha 7 (vencida 09-26); Diana Molina · Entregar el punto 16 (vencida 10-03) | Su doliente no estuvo el 10-16 (Sandra no figura desde el 09-25). Las minutas dicen «dice que ya entregó. No se presentó acta». Sin ellas en la sala nadie puede cerrarlo | Beatriz les pide el acta fuera de la reunión; si llega, se cierra y sale del seguimiento |
| Carlos Peña · Entregar el punto 24 (sin fecha, «por definir» desde el 10-09) | No estuvo el 10-16 | Lo mismo: se le pide fecha directo; si asiste el 10-30, entra a «Fechas faltantes» |
| Si el sobrecosto de [6] excede lo que la sala puede aprobar | La autoridad no está documentada en el acta | `/pm-escalate` para formularlo como decisión |

### Anexo — sin cambios desde el 2026-10-16
- Natalia Ospina: Aprobar el diseño 21 (11-01).
- Javier Hoyos: Actualizar la matriz 22 (11-01).
- Paula Céspedes: Revisar el anexo 11 (11-08; ya reprogramado dos veces, antes 10-03 y 10-18): no vence antes de la reunión, pero está a una del umbral.
- Cerrados con acta: Revisar el anexo 3 (Camilo Beltrán), Validar el ambiente 12 y Aprobar el diseño 13 (Natalia Ospina), Cerrar la prueba 18 (Laura Vélez).

**Personas requeridas (9):** María Restrepo, Ricardo Salas, Camilo Beltrán, Felipe Arango, Laura Vélez, Andrés Lozano, Óscar Ramírez, Paula Céspedes, Beatriz Cuéllar.

**Lo que no sé:** si Sandra Gil, Diana Molina y Carlos Peña asistirán; qué bloquea la prueba 2; si hay duración fijada para la reunión; quién tiene facultad para aprobar el sobrecosto; si el cambio a quincenal es una decisión o un descuido.

**Después:** cuando termine la reunión, `/pm-minutes` sobre la transcripción o las notas.
