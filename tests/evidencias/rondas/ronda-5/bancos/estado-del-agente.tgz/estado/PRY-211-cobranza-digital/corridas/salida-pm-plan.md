# Plan — Cobranza digital (PRY-211) · borrador del 2026-10-16
**Desde:** acta de constitución del 2025-07-08 (`00-gobierno/2025-07-08-acta-constitucion.md`) · **Criterio de éxito:** «Cobranza digital en producción y medido» — está declarado, pero sin ninguna medida (ver abajo).

**Contexto que cambia la lectura:** este proyecto no está arrancando. El informe del 2026-10-13 declara 89 % y verde, y 3 de los 4 hitos del cronograma v1 figuran cerrados. Este borrador reconstruye la estructura desde el acta para ver qué sostiene el acta, no para reemplazar el plan vigente. No hay plan aprobado en `10-plan/` más allá del cronograma v1 (4 hitos, sin tareas ni duraciones).

## Lo que le falta al acta
| Qué | Consecuencia de planificar sin eso |
|---|---|
| **Alcance sin describir**: «Componente 1, 2, 3» (acta, §Alcance) | No se puede descomponer por entregable. La WBS de abajo tiene tres nodos que nadie puede aceptar porque nadie sabe qué son. Es el hueco más caro. |
| **Criterio de éxito sin medida**: «en producción y medido» | No dice qué se mide, con qué umbral, ni quién lo da por cumplido. Nada de lo que se planifique se puede cerrar contra él. |
| **Fuera de alcance vacío**: «Lo que otro proyecto cubre» | No se sabe qué proyecto ni qué entregables quedan fuera. Riesgo de que dos proyectos construyan lo mismo, o de que nadie construya algo. |
| **Autoridad no declarada** (`identity.authority`: no encontrada) | No se sabe qué puede decidir la gerente al planificar y qué hay que subir al Comité de Riesgos. |
| **Dependencias: «Ninguna declarada»**, pero las reuniones nombran al proveedor y al equipo de seguridad | El plan nacería sin dependencias que ya son riesgos abiertos (informe 2026-10-13). |
| Fase actual no declarada (`identity.phase`) | No se puede decir en qué etapa va el proyecto sin inferirlo. |

Patrocinador sí está declarado: Paula Céspedes. Sigo marcando los vacíos y no los relleno.

## WBS
Estados: **del acta** · **supuesto** · **sin definir**. La duración queda vacía en todos los nodos: ninguno tiene duración citable (el cronograma v1 solo trae fechas de hito, no duraciones).

| # | Entregable | Quién lo acepta | De dónde sale | Duración |
|---|---|---|---|---|
| 1 | Componente 1 | sin definir | del acta (nombre) · contenido **sin definir** | — |
| 2 | Componente 2 | sin definir | del acta (nombre) · contenido **sin definir** | — |
| 3 | Componente 3 | sin definir | del acta (nombre) · contenido **sin definir** | — |
| 4 | Diseño funcional aprobado | sin definir | supuesto: es un hito del cronograma v1, no del acta; no dice a qué componente corresponde | — |
| 5 | Ambiente de pruebas certificado | sin definir | supuesto: hito del cronograma v1 | — |
| 6 | Integración con el core (acta de recibo 2026-10-14) | sin definir | supuesto: hito del cronograma v1; tiene acta de recibo | — |
| 7 | Piloto con usuarios internos | sin definir | supuesto: hito del cronograma v1 | — |
| 8 | Cobranza digital en producción | sin definir | del acta (criterio de éxito) | — |
| 9 | Medición de cobranza digital en producción | sin definir | del acta («y medido»); qué se mide, **sin definir** | — |
| 10 | Prueba de carga superando el umbral pactado | sin definir | supuesto: la repetición viene del informe 2026-10-13; el umbral pactado **no está en ningún documento leído** | — |
| 11 | Revisión final de seguridad | sin definir | supuesto: aparece como riesgo en el informe 2026-10-13, no en el acta | — |
| 12 | Última entrega del proveedor | sin definir | supuesto: idem; qué entrega es y cuál es su contrato, **sin definir** | — |

Los nodos 1–3 son terminales que nadie puede aceptar hoy; mientras sigan así no son cerrables. No hay contratos de proveedor en la carpeta (`vendors` vacío en la ficha).

## Orden
Sin fechas. Qué necesita qué, solo donde el trabajo lo dice:
- Diseño funcional → ambiente de pruebas certificado → integración con el core → piloto con usuarios internos → producción → medición. Es el orden de los hitos del cronograma v1 y la secuencia natural del trabajo; **que cada uno dependa del anterior es supuesto**, el acta no declara dependencias.
- La prueba de carga (10) y la revisión de seguridad (11) preceden a producción: supuesto, no está escrito.
- Cómo se reparten los componentes 1–3 entre esos hitos: **sin definir**.

Fechas ya existentes en el cronograma v1 (referencia, no propuesta): inicio 2025-07-18, piloto 2026-12-25, cierre 2027-03-01 (acta).

## Supuestos sobre los que está construido
| Supuesto | Qué pasa si resulta falso |
|---|---|
| Los 4 hitos del cronograma v1 son entregables del proyecto y no solo marcas de calendario | La WBS pierde cuatro nodos y vuelve a depender de componentes sin describir |
| Los hitos se encadenan en orden secuencial | Hay trabajo paralelo no visto; el orden y el camino crítico cambian |
| Prueba de carga y seguridad son requisitos previos a producción | Podrían ir después o en paralelo; cambia qué bloquea el piloto |
| La última entrega del proveedor y el equipo de seguridad son dependencias de este proyecto | Si no lo son, los riesgos abiertos están mal dueños; si lo son y no están en el acta, nadie los gobierna |
| «Medido» significa medición posterior a producción | Si significa medición previa o piloto, el nodo 9 cambia de lugar |

Estos pasan a riesgos del proyecto cuando el plan se apruebe.

## Sin definir
| Qué | Quién lo define |
|---|---|
| Qué son los componentes 1, 2 y 3 | Patrocinador (Paula Céspedes) con la gerente — el acta no dice quién |
| Quién acepta cada entregable | Patrocinador / Comité de Riesgos — el acta no lo dice |
| Qué se mide y con qué umbral para dar «medido» por cumplido | Patrocinador |
| Qué queda fuera de alcance y en qué otro proyecto | Patrocinador / PMO |
| Umbral de la prueba de carga | No hay documento; hay que preguntarlo al equipo de pruebas (por confirmar quién) |
| Autoridad de la gerente al planificar | Patrocinador / Comité de Riesgos |
| Dependencias reales (proveedor, seguridad) | Gerente, con el patrocinador |

## Proyectos análogos
Ninguno a la vista. La configuración no apunta a una carpeta de fichas de la PMO y el único proyecto en el espacio es éste. Es la respuesta correcta; no se estima por analogía.

## Preguntas para el equipo
Una por duración vacía (nodos 1–12):
1. ¿Qué entrega concreta es cada componente 1, 2 y 3, y cuánto toma cada uno?
2. ¿Cuánto toma el diseño funcional restante, si queda algo? (el hito figura cerrado)
3. ¿Cuánto toma certificar el ambiente de pruebas si hay que repetirlo?
4. ¿Cuánto toma la integración con el core a partir de ahora, si queda algo abierto tras el acta del 2026-10-14?
5. ¿Cuánto toma el piloto con usuarios internos, desde que arranca hasta que se da por terminado?
6. ¿Cuánto toma pasar a producción después del piloto?
7. ¿Cuánto toma la medición, y cuántas semanas de datos hacen falta para decir «medido»?
8. ¿Cuánto toma repetir la prueba de carga hasta alcanzar el umbral, y qué cambia para que lo alcance?
9. ¿Cuánto toma la revisión final de seguridad, y desde cuándo está disponible el equipo?
10. ¿Cuándo confirma el proveedor su última entrega, y cuánto dura?

## Para comprometer una fecha falta
- La disponibilidad real del equipo (las reuniones reprograman compromisos semana tras semana; ver `pm-commitments`).
- La fecha del proveedor para su última entrega — el informe dice que no la ha confirmado.
- La disponibilidad del equipo de seguridad para la revisión final.
- La ventana de la sala de producción / pase a producción: no está en ningún documento.
- Una aclaración aparte, que no es del plan: el informe declara verde, pero la proyección al cierre (2.771.140.444 COP) supera el presupuesto aprobado (2.400.000.000 COP) en 371.140.444 COP, y la prueba de carga falló. Esto no lo resuelve el plan; lo decide quien tiene autoridad.

Este borrador no compromete ninguna fecha, no crea línea base ni asigna personas.
