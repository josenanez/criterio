# Acta — Cobranza digital (PRY-211) · 2026-10-16

**Asistieron (14):** Andrés Lozano, Beatriz Cuéllar, Camilo Beltrán, Felipe Arango, Javier Hoyos, Jorge Medina, Laura Vélez, Liliana Torres, María Restrepo, Mauricio Pérez, Natalia Ospina, Paula Céspedes, Ricardo Salas, Óscar Ramírez
**Fuente:** `documentos/proyectos/PRY-211-cobranza-digital/2026-10-16-notas-reunion.txt` (notas de 5 líneas; no hay agenda escrita)
**Ausentes con tema en agenda:** no hay agenda, así que no se puede decir. Sí faltan tres personas con compromisos abiertos en la ficha: **Carlos Peña** (estuvo el 09-10; «Entregar el punto 24», sin fecha), **Sandra Gil** (no figura desde el 25-09; «Confirmar la fecha 7», vencido) y **Diana Molina** («Entregar el punto 16», vencido; el 09-10 dijo que ya lo entregó y no hay acta).

**Términos:** vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-16); no hizo falta registrarlos de nuevo. Resumen y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.11

## Compromisos
| Quién | Qué | Para cuándo | |
|---|---|---|---|
| María Restrepo | Cerrar la prueba 2 | 2026-12-09 | **Reprogramado por 6.ª vez.** Primera promesa: 2026-10-01. Fechas siguientes: 10-08, 10-16, 10-27, 11-16, 11-25, 12-09. Cita: «lo de "cerrar la prueba 2" no alcanzó, se compromete para el 09/12/2026». |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-26 | Nuevo. Cita: «revisión con el proveedor, queda para el 2026-10-26». |

### Sin fecha
| Quién | Qué |
|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto. Cita: «la otra semana». Eso no es una fecha y no se calcula; queda `no_declarada`. |

## Decisiones
Ninguna. Las notas no registran ninguna decisión.

## Quedó sin decidir
Las notas no dicen que algo se haya puesto sobre la mesa y quedado abierto. No se infiere.

## Intenciones sin doliente
Ninguna en las notas.

## Dicho al pasar y no registrado
| Qué | Quién lo dijo | Categoría | Ya estaba en el RAID |
|---|---|---|---|
| El proveedor podría no llegar con el equipo completo para la siguiente fase. Cita: «nadie lo anotó como riesgo». | No se atribuye: las notas dicen «se comentó» | Riesgo (dependencia de proveedor) | **No.** Lo más cercano es «El proveedor no ha confirmado la fecha de la última entrega» (informe del 13-10). Habla de una fecha, no de la capacidad del equipo. Va sin dueño, probabilidad ni impacto. |

## Cerrado en esta reunión
Nada. Se omite el detalle: ningún compromiso se cerró con documento.

## Lo que esta reunión contradice
Nada. Las notas no tocan patrocinador, fechas de cierre ni comité, así que no chocan con el acta de constitución.

## Sin resolver de la transcripción
- **Formato de fecha de María Restrepo:** «09/12/2026». Se leyó día/mes (9 de diciembre). La lectura mes/día (12 de septiembre) ya pasó y no tendría sentido como promesa nueva. Las demás actas usan año-mes-día, así que conviene confirmarlo con ella.
- **«No alcanzó»:** la fecha vigente de «Cerrar la prueba 2» era 2026-11-25, que aún no llegaba. Las notas no dicen qué fue lo que no alcanzó.
- **Quién comentó lo del proveedor:** las notas no lo dicen.
- **«Próxima reunión en dos semanas»:** sería el 2026-10-30, que coincide con `committee_next`. Pero la configuración dice comité semanal y las seis reuniones anteriores fueron semanales. Las notas no explican el cambio.
- **Sin mención hoy** de compromisos que siguen abiertos o vencidos: Camilo Beltrán (ambiente 4, vencido), Ricardo Salas (diseño 5, vencido; documentos 1 y 17), Felipe Arango (matriz 6 y fecha 23, vencidos), Laura Vélez (anexo 19, vencido), María Restrepo (matriz 14, vence el 10-18). Que no se hayan nombrado no los cierra.

## Estado del seguimiento tras recalcular (`compute`)
- Vencidos sin evidencia: 7. Sin fecha: 3 (Andrés Lozano, Carlos Peña, Laura Vélez). Reprogramados 3 o más veces: 2 (Ricardo Salas ×4, María Restrepo ×6).
- El informe del 13-10 declara **verde**. Esa declaración queda sin sostener por cuatro señales: compromisos vencidos, reprogramados, hitos «cumplidos» sin evidencia y proyección 15,5 % sobre el presupuesto. Esto no sale de la reunión, pero es el contexto del acta.
- Nota de procesamiento: la ficha ya traía las entradas de esta reunión de una corrida anterior del mismo día; se contrastaron contra las notas y no se duplicaron.

*El acta queda en esta conversación. No se escribió en la carpeta de reuniones del proyecto.*

**Siguiente:** `/pm-commitments` para el seguimiento completo, y `/pm-publish` si quieres que la PMO vea el estado actualizado.
