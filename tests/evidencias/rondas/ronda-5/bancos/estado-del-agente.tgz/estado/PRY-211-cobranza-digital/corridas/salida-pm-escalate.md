**Términos:** vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-16); no hizo falta registrarlos de nuevo. Nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal

**Qué escalo y por qué (sin argumento, tomé «lo ya marcado como escalable»):** la agenda del 2026-10-30 dejó marcado el punto [6], el sobrecosto, con la nota «si excede lo que esta sala puede aprobar, formularlo con `/pm-escalate`». Antes de ese hay otro, que es el primero: el acta no declara la autoridad del gerente. Van los dos, en ese orden.

## Para decisión — Cobranza digital (PRY-211) · 2026-10-16

### 1. ¿Quién tiene la facultad de aprobar un gasto por encima de los 2.400.000.000 COP aprobados: el Comité de Riesgos, la patrocinadora Paula Céspedes, o la gerente dentro de un margen?

**Quién decide:** no se puede decir según el acta. El acta del 2025-07-08 nombra al Comité de Riesgos como el que aprobó el presupuesto y a Paula Céspedes como patrocinadora, pero no tiene sección de autoridad del gerente, ni umbral de tolerancia, ni quién aprueba excesos. · **Si no se decide hoy:** no hay una fecha documentada que venza. Lo que sí está documentado: la proyección ya declarada supera lo aprobado y el siguiente comité es el 2026-10-30 (`committee_next`); sin esta respuesta, el punto 2 se discute sin que nadie pueda cerrarlo y puede volver con un «eso lo decide otro».

**Recomiendo:** que Paula Céspedes responda por escrito antes del 2026-10-30 si el exceso lo decide el Comité de Riesgos (quien aprobó el presupuesto) o ella, y que esa respuesta se anexe al acta como adenda de autoridad. Razón: un exceso sobre un presupuesto aprobado por un comité normalmente vuelve a ese comité, pero eso es una inferencia mía, no un dato del acta.

### 2. ¿Se aprueba una ampliación del presupuesto hasta la proyección declarada, se recorta alcance para volver a 2.400.000.000, o se espera el ajuste de Laura Vélez antes de decidir?

**Quién decide:** por determinar con el punto 1 · **Si no se decide hoy:** el ajuste de presupuesto de Laura Vélez quedó «la otra semana» (notas del 2026-10-16), que no es una fecha; sin fecha y sin decisor, el sobrecosto sigue sin dueño mientras el informe lo reporta en verde.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar ampliación hasta la proyección | Se mantiene | Sin efecto documentado | +371.140.444 COP sobre lo aprobado (proyección 2.771.140.444; 15,5 % más) |
| B. Recortar alcance a lo aprobado | Se reduce, pero **no se sabe cuánto ni qué**: el acta lista «Componente 1, 2 y 3» sin describirlos | **No sé**: no hay cronograma por actividad que lo diga | 0 sobre lo aprobado; el costo del recorte no está calculado |
| C. Esperar el ajuste de Laura Vélez (sin fecha) | Se mantiene | Cada día de espera acerca el comité del 2026-10-30 sin cifra nueva | No sé: el ajuste puede mover los 371.140.444 en cualquier dirección |

**Recomiendo:** C con fecha: que Laura Vélez entregue el ajuste el 2026-10-23 como tarde, para que el 2026-10-30 el comité elija entre A y B con cifra revisada. Razón: la proyección que hay es declarada por el informe del 2026-10-13, sin desglose, y B no se puede evaluar hasta que alguien diga qué alcance se recorta. La fecha del 10-23 es mi propuesta, no un compromiso de nadie; hay que acordarla con ella.

**Dato que no cierra y conviene tener a la vista:** el informe declara 89 % de avance y estado verde, con 949.227.038 COP ejecutados (39,6 % de lo aprobado) y 1.243.793.744 comprometidos (51,8 %). Con eso, una proyección de 115,5 % de lo aprobado no es consistente con un 89 % de avance en verde. No sé cuál de las cifras está mal; el informe no lo explica.

### A quién alcanza
No calculé el efecto con `portafolio.py impact`: lo que se escala no mueve ninguna fecha, es plata y autoridad, y ese cálculo necesita un cambio en días. El acta declara «Ninguna declarada» en dependencias, así que no hay otro proyecto ni gerente alcanzado que yo pueda nombrar con sustento. Si la opción B mueve el piloto, entonces sí hay que correrlo.

### Mis hitos por los que pasa
| Hito | Fecha vigente | En cuántos días |
|---|---|---|
| Piloto con usuarios internos | 2026-12-25 | No se calcula: ninguna opción declara un cambio de fecha |

### Otros puntos que también cumplen el criterio de escalar (no armé su paquete)
- **Cerrar la prueba 2** (María Restrepo): seis reprogramaciones, de 2026-10-01 a 2026-12-09. Cumple «compromiso reprogramado tres veces». La causa del bloqueo no está dicha; sin ella no se puede formular una pregunta cerrada. Primero hay que pedirle el bloqueo con nombre.
- **Enviar el documento 1** (Ricardo Salas): cuatro reprogramaciones, ahora 2026-11-29. Lo mismo.
- **Riesgos sin dueño** (cuatro, incluida la prueba de carga que no alcanzó el umbral): son del gerente, se resuelven dentro del proyecto y no escalan.

### De dónde sale esto
- Autoridad no declarada, presupuesto aprobado por el Comité de Riesgos el 2025-07-08, patrocinadora: `00-gobierno/2025-07-08-acta-constitucion.md`.
- Presupuesto, comprometido, ejecutado, proyección, 89 % y verde: `20-seguimiento/2026-10-13-informe-avance.md`.
- Ajuste de presupuesto «la otra semana», fecha del próximo comité en dos semanas: `2026-10-16-notas-reunion.txt`.
- El punto [6] marcado como escalable: `estado/PRY-211-cobranza-digital/corridas/salida-pm-agenda.md`.
- Cálculos míos: 2.771.140.444 − 2.400.000.000 = 371.140.444 (15,5 %); 949.227.038 / 2.400.000.000 = 39,6 %; 1.243.793.744 / 2.400.000.000 = 51,8 %.

**Lo que no sé:** quién aprueba excesos; qué desglosa la proyección de 2.771.140.444; qué alcance se recortaría en B y cuánto tiempo mueve; por qué el 89 % convive con 39,6 % ejecutado. **Lo que no hice:** escalar yo (llevarlo al comité es de la gerente) ni escribirle a Paula Céspedes o a Laura Vélez.

**Después:** si el comité decide, ofrezco registrar la decisión con su fecha y documento en la ficha; si cambia la línea base, eso es control de cambios y la anterior no se toca.
