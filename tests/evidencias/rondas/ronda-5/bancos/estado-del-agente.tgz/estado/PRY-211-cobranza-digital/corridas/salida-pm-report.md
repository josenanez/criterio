# Cobranza digital (PRY-211) — semana del 2026-10-09 al 2026-10-16

*Sesión sin interfaz: nadie respondió preguntas. Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-16).*

**Declara el gerente (Beatriz Cuéllar):** verde · 89 % · al 2026-10-13 (hace 3 días, vigente). Es la declaración que ya estaba en el informe de avance del 2026-10-13. En esta sesión no se pudo preguntar una declaración nueva, y Samuel no propone ni declara estado. Si Beatriz quiere sostener o cambiar ese verde, tiene que decirlo ella.
**Sustento documental:** contradicho. El cálculo marca `declared_vs_evidence`: se declara verde y hay evidencia que ese verde no cubre.
**Lo que el semáforo no explica:** compromisos vencidos, compromisos reprogramados, hitos «cumplidos» sin evidencia y desviación de costo.

## Qué cambió esta semana
Esta es la primera corrida registrada del proyecto: el snapshot es del 2026-10-16 y no hay un anterior con qué comparar (diff: 0 cambios). No se puede decir qué cambió desde la semana pasada. Desde la próxima corrida este apartado sí tendrá comparación.

Lo que entró en el periodo, según la ficha:
| Qué | Estaba | Está |
|---|---|---|
| Hito «Integración con el core» | sin evidencia | cumplido, con acta de recibo del 2026-10-14 |
| Prueba de carga | — | incidencia abierta desde 2026-10-13: no alcanzó el umbral pactado y se repite |
| Riesgo: el proveedor podría no llegar con el equipo completo | no registrado | dicho en la reunión del 2026-10-16, nadie lo anotó; queda en el RAID |

## Lo que sigue igual y sigue mal
| Qué | Desde | Días así |
|---|---|---|
| Hito «Diseño funcional aprobado» declarado cumplido, sin evidencia | vencía 2025-11-26 | 324 |
| Hito «Ambiente de pruebas certificado» declarado cumplido, sin evidencia | vencía 2026-04-06 | 193 |
| Proyección de costo sobre lo aprobado: +15,5 % (umbral 10 %) | informe del 2026-10-13 | sin dato de antes |
| Riesgos sin dueño, sin probabilidad ni impacto (3 de 3) | 2026-10-13 y 2026-10-16 | 3 y 0 |

## Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2027-03-01 | 2027-03-01 | 0 días |
| Presupuesto | COP 2.400.000.000 | COP 2.400.000.000 | proyección COP 2.771.140.444 → +15,5 % (+COP 371.140.444) |

Replanificaciones: 0. Hay una sola línea base, la del 2025-07-08 (aprobación inicial del Comité de Riesgos). Que no haya replanificación no prueba que no haya atraso: dos hitos «cumplidos» no tienen evidencia, y el avance de 89 % está en el borde del rango que el plan sostiene (75–100 %).

### Hitos de las próximas cuatro semanas
Ninguno. El próximo es «Piloto con usuarios internos», base y vigente 2026-12-25 (10 semanas), pendiente y sin evidencia.

## Las cifras (COP)
| Aprobado | Comprometido | Ejecutado | Proyectado | Disponible real |
|---|---|---|---|---|
| 2.400.000.000 | 1.243.793.744 (51,8 %) | 949.227.038 (39,6 %) | 2.771.140.444 | 1.156.206.256 |

El disponible real es aprobado menos comprometido, no menos ejecutado. Comprometido, ejecutado y proyectado son declaraciones del informe del 2026-10-13; ninguna cifra tiene evidencia contable aparte.

## Abierto
**Reprogramados (primero):**
- María Restrepo, «Cerrar la prueba 2»: 6 veces. Era para 2026-10-01 y ahora está en 2026-12-09. Supera el umbral de 3.
- Ricardo Salas, «Enviar el documento 1»: 4 veces. Era para 2026-09-25 y ahora está en 2026-11-29. Supera el umbral de 3.

**Vencidos sin evidencia:**
- Camilo Beltrán, validar el ambiente 4: venció 2026-09-13 (33 días).
- Sandra Gil, confirmar la fecha 7: venció 2026-09-26 (20 días).
- Diana Molina, entregar el punto 16: venció 2026-10-03 (13 días).
- Felipe Arango, actualizar la matriz 6: venció 2026-10-04 (12 días).
- Laura Vélez, revisar el anexo 19: venció 2026-10-05 (11 días).
- Ricardo Salas, aprobar el diseño 5: venció 2026-10-12 (4 días).
- Felipe Arango, confirmar la fecha 23: venció 2026-10-14 (2 días).

**Sin fecha (no se pueden vencer, tampoco cumplir):** Andrés Lozano (validar el ambiente 20), Carlos Peña (entregar el punto 24), Laura Vélez (mandar el ajuste del presupuesto).

**RAID sin movimiento:** nada con más de 15 días sin movimiento. Lo más viejo se movió el 2026-10-13. Tres riesgos y una incidencia, ninguno con dueño.

**Proveedor:** la ficha no tiene proveedores registrados, así que no hay entregables que contrastar. Aun así, hay un riesgo abierto sobre el proveedor: no ha confirmado la fecha de la última entrega y podría no llegar con el equipo completo. Si hay contrato, falta cargarlo.

## Lo que necesito de alguien
- **Beatriz Cuéllar:** declarar de nuevo el estado y el avance, mirando la contradicción de arriba.
- **Beatriz Cuéllar / quien aprobó los hitos:** poner la evidencia de «Diseño funcional aprobado» y «Ambiente de pruebas certificado», o corregir su estado.
- **María Restrepo y Ricardo Salas:** decir qué bloquea sus compromisos reprogramados.
- **Quien asigne dueño:** los 3 riesgos y la incidencia de la prueba de carga no tienen dueño.
- **Material de comité (excede al gerente, no es de este informe):** la proyección de costo está 15,5 % sobre lo aprobado y el umbral es 10 %; esa es una decisión de comité. Dos compromisos llevan 3 o más reprogramaciones.

## Lo que no se sabe
**Sin dato:** autoridad que aprueba (`identity.authority`) y fase (`identity.phase`). Probabilidad, impacto y dueño de los 3 riesgos. Proveedores y contrato. 12 campos de identidad y plan vienen del acta del 2025-07-08 (15 meses) y no se han reconfirmado.
**Silencio:** último documento hace 0 días (notas del 2026-10-16) · última reunión hace 0 días (2026-10-16; el último comité semanal con acta fue el 2026-10-09, hace 7 días). Ningún documento de la ficha es evidencia primaria: 0 de 17 fuentes marcadas como evidencia; 5 son declaraciones y 12 sin marcar.

---
**Pie:** sale de la ficha `records/PRY-211.json`, con corte al 2026-10-16. Van 2 campos sin dato y 12 desactualizados. Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.11

**Después:** hay compromisos reprogramados 3 o más veces y una desviación de costo sobre el umbral, así que puedo armar el punto de comité con la decisión formulada. La declaración quedó contradicha por la evidencia, así que puedo preparar `/pm-publish`; es mejor que la PMO lo lea de tu ficha antes de que lo encuentre por su cuenta.
