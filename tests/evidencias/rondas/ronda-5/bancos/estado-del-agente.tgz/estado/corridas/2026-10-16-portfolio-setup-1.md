# Corrida del 2026-10-16 · portfolio-setup

3 proyectos · 72 documentos, 47 releídos y 25 sin cambio · 150 s · 24 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_overdue` | 7 |
| `milestone_met_without_evidence` | 5 |
| `commitment_undated` | 4 |
| `variance_cost` | 2 |
| `commitment_rescheduled` | 2 |
| `variance_time` | 1 |
| `progress_vs_plan` | 1 |
| `declared_vs_evidence` | 1 |
| `pm_vs_pmo` | 1 |

0 preguntas (prueba sin interfaz, se tomaron las respuestas sugeridas); minutos hasta el primer resultado no medidos; probó 3 proyectos (PRY-208, PRY-201, PRY-211) con 24 señales: PRY-211 verde contradicho (7 compromisos vencidos, 2 reprogramados 4 y 6 veces, 2 hitos sin acta, costo +15,5%), PRY-201 rojo respaldado (+43 días, 3 hitos sin acta), PRY-208 costo +23%. Error propio corregido: fecha vigente de compromisos reprogramados de PRY-211 mal escrita.

Primera corrida: no hay una anterior contra la cual comparar.

## Lo que produjo

Soy Vera, el agente PMO de Criterio. Leo la documentación que ya tienes y digo qué no se sostiene.

Miré `documentos/proyectos`: 13 proyectos, 72 documentos. Formatos: .md (36), .docx (14), .pdf (8), .xlsx (7), .csv (5), .json (1), .txt (1); ninguno ilegible. El más reciente es del 2026-10-16.

Esta fue una prueba sin interfaz y nadie respondió preguntas. En cada punto tomé la respuesta sugerida:
- **Eres:** PMO del portafolio (hay 13 proyectos).
- **Comité:** semanal, porque los nombres de archivo dicen `comite-semanal`. El próximo lo puse el 2026-10-21 (siete días después del último, 2026-10-14). El informe llega dos días antes.
- **Formato:** presentación.
- **Dónde guardo lo que encuentro:** `estado/`. Los informes irán a `reportes/`. Quedan junto a la carpeta de documentos y fuera de `.criterio/`.
- **Costo de una corrida:** lotes de 10 proyectos, uno tras otro, hasta 400 documentos, sin releer lo que no cambió.

## Listo — Portafolio de proyectos

**Miré:** 72 documentos en 13 proyectos · formatos: .md, .docx, .pdf, .xlsx, .csv, .json, .txt · más reciente: 2026-10-16
**Eres:** PMO del portafolio
**Te aviso:** dos días antes del comité semanal; el próximo comité es el 2026-10-21
**En:** presentación
**Términos:** aceptados por José Francisco Ñáñez, 2026-10-16, para la versión 0.3.11 (términos 1.1) · comprobante en `.criterio/terminos/aceptacion-criterio-portfolio-0.3.11-2026-10-16.md` y `.pdf` · SHA-256 41a739aec7049af3…

La configuración quedó en `.criterio/portafolio/config.json` y la verificación pasó sin problemas.

### Probé con tres proyectos

Tomé los tres con documentación del 2026-10-16: PRY-208, PRY-201 y PRY-211. Cada ficha quedó escrita en `estado/records/` y sellada. Primero escribí PRY-211 con un error mío en la fecha vigente de los compromisos reprogramados. `compute` lo mostró como falsas señales de "compromiso sin fecha". Corregí las fichas, las resellé y recalculé. Lo que sigue sale del cálculo corregido.

| Proyecto | Documentos | Qué supe | Qué no está |
|---|---|---|---|
| PRY-208 Motor de decisión | 2 de 2 | Gerente Jorge Medina; patrocinador Javier Hoyos; presupuesto aprobado 800 M COP; cierre comprometido 2027-07-24. El informe del 2026-10-16 declara **rojo** y 41 %. Hay dos riesgos abiertos (`20-seguimiento/2026-10-16-informe-avance.pdf`). | Producto (el acta dice «No aplica»), facultad del gerente, etapa, cronograma e hitos. |
| PRY-201 Core de depósitos | 7 de 7 | Gerente Mauricio Pérez; patrocinador Elena Duarte; producto cuenta de ahorros; presupuesto aprobado 4.200 M COP. El informe del 2026-10-12 declara **rojo** y 55 %. Hay una solicitud de cambio CC-01 (+43 días, +86 M COP) «autorizada por el comité». | Facultad del gerente, etapa, quién autorizó CC-01, y una nueva fecha de cierre que lo respalde. |
| PRY-211 Cobranza digital | 16 de 16 | Gerente Beatriz Cuéllar; patrocinadora Paula Céspedes; producto recaudos; presupuesto aprobado 2.400 M COP. El informe del 2026-10-13 declara **verde** y 89 %. | Facultad del gerente, etapa, y acta de recibo para dos hitos declarados cerrados. |

PRY-211 tiene `ficha-pm.json`. La conservé entera en `pm_record`, sin fusionarla con mi lectura.

### Lo que `compute` levantó

24 señales entre los tres proyectos.

**PRY-211: declarado verde, el cálculo lo contradice.** Es el único verde contradicho (`declared_vs_evidence`). Las señales que el informe no recoge:
- **Compromisos vencidos (7):**
  - «Validar el ambiente 4» (Camilo Beltrán): 33 días.
  - «Confirmar la fecha 7» (Sandra Gil): 20 días. Se dijo entregado el 2026-09-18 y no se presentó acta.
  - «Entregar el punto 16» (Diana Molina): 13 días. Se dijo entregado el 2026-10-09 y no se presentó acta.
  - «Actualizar la matriz 6» (Felipe Arango): 12 días. Se dijo entregado el 2026-10-02 y no se presentó acta.
  - «Revisar el anexo 19» (Laura Vélez): 11 días.
  - «Aprobar el diseño 5» (Ricardo Salas): 4 días.
  - «Confirmar la fecha 23» (Felipe Arango): 2 días.
- **Compromisos reprogramados:** «Cerrar la prueba 2» (María Restrepo) se movió 6 veces, de 2026-10-01 a 2026-12-09. «Enviar el documento 1» (Ricardo Salas) se movió 4 veces. Ahora está para 2026-11-29.
- **Compromisos sin fecha (3):** «Validar el ambiente 20» (Andrés Lozano), «Entregar el punto 24» (Carlos Peña) y «Mandar el ajuste del presupuesto» (Laura Vélez, notas del 2026-10-16).
- **Hitos declarados cerrados sin acta (2):** «Diseño funcional aprobado» (2025-11-26) y «Ambiente de pruebas certificado» (2026-04-06).
- **Costo:** la proyección al cierre es 2.771 M COP contra 2.400 M aprobados, un 15,5 % de más.
- **Fecha de cierre:** el acta dice 2027-03-01 y el cronograma termina el 2026-12-25 (`pm_vs_pmo`). Ningún documento posterior aclara cuál vale.

**PRY-201: rojo declarado, y las señales lo respaldan.**
- **Desviación en tiempo:** +43 días, un 11,6 % sobre la línea base original. Pasa el umbral de 10 %.
- **Avance contra plan:** declara 55 %, pero el cronograma tiene sus 4 hitos cerrados. La diferencia es de 45 puntos.
- **Hitos cerrados sin acta (3):** «Ambiente de pruebas certificado», «Integración con el core» y «Piloto con usuarios internos». El único hito con acta es «Diseño funcional aprobado», y el acta es del 2026-10-16, más de un año después de su fecha de línea base.
- **Compromiso sin fecha:** «Entregar el punto 19» (Óscar Ramírez), del comité del 2026-10-13.

**PRY-208: una señal.** La proyección al cierre (984 M COP) supera en 23 % el presupuesto aprobado (800 M).

### El portafolio completo
Quedan 10 proyectos y 47 documentos, en un solo lote de 10 proyectos que se leen uno tras otro. No medí cuántos minutos tomó llegar al primer resultado. Leer los 25 documentos de estos tres proyectos fue lo que más tomó. A ese ritmo calculo entre 30 y 40 minutos para el resto, pero es una estimación mía.

### Lo que le falta a tu carpeta
- **Facultad del gerente:** ninguna de las tres actas la dice. Sin ella no puedo saber si una solicitud como CC-01 excede lo que el gerente podía aprobar.
- **Cuatro proyectos sin cronograma:** PRY-205, PRY-207, PRY-208 y PRY-209 no tienen archivo en `10-plan`. Sin hitos no se puede medir avance contra plan.
- **Actas de recibo:** casi todos los hitos «cerrados» no traen la suya.
- **Compromisos sin fecha o sin acta:** en los comités de PRY-211 aparecen compromisos «por definir» y entregas dichas en reunión que nadie respaldó con acta.
- **Riesgo no registrado:** las notas del 2026-10-16 de PRY-211 dicen que el proveedor podría no llegar con el equipo completo. Nadie lo anotó como riesgo. Lo dejé en la ficha.
- **Autorización de CC-01 en PRY-201:** dice «autorizada por el comité» sin nombre ni acta de ese comité.

Siguiente paso: correr el portafolio completo. Como eres PMO, también puedo publicar el estándar en una carpeta compartida para que los gerentes de proyecto usen los mismos criterios.
