# Corrida del 2026-10-16 · vendor-tracking

13 proyectos · 35 s · 50 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 13 |
| `commitment_overdue` | 9 |
| `declared_vs_evidence` | 6 |
| `commitment_undated` | 5 |
| `variance_cost` | 4 |
| `progress_vs_plan` | 4 |
| `variance_time` | 3 |
| `commitment_rescheduled` | 2 |
| `rebaseline_unauthorized` | 1 |
| `milestone_overdue` | 1 |
| `silent` | 1 |
| `pm_vs_pmo` | 1 |

PRY-207 no tiene proveedores en la ficha ni contratos en la carpeta; no se produjo cruce. Se declaró sin dato: contratos, vigencia, preaviso, facturación. Se señaló aparte silencio de 22 días y estado verde sin evidencia.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

**Sale de:** la ficha `estado/records/PRY-207.json`, el cálculo de `portafolio.py compute` (corte 2026-10-16) y los dos documentos de la carpeta del proyecto: `00-gobierno/2025-06-27-acta-constitucion.docx` y `20-seguimiento/2026-09-24-informe-avance.pdf`.

## Proveedores — PRY-207 Onboarding PyME al 2026-10-16

**No hay nada que contrastar: la ficha no tiene ningún proveedor** (`vendors: []`, y `vendors` vacío también en la salida de `compute`). Ni el acta de constitución ni el informe de avance nombran un proveedor, un contrato, entregables contractuales ni facturas.

No armo la tabla por proveedor, ni el cruce contra lo facturado, ni los vencimientos de contrato. Hacerlo sería inventar. Sin el contrato, esto no pasaría de una lista de supuestos.

### Dónde no cuadra
Sin datos para cruzar. Con cero proveedores, el script no levanta `late`, `accepted_without_evidence` ni `vendor_invoiced_without_delivery`. Eso es ausencia de dato, no un resultado limpio.

### Sin evidencia de recibo
Ninguno. No hay entregables contractuales declarados.

### Compromisos del proveedor vencidos
Ninguno. La ficha no tiene compromisos (`commitments: []`) y la carpeta no contiene minutas ni reuniones con proveedores.

### Sin dato
- **Contrato(s):** no están en la carpeta. `00-gobierno` solo trae el acta de constitución. No sé si el proyecto tiene proveedores.
- **Vigencia, renovación automática y preaviso:** no se pueden revisar, porque no hay contrato.
- **Montos facturados o aceptados:** no declarados en ningún documento.
- **Dependencias:** el acta declara "Ninguna declarada".

### Lo que sí se ve, aunque no es de proveedores
- El informe del 2026-09-24 declara estado **verde**, pero `compute` levanta `silent` (22 días sin documentos nuevos, desde 2026-09-24) y `declared_vs_evidence`. De las fuentes de la ficha, 0 son evidencia, 2 son declaración y 15 no están marcadas.
- El informe menciona una salida reprogramada "por ventana de cambio del área de operaciones" y dos semanas perdidas por la rotación de un desarrollador clave. Ninguna de las dos cosas aparece en un acta de cambio ni en una línea base nueva.
- La fecha de cierre del acta es 2026-06-19, que ya pasó al corte. La ficha tiene una sola línea base y 0 cambios registrados.
- Si algún tercero está detrás de esa salida o de ese desarrollador, nada en la carpeta lo dice. Pregúntale al gerente, Rubén Cárdenas, si hay contratos con terceros y pídele que los suba a `00-gobierno`.

**Siguiente paso:** subir los contratos y las actas de recibo de PRY-207, o confirmar por escrito que no tiene proveedores, y volver a correr `/vendor-tracking PRY-207`.

---
*Rigor:* cifras copiadas de `portafolio.py compute`; ninguna calculada a mano. Nada se afirma sin documento, y lo que falta se declara como falta. Es un borrador de trabajo: la verificación contra los documentos es de quien lo lee.
