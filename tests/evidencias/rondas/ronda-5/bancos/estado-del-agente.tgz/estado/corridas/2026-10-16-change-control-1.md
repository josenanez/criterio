# Corrida del 2026-10-16 · change-control

13 proyectos · 65 s · 50 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 13 |
| `commitment_overdue` | 9 |
| `declared_vs_evidence` | 6 |
| `commitment_undated` | 5 |
| `variance_cost` | 4 |
| `progress_vs_plan` | 4 |
| `variance_time` | 3 |
| `commitment_rescheduled` | 2 |
| `rebaseline_unauthorized` | 1 |
| `milestone_overdue` | 1 |
| `silent` | 1 |
| `pm_vs_pmo` | 1 |

Solicitud: mover 30 días la salida a producción de PRY-201. La salida a producción no es hito del plan y el fin vigente (2026-08-20) ya venció, así que no se registró línea base 3. impact: 0 proyectos alcanzados, pero hay una dependencia con el core sin nombrar. Autoridad no declarada; CC-01 sin acta ni nombre. Va a comité. No sé quién pide ni por qué, ni la fecha real de producción.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

Sale de la ficha PRY-201 (Core de depósitos), actualizada el 2026-10-16. Términos vigentes: versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-16 (ya estaban registrados; no se repitió el registro).

## Solicitud de cambio — PRY-201 Core de depósitos — 2026-10-16

**Qué se pide:** mover la salida a producción 30 días. · **Quién lo pide:** no consta en lo que me diste (no hay documento de solicitud; CC-01 es otra solicitud). · **Por qué:** no consta.

**Antes de evaluar, tres cosas que el plan no permite resolver:**
1. **La «salida a producción» no es un hito del plan.** El cronograma v2 tiene cuatro hitos y el último es «Piloto con usuarios internos». El criterio de éxito del acta es «Core de depósitos en producción y medido», pero ninguna fecha del plan lo representa. Tomé como referencia la única fecha de cierre que hay: la fecha de fin vigente.
2. **Esa fecha ya pasó.** El fin vigente es 2026-08-20 (cronograma v2). Moverla 30 días da 2026-09-19, que también es anterior a hoy (2026-10-16). El informe del 2026-10-12 declara el proyecto en rojo, con avance del 55%, y el plan dice que los cuatro hitos están cerrados (100%). La solicitud pide mover una fecha que ya está vencida, así que el cambio real sería fijar una fecha futura que nadie ha propuesto. Eso lo tiene que traer quien pide.
3. **Las cifras de CC-01 y de la línea base v2 no tienen sustento completo** (ver «Quién decide»).

### Impacto
| Dimensión | Hoy | Con el cambio | Diferencia |
| Alcance | Componentes 1–3 (acta); CC-01 amplió alcance sin detallarlo | Sin cambio declarado | No declarada |
| Tiempo | Fin vigente 2026-08-20 (línea base v2) | 2026-09-19 (si se suman 30 días a la fecha vigente) | +30 días; la fecha resultante ya pasó |
| Costo | 4.200.000.000 COP aprobados; CC-01 pide 86.000.000 COP adicionales; proyección 4.024.199.525 COP | No declarado | No declarado |

**Quién absorbe lo que no se declaró:** la solicitud no trae impacto en alcance ni en costo. Treinta días más con un equipo que ya perdió dos semanas por rotación de un desarrollador clave (informe 2026-10-12) se pagan en horas del equipo o en calidad, y la prueba de carga ya no alcanzó el umbral. El costo de esos 30 días no está estimado en ningún documento y no lo invento.

### Efecto en el portafolio
`impact` con 30 días sobre PRY-201 no alcanza a ningún proyecto: 0 alcanzados, 0 sin poder sostener su fecha, 0 dependencias sin confirmar. **Eso no significa que no haya efecto.** El informe del 2026-10-12 dice que dos historias quedaron fuera del sprint «por dependencia con el core» y no nombra el proyecto. La ficha la guarda como dependencia sin proyecto y sin confirmar, y el acta declara «Ninguna declarada». El cálculo no puede recorrer una dependencia que nadie nombró. Hay que preguntarle al gerente de qué proyecto o sistema depende.

| Proyecto afectado | Cómo | Gerente |
| Ninguno por dependencias declaradas | — | Mauricio Pérez (PRY-201) |

El cálculo tampoco dice cuántos días se mueve cada proyecto afectado: eso necesita holgura por actividad, que la ficha no tiene.

### Quién decide
**Autoridad requerida:** no determinable. La ficha no tiene autoridad declarada (`identity.authority`: no encontrado) y el acta de constitución no trae una cláusula de control de cambios. Ese es el hallazgo de fondo. Lo único documentado es que el Comité de Riesgos aprobó el presupuesto y la línea base v1 el 2025-06-23.
**Según:** acta 2025-06-23, que dice quién aprobó presupuesto y no quién aprueba cambios.
**Va a comité:** sí, por defecto. Sin autoridad declarada no se puede sostener que el gerente decide solo. Va al Comité de Riesgos, el que consta en el acta.

**Lo que ya pasó con CC-01 y condiciona esta decisión:**
- CC-01 (2026-10-05, +43 días, +86.000.000 COP) dice «Autorizada por el comité» sin nombre, sin fecha de decisión y sin acta. El acta del comité del 2026-10-13 solo lista asistentes (Mauricio Pérez, Elena Duarte) y un compromiso; no menciona CC-01.
- La línea base v2 (aprobada el 2026-10-12, fin 2026-08-20) no tiene motivo registrado. Los 43 días de CC-01 cuadran numéricamente con el movimiento (2026-07-08 → 2026-08-20), así que el script no marca días sin autorizar. Eso es cuadre de cifras, no autorización: el documento que autoriza no identifica quién autorizó. Además, las dos aprobaciones son posteriores a la fecha de fin que mueven.
- El acta fija el cierre en 2026-08-24; la línea base v1 del cronograma dice 2026-07-08. Esa diferencia no está explicada en ningún documento.
- Tres de los cuatro hitos figuran como cumplidos sin evidencia (ambiente de pruebas, integración con el core, piloto). Solo el diseño funcional tiene un acta de recibo, y es del 2026-10-16.

### Si no se aprueba
El proyecto sigue con fin 2026-08-20, ya vencido, en rojo, con 55% declarado frente a un plan que dice 100%. No hay una fecha vigente que alguien pueda cumplir, así que no aprobar deja un plan sin sentido, no uno sano.

### Si se aprueba
Línea base 3 — cierre 2026-09-19 (solo si se suman los 30 días a la fecha vigente; no sirve porque ya pasó) · presupuesto: sin cambio declarado · motivo: sin motivo en la solicitud.
**No la registro.** Para registrar la línea base 3 faltan una fecha futura propuesta, un motivo y el documento que la aprueba, firmado por quien tenga autoridad. La línea base v2 sigue en pie; no se toca ninguna.

**Desviación acumulada contra la línea base original (v1, 2026-07-08):** hoy +43 días (11,6%). Con 30 más serían +73 días (≈19,7%) y la segunda replanificación (el conteo pasaría de 1 a 2). En costo, contra el original: +86.000.000 COP pedidos en CC-01 (+2,0% sobre 4.200.000.000), más lo que costaran estos 30 días, que no está estimado.

## Qué no sé
- Qué fecha de producción se quiere realmente, quién la pide y por qué.
- De qué proyecto depende PRY-201 para las dos historias fuera del sprint.
- Quién autorizó CC-01 y la línea base v2.
- Cuántos días se mueve cada proyecto afectado (no hay holgura por actividad).

## Siguiente paso
Llevarlo al Comité de Riesgos con tres preguntas cerradas: (1) fecha real de producción, (2) quién autoriza cambios en este proyecto, (3) acta que respalde CC-01. No registro línea base nueva hasta que exista un documento de aprobación.

---
Pie de rigor: borrador de trabajo, no decisión ni asesoría. Cada dato sale de los documentos de la carpeta PRY-201 (acta 2025-06-23, cronograma v1 y v2, CC-01, informe 2026-10-12, acta de comité 2026-10-13); lo que no está lo dije. La verificación es de quien lo lea.
