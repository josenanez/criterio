Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-16). Ya había comprobante; no se registró de nuevo.

## Acta — PRY-205 · Prevención de lavado de activos
**Estado:** existe, del 2025-07-04 (`documentos/proyectos/PRY-205-prevención-de-lavado-de-activos/00-gobierno/2025-07-04-acta-constitucion.md`). No hay corrida previa de /project-charter para este proyecto.

### Qué falta
| Campo | Estado | Consecuencia |
|---|---|---|
| Autoridad del gerente | **No existe** | Diana Molina no tiene un monto ni un tipo de cambio que pueda decidir sin comité. Cualquier cambio, incluido el de fechas que ya hace falta (ver más abajo), tiene que subir al Comité de Transformación Digital, porque nada dice que no. |
| Objetivo de negocio | Describe la solución, no el negocio: «Entregar prevención de lavado de activos para Tesorería» | No dice qué riesgo se reduce ni cuánto. Nadie puede juzgar si el proyecto vale lo que cuesta (18.000 M COP) ni si un recorte de alcance lo sigue cumpliendo. |
| Alcance | Marcadores sin llenar: «Componente 1, 2, 3» | El alcance no está definido. Cualquier solicitud de cambio se compara contra nada y no se puede decir qué es cambio y qué es alcance original. |
| Exclusiones | «Lo que otro proyecto cubre», sin nombrar ese proyecto | No excluye nada concreto. Si hay un proyecto vecino que cubre parte de esto, el acta no lo identifica y el solapamiento queda sin dueño. |
| Dependencias | «Ninguna declarada» | Un proyecto de PLA para Tesorería sin ninguna dependencia de sistemas, datos o regulador es poco creíble. Y el informe del 2026-10-14 habla de una «aprobación regulatoria pendiente desde el trimestre anterior», que el acta nunca anticipó. |
| Supuestos y restricciones | **No existen** | No hay contra qué detectar que un supuesto cayó. La espera regulatoria no se puede registrar como supuesto vencido porque nunca se declaró uno. |
| Criterio de éxito | «En producción y medido», sin umbral ni quién mide | No se puede declarar éxito ni fracaso en el cierre. «Medido» no dice contra qué meta. |
| Hitos principales | Solo inicio (2025-07-14) y cierre (2026-08-24) | No hay hitos intermedios, así que el avance del 77% no se puede contrastar con ningún hito. |
| Cadencia del comité | El comité está nombrado, la cadencia no | No se sabe cada cuánto debe ver el proyecto. |
| Patrocinador / Gerente | Con nombre: Andrés Lozano / Diana Molina | Sin hallazgo. |
| Presupuesto | Declarado: 18.000.000.000 COP, aprobado el 2025-07-04 | Sin hallazgo. No declara reserva de contingencia, pero eso no es obligatorio. |

### Contenido (tal como está en el acta)
**Objetivo de negocio:** pendiente de definir. El acta dice «Entregar prevención de lavado de activos para Tesorería», que es la solución, no un objetivo medible. (acta, §Objetivo del negocio)
**Alcance:** pendiente de definir. El acta solo trae «Componente 1/2/3». (acta, §Alcance)
**Exclusiones:** pendiente de definir. Dice «Lo que otro proyecto cubre», sin proyecto. (acta, §Fuera de alcance)
**Patrocinador:** Andrés Lozano · **Gerente:** Diana Molina (acta, encabezado)
**Autoridad del gerente:** pendiente de definir. No hay monto ni cambios delegados.
**Comité al que reporta:** Comité de Transformación Digital (acta) · **Cadencia:** pendiente de definir.
**Supuestos:** pendiente de definir · **Restricciones:** pendiente de definir.
**Criterio de éxito:** «en producción y medido» (acta, §Criterio de éxito); sin meta numérica · **Lo mide:** pendiente de definir.
**Hitos principales:** inicio 2025-07-14 y cierre 2026-08-24 (acta, §Fechas comprometidas). No hay otros.

### Lo que el acta no previó y ya pasó
- La fecha de cierre del acta, 2026-08-24, venció hace 53 días. El informe del 2026-10-14 reporta 77% de avance, estado Amarillo y no menciona una fecha nueva ni un cambio de línea base aprobado. No encontré ese cambio en los documentos del proyecto, que son solo el acta y el informe. Como no hay autoridad delegada, la decisión sobre la fecha nueva le corresponde al comité.
- El informe reporta 77% de avance y 4.201.895.790 COP ejecutados sobre 18.000.000.000 aprobados (23%). Eso queda fuera del acta y no lo analicé aquí; es materia de /health-check o /budget-tracking.

### Lo que no sé
- No tengo la minuta del comité del 2025-07-04 ni ningún otro documento de PRY-205. Si la autoridad del gerente, los supuestos o el proyecto vecino se hablaron allí, no consta en lo que leí.
- No sé a qué otro proyecto se refiere «lo que otro proyecto cubre».

### Después
- El acta quedó sin autoridad declarada. Propongo llevar esa definición al comité como decisión: cuánto puede aprobar Diana Molina y qué cambios de alcance y de fechas puede cerrar sin subir. Va junto con la fecha de cierre vencida.
- De la revisión sale un supuesto implícito que habría que registrar en RAID: que la aprobación regulatoria llegaría a tiempo. Ya se dio tarde. El riesgo abierto en el informe, «concentración del conocimiento en una sola persona», no está en el acta. Si quieres, lo paso a /raid-log.

*Pie de rigor: borrador de trabajo basado solo en el acta (2025-07-04) y el informe de avance (2026-10-14). Cada dato lleva su fuente; la verificación es tuya.*
