# Corrida del 2026-10-16 · budget-tracking

13 proyectos · 46 s · 50 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 13 |
| `commitment_overdue` | 9 |
| `declared_vs_evidence` | 6 |
| `commitment_undated` | 5 |
| `variance_cost` | 4 |
| `progress_vs_plan` | 4 |
| `variance_time` | 3 |
| `commitment_rescheduled` | 2 |
| `rebaseline_unauthorized` | 1 |
| `milestone_overdue` | 1 |
| `silent` | 1 |
| `pm_vs_pmo` | 1 |

Presupuesto de PRY-211: proyección 15.5% sobre el aprobado con informe en verde; 2 hitos cumplidos sin evidencia; ejecutado 39.6% frente a avance declarado 89%. No se escribió el monto de la desviación porque el script no lo da; hay un ajuste de presupuesto prometido sin fecha.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

Fuentes: ficha PRY-211 (`estado/records/PRY-211.json`), cifras recalculadas con `portafolio.py compute` al 2026-10-16. Documentos: acta de constitución (2025-07-08) e informe de avance (2026-10-13). Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-16).

## Presupuesto — PRY-211 Cobranza digital al 2026-10-16
**Moneda:** COP (única; no hay contratos en otra moneda ni conversiones)

| | Monto (COP) | % del aprobado | Fuente | Fecha |
|---|---|---|---|---|
| Aprobado | 2.400.000.000 | 100% | 00-gobierno/2025-07-08-acta-constitucion.md | 2025-07-08 |
| Comprometido | 1.243.793.744 | 51.8% | 20-seguimiento/2026-10-13-informe-avance.md | 2026-10-13 |
| Ejecutado | 949.227.038 | 39.6% | 20-seguimiento/2026-10-13-informe-avance.md | 2026-10-13 |
| Proyección al cierre | 2.771.140.444 | 15.5% por encima del aprobado | 20-seguimiento/2026-10-13-informe-avance.md | 2026-10-13 |

**Disponible real** (aprobado menos comprometido): 1.156.206.256 COP

La proyección es una declaración del gerente, no un dato duro. Tiene la misma fecha que comprometido y ejecutado (2026-10-13), así que no es más vieja que el último movimiento de presupuesto que hay en los documentos.

### Contra la línea base
| | Original | Vigente | Desviación |
|---|---|---|---|
| Presupuesto aprobado | 2.400.000.000 | 2.400.000.000 | 0 |

Replanificaciones de presupuesto: 0. No hay solicitudes de cambio registradas (0). El acta del 2025-07-08 es la única fuente del aprobado y tiene 15 meses, por encima del umbral de 12 meses para campos viejos.

### Ejecución frente a avance
Ejecutado 39.6% · Hitos cumplidos 3 de 4 · Avance declarado 89% (el plan sustenta entre 75% y 100%).
Lectura: la ejecución está muy por debajo del avance declarado. Puede ser trabajo hecho y no facturado que aparecerá de golpe, o un avance sobredeclarado. Los documentos no distinguen entre las dos. Además, de los 3 hitos "cumplidos", 2 no tienen evidencia de recibo (Diseño funcional aprobado, vencido el 2025-11-26; Ambiente de pruebas certificado, vencido el 2026-04-06). Solo "Integración con el core" tiene acta de recibo.

### Alertas
- **Proyección por encima del aprobado: 15.5%**, sobre el umbral de 10%. El informe de avance del 2026-10-13 declara el proyecto en **verde** y no da cuenta de esta señal.
- Comprometido en 51.8%, por debajo del umbral de 90%. No hay alerta de agotamiento.
- Hay 2 hitos declarados cumplidos sin evidencia (ver arriba).
- Hay un compromiso sin fecha de Laura Vélez, "Mandar el ajuste del presupuesto" (notas del 2026-10-16). Si ese ajuste cambia el aprobado o la proyección, hoy no está en ningún documento.

### Sin dato
- Ninguna de las cuatro cifras está en `not_found`.
- Monto de la desviación en pesos (proyección menos aprobado): el script no lo entrega, así que no lo escribo. Solo se reporta el porcentaje, 15.5%.
- Sin facturación por proveedor: la ficha no tiene proveedores registrados (`vendors` vacío).
- Faltan en la ficha la autoridad y la fase del proyecto.

### Después
La proyección excede el aprobado: puedo preparar la solicitud de cambio de presupuesto (`/criterio-portfolio:change-control`), si la pides.

*Pie de rigor: borrador de trabajo, no decisión ni asesoría. Cada cifra sale de los documentos citados y del cálculo del script; la verificación es de quien lo lea. Lo que se habló fuera de esos documentos no está aquí.*
