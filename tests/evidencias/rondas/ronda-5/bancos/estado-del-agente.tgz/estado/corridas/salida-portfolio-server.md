# Rostrum — para mirarlo un rato

**Términos:** ya estaban vigentes (versión 1.1, familia 0.3.11), aceptados por José Francisco Ñáñez el 2026-10-16. Comprobante en `.criterio/terminos/aceptacion-criterio-portfolio-0.3.11-2026-10-16.md` y `.pdf`. Resumen: Criterio produce borradores de trabajo, no decisiones ni asesoría; cada dato lleva la cita del documento de donde salió y la verificación es de quien lo usa. Nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal

**Modo elegido:** «para mirarlo un rato» (venía en el argumento `rato`). No se pregunta nada más: se levanta, se mira y se apaga con Ctrl-C.

**Informe encontrado:** `reportes/` (13 proyectos PRY-199 a PRY-211, 9 productos, decisiones, proyectos, productos e índice).

**Dirección:** `http://127.0.0.1:8787` — escucha solo en este equipo, sin autenticación y sin salir a la red. Si el puerto está ocupado, `--puerto 8788`.

| Ruta | Qué es | Para quién |
|---|---|---|
| `/` | La portada, con las tres secciones y el formulario de peticiones | Todos |
| `/pmo` | Cómo va el portafolio: verdes que la evidencia no sostiene, silencios, quién patrocina más de una cosa | La PMO |
| `/decisiones` | Lo que necesita una decisión, como pregunta cerrada y con la consecuencia de no decidirla | El comité y el patrocinador |
| `/proyectos` | El listado, ordenado por lo que más pide atención | Todos |
| `/p/<código>` | El informe de un proyecto, con enlace al producto que lo origina | Quien gerencia y quien pregunta |
| `/productos` | Los productos y los proyectos que no dicen cuál construyen | Quien responde por un producto |
| `/producto/<nombre>` | El informe de un producto, con enlace a los proyectos que lo construyen | Quien responde por un producto |
| `/estado.json` | De cuándo es el informe y cuántas peticiones hay abiertas | Un mecanismo |

El portal lleva el nombre «Portafolio de proyectos» (de `organization.name`).

**Lo que Rostrum no hace:** no calcula (sirve lo que `informe.py` ya escribió), no escribe fichas (solo crea peticiones en `estado/peticiones/`), no autentica y no manda nada (ni correo ni notificaciones). El servidor no puede correr el agente: las peticiones esperan hasta que `due` las cuente y rompan el silencio de `/portfolio-wake`.

**Para que quede corriendo después:** es otra conversación (host, puerto y control de acceso de la organización, con `--abierto`). Hoy no hace falta.

**A quién le pasas el enlace:** a nadie todavía. `127.0.0.1` solo abre en este equipo; sirve para que lo veas tú. El informe es del 2026-10-16 y se desactualiza con la próxima corrida de barrido; la portada muestra la fecha. El próximo comité es el 2026-10-21.
