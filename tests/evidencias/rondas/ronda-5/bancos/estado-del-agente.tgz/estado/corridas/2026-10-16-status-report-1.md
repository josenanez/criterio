# Corrida del 2026-10-16 · status-report

13 proyectos · 29 s · 50 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 13 |
| `commitment_overdue` | 9 |
| `declared_vs_evidence` | 6 |
| `commitment_undated` | 5 |
| `variance_cost` | 4 |
| `progress_vs_plan` | 4 |
| `variance_time` | 3 |
| `commitment_rescheduled` | 2 |
| `rebaseline_unauthorized` | 1 |
| `milestone_overdue` | 1 |
| `silent` | 1 |
| `pm_vs_pmo` | 1 |

Informe de PRY-207: verde declarado al 2026-09-24 sin sustento (22 días en silencio, alerta declared_vs_evidence). Fecha de cierre 2026-06-19 ya pasada sin replanificación, el script no la marca. Dije que no sé: hitos, última reunión, autoridad, fase.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

Informe generado desde la ficha `estado/records/PRY-207.json` (actualizada el 2026-10-16), con cifras recalculadas por `portafolio.py compute` al 2026-10-16.

## PRY-207 Onboarding PyME — estado al 2026-10-16

**Declara el gerente:** verde · 37% · al 2026-09-24 (Rubén Cárdenas; informe de avance `20-seguimiento/2026-09-24-informe-avance.pdf`; la declaración tiene 22 días, dentro del límite de 30)
**Sustento documental:** sin sustento. De los datos de la ficha, 0 están marcados como evidencia, 2 como declaración y 15 sin marcar. Los únicos documentos leídos son el acta de constitución (2025-06-27) y ese mismo informe de avance.
**Lo que el semáforo no explica:** `silent`. Alerta `declared_vs_evidence`: el gerente reporta verde y el proyecto lleva 22 días en silencio.
**Último documento:** 2026-09-24 · **Última reunión:** sin dato (la ficha no registra ninguna reunión)

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2026-06-19 | 2026-06-19 | 0 días contra la original y contra la vigente |
| Presupuesto (COP) | 6.800.000.000 aprobado | 6.800.000.000 aprobado | Proyección 6.389.554.656 → −6.0% sobre lo aprobado |

Ejecutado: 2.689.278.690 (39.5%). Comprometido: 2.965.251.105 (43.6%). Disponible real: 3.834.748.895.

Replanificaciones: 0. No hay solicitudes de cambio en la ficha.

**Ojo con el cero de desviación:** el script mide la desviación contra una fecha de cierre que nadie ha movido. La fecha de cierre vigente (2026-06-19) es anterior a la fecha de este informe (2026-10-16), y el gerente declara 37% de avance. Ningún documento mueve esa fecha ni explica el desfase. El script no lo marca como alerta; lo dejo a la vista.

### Hitos
Sin dato: la ficha no tiene hitos (`plan.milestones` está vacío). No se puede decir si alguno se cumplió ni si venció.

### Dónde no coincide
- **Declarado (informe de avance, 2026-09-24):** verde y 37%.
- **Documentos (mismo informe, 2026-09-24):** reporta dos incidencias abiertas: reprogramación de la salida por ventana de cambio de operaciones, y dos semanas perdidas por rotación de un desarrollador clave. Ambas contradicen el verde en su espíritu, pero ningún documento independiente las confirma ni las cuantifica.
- No hay ningún documento posterior al 2026-09-24 que sostenga o contradiga la declaración.

### Abierto
**Riesgos e incidencias sin movimiento:**
- Riesgo: cambio regulatorio en discusión que puede mover el alcance. Sin probabilidad, impacto, dueño, fecha ni último movimiento.
- Incidencia (desde 2026-09-24, sin dueño): reprogramación de la salida por ventana de cambio de operaciones.
- Incidencia (desde 2026-09-24, sin dueño): dos semanas perdidas por rotación de un desarrollador clave.

**Compromisos vencidos:** ninguno registrado (la ficha no tiene compromisos).
**Dependencias sin confirmar:** ninguna registrada.

### Sin dato
- Autoridad (`identity.authority`) y fase (`identity.phase`).
- Hitos (`plan.milestones`).
- Última reunión, compromisos y dependencias.
- Dueño de las dos incidencias y datos de valoración del riesgo.
- Datos con más de 12 meses de antigüedad (16 meses, del acta del 2025-06-27): código, nombre, área, producto, patrocinador, gerente, comité, fechas de inicio y cierre, alcance, exclusiones y presupuesto aprobado.

### Siguiente paso posible
El silencio de 22 días supera el umbral de 15 y hay una fecha de cierre vencida sin replanificación. Puedo preparar el punto de comité, o la solicitud de cambio si se confirma que la fecha cambió y nadie lo formalizó.

---
*Criterio Portafolio v0.3.11 · ficha de PRY-207 actualizada el 2026-10-16 · campos inciertos: autoridad, fase, hitos y los 12 campos con más de 12 meses · términos aceptados por José Francisco Ñáñez el 2026-10-16: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.11*
