# Portafolio — 2026-10-16
13 proyectos · 10 con hallazgos (50 señales) · fichas cargadas desde `estado/records/` (13 fichas, instantánea del 2026-10-16) · último barrido 2026-10-16

Términos: vigentes (v1.1, familia 0.3.11), aceptados por José Francisco Ñáñez el 2026-10-16; no hizo falta registrarlos de nuevo.
Nota: la configuración habla de `estado/fichas/`, pero las fichas están en `estado/records/`; leí esa carpeta.

## Qué cambió desde la corrida anterior
Sin cambios desde la corrida anterior. La única instantánea es la de hoy (2026-10-16) y el diff contra ella da 0 cambios; este informe es el punto de partida, no hay delta histórico.

## Contradicciones abiertas
| Proyecto | Campo | Dice | Fuente | Dice también | Fuente |
|---|---|---|---|---|---|
| PRY-211 Cobranza digital | plan.end_date | 2026-12-25 | 10-plan/2025-07-08-cronograma-v1.xlsx (2025-07-08) | 2027-03-01 | 00-gobierno/2025-07-08-acta-constitucion.md (2025-07-08) |

Misma fecha en ambas fuentes, así que no se puede decir cuál es la más reciente: necesita que alguien decida.

## Hitos vencidos sin evidencia
| Proyecto | Hito | Fecha | Días | Última mención |
|---|---|---|---|---|
| PRY-202 Migración a la nube | Integración con el core | 2026-10-13 | 3 | vencido, sin cierre |

Además, 13 hitos figuran como "cumplido" sin documento que lo respalde (ver "Sin sustento").

## Proyectos en silencio
| Proyecto | Días | Último documento |
|---|---|---|
| PRY-207 Onboarding PyME | 22 (umbral 15) | 2026-09-24, informe de avance |

## Dependencias en riesgo
Vacía: el cálculo no encontró dependencias rotas entre proyectos.

## Sin sustento
Seis proyectos declaran verde y las señales lo contradicen (`verdes_contradichos` = 6):
| Proyecto | Declara | Qué lo respalda |
|---|---|---|
| PRY-202 Migración a la nube | verde (2026-10-15) | Nada: avance declarado 24% frente a 50–75% que sostiene el plan, un hito vencido y uno "cumplido" sin evidencia |
| PRY-204 Débito contactless | verde (2026-10-07) | Nada: 71% declarado frente a 100% que sostiene el plan, +31 días vs original, 3 hitos "cumplidos" sin evidencia, un compromiso vencido |
| PRY-206 Billetera y QR | verde (2026-09-26) | Nada: 62% declarado frente a 100% que sostiene el plan, 3 hitos "cumplidos" sin evidencia (hasta 373 días) |
| PRY-207 Onboarding PyME | verde (2026-09-24) | Nada: 22 días sin documentos |
| PRY-210 Portal de proveedores | verde (2026-10-12) | "Diseño funcional aprobado" cumplido sin evidencia (115 días) |
| PRY-211 Cobranza digital | verde (2026-10-13) | Nada: 7 compromisos vencidos, 2 reprogramados 4 y 6 veces, 2 hitos sin evidencia, costo +15,5% |

PRY-201 Core de depósitos tiene además 3 hitos "cumplidos" sin evidencia y avance declarado 55% frente al 100% que sostiene el plan.

## Vacíos de información
| Proyecto | Qué falta |
|---|---|
| Los 13 | Sin autoridad registrada (`no_authority` = 13): no se sabe quién aprueba qué |
| PRY-202, 205, 208, 210 | Sin producto asociado |

## Estado general
| Proyecto | Declarado | Sustento | Desviación vs original | vs vigente | Replanificaciones |
|---|---|---|---|---|---|
| PRY-199 Cajeros | — | sin señales | 0 d | 0 d | 0 |
| PRY-200 Originación digital | — | tiempo +139 d (36%), costo +10,6%, línea base movida 139 d sin autorización | +139 d | 0 d | 1 |
| PRY-201 Core de depósitos | — | avance 55% vs 100% del plan; 3 hitos sin evidencia | +43 d (11,6%) | 0 d | 1 |
| PRY-202 Migración a la nube | verde | contradicho | 0 d | 0 d | 0 |
| PRY-203 Open Banking | — | costo +26,8%; 1 compromiso vencido (16 d) | 0 d | 0 d | 0 |
| PRY-204 Débito contactless | verde | contradicho | +31 d (13,8%) | 0 d | 1 |
| PRY-205 Prevención de lavado | — | sin señales | 0 d | 0 d | 0 |
| PRY-206 Billetera y QR | verde | contradicho | 0 d | 0 d | 0 |
| PRY-207 Onboarding PyME | verde | contradicho (silencio) | 0 d | 0 d | 0 |
| PRY-208 Motor de decisión | — | costo +23% | 0 d | 0 d | 0 |
| PRY-209 Nómina electrónica | — | sin señales | 0 d | 0 d | 0 |
| PRY-210 Portal de proveedores | verde | contradicho | 0 d | 0 d | 0 |
| PRY-211 Cobranza digital | verde | contradicho; costo +15,5%; 17 señales | 0 d | 0 d | 0 |

Sin señales: PRY-199, 205 y 209.

## Necesito que confirmes
Sesión sin interfaz: no hay confirmación periódica este mes. Queda para la próxima corrida con persona.

## Informe HTML
Quedó en `reportes/` (26 páginas: una por proyecto, una por producto y las vistas generales).
- `reportes/index.html` — por campo, con la cadena de evidencia completa. Para quien va a actuar (PMO y gerentes).
- `reportes/decisiones.html` — por decisión, para el patrocinador: solo lo que excede la facultad de quien gerencia, como pregunta cerrada y con la consecuencia de no decidir.
- PDF: se obtiene imprimiendo el HTML.

La configuración trae `report.format: presentation`; usé `html` porque lo pediste.

Comité próximo: 2026-10-21. Puedo preparar el material con `/criterio-portfolio:steering-pack`, o entrar al detalle de PRY-211, PRY-200 y PRY-204.

---
Pie: criterio-portfolio 0.3.11 · fichas de `estado/records/` con fecha 2026-10-16 · campos inciertos: la fecha de fin de PRY-211 y la autoridad de los 13 proyectos · términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.11
