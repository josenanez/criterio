Fichas cargadas: las 13 de `estado/records/` (PRY-199 a PRY-211), todas con fecha de corte 2026-10-16, y las salidas de hoy de raid-log y change-control. Cifras copiadas de `portafolio.py compute` al 2026-10-16. Términos vigentes: versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-16 (ya estaban registrados; no se repitió el registro).

# Comité de proyectos — 2026-10-21
6 decisiones · 2 escalamientos sin decisión asociada · 10 de 13 proyectos con hallazgos (50 señales)

**Antes de la lista:** ningún proyecto de las 13 fichas tiene autoridad de decisión declarada (`identity.authority`: sin dato en 13 de 13). Por eso el punto 1 es quién decide; los demás dicen «Quién decide» según lo que consta en cada acta y lo marcan como no verificado.

## Decisiones del comité anterior
No hay material de comité anterior en `estado/` (esta es la primera corrida de steering-pack) ni decisiones registradas en las fichas. No sé qué se decidió antes; lo único que consta son aprobaciones atribuidas a «comité» sin acta (PRY-201 CC-01 y PRY-204 CC-01, punto 2).

| Decisión | Fecha | Qué pasó | Estado |
|---|---|---|---|
| Sin registro | — | No consta | Desconocido |

## Decisiones de hoy

### [1] ¿Quién tiene la facultad de aprobar cambios de línea base en el portafolio, y quedan esas facultades por escrito en cada acta?
**Proyecto:** los 13 · **Quién decide:** el patrocinador de cada proyecto o quien presida el comité; no se puede determinar con los documentos · **Si no se decide hoy:** los puntos 2 a 5 se deciden sin que conste que quien decide puede hacerlo, y las aprobaciones de hoy quedarían en el mismo estado que las dos «aprobadas por comité sin acta».
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. El comité declara hoy autoridad por proyecto y la PMO la registra en las 13 fichas | Sin cambio | Una sesión | Sin costo declarado |
| B. Se pide a cada gerente declararla en el acta antes del próximo comité | Sin cambio | Una semana más sin autoridad | Sin costo declarado |
**Recomendación:** A, porque los puntos 2 a 5 dependen de ello. No sé si algún comité tiene esa facultad por reglamento interno; no está en los documentos.

### [2] PRY-201 Core de depósitos: ¿se ratifica o se revierte el CC-01 (+43 días, +86.000.000 COP) y la línea base v2 con fin 2026-08-20?
**Proyecto:** PRY-201 · **Quién decide:** el Comité de Riesgos, que es el que consta en el acta del 2025-06-23 (aprobó presupuesto y línea base v1); el acta no trae cláusula de control de cambios · **Si no se decide hoy:** el proyecto sigue con fin 2026-08-20, ya vencido, declarado en rojo con 55 % de avance frente a un plan que sustenta 100 % (4 de 4 hitos), y 3 hitos cumplidos sin evidencia.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Ratificar CC-01 con acta que nombre quién lo autorizó | Ampliación sin detallar | Fin vigente 2026-08-20 (+43 días, 11,6 % contra el original); la fecha ya pasó | +86.000.000 COP sobre 4.200.000.000 COP aprobados; proyección 4.024.199.525 COP |
| B. No ratificar y exigir nueva línea base con fecha futura, motivo y firma | Sin cambio declarado | Fecha por proponer por el gerente | Sin estimar |
**Recomendación:** B. CC-01 dice «autorizada por el comité» sin nombre ni acta; el comité del 2026-10-13 no la menciona. Ratificar una fecha ya vencida no deja un plan que alguien pueda cumplir. Además hay una solicitud verbal de +30 días a producción sin documento ni solicitante: no se incluye como opción.

### [3] PRY-200 Originación digital: ¿se aprueban CC-01 (+99 días, 198.000.000 COP) y CC-02 (+40 días, 80.000.000 COP), cuando la línea base ya se movió 139 días?
**Proyecto:** PRY-200 · **Quién decide:** el Comité de Transformación Digital, según el acta del 2026-06-17 (no verificado: sin cláusula de cambios a la vista) · **Si no se decide hoy:** el cronograma v3 (fin 2027-12-04) queda vigente sin autorización: ambas solicitudes figuran pendientes y el script marca 139 días de desplazamiento sin autorizar (36,0 % contra el original), con 10,6 % de sobrecosto proyectado (4.643.424.770 COP contra 4.200.000.000 COP).
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar ambas y registrar v3 con motivo | Ampliación (ambas) | Fin 2027-12-04 | 198.000.000 COP + 80.000.000 COP pedidos; la proyección ya supera lo aprobado |
| B. Aprobar solo una | No sé cuál tiene mayor sustento: no leí el contenido de las solicitudes más allá de la ficha | Se reajusta v3 | Según la elegida |
| C. Rechazar y volver a la línea base original (fin 2027-07-18) | Sin cambio | Original | Sobrecosto proyectado sigue |
**Recomendación:** decidir con A o B solo con motivo escrito; hoy v3 salta de v1 a v3 sin v2 y sin motivo registrado. El proyecto declara rojo y reconoce ya las señales de tiempo y costo.

### [4] PRY-209 Nómina electrónica: ¿se aprueba el CC-01 (+44 días, 88.000.000 COP) mientras el proveedor no confirma su última entrega?
**Proyecto:** PRY-209 · **Quién decide:** no consta en la ficha · **Si no se decide hoy:** la solicitud, pendiente desde 2026-10-11, sigue sin respuesta; el proyecto está en amarillo, con 43 % declarado, proyección 6,1 % bajo lo aprobado (16.894.433.848 COP contra 18.000.000.000 COP).
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar ya | Ampliación | +44 días | +88.000.000 COP |
| B. Aprobar condicionado a fecha firme del proveedor | Ampliación | +44 días, sujeto | +88.000.000 COP |
| C. Diferir hasta el comité siguiente | Sin cambio | Sin cambio | Sin cambio |
**Recomendación:** B o C. Con holgura de presupuesto el costo no es el obstáculo; el obstáculo es una fecha de proveedor sin confirmar (PRY-209-D1).

### [5] La dependencia del «core»: ¿quién es «el core», quién responde por él y con qué fecha se compromete?
**Proyecto:** PRY-200, PRY-201, PRY-203, PRY-210 (y PRY-202 con su hito de integración) · **Quién decide:** el comité, para nombrar un doliente · **Si no se decide hoy:** PRY-202 ya pasó el hito «Integración con el core» (2026-10-13, 3 días de atraso); el de PRY-210 vence el 2026-10-21; PRY-203 lo tiene el 2026-10-26.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Designar a PRY-201 como proyecto «core» y su gerente como doliente | Sin cambio | Condiciona a PRY-200, 202, 203, 210 a un proyecto en rojo con fecha vencida | Sin estimar |
| B. Pedir a cada gerente nombrar el proyecto o sistema del que depende | Sin cambio | Una semana más con la dependencia sin nombre | Sin costo |
**Recomendación:** B, porque A es hipótesis de la PMO, no un dato: ningún documento nombra el proyecto y PRY-201 se registra a sí mismo como dependencia.

### [6] PRY-211 Cobranza digital: ¿qué fecha de fin rige (2026-12-25 o 2027-03-01) y se atiende el sobrecosto del 15,5 %?
**Proyecto:** PRY-211 · **Quién decide:** no consta · **Si no se decide hoy:** el proyecto sigue declarado en verde con 89 % mientras tiene 7 compromisos vencidos, 2 reprogramados 4 y 6 veces, 2 hitos cumplidos sin evidencia y proyección de 2.771.140.444 COP contra 2.400.000.000 COP.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Fijar 2026-12-25 (cronograma v1) | Sin cambio | Más exigente | Sobrecosto proyectado 15,5 % |
| B. Fijar 2027-03-01 (acta de constitución) | Sin cambio | Más holgado | Igual |
| C. Pedir al gerente una sola fecha con motivo y una revisión de estado | Sin cambio | Una semana | Sin costo |
**Recomendación:** C. Las dos fechas son de la misma fecha de origen (2025-07-08) y ninguna es más reciente: no hay base para elegir entre A y B.

## Escalamientos sin decisión asociada
| Proyecto | Qué | Desde cuándo | Qué se necesita |
|---|---|---|---|
| PRY-208 Motor de decisión | Rojo, sobrecosto proyectado 23,0 % (984.226.926 COP contra 800.000.000 COP), 84,3 % comprometido (umbral configurado 90 %), proveedor sin fecha de entrega | informe 2026-10-16 | Que el gerente presente solicitud de cambio o plan de contención; no hay solicitud documentada |
| PRY-203 Open Banking | Sobrecosto proyectado 26,8 % (1.521.476.148 COP contra 1.200.000.000 COP), compromiso de Beatriz Cuéllar vencido 16 días | 2026-09-30 | Sustento de la proyección; informe declarado amarillo con 24 días de antigüedad |

## Para conocimiento
- PRY-199 Renovación de cajeros: sin señales; verde declarado (20 %).
- PRY-205 Prevención de lavado: sin señales; amarillo declarado (77 %); fecha de fin 2026-08-24 ya pasó y no hay solicitud de cambio, no sé por qué.
- PRY-202 Migración a la nube: verde declarado contra 24 % de avance y plan que sustenta 50–75 % (26,0 puntos de brecha); hito vencido; sin decisión asociada por ahora.
- PRY-204 Débito contactless: verde declarado contra 71 % de avance y plan que sustenta 100 % (29,0 puntos); CC-01 (+31 días, 62.000.000 COP) figura aprobado por «comité» sin nombre ni acta, mismo patrón que PRY-201.
- PRY-206 Billetera y QR: verde declarado hace 20 días contra 62 % y plan 100 % (38,0 puntos); 3 hitos cumplidos sin evidencia.
- PRY-207 Onboarding PyME: silencio de 22 días desde 2026-09-24 (umbral 15), verde declarado.
- PRY-210 Portal de proveedores: verde con un hito cumplido sin evidencia.

## Anexo
**Verde contradicho por la evidencia:** 6 proyectos (PRY-202, 204, 206, 207, 210, 211).
**Contradicciones:** `pm_vs_pmo` en PRY-211 (fecha de fin).
**Hitos cumplidos sin evidencia:** PRY-201 (3), PRY-204 (3), PRY-206 (3), PRY-211 (2), PRY-202 (1), PRY-210 (1).
**Informes antiguos (>15 días):** PRY-203 (24 días), PRY-206 (20), PRY-207 (22).
**Compromisos sin fecha:** PRY-201 (1), PRY-202 (1), PRY-211 (3).
**Datos obsoletos:** identidad y alcance con más de 12 meses en PRY-201, 202, 204, 205, 206, 207, 209, 211.
**Raid:** 36 ítems, ninguno con doliente, fecha, probabilidad ni impacto; 0 supuestos registrados.

## Qué no sé
- Quién tiene facultad de decidir en cada proyecto (13 de 13 sin autoridad declarada).
- Qué se decidió en el comité anterior: no hay registro.
- El contenido de las solicitudes CC de PRY-200 y PRY-209 más allá de lo que guarda la ficha.
- Qué es «el core» (hipótesis, no dato).
- Qué sustenta las proyecciones de costo de PRY-203 y PRY-208.
- Los campos de fase están sin dato en todos los proyectos.

---
Pie: criterio-portfolio 0.3.11 · fichas aplicadas: 13 (PRY-199 a PRY-211, corte 2026-10-16) · campos inciertos: los de «Qué no sé» · términos v1.1: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.11 · borrador de trabajo, no decisión ni asesoría; la verificación es de quien lo lee.

**Después:** cuando el comité sesione, puedo registrar las decisiones en las fichas para que el próximo material parta del ciclo cerrado. No lo hice: no se ha tomado ninguna.
