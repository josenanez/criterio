# Corrida del 2026-10-16 · portfolio-scan

13 proyectos · 72 documentos, 0 releídos y 72 sin cambio · 227 s · 50 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 13 |
| `commitment_overdue` | 9 |
| `declared_vs_evidence` | 6 |
| `commitment_undated` | 5 |
| `variance_cost` | 4 |
| `progress_vs_plan` | 4 |
| `variance_time` | 3 |
| `commitment_rescheduled` | 2 |
| `rebaseline_unauthorized` | 1 |
| `milestone_overdue` | 1 |
| `silent` | 1 |
| `pm_vs_pmo` | 1 |

Se leyeron 47 de 72 documentos (10 proyectos); no se movió ni omitió nada; sin carpeta entrada/. Mirar: PRY-200 (cronograma v3 ya aplica CC-01+CC-02 pendientes; falta v2), PRY-204 (CC autorizado sin acta), compromisos vencidos en PRY-203 y PRY-204, hitos cerrados sin acta en 202/204/206/210, cierres vencidos en 205/206/207. PRY-211 pm_record cita fuentes sin prefijo de carpeta.

Contra la corrida del 2026-10-16: +26 hallazgos.

## Lo que produjo

## Barrido — 2026-10-16

**Términos:** vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-16, comprobante en `.criterio/terminos/`). No hizo falta registrarlos de nuevo.

**Documentos:** 72 en la carpeta · 47 leídos · 25 sin cambio desde la corrida anterior · 0 ilegibles
**Proyectos:** 13 en la carpeta · 10 con ficha escrita y sellada en esta corrida · 3 sin cambio (PRY-201, PRY-208, PRY-211) · 0 nuevos sin carpeta propia

Formatos: 36 .md, 14 .docx, 8 .pdf, 7 .xlsx, 5 .csv, 1 .txt, 1 .json. Word, Excel y PDF se leyeron por su texto convertido; las citas van a los originales. Plan de lectura: 1 lote de 10 proyectos, uno tras otro, sin subagentes.

### Nuevos
No hay proyectos nuevos. Los 10 leídos ya tenían carpeta; las fichas de PRY-199, 200, 202–207, 209 y 210 son las primeras de este estado.

| Proyecto | Documentos | Campos encontrados | Campos sin dato |
|---|---|---|---|
| PRY-199 Renovación de cajeros | 6 | identidad, declarado, plan, 5 hitos, dinero, contrato CT-199 (3 entregables), 1 riesgo, 2 incidencias, 1 compromiso | autoridad, fase, facturado del contrato |
| PRY-200 Originación digital | 7 | identidad, declarado, plan (v1 y v3), 3 hitos, dinero, 2 cambios, 1 compromiso | autoridad, fase |
| PRY-202 Migración a la nube | 5 | identidad, declarado, plan, 4 hitos, dinero, 2 riesgos, 1 compromiso | autoridad, fase, producto (el acta dice «No aplica») |
| PRY-203 Open Banking | 6 | identidad, declarado, plan, 4 hitos, dinero, 1 riesgo, 1 compromiso | autoridad, fase |
| PRY-204 Débito contactless | 7 | identidad, declarado, plan (v1 y v2), 4 hitos, dinero, 1 cambio, 1 compromiso | autoridad, fase |
| PRY-205 Prevención de lavado | 2 | identidad, declarado, fechas, dinero, 1 riesgo | autoridad, fase, producto («No aplica»), cronograma e hitos |
| PRY-206 Billetera y QR | 5 | identidad, declarado, plan, 4 hitos, dinero, 2 riesgos, 1 compromiso | autoridad, fase |
| PRY-207 Onboarding PyME | 2 | identidad, declarado, fechas, dinero, 1 riesgo, 2 incidencias | autoridad, fase, cronograma e hitos |
| PRY-209 Nómina electrónica | 3 | identidad, declarado, fechas, dinero, 1 cambio, 1 riesgo | autoridad, fase, cronograma e hitos, contrato del proveedor que el informe menciona |
| PRY-210 Portal de proveedores | 4 | identidad, declarado, plan, 4 hitos, dinero, 2 incidencias, 1 riesgo | autoridad, fase, producto («No aplica») |

### Actualizados
Ninguno: no había fichas previas de estos 10. Las de PRY-201, PRY-208 y PRY-211 no se tocaron porque sus documentos no cambiaron.

### Lo que hay que mirar (contradicciones y vacíos que vi al leer)
Son lecturas de los documentos; el cálculo de señales y umbrales lo hace el informe.

| Proyecto | Qué vi | Fuente |
|---|---|---|
| PRY-200 | El cronograma v3 (2026-10-04) ya mueve «Integración con el core» de 2027-07-18 a 2027-12-04, +139 días, que es exactamente CC-01 (+99) más CC-02 (+40). Ambos cambios figuran «Pendiente de presentación al comité», y el v3 es anterior a las dos solicitudes. | `10-plan/2026-10-04-cronograma-v3.xlsx`, `20-seguimiento/2026-10-05-…cc-01.md`, `…2026-10-11-…cc-02.md` |
| PRY-200 | Falta el cronograma v2 (hay v1 y v3). El hito movido queda después del cierre comprometido en el acta (2027-09-21). | carpeta `10-plan/` |
| PRY-204 | CC-01 dice «Autorizada por el comité», sin acta ni nombre que lo respalde. El v2 mueve el piloto a 2026-05-23 (+31 días, igual que el CC), tres días después del cierre del acta (2026-05-20), que ya pasó con 71% de avance. | `20-seguimiento/2026-10-05-solicitud-cambio-cc-01.md`, `10-plan/2026-10-07-cronograma-v2.xlsx` |
| PRY-204, 206 | Cronogramas con todos los hitos «cerrado» y un solo acta de recibo (ambiente de pruebas en 204, diseño funcional en 206). Los demás cerrados no tienen acta que lo pruebe. | cronogramas y actas de recibo |
| PRY-202, 203, 210 | Cada uno con hitos cerrados y acta de recibo solo para parte. En 202, «Integración con el core» (2026-10-13) sigue en curso y ya venció. | cronogramas |
| PRY-203 | Compromiso de Beatriz Cuéllar para 2026-09-30, dicho en el comité del 2026-10-14: nace vencido. | `30-reuniones/2026-10-14-comite-semanal.docx` |
| PRY-204 | Compromiso de Rubén Cárdenas para 2026-10-03, dicho el 2026-10-12: nace vencido. | `30-reuniones/2026-10-12-comite-semanal.md` |
| PRY-202 | Compromiso de Liliana Torres con fecha «por definir». | `30-reuniones/2026-10-12-comite-semanal.md` |
| PRY-199 | El compromiso es de Carlos Peña, que no asistió al comité ni figura en el acta. | `30-reuniones/2026-10-12-comite-semanal.md` |
| PRY-205, 206, 207 | Cierre comprometido ya pasado (2026-08-24, 2026-02-09, 2026-06-19) con avance declarado de 77%, 62% y 37%. | actas e informes |
| PRY-200, 203, 210 | Los informes de 200 y 210 dicen «Dos historias… por dependencia con el core» y el de 203 «Dependencia del calendario de liberaciones del core», sin nombrar proyecto; las actas declaran «Ninguna declarada». En 200 y 210 quedó como dependencia sin proyecto y sin confirmar; en 203 como riesgo. | informes de avance |
| PRY-209 | El informe habla de un proveedor que no ha confirmado la última entrega; ningún documento trae su contrato. Solo PRY-199 tiene contrato (CT-199, Consultora Andina, 3 × 144.000.000 COP, todos pendientes, sin dato de facturación). | `20-seguimiento/2026-10-15-informe-avance.pdf` |
| PRY-211 | Su ficha del gerente (`pm_record`) cita fuentes sin la carpeta del proyecto («00-gobierno/…»), no relativas a la raíz de documentación; por eso el índice las marca como «fuente no encontrada» (17 campos). No lo corregí: esa ficha es del gerente. | `plan-lectura`, sección `index.source_missing` |

### No pude leer
Nada: 72 de 72 convertidos.

### Movidos desde entrada/
Nada. No existe carpeta `entrada/` en `documentos/`.

### Pendientes de clasificar
Nada.

### Qué no se hizo
- No se calcularon desviaciones, semáforos ni vencimientos: eso lo hace el informe.
- No se tocaron PRY-201, PRY-208 ni PRY-211.
- No hay `ficha-pm.json` en los 10 proyectos leídos; solo PRY-211 la tiene.
- Pasé el estado de los compromisos vencidos a `overdue` por la fecha del propio documento; el script los recalcula.

### Después
Hay más de un proyecto: puedo correr `/criterio-portfolio:portfolio-report` para el informe consolidado. Las contradicciones de PRY-200 y PRY-204 y los compromisos vencidos de PRY-203 y PRY-204 conviene verlos antes del comité del 2026-10-21.

---
Criterio Portfolio 0.3.11 · Fichas tocadas: PRY-199, 200, 202, 203, 204, 205, 206, 207, 209, 210 · `not_found`: autoridad y fase en las 10; producto en 202, 205 y 210; hitos en 205, 207 y 209; facturado en CT-199 · Términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.11
