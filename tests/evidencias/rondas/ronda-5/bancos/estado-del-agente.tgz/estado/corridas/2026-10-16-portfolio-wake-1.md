# Corrida del 2026-10-16 · portfolio-wake

13 proyectos · 49 s · 50 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 13 |
| `commitment_overdue` | 9 |
| `declared_vs_evidence` | 6 |
| `commitment_undated` | 5 |
| `variance_cost` | 4 |
| `progress_vs_plan` | 4 |
| `variance_time` | 3 |
| `commitment_rescheduled` | 2 |
| `rebaseline_unauthorized` | 1 |
| `milestone_overdue` | 1 |
| `silent` | 1 |
| `pm_vs_pmo` | 1 |

Barrido: 72 documentos, ninguno cambió, sin recálculo. Hallazgo: 17 citas de PRY-211 marcadas como rotas por una copia anidada vieja de la ficha; la vigente resuelve. Confirmación: 5 preguntas sin responder (sin interfaz). No consulté peticiones (no tocaban). No sé quién autorizó el movimiento de PRY-200 ni cuál fecha rige en PRY-211.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

## 2026-10-16

**Revisé:** 72 documentos · 0 cambiaron · 0 proyectos recalculados

### Lo que cruzó un umbral
Nada nuevo: ningún documento cambió, así que no hubo recálculo. El estado vigente sigue abierto (13 proyectos, 10 con alertas, 50 alertas, 6 con "verde" contradicho por la evidencia). No lo repito aquí; está en el último informe.

Un hallazgo del barrido, que no es de documentos:
- **PRY-211 — 17 citas que no resuelven.** El índice las marca como fuente inexistente (`00-gobierno/2025-07-08-acta-constitucion.md`, `20-seguimiento/2026-10-13-informe-avance.md`). Los archivos existen. La causa es una copia anidada y más vieja de la ficha (`estado/PRY-211-cobranza-digital/records/PRY-211.json`, 06:41) que cita con ruta relativa a la carpeta del proyecto. La ficha vigente (`estado/records/PRY-211.json`, 09:32) cita con el prefijo completo y resuelve. No toqué ninguna de las dos: hay que decidir si se retira la copia anidada.

### Peticiones atendidas
No tocaba `requests`; no las consulté.

### Preguntas
Nadie las respondió en esta corrida (sin interfaz). Quedan preguntadas el 16 de octubre, sin respuesta; no las repito.
1. **PRY-200, plan.end_date:** la fecha se movió 139 días (36 % sobre la original) sin cambio autorizado (2 cambios vistos, 0 autorizados). ¿Quién autorizó el movimiento? Fuente: señal `rebaseline_unauthorized`.
2. **PRY-207, estado declarado:** declarado verde el 24 de septiembre (informe de avance en PDF) y en silencio 22 días desde entonces. ¿Cuál es el estado hoy?
3. **PRY-211, plan.end_date:** la PMO tiene 2026-12-25 (cronograma v1, 2025-07-08) y el gerente 2027-03-01 (acta de constitución, 2025-07-08). Mismo día, dos fechas, ninguna es más nueva. ¿Cuál rige?
4. **PRY-202, estado declarado:** verde el 15 de octubre, con 24 % declarado frente a 50-75 % que sustenta el plan, e "Integración con el core" vencido hace 3 días. ¿Se mantiene el verde?
5. **PRY-203, money.projection:** la proyección es 1.521 M frente a 1.200 M aprobados (26,8 % por encima, el mayor desvío de costo). ¿Hay solicitud de cambio o adición presupuestal?

Observación aparte: los 13 proyectos aparecen sin autoridad de aprobación declarada (`no_authority`: 13).

**Vuelvo el 17 de octubre.**
