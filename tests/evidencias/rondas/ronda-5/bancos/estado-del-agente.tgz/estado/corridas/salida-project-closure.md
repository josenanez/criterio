**Fuente de esta salida:** ficha `estado/records/PRY-201.json` (actualizada 2026-10-16), cifras recalculadas con `portafolio.py compute` (corte 2026-10-16), y los siete documentos de `PRY-201-core-de-depósitos`: acta de constitución (2025-06-23), cronograma v1 (2025-06-23) y v2 (2026-10-12), solicitud de cambio CC-01 (2026-10-05), informe de avance (2026-10-12), comité semanal (2026-10-13) y acta de recibo del diseño funcional (2026-10-16). Términos vigentes (v0.3.11, aceptados por José Francisco Ñáñez el 2026-10-16).

## Cierre — PRY-201 Core de depósitos — 2026-10-16

**Lectura de entrada:** este proyecto no muestra evidencia de haber terminado. Su propio informe de avance (2026-10-12) lo declara en **rojo, 55 %**, con una prueba de carga que "no alcanzó el umbral pactado y se repite". Si se cierra hoy, se cierra **por decisión, no por cumplimiento**. Esta acta de cierre se produce para que esa decisión se tome con la evidencia a la vista.

### Contra lo comprometido
**Criterio de éxito:** "Core de depósitos en producción y medido." (acta de constitución, 2025-06-23, sección *Criterio de éxito*).
**Se cumplió:** **no se puede determinar**. Ningún documento muestra puesta en producción ni medición. El último hito del cronograma es un piloto con usuarios internos, y ese hito no tiene evidencia de cumplimiento. Lo que sí hay en contra: avance declarado 55 %, estado rojo y prueba de carga fallida en repetición (informe 2026-10-12).

El acta de constitución nombra el alcance como "Componente 1, Componente 2, Componente 3", sin describirlos. Los entregables que se pueden contrastar son los cuatro hitos del cronograma:

| Entregable comprometido | Estado declarado | Evidencia |
|---|---|---|
| Diseño funcional aprobado (hito 2025-10-03) | cumplido | Acta de recibo del 2026-10-16, firmada por Mauricio Pérez (gerente). El recibo es posterior a la fecha del hito. |
| Ambiente de pruebas certificado (hito 2026-01-04) | cumplido | **Sin evidencia.** Marcado cumplido sin documento; 285 días desde su fecha. |
| Integración con el core (hito 2026-04-07) | cumplido | **Sin evidencia.** 192 días desde su fecha. |
| Piloto con usuarios internos (hito 2026-08-20 vigente; 2026-07-08 original) | cumplido | **Sin evidencia.** 57 días desde la fecha vigente. |

Los cuatro hitos figuran cumplidos (4 de 4) y el avance declarado es 55 %: el plan sostiene 100 % y la declaración 55 %, una brecha de 45 puntos. Los dos números no se pueden reconciliar con los documentos. Además, el cronograma v1, fechado 2025-06-23, ya trae los cuatro hitos en estado "cerrado", incluidos los que en esa fecha eran futuros. Ese estado no es confiable como evidencia.

### Fuera de alcance final
| Qué quedó fuera | Decidido por | Cuándo |
|---|---|---|
| "Lo que otro proyecto cubre" (exclusión del acta, sin detalle) | Acta de constitución | 2025-06-23 |
| Dos historias fuera del sprint por dependencia con el core (informe de avance) | **No hay decisión registrada**; el informe lo describe como hecho, no como acuerdo | informe del 2026-10-12 |
| **Ampliación de alcance CC-01** (entró, no salió): el contenido no se describe en la solicitud ("Ampliación de alcance") | "El comité", sin nombre ni acta que lo respalde | solicitud del 2026-10-05 |

Hallazgo de cierre: las dos historias fuera de sprint son un recorte sin decisión registrada. Si se cierra el proyecto con ellas pendientes, quedan fuera de alcance de hecho.

### Números finales
| | Original | Vigente | Final | Desviación vs original |
|---|---|---|---|---|
| Fecha de cierre | 2026-07-08 (cronograma v1) | 2026-08-20 (cronograma v2, aprobado 2026-10-12) | **No hay fecha final**: no existe evidencia de cierre. La fecha vigente ya venció. | +43 días (11,6 %); contra la vigente: 0 días |
| Presupuesto aprobado | 4.200.000.000 COP | 4.200.000.000 COP en el informe; **CC-01 pide 86.000.000 COP adicionales** y no se ve reflejado | Ejecutado a hoy: 1.977.957.330 COP (47,1 %) | Proyección al cierre 4.024.199.525 COP, −4,2 % frente al aprobado |

Presupuesto, detalle (informe 2026-10-12, declaración del gerente): comprometido 1.271.847.231 COP (30,3 %), ejecutado 1.977.957.330 COP (47,1 %), proyección 4.024.199.525 COP.

Replanificaciones: **1** (v1 → v2). La v2 no registra motivo en ningún documento. La CC-01 (+43 días, aprobada por "el comité") coincide con los 43 días de desplazamiento y el script no la marca como no autorizada, pero su autorización carece de nombre y de acta.

Alertas del cálculo: la desviación de tiempo contra la original (11,6 %) supera el umbral de 10 %. Hay discrepancia de fuente: el acta de constitución dice cierre **2026-08-24** y el cronograma v1, "aprobado" el mismo día, termina el **2026-07-08**. Se usó el cronograma v1 como línea base original porque así lo toma la ficha; la diferencia queda para que alguien la resuelva.

Dos cifras del informe llaman la atención sin que los documentos expliquen por qué: lo comprometido (1.271.847.231) es menor que lo ejecutado (1.977.957.330), y la proyección queda por debajo de lo aprobado aunque el proyecto está en rojo y tiene un cambio de +86.000.000. No se concluye nada: se señala para que lo revise quien lleva el presupuesto.

### RAID al cierre
**Materializados**
- Rotación de un desarrollador clave: dos semanas perdidas (informe 2026-10-12). El registro lista aparte el riesgo "concentración del conocimiento en una sola persona"; que ambos sean el mismo hecho es lectura nuestra, no algo que el documento afirme.
- Dependencia con el core: dos historias quedaron fuera del sprint. El acta de constitución declaró "Ninguna declarada" como dependencias.

**No materializados:** no hay ninguno documentado como descartado.

**Abiertos, con doliente**
| Qué | Doliente |
|---|---|
| Riesgo: concentración del conocimiento en una sola persona | **Sin doliente** |
| Incidencia: prueba de carga bajo el umbral, se repite | **Sin doliente** |
| Incidencia: dos historias fuera del alcance del sprint | **Sin doliente** |
| Incidencia: tiempo perdido por rotación | **Sin doliente** |
| Dependencia con el core (el informe no nombra el proyecto) | **Sin doliente ni proyecto identificado** |
| Compromiso "Entregar el punto 19" (comité 2026-10-13) | Óscar Ramírez; sin fecha ("por definir"). No figura entre los asistentes del comité. |

Lo que queda abierto no tiene doliente, así que **no está cerrado**.

### Lecciones
Solo entran las que se anclan a un hecho documentado.

| Qué pasó | Cuándo | Efecto | Qué haríamos distinto |
|---|---|---|---|
| El acta declaró "Ninguna declarada" como dependencia, y después dos historias quedaron fuera del sprint por depender del core | Acta 2025-06-23; informe 2026-10-12 | Dos historias fuera del sprint; el documento no cuantifica el efecto en fechas | Declarar en el acta la dependencia con el core y su proyecto dueño antes de aprobar el alcance |
| Tres hitos se marcaron cumplidos sin acta de recibo; el único recibo documentado (diseño funcional) es del 2026-10-16, no de la fecha del hito (2025-10-03) | Hitos 2026-01-04, 2026-04-07, 2026-08-20; recibo 2026-10-16 | El avance declarado (55 %) y el plan (100 %) no se pueden reconciliar | Exigir el acta de recibo en la fecha en que el hito se da por cumplido |
| CC-01 (ampliación de alcance, +43 días, +86.000.000 COP) se aprobó con "autorizada por el comité", sin nombre ni acta | Solicitud 2026-10-05 | La línea base se movió 43 días sin motivo ni decisor trazable (la v2 no tiene razón registrada) | Registrar quién aprueba, en qué sesión y con qué acta antes de mover la línea base |
| Un desarrollador clave rotó y el equipo perdió dos semanas | Informe 2026-10-12 | Dos semanas perdidas; el documento no las liga a los 43 días de desplazamiento | Registrar el riesgo de concentración con doliente, probabilidad e impacto antes de que ocurra (hoy figura sin ninguno de los tres) |

### Sin dato
- Evidencia de producción y de medición (criterio de éxito).
- Descripción de los Componentes 1, 2 y 3 y de lo que entró con CC-01.
- Evidencia de cumplimiento de tres de los cuatro hitos; resultado de la prueba de carga repetida.
- Motivo de la v2 del cronograma; quién y cuándo aprobó CC-01; si los 86.000.000 COP entraron al presupuesto.
- Por qué el acta dice cierre 2026-08-24 y el cronograma v1 dice 2026-07-08.
- Dolientes de los riesgos, incidencias y dependencias abiertas; fecha del compromiso "punto 19".
- Autoridad de aprobación y fase del proyecto (campos no encontrados en ninguna fuente).
- Todo lo declarado por el gerente (estado, avance, presupuesto) proviene de un solo informe y no tiene contraparte en otro documento. Las 15 fuentes de la ficha sin marcar y las 2 declaraciones no incluyen ninguna evidencia independiente.

### Después
No se mueve la carpeta a `archivo/` ni se congela la ficha. Con el criterio de éxito sin evidencia y los asuntos abiertos sin doliente, archivar ocultaría el proyecto del barrido diario mientras el informe lo declara en rojo. Se archiva cuando alguien declare el cierre con nombre, o cuando haya evidencia de producción y medición.

---
**Pie de rigor:** lo que está arriba sale de siete documentos de la carpeta y de la ficha del 2026-10-16. Estado, avance y cifras de presupuesto son declaración del gerente (informe del 2026-10-12), sin evidencia independiente. Las cifras derivadas (43 días, 11,6 %, 47,1 %, 30,3 %, −4,2 %, 285/192/57 días, brecha de 45 puntos) vienen del cálculo del script. No se sabe nada de lo hablado fuera de esos documentos. Verifique las citas antes de decidir.
