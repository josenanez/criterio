# Corrida del 2026-10-16 · document-index

13 proyectos · 26 s · 50 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 13 |
| `commitment_overdue` | 9 |
| `declared_vs_evidence` | 6 |
| `commitment_undated` | 5 |
| `variance_cost` | 4 |
| `progress_vs_plan` | 4 |
| `variance_time` | 3 |
| `commitment_rescheduled` | 2 |
| `rebaseline_unauthorized` | 1 |
| `milestone_overdue` | 1 |
| `silent` | 1 |
| `pm_vs_pmo` | 1 |

72 documentos sin cambio, 0 por releer. 17 citas de PRY-211 no resuelven (ruta sin carpeta del proyecto; los archivos existen). No verifiqué la causa contra la ficha.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

## Carpeta al 2026-10-16

**Documentos:** 72 · **Sin cambio:** 72 · **Hay que releer:** 0

### Cambió el contenido
Ninguno.

### Solo se reguardó
Ninguno.

### Renombrado o movido
Ninguno.

### Ya no está
Ninguno.

### Citas que dejaron de resolver
17 citas de un solo proyecto, PRY-211, apuntan a rutas que el índice no resuelve:

| Proyecto | Campo | Documento citado |
|---|---|---|
| PRY-211 | pm_record.identity.code | 00-gobierno/2025-07-08-acta-constitucion.md |
| PRY-211 | pm_record.identity.name | 00-gobierno/2025-07-08-acta-constitucion.md |
| PRY-211 | pm_record.identity.business_area | 00-gobierno/2025-07-08-acta-constitucion.md |
| PRY-211 | pm_record.identity.product | 00-gobierno/2025-07-08-acta-constitucion.md |
| PRY-211 | pm_record.identity.sponsor | 00-gobierno/2025-07-08-acta-constitucion.md |
| PRY-211 | pm_record.identity.manager | 00-gobierno/2025-07-08-acta-constitucion.md |
| PRY-211 | pm_record.identity.committee | 00-gobierno/2025-07-08-acta-constitucion.md |
| PRY-211 | pm_record.declared.status | 20-seguimiento/2026-10-13-informe-avance.md |
| PRY-211 | pm_record.declared.progress_pct | 20-seguimiento/2026-10-13-informe-avance.md |
| PRY-211 | pm_record.plan.start_date | 00-gobierno/2025-07-08-acta-constitucion.md |
| PRY-211 | pm_record.plan.end_date | 00-gobierno/2025-07-08-acta-constitucion.md |
| PRY-211 | pm_record.plan.scope_summary | 00-gobierno/2025-07-08-acta-constitucion.md |
| PRY-211 | pm_record.plan.exclusions | 00-gobierno/2025-07-08-acta-constitucion.md |
| PRY-211 | pm_record.money.approved | 00-gobierno/2025-07-08-acta-constitucion.md |
| PRY-211 | pm_record.money.committed | 20-seguimiento/2026-10-13-informe-avance.md |
| PRY-211 | pm_record.money.executed | 20-seguimiento/2026-10-13-informe-avance.md |
| PRY-211 | pm_record.money.projection | 20-seguimiento/2026-10-13-informe-avance.md |

Los dos archivos existen en disco, dentro de `PRY-211-cobranza-digital/`. Lo que no resuelve es la ruta de la cita, que está escrita sin la carpeta del proyecto. Es probable que la causa sea ese prefijo y no un documento perdido, pero no lo verifiqué contra la ficha. La ficha `ficha-pm.json` de PRY-211 la escribió el gerente, no el agente, y no la toqué.

### Formatos que no se pudieron leer
Ninguno. Este comando no lee contenido: cuenta y compara.

### Siguiente paso
No hay documentos por releer, así que no corresponde `/portfolio-scan`. Lo pendiente es corregir el prefijo de ruta de las 17 citas de PRY-211, y eso lo decide su dueño.
