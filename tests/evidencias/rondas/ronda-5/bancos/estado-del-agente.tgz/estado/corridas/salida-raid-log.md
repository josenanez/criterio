Sale de: las 13 fichas de `estado/records/` (PRY-199 a PRY-211) y de los documentos citados en ellas: 13 informes de avance, 13 actas de constitución, 13 minutas de comité (7 proyectos; 6 de ellas de PRY-211) de 2026-09-04 a 2026-10-14 y las notas de reunión de PRY-211 del 2026-10-16. Escala de valoración: no hay una definida en la organización; se usaría alta/media/baja, pero ningún ítem trae probabilidad ni impacto y no los inventé. Los ids `PRY-xxx-Rn` / `-In` / `-Dn` son referencias de esta corrida; el registro de origen no tiene ids.

## RAID — portafolio al 2026-10-16
9 riesgos · 0 supuestos · 15 incidencias · 12 dependencias (36 ítems en 13 proyectos)
36 sin doliente · 36 sin fecha · 36 sin probabilidad/impacto · 1 no registrado formalmente
Sin movimiento en dos períodos: no se puede calcular. Cada proyecto tiene un solo informe de avance con riesgos, y ninguna ficha guarda fecha de último movimiento.

### Reclasificados (por qué)
Por la prueba rápida —si depende de alguien fuera del proyecto, es dependencia—, 9 ítems que los informes llaman "riesgos" pasan a dependencias. Esto lo hice yo, no lo dicen los documentos; el gerente puede objetarlo.
- "Disponibilidad del equipo de seguridad para la revisión final" (PRY-200, 204, 206, 210, 211): depende de un área ajena al proyecto.
- "El proveedor no ha confirmado la fecha de la última entrega" (PRY-208, 209, 211): depende de un tercero y es un hecho presente, no una posibilidad.
- "Dependencia del calendario de liberaciones del core" (PRY-203): el propio texto la llama dependencia.
- "Dos historias fuera del sprint por dependencia con el core" (PRY-200, 201, 210) ya estaba como incidencia, y su dependencia asociada como dependencia. Queda así.

### Necesitan decisión ahora
| Id | Tipo | Qué | Doliente | Desde | Por qué sube |
|---|---|---|---|---|---|
| PRY-200-D2, PRY-201-D1, PRY-210-D2 (más PRY-203-D1) | Dependencia | "Dependencia con el core": 2 historias fuera del sprint en PRY-200, 201 y 210; PRY-203 depende del calendario de liberaciones del core | Sin doliente | 2026-10-04 a 2026-10-12 (PRY-203: 2026-09-22) | Afecta a otros proyectos del portafolio. Ningún documento nombra el proyecto del que dependen y ninguna contraparte la confirmó. PRY-201 se llama "Core de depósitos" y registra esta dependencia sobre sí mismo. Decisión a formular: quién es "el core", quién es su doliente y qué fecha se compromete. |
| PRY-211-R1 | Riesgo (no registrado formalmente) | El proveedor podría no llegar con el equipo completo para la siguiente fase | Sin doliente | 2026-10-16 | Se dijo en reunión y nadie lo anotó. Convive con "el proveedor no ha confirmado la fecha de la última entrega" (PRY-211-D1) y con una incidencia de carga abierta. El informe del 2026-10-13 declara verde con 89 % y proyección 2.771.140.444 COP contra 2.400.000.000 COP aprobados. Decisión a formular: formalizar o descartar. |
| PRY-208-D1 | Dependencia | Proveedor sin fecha confirmada de la última entrega | Sin doliente | 2026-10-16 | PRY-208 declara rojo; comprometido 674.456.575 de 800.000.000 COP (84 %) y proyección 984.226.926 COP (123 %). La ficha no registra ningún proveedor ni contrato, así que no se puede contrastar con entregables. |
| PRY-209-D1 | Dependencia | Proveedor sin fecha confirmada de la última entrega | Sin doliente | 2026-10-15 | Hay un CC-01 pendiente (+44 días, +88.000.000 COP). Una fecha de proveedor sin confirmar condiciona esa decisión. |

### Detectados en reuniones, no registrados
| Qué | Tipo | Dicho en | Fecha |
|---|---|---|---|
| "El proveedor podría no llegar con el equipo completo para la siguiente fase" ("nadie lo anotó como riesgo") | Riesgo | PRY-211/2026-10-16-notas-reunion.txt | 2026-10-16 |

Las demás minutas (PRY-199, 200, 201, 202, 203, 204, 206 y los comités de PRY-211) solo traen asistentes y compromisos, sin riesgos dichos al pasar; lo comprobé buscando lenguaje de riesgo en todo el texto, no leyendo cada una en su totalidad. No inventé ninguno. PRY-205, 207, 208, 209 y 210 no tienen minutas en la carpeta.

### Sin doliente o sin fecha
Los 36 ítems no tienen doliente ni fecha (los 12 de dependencias tampoco tienen "necesaria para"). No relleno nada; abajo se listan por proyecto en el registro completo. Dos observaciones sobre la calidad del dato:
- "Concentración del conocimiento en una sola persona" aparece con el mismo texto en 6 proyectos (PRY-199, 201, 202, 205, 206, 208). No sé si es un riesgo real de cada uno o una frase de plantilla.
- Los informes de PRY-203 (2026-09-22), PRY-207 (2026-09-24) y PRY-206 (2026-09-26) tienen 20 a 24 días, por encima del umbral de silencio configurado de 15. Sus ítems no se han refrescado.

### Dependencias en riesgo
| Id | Depende de | Confirmada | Qué pasó |
|---|---|---|---|
| PRY-200-D2 / PRY-210-D2 | "El core" (proyecto no nombrado) | No | Si fuera PRY-201: su CC-01 (+43 días, +86.000.000 COP) figura aprobado por "comité" sin nombre ni acta, y su piloto pasó de 2026-07-08 a 2026-08-20. Es una hipótesis mía, no está en los documentos. |
| PRY-201-D1 | "El core" (el propio proyecto) | No | Dependencia sobre sí mismo; probablemente mal escrita. Hay que preguntar de qué depende en realidad. |
| PRY-203-D1 | Calendario de liberaciones del core | No | Su hito "Integración con el core" vence el 2026-10-26. La salida ya se reprogramó por una ventana de cambio de operaciones. |
| PRY-202 (sin ítem RAID) | Integración con el core | — | Hito con fecha 2026-10-13 sigue pendiente, sin acta de recibo. Pasó la fecha sin que el RAID diga nada. |
| PRY-210 (sin ítem RAID) | Integración con el core | — | Hito del 2026-10-21 sigue pendiente, con dos historias ya fuera del sprint por el core. Vence en 5 días. |

De las 12 dependencias, 0 llevan el código del proyecto del que dependen y 0 están confirmadas por la contraparte. El cruce de portafolio que haría este registro no se puede hacer hoy.

### Registro completo
Prob., Impacto, Doliente y Fecha están vacíos en todas las filas ("no declarado"). "Desde" es la fecha del informe donde aparece.

| Id | Tipo | Qué | Desde |
|---|---|---|---|
| PRY-199-R1 | Riesgo | Concentración del conocimiento en una sola persona | 2026-10-14 |
| PRY-199-I1 | Incidencia | Se reprogramó la salida por ventana de cambio del área de operaciones | 2026-10-14 |
| PRY-199-I2 | Incidencia | La prueba de carga no alcanzó el umbral pactado y se repite | 2026-10-14 |
| PRY-200-D1 | Dependencia (antes riesgo) | Disponibilidad del equipo de seguridad para la revisión final | 2026-10-04 |
| PRY-200-I1 | Incidencia | Hallazgo de seguridad en la revisión de arquitectura | 2026-10-04 |
| PRY-200-I2 | Incidencia | Dos historias fuera del sprint por dependencia con el core | 2026-10-04 |
| PRY-200-D2 | Dependencia | Core (proyecto no nombrado, sin confirmar) | 2026-10-04 |
| PRY-201-R1 | Riesgo | Concentración del conocimiento en una sola persona | 2026-10-12 |
| PRY-201-I1 | Incidencia | Dos semanas perdidas por rotación de un desarrollador clave | 2026-10-12 |
| PRY-201-I2 | Incidencia | Dos historias fuera del sprint por dependencia con el core | 2026-10-12 |
| PRY-201-I3 | Incidencia | Prueba de carga no alcanzó el umbral y se repite | 2026-10-12 |
| PRY-201-D1 | Dependencia | Core (el propio proyecto, sin confirmar) | 2026-10-12 |
| PRY-202-R1 | Riesgo | Concentración del conocimiento en una sola persona | 2026-10-15 |
| PRY-202-R2 | Riesgo | Cambio regulatorio en discusión que puede mover el alcance | 2026-10-15 |
| PRY-203-D1 | Dependencia (antes riesgo) | Calendario de liberaciones del core | 2026-09-22 |
| PRY-203-I1 | Incidencia | Se reprogramó la salida por ventana de cambio de operaciones | 2026-09-22 |
| PRY-204-D1 | Dependencia (antes riesgo) | Disponibilidad del equipo de seguridad para la revisión final | 2026-10-07 |
| PRY-204-I1 | Incidencia | Prueba de carga no alcanzó el umbral y se repite | 2026-10-07 |
| PRY-204-I2 | Incidencia | Dos semanas perdidas por rotación de un desarrollador clave | 2026-10-07 |
| PRY-205-R1 | Riesgo | Concentración del conocimiento en una sola persona | 2026-10-14 |
| PRY-206-R1 | Riesgo | Concentración del conocimiento en una sola persona | 2026-09-26 |
| PRY-206-D1 | Dependencia (antes riesgo) | Disponibilidad del equipo de seguridad para la revisión final | 2026-09-26 |
| PRY-207-R1 | Riesgo | Cambio regulatorio en discusión que puede mover el alcance | 2026-09-24 |
| PRY-207-I1 | Incidencia | Se reprogramó la salida por ventana de cambio de operaciones | 2026-09-24 |
| PRY-207-I2 | Incidencia | Dos semanas perdidas por rotación de un desarrollador clave | 2026-09-24 |
| PRY-208-R1 | Riesgo | Concentración del conocimiento en una sola persona | 2026-10-16 |
| PRY-208-D1 | Dependencia (antes riesgo) | Proveedor sin fecha confirmada de la última entrega | 2026-10-16 |
| PRY-209-D1 | Dependencia (antes riesgo) | Proveedor sin fecha confirmada de la última entrega | 2026-10-15 |
| PRY-210-D1 | Dependencia (antes riesgo) | Disponibilidad del equipo de seguridad para la revisión final | 2026-10-12 |
| PRY-210-I1 | Incidencia | Prueba de carga no alcanzó el umbral y se repite | 2026-10-12 |
| PRY-210-I2 | Incidencia | Dos historias fuera del sprint por dependencia con el core | 2026-10-12 |
| PRY-210-D2 | Dependencia | Core (proyecto no nombrado, sin confirmar) | 2026-10-12 |
| PRY-211-D1 | Dependencia (antes riesgo) | Proveedor sin fecha confirmada de la última entrega | 2026-10-13 |
| PRY-211-D2 | Dependencia (antes riesgo) | Disponibilidad del equipo de seguridad para la revisión final | 2026-10-13 |
| PRY-211-R1 | Riesgo (no registrado formalmente) | El proveedor podría no llegar con el equipo completo para la siguiente fase | 2026-10-16 |
| PRY-211-I1 | Incidencia | Prueba de carga no alcanzó el umbral y se repite | 2026-10-13 |

Supuestos: ninguno registrado en ningún proyecto. Tampoco los levanté: ningún documento dice qué se está dando por cierto. Los que más suelen fallar y que conviene preguntar a los gerentes: que el proveedor llegue con el equipo completo, que seguridad tenga disponibilidad, que el core libere a tiempo.

## Después
Puedo subir a comité (21 de octubre) lo que cumple el criterio de escalamiento: las dependencias del core (afectan a otros proyectos) y las dos de proveedor de PRY-208 y PRY-209. Cada una iría con la decisión formulada. También puedo proponer doliente para los 36 ítems —proponer, no asignar—. No hice ninguna de las dos cosas: queda a su decisión.

## Lo que esta corrida no sabe
- Quién es el doliente de cualquier ítem, y la probabilidad, el impacto y la fecha de todos.
- Qué proyecto es "el core". Es una hipótesis, no un dato.
- Cuánto llevan sin movimiento los ítems: hace falta más de un informe por proyecto.
- Si los informes de PRY-205 a PRY-210 omiten riesgos: no hay minutas de esos proyectos que contrastar.

---
Pie de rigor: borrador de trabajo, no decisión ni asesoría. Cada dato sale del documento citado; la verificación es de quien lo lee. 13 proyectos, 0 documentos nuevos releídos (se usó el caché de texto y las fichas del 2026-10-16). Términos v1.1 aceptados por José Francisco Ñáñez el 2026-10-16.
