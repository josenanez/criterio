## Producto «tarjeta débito» al 2026-10-16

Sale de las fichas de estado de los 13 proyectos del portafolio, calculadas al 2026-10-16.

**Tarjeta débito tiene un solo proyecto: PRY-204 Débito contactless.** La vista por producto no aporta nada aquí que no dé la ficha del proyecto, así que no armo sección de producto. Lo que dice el cálculo de ese proyecto, por si lo necesitas:

- **Alertas:** 7. Fecha comprometida: 2026-05-23 (única, sale de PRY-204). Ya está vencida 146 días.
- **Atraso:** 31 días contra la línea base original (13.8 %); 0 contra la vigente (1 replanificación, con cambio aprobado de 31 días).
- **Avance declarado 71 % contra un plan que sustenta 100 %** (4 de 4 hitos cumplidos): brecha de 29 puntos.
- **Tres hitos declarados cumplidos sin evidencia:** Diseño funcional aprobado (vencía 2025-11-05), Integración con el core (2026-02-25), Piloto con usuarios internos (2026-05-23).
- **Compromiso vencido:** Rubén Cárdenas, «Entregar el punto 18», vencía 2026-10-03, 13 días (comité 2026-10-12).
- **Declarado «verde» el 2026-10-07 contra 4 señales abiertas** (compromiso vencido, hito sin evidencia, avance contra plan, atraso). Estado declarado no sustentado.
- **Dinero (COP), las cuatro cifras presentes:** aprobado 9.500.000.000; comprometido 4.993.617.766 (52.6 %); ejecutado 2.541.292.498 (26.8 %); proyección 9.687.255.229 (2.0 % sobre lo aprobado).
- **Dependencias internas:** no hay; el producto no tiene otro proyecto con quien cruzarlas.
- **No sé:** la autoridad y la fase del proyecto no constan; las fichas no traen ningún dato marcado como evidencia (0 de 17), y varios campos de identidad tienen 14 meses de antigüedad.

### Proyectos sin producto declarado

Cuatro de los 13 proyectos no declaran producto. Nadie puede responder por el conjunto al que sirven.

| Proyecto | Área dueña |
|---|---|
| PRY-202 Migración a la nube | Tecnología |
| PRY-205 Prevención de lavado de activos | Tesorería |
| PRY-208 Motor de decisión | Banca Hipotecaria |
| PRY-210 Portal de proveedores | Tecnología |

Nota: PRY-199 declara «PRD-299», un código y no un nombre de producto; conviene confirmar que corresponde a un producto real.

*Pie de rigor: borrador de trabajo, no decisión ni asesoría. Cada dato sale de las fichas y sus citas; la verificación es de quien lo usa.*
