# Corrida del 2026-10-16 · project-history

13 proyectos · 54 s · 50 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 13 |
| `commitment_overdue` | 9 |
| `declared_vs_evidence` | 6 |
| `commitment_undated` | 5 |
| `variance_cost` | 4 |
| `progress_vs_plan` | 4 |
| `variance_time` | 3 |
| `commitment_rescheduled` | 2 |
| `rebaseline_unauthorized` | 1 |
| `milestone_overdue` | 1 |
| `silent` | 1 |
| `pm_vs_pmo` | 1 |

Historia de PRY-200 sobre 7 documentos (2026-06-17 a 2026-10-13). Una replanificación sin motivo ni aprobación (139 días, 36.0 %), 3.er trimestre 2026 sin documentos. No pude calcular meses declarando sin sustento (una sola declaración) ni decir por qué se movió el hito; falta la v2 y no está definida la referencia de cierre original (acta 2027-09-21 vs. v1 2027-07-18).

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

## Historia · PRY-200 Originación digital · 2026-06-17 a 2026-10-13

**Leí:** 7 documentos entre 2026-06-17 y 2026-10-13 (acta de constitución, cronogramas v1 y v3, informe de avance, CC-01, CC-02 y acta del comité del 13 de octubre). Todos desde la copia de texto en caché; las citas apuntan a los originales.
**Trimestres sin un solo documento:** 3.º trimestre de 2026 (julio–septiembre). Entre el acta y el cronograma v1 (2026-06-17) y el siguiente documento (2026-10-04) hay 109 días sin nada escrito.

### En una línea
El proyecto se aprobó el 2026-06-17 con la integración con el core el 2027-07-18 y sin dependencias declaradas. Tres meses y medio después, el cronograma v3 (2026-10-04) movió ese hito al 2027-12-04, sin motivo escrito ni documento que lo apruebe; las dos solicitudes de cambio que podrían explicarlo se fecharon después (10-05 y 10-11) y siguen pendientes de presentarse al comité. Al comité del 13 de octubre solo se le registró «Avance» y «Compromisos».

### Las cuatro cifras
| Replanificaciones | Atraso acumulado vs. original | Meses declarando sin sustento | Cambios de gobierno |
|---|---|---|---|
| 1 | 139 días (36.0 %) | No calculable: hay una sola declaración (2026-10-04); no hay serie | 0 |

### Línea de tiempo
| Fecha | Documento | Qué cambió |
|---|---|---|
| 2026-06-17 | 00-gobierno/2026-06-17-acta-constitucion.docx | Se aprueba el proyecto: 4.200.000.000 COP, inicio 2026-06-27, cierre 2027-09-21. Sponsor Laura Vélez, gerente Paula Céspedes. Dependencias: «Ninguna declarada». |
| 2026-06-17 | 10-plan/2026-06-17-cronograma-v1.xlsx | Línea base v1: Diseño funcional 2026-11-02, Ambiente de pruebas 2027-03-11, Integración con el core 2027-07-18. |
| 2026-10-04 | 10-plan/2026-10-04-cronograma-v3.xlsx | «Integración con el core» pasa de 2027-07-18 a 2027-12-04. Los otros dos hitos no cambian. No hay v2 en la carpeta. |
| 2026-10-04 | 20-seguimiento/2026-10-04-informe-avance.pdf | Estado declarado rojo, avance 24 %. Hallazgo de seguridad; dos historias fuera del sprint por dependencia con el core; proyección al cierre 4.643.424.770 COP. |
| 2026-10-05 | 20-seguimiento/2026-10-05-solicitud-cambio-cc-01.md | CC-01: ampliación de alcance, +99 días sobre la línea base vigente, +198.000.000 COP. «Pendiente de presentación al comité». |
| 2026-10-11 | 20-seguimiento/2026-10-11-solicitud-cambio-cc-02.md | CC-02: ampliación de alcance, +40 días, +80.000.000 COP. «Pendiente de presentación al comité». |
| 2026-10-13 | 30-reuniones/2026-10-13-comite-semanal.docx | Asisten Paula Céspedes y Laura Vélez. Temas: Avance, Compromisos. Un compromiso: Javier Hoyos, «Entregar el punto 38», para 2026-11-10. No menciona CC-01, CC-02 ni el cronograma v3. |

### Replanificaciones
| Nº | Fecha | Fecha de cierre nueva | Motivo declarado | Documento que la aprobó |
|---|---|---|---|---|
| 1 | 2026-10-04 (cronograma v3) | 2027-12-04 | Sin motivo documentado | Ninguno |

Atraso acumulado contra la línea base original: 139 días (36.0 %). Contra la vigente: 0, porque la v3 ya incorporó el movimiento. El script marca `rebaseline_unauthorized`: 139 días movidos, 0 autorizados, 2 solicitudes de cambio vistas, ambas pendientes. CC-01 (+99) y CC-02 (+40) hablan de días «sobre la línea base vigente», y ambas son posteriores a la v3.

### Gobierno
| Fecha | Qué cambió | Documento |
|---|---|---|
| — | Sin cambios de patrocinador, gerente ni comité en los documentos leídos | — |

### Compromisos que se repitieron
| Doliente | Qué | Veces | Fechas prometidas |
|---|---|---|---|
| — | Ninguno se repitió. Hay un solo compromiso abierto (Javier Hoyos, «Entregar el punto 38»), con una fecha prometida: 2026-11-10 | 1 | 2026-11-10 |

### Desde cuándo lo declarado no se sostiene
No se puede fechar un deslizamiento: hay una sola declaración (2026-10-04, rojo, 24 %) y no hay informes anteriores contra los cuales ver una deriva. Lo que sí se observa:
- La declaración dice rojo, y las señales abiertas coinciden con ese color: atraso de 139 días, proyección de costo 10.6 % sobre lo aprobado y movimiento de línea base sin autorizar. Ninguna de las tres aparece explicada en el informe (el script las marca como no contabilizadas).
- El 24 % no tiene un hito cumplido detrás: 0 de 3 hitos cumplidos, y el plan sustenta entre 0 % y 33 %. Está dentro del rango, no en contradicción.
- Ningún hito tiene evidencia de cumplimiento en los documentos.

### Lecciones ancladas a un hecho
1. **Una línea base que se mueve antes de que exista la solicitud que la justifica.** Hecho: la v3 del 2026-10-04 movió «Integración con el core» al 2027-12-04, y CC-01 y CC-02 son del 10-05 y del 10-11. Efecto: 139 días de atraso sobre la original sin autorización registrada.
2. **Una dependencia que no estaba en el acta.** Hecho: el acta del 2026-06-17 dice «Ninguna declarada»; el informe del 2026-10-04 reporta dos historias fuera del sprint «por dependencia con el core» y no nombra el proyecto del que depende. Efecto: la dependencia no tiene dueño ni fecha, y el hito de integración con el core es el que se movió.
3. **Un trimestre sin documentos.** Hecho: nada entre 2026-06-17 y 2026-10-04 (109 días). Efecto: no se puede saber cuándo se supo del desvío; el primer rastro escrito ya lo trae hecho.

### Lo que no sé
- Por qué se movió la integración con el core: ningún documento lo dice.
- Dónde está el cronograma v2 y quién aprobó la v3.
- Contra qué fecha medir. El script usa 2027-07-18 (último hito de la v1) como cierre original, pero el acta de constitución fija el cierre en 2027-09-21. No recalculé contra la fecha del acta; hay que confirmar cuál es la referencia.
- Si CC-01 y CC-02 explican el movimiento de la v3: los documentos no lo dicen.
- Quién es el responsable de las incidencias y del riesgo abiertos en el informe: ninguno tiene dueño.
- Autoridad y fase del proyecto: no figuran en ningún documento.

**Pie de rigor:** esto es un borrador de trabajo hecho con los 7 documentos de la carpeta; no sé lo que se habló fuera de ellos. Cada dato lleva su documento en la ficha `estado/records/PRY-200.json` y la verificación es de quien lo lea. Esta historia no atribuye intención: que el movimiento no tenga motivo escrito no dice por qué ocurrió ni quién decidió qué; eso se averigua hablando con las personas.

### Siguiente paso
Puedo llevar esta historia al cierre del proyecto o al comité del 2026-10-21, donde hay una decisión pendiente: qué hacer con CC-01 y CC-02 y con la v3 ya publicada.
