# Corrida del 2026-10-16 · product-requirements

PRD-303 · 17 requerimientos · 28 s · 36 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 14 |
| `requirement_untraced` | 12 |
| `requirement_undecided` | 5 |
| `requirement_accepted_without_evidence` | 2 |
| `requirement_without_owner` | 2 |
| `assumption_unverified` | 1 |

REQ-4305 y REQ-4309 aceptados sin evidencia; 12 aceptados sin proyecto ni decisor; 5 propuestos sin decidir (>60 días); REQ-4306 y REQ-4311 sin doliente; sin fichas en la corrida

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

## Registro — Cuenta PyME (PRD-303) · al 2026-10-16
17 requerimientos · 12 decididos · 83,3 % con evidencia · 0 % con proyecto que lo ejecuta

Nota de alcance: no hay fichas de proyecto en esta corrida (`--fichas` no existe), así que «sin proyecto» significa «ningún documento lo vincula», no «se comprobó que nadie lo construye».

### Se va a construir y nadie lo pidió
| REQ | Título | Estado | Doliente |
|---|---|---|---|
| REQ-4305 | Requerimiento REQ-4305 | aceptado | Felipe Arango |
| REQ-4309 | Requerimiento REQ-4309 | aceptado | Ricardo Salas |

Ninguno tiene una sola cita de quien lo pidió. Además, la evidencia de los otros 10 aceptados es la misma cita de una sola entrevista (2025-10-09): «Lo necesito y hoy no lo tengo.»

### Decidido y nadie lo está construyendo
Los 12 aceptados (REQ-2030, 4301–4306, 4309, 4310, 4312–4314), decididos el 2026-10-15, sin proyecto vinculado. Se decidieron hace un día, así que todavía no es un atraso; es el punto de partida para `/product-trace`.

### Sin doliente, o con un área en vez de una persona
| REQ | Título | Estado | Dice |
|---|---|---|---|
| REQ-4306 | Requerimiento REQ-4306 | aceptado | no dice quién |
| REQ-4311 | Requerimiento REQ-4311 | propuesto | no dice quién |

Lo cierra Javier Hoyos (gerente de producto), asignando una persona.

### Sin criterio de aceptación
Ninguno de los decididos. (REQ-4300 propuesto no tiene criterio, y no se le exige.) Aviso de forma: REQ-4305 solo dice «se verifica en producción», que no es medible.

### Decidido sin documento que lo respalde
El documento existe: el acta del comité del 2026-10-15. Lo que falta es **quién decidió**: en los 12 aceptados el acta no nombra a la persona que decidió, y cierra con «Se mantiene el plan».

| REQ | Quién decidió | Cuándo |
|---|---|---|
| los 12 aceptados | no consta | 2026-10-15 |

### Lleva meses y nadie lo decide
Umbral de la configuración: 60 días. Tiene la facultad el Comité de producto (autoridad configurada); lo lleva Javier Hoyos.

| REQ | Título | Propuesto hace | Quién tiene la facultad |
|---|---|---|---|
| REQ-4308 | Requerimiento REQ-4308 | 213 días (2026-03-17) | Comité de producto |
| REQ-4311 | Requerimiento REQ-4311 | 151 días (2026-05-18) | Comité de producto |
| REQ-4300 | Requerimiento REQ-4300 | 138 días (2026-05-31) | Comité de producto |
| REQ-4307 | Requerimiento REQ-4307 | 138 días (2026-05-31) | Comité de producto |
| REQ-4315 | Requerimiento REQ-4315 | 124 días (2026-06-14) | Comité de producto |

Se propone decidirlos (aceptar o descartar con documento), no cerrarlos por viejos.

### Evidencia vieja
14 requerimientos cuya evidencia más nueva es del 2025-10-09 (12 meses): REQ-2030, 4301–4304, 4306, 4307, 4308, 4310, 4311, 4312, 4313, 4314, 4315.

### Definición
- Supuesto sin verificar hace 90 días: «El segmento paga por esto» (umbral 30).
- Caso de negocio declara volumen mensual 149 630 (2026-07-16); no hay medición contra la cual contrastarlo.
- Criterio de éxito del producto: no está dicho.

## Por estado
| propuesto | aceptado | en construcción | entregado | descartado |
|---|---|---|---|---|
| 5 | 12 | 0 | 0 | 0 |

Después: ofrezco `/product-trace` (12 decididos sin proyecto). No hay candidato listo para `/product-charter` mientras los aceptados tengan evidencia vieja o ausente.
