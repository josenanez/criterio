# Acta de constitución — Cuenta PyME (REQ-4301) · borrador del 2026-10-16
**Producto:** PRD-303 Cuenta PyME · **Requerimientos:** REQ-4301

> Corrida sin interfaz: nadie respondió preguntas. Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-16), así que no se registró nada nuevo. Donde el comando ofrece seguir sin un elemento faltante, se tomó la respuesta sugerida: **se sigue y el faltante queda marcado como vacío del acta, sin rellenarlo.**

## Verificación previa del requerimiento (requirement-record)

| Condición | Resultado | Cita |
|---|---|---|
| Aceptado, no propuesto | **Sí, con reserva.** Figura «aceptado» desde 2026-06-28, pero el acta del comité solo cierra con «Se mantiene el plan» y **no dice quién decidió**. Quién decide qué se construye es el gerente de producto; la decisión no está atribuida a nadie. | `30-decisiones/2026-10-15-comite-producto.docx`; `requirements/REQ-4301.json` (`decision.who`: no encontrado) |
| Criterios de aceptación verificables | **Insuficiente.** El único criterio es «se verifica en producción»: no dice qué se mide, con qué umbral ni quién lo verifica. Existe, pero no permite juzgar el cierre meses después. | `30-decisiones/2026-10-15-comite-producto.docx` |
| Evidencia de demanda con cita | **Existe pero es débil y está vencida.** Una sola cita anónima: «Lo necesito y hoy no lo tengo.» (Cliente entrevistado, 2025-10-09). No nombra la cuenta pyme ni el REQ-4301, y tiene 12 meses y 7 días contra un umbral de 12 meses. | `10-descubrimiento/2025-10-09-entrevistas.docx` |
| Autoridad declarada en la definición | **No está.** La definición no declara qué puede decidir el gerente. El único dato es que el comité aparece como órgano y que el acta solo lista a Javier Hoyos como asistente. | `00-definicion/2026-07-16-definicion-producto.docx`; `30-decisiones/2026-10-15-comite-producto.docx` |

Faltan o están flojos cuatro elementos. Ninguno se rellenó; los cuatro pasan a «Vacíos de este acta».

## Qué problema resuelve
«El segmento Personas no tiene cuenta pyme.» (`00-definicion/2026-07-16-definicion-producto.docx`, 2026-07-16).
La frase se contradice sola: un segmento de Personas y un producto para pyme. La definición no lo aclara. La propuesta figura como «Propuesta principal», sin desarrollar.

## Criterio de éxito
- **De la definición:** no hay criterio de éxito (`definition.success`: no encontrado).
- **Del requerimiento REQ-4301:** «se verifica en producción» (doliente: Carlos Peña). Cómo se verifica: **no está dicho**. Este acta no lo inventa; es un vacío que cierra el doliente antes de firmar.
- **Cifra declarada:** volumen mensual de 149.630 (`2026-07-16-caso-de-negocio.md`). No tiene medición independiente en el expediente; es una cifra del negocio, no un criterio de éxito. Retorno esperado «en 24 meses», sin cifra.

## Alcance
### Entra
| REQ | Título | Evidencia que lo sostiene |
|---|---|---|
| REQ-4301 | Requerimiento REQ-4301 (el título es genérico en el acta; no hay descripción) | Cita de 2025-10-09 del «Cliente entrevistado», vencida y sin nombrar el producto. Pidió: «Cliente entrevistado». Doliente: Carlos Peña. |

### No entra
Esta acta cubre solo lo pedido (REQ-4301). El resto del registro queda fuera por no haberse pedido, no por una decisión de fondo. Fuente: tabla del comité de 2026-10-15.

| REQ | Estado en el comité | Por qué no entra |
|---|---|---|
| REQ-4300, 4307, 4308, 4311, 4315 | propuesto | No está aceptado: sin decisión no hay acta. |
| REQ-4302, 4303, 4304, 4305, 4306, 4309, 4310, 4312, 4313, 4314, REQ-2030 | aceptado | No se incluyó en el argumento de esta acta. Si pertenecen al mismo proyecto, se agregan en otra acta. REQ-4306 no tiene doliente, y REQ-4305 y REQ-4309 no tienen quién lo pidió. |

Ningún requerimiento tiene proyecto que lo ejecute en el comité (columna «Proyecto que lo ejecuta»: «—»), y la definición declara «Ninguno» (`2026-07-16-definicion-producto.docx`).

## Gobierno
- **Patrocinador:** no dicho en ningún documento.
- **Gerente propuesto del proyecto:** no dicho. Javier Hoyos es gerente de *producto* (`definicion-producto.docx`); no se propone como gerente del proyecto sin que lo decida quien tiene la autoridad.
- **Comité:** Comité de producto, mensual (`config.json`; `comite-producto.docx`). Quién lo integra y quién decide: no dicho.
- **Autoridad del gerente:** no declarada.

## Supuestos que se llevan al proyecto
| Supuesto | Verificado | Se convierte en riesgo de |
|---|---|---|
| «El segmento paga por esto» (declarado 2026-07-18, `definicion-producto.docx`) | No. Lleva 90 días sin verificar contra un umbral de 30. | Riesgo del proyecto (raid-taxonomy): si el segmento no paga, el retorno de 24 meses no se sostiene. **Doliente: sin asignar**; lo asigna quien firma. |
| REQ-4301 no trae supuestos propios registrados | — | — |

Observación: el supuesto está fechado el 2026-07-18, dos días *después* de la fecha de la definición (2026-07-16). Hay que aclarar cuál fecha vale.

## Restricciones normativas sin resolver
| Qué toca | Obligación | Norma | Estado |
|---|---|---|---|
| Una cuenta para pymes toca captación de depósitos, datos personales y consumidor financiero, pero **ningún documento del expediente lo menciona** | No determinada | No citada: no se hizo el barrido normativo y no se inventa una norma | **Sin barrido.** Se corre `regulatory-sweep` antes de firmar. |

## Vacíos de este acta
| Qué falta | Consecuencia de firmar sin eso | Quién lo cierra |
|---|---|---|
| Quién decidió aceptar REQ-4301 | La aceptación no tiene autor; el proyecto nace sobre una decisión que nadie puede sostener. | Gerente de producto (Javier Hoyos) |
| Criterio de aceptación verificable | El cierre no se podrá juzgar: «se verifica en producción» admite cualquier resultado. | Doliente (Carlos Peña) con el gerente de producto |
| Criterio de éxito en la definición | El proyecto no tiene contra qué medirse. | Gerente de producto |
| Evidencia de demanda vigente y específica | Se construye sobre una frase anónima de hace más de 12 meses. | Gerente de producto (nueva ronda de entrevistas) |
| Autoridad del gerente del proyecto | Escala todo o no escala nada. | Comité de producto |
| Patrocinador y gerente del proyecto | No hay a quién le queda la ficha. | Quien tiene la autoridad en la organización |
| Contradicción «Personas» vs «pyme» en el problema | El alcance del producto es ambiguo. | Gerente de producto |
| Barrido normativo | Obligaciones sin ver. | Gerente de producto con cumplimiento |

---
**Esto es un borrador.** Lo firma quien tenga la autoridad para constituir el proyecto (patrocinador o comité: ningún documento dice cuál). **La ficha del proyecto no se creó:** no hay firma, y la ficha nace después de ella. No se escribió estado declarado.

## Qué sigue y para quién
Cuando el acta esté firmada, se crea la ficha con `portafolio.py init`. El gerente del proyecto, una vez nombrado por quien tiene la autoridad, instala `criterio-project` y corre `/pm-setup`. Cuando publique su ficha con `/pm-publish`, `/product-trace` podrá confirmar la traza, y Alba sabrá si su producto se está construyendo sin tener que preguntarle a nadie.
