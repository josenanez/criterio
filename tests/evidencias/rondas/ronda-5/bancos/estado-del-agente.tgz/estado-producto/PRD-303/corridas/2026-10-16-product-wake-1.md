# Corrida del 2026-10-16 · product-wake

PRD-303 · 17 requerimientos · 74 s · 36 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 14 |
| `requirement_untraced` | 12 |
| `requirement_undecided` | 5 |
| `requirement_accepted_without_evidence` | 2 |
| `requirement_without_owner` | 2 |
| `assumption_unverified` | 1 |

Primera revisión sin corte previo: línea base de 17 requerimientos (35 señales). No verifiqué trazas por código: solo PRY-207 nombra 'cuenta PyME' y queda sin confirmar. Dije que no sé quién decide en el comité ni contrastar el volumen declarado (sin serie medida). Rutas de fuente del registro no resuelven en plan-lectura.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

## Cuenta PyME (PRD-303) · 2026-10-16

**Primera revisión: no hay corte anterior** (`last: null`), así que no puedo separar lo nuevo de lo que ya estaba. Lo que sigue es la línea base: de aquí en adelante solo se reportará lo que cruce un umbral después de hoy.

Términos vigentes (versión 1.1, aceptados el 2026-10-16 por José Francisco Ñáñez). Carpeta: 4 documentos, ninguno nuevo ni cambiado desde el registro; no hubo nada que releer.

Registro: 17 requerimientos (12 aceptados, 5 propuestos). 10 con evidencia (83,3 % de los 12 decididos), 0 trazados a un proyecto.

### Lo que necesita decisión
| Qué | REQ | Cuánto lleva | Qué se necesita | Quién |
|---|---|---|---|---|
| Sin decidir (umbral 60 días) | REQ-4308 | 213 días (desde 2026-03-17) | Decisión de aceptar o descartar | Gustavo Neira es el doliente; **quién decide no está nombrado** |
| Sin decidir | REQ-4311 | 151 días; además **sin doliente** | Nombrar doliente, luego decidir | Sin dueño |
| Sin decidir | REQ-4300 | 138 días y sin criterio de aceptación ni evidencia | Criterio de aceptación y evidencia antes de decidir | Javier Hoyos |
| Sin decidir | REQ-4307 | 138 días | Decidir | Rubén Cárdenas |
| Sin decidir | REQ-4315 | 124 días | Decidir | Mauricio Pérez |

El acta del comité del 2026-10-15 solo lista a Javier Hoyos como asistente y ningún documento nombra a quién tiene la facultad de decidir. Es el dato que falta para los cinco. Ofrezco llevarlos al comité de producto.

### Aceptado sin sustento
- **REQ-4305** y **REQ-4309** están aceptados sin ninguna evidencia de que alguien los pidiera.
- **REQ-4306** está aceptado y **no tiene doliente**.

### Supuesto sin verificar
- «El segmento paga por esto» lleva 90 días sin verificarse (umbral 30). Hace falta una prueba de disposición a pagar con clientes del segmento, por ejemplo una oferta con precio. Ya pasó el punto en que conviene tratarlo como riesgo registrado: aplica assumption-tracking.

### Evidencia que envejeció
- 14 requerimientos se sostienen en la misma entrevista del 2025-10-09, que cumple 12 meses. Se queda sin sustento todo lo que dependa de «Lo necesito y hoy no lo tengo.» Hace falta descubrimiento nuevo antes de que el comité acepte algo más con esa base. Esto incluye los 10 aceptados con evidencia.

### Las trazas
- **0 de 12 requerimientos aceptados tienen proyecto.** Ninguno se está construyendo según el registro (y la definición dice «Ninguno declarado»).
- La ficha de **PRY-207 «Onboarding PyME»** dice que ejecuta el producto «cuenta PyME», pero ningún requerimiento apunta a ese proyecto. Es un desacuerdo entre su ficha y este registro; no lo resuelvo yo. La coincidencia es por nombre, no por código, y la ficha es del acta de 2025-06-27, así que la traza **no queda confirmada**: queda pendiente de que alguien la confirme.

### De la definición y el descubrimiento
- Sin criterio de éxito en la definición (no encontrado).
- El caso de negocio declara un volumen mensual de 149.630 y no hay serie medida para contrastarlo; no puedo decir si coincide con los datos.
- La definición dice que el problema es que «el segmento Personas no tiene cuenta pyme», una incongruencia entre segmento y producto que merece revisión en `/product-definition`.
- Sin documentos de descubrimiento nuevos.

### Aviso técnico
`plan-lectura` marcó como «fuente no encontrada» las 10 citas del registro; sus rutas están escritas desde `documentos/…` y el plan las resolvió contra la carpeta del producto. Los 4 documentos existen y sus huellas no cambiaron, así que lo trato como un desajuste de rutas del registro y no como documentos borrados. Conviene revisarlo.

**Vuelvo el 2026-11-15.**
