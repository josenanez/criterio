Sesión sin interfaz: tomé las respuestas sugeridas. Términos ya vigentes (versión 0.3.11, términos 1.1), aceptados por José Francisco Ñáñez el 2026-10-16; no hizo falta registrarlos de nuevo.

# Caso de negocio — Cuenta PyME (PRD-303) · borrador del 2026-10-16
**Desde:** `00-definicion/2026-07-16-definicion-producto.docx` y `00-definicion/2026-07-16-caso-de-negocio.md` (ambos del 2026-07-16) · **Cifras con fuente:** 1 de 1 declarada; 0 medidas

> Primer vacío, y el que decide: **no hay costo de construir en ningún documento.** Sin él esto es una propuesta, no un caso de negocio que se pueda evaluar.

## Qué problema resuelve, y para quién
- **Problema:** «El segmento Personas no tiene cuenta pyme.» (definición, 2026-07-16).
- **Para quién:** «Segmento Personas» (misma fuente). El problema habla de pymes y el segmento es Personas; ningún documento explica la diferencia.
- **Lo que lo sostiene:** una sola cita, «Lo necesito y hoy no lo tengo» (`10-descubrimiento/2025-10-09-entrevistas.docx`, 2025-10-09). No dice cuántos clientes se entrevistaron, si es del segmento ni si pagaría. Evidencia débil y de hace 12 meses.

## Qué se construye
Alcance: los 12 requerimientos **aceptados** del acta del 2026-10-15 (`30-decisiones/2026-10-15-comite-producto.docx`). Los 5 propuestos (REQ-4300, 4307, 4308, 4311, 4315) quedan fuera hasta que se decidan. Ningún requerimiento tiene proyecto que lo ejecute.

| Requerimiento | Estado (desde) | Evidencia de demanda |
|---|---|---|
| REQ-4301 | aceptado (2026-06-28) | «Cliente entrevistado» (Carlos Peña, doliente) |
| REQ-4302 | aceptado (2026-08-21) | «Cliente entrevistado» |
| REQ-4303 | aceptado (2026-04-10) | «Cliente entrevistado» |
| REQ-4304 | aceptado (2026-04-28) | «Cliente entrevistado» |
| REQ-4305 | aceptado (2026-06-02) | **Ninguna** — el acta no dice quién lo pidió |
| REQ-4306 | aceptado (2026-06-13) | «Cliente entrevistado»; **sin doliente** |
| REQ-4309 | aceptado (2026-08-17) | **Ninguna** — el acta no dice quién lo pidió |
| REQ-4310 | aceptado (2026-04-11) | «Cliente entrevistado» |
| REQ-4312 | aceptado (2026-08-29) | «Cliente entrevistado» |
| REQ-4313 | aceptado (2026-04-25) | «Cliente entrevistado» |
| REQ-4314 | aceptado (2026-07-02) | «Cliente entrevistado» |
| REQ-2030 | aceptado (2026-10-08) | «Cliente entrevistado» |

Los 12 se llaman «Requerimiento REQ-xxxx» y tienen el mismo criterio de aceptación («se verifica en producción»): el documento no dice qué se construye. «Cliente entrevistado» remite a una sola entrevista (2025-10-09).

## Las cifras
| Cifra | Valor | Clase | De dónde sale | De cuándo |
|---|---|---|---|---|
| volumen_mensual | 149.630 | **Declarada** | Caso de negocio (Javier Hoyos) | 2026-07-16 |
| Retorno esperado | «en 24 meses», sin cifra | **Declarada, sin valor** | Caso de negocio | 2026-07-16 |
| Que el segmento paga por esto | (sin cifra) | **Supuesta** | Definición, declarado el 2026-07-18, sin verificar | 2026-07-18 |

No hay ninguna cifra medida. No se calculó ni se estimó nada.

### Donde la cifra declarada y la medida no coinciden
Nada que contrastar: no existe serie medida de `volumen_mensual` (ni de ninguna otra métrica). El 149.630 no tiene con qué compararse, y nadie está midiendo lo que el caso afirmó. Quién lo produce: el sistema donde vivirá el producto, o el equipo de datos.

## Los costos
| Concepto | Valor | De dónde sale |
|---|---|---|
| Costo de construir | **Sin fuente** | Ningún documento (ver Vacíos) |
| Costo del equipo | **Sin fuente** | Ningún documento |
| Contratos o cotizaciones | **Sin fuente** | Ningún documento |

## Supuestos sobre los que se sostiene
| Supuesto | Qué pasa si resulta falso | Quién lo verificaría |
|---|---|---|
| «El segmento paga por esto» (declarado 2026-07-18; 90 días sin verificar, umbral 30) | Caen el volumen de 149.630 y el retorno a 24 meses: ambos dependen de que alguien pague. | Sin nombre. Haría falta un dato de pago: precio probado, preinscripción, piloto cobrado o encuesta de disposición a pagar con precio. Hoy no hay ninguno. |
| Implícito: que «Personas» y «pyme» son el mismo segmento | La demanda entrevistada y el volumen no corresponderían al producto. | Sin nombre; quien definió el segmento. |

El texto del primer supuesto no trae precio ni cantidad. Sugiero reescribirlo con una cifra para que se pueda desmentir.

## Vacíos
| Qué falta | Por qué importa | Quién lo produce |
|---|---|---|
| **Costo de construir** | Sin él no hay caso que evaluar. | Sin nombrar: finanzas o el gerente de producto |
| Valor del retorno esperado | «Retorno en 24 meses» sin cifra no se puede defender ante el comité. | El negocio (Javier Hoyos) |
| Serie medida de `volumen_mensual` | El 149.630 no tiene fuente medida. | Sistema donde vive el producto / datos |
| Origen del 149.630 | El caso lo declara sin decir cómo se calculó. | Javier Hoyos |
| Criterio de éxito | Sin él el producto no se puede cerrar meses después. | Quien decide (sin nombre) |
| Quién decide | El acta solo lista a Javier Hoyos; «Comité de producto» es un órgano, no una persona. | La organización |
| Qué pasa si no se hace | No está en ningún documento. | El negocio |
| Alternativas consideradas | No están en ningún documento. | El negocio |
| País y obligaciones normativas | Una cuenta pyme es un producto financiero y probablemente toca datos personales, consumidor financiero y conocimiento del cliente; sin país no puedo precisarlo ni tengo la norma a la vista. Va a revisión jurídica, no la reemplaza. | Jurídico |
| Quién pidió REQ-4305 y REQ-4309; doliente de REQ-4306 | Aceptados sin evidencia o sin doliente. | Javier Hoyos / comité |

## Cómo se sabrá si funcionó
**No está declarado.** No hay criterio de éxito en ningún documento, ni métrica ni fecha de corte. El único candidato es `volumen_mensual`, que no se mide. Hasta que exista, el producto no se puede cerrar meses después.

## Si hay otros productos publicados
Ninguno publicado (la carpeta `estado/` está vacía). Busqué «149.630» en las carpetas de documentos de PRD-299 a PRD-309 y ningún otro caso de negocio lo afirma. Esto no sustituye el cruce de `/product-overlap` cuando haya fichas publicadas.

---
**Después:** el supuesto «El segmento paga por esto» lleva 90 días sin verificar. Puedo pasarlo a seguimiento con assumption-tracking, con doliente. No ofrezco `/product-charter`: el caso no tiene costo ni criterio de éxito.
