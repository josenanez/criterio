# Corrida del 2026-10-16 · product-setup

PRD-303 · 17 requerimientos · 36 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 14 |
| `requirement_untraced` | 12 |
| `requirement_undecided` | 5 |
| `requirement_accepted_without_evidence` | 2 |
| `requirement_without_owner` | 2 |
| `assumption_unverified` | 1 |

> El tiempo no se midió: faltó `corrida-inicio` al arrancar.

Prueba sin interfaz: 4 preguntas con lo sugerido; términos con el sí de José Francisco Ñáñez; 17 requerimientos y la definición levantados; sin serie medida, sin criterio de éxito, 0 de 12 aceptados con proyecto, evidencia única de 2025-10-09

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

Soy Alba. Trabajo antes de que haya proyecto: miro qué sostiene tu definición y qué se sostiene solo.

**Lo que vi:** 4 documentos: 1 de descubrimiento (entrevistas del 2025-10-09), 1 caso de negocio y 1 definición (ambos del 2026-07-16) y 1 acta del comité de producto (2026-10-15, lo más reciente). No hay formatos que no pueda leer. No hay tickets, encuestas ni serie de métricas.

Sin interfaz: tomé las respuestas sugeridas. Producto: PRD-303 · Cuenta PyME · gerente Javier Hoyos. Quién decide: «Comité de producto» (ningún documento nombra a una persona que decida). Estado en `estado-producto/PRD-303`.

## Listo — Cuenta PyME

**Lo que miré:** 4 documentos · 1 de descubrimiento · la definición del 2026-07-16
**Términos:** aceptados para la versión 0.3.11 (términos 1.1) por José Francisco Ñáñez, 2026-10-16 · comprobante en `.criterio/terminos/aceptacion-criterio-product-0.3.11-2026-10-16.md` y `.pdf` · SHA-256 f969d4f658630df3… (md) / 064270343bd7a374… (pdf)

### Lo que tu definición afirma, y qué lo sostiene
| Afirmación | Sostenida por | De cuándo |
|---|---|---|
| «El segmento Personas no tiene cuenta pyme» (problema) | Una entrevista: «Lo necesito y hoy no lo tengo.» No dice a cuántos se entrevistó | 2025-10-09 (12 meses, ya vencida) |
| «El segmento paga por esto» | Un supuesto declarado, sin verificar (90 días) | 2026-07-18 |
| volumen_mensual = 149.630 | Solo el propio caso de negocio; ninguna serie medida | 2026-07-16 |
| 12 requerimientos aceptados | 10 de 12 citan «Cliente entrevistado» (83,3 %); la entrevista es una sola y de hace 12 meses | 2025-10-09 |

### Lo que no está dicho en ninguna parte
- **Criterio de éxito:** no existe en ningún documento.
- **Quién decide:** el acta lista solo a Javier Hoyos como asistente y cierra con «Se mantiene el plan»; no hay una decisión por requerimiento ni nombre de quien la toma.
- **Proyecto que construye algo:** 0 de 12 aceptados tienen proyecto (0,0 %); la definición dice «Ninguno declarado».
- **Retorno esperado:** «en 24 meses», sin cifra.
- **La propuesta:** «Propuesta principal», sin contenido.
- **Qué es cada requerimiento:** los 17 se llaman «Requerimiento REQ-xxxx»; ningún documento dice qué piden. El criterio de aceptación es el mismo en todos («se verifica en producción»).
- **Quién pidió REQ-4305 y REQ-4309:** aceptados sin evidencia. REQ-4300 no tiene criterio de aceptación ni quién lo pidió.
- **Doliente de REQ-4306 y REQ-4311:** «sin asignar».
- **La serie del volumen mensual:** nadie está midiendo lo que el caso de negocio afirmó; no hay con qué contrastar 149.630.
- **Segmento:** el problema habla de una cuenta pyme y el segmento es «Personas»; ningún documento lo explica.

### Supuestos sobre los que está escrita
Uno declarado: «El segmento paga por esto» (2026-07-18), sin verificar hace 90 días. Es el que sostiene el retorno y el volumen, y nada lo verifica.

### Qué le falta a tu carpeta
- Las transcripciones de las entrevistas y cuántas hubo; hoy hay una cita, de hace 12 meses.
- La serie de volumen_mensual con su fuente.
- El acta con una decisión por requerimiento y quién la toma; sin eso un requerimiento descartado se ve igual que uno que nadie miró.

### Señales que cruzaron umbral (cifras del cálculo)
evidencia vencida 14 · sin proyecto 12 · propuestos sin decidir 5 (124 a 213 días; el más viejo REQ-4308) · aceptados sin evidencia 2 · sin doliente 2 · supuesto sin verificar 1.

**Siguiente:** `/product-discovery` sobre las entrevistas.
