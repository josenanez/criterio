No publiqué la ficha de PRD-303 (Cuenta PyME): la configuración no define una carpeta de productos publicados y esa carpeta tampoco existe en el espacio. Sin un sitio común acordado no hay dónde escribir `PRD-303.json`, y acordarlo es una conversación de la organización, no un comando. No la inventé ni la creé.

**Lo que habría llevado (corte al 2026-10-16):** 17 requerimientos (12 aceptados, 5 propuestos) · 0 proyectos · 1 métrica afirmada
**Segmento declarado:** Segmento Personas
**Métrica:** volumen_mensual = 149630, del caso de negocio `documentos/productos/PRD-303/00-definicion/2026-07-16-caso-de-negocio.md` (2026-07-16)

Para publicar: acordar la carpeta común (p. ej. `productos/publicados/`) y registrarla en la configuración; luego se vuelve a correr.
