# Corrida del 2026-10-16 · product-trace

PRD-303 · 17 requerimientos · 50 s · 36 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 14 |
| `requirement_untraced` | 12 |
| `requirement_undecided` | 5 |
| `requirement_accepted_without_evidence` | 2 |
| `requirement_without_owner` | 2 |
| `assumption_unverified` | 1 |

12 requerimientos decididos el 2026-10-15 y ninguno tiene proyecto; PRY-207 declara cuenta PyME y ningún REQ lo nombra

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

## Trazabilidad — Cuenta PyME (PRD-303) · al 2026-10-16
12 decididos · 0 con proyecto · 0 confirmados contra la ficha · 0 entregados

Fichas a la vista: las 13 del portafolio (`estado/records`, PRY-199 a PRY-211). Ninguna traza se confirma, porque ningún requerimiento nombra un proyecto.

### Decidido y nadie lo está construyendo
Los 12 aceptados en el comité del 2026-10-15 (`documentos/productos/PRD-303/30-decisiones/2026-10-15-comite-producto.docx`). El acta cierra con «Se mantiene el plan», y en ninguno consta quién decidió (`decision.who` no encontrado).

| REQ | Responsable | Decidido el | Por quién |
|---|---|---|---|
| REQ-2030 | Liliana Torres | 2026-10-15 | no consta |
| REQ-4301 | Carlos Peña | 2026-10-15 | no consta |
| REQ-4302 | Diana Molina | 2026-10-15 | no consta |
| REQ-4303 | Camilo Beltrán | 2026-10-15 | no consta |
| REQ-4304 | Camilo Beltrán | 2026-10-15 | no consta |
| REQ-4305 | Felipe Arango | 2026-10-15 | no consta |
| REQ-4306 | sin responsable | 2026-10-15 | no consta |
| REQ-4309 | Ricardo Salas | 2026-10-15 | no consta |
| REQ-4310 | Natalia Ospina | 2026-10-15 | no consta |
| REQ-4312 | Paula Céspedes | 2026-10-15 | no consta |
| REQ-4313 | María Restrepo | 2026-10-15 | no consta |
| REQ-4314 | Sandra Gil | 2026-10-15 | no consta |

Los títulos son genéricos («Requerimiento REQ-xxxx»): el acta no los da.

Otros dos datos de estos 12:
- REQ-4305 y REQ-4309 se aceptaron sin evidencia de demanda.
- La evidencia de los otros 10 es de 2025-10-09, con 12 meses de antigüedad.

Quedan 5 en `propuesto` (REQ-4300, 4307, 4308, 4311, 4315), de 124 a 213 días sin decisión. No cuentan como decididos y no entran en esta brecha.

### La traza no se confirma
No aplica: ningún requerimiento dice que lo ejecute un proyecto, así que no hay traza que contrastar con una ficha.

### Lo que un proyecto construye y el registro no tiene
| Proyecto | Su ficha dice que ejecuta este producto | Ningún REQ lo nombra |
|---|---|---|
| PRY-207 Onboarding PyME | Producto: «cuenta PyME» (`PRY-207-onboarding-pyme/00-gobierno/2025-06-27-acta-constitucion.docx`, 2025-06-27) | Sí, ninguno de los 17 lo nombra |

Es probablemente donde se está construyendo lo decidido. La ficha lo nombra por el texto «cuenta PyME», no por el código PRD-303. Alguien tiene que ir a ver si es el mismo producto y a qué REQ corresponde cada entregable. Esta corrida no lo asume.

Las demás fichas declaran otro producto (PRY-199 → PRD-299, PRY-200, 201, 203, 204, 206, 209, 211) o ninguno (PRY-202, 205, 208, 210). No hay nada más que reportar sobre PRD-303.

### La cadena completa
| REQ | Estado | Decisión | Proyecto | Confirmado | Entregables |
|---|---|---|---|---|---|
| 12 aceptados (lista arriba) | aceptado | comité 2026-10-15 | — | no | — |
| 5 propuestos | propuesto | sin decisión | — | no | — |

Cadena rota en el eslabón decisión → proyecto, en los 12.

### Sin fichas a la vista
Se omite: están las 13 fichas.
