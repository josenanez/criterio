# Corrida del 2026-10-16 · product-spec

PRD-303 · 17 requerimientos · 47 s · 36 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 14 |
| `requirement_untraced` | 12 |
| `requirement_undecided` | 5 |
| `requirement_accepted_without_evidence` | 2 |
| `requirement_without_owner` | 2 |
| `assumption_unverified` | 1 |

Borrador desde 17 requerimientos (12 aceptados). No pude redactar comportamiento: títulos genéricos, sin necesidad, criterio único 'se verifica en producción' no medible. Dejé a la vista 11 vacíos con dueño; no hice barrido normativo ni cité normas; 0 de 12 aceptados cubiertos en comportamiento.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

> **Borrador.** Lo escribió el agente desde el registro; lo cierra Javier Hoyos (gerente de producto) y lo aprueba el Comité de producto. Este agente no firma.

# Especificación — Cuenta PyME (PRD-303) · borrador del 2026-10-16

**Aviso por delante:** el registro no permite redactar comportamiento. Los 17 requerimientos tienen como título «Requerimiento REQ-xxxx», ninguno tiene `need` (el problema en palabras de quien lo tiene) y el criterio de aceptación de todos es la misma frase. Escribir qué hace la cuenta sería inventarlo, así que esta especificación deja a la vista lo que falta en vez de rellenarlo.

## Qué problema resuelve
La definición (2026-07-16) dice solo: «El segmento Personas no tiene cuenta pyme.» La propuesta principal está en blanco («Propuesta principal», sin texto). Además hay una inconsistencia que no resuelvo: el segmento declarado es *Personas* y el producto se llama *Cuenta PyME*. Criterio de éxito del producto: no está dicho en ninguna parte.

## Alcance
### Entra
Los 12 requerimientos en estado `aceptado` (acta del comité, 2026-10-15): REQ-2030, 4301, 4302, 4303, 4304, 4305, 4306, 4309, 4310, 4312, 4313, 4314. Entran por su identificador; **ninguno tiene descripción de qué debe hacer**.

### No entra
- Los 5 `propuesto`: REQ-4300, 4307, 4308, 4311, 4315. Nadie los decidió; llevan entre 124 y 213 días propuestos (umbral 60). Los decide el Comité de producto.
- Todo lo que no esté en el registro: el registro no dice qué cuentas, canales, límites ni tipos de cliente PyME incluye. Sigue fuera hasta que alguien lo decida.
- Diseño técnico, estimación, costo y fechas (no son de este documento).

## Comportamiento
**No definido.** Ninguna sección de comportamiento puede citar un requerimiento, porque ninguno dice qué problema concreto resuelve. Lo único que el registro sostiene por requerimiento es: doliente, fecha, estado, y (en 10 de 12) una cita de una sola entrevista del 2025-10-09: «Lo necesito y hoy no lo tengo.»

Casos borde (sin conexión, operación duplicada, abandono antes de confirmar, cierre de cuenta, etc.): **no están definidos en ningún documento.** Dueño: Javier Hoyos.

## Criterios de aceptación
| Criterio | Requerimiento | Cómo se verifica | ¿Se puede medir hoy? |
|---|---|---|---|
| «se verifica en producción» (idéntico en los 12) | REQ-2030, 4301–4306, 4309, 4310, 4312–4314 | No hay forma: no dice qué se observa, ni umbral, ni quién lo observa. Dos personas mirando lo construido no llegan a la misma respuesta | **No.** No es un criterio todavía |

Propuesta de forma, sin completar el contenido: cada criterio necesita *qué se mide, con qué umbral y en qué población* (p. ej. «X en el percentil 95»), y confirmar que la organización ya mide eso. Los umbrales los pone el negocio; no los invento.

## Supuestos sobre los que está escrita
| Supuesto | Verificado | Quién lo verificaría |
|---|---|---|
| «El segmento paga por esto» (declarado 2026-07-18, definición) | No — lleva 90 días sin verificar (umbral 30) | Javier Hoyos |
| «Cliente entrevistado» representa a los dolientes de los 10 requerimientos que lo citan (una sola entrevista, 2025-10-09, 12 meses de antigüedad) | No — no hay segunda fuente | Javier Hoyos |
| Volumen mensual 149 630 del caso de negocio (2026-07-16) | No — sin medición contra la cual contrastarlo | Javier Hoyos / dueño de la cifra en el negocio |

## Vacíos
| Qué falta decidir | Consecuencia de no decidirlo | Quién lo cierra |
|---|---|---|
| Qué hace cada requerimiento (título, necesidad, problema) | No se puede escribir comportamiento ni construir; cualquier texto sería del agente | Cada doliente, consolidado por Javier Hoyos |
| Criterio de aceptación medible para los 12 | «Quedó bien» se discute después de construir | Javier Hoyos con cada doliente |
| REQ-4305 y REQ-4309: aceptados sin una sola cita de quien los pidió | Se construye algo que nadie pidió | Felipe Arango / Ricardo Salas (dolientes); decide el Comité |
| REQ-4306: doliente «sin asignar» (aceptado) | Nadie responde por él | Javier Hoyos asigna una persona |
| Quién decidió la aceptación: el acta del 2026-10-15 no nombra a quien decide y cierra con «Se mantiene el plan» | La decisión no es trazable a una persona | Comité de producto (secretaría del acta) |
| Proyecto que ejecuta los 12 (ninguno vinculado; no hay fichas en esta corrida, así que es «ningún documento lo vincula») | Aceptado sin constructor: `/product-trace` | Javier Hoyos |
| Evidencia vieja (2025-10-09, 12 meses) en 10 de los 12 | La demanda puede haber cambiado | Javier Hoyos |
| Qué necesita de otros equipos (riesgo, cumplimiento, canales, tecnología) | No se ha acordado con ninguno; **no hay ningún documento que lo mencione** | Javier Hoyos |
| Obligaciones normativas: una cuenta para PyME es un producto financiero y probablemente toca datos personales, consumidor financiero y retención de información. **No hice el barrido ni cito norma alguna**; no hay fuente en los documentos | Se podría construir algo que no se puede lanzar | Cumplimiento / Jurídico, solicitado por Javier Hoyos |
| Segmento: «Personas» frente a producto «Cuenta PyME» | Se especifica para un público equivocado | Javier Hoyos |
| Criterio de éxito del producto | No hay cómo saber si el producto funcionó | Comité de producto |

## Requerimientos aceptados que esta especificación no cubre
Ninguna sección de comportamiento cubre ninguno de los 12; solo aparecen en el alcance.

| REQ | Título | Por qué no |
|---|---|---|
| REQ-2030 | Requerimiento REQ-2030 | El registro no dice qué problema resuelve; criterio no medible |
| REQ-4301 | Requerimiento REQ-4301 | Ídem |
| REQ-4302 | Requerimiento REQ-4302 | Ídem |
| REQ-4303 | Requerimiento REQ-4303 | Ídem |
| REQ-4304 | Requerimiento REQ-4304 | Ídem |
| REQ-4305 | Requerimiento REQ-4305 | Ídem, y sin evidencia de quién lo pidió |
| REQ-4306 | Requerimiento REQ-4306 | Ídem, y sin doliente |
| REQ-4309 | Requerimiento REQ-4309 | Ídem, y sin evidencia de quién lo pidió |
| REQ-4310 | Requerimiento REQ-4310 | Ídem |
| REQ-4312 | Requerimiento REQ-4312 | Ídem |
| REQ-4313 | Requerimiento REQ-4313 | Ídem |
| REQ-4314 | Requerimiento REQ-4314 | Ídem |

## Pie
Sale del registro `estado-producto/PRD-303/requirements/` (17 requerimientos: 12 aceptados, 5 propuestos), al 2026-10-16, con la definición (2026-07-16), el caso de negocio (2026-07-16) y el acta del comité (2026-10-15). Cubre 12 requerimientos solo en alcance; en comportamiento, 0. Términos: https://www.josenanez.com/es/agents/criterio-pmo/legal

**Después:** no ofrezco `/product-charter`: los vacíos no están cerrados y los requerimientos no tienen criterio de éxito verificable. Lo útil ahora es `/product-trace` y que cada doliente escriba qué problema es el suyo.
