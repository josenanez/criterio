# Corrida del 2026-10-16 · product-definition

PRD-303 · 17 requerimientos · 30 s · 36 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 14 |
| `requirement_untraced` | 12 |
| `requirement_undecided` | 5 |
| `requirement_accepted_without_evidence` | 2 |
| `requirement_without_owner` | 2 |
| `assumption_unverified` | 1 |

La evidencia sostiene solo el problema, con una entrevista de hace 12 meses; el supuesto de pago lleva 90 días sin verificar, el volumen no tiene serie y no hay criterio de éxito

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

Sesión sin interfaz: tomé las respuestas sugeridas. Términos ya vigentes (versión 0.3.11, términos 1.1), aceptados por José Francisco Ñáñez el 2026-10-16; no hizo falta registrarlos de nuevo.

## Definición — Cuenta PyME (PRD-303) · contrastada al 2026-10-16
**Documento:** `00-definicion/2026-07-16-definicion-producto.docx` y `00-definicion/2026-07-16-caso-de-negocio.md` · **del** 2026-07-16 · 6 afirmaciones (problema, para quién, propuesta, un supuesto, una cifra de volumen, retorno a 24 meses)

### Lo que la evidencia contradice
Nada. Ningún documento dice lo contrario de la definición. Esto no quiere decir que esté sostenida: casi todo cae en las secciones de abajo.

### El negocio y los datos
Ninguna métrica pasa el umbral (20 %), porque no hay nada medido con qué comparar. Ver la sección siguiente.

### Afirmaciones numéricas que nadie mide
| Afirma | De qué documento | No hay serie |
|---|---|---|
| volumen_mensual = 149.630 | Caso de negocio, 2026-07-16 | No hay ninguna serie medida, así que `claim_vs_metric` no tiene punto con qué contrastar. Nadie está midiendo lo que el caso de negocio afirmó. |

### No está dicho en ninguna parte
- **Criterio de éxito:** no existe en ningún documento (el cálculo lo trae en `unknown`).
- **Quién decide:** la autoridad es «Comité de producto», pero el acta lista solo a Javier Hoyos como asistente y cierra con «Se mantiene el plan». Ningún documento nombra a una persona que decida.
- **La propuesta:** dice «Propuesta principal» y no tiene contenido.
- **Retorno esperado:** «en 24 meses», sin cifra.
- **Proyecto que lo construye:** la definición dice «Ninguno declarado». Ninguno de los 12 requerimientos aceptados tiene proyecto (0,0 %).
- **Segmento:** el problema habla de una cuenta pyme y el segmento es «Personas». Ningún documento explica esa diferencia.
- **Cuántos clientes se entrevistaron:** el documento de entrevistas trae una sola cita y no dice cuántos hubo.
- **Qué pide cada requerimiento:** los 17 se llaman «Requerimiento REQ-xxxx». El criterio de aceptación es el mismo en todos («se verifica en producción»).
- **Quién pidió REQ-4300, REQ-4305 y REQ-4309:** el acta no lo dice. REQ-4305 y REQ-4309 están aceptados sin evidencia. REQ-4300 no tiene criterio de aceptación.
- **Doliente de REQ-4306 y REQ-4311:** «sin asignar».

### Sostenida por un supuesto
| Supuesto | Días sin verificar | Qué haría falta para verificarlo |
|---|---|---|
| «El segmento paga por esto» (declarado el 2026-07-18) | 90 (el umbral es 30) | Un dato de pago: alguien del segmento que haya pagado por una cuenta así (precio probado, preinscripción o un piloto cobrado), o una encuesta de disposición a pagar con precio. Hoy no hay ninguno. Es el supuesto que sostiene el retorno y el volumen. |

Otro punto: el texto del supuesto no dice a cuánto pagaría ni por qué. Un supuesto sin precio ni cantidad se puede desmentir con dificultad. Sugiero reescribirlo con una cifra.

### Sostenida por evidencia
| Afirmación | Sostenida por | De cuándo | Qué tan fuerte |
|---|---|---|---|
| «El segmento Personas no tiene cuenta pyme» (problema) | Una entrevista a un cliente: «Lo necesito y hoy no lo tengo.» (`10-descubrimiento/2025-10-09-entrevistas.docx`) | 2025-10-09 | Débil: es lo que alguien dijo, un solo caso, y no dice si es del segmento ni si pagaría. En la jerarquía de demand-evidence está por debajo de cualquier pago o compromiso. |

### Evidencia que ya envejeció
| Afirmación | Lo más nuevo que la sostiene | Hace |
|---|---|---|
| El problema, y 10 de los 12 requerimientos aceptados que citan «Cliente entrevistado» | La entrevista del 2025-10-09 | 12 meses (umbral: 12). 14 requerimientos con evidencia vencida en total. |

### Lo normativo que toca
| Qué toca | País | Obligación | Norma | Estado |
|---|---|---|---|---|
| Una cuenta para pymes es un producto financiero: probablemente toca protección de datos personales, consumidor financiero y conocimiento del cliente / prevención de lavado | No declarado en ningún documento | No la puedo precisar sin el país | — | **No tengo la norma a la vista.** Esto no dice si cumple. Va a revisión jurídica, no la reemplaza. |

### Lo que falta para cerrar la definición
- **Criterio de éxito:** falta. Sin él, el producto no se puede cerrar, porque el cierre se juzga contra él meses después.
- **Quién decide:** falta un nombre.
- **Problema y para quién:** están escritos, pero el segmento («Personas») no coincide con el problema (cuenta pyme).
- **Lo demás por completar:** la propuesta, la cifra del retorno y la serie de volumen_mensual.

### Señales del cálculo
evidencia vencida 14 · sin proyecto 12 · propuestos sin decidir 5 (124 a 213 días; el más viejo, REQ-4308) · aceptados sin evidencia 2 · sin doliente 2 · supuesto sin verificar 1.

**Después:** el supuesto lleva 90 días sin verificar, el triple del umbral. Puedo convertirlo en riesgo con doliente (raid-taxonomy). La definición no se puede cerrar, así que no ofrezco `/product-charter`.
