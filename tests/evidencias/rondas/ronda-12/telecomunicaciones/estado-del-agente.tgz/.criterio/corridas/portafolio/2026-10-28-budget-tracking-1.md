# Corrida · 2026-10-28-budget-tracking-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:budget-tracking PRY-210

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-28; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-210

**Inicio:** 2026-10-28T20:55:29 · **Fin:** 2026-10-28T20:56:21 · **Duración:** 52 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `budget-tracking` | 13 | — | 35 | 70 | Presupuesto de PRY-210 en COP: proyección 19.7% sobre el aprobado y ejecución (56.0%) por encima del avance que sustenta el plan. Dijo que no sabe: ninguna cifra salvo el aprobado tiene evidencia (son declaraciones del informe de avance), el ejecutado supera al comprometido sin explicación, y no hay proveedores registrados. |

Por señal (`budget-tracking`): `milestone_met_without_evidence` 20, `vendor_deliverable_late` 10, `commitment_overdue` 9, `progress_vs_plan` 7, `commitment_rescheduled` 7, `variance_time` 5, `declared_vs_evidence` 3, `rebaseline_unauthorized` 3, `commitment_undated` 2, `vendor_accepted_without_evidence` 1, `vendor_invoiced_over_accepted` 1, `vendor_invoiced_without_delivery` 1, `variance_cost` 1

## Lo que el agente mostró

## Presupuesto: PRY-210, Conectividad para colegios públicos, al 2026-10-28

Los términos ya estaban vigentes (v0.12.1, aceptados por José Francisco Ñáñez el 2026-10-28), así que no los volví a registrar. Las cifras salen de la ficha PRY-210 y de `compute`. Todo está en COP, sin conversión de moneda.

| | Monto (COP) | % del aprobado | Fuente | Fecha |
|---|---|---|---|---|
| Aprobado | 3.300.000.000 | 100% | Acta de constitución | 2026-05-14 |
| Comprometido | 1.565.215.894 | 47.4% | Informe de avance (declaración) | 2026-10-28 |
| Ejecutado | 1.847.276.551 | 56.0% | Informe de avance (declaración) | 2026-10-28 |
| Proyección al cierre | 3.951.444.314 | 19.7% por encima del aprobado | Informe de avance (declaración) | 2026-10-28 |

**Disponible real** (aprobado menos comprometido): 1.734.784.106 COP.

- **Contra la línea base:** el presupuesto vigente sigue siendo el del acta (3.300.000.000 COP) y no hay replanificaciones de presupuesto aprobadas. La solicitud de cambio CC-01 (2026-10-27) pide 220.000.000 COP más y +110 días. Está pendiente, sin decisión ni decisor.
- **Ejecución frente a avance:** el 56.0% ejecutado va por delante del avance. El avance declarado es 50%, el plan solo sostiene entre 20% y 40%, y hay 1 hito de 5 cumplido, sin evidencia.

**Alertas**
- La proyección supera el aprobado en 19.7%, sobre el umbral de 10%.
- Lo ejecutado va por encima de lo que respalda el plan.
- El hito "Diseño de red aprobado" figura como cumplido sin evidencia desde hace 71 días.
- La línea base de tiempo se movió 110 días sin autorización.
- El comprometido (47.4%) no llega al umbral de 90%, así que no hay alerta por ese concepto.
- El ejecutado es mayor que el comprometido, lo que normalmente no ocurre. No lo interpreté. Hay que pedirle la explicación a quien firma el informe de avance.

**Sin dato**
- Ninguna cifra salvo el aprobado tiene evidencia: las otras tres son declaraciones del mismo informe de avance.
- La ficha no registra proveedores, así que no hay detalle por proveedor.
- No sé si los 220.000.000 de CC-01 cubren la diferencia entre proyección y aprobado, porque `compute` no la da.

Como la proyección excede el aprobado y CC-01 está pendiente, puedo evaluarla con `/criterio-portfolio:change-control` si quieres.

La corrida quedó registrada como `2026-10-28-budget-tracking-1` (35 segundos). Lo que te mostré está guardado en `estado/corridas/salida-budget-tracking.md`.
