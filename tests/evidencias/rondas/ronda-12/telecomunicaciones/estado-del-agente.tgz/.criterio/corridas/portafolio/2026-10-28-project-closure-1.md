# Corrida · 2026-10-28-project-closure-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-closure PRY-200

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-28; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-200

**Inicio:** 2026-10-28T21:02:45 · **Fin:** 2026-10-28T21:04:06 · **Duración:** 81 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-closure` | 13 | — | 64 | 70 | Cierre de PRY-200 no sustentado: sin declaración de terminado ni evidencia de producción y medición; 4 de 5 hitos cerrados sin evidencia; 0 replanificaciones; RAID abierto sin doliente. No se archivó. Sin dato: definición de componentes, punto 26, acta de recibo de la bolsa de horas de CT-478, presupuesto ejecutado final. |

Por señal (`project-closure`): `milestone_met_without_evidence` 20, `vendor_deliverable_late` 10, `commitment_overdue` 9, `progress_vs_plan` 7, `commitment_rescheduled` 7, `variance_time` 5, `declared_vs_evidence` 3, `rebaseline_unauthorized` 3, `commitment_undated` 2, `vendor_accepted_without_evidence` 1, `vendor_invoiced_over_accepted` 1, `vendor_invoiced_without_delivery` 1, `variance_cost` 1

## Lo que el agente mostró

PRY-200 no se puede cerrar hoy. Ningún documento declara que el proyecto terminó, ni hay evidencia de que esté en producción y medido, que es el criterio de éxito del acta del 2025-06-03. Dejé el acta de cierre como borrador de trabajo, sin archivar el proyecto.

- **Términos:** ya estaban vigentes (v1.3, aceptados por José Francisco Ñáñez el 2026-10-28), así que no los volví a registrar.
- **Avance declarado frente al plan:** el informe del 2026-10-17 dice amarillo y 59%. El cronograma v1 da los 5 hitos por cerrados. Solo "Sitios construidos" tiene evidencia (acta de recibo del 2026-10-16, con línea base 2025-10-04). Los otros cuatro llevan 465, 427, 351 y 313 días vencidos sin evidencia.
- **Fechas y presupuesto:** hay 0 replanificaciones, así que el atraso contra la línea base original sale en 0 días. Ese 0 no significa que no haya atraso: el cierre pactado era el 2025-12-19. La proyección declarada es 3.425.145.140 COP, 3,8 % sobre los 3.300.000.000 aprobados.
- **Abiertos y sin responsable:**
  - Dos riesgos y dos incidencias: la prueba de velocidad en campo que se repite y la reprogramación de los equipos de radio por la aduana.
  - Un compromiso vencido hace 22 días: Carlos Peña, "Entregar el punto 26".
  - Tres entregables de proveedores vencidos y pendientes, en CT-235 y CT-478.
- **Pagos:** CT-478 facturó 531.795.504 COP por dos entregables recibidos. El contrato exige un acta de recibo por entregable y en la carpeta falta la de la bolsa de horas de ingeniería.
- **Lecciones:** entraron solo tres, ancladas a hechos documentados (cronograma nunca replanificado, hitos sin acta, factura sin acta completa). Dejé fuera la aduana y la prueba de velocidad porque no tienen fecha del hecho.
- **Sin dato:** qué son los Componentes 1 a 3 y el "punto 26", quién responde por cada riesgo e incidencia, y el presupuesto ejecutado final. Las cifras financieras vienen del informe de avance, no de un documento contable.

Para cerrarlo hace falta que el Comité de Cambios declare el cierre (por cumplimiento o por decisión), que aparezca la evidencia de los hitos y que cada abierto tenga responsable con nombre.

La corrida quedó registrada como `2026-10-28-project-closure-1` (64 segundos). No se pudo medir cuántos documentos leyó.

Archivos en `estado/corridas/`:
- `salida-project-closure.md`
- `2026-10-28-project-closure-1.md`
