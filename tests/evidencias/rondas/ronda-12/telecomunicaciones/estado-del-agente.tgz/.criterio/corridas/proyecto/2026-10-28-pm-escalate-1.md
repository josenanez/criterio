# Corrida · 2026-10-28-pm-escalate-1

**Agente:** Samuel (proyecto) · **Comando:** `/criterio-project:pm-escalate (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-28; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-28T20:42:29 · **Fin:** 2026-10-28T20:43:44 · **Duración:** 75 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `pm-escalate` | 1 | — | 57 | 20 | Dos puntos: autoridad del gerente no declarada en el acta, y CC-01 (+102 días, 204 MM COP). Los 102 días coinciden con v1 (07-26) a v2 (11-05): ambigüedad de línea base no resuelta. impact devolvió 0 proyectos alcanzados porque no hay dependencias declaradas ni otras fichas; no se estimó el movimiento por proyecto. |

Por señal (`pm-escalate`): `commitment_rescheduled` 7, `commitment_overdue` 6, `milestone_met_without_evidence` 2, `vendor_deliverable_late` 2, `variance_time` 1, `progress_vs_plan` 1, `commitment_undated` 1

## Lo que el agente mostró

Armé el paquete de escalamiento de PRY-211 y la corrida quedó registrada con ese texto como evidencia. El cálculo de impacto no devolvió ningún otro proyecto alcanzado, pero eso no prueba que no haya. Los términos (v1.3) ya estaban vigentes y aceptados por José Francisco Ñáñez el 2026-10-28, así que no los volví a mostrar.

**Punto 1: ¿se declara por escrito qué puede decidir el gerente?** El acta no dice qué decide el gerente, por eso va primero. Recomiendo una adenda al acta con umbrales de qué decide el gerente, qué el patrocinador y qué el comité. Que la firmen el Comité de Inversiones o Ricardo Salas es inferencia mía. Si no se decide, CC-01 llega al comité sin que nadie pueda decir si el gerente podía resolverlo.

**Punto 2: ¿el Comité de Inversiones aprueba CC-01 (ampliación de alcance, +102 días, +204.000.000 COP)?**
- **Qué pasa si no se decide:** el 2026-11-05 vence el cierre del cronograma v2 sin línea base aprobada que lo cubra, seis días antes del comité del 2026-11-11.
- **Hallazgo de las fechas:** la línea base v1 cierra el 2026-07-26 y esa fecha más 102 días da exactamente el 2026-11-05, el cierre del cronograma v2. Puede que CC-01 solo formalice un atraso que ya está en ejecución, o que los 102 días se sumen aparte y el cierre pase al 2027-02-15. No puedo distinguirlo con los documentos.
- **Qué falta:** CC-01 no describe qué alcance se amplía.
- **Recomiendo:** aprobar si llega esa información y la lectura es la primera. En ese caso la proyección declarada más los 204.000.000 COP da 3.241.162.738 COP, dentro de los 3.300.000.000 aprobados. Si no llega antes del 11-11, devolverlo para completar.

**Impacto:**
- **A quién alcanza:** el cálculo devolvió 0 proyectos, sin hitos por los que pase el cambio. En esta carpeta solo hay la ficha de PRY-211 y el acta dice «ninguna dependencia declarada».
- **Días por proyecto:** no los estimo, porque la ficha no tiene holgura por actividad.

Quedaron fuera del paquete el contrato CT-707 y los compromisos reprogramados tres veces o más. Los dejé anotados porque su fecha depende de lo que se decida en los puntos 1 y 2.

El texto completo está en `estado/PRY-211-plataforma-de-internet-de-las-cosas/corridas/salida-pm-escalate.md`. Llevarlo al comité te toca a ti.
