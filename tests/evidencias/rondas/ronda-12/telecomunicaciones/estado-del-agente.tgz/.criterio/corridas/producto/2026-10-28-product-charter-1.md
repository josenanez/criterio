# Corrida · 2026-10-28-product-charter-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-charter REQ-4600

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-28; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** REQ-4600

**Inicio:** 2026-10-28T19:54:57 · **Fin:** 2026-10-28T19:55:42 · **Duración:** 45 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-charter` | 12 | — | 30 | 26 | Borrador de acta para REQ-4600 con 8 vacíos: sin quién decidió, sin evidencia de demanda, criterio de aceptación no verificable, sin autoridad, patrocinador/gerente, presupuesto, criterio de éxito ni barrido normativo. No se creó la ficha porque falta la firma. |

Por señal (`product-charter`): `requirement_untraced` 11, `evidence_stale` 8, `requirement_accepted_without_evidence` 3, `requirement_without_acceptance` 2, `requirement_without_owner` 1, `requirement_undecided` 1

## Lo que el agente mostró

Dejé el borrador del acta de REQ-4600 (producto PRD-306, Televisión IP), pero no creé la ficha del proyecto porque falta la firma.

**Términos:** ya estaban vigentes, versión 1.3, aceptados por José Francisco Ñáñez el 2026-10-28. Solo mostré el texto de `terminos`.

**Verificación previa:** REQ-4600 consta como aceptado, pero le faltan cuatro cosas. Las dejé marcadas como vacíos del acta, sin rellenarlas:
- **Quién decidió:** `decision.who` está vacío. La aceptación es del 2026-07-23 y el acta del comité que la cita es del 2026-10-25.
- **Criterio de aceptación:** solo dice «se verifica en producción», que no es verificable.
- **Evidencia de demanda:** no hay ninguna, y nadie consta como quien lo pidió.
- **Autoridad:** no está declarada.

**Contenido del borrador:**
- **Problema:** «El segmento Grandes empresas no tiene televisión ip», citado de la definición del producto.
- **Alcance:** entra solo REQ-4600. Los otros 11 requerimientos no entran porque el acta se pidió solo para REQ-4600 (REQ-4605 además está propuesto y sin doliente).
- **Supuesto:** «El proveedor cumple el tiempo pactado» está verificado desde el 2026-09-19. Lo dejé como dependencia del proveedor, no como riesgo abierto.
- **Vacíos:** son ocho. A los cuatro de arriba se suman el patrocinador y el gerente del proyecto, el presupuesto y los hitos, el criterio de éxito del producto y el barrido normativo, que no se hizo.

**Qué sigue:** quien firme (patrocinador, aún sin nombrar) cierra los vacíos o los acepta por escrito. Después, el gerente del proyecto instala `criterio-project` y corre `/pm-setup`.

**Archivos:**
- `estado-producto/PRD-306/corridas/salida-product-charter.md` (el acta completa)
- `estado-producto/PRD-306/corridas/2026-10-28-product-charter-1.md` (la corrida registrada: 30 segundos, 12 requerimientos, 26 hallazgos)
