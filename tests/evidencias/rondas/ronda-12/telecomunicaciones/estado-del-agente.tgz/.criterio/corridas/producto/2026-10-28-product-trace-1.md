# Corrida · 2026-10-28-product-trace-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-trace (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-28; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-28T21:11:15 · **Fin:** 2026-10-28T21:11:54 · **Duración:** 38 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-trace` | 12 | — | 24 | 26 | 11 requerimientos decididos y ninguno tiene proyecto; ninguna de las 13 fichas nombra PRD-306 |

Por señal (`product-trace`): `requirement_untraced` 11, `evidence_stale` 8, `requirement_accepted_without_evidence` 3, `requirement_without_acceptance` 2, `requirement_without_owner` 1, `requirement_undecided` 1

## Lo que el agente mostró

## Trazabilidad de Televisión IP (PRD-306), al 2026-10-28

De los 12 requerimientos, 11 están decididos y ninguno tiene proyecto. El otro, REQ-4605, sigue propuesto: lleva 204 días sin decidir y no tiene dueño.

- **Decidido y nadie lo construye:** los 11 aceptados están en esa situación. El más antiguo, REQ-4609, lleva 195 días decidido sin proyecto. El acta del comité no dice quién decidió ninguno.
- **Trazas sin confirmar:** ninguna. Ningún requerimiento nombra un proyecto, así que no había nada que contrastar con una ficha.
- **Proyecto que construye algo que el registro no tiene:** ninguno. Leí las 13 fichas de `estado/records` (PRY-199 a PRY-211) y ninguna nombra PRD-306 ni «Televisión IP».
- **Cadena rota:** se corta entre la decisión y el proyecto, en los 11.

Los términos ya estaban aceptados y vigentes (v1.3, a nombre de José Francisco Ñáñez), así que no los registré de nuevo. Las fichas no venían indicadas; usé `estado/records` por ser el único lugar donde las encontré.

La corrida quedó registrada como `2026-10-28-product-trace-1` (26 hallazgos, 24 segundos). La salida completa está en `estado-producto/PRD-306/corridas/salida-product-trace.md`.

Como hay decididos sin proyecto, queda la opción de `/product-charter` para el requerimiento que ya esté listo para serlo.
