# Corrida · 2026-10-28-project-charter-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-charter PRY-203 revisar

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-28; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-203

**Inicio:** 2026-10-28T21:02:00 · **Fin:** 2026-10-28T21:02:40 · **Duración:** 40 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-charter` | 13 | — | 25 | 70 | Revisión del acta PRY-203 (2025-11-30): faltan autoridad del gerente, supuestos, restricciones, hitos, cadencia y quién mide el éxito; alcance, exclusiones y objetivo son genéricos. No se sabe si el informe (antenas) corresponde al proyecto ni si hay más documentos fuera de la carpeta. |

Por señal (`project-charter`): `milestone_met_without_evidence` 20, `vendor_deliverable_late` 10, `commitment_overdue` 9, `progress_vs_plan` 7, `commitment_rescheduled` 7, `variance_time` 5, `declared_vs_evidence` 3, `rebaseline_unauthorized` 3, `commitment_undated` 2, `vendor_accepted_without_evidence` 1, `vendor_invoiced_over_accepted` 1, `vendor_invoiced_without_delivery` 1, `variance_cost` 1

## Lo que el agente mostró

Terminé la revisión del acta de PRY-203 y dejé la corrida registrada.

**Acta previa:** sí, del 2025-11-30, aprobada por el Comité de Inversiones. Los términos ya estaban vigentes (v1.3, aceptados por José Francisco Ñáñez el 2026-10-28), así que no los registré de nuevo.

**Lo que falta y su consecuencia:**
- **Autoridad del gerente:** no existe. Mauricio Pérez no tiene declarado hasta qué monto decide sin comité. La proyección al cierre es 1.235.285.263 COP contra 1.200.000.000 aprobados (+2,9%), y no hay forma de saber si él puede absorber ese desvío.
- **Supuestos, restricciones, hitos, cadencia del comité y quién mide el éxito:** no existen. Con 59% de avance a 30 días del cierre, no hay hitos contra los cuales verificarlo.
- **Objetivo, alcance y exclusiones:** están, pero son genéricos. El objetivo repite la solución. El alcance dice "Componente 1, 2, 3" y las exclusiones "lo que otro proyecto cubre". Esos campos parecen cerrados y no lo están.
- **Dependencias:** el acta dice "Ninguna declarada", pero el informe de avance cita permisos municipales, que son una dependencia externa.
- **Patrocinador:** Javier Hoyos, con nombre. Cumple.

**Cosas que el acta y el informe no concilian:**
- Mercadeo figura como área dueña de una migración del core de voz.
- El informe habla de antenas, que no corresponden a una migración a la nube. Puede ser texto de otro proyecto.
- El informe reporta ejecutado (484.949.082) mayor que comprometido (467.181.006), lo que no debería pasar.

No sé si existe algún otro documento de PRY-203 fuera de la carpeta, que solo tiene el acta y el informe.

**Siguiente paso:** como el acta quedó sin autoridad declarada, ofrezco llevar esa definición al Comité de Inversiones del 2026-11-04. Los dos riesgos del informe se pueden pasar al registro RAID, pero no lo hice porque nadie lo pidió.

Archivos en `/home/claude/r12/telecomunicaciones/espacio/estado/corridas/`:
- `salida-project-charter.md`
- `2026-10-28-project-charter-1.md`

La corrida tardó 25 segundos. Su resumen cuenta 70 hallazgos del portafolio completo, ninguno asignado a PRY-203. Esas cifras salen de las señales ya abiertas en el estado, no de esta revisión.
