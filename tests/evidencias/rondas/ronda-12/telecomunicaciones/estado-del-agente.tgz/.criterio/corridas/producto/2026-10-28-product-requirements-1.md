# Corrida · 2026-10-28-product-requirements-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-requirements (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-28; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-28T19:51:13 · **Fin:** 2026-10-28T19:51:51 · **Duración:** 37 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-requirements` | 12 | — | 20 | 26 | Sin sustento: REQ-4600, 4602 y 4609 sin evidencia; 8 con evidencia de hace 13 meses; REQ-4605 sin doliente ni decisión hace 204 días; ninguno trazado a proyecto (sin fichas) |

Por señal (`product-requirements`): `requirement_untraced` 11, `evidence_stale` 8, `requirement_accepted_without_evidence` 3, `requirement_without_acceptance` 2, `requirement_without_owner` 1, `requirement_undecided` 1

## Lo que el agente mostró

## Registro — Televisión IP (PRD-306) · al 2026-10-28

Hay 12 requerimientos y 11 están decididos. El 72.7% de lo decidido tiene evidencia y ninguno tiene un proyecto trazado. No me pasaron fichas de proyecto, así que ese 0% quiere decir que ninguno está trazado, no que no exista un proyecto. Para saberlo hay que correr `/criterio-product:product-trace` con las fichas.

Los términos ya estaban vigentes, aceptados por José Francisco Ñáñez el 2026-10-28, así que no los registré otra vez.

- **Se va a construir y nadie lo pidió:** REQ-4600 (Beatriz Cuéllar), REQ-4602 (Laura Vélez) y REQ-4609 (Diana Molina). Están aceptados y no tienen ninguna cita de quien los pidió.
- **Decidido y nadie lo construye:** los 11 aceptados (REQ-4600 a 4604 y REQ-4606 a 4611) no tienen proyecto trazado. Esto depende de las fichas que faltan.
- **Sin doliente:** REQ-4605.
- **Sin criterio de aceptación:** REQ-4603 y REQ-4608, ambos aceptados.
- **Decidido sin quién decidió:** los 11 aceptados citan el acta del comité del 2026-10-25, pero ninguno dice quién decidió. Además, sus fechas de decisión (de abril a agosto) son anteriores al acta. Esto lo leí yo en el registro, no sale del cálculo.
- **Lleva meses y nadie lo decide:** REQ-4605 lleva 204 días propuesto (el umbral es 60). La configuración no define `authority`, así que no se sabe quién tiene la facultad. Sugiero que Gustavo Neira, gerente del producto, lo declare o lo lleve al comité mensual.
- **Evidencia vieja:** ocho requerimientos (REQ-4601, 4603, 4604, 4606, 4607, 4608, 4610 y 4611) se apoyan solo en la entrevista del 2025-09-25, de hace 13 meses (el umbral es 12). Esa entrevista trata «Necesidad principal» y no nombra ninguno de ellos.

Por estado: 1 propuesto y 11 aceptados. No hay requerimientos en construcción, entregados ni descartados. Tampoco están definidos el criterio de éxito del producto ni la autoridad que decide.

Después: ofrezco `/criterio-product:product-trace` para lo decidido que nadie construye. `/criterio-product:product-charter` no aplica todavía, porque ningún aceptado tiene evidencia vigente, criterio y doliente a la vez.

La corrida quedó registrada como `2026-10-28-product-requirements-1`, con 26 hallazgos y 20 segundos. La salida completa está en `estado-producto/PRD-306/corridas/salida-product-requirements.md`.
