# Corrida · 2026-10-28-change-control-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:change-control PRY-200 mover la salida a producción 30 días

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-28; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-200

**Inicio:** 2026-10-28T20:57:30 · **Fin:** 2026-10-28T20:58:30 · **Duración:** 60 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `change-control` | 13 | — | 44 | 70 | Solicitud de mover 30 días la salida a producción de PRY-200. Sin línea base nueva: no hay solicitante, motivo, autoridad declarada ni aprobación, y la fecha de cierre (2025-12-19) y la nueva (2026-01-18) ya vencieron. Impacto en portafolio 0 por dependencias no declaradas, no por ausencia probada. No sabe: quién pide, costo del mes extra, autoridad, evidencia de 4 de 5 hitos. |

Por señal (`change-control`): `milestone_met_without_evidence` 20, `vendor_deliverable_late` 10, `commitment_overdue` 9, `progress_vs_plan` 7, `commitment_rescheduled` 7, `variance_time` 5, `declared_vs_evidence` 3, `rebaseline_unauthorized` 3, `commitment_undated` 2, `vendor_accepted_without_evidence` 1, `vendor_invoiced_over_accepted` 1, `vendor_invoiced_without_delivery` 1, `variance_cost` 1

## Lo que el agente mostró

La solicitud de cambio de PRY-200 está lista, pero no registré una línea base nueva: no hay quien la apruebe, ni motivo, ni una fecha real a la cual moverla. Los términos v1.3 ya estaban vigentes (aceptados por José Francisco Ñáñez el 2026-10-28), así que no los registré de nuevo.

- **Fecha:** la salida a producción estaba para 2025-12-19, hace 313 días. Sumarle 30 días da 2026-01-18, que también ya pasó (hace 283 días). Mover «30 días» sobre una fecha vencida no describe el plan real. Hace falta que quien pide el cambio diga a qué fecha real se mueve.
- **Alcance y costo:** la solicitud no declara impacto en ninguno de los dos, así que quien lo absorbe es el presupuesto o las horas no pagadas. El presupuesto ya está superado: la proyección declarada es 3.425.145.140 COP contra 3.300.000.000 aprobados (+125.145.140, 3,8 %).
- **Portafolio:** el cálculo da 0 proyectos alcanzados. Eso solo significa que el acta declara «Ninguna dependencia declarada»; no prueba que no haya efecto.
- **Quién decide:** la autoridad no está declarada en el acta, que solo nombra un Comité de Cambios. El paquete va a comité por defecto; el próximo está en la configuración para 2026-11-04.
- **Hitos:** la ficha declara los 5 hitos como cumplidos y 4 no tienen evidencia. El informe de avance dice 59 % y amarillo, lo que se contradice con esos hitos. Con una sola línea base y ningún cambio registrado, el atraso contra la original sale 0 días.
- **No se sabe:** quién pide el cambio y por qué, el costo del mes adicional y quién tiene autoridad para aprobarlo.

Dejé la solicitud completa en `/home/claude/r12/telecomunicaciones/espacio/estado/corridas/salida-change-control.md`. La corrida quedó registrada con el id `2026-10-28-change-control-1`. Lo siguiente sería llevar el paquete al comité del 2026-11-04 con solicitante, motivo, fecha real y costo, y registrar la línea base nueva solo si lo aprueba.
