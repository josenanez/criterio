# Corrida · 2026-10-28-status-report-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:status-report PRY-201

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-28; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-201

**Inicio:** 2026-10-28T20:52:52 · **Fin:** 2026-10-28T20:53:39 · **Duración:** 46 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `status-report` | 13 | — | 30 | 70 | Informe de PRY-201: verde declarado el 2026-10-17 contradicho por 3 señales (4 hitos cumplidos sin evidencia, avance 51 % frente a 100 % del plan, 3 entregables del proveedor vencidos). Dije que no sé la autoridad, la fase, lo facturado ni los responsables de RAID. |

Por señal (`status-report`): `milestone_met_without_evidence` 20, `vendor_deliverable_late` 10, `commitment_overdue` 9, `progress_vs_plan` 7, `commitment_rescheduled` 7, `variance_time` 5, `declared_vs_evidence` 3, `rebaseline_unauthorized` 3, `commitment_undated` 2, `vendor_accepted_without_evidence` 1, `vendor_invoiced_over_accepted` 1, `vendor_invoiced_without_delivery` 1, `variance_cost` 1

## Lo que el agente mostró

**PRY-201 (Fibra hasta el hogar fase 3): el verde que declara el gerente no tiene sustento en los documentos.**

El estado sale de la ficha del 2026-10-28, con las cifras recalculadas por `compute`. Los términos v1.3 ya estaban vigentes (aceptados por José Francisco Ñáñez el 2026-10-28), así que no registré nada nuevo.

- **Lo que declara Javier Hoyos:** verde y 51 % de avance, en el informe del 2026-10-17.
- **Lo que no explica el verde:**
  - Cuatro de los cinco hitos figuran como cumplidos sin evidencia, con entre 56 y 352 días de vencidos.
  - El plan respalda 100 % de avance y el gerente declara 51 %, una diferencia de 49 puntos.
  - Los tres entregables del proveedor CT-801 están sin aceptar y vencidos hace entre 121 y 324 días.
- **Contra el plan:**
  - La fecha de cierre era el 2026-09-02, hace 56 días, y no hay replanificaciones.
  - La desviación sale en 0 días solo porque nadie movió la línea base.
  - La proyección de costo declarada supera el presupuesto de COP 6.800.000.000 en 2,7 %.
- **Abierto:** hay 2 riesgos y 1 incidencia, sin responsable ni fecha de apertura, así que no se pueden calcular sus días sin movimiento. Hay un compromiso abierto, de Beatriz Cuéllar, para el 2026-10-31, y ninguno vencido.
- **No lo sé:** la autoridad de decisión, la fase, lo facturado al proveedor y los responsables de los riesgos. Trece campos de identidad, plan y presupuesto vienen del acta de hace 14 meses.

Ofrezco preparar el punto de comité del 2026-11-04 y la solicitud de cambio; no los preparé en esta corrida.

La corrida quedó registrada como `2026-10-28-status-report-1`. El informe completo está en `estado/corridas/salida-status-report.md`.
