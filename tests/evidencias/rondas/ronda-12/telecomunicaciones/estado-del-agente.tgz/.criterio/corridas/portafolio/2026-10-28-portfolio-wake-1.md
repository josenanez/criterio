# Corrida · 2026-10-28-portfolio-wake-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-wake (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-28; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-28T21:08:49 · **Fin:** 2026-10-28T21:10:35 · **Duración:** 105 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-wake` | 13 | — | 27 | 70 | Barrido: 92 documentos sin cambios, nada que releer. Peticiones: ninguna. Confirmación: 5 campos preguntados (autoridad en PRY-204, 205, 206, 210; producto en PRY-205), sin respuesta en prueba sin interfaz. No se escribió nada en las fichas. |

Por señal (`portfolio-wake`): `milestone_met_without_evidence` 20, `vendor_deliverable_late` 10, `commitment_overdue` 9, `progress_vs_plan` 7, `commitment_rescheduled` 7, `variance_time` 5, `declared_vs_evidence` 3, `rebaseline_unauthorized` 3, `commitment_undated` 2, `vendor_accepted_without_evidence` 1, `vendor_invoiced_over_accepted` 1, `vendor_invoiced_without_delivery` 1, `variance_cost` 1

## Lo que el agente mostró

El mapa de Rostrum quedó escrito en `.criterio/rostrum/config.json`, con la organización "Telecomunicaciones". Tiene 3 entradas de la familia pmo: Vera (portafolio), Samuel (proyecto PRY-211) y Alba (producto PRD-306). No dejé nada fuera. La revisión final no encontró entradas nuevas ni desaparecidas, y todas tienen su estado.

Los términos 1.3 quedaron aceptados a nombre de José Francisco Ñáñez, con fecha 2026-10-28. El comprobante, en Markdown y PDF, está en `.criterio/terminos/aceptacion-criterio-server-0.12.1-2026-10-28.*`.

Cambié el orden de dos pasos. Los términos se guardan dentro de `rostrum/config.json`, que no existía, así que guardé el mapa antes de consultarlos y aceptarlos. Tomé las respuestas sugeridas: la carpeta de la sesión como carpeta de trabajo y ninguna exclusión. Como la configuración de la PMO no traía el nombre de la organización, usé el de la entrada de portafolio.

Para levantar el portal: `/criterio-server:server-start`.

## Respuesta 2

Rostrum está corriendo en `http://127.0.0.1:8787/`, y solo se llega desde este equipo. Se para con Ctrl-C, o matando el proceso si sigue en segundo plano. El registro del arranque está en `/tmp/claude-0/-home-claude-r12-telecomunicaciones-espacio/692b0e4d-0e89-5e8d-a391-2cabbf233557/scratchpad/rostrum.log`.

**Términos.** Ya estaban vigentes (v1.3, aceptada por José Francisco Ñáñez el 2026-10-28), así que no hubo que mostrarlos ni registrar nada.

**El mapa.** Coincide con el disco: no hay entradas nuevas, desaparecidas ni sin estado. Tiene tres entradas, todas de la familia PMO: Vera (portafolio), Samuel (PRY-211) y Alba (PRD-306). El informe de la PMO ya existía en `reportes/`, con fecha 2026-10-29 02:08 UTC, y el servidor lo sirve tal cual.

**Qué hay y para quién:**

| Ruta | Qué es | Para quién |
|---|---|---|
| `/` | Portada: los tres agentes y el formulario de peticiones | Todos |
| `/pmo`, `/decisiones` | Informe de la PMO y paquete de comité | PMO, comité, patrocinador |
| `/proyectos` | 13 proyectos, de PRY-199 a PRY-211 | PMO y patrocinador |
| `/productos` | 6 productos | PMO y patrocinador |
| `/corridas` | Historia de 33 corridas | Quien audita |
| `/estado.json` | Frescura de cada agente y peticiones abiertas | Un mecanismo, no una persona |

**Lo que se ve por ahora:**
- **Sin fecha de última corrida.** `/estado.json` muestra `ultimo: null` para los tres agentes. Esas entradas aparecerán sin fecha de corrida hasta que cada agente corra.
- **Sin próxima corrida programada.** `proxima_corrida` está en null.
- **Sin peticiones abiertas.** Hay 0.
- **Sin otras familias.** Como el mapa solo tiene la PMO, no hay rutas `/familia/cfo` ni `/familia/clo`. `/vence` y `/caso/<código>` no se probaron.

**Qué enlace pasarle a quién:**
- **Patrocinador:** `/`, para entrar al informe y a los proyectos. El informe es del 2026-10-29 02:08 UTC.
- **Comité:** `/decisiones`, con la misma fecha.
- **Auditoría:** `/corridas`.

Este enlace funciona solo mientras el equipo siga encendido. Para que el patrocinador tenga uno estable hay que pasar a «que quede corriendo» con `--abierto`. Eso exige pedirle a la organización un host y un puerto, y publicarlo detrás de su control de acceso. El servidor no trae autenticación. No necesita base de datos, certificado propio ni salida a internet.

**Lo que no hace.** No calcula, no escribe fichas, no autentica y no manda correos. Las peticiones del formulario quedan en la carpeta `peticiones/` del agente elegido. Cada agente las toma cuando despierte, porque el servidor no puede correrlo.
