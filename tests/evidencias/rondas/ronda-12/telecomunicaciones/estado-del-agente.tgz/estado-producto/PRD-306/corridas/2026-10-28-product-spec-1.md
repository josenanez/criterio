# Corrida del 2026-10-28 · product-spec

PRD-306 · 12 requerimientos · 38 s · 26 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 11 |
| `evidence_stale` | 8 |
| `requirement_accepted_without_evidence` | 3 |
| `requirement_without_acceptance` | 2 |
| `requirement_without_owner` | 1 |
| `requirement_undecided` | 1 |

Borrador sobre 11 aceptados; sin necesidad descrita en ninguno (título=código), criterio único 'se verifica en producción' no verificable, 2 sin criterio. Dijo que no sabe: necesidades, casos borde, dependencias de otros equipos, obligaciones normativas, criterio de éxito.

Contra la corrida del 2026-10-28: +0 hallazgos.

## Lo que produjo

> **Borrador del 2026-10-28, escrito por el agente (Alba). Lo cierra Gustavo Neira, gerente del producto; el agente no aprueba ni firma.**

# Especificación — Televisión IP (PRD-306) · borrador del 2026-10-28

**Lectura rápida:** el registro permite listar qué entra, pero no describir lo que cada requerimiento pide. En los 12 registros el título es el propio código («Requerimiento REQ-46xx») y el campo `need` está vacío en todos. Por eso este borrador no tiene secciones de comportamiento: escribirlas habría sido inventar. Lo que sí entrega es el alcance trazable, los criterios tal como existen, y los vacíos con dueño.

## Alcance

### Entra
Los 11 requerimientos en estado `aceptado` (ninguno está `en_construccion`). Cada uno cita el acta `30-decisiones/2026-10-25-comite-producto.docx`.

| REQ | Doliente | Aceptado desde |
|---|---|---|
| REQ-4600 | Beatriz Cuéllar | 2026-07-23 |
| REQ-4601 | Rubén Cárdenas | 2026-04-24 |
| REQ-4602 | Laura Vélez | 2026-06-09 |
| REQ-4603 | Ricardo Salas | 2026-08-06 |
| REQ-4604 | Mauricio Pérez | 2026-06-26 |
| REQ-4606 | Felipe Arango | 2026-05-23 |
| REQ-4607 | María Restrepo | 2026-05-12 |
| REQ-4608 | Andrés Lozano | 2026-06-15 |
| REQ-4609 | Diana Molina | 2026-04-16 |
| REQ-4610 | Sandra Gil | 2026-05-12 |
| REQ-4611 | Mauricio Pérez | 2026-08-22 |

Contexto del producto (definición del 2026-03-07): el segmento Grandes empresas no tiene televisión IP. La propuesta está escrita solo como «Propuesta principal».

### No entra
- **REQ-4605**: está `propuesto` desde 2026-04-07 (204 días, umbral 60), sin doliente. Nadie lo decidió; especificarlo sería decidirlo.
- Todo comportamiento, canal, funcionalidad o integración que no esté en un requerimiento aceptado. La definición no enumera ninguno.
- Arquitectura, estimación, costo y fechas: no son de este documento.
- El criterio de éxito del producto: no está definido (`success` vacío); no se propone uno.

## Criterios de aceptación

El único criterio que existe en el registro es «se verifica en producción», copiado del acta. **No pasa la prueba de las dos personas**: no dice qué se observa, con qué umbral, ni quién lo mide. No lo reescribí con una cifra porque cualquier cifra sería mía.

| Criterio | Requerimiento | Cómo se verifica | ¿Se puede medir hoy? |
|---|---|---|---|
| «se verifica en producción» | REQ-4600, 4601, 4602, 4604, 4606, 4607, 4609, 4610, 4611 (9) | No definido: falta qué se observa y con qué umbral | No. No hay observable ni umbral; además ningún requerimiento tiene proyecto que lo construya, así que no hay nada en producción contra qué verificar |
| **Sin criterio** | REQ-4603, REQ-4608 | — | No aplica: no hay criterio |

## Supuestos sobre los que está escrita

| Supuesto | Verificado | Quién lo verificaría |
|---|---|---|
| El proveedor cumple el tiempo pactado | Sí, el 2026-09-19, según el anexo `00-definicion/2026-09-19-verificacion-supuesto.md` («se confirmó»). Reservas: el anexo dice haberse apoyado en un «documento técnico del proveedor» que no está en la carpeta; no se dice cuál es el tiempo pactado ni con qué contrato; el supuesto figura declarado el 2026-08-11 en una definición fechada 2026-03-07 | Gustavo Neira, adjuntando el documento del proveedor y el tiempo pactado |
| Los 11 requerimientos siguen vigentes | No verificado. Las fechas de aceptación (2026-04-16 a 2026-08-22) son anteriores al acta que las cita (2026-10-25) | Gustavo Neira |
| La entrevista del 2025-09-25 sostiene a los ocho requerimientos que la citan | No sostenido: la propia entrevista trata «Necesidad principal» y no nombra ningún requerimiento; además tiene 13 meses (umbral 12) | Gustavo Neira, con entrevistas o tickets nuevos y específicos |

## Vacíos

| Qué falta decidir | Consecuencia de no decidirlo | Quién lo cierra |
|---|---|---|
| Qué pide cada requerimiento (`need` vacío y título = código en los 12) | No se puede escribir ninguna sección de comportamiento; quien construya decidirá por su cuenta | Cada doliente (ver tabla de Alcance) |
| Criterio verificable para los 9 con «se verifica en producción» | Dos personas pueden discrepar sobre si está entregado | Cada doliente, con Gustavo Neira |
| Criterio de aceptación de REQ-4603 y REQ-4608 | Aceptados sin forma de saber cuándo están listos | Ricardo Salas (4603); Andrés Lozano (4608) |
| Comportamiento en casos borde | No hay ninguno descrito en ningún documento | Dolientes; sin definir quién lo consolida |
| Quién pidió REQ-4600, 4602 y 4609 (aceptados sin ninguna cita de demanda) | Se construiría algo que nadie pidió | Beatriz Cuéllar, Laura Vélez, Diana Molina |
| Quién decidió la aceptación (`decision.who` vacío en los 11) y quién tiene la autoridad (`authority` sin definir en la configuración) | Aceptaciones sin responsable; REQ-4605 sin quién lo resuelva | Gustavo Neira declara la autoridad |
| Criterio de éxito del producto | No hay contra qué juzgar si la especificación cumple su propósito | Gustavo Neira |
| Qué debe hacer otro equipo | Las dependencias con otros equipos no están en ningún documento; no sé si existen. Sin proyecto trazado en ningún requerimiento, tampoco se sabe quién construye | Gustavo Neira (primero `/criterio-product:product-trace` con las fichas de proyecto) |
| Obligaciones normativas | El barrido no se pudo hacer sobre un contenido que no existe: la definición no dice qué datos, pagos o retención toca el servicio. No concluyo que no haya obligaciones; queda sin resolver | Gustavo Neira, con el área jurídica que corresponda |
| Cifra del caso de negocio: volumen mensual declarado de 100.016, sin fuente más allá del propio caso | Si la especificación se dimensiona con ella, hereda una cifra sin respaldo | Gustavo Neira |

## Requerimientos aceptados que esta especificación no cubre

Ninguno queda fuera por exclusión: los 11 aceptados entran al alcance. **Pero ninguno queda cubierto en contenido**, porque no hay necesidad descrita que especificar. Un lector que cuente «11 cubiertos» entendería mal; la cobertura real es de trazabilidad, no de comportamiento.

| REQ | Título | Por qué no |
|---|---|---|
| (los 11 listados arriba) | Requerimiento REQ-46xx | Sin `need`: se cubren por cita, no por comportamiento |
| REQ-4605 | Requerimiento REQ-4605 | No es aceptado; excluido a propósito (ver «No entra») |

---
**Pie:** sale del registro `estado-producto/PRD-306/requirements/` (12 requerimientos, 11 aceptados), actualizado al 2026-10-28; fuentes: acta del comité 2026-10-25, definición y caso de negocio 2026-03-07, verificación de supuesto 2026-09-19, entrevista 2025-09-25. Cubre 11 requerimientos. Términos aceptados por José Francisco Ñáñez el 2026-10-28 (versión 1.3): https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.12.1

**Después:** no ofrezco `/criterio-product:product-charter`. Los vacíos no están cerrados y el producto no tiene criterio de éxito.
