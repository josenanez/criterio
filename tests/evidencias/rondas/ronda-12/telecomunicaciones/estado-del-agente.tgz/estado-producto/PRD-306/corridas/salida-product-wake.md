## Televisión IP (PRD-306) · 2026-10-28

Términos vigentes (versión 1.3, aceptados por José Francisco Ñáñez el 2026-10-28). Tocaba la revisión mensual; era la primera, así que no hay corte anterior de wake. No había nada en `crossed`.

**Carpeta de documentos:** 5 documentos, ninguno nuevo ni cambiado desde la lectura anterior. No hay nada que releer ni nada nuevo del descubrimiento. Por eso no ofrezco `/product-discovery` ni `/product-definition`.

**Registro recalculado:** 12 requerimientos (11 aceptados, 1 propuesto). Es el mismo estado que dejó `product-setup` hoy, así que no repito los hallazgos como nuevos. Lo que sigue abierto y necesita decisión:

| Qué | REQ | Cuánto lleva | Qué se necesita | Quién |
|---|---|---|---|---|
| Sin decidir | REQ-4605 | 204 días (desde 2026-04-07; umbral 60) | Alguien con facultad de decidirlo. El producto tiene `authority` en blanco y el requerimiento no tiene doliente. | Sin dato: falta nombrar la autoridad |
| Aceptado sin evidencia de demanda | REQ-4600, 4602, 4609 | 97, 141 y 195 días desde que se planteó | Evidencia de que alguien lo pidió, o rebajar el estado | Beatriz Cuéllar, Laura Vélez, Diana Molina |
| Evidencia vencida (13 meses; umbral 12) | REQ-4601, 4603, 4604, 4606, 4607, 4608, 4610, 4611 | La entrevista es del 2025-09-25 | Esa entrevista trata «Necesidad principal» y no nombra ninguno de estos requerimientos, así que sostiene la definición general y no cada uno | Dolientes de cada requerimiento |
| Aceptado sin criterio de aceptación | REQ-4603, 4608 | 83 y 135 días | Criterio verificable | Ricardo Salas, Andrés Lozano |

### Las trazas
Ninguna traza está confirmada (0 de 11 requerimientos aceptados con proyecto). No se dio la carpeta de fichas de proyectos, y sin ella no se da ninguna traza por confirmada. Los 11 aceptados figuran sin construir ni proyecto asociado.

### Lo que no sé
- Éxito de la definición y autoridad de decisión: no están en ningún documento.
- Cifra del caso de negocio (volumen mensual 100.016, del 2026-03-07): sin serie medida con la que contrastarla.
- Seis campos de la definición apuntan a `2026-03-07-definicion-producto.md`, que el índice marca como fuente no resuelta. Hay que revisarlo.

**Vuelvo el 2026-11-27.**
