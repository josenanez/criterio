## Registro — Televisión IP (PRD-306) · al 2026-10-28
12 requerimientos · 11 decididos · 72.7% con evidencia · 0% con proyecto que lo ejecuta

Nota: la corrida no recibió fichas de proyecto (`--fichas`), así que el 0% de "con proyecto" significa "ninguno trazado", no "ninguno existe". Hay que correr `/criterio-product:product-trace` con las fichas para saberlo.

### Se va a construir y nadie lo pidió
| REQ | Título | Estado | Doliente |
|---|---|---|---|
| REQ-4600 | Requerimiento REQ-4600 | aceptado (2026-07-23) | Beatriz Cuéllar |
| REQ-4602 | Requerimiento REQ-4602 | aceptado (2026-06-09) | Laura Vélez |
| REQ-4609 | Requerimiento REQ-4609 | aceptado (2026-04-16) | Diana Molina |

Sin una sola cita de quien lo pidió. Quien cierra cada vacío: su doliente, con una entrevista o ticket que lo respalde; la facultad para dar marcha atrás no está definida (ver abajo).

### Decidido y nadie lo está construyendo
Los 11 aceptados (REQ-4600 a REQ-4604 y REQ-4606 a REQ-4611) no tienen proyecto trazado. Pendiente de confirmar con las fichas (ver nota).

### Sin doliente, o con un área en vez de una persona
| REQ | Título | Dice |
|---|---|---|
| REQ-4605 | Requerimiento REQ-4605 | sin doliente |

### Sin criterio de aceptación
| REQ | Título | Estado |
|---|---|---|
| REQ-4603 | Requerimiento REQ-4603 | aceptado |
| REQ-4608 | Requerimiento REQ-4608 | aceptado |

(REQ-4605 está propuesto: no se le exige.)

### Decidido sin documento que lo respalde
Los 11 aceptados citan el acta `30-decisiones/2026-10-25-comite-producto.docx`, pero en ninguno consta quién decidió (`decision.who` vacío). Además, la fecha de decisión de cada uno (de 2026-04-16 a 2026-08-22) es anterior al acta, que es del 2026-10-25. Es una observación de lectura del registro, no una señal calculada por el script.

### Lleva meses y nadie lo decide
| REQ | Título | Propuesto hace | Quién tiene la facultad |
|---|---|---|---|
| REQ-4605 | Requerimiento REQ-4605 | 204 días (desde 2026-04-07; umbral 60) | No se sabe: `authority` no está definida en la configuración |

El problema de fondo es que nadie sabe a quién le toca. Sugerencia: que Gustavo Neira (gerente del producto) declare quién decide, o lo lleve al comité mensual.

### Evidencia vieja
| REQ | Lo más nuevo que lo sostiene | Hace |
|---|---|---|
| REQ-4601, 4603, 4604, 4606, 4607, 4608, 4610, 4611 | Entrevista del 2025-09-25 | 13 meses (umbral 12) |

Es la misma entrevista para los ocho, y según la propia nota "trata «Necesidad principal» y no nombra este requerimiento".

## Por estado
| propuesto | aceptado | en construcción | entregado | descartado |
|---|---|---|---|---|
| 1 | 11 | 0 | 0 | 0 |

Totales por señal: sin traza 11 · evidencia vieja 8 · aceptado sin evidencia 3 · sin criterio 2 · sin doliente 1 · sin decidir 1.
Sin determinar: criterio de éxito del producto y autoridad que decide.
