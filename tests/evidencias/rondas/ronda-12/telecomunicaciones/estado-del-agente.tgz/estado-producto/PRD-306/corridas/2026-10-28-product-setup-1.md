# Corrida del 2026-10-28 · product-setup

PRD-306 · 12 requerimientos · 31 s · 26 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 11 |
| `evidence_stale` | 8 |
| `requirement_accepted_without_evidence` | 3 |
| `requirement_without_acceptance` | 2 |
| `requirement_without_owner` | 1 |
| `requirement_undecided` | 1 |

0 preguntas respondidas por una persona (sesión sin interfaz, 4 respuestas sugeridas); un solo pase; halló 5 documentos, definición sin criterio de éxito ni serie medida, 11 aceptados sin proyecto, 8 con la misma entrevista de 13 meses

Primera corrida: no hay una anterior contra la cual comparar.

## Lo que produjo

Soy Alba. Trabajo antes de que haya proyecto: miro qué sostiene tu definición y qué se sostiene solo.

*Sesión sin interfaz: tomé la respuesta sugerida en cada pregunta. Carpeta del producto: `documentos/productos/PRD-306` (vino en el argumento; tiene `00-definicion/`, `10-descubrimiento/`, `30-decisiones/`). Quién eres: Gustavo Neira, gerente de Televisión IP (PRD-306), según la definición. Quién decide: ningún documento lo dice, queda sin dato. Estado: `estado-producto/PRD-306`, hermana de la documentación y distinta de `estado/`. Marca de carpeta: sí, `_CRITERIO_PRODUCTO.txt`.*

## Listo — Televisión IP (PRD-306)

**Lo que miré:** 5 documentos · 1 de descubrimiento (una ronda de entrevistas del 2025-09-25) · la definición del 2026-03-07 · lo más reciente, el acta de comité del 2026-10-25 · formatos que no pude leer: ninguno.
**Términos:** aceptados por José Francisco Ñáñez el 2026-10-28 para la versión 0.12.1 (términos 1.3) · comprobante en `.criterio/terminos/aceptacion-criterio-product-0.12.1-2026-10-28.md` y `.pdf` · SHA-256 0436c0ebf441ef53…
**Registro levantado:** la ficha del producto y 12 requerimientos (11 aceptados, 1 propuesto), tal como los nombra el acta del 2026-10-25.

### Lo que tu definición afirma, y qué lo sostiene
| Afirmación | Sostenida por | De cuándo |
|---|---|---|
| «El segmento Grandes empresas no tiene televisión ip» | Una sola entrevista, un cliente sin nombre: «Lo necesito y hoy no lo tengo». No dice de qué segmento es ni si habla por el segmento. Evidencia media, 13 meses de antigüedad | 2025-09-25 |
| «El proveedor cumple el tiempo pactado» (supuesto) | El anexo de verificación dice «se confirmó» y se declara a sí mismo como evidencia, pero no trae el documento técnico del proveedor ni dice cuál es el tiempo pactado | declarado 2026-08-11 · verificado 2026-09-19 |

### Lo que no está dicho en ninguna parte
- **Que quien necesita esto sea Grandes empresas.** La entrevista no nombra al cliente ni su segmento. Es la única demanda escrita, y no dice para quién es.
- **El criterio de éxito.** La definición no lo tiene. El caso de negocio solo dice «Retorno esperado en 24 meses», sin cifra ni forma de medirlo. No hay contra qué cerrar el producto.
- **La propuesta.** La definición dice «Propuesta principal» y nada más.
- **El volumen mensual de 100.016.** El caso de negocio no dice de qué es el volumen (usuarios, contratos, horas) ni de dónde sale la cifra. No hay ninguna serie medida a la vista (no existe `20-metricas/`): nadie está midiendo lo que el negocio afirmó.
- **Quién decide qué se construye.** Ni la definición ni el acta lo dicen. El acta solo lista como asistente a Gustavo Neira, que es también el gerente, y su decisión es «Se mantiene el plan», sin que ningún documento diga cuál plan.
- **Qué pidió cada requerimiento.** Los 12 se llaman «Requerimiento REQ-46xx», sin enunciado. La necesidad de cada uno queda sin dato.
- **Proyectos que los construyan.** La definición dice «Ninguno declarado», y el acta no nombra proyecto para ninguno de los 12.

### Lo que el registro ya muestra
- 11 requerimientos aceptados, 0 con proyecto que los ejecute (0,0 %).
- 8 de los 11 aceptados (72,7 %) tienen evidencia, y es siempre la misma entrevista del 2025-09-25, con 13 meses de antigüedad (`evidence_stale` en 8). Esa entrevista trata «Necesidad principal» y no nombra ninguno de los 8: es una sola cita sosteniendo ocho.
- 3 aceptados sin evidencia de quién los pidió: REQ-4600, REQ-4602, REQ-4609.
- 2 aceptados sin criterio de aceptación: REQ-4603, REQ-4608.
- REQ-4605 está propuesto, sin doliente, desde el 2026-04-07 (204 días sin decidir).

### Supuestos sobre los que está escrita
Uno declarado: «El proveedor cumple el tiempo pactado», declarado el 2026-08-11 y marcado como verificado el 2026-09-19. Nota: la definición está fechada 2026-03-07 pero contiene un supuesto declarado en agosto; el documento se editó después de su fecha y no dice cuándo. No declara ningún otro supuesto, y tampoco dice qué asume sobre el tamaño del segmento.

### Qué le falta a tu carpeta
Como hallazgo, no como requisito:
- Las transcripciones de las entrevistas, con quién habló y de qué empresa. Hoy hay una cita de una línea.
- La serie de la métrica principal con su fuente (`20-metricas/`).
- Un criterio de éxito escrito y quién autoriza qué se construye.
- Los documentos que la decisión «Se mantiene el plan» da por conocidos.
- El documento técnico del proveedor, citado por el anexo y que no está.

**Siguiente paso:** `/product-discovery` sobre las entrevistas, para que los temas queden con la cita de quién los pidió, que es la evidencia de la que cuelga todo lo demás.
