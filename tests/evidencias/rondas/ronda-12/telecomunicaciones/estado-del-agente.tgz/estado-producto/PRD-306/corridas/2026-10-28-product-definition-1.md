# Corrida del 2026-10-28 · product-definition

PRD-306 · 12 requerimientos · 37 s · 26 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 11 |
| `evidence_stale` | 8 |
| `requirement_accepted_without_evidence` | 3 |
| `requirement_without_acceptance` | 2 |
| `requirement_without_owner` | 1 |
| `requirement_undecided` | 1 |

La evidencia no contradice la definición, pero casi nada la sostiene: una sola entrevista de hace 13 meses, ninguna serie mide el volumen declarado, y faltan criterio de éxito y autoridad.

Contra la corrida del 2026-10-28: +0 hallazgos.

## Lo que produjo

## Definición — Televisión IP (PRD-306) · contrastada al 2026-10-28
**Documento:** `00-definicion/2026-03-07-definicion-producto.md` y `00-definicion/2026-03-07-caso-de-negocio.md` · **del** 2026-03-07 (hace 7 meses) · 8 afirmaciones

Nota de la prueba: los términos (v1.3) ya estaban vigentes y aceptados por José Francisco Ñáñez el 2026-10-28; no se volvieron a registrar. Las preguntas se resolvieron con la respuesta sugerida.

### Lo que la evidencia contradice
Nada. Ningún documento de la carpeta dice lo contrario de lo que afirma la definición. Hay una rareza interna, que no es contradicción: la definición es del 2026-03-07, pero su supuesto figura «declarado el 2026-08-11», cinco meses después. O la definición se editó sin cambiar su fecha, o el supuesto se agregó después; el documento no lo aclara.

### El negocio y los datos
| Métrica | Declarado | Medido | Diferencia | Las dos fuentes y fechas |
|---|---|---|---|---|
| (ninguna pasa el umbral de 20 %) | | | | No hay serie medida contra la cual comparar |

### Afirmaciones numéricas que nadie mide
| Afirma | De qué documento | No hay serie |
|---|---|---|
| `volumen_mensual` = 100.016 (la unidad no está dicha: no se sabe volumen de qué) | Caso de negocio, 2026-03-07 | No hay ninguna medición de esta métrica. Nadie está midiendo lo que el caso de negocio afirmó. |
| «Retorno esperado en 24 meses» | Caso de negocio, 2026-03-07 | Ni siquiera trae cifra: es un plazo sin monto ni tasa. No hay qué medir. |

### No está dicho en ninguna parte
- **Criterio de éxito:** no existe. Sin él el producto no se puede cerrar ni juzgar después.
- **Quién decide (autoridad):** no está declarada; es la razón por la que REQ-4605 lleva 204 días propuesto.
- **Qué es la «propuesta»:** la sección solo dice «Propuesta principal», sin contenido.
- **Qué mide `volumen_mensual`** y de dónde sale 100.016.
- **Cuántas grandes empresas tienen el problema** ni qué tamaño tiene el segmento.
- **Cuánto pagaría el cliente** o si alguien ya pagó o se comprometió a pagar. No hay en la carpeta un solo pedido formal, piloto ni compromiso.
- **Que el cliente entrevistado sea del segmento «Grandes empresas».** La entrevista no lo dice.
- **Cuál es el tiempo pactado con el proveedor, quién es el proveedor** y qué pasa si no cumple.
- **Qué proyecto construye el producto:** «Ninguno declarado».
- **Cómo se llegó a «el segmento no tiene televisión IP»:** es la afirmación central y no tiene fuente propia en la definición.

### Sostenida por un supuesto
| Supuesto | Días sin verificar | Qué haría falta para verificarlo |
|---|---|---|
| Ninguno abierto. El único declarado está marcado verificado. | 0 | — |

Observación: el supuesto «El proveedor cumple el tiempo pactado» está verificado el 2026-09-19 por un anexo que dice ser la evidencia misma y remitir a un «documento técnico del proveedor» de esa fecha. Ese documento técnico no está en la carpeta; el anexo solo afirma «se confirmó». Está verificado en el papel, pero quien quiera auditarlo no puede ver la evidencia de fondo. Además, «cumple el tiempo pactado» es una conducta futura: una confirmación a septiembre no garantiza el cumplimiento posterior.

### Sostenida por evidencia
| Afirmación | Sostenida por | De cuándo | Qué tan fuerte |
|---|---|---|---|
| «El segmento no tiene televisión IP» / hay una necesidad | Entrevista a un cliente (sin nombre ni segmento): «Lo necesito y hoy no lo tengo.» (`10-descubrimiento/2025-09-25-entrevistas.docx`) | 2025-09-25 | Débil: un solo cliente que dijo que lo necesita. En la jerarquía, alguien dijo, no alguien pagó. |
| El proveedor cumple el tiempo pactado | Anexo `00-definicion/2026-09-19-verificacion-supuesto.md` | 2026-09-19 | Declarativa: resultado «se confirmó», sin el documento del proveedor a la vista. |

### Evidencia que ya envejeció
| Afirmación | Lo más nuevo que la sostiene | Hace |
|---|---|---|
| Existe la necesidad (toda la demanda de la carpeta) | Entrevista del 2025-09-25 | 13 meses (umbral 12). Es anterior en 5 meses a la definición misma. |

Es la única entrevista de la carpeta. Los 8 requerimientos que citan evidencia citan esta misma entrevista, y su propia nota dice que trata «Necesidad principal» y no nombra ninguno de ellos.

### Lo normativo que toca
| Qué toca | País | Obligación | Norma | Estado |
|---|---|---|---|---|
| Nada en el texto de la definición roza datos personales, pagos, consumidor financiero ni retención de información | No se declara país | — | — | No tengo la norma a la vista. Esto no dice que no haya obligaciones: un servicio de televisión IP para empresas tiene normativa sectorial de telecomunicaciones y de contenidos que la definición no menciona. Va a revisión jurídica, no la reemplaza. |

### Lo que falta para cerrar la definición
- **Criterio de éxito:** falta.
- **Quién decide:** falta (`authority` sin declarar).
- **Problema:** declarado, pero con una sola frase y sin fuente propia.
- **Para quién:** declarado («Grandes empresas»), sin cuantificar ni verificar en la entrevista.

La definición no se puede cerrar hoy: sin criterio de éxito no hay contra qué juzgar el cierre meses después.

### Contexto del registro, sin repetir
12 requerimientos (11 aceptados): 3 aceptados sin evidencia (REQ-4600, 4602, 4609), 8 con evidencia vieja, 11 sin proyecto trazado. Detalle en la corrida de `product-requirements`.
