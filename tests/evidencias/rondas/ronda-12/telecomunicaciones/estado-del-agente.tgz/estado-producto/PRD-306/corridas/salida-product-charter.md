# Acta de constitución — Televisión IP (proyecto sin nombre) · borrador del 2026-10-28
**Producto:** PRD-306 Televisión IP · **Requerimientos:** REQ-4600

**Verificación previa (paso 1).** REQ-4600 está `aceptado`, pero no pasa limpio la verificación. Se sigue sin lo que falta, marcado como vacío del acta (respuesta sugerida tomada en esta prueba sin interfaz):
- **Aceptado:** consta como aceptado desde 2026-07-23, pero `decision.who` está vacío: no se sabe quién decidió. El acta del comité que lo cita es del 2026-10-25, posterior a esa fecha (`30-decisiones/2026-10-25-comite-producto.docx`).
- **Criterio de aceptación:** solo dice «se verifica en producción» (mismo acta). Eso no es verificable: no dice qué se mide ni contra qué.
- **Evidencia de demanda:** ninguna. `evidence` está vacío y la columna «Quién lo pidió» del acta del comité trae «—».
- **Autoridad:** no está declarada (`authority` es nulo en la configuración y en la ficha del producto).

## Qué problema resuelve
«El segmento Grandes empresas no tiene televisión ip.» (`00-definicion/2026-03-07-definicion-producto.md`, 2026-03-07). El requerimiento REQ-4600 no trae su propia necesidad (`need` vacío); su título es solo «Requerimiento REQ-4600».

## Criterio de éxito
| Criterio | Cómo se verifica |
|---|---|
| «se verifica en producción» (comité 2026-10-25) | **Sin determinar.** No hay métrica, umbral ni fecha. El criterio de éxito del producto tampoco está definido (`definition.success` vacío). |

## Alcance
### Entra
| REQ | Título | Evidencia que lo sostiene |
|---|---|---|
| REQ-4600 | Requerimiento REQ-4600 | **Ninguna.** Doliente: Beatriz Cuéllar (comité 2026-10-25). Nadie consta como quien lo pidió. |

### No entra
| REQ | Título | Por qué no |
|---|---|---|
| REQ-4601 a REQ-4604, REQ-4606 a REQ-4611 | Requerimiento REQ-46xx | Aceptados en el registro, pero esta acta se pidió solo para REQ-4600. Si van al mismo proyecto, se agregan antes de firmar. |
| REQ-4605 | Requerimiento REQ-4605 | Está propuesto, no aceptado, y sin doliente. Sin decisión del gerente de producto no entra a un acta. |

## Gobierno
**Patrocinador:** no está dicho en ningún documento. · **Gerente propuesto:** no está dicho; Gustavo Neira es el gerente del *producto*, no consta como del proyecto. Asignarlo es de quien tiene la autoridad. · **Comité:** el comité de producto mensual (configuración); asistió Gustavo Neira (acta 2026-10-25). · **Autoridad del gerente:** no declarada. Sin ella el gerente del proyecto no sabrá qué puede decidir.

## Supuestos que se llevan al proyecto
| Supuesto | Verificado | Se convierte en riesgo de |
|---|---|---|
| El proveedor cumple el tiempo pactado (declarado 2026-08-11) | Sí, 2026-09-19, con el documento técnico del proveedor (`00-definicion/2026-09-19-verificacion-supuesto.md`) | No pasa como riesgo abierto. Queda anotado como dependencia del proveedor por si el plazo cambia. Nota: la definición está fechada 2026-03-07 y el supuesto, 2026-08-11. |

## Restricciones normativas sin resolver
| Qué toca | Obligación | Norma | Estado |
|---|---|---|---|
| No se hizo barrido normativo | — | — | Sin determinar. Ningún documento dice qué datos o contenidos maneja el servicio. |

## Vacíos de este acta
| Qué falta | Consecuencia de firmar sin eso | Quién lo cierra |
|---|---|---|
| Quién decidió aceptar REQ-4600 | La aceptación no tiene dueño; no se puede defender ante una revisión | Gustavo Neira, gerente de producto |
| Evidencia de demanda | El proyecto arranca sin prueba de que alguien lo pidió | Beatriz Cuéllar (doliente), con entrevista o ticket |
| Criterio de aceptación verificable | El cierre no se podrá juzgar meses después | Gustavo Neira con el doliente |
| Criterio de éxito del producto | No hay contra qué medir el retorno («esperado en 24 meses», sin cifra) | Gustavo Neira |
| Autoridad del gerente | Escala todo o no escala nada | Quien tenga la facultad; hoy no se sabe quién |
| Patrocinador y gerente del proyecto | Nadie firma ni responde | Quien tenga la facultad |
| Presupuesto e hitos | No se declararon; no se inventan | Patrocinador |
| Barrido normativo | Obligaciones no vistas | Gustavo Neira |

---
**Esto es un borrador.** Lo firma el patrocinador, que está por nombrar. **La ficha del proyecto no se creó:** se crea después de la firma, con `portafolio.py init`, y esa firma no existe.

**Qué sigue:** quien firme cierra los vacíos o los acepta por escrito. Después, el gerente del proyecto instala `criterio-project` y corre `/pm-setup`. Cuando publique su ficha con `/pm-publish`, `/product-trace` podrá confirmar la traza.
