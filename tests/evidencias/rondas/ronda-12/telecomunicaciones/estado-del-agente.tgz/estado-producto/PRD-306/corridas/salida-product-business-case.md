# Caso de negocio — Televisión IP (PRD-306) · borrador del 2026-10-28
**Desde:** la definición del 2026-03-07 (`00-definicion/2026-03-07-definicion-producto.md`) y el caso de negocio del 2026-03-07 (`00-definicion/2026-03-07-caso-de-negocio.md`) · **Cifras con fuente:** 1 de 1 cifra numérica (más 1 plazo sin monto: «retorno esperado en 24 meses»)

Nota de la prueba: los términos (v1.3) ya estaban vigentes y aceptados por José Francisco Ñáñez el 2026-10-28; no se volvieron a registrar. No había nadie para responder: cada pregunta se resolvió con la respuesta sugerida. Este documento no produce cifras ni recomienda aprobar o rechazar.

## Qué problema resuelve, y para quién
- **Problema:** «El segmento Grandes empresas no tiene televisión ip.» (definición, 2026-03-07). Una sola frase y sin fuente propia en la definición.
- **Para quién:** Grandes empresas (definición, 2026-03-07). Sin cuantificar: no se dice cuántas empresas ni qué tamaño tiene el segmento.
- **Lo único que lo respalda:** una entrevista a «Cliente entrevistado» del 2025-09-25: «Lo necesito y hoy no lo tengo.» (`10-descubrimiento/2025-09-25-entrevistas.docx`). Un cliente sin nombre y sin segmento dicho; alguien dijo, nadie pagó. Tiene 13 meses (umbral 12).

## Qué se construye
Alcance: los requerimientos decididos (aceptados), no el registro entero. Hay 11 aceptados y 1 propuesto (REQ-4605, queda fuera del caso hasta que se decida). Todos tienen el mismo título genérico («Requerimiento REQ-46xx»: el acta no los describe), y de ninguno consta quién decidió. La sección «La propuesta» de la definición dice solo «Propuesta principal», sin contenido.

| Requerimiento | Estado | Evidencia de demanda |
|---|---|---|
| REQ-4600 | aceptado (2026-07-23) | **Ninguna.** «Quién lo pidió»: — (acta 2026-10-25) |
| REQ-4601 | aceptado (2026-04-24) | «Cliente entrevistado», entrevista 2025-09-25 (no nombra el requerimiento) |
| REQ-4602 | aceptado (2026-06-09) | **Ninguna.** |
| REQ-4603 | aceptado (2026-08-06) | «Cliente entrevistado», entrevista 2025-09-25. Sin criterio de aceptación |
| REQ-4604 | aceptado (2026-06-26) | «Cliente entrevistado», entrevista 2025-09-25 |
| REQ-4606 | aceptado (2026-05-23) | «Cliente entrevistado», entrevista 2025-09-25 |
| REQ-4607 | aceptado (2026-05-12) | «Cliente entrevistado», entrevista 2025-09-25 |
| REQ-4608 | aceptado (2026-06-15) | «Cliente entrevistado», entrevista 2025-09-25. Sin criterio de aceptación |
| REQ-4609 | aceptado (2026-04-16) | **Ninguna.** |
| REQ-4610 | aceptado (2026-05-12) | «Cliente entrevistado», entrevista 2025-09-25 |
| REQ-4611 | aceptado (2026-08-22) | «Cliente entrevistado», entrevista 2025-09-25 |

Los ocho con evidencia citan la misma entrevista, y esa entrevista trata «Necesidad principal» y no nombra ninguno de ellos. Los 11 figuran sin proyecto que los ejecute («—» en el acta; la definición dice «Ninguno declarado»).

## Las cifras
| Cifra | Valor | Clase | De dónde sale | De cuándo |
|---|---|---|---|---|
| `volumen_mensual` | 100.016 (sin unidad: no se dice volumen de qué) | **Declarada** | Caso de negocio, tabla «Cifras que sostienen el caso», preparado por Gustavo Neira | 2026-03-07 |
| Retorno esperado | «en 24 meses» (plazo; sin monto ni tasa) | **Declarada, sin cifra** | Caso de negocio, sección «Retorno esperado» | 2026-03-07 |
| Cualquier cifra que sostenga el retorno (ingresos, precio, tamaño del segmento, adopción) | — | **Supuesta**: no está escrita en ningún documento | Nadie la ha afirmado | — |

No hay ninguna cifra **medida** en la carpeta.

### Donde la cifra declarada y la medida no coinciden
| Métrica | Declarada | Medida | Las dos fuentes y fechas |
|---|---|---|---|
| (ninguna) | `volumen_mensual` = 100.016 | No hay serie medida | Caso de negocio 2026-03-07 contra nada: nadie está midiendo lo que el caso afirma. Sin serie no hay diferencia que calcular, ni contra el umbral del 20 %. |

## Los costos
| Concepto | Valor | De dónde sale |
|---|---|---|
| Costo de construir | **No consta** | Ningún documento de la carpeta |
| Contrato o cotización del proveedor | **No consta** | Ni siquiera se nombra al proveedor |
| Costo del equipo | **No consta** | Ningún documento |

El costo de construir no está en ningún documento: **ese es el primer vacío**, y sin él lo que hay es una propuesta, no un caso de negocio que evaluar.

## Supuestos sobre los que se sostiene
| Supuesto | Qué pasa si resulta falso | Quién lo verificaría |
|---|---|---|
| «El proveedor cumple el tiempo pactado» (declarado el 2026-08-11; marcado verificado el 2026-09-19 con el anexo `00-definicion/2026-09-19-verificacion-supuesto.md`) | No consta: no se dice cuál es el tiempo pactado ni qué pasa si no se cumple | El anexo afirma «se confirmó» y dice ser la evidencia, pero remite a un documento técnico del proveedor del 2026-09-19 que **no está en la carpeta**. Verificado en el papel; quien audite no ve la evidencia de fondo. Además es una conducta futura: confirmar en septiembre no garantiza lo posterior. |
| Que existe demanda en Grandes empresas (implícito; nadie lo declara como supuesto) | El volumen y el retorno quedan sin base | Gustavo Neira, con entrevistas o pedidos del segmento; la única entrevista no dice que el cliente sea de ese segmento |
| Que 100.016 es el volumen mensual alcanzable (implícito) | El caso entero se mueve con esa cifra | Quien la produjo: no consta de dónde sale |

Rareza interna: la definición es del 2026-03-07 pero su supuesto figura «declarado el 2026-08-11»; el documento no aclara si se editó después sin cambiar la fecha.

## Vacíos
| Qué falta | Por qué importa | Quién lo produce |
|---|---|---|
| Costo de construir y operar | Sin él no hay caso que evaluar | Quien tenga el contrato o la cotización; Gustavo Neira lo pide |
| Qué mide `volumen_mensual` y de dónde sale 100.016 | Es la única cifra del caso y no tiene unidad ni método | Gustavo Neira (autor del caso) |
| Monto o tasa del «retorno esperado» | «24 meses» es un plazo, no una cifra | El negocio; no el agente |
| Tamaño del segmento y cuánto pagaría el cliente | Sin precio ni universo no hay ingreso que sustentar | Comercial / Gustavo Neira |
| Criterio de éxito del producto | Sin él el producto no se puede cerrar ni juzgar después | Gustavo Neira, con quien tenga autoridad |
| Autoridad que decide | `authority` sin declarar; es la razón por la que REQ-4605 lleva 204 días propuesto (umbral 60) | Gustavo Neira o el comité mensual |
| Proyecto que construye el producto | «Ninguno declarado»; los 11 aceptados sin traza (pendiente confirmar con las fichas de proyecto, que esta corrida no recibió) | Gestión de proyectos; `/criterio-product:product-trace` |
| Contenido de «la propuesta» | La sección dice solo «Propuesta principal» | Gustavo Neira |
| Evidencia de demanda para REQ-4600, 4602 y 4609 | Aceptados sin que conste quién los pidió | Sus dolientes: Beatriz Cuéllar, Laura Vélez, Diana Molina |
| Quién decidió los 11 aceptados | `decision.who` vacío; además las fechas de decisión (2026-04-16 a 2026-08-22) son anteriores al acta del 2026-10-25 | Gustavo Neira |
| Qué pasa si no se hace; alternativas consideradas | El caso no las dice | Gustavo Neira |
| Normativa sectorial de telecomunicaciones y contenidos | La definición no declara país ni la menciona; va a revisión jurídica (no se evaluó cumplimiento) | Jurídico |

## Cómo se sabrá si funcionó
**No está declarado.** El criterio de éxito del producto no existe en ningún documento, y el único plazo del caso («retorno en 24 meses», contado desde el 2026-03-07, o sea hacia marzo de 2028 si se leyera así; el documento no dice desde cuándo corre) no trae métrica ni fecha de corte. Sin una métrica y una fecha de corte, el producto no se puede cerrar meses después.

## Si hay otros productos publicados
No hay fichas de otros productos a la vista (no se pasó `--otros`), así que no se pudo hacer el cruce de `/product-overlap`. No se afirma que no haya solapamiento: no se miró. Cuando haya productos publicados conviene correrlo, porque `volumen_mensual` no dice qué cuenta y es fácil que otro caso cuente lo mismo.

## Después
- Pasar los supuestos al seguimiento con **assumption-tracking**: los tres de arriba, el implícito de demanda y el del volumen incluidos.
- `/criterio-product:product-charter` solo si el caso se aprueba; hoy faltan costo, criterio de éxito y autoridad.
