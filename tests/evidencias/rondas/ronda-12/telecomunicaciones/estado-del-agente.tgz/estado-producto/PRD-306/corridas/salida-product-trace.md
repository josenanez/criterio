## Trazabilidad — Televisión IP (PRD-306) · al 2026-10-28
11 decididos · 0 con proyecto · 0 confirmados contra la ficha · 0 entregados

Fichas leídas: las 13 de `estado/records` (PRY-199 a PRY-211). Ninguna nombra PRD-306 ni «Televisión IP».

### Decidido y nadie lo está construyendo
Los 11 requerimientos aceptados no tienen proyecto en su traza (`requirement_untraced`: 11). Todos van a la vez; la decisión es de las actas del comité (fuente: `documentos/productos/PRD-306/30-decisiones/2026-10-25-comite-producto.docx`).

| REQ | Estado | Decidido el | Por quién | Dueño |
|---|---|---|---|---|
| REQ-4609 | aceptado | 2026-04-16 | no consta en el acta | Diana Molina |
| REQ-4601 | aceptado | 2026-04-24 | no consta en el acta | Rubén Cárdenas |
| REQ-4607 | aceptado | 2026-05-12 | no consta en el acta | María Restrepo |
| REQ-4610 | aceptado | 2026-05-12 | no consta en el acta | Sandra Gil |
| REQ-4606 | aceptado | 2026-05-23 | no consta en el acta | Felipe Arango |
| REQ-4608 | aceptado | 2026-06-15 | no consta en el acta | Andrés Lozano |
| REQ-4602 | aceptado | 2026-06-09 | no consta en el acta | Laura Vélez |
| REQ-4604 | aceptado | 2026-06-26 | no consta en el acta | Mauricio Pérez |
| REQ-4600 | aceptado | 2026-07-23 | no consta en el acta | Beatriz Cuéllar |
| REQ-4603 | aceptado | 2026-08-06 | no consta en el acta | Ricardo Salas |
| REQ-4611 | aceptado | 2026-08-22 | no consta en el acta | Mauricio Pérez |

El más viejo lleva 195 días decidido sin proyecto (REQ-4609).

### La traza no se confirma
Ninguna: ningún requerimiento dice ejecutarse en un proyecto, así que no hay traza que confirmar ni desacuerdo con una ficha.

### Lo que un proyecto construye y el registro no tiene
Ninguno. Ninguna de las 13 fichas dice ejecutar PRD-306.

### La cadena completa
| REQ | Estado | Decisión | Proyecto | Confirmado | Entregables |
|---|---|---|---|---|---|
| REQ-4600 | aceptado | comité, 2026-07-23 | — | no | — |
| REQ-4601 | aceptado | comité, 2026-04-24 | — | no | — |
| REQ-4602 | aceptado | comité, 2026-06-09 | — | no | — |
| REQ-4603 | aceptado | comité, 2026-08-06 | — | no | — |
| REQ-4604 | aceptado | comité, 2026-06-26 | — | no | — |
| REQ-4605 | propuesto | sin decidir (204 días) | — | no | — |
| REQ-4606 | aceptado | comité, 2026-05-23 | — | no | — |
| REQ-4607 | aceptado | comité, 2026-05-12 | — | no | — |
| REQ-4608 | aceptado | comité, 2026-06-15 | — | no | — |
| REQ-4609 | aceptado | comité, 2026-04-16 | — | no | — |
| REQ-4610 | aceptado | comité, 2026-05-12 | — | no | — |
| REQ-4611 | aceptado | comité, 2026-08-22 | — | no | — |

La cadena se rompe en el eslabón decisión → proyecto, en los 11. REQ-4605 sigue propuesto, sin dueño, y no cuenta como decidido.

### Sin fichas a la vista
No aplica a la cadena: ningún requerimiento nombra proyecto, así que ninguna ficha faltante impidió confirmar nada. Sí queda dicho que, mientras no haya un proyecto nombrado, ninguna traza puede darse por confirmada.
