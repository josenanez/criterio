<!-- origen: PRY-209-apagado-de-la-red-3g/20-seguimiento/2026-10-26-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Apagado de la red 3G
Código: PRY-209
Fecha de corte: 2026-10-26
Gerente: Liliana Torres

Estado declarado
Amarillo
Avance reportado: 87%

Lo que pasó en el periodo
- Se recibió el concepto del regulador sobre el uso del espectro
- Se reprogramó la llegada de los equipos de radio por demoras en la aduana
- Se ajustó el plan de sitios con el proveedor de infraestructura

Presupuesto
COP
Aprobado 18.000.000.000
Comprometido 13.909.432.543
Ejecutado 9.506.759.546
Proyección al cierre 18.234.395.866

Riesgos abiertos
- Concentración del conocimiento en una sola persona
- Permisos municipales para instalar antenas
