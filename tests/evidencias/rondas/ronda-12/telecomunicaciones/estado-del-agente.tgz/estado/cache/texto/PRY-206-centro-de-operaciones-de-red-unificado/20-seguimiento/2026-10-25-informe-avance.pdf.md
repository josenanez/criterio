<!-- origen: PRY-206-centro-de-operaciones-de-red-unificado/20-seguimiento/2026-10-25-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Centro de operaciones de red unificado
Código: PRY-206
Fecha de corte: 2026-10-25
Gerente: Javier Hoyos

Estado declarado
Rojo
Avance reportado: 65%

Lo que pasó en el periodo
- Se acordó con operaciones cómo se miden las pruebas de aceptación de cada sitio
- El equipo perdió dos semanas por rotación del gerente de despliegue

Presupuesto
COP
Aprobado 4.200.000.000
Comprometido 1.789.744.389
Ejecutado 1.953.080.928
Proyección al cierre 4.261.219.163

Riesgos abiertos
- Subasta de espectro aplazada por el regulador
- Cambio en la norma de compartición de infraestructura que puede mover el alcance
