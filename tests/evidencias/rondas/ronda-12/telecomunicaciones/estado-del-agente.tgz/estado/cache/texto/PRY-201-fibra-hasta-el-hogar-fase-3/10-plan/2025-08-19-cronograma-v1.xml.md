<!-- origen: PRY-201-fibra-hasta-el-hogar-fase-3/10-plan/2025-08-19-cronograma-v1.xml · convertidor: project -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Cronograma · Microsoft Project · Cronograma

**Inicio:** — · **Fin:** — · **Fecha de estado:** —

## Tareas

| ID | EDT | Tarea | Inicio | Fin | Línea base: fin | Avance | Tipo | Predecesoras | Recursos |
|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | Diseño de red aprobado | 2025-11-10 | 2025-11-10 | 2025-11-10 | 100% | hito | — | — |
| 2 | 2 | Permisos de instalación obtenidos | 2026-01-23 | 2026-01-23 | 2026-01-23 | 100% | hito | 1FS | — |
| 3 | 3 | Sitios construidos | 2026-04-07 | 2026-04-07 | 2026-04-07 | 100% | hito | 2FS | — |
| 4 | 4 | Integración con la red | 2026-06-20 | 2026-06-20 | 2026-06-20 | 100% | hito | 3FS | — |
| 5 | 5 | Lanzamiento comercial | 2026-09-02 | 2026-09-02 | 2026-09-02 | 100% | hito | 4FS | — |

## Hitos

| Hito | Línea base | Vigente | Estado |
|---|---|---|---|
| Diseño de red aprobado | 2025-11-10 | 2025-11-10 | cerrado |
| Permisos de instalación obtenidos | 2026-01-23 | 2026-01-23 | cerrado |
| Sitios construidos | 2026-04-07 | 2026-04-07 | cerrado |
| Integración con la red | 2026-06-20 | 2026-06-20 | cerrado |
| Lanzamiento comercial | 2026-09-02 | 2026-09-02 | cerrado |
