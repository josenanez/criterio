<!-- origen: PRY-211-plataforma-de-internet-de-las-cosas/30-reuniones/2026-09-30-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Inversiones · Plataforma de internet de las cosas

**Fecha:** 2026-09-30
**Asistentes:** Camilo Beltrán, Carlos Peña, Gustavo Neira, Javier Hoyos, Jorge Medina, Liliana Torres, Ricardo Salas, Rubén Cárdenas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Gustavo Neira | Enviar el documento 1 | 2026-10-20 |
| Javier Hoyos | Cerrar la prueba 2 | 2026-10-28 |
| Rubén Cárdenas | Revisar el anexo 3 | 2026-10-24 |
| Carlos Peña | Validar el ambiente 4 | 2026-10-03 |
| Ricardo Salas | Aprobar el diseño 5 | 2026-10-24 |
| Camilo Beltrán | Actualizar la matriz 6 | 2026-10-24 |
| Camilo Beltrán | Confirmar la fecha 7 | 2026-10-21 |
| Ricardo Salas | Entregar el punto 8 | 2026-11-05 |
| Carlos Peña | Enviar el documento 9 | 2026-10-17 |
| Gustavo Neira | Cerrar la prueba 10 | 2026-10-28 |
| Rubén Cárdenas | Revisar el anexo 11 | por definir |
| Liliana Torres | Validar el ambiente 12 | 2026-10-25 |
