<!-- origen: PRY-206-centro-de-operaciones-de-red-unificado/20-seguimiento/2026-10-19-solicitud-cambio-cc-01.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-01

**Proyecto:** PRY-206 · Centro de operaciones de red unificado
**Fecha:** 2026-10-19
**Solicitante:** Javier Hoyos

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +93 días sobre la línea base vigente |
| Costo | 186.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
