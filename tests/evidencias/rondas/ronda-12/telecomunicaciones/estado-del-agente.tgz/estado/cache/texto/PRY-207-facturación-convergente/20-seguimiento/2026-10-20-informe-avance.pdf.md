<!-- origen: PRY-207-facturación-convergente/20-seguimiento/2026-10-20-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Facturación convergente
Código: PRY-207
Fecha de corte: 2026-10-20
Gerente: Liliana Torres

Estado declarado
Verde
Avance reportado: 35%

Lo que pasó en el periodo
- El equipo perdió dos semanas por rotación del gerente de despliegue
- Se ajustó el plan de sitios con el proveedor de infraestructura
- La alcaldía detuvo la instalación de antenas en dos barrios durante diez días

Presupuesto
COP
Aprobado 1.200.000.000
Comprometido 862.850.414
Ejecutado 512.570.966
Proyección al cierre 1.257.252.472

Riesgos abiertos
- Permisos municipales para instalar antenas
