<!-- origen: PRY-203-migración-del-core-de-voz-a-la-nube/20-seguimiento/2026-10-18-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Migración del core de voz a la nube
Código: PRY-203
Fecha de corte: 2026-10-18
Gerente: Mauricio Pérez

Estado declarado
Amarillo
Avance reportado: 59%

Lo que pasó en el periodo
- El equipo perdió dos semanas por rotación del gerente de despliegue
- La alcaldía detuvo la instalación de antenas en dos barrios durante diez días

Presupuesto
COP
Aprobado 1.200.000.000
Comprometido 467.181.006
Ejecutado 484.949.082
Proyección al cierre 1.235.285.263

Riesgos abiertos
- Concentración del conocimiento en una sola persona
- Permisos municipales para instalar antenas
