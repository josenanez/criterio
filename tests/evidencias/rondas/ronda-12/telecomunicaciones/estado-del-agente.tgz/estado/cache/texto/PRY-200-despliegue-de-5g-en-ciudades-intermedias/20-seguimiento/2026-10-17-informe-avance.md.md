<!-- origen: PRY-200-despliegue-de-5g-en-ciudades-intermedias/20-seguimiento/2026-10-17-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Despliegue de 5G en ciudades intermedias

**Código:** PRY-200
**Fecha de corte:** 2026-10-17
**Gerente:** Óscar Ramírez

## Estado declarado

**Amarillo**

Avance reportado: **59%**

## Lo que pasó en el periodo

- La prueba de velocidad en campo no alcanzó el valor pactado y se repite
- Se reprogramó la llegada de los equipos de radio por demoras en la aduana

## Presupuesto

| | COP |
|---|---|
| Aprobado | 3.300.000.000 |
| Comprometido | 2.493.745.794 |
| Ejecutado | 1.136.310.608 |
| Proyección al cierre | 3.425.145.140 |

## Riesgos abiertos

- Cambio en la norma de compartición de infraestructura que puede mover el alcance
- Subasta de espectro aplazada por el regulador
