<!-- origen: PRY-202-modernización-de-la-red-de-transporte/20-seguimiento/2026-10-25-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Modernización de la red de transporte
Código: PRY-202
Fecha de corte: 2026-10-25
Gerente: Carlos Peña

Estado declarado
Verde
Avance reportado: 52%

Lo que pasó en el periodo
- Se recibió el concepto del regulador sobre el uso del espectro

Presupuesto
COP
Aprobado 4.200.000.000
Comprometido 2.747.834.267
Ejecutado 914.788.857
Proyección al cierre 3.924.582.812

Riesgos abiertos
- Concentración del conocimiento en una sola persona
