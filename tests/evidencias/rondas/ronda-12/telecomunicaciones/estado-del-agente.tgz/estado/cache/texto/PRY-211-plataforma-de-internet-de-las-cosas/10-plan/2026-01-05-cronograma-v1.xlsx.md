<!-- origen: PRY-211-plataforma-de-internet-de-las-cosas/10-plan/2026-01-05-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de red aprobado | 2026-02-22 | 2026-02-22 | cerrado
Permisos de instalación obtenidos | 2026-04-02 | 2026-04-02 | cerrado
Sitios construidos | 2026-05-10 | 2026-05-10 | cerrado
Integración con la red | 2026-06-18 | 2026-06-18 | cerrado
Lanzamiento comercial | 2026-07-26 | 2026-07-26 | cerrado
