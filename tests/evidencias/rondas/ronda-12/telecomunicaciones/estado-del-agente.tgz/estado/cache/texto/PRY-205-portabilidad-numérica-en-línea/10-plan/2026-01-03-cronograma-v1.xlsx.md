<!-- origen: PRY-205-portabilidad-numérica-en-línea/10-plan/2026-01-03-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de red aprobado | 2026-05-07 | 2026-05-07 | cerrado
Permisos de instalación obtenidos | 2026-08-29 | 2026-08-29 | cerrado
Sitios construidos | 2026-12-21 | 2026-12-21 | en curso
Integración con la red | 2027-04-14 | 2027-04-14 | en curso
