<!-- origen: PRY-207-facturación-convergente/00-gobierno/2025-06-16-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Facturación convergente

Código: PRY-207

Área dueña: Compras

Patrocinador: Sandra Gil

Gerente de proyecto: Liliana Torres

Comité: Comité de Inversiones

Producto asociado: No aplica

Fecha de aprobación: 2025-06-16

Objetivo del negocio

Entregar facturación convergente para Compras.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

1.200.000.000 COP, aprobado por Comité de Inversiones el 2025-06-16.

Fechas comprometidas

Fecha

Inicio

2025-06-26

Cierre

2026-01-03

Criterio de éxito

Facturación convergente en producción y medido.

Dependencias declaradas

• Ninguna declarada
