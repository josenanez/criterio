<!-- origen: PRY-211-plataforma-de-internet-de-las-cosas/30-reuniones/2026-09-16-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Inversiones · Plataforma de internet de las cosas

**Fecha:** 2026-09-16
**Asistentes:** Carlos Peña, Gustavo Neira, Javier Hoyos, Jorge Medina, Rubén Cárdenas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Gustavo Neira | Enviar el documento 1 | 2026-09-20 |
| Javier Hoyos | Cerrar la prueba 2 | 2026-10-02 |
| Rubén Cárdenas | Revisar el anexo 3 | 2026-10-05 |
| Carlos Peña | Validar el ambiente 4 | 2026-10-03 |
