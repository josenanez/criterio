<!-- origen: PRY-201-fibra-hasta-el-hogar-fase-3/00-gobierno/2025-08-19-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Fibra hasta el hogar fase 3

Código: PRY-201

Área dueña: Mercadeo

Patrocinador: Natalia Ospina

Gerente de proyecto: Javier Hoyos

Comité: Comité de Cambios

Producto asociado: internet por fibra

Fecha de aprobación: 2025-08-19

Objetivo del negocio

Entregar fibra hasta el hogar fase 3 para Mercadeo.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

6.800.000.000 COP, aprobado por Comité de Cambios el 2025-08-19.

Fechas comprometidas

Fecha

Inicio

2025-08-29

Cierre

2026-09-02

Criterio de éxito

Fibra hasta el hogar fase 3 en producción y medido.

Dependencias declaradas

• Ninguna declarada
