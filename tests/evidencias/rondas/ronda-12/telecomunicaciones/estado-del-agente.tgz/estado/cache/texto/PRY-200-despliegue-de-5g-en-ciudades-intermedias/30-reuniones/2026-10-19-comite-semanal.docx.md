<!-- origen: PRY-200-despliegue-de-5g-en-ciudades-intermedias/30-reuniones/2026-10-19-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Cambios · Despliegue de 5G en ciudades intermedias

Fecha: 2026-10-19

Asistentes: Óscar Ramírez, Natalia Ospina

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Carlos Peña

Entregar el punto 26

2026-10-06
