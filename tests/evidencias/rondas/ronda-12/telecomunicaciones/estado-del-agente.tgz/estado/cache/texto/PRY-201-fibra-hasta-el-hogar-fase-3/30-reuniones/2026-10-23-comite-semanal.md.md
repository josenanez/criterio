<!-- origen: PRY-201-fibra-hasta-el-hogar-fase-3/30-reuniones/2026-10-23-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Cambios · Fibra hasta el hogar fase 3

**Fecha:** 2026-10-23
**Asistentes:** Javier Hoyos, Natalia Ospina

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Beatriz Cuéllar | Entregar el punto 16 | 2026-10-31 |
