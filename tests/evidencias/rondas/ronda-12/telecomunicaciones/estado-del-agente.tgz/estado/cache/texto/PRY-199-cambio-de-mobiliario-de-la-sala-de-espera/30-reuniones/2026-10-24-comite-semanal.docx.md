<!-- origen: PRY-199-cambio-de-mobiliario-de-la-sala-de-espera/30-reuniones/2026-10-24-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Red · Cambio de mobiliario de la sala de espera

Fecha: 2026-10-24

Asistentes: Andrés Lozano, María Restrepo

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Carlos Peña

Presentar el cierre de la fase

2026-11-17
