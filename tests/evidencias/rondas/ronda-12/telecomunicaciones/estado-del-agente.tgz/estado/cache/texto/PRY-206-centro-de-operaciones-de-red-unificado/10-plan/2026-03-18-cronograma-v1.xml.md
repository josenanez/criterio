<!-- origen: PRY-206-centro-de-operaciones-de-red-unificado/10-plan/2026-03-18-cronograma-v1.xml · convertidor: project -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Cronograma · Microsoft Project · Cronograma

**Inicio:** — · **Fin:** — · **Fecha de estado:** —

## Tareas

| ID | EDT | Tarea | Inicio | Fin | Línea base: fin | Avance | Tipo | Predecesoras | Recursos |
|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | Diseño de red aprobado | 2026-07-13 | 2026-07-13 | 2026-07-13 | 100% | hito | — | — |
| 2 | 2 | Permisos de instalación obtenidos | 2026-10-28 | 2026-10-28 | 2026-10-28 | 50% | hito | 1FS | — |
| 3 | 3 | Sitios construidos | 2027-02-12 | 2027-02-12 | 2027-02-12 | 50% | hito | 2FS | — |
| 4 | 4 | Integración con la red | 2027-05-30 | 2027-05-30 | 2027-05-30 | 50% | hito | 3FS | — |
| 5 | 5 | Lanzamiento comercial | 2027-09-14 | 2027-09-14 | 2027-09-14 | 50% | hito | 4FS | — |

## Hitos

| Hito | Línea base | Vigente | Estado |
|---|---|---|---|
| Diseño de red aprobado | 2026-07-13 | 2026-07-13 | cerrado |
| Permisos de instalación obtenidos | 2026-10-28 | 2026-10-28 | en curso |
| Sitios construidos | 2027-02-12 | 2027-02-12 | en curso |
| Integración con la red | 2027-05-30 | 2027-05-30 | en curso |
| Lanzamiento comercial | 2027-09-14 | 2027-09-14 | en curso |
