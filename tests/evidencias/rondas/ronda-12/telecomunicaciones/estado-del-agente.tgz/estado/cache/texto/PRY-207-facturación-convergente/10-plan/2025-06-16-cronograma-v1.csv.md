<!-- origen: PRY-207-facturación-convergente/10-plan/2025-06-16-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño de red aprobado,2025-08-12,2025-08-12,cerrado
Permisos de instalación obtenidos,2025-09-29,2025-09-29,cerrado
Sitios construidos,2025-11-16,2025-11-16,cerrado
Integración con la red,2026-01-03,2026-01-03,cerrado
