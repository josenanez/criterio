<!-- origen: PRY-211-plataforma-de-internet-de-las-cosas/30-reuniones/2026-10-21-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Inversiones · Plataforma de internet de las cosas

**Fecha:** 2026-10-21
**Asistentes:** Beatriz Cuéllar, Camilo Beltrán, Carlos Peña, Diana Molina, Elena Duarte, Felipe Arango, Gustavo Neira, Javier Hoyos, Jorge Medina, Natalia Ospina, Ricardo Salas, Rubén Cárdenas, Sandra Gil

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Gustavo Neira | Enviar el documento 1 | 2026-12-12 |
| Javier Hoyos | Cerrar la prueba 2 | 2026-12-12 |
| Rubén Cárdenas | Revisar el anexo 3 | 2026-11-25 |
| Carlos Peña | Validar el ambiente 4 | 2026-11-03 |
| Ricardo Salas | Aprobar el diseño 5 | 2026-11-17 |
| Camilo Beltrán | Actualizar la matriz 6 | 2026-12-09 |
| Camilo Beltrán | Confirmar la fecha 7 | 2026-12-12 |
| Ricardo Salas | Entregar el punto 8 | 2026-11-23 |
| Carlos Peña | Enviar el documento 9 | 2026-11-24 |
| Gustavo Neira | Cerrar la prueba 10 | 2026-10-28 |
| Rubén Cárdenas | Revisar el anexo 11 | 2026-11-20 |
| Natalia Ospina | Actualizar la matriz 14 | 2026-11-08 |
| Felipe Arango | Confirmar la fecha 15 | 2026-10-19 |
| Jorge Medina | Entregar el punto 16 | 2026-10-30 |
| Jorge Medina | Enviar el documento 17 | 2026-10-22 |
| Beatriz Cuéllar | Cerrar la prueba 18 | 2026-10-22 |
| Diana Molina | Revisar el anexo 19 | 2026-11-03 |
| Felipe Arango | Validar el ambiente 20 | 2026-10-21 |
| Natalia Ospina | Aprobar el diseño 21 | 2026-11-06 |
| Sandra Gil | Actualizar la matriz 22 | 2026-10-24 |
| Camilo Beltrán | Confirmar la fecha 23 | 2026-10-30 |
| Elena Duarte | Entregar el punto 24 | 2026-10-24 |

## Lo que se dijo

- Carlos Peña dice que ya entregó «aprobar el diseño 13». No se presentó acta.
