<!-- origen: PRY-211-plataforma-de-internet-de-las-cosas/00-gobierno/ficha-pm.json · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

{
 "schema_version": "0.2",
 "identity": {
 "code": {
 "value": "PRY-211",
 "source": "00-gobierno/2026-01-05-acta-constitucion.md",
 "source_date": "2026-01-05",
 "state": "found"
 },
 "name": {
 "value": "Plataforma de internet de las cosas",
 "source": "00-gobierno/2026-01-05-acta-constitucion.md",
 "source_date": "2026-01-05",
 "state": "found"
 },
 "aliases": [],
 "business_area": {
 "value": "Mercadeo",
 "source": "00-gobierno/2026-01-05-acta-constitucion.md",
 "source_date": "2026-01-05",
 "state": "found"
 },
 "product": {
 "value": "conectividad IoT",
 "source": "00-gobierno/2026-01-05-acta-constitucion.md",
 "source_date": "2026-01-05",
 "state": "found"
 },
 "authority": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "sponsor": {
 "value": "Ricardo Salas",
 "source": "00-gobierno/2026-01-05-acta-constitucion.md",
 "source_date": "2026-01-05",
 "state": "found"
 },
 "manager": {
 "value": "Jorge Medina",
 "source": "00-gobierno/2026-01-05-acta-constitucion.md",
 "source_date": "2026-01-05",
 "state": "found"
 },
 "committee": {
 "value": "Comité de Inversiones",
 "source": "00-gobierno/2026-01-05-acta-constitucion.md",
 "source_date": "2026-01-05",
 "state": "found"
 },
 "phase": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 }
 },
 "declared": {
 "status": {
 "value": "amarillo",
 "source": "20-seguimiento/2026-10-28-informe-avance.md",
 "source_date": "2026-10-28",
 "state": "found",
 "source_kind": "declaration"
 },
 "progress_pct": {
 "value": 49,
 "source": "20-seguimiento/2026-10-28-informe-avance.md",
 "source_date": "2026-10-28",
 "state": "found",
 "source_kind": "declaration"
 },
 "as_of": {
 "value": "2026-10-28",
 "source": "20-seguimiento/2026-10-28-informe-avance.md",
 "source_date": "2026-10-28",
 "state": "found"
 },
 "source": {
 "value": "20-seguimiento/2026-10-28-informe-avance.md",
 "source": "20-seguimiento/2026-10-28-informe-avance.md",
 "source_date": "2026-10-28",
 "state": "found"
 }
 },
 "plan": {
 "start_date": {
 "value": "2026-01-15",
 "source": "00-gobierno/2026-01-05-acta-constitucion.md",
 "source_date": "2026-01-05",
 "state": "found"
 },
 "end_date": {
 "value": "2026-11-05",
 "source": "10-plan/2026-10-28-cronograma-v2.xlsx",
 "source_date": "2026-10-28",
 "state": "found"
 },
 "baseline": [
 {
 "version": 1,
 "approved_on": "2026-01-05",
 "start_date": "2026-01-15",
 "end_date": "2026-07-26",
 "reason": "Aprobación inicial del Comité de Inversiones",
 "source": "00-gobierno/2026-01-05-acta-constitucion.md"
 }
 ],
 "milestones": [
 {
 "name": {
 "value": "Diseño de red aprobado"
 },
 "baseline_date": {
 "value": "2026-02-22"
 },
 "current_date": {
 "value": "2026-02-22"
 },
 "state": {
 "value": "met"
 },
 "evidence": {
 "value": null
 },
 "source": {
 "value": "10-plan/2026-10-28-cronograma-v2.xlsx"
 }
 },
 {
 "name": {
 "value": "Permisos de instalación obtenidos"
 },
 "baseline_date": {
 "value": "2026-04-02"
 },
 "current_date": {
 "value": "2026-04-02"
 },
 "state": {
 "value": "met"
 },
 "evidence": {
 "value": "20-seguimiento/2026-10-16-acta-recibo-permisos-de-instalación-obtenidos.md"
 },
 "source": {
 "value": "10-plan/2026-10-28-cronograma-v2.xlsx"
 }
 },
 {
 "name": {
 "value": "Sitios construidos"
 },
 "baseline_date": {
 "value": "2026-05-10"
 },
 "current_date": {
 "value": "2026-05-10"
 },
 "state": {
 "value": "met"
 },
 "evidence": {
 "value": "20-seguimiento/2026-10-28-acta-recibo-sitios-construidos.pdf"
 },
 "source": {
 "value": "10-plan/2026-10-28-cronograma-v2.xlsx"
 }
 },
 {
 "name": {
 "value": "Integración con la red"
 },
 "baseline_date": {
 "value": "2026-06-18"
 },
 "current_date": {
 "value": "2026-06-18"
 },
 "state": {
 "value": "met"
 },
 "evidence": {
 "value": null
 },
 "source": {
 "value": "10-plan/2026-10-28-cronograma-v2.xlsx"
 }
 },
 {
 "name": {
 "value": "Lanzamiento comercial"
 },
 "baseline_date": {
 "value": "2026-07-26"
 },
 "current_date": {
 "value": "2026-11-05"
 },
 "state": {
 "value": "met"
 },
 "evidence": {
 "value": null
 },
 "source": {
 "value": "10-plan/2026-10-28-cronograma-v2.xlsx"
 }
 }
 ],
 "scope_summary": {
 "value": "Componente 1; Componente 2; Componente 3",
 "source": "00-gobierno/2026-01-05-acta-constitucion.md",
 "source_date": "2026-01-05",
 "state": "found"
 },
 "exclusions": {
 "value": "Lo que otro proyecto cubre",
 "source": "00-gobierno/2026-01-05-acta-constitucion.md",
 "source_date": "2026-01-05",
 "state": "found"
 }
 },
 "money": {
 "currency": {
 "value": "COP",
 "source": "00-gobierno/2026-01-05-acta-constitucion.md",
 "source_date": "2026-01-05",
 "state": "found"
 },
 "approved": {
 "value": 3300000000,
 "source": "00-gobierno/2026-01-05-acta-constitucion.md",
 "source_date": "2026-01-05",
 "state": "found"
 },
 "committed": {
 "value": 1710711399,
 "source": "20-seguimiento/2026-10-28-informe-avance.md",
 "source_date": "2026-10-28",
 "state": "found",
 "source_kind": "declaration"
 },
 "executed": {
 "value": 1847540267,
 "source": "20-seguimiento/2026-10-28-informe-avance.md",
 "source_date": "2026-10-28",
 "state": "found",
 "source_kind": "declaration"
 },
 "projection": {
 "value": 3037162738,
 "source": "20-seguimiento/2026-10-28-informe-avance.md",
 "source_date": "2026-10-28",
 "state": "found",
 "source_kind": "declaration"
 }
 },
 "vendors": [
 {
 "name": {
 "value": "Obras Civiles de Telecomunicaciones",
 "source": "00-gobierno/2025-12-29-contrato-ct-707.docx",
 "source_date": "2025-12-29",
 "state": "found"
 },
 "contract_ref": {
 "value": "CT-707",
 "source": "00-gobierno/2025-12-29-contrato-ct-707.docx",
 "source_date": "2025-12-29",
 "state": "found"
 },
 "deliverables": [
 {
 "name": {
 "value": "Suministro de antenas y radios"
 },
 "due_date": {
 "value": "2026-03-26"
 },
 "amount": {
 "value": 371745399
 },
 "state": {
 "value": "pending"
 },
 "evidence": {
 "value": null
 }
 },
 {
 "name": {
 "value": "Bolsa de horas de ingeniería"
 },
 "due_date": {
 "value": "2026-06-05"
 },
 "amount": {
 "value": 371745399
 },
 "state": {
 "value": "pending"
 },
 "evidence": {
 "value": null
 }
 }
 ],
 "invoiced": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "source": "00-gobierno/2025-12-29-contrato-ct-707.docx"
 }
 ],
 "raid": {
 "risks": [
 {
 "what": "Concentración del conocimiento en una sola persona",
 "owner": null,
 "source": "20-seguimiento/2026-10-28-informe-avance.md",
 "source_date": "2026-10-28",
 "registered": true
 },
 {
 "what": "El proveedor podría no llegar con el equipo completo para la siguiente fase",
 "owner": null,
 "source": "2026-10-28-notas-reunion.txt",
 "source_date": "2026-10-28",
 "registered": false,
 "note": "Se comentó en la reunión; nadie lo anotó como riesgo"
 }
 ],
 "assumptions": [],
 "issues": [
 {
 "what": "La prueba de velocidad en campo no alcanzó el valor pactado y se repite",
 "since": "2026-10-28",
 "owner": null,
 "source": "20-seguimiento/2026-10-28-informe-avance.md"
 }
 ],
 "dependencies": []
 },
 "changes": [
 {
 "ref": {
 "value": "CC-01"
 },
 "requested_on": {
 "value": "2026-10-17"
 },
 "scope_impact": {
 "value": "Ampliación de alcance"
 },
 "time_impact": {
 "value": "+102 días sobre la línea base vigente"
 },
 "cost_impact": {
 "value": "204.000.000 COP adicionales"
 },
 "decision": {
 "value": "pending"
 },
 "decided_by": {
 "value": null
 },
 "source": {
 "value": "20-seguimiento/2026-10-17-solicitud-cambio-cc-01.md"
 }
 }
 ],
 "commitments": [
 {
 "who": {
 "value": "Gustavo Neira"
 },
 "what": {
 "value": "Enviar el documento 1"
 },
 "due_date": {
 "value": "2026-12-26"
 },
 "original_due_date": "2026-09-20",
 "stated_on": "2026-09-16",
 "source": {
 "value": "30-reuniones/2026-09-16-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-02",
 "stated_on": "2026-09-23",
 "source": "30-reuniones/2026-09-23-comite-semanal.md"
 },
 {
 "due_date": "2026-10-20",
 "stated_on": "2026-09-30",
 "source": "30-reuniones/2026-09-30-comite-semanal.md"
 },
 {
 "due_date": "2026-11-10",
 "stated_on": "2026-10-07",
 "source": "30-reuniones/2026-10-07-comite-semanal.md"
 },
 {
 "due_date": "2026-11-29",
 "stated_on": "2026-10-14",
 "source": "30-reuniones/2026-10-14-comite-semanal.md"
 },
 {
 "due_date": "2026-12-12",
 "stated_on": "2026-10-21",
 "source": "30-reuniones/2026-10-21-comite-semanal.md"
 },
 {
 "due_date": "2026-12-26",
 "stated_on": "2026-10-28",
 "source": "2026-10-28-notas-reunion.txt"
 }
 ]
 },
 {
 "who": {
 "value": "Javier Hoyos"
 },
 "what": {
 "value": "Cerrar la prueba 2"
 },
 "due_date": {
 "value": "2026-12-12"
 },
 "original_due_date": "2026-10-02",
 "stated_on": "2026-09-16",
 "source": {
 "value": "30-reuniones/2026-09-16-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-09",
 "stated_on": "2026-09-23",
 "source": "30-reuniones/2026-09-23-comite-semanal.md"
 },
 {
 "due_date": "2026-10-28",
 "stated_on": "2026-09-30",
 "source": "30-reuniones/2026-09-30-comite-semanal.md"
 },
 {
 "due_date": "2026-11-08",
 "stated_on": "2026-10-07",
 "source": "30-reuniones/2026-10-07-comite-semanal.md"
 },
 {
 "due_date": "2026-11-22",
 "stated_on": "2026-10-14",
 "source": "30-reuniones/2026-10-14-comite-semanal.md"
 },
 {
 "due_date": "2026-12-12",
 "stated_on": "2026-10-21",
 "source": "30-reuniones/2026-10-21-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Rubén Cárdenas"
 },
 "what": {
 "value": "Revisar el anexo 3"
 },
 "due_date": {
 "value": "2026-11-25"
 },
 "original_due_date": "2026-10-05",
 "stated_on": "2026-09-16",
 "source": {
 "value": "30-reuniones/2026-09-16-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-24",
 "stated_on": "2026-09-23",
 "source": "30-reuniones/2026-09-23-comite-semanal.md"
 },
 {
 "due_date": "2026-11-06",
 "stated_on": "2026-10-14",
 "source": "30-reuniones/2026-10-14-comite-semanal.md"
 },
 {
 "due_date": "2026-11-25",
 "stated_on": "2026-10-21",
 "source": "30-reuniones/2026-10-21-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Carlos Peña"
 },
 "what": {
 "value": "Validar el ambiente 4"
 },
 "due_date": {
 "value": "2026-11-03"
 },
 "original_due_date": "2026-10-03",
 "stated_on": "2026-09-16",
 "source": {
 "value": "30-reuniones/2026-09-16-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-11-03",
 "stated_on": "2026-10-21",
 "source": "30-reuniones/2026-10-21-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Ricardo Salas"
 },
 "what": {
 "value": "Aprobar el diseño 5"
 },
 "due_date": {
 "value": "2026-11-17"
 },
 "original_due_date": "2026-10-15",
 "stated_on": "2026-09-23",
 "source": {
 "value": "30-reuniones/2026-09-23-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-24",
 "stated_on": "2026-09-30",
 "source": "30-reuniones/2026-09-30-comite-semanal.md"
 },
 {
 "due_date": "2026-11-01",
 "stated_on": "2026-10-07",
 "source": "30-reuniones/2026-10-07-comite-semanal.md"
 },
 {
 "due_date": "2026-11-17",
 "stated_on": "2026-10-14",
 "source": "30-reuniones/2026-10-14-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Camilo Beltrán"
 },
 "what": {
 "value": "Actualizar la matriz 6"
 },
 "due_date": {
 "value": "2026-12-09"
 },
 "original_due_date": "2026-10-16",
 "stated_on": "2026-09-23",
 "source": {
 "value": "30-reuniones/2026-09-23-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-24",
 "stated_on": "2026-09-30",
 "source": "30-reuniones/2026-09-30-comite-semanal.md"
 },
 {
 "due_date": "2026-11-06",
 "stated_on": "2026-10-07",
 "source": "30-reuniones/2026-10-07-comite-semanal.md"
 },
 {
 "due_date": "2026-11-25",
 "stated_on": "2026-10-14",
 "source": "30-reuniones/2026-10-14-comite-semanal.md"
 },
 {
 "due_date": "2026-12-09",
 "stated_on": "2026-10-21",
 "source": "30-reuniones/2026-10-21-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Camilo Beltrán"
 },
 "what": {
 "value": "Confirmar la fecha 7"
 },
 "due_date": {
 "value": "2026-12-12"
 },
 "original_due_date": "2026-10-08",
 "stated_on": "2026-09-23",
 "source": {
 "value": "30-reuniones/2026-09-23-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-21",
 "stated_on": "2026-09-30",
 "source": "30-reuniones/2026-09-30-comite-semanal.md"
 },
 {
 "due_date": "2026-11-03",
 "stated_on": "2026-10-07",
 "source": "30-reuniones/2026-10-07-comite-semanal.md"
 },
 {
 "due_date": "2026-11-21",
 "stated_on": "2026-10-14",
 "source": "30-reuniones/2026-10-14-comite-semanal.md"
 },
 {
 "due_date": "2026-12-12",
 "stated_on": "2026-10-21",
 "source": "30-reuniones/2026-10-21-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Ricardo Salas"
 },
 "what": {
 "value": "Entregar el punto 8"
 },
 "due_date": {
 "value": "2026-11-23"
 },
 "original_due_date": "2026-10-20",
 "stated_on": "2026-09-23",
 "source": {
 "value": "30-reuniones/2026-09-23-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-11-05",
 "stated_on": "2026-09-30",
 "source": "30-reuniones/2026-09-30-comite-semanal.md"
 },
 {
 "due_date": "2026-11-12",
 "stated_on": "2026-10-14",
 "source": "30-reuniones/2026-10-14-comite-semanal.md"
 },
 {
 "due_date": "2026-11-23",
 "stated_on": "2026-10-21",
 "source": "30-reuniones/2026-10-21-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Carlos Peña"
 },
 "what": {
 "value": "Enviar el documento 9"
 },
 "due_date": {
 "value": "2026-11-24"
 },
 "original_due_date": "2026-10-17",
 "stated_on": "2026-09-30",
 "source": {
 "value": "30-reuniones/2026-09-30-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-11-03",
 "stated_on": "2026-10-07",
 "source": "30-reuniones/2026-10-07-comite-semanal.md"
 },
 {
 "due_date": "2026-11-24",
 "stated_on": "2026-10-14",
 "source": "30-reuniones/2026-10-14-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Gustavo Neira"
 },
 "what": {
 "value": "Cerrar la prueba 10"
 },
 "due_date": {
 "value": "2026-10-28"
 },
 "original_due_date": "2026-10-28",
 "stated_on": "2026-09-30",
 "source": {
 "value": "30-reuniones/2026-09-30-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Rubén Cárdenas"
 },
 "what": {
 "value": "Revisar el anexo 11"
 },
 "due_date": {
 "value": "2026-11-20"
 },
 "original_due_date": "2026-10-31",
 "stated_on": "2026-09-30",
 "source": {
 "value": "30-reuniones/2026-09-30-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-11-20",
 "stated_on": "2026-10-21",
 "source": "30-reuniones/2026-10-21-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Liliana Torres"
 },
 "what": {
 "value": "Validar el ambiente 12"
 },
 "due_date": {
 "value": "2026-10-25"
 },
 "original_due_date": "2026-10-25",
 "stated_on": "2026-09-30",
 "source": {
 "value": "30-reuniones/2026-09-30-comite-semanal.md"
 },
 "state": {
 "value": "met"
 },
 "reschedules": [],
 "evidence": "20-seguimiento/2026-10-07-acta-recibo-12.md",
 "closed_on": "2026-10-07"
 },
 {
 "who": {
 "value": "Carlos Peña"
 },
 "what": {
 "value": "Aprobar el diseño 13"
 },
 "due_date": {
 "value": "2026-11-03"
 },
 "original_due_date": "2026-11-03",
 "stated_on": "2026-10-07",
 "source": {
 "value": "30-reuniones/2026-10-07-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [],
 "note": "El 2026-10-21 dice que ya lo entregó; no se presentó acta (30-reuniones/2026-10-21-comite-semanal.md). Desde esa fecha ya no aparece en la tabla de abiertos."
 },
 {
 "who": {
 "value": "Natalia Ospina"
 },
 "what": {
 "value": "Actualizar la matriz 14"
 },
 "due_date": {
 "value": "2026-11-08"
 },
 "original_due_date": "2026-10-25",
 "stated_on": "2026-10-07",
 "source": {
 "value": "30-reuniones/2026-10-07-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-11-08",
 "stated_on": "2026-10-14",
 "source": "30-reuniones/2026-10-14-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Felipe Arango"
 },
 "what": {
 "value": "Confirmar la fecha 15"
 },
 "due_date": {
 "value": "2026-10-19"
 },
 "original_due_date": "2026-10-19",
 "stated_on": "2026-10-07",
 "source": {
 "value": "30-reuniones/2026-10-07-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Jorge Medina"
 },
 "what": {
 "value": "Entregar el punto 16"
 },
 "due_date": {
 "value": "2026-10-30"
 },
 "original_due_date": "2026-10-17",
 "stated_on": "2026-10-07",
 "source": {
 "value": "30-reuniones/2026-10-07-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-30",
 "stated_on": "2026-10-21",
 "source": "30-reuniones/2026-10-21-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Jorge Medina"
 },
 "what": {
 "value": "Enviar el documento 17"
 },
 "due_date": {
 "value": "2026-10-22"
 },
 "original_due_date": "2026-10-22",
 "stated_on": "2026-10-14",
 "source": {
 "value": "30-reuniones/2026-10-14-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Beatriz Cuéllar"
 },
 "what": {
 "value": "Cerrar la prueba 18"
 },
 "due_date": {
 "value": "2026-10-22"
 },
 "original_due_date": "2026-10-22",
 "stated_on": "2026-10-14",
 "source": {
 "value": "30-reuniones/2026-10-14-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Diana Molina"
 },
 "what": {
 "value": "Revisar el anexo 19"
 },
 "due_date": {
 "value": "2026-11-03"
 },
 "original_due_date": "2026-10-23",
 "stated_on": "2026-10-14",
 "source": {
 "value": "30-reuniones/2026-10-14-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-11-03",
 "stated_on": "2026-10-21",
 "source": "30-reuniones/2026-10-21-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Felipe Arango"
 },
 "what": {
 "value": "Validar el ambiente 20"
 },
 "due_date": {
 "value": "2026-10-21"
 },
 "original_due_date": "2026-10-21",
 "stated_on": "2026-10-14",
 "source": {
 "value": "30-reuniones/2026-10-14-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Natalia Ospina"
 },
 "what": {
 "value": "Aprobar el diseño 21"
 },
 "due_date": {
 "value": "2026-11-06"
 },
 "original_due_date": "2026-11-06",
 "stated_on": "2026-10-21",
 "source": {
 "value": "30-reuniones/2026-10-21-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Sandra Gil"
 },
 "what": {
 "value": "Actualizar la matriz 22"
 },
 "due_date": {
 "value": "2026-10-24"
 },
 "original_due_date": "2026-10-24",
 "stated_on": "2026-10-21",
 "source": {
 "value": "30-reuniones/2026-10-21-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Camilo Beltrán"
 },
 "what": {
 "value": "Confirmar la fecha 23"
 },
 "due_date": {
 "value": "2026-10-30"
 },
 "original_due_date": "2026-10-30",
 "stated_on": "2026-10-21",
 "source": {
 "value": "30-reuniones/2026-10-21-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Elena Duarte"
 },
 "what": {
 "value": "Entregar el punto 24"
 },
 "due_date": {
 "value": "2026-10-24"
 },
 "original_due_date": "2026-10-24",
 "stated_on": "2026-10-21",
 "source": {
 "value": "30-reuniones/2026-10-21-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Laura Vélez"
 },
 "what": {
 "value": "Mandar el ajuste del presupuesto"
 },
 "due_date": {
 "value": "no_declarada"
 },
 "original_due_date": "no_declarada",
 "due_text": "la otra semana",
 "stated_on": "2026-10-28",
 "source": {
 "value": "2026-10-28-notas-reunion.txt"
 },
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Óscar Ramírez"
 },
 "what": {
 "value": "Revisión con el proveedor"
 },
 "due_date": {
 "value": "2026-11-07"
 },
 "original_due_date": "2026-11-07",
 "stated_on": "2026-10-28",
 "source": {
 "value": "2026-10-28-notas-reunion.txt"
 },
 "state": {
 "value": "open"
 },
 "reschedules": []
 }
 ],
 "activity": {
 "last_document_date": {
 "value": "2026-10-28",
 "source": "20-seguimiento/2026-10-28-informe-avance.md",
 "source_date": "2026-10-28",
 "state": "found"
 },
 "last_meeting_date": {
 "value": "2026-10-28",
 "source": "2026-10-28-notas-reunion.txt",
 "source_date": "2026-10-28",
 "state": "found"
 }
 },
 "meta": {
 "record_updated": "2026-10-28",
 "documents_seen": [
 {
 "path": "00-gobierno/2025-12-29-contrato-ct-707.docx",
 "date": "2025-12-29"
 },
 {
 "path": "00-gobierno/2026-01-05-acta-constitucion.md",
 "date": "2026-01-05"
 },
 {
 "path": "10-plan/2026-01-05-cronograma-v1.xlsx",
 "date": "2026-01-05"
 },
 {
 "path": "10-plan/2026-10-28-cronograma-v2.xlsx",
 "date": "2026-10-28"
 },
 {
 "path": "20-seguimiento/2026-10-07-acta-recibo-12.md",
 "date": "2026-10-07"
 },
 {
 "path": "20-seguimiento/2026-10-16-acta-recibo-permisos-de-instalación-obtenidos.md",
 "date": "2026-10-16"
 },
 {
 "path": "20-seguimiento/2026-10-17-solicitud-cambio-cc-01.md",
 "date": "2026-10-17"
 },
 {
 "path": "20-seguimiento/2026-10-28-acta-recibo-sitios-construidos.pdf",
 "date": "2026-10-28"
 },
 {
 "path": "20-seguimiento/2026-10-28-informe-avance.md",
 "date": "2026-10-28"
 },
 {
 "path": "2026-10-28-notas-reunion.txt",
 "date": "2026-10-28"
 },
 {
 "path": "30-reuniones/2026-09-16-comite-semanal.md",
 "date": "2026-09-16"
 },
 {
 "path": "30-reuniones/2026-09-23-comite-semanal.md",
 "date": "2026-09-23"
 },
 {
 "path": "30-reuniones/2026-09-30-comite-semanal.md",
 "date": "2026-09-30"
 },
 {
 "path": "30-reuniones/2026-10-07-comite-semanal.md",
 "date": "2026-10-07"
 },
 {
 "path": "30-reuniones/2026-10-14-comite-semanal.md",
 "date": "2026-10-14"
 },
 {
 "path": "30-reuniones/2026-10-21-comite-semanal.md",
 "date": "2026-10-21"
 }
 ],
 "fields_not_found": [
 "identity.authority",
 "identity.phase",
 "vendors[0].invoiced"
 ],
 "open_conflicts": []
 }
}
