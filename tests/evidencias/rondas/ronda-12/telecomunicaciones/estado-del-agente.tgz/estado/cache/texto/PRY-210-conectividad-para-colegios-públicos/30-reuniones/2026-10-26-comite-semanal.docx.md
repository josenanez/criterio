<!-- origen: PRY-210-conectividad-para-colegios-públicos/30-reuniones/2026-10-26-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Cambios · Conectividad para colegios públicos

Fecha: 2026-10-26

Asistentes: Felipe Arango, Mauricio Pérez

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Natalia Ospina

Entregar el punto 16

por definir
