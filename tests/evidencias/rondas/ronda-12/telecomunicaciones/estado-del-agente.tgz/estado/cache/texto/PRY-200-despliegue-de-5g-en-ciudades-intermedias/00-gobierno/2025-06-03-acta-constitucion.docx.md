<!-- origen: PRY-200-despliegue-de-5g-en-ciudades-intermedias/00-gobierno/2025-06-03-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Despliegue de 5G en ciudades intermedias

Código: PRY-200

Área dueña: Mercadeo

Patrocinador: Natalia Ospina

Gerente de proyecto: Óscar Ramírez

Comité: Comité de Cambios

Producto asociado: planes 5G

Fecha de aprobación: 2025-06-03

Objetivo del negocio

Entregar despliegue de 5g en ciudades intermedias para Mercadeo.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

3.300.000.000 COP, aprobado por Comité de Cambios el 2025-06-03.

Fechas comprometidas

Fecha

Inicio

2025-06-13

Cierre

2025-12-19

Criterio de éxito

Despliegue de 5G en ciudades intermedias en producción y medido.

Dependencias declaradas

• Ninguna declarada
