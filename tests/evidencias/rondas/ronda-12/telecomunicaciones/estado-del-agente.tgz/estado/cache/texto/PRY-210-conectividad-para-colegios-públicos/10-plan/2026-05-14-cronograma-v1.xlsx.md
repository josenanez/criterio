<!-- origen: PRY-210-conectividad-para-colegios-públicos/10-plan/2026-05-14-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de red aprobado | 2026-08-18 | 2026-08-18 | cerrado
Permisos de instalación obtenidos | 2026-11-12 | 2026-11-12 | en curso
Sitios construidos | 2027-02-06 | 2027-02-06 | en curso
Integración con la red | 2027-05-03 | 2027-05-03 | en curso
Lanzamiento comercial | 2027-07-28 | 2027-07-28 | en curso
