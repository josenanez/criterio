<!-- origen: PRY-199-cambio-de-mobiliario-de-la-sala-de-espera/20-seguimiento/2026-10-26-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Cambio de mobiliario de la sala de espera
Código: PRY-199
Fecha de corte: 2026-10-26
Gerente: Andrés Lozano

Estado declarado
Verde
Avance reportado: 20%

Lo que pasó en el periodo
- La prueba de velocidad en campo no alcanzó el valor pactado y se repite
- Se acordó con operaciones cómo se miden las pruebas de aceptación de cada sitio

Presupuesto
COP
Aprobado 2.400.000.000
Comprometido 1.080.000.000
Ejecutado 720.000.000
Proyección al cierre 2.400.000.000

Riesgos abiertos
- Concentración del conocimiento en una sola persona
