<!-- origen: PRY-209-apagado-de-la-red-3g/20-seguimiento/2026-10-25-solicitud-cambio-cc-01.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-01

**Proyecto:** PRY-209 · Apagado de la red 3G
**Fecha:** 2026-10-25
**Solicitante:** Liliana Torres

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +82 días sobre la línea base vigente |
| Costo | 164.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
