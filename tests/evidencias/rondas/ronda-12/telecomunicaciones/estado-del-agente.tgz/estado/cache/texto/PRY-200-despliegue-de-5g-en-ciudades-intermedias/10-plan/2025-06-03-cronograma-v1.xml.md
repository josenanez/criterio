<!-- origen: PRY-200-despliegue-de-5g-en-ciudades-intermedias/10-plan/2025-06-03-cronograma-v1.xml · convertidor: project -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Cronograma · Microsoft Project · Cronograma

**Inicio:** — · **Fin:** — · **Fecha de estado:** —

## Tareas

| ID | EDT | Tarea | Inicio | Fin | Línea base: fin | Avance | Tipo | Predecesoras | Recursos |
|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | Diseño de red aprobado | 2025-07-20 | 2025-07-20 | 2025-07-20 | 100% | hito | — | — |
| 2 | 2 | Permisos de instalación obtenidos | 2025-08-27 | 2025-08-27 | 2025-08-27 | 100% | hito | 1FS | — |
| 3 | 3 | Sitios construidos | 2025-10-04 | 2025-10-04 | 2025-10-04 | 100% | hito | 2FS | — |
| 4 | 4 | Integración con la red | 2025-11-11 | 2025-11-11 | 2025-11-11 | 100% | hito | 3FS | — |
| 5 | 5 | Lanzamiento comercial | 2025-12-19 | 2025-12-19 | 2025-12-19 | 100% | hito | 4FS | — |

## Hitos

| Hito | Línea base | Vigente | Estado |
|---|---|---|---|
| Diseño de red aprobado | 2025-07-20 | 2025-07-20 | cerrado |
| Permisos de instalación obtenidos | 2025-08-27 | 2025-08-27 | cerrado |
| Sitios construidos | 2025-10-04 | 2025-10-04 | cerrado |
| Integración con la red | 2025-11-11 | 2025-11-11 | cerrado |
| Lanzamiento comercial | 2025-12-19 | 2025-12-19 | cerrado |
