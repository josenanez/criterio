<!-- origen: PRY-204-torres-compartidas-en-zonas-rurales/00-gobierno/2026-01-16-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Torres compartidas en zonas rurales

Código: PRY-204

Área dueña: Finanzas

Patrocinador: Beatriz Cuéllar

Gerente de proyecto: María Restrepo

Comité: Comité de Cambios

Producto asociado: arriendo de torres

Fecha de aprobación: 2026-01-16

Objetivo del negocio

Entregar torres compartidas en zonas rurales para Finanzas.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

9.500.000.000 COP, aprobado por Comité de Cambios el 2026-01-16.

Fechas comprometidas

Fecha

Inicio

2026-01-26

Cierre

2027-04-21

Criterio de éxito

Torres compartidas en zonas rurales en producción y medido.

Dependencias declaradas

• Ninguna declarada
