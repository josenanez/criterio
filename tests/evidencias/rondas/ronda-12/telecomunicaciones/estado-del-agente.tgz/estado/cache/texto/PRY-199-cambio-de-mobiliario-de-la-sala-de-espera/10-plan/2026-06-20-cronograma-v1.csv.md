<!-- origen: PRY-199-cambio-de-mobiliario-de-la-sala-de-espera/10-plan/2026-06-20-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño de red aprobado,2026-10-17,2026-10-17,cerrado
Permisos de instalación obtenidos,2027-02-03,2027-02-03,en curso
Sitios construidos,2027-05-23,2027-05-23,en curso
Integración con la red,2027-09-09,2027-09-09,en curso
Lanzamiento comercial,2027-12-27,2027-12-27,en curso
