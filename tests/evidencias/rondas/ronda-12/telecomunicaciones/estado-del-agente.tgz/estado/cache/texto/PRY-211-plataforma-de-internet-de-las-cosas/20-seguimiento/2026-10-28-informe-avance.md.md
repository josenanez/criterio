<!-- origen: PRY-211-plataforma-de-internet-de-las-cosas/20-seguimiento/2026-10-28-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Plataforma de internet de las cosas

**Código:** PRY-211
**Fecha de corte:** 2026-10-28
**Gerente:** Jorge Medina

## Estado declarado

**Amarillo**

Avance reportado: **49%**

## Lo que pasó en el periodo

- La prueba de velocidad en campo no alcanzó el valor pactado y se repite

## Presupuesto

| | COP |
|---|---|
| Aprobado | 3.300.000.000 |
| Comprometido | 1.710.711.399 |
| Ejecutado | 1.847.540.267 |
| Proyección al cierre | 3.037.162.738 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
