<!-- origen: PRY-208-red-privada-para-empresas/00-gobierno/2025-09-21-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Red privada para empresas

**Código:** PRY-208
**Área dueña:** Mercadeo
**Patrocinador:** María Restrepo
**Gerente de proyecto:** Felipe Arango
**Comité:** Comité de Cambios
**Producto asociado:** redes privadas
**Fecha de aprobación:** 2025-09-21

## Objetivo del negocio

Entregar red privada para empresas para Mercadeo.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**3.300.000.000 COP**, aprobado por Comité de Cambios el 2025-09-21.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-10-01 |
| Cierre | 2026-04-14 |

## Criterio de éxito

Red privada para empresas en producción y medido.

## Dependencias declaradas

- Ninguna declarada
