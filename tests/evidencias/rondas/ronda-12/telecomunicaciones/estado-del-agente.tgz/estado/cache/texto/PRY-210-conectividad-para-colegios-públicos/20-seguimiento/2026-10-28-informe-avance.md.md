<!-- origen: PRY-210-conectividad-para-colegios-públicos/20-seguimiento/2026-10-28-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Conectividad para colegios públicos

**Código:** PRY-210
**Fecha de corte:** 2026-10-28
**Gerente:** Felipe Arango

## Estado declarado

**Rojo**

Avance reportado: **50%**

## Lo que pasó en el periodo

- Se ajustó el plan de sitios con el proveedor de infraestructura
- La alcaldía detuvo la instalación de antenas en dos barrios durante diez días

## Presupuesto

| | COP |
|---|---|
| Aprobado | 3.300.000.000 |
| Comprometido | 1.565.215.894 |
| Ejecutado | 1.847.276.551 |
| Proyección al cierre | 3.951.444.314 |

## Riesgos abiertos

- Permisos municipales para instalar antenas
