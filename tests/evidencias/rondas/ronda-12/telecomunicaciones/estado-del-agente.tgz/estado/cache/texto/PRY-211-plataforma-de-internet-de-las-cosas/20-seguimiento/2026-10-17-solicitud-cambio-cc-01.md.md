<!-- origen: PRY-211-plataforma-de-internet-de-las-cosas/20-seguimiento/2026-10-17-solicitud-cambio-cc-01.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-01

**Proyecto:** PRY-211 · Plataforma de internet de las cosas
**Fecha:** 2026-10-17
**Solicitante:** Jorge Medina

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +102 días sobre la línea base vigente |
| Costo | 204.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
