<!-- origen: PRY-209-apagado-de-la-red-3g/00-gobierno/2026-03-14-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Apagado de la red 3G

Código: PRY-209

Área dueña: Despliegue

Patrocinador: Jorge Medina

Gerente de proyecto: Liliana Torres

Comité: Comité de Cambios

Producto asociado: No aplica

Fecha de aprobación: 2026-03-14

Objetivo del negocio

Entregar apagado de la red 3g para Despliegue.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

18.000.000.000 COP, aprobado por Comité de Cambios el 2026-03-14.

Fechas comprometidas

Fecha

Inicio

2026-03-24

Cierre

2027-01-20

Criterio de éxito

Apagado de la red 3G en producción y medido.

Dependencias declaradas

• Ninguna declarada
