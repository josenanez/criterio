<!-- origen: PRY-202-modernización-de-la-red-de-transporte/00-gobierno/2025-07-08-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Modernización de la red de transporte

**Código:** PRY-202
**Área dueña:** Compras
**Patrocinador:** Ricardo Salas
**Gerente de proyecto:** Carlos Peña
**Comité:** Comité de Cambios
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-07-08

## Objetivo del negocio

Entregar modernización de la red de transporte para Compras.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**4.200.000.000 COP**, aprobado por Comité de Cambios el 2025-07-08.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-07-18 |
| Cierre | 2026-03-18 |

## Criterio de éxito

Modernización de la red de transporte en producción y medido.

## Dependencias declaradas

- Ninguna declarada
