<!-- origen: PRY-203-migración-del-core-de-voz-a-la-nube/00-gobierno/2025-11-30-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Migración del core de voz a la nube

Código: PRY-203

Área dueña: Mercadeo

Patrocinador: Javier Hoyos

Gerente de proyecto: Mauricio Pérez

Comité: Comité de Inversiones

Producto asociado: No aplica

Fecha de aprobación: 2025-11-30

Objetivo del negocio

Entregar migración del core de voz a la nube para Mercadeo.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

1.200.000.000 COP, aprobado por Comité de Inversiones el 2025-11-30.

Fechas comprometidas

Fecha

Inicio

2025-12-10

Cierre

2026-11-27

Criterio de éxito

Migración del core de voz a la nube en producción y medido.

Dependencias declaradas

• Ninguna declarada
