<!-- origen: PRY-206-centro-de-operaciones-de-red-unificado/00-gobierno/2026-03-18-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Centro de operaciones de red unificado

Código: PRY-206

Área dueña: Seguridad de la información

Patrocinador: Diana Molina

Gerente de proyecto: Javier Hoyos

Comité: Comité de Producto

Producto asociado: No aplica

Fecha de aprobación: 2026-03-18

Objetivo del negocio

Entregar centro de operaciones de red unificado para Seguridad de la información.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

4.200.000.000 COP, aprobado por Comité de Producto el 2026-03-18.

Fechas comprometidas

Fecha

Inicio

2026-03-28

Cierre

2027-09-14

Criterio de éxito

Centro de operaciones de red unificado en producción y medido.

Dependencias declaradas

• Ninguna declarada
