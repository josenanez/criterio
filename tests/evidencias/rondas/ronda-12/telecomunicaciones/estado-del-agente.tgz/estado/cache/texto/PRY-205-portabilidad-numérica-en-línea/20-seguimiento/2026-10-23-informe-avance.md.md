<!-- origen: PRY-205-portabilidad-numérica-en-línea/20-seguimiento/2026-10-23-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Portabilidad numérica en línea

**Código:** PRY-205
**Fecha de corte:** 2026-10-23
**Gerente:** Diana Molina

## Estado declarado

**Rojo**

Avance reportado: **48%**

## Lo que pasó en el periodo

- Se recibió el concepto del regulador sobre el uso del espectro
- Se reprogramó la llegada de los equipos de radio por demoras en la aduana

## Presupuesto

| | COP |
|---|---|
| Aprobado | 9.500.000.000 |
| Comprometido | 6.628.351.364 |
| Ejecutado | 1.749.683.488 |
| Proyección al cierre | 9.295.399.324 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
