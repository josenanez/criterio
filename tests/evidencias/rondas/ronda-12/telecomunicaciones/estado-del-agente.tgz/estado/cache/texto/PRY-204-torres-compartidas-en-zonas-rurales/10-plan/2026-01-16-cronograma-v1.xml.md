<!-- origen: PRY-204-torres-compartidas-en-zonas-rurales/10-plan/2026-01-16-cronograma-v1.xml · convertidor: project -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Cronograma · Microsoft Project · Cronograma

**Inicio:** — · **Fin:** — · **Fecha de estado:** —

## Tareas

| ID | EDT | Tarea | Inicio | Fin | Línea base: fin | Avance | Tipo | Predecesoras | Recursos |
|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | Diseño de red aprobado | 2026-06-25 | 2026-06-25 | 2026-06-25 | 100% | hito | — | — |
| 2 | 2 | Permisos de instalación obtenidos | 2026-11-22 | 2026-11-22 | 2026-11-22 | 50% | hito | 1FS | — |
| 3 | 3 | Sitios construidos | 2027-04-21 | 2027-04-21 | 2027-04-21 | 50% | hito | 2FS | — |

## Hitos

| Hito | Línea base | Vigente | Estado |
|---|---|---|---|
| Diseño de red aprobado | 2026-06-25 | 2026-06-25 | cerrado |
| Permisos de instalación obtenidos | 2026-11-22 | 2026-11-22 | en curso |
| Sitios construidos | 2027-04-21 | 2027-04-21 | en curso |
