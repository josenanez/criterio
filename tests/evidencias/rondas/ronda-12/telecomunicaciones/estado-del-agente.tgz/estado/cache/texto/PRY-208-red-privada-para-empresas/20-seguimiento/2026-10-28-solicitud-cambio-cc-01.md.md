<!-- origen: PRY-208-red-privada-para-empresas/20-seguimiento/2026-10-28-solicitud-cambio-cc-01.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-01

**Proyecto:** PRY-208 · Red privada para empresas
**Fecha:** 2026-10-28
**Solicitante:** Felipe Arango

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +76 días sobre la línea base vigente |
| Costo | 152.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
