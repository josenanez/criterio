<!-- origen: PRY-199-cambio-de-mobiliario-de-la-sala-de-espera/00-gobierno/2026-06-20-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Cambio de mobiliario de la sala de espera

**Código:** PRY-199
**Área dueña:** Ingeniería de red
**Patrocinador:** María Restrepo
**Gerente de proyecto:** Andrés Lozano
**Comité:** Comité de Red
**Producto asociado:** PRD-299
**Fecha de aprobación:** 2026-06-20

## Objetivo del negocio

Entregar cambio de mobiliario de la sala de espera para Ingeniería de red.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**2.400.000.000 COP**, aprobado por Comité de Red el 2026-06-20.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-06-30 |
| Cierre | 2027-12-27 |

## Criterio de éxito

Cambio de mobiliario de la sala de espera en producción y medido.

## Dependencias declaradas

- Ninguna declarada
