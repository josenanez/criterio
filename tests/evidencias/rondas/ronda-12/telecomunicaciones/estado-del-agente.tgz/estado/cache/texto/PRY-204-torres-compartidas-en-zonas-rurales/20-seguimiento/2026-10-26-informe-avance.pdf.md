<!-- origen: PRY-204-torres-compartidas-en-zonas-rurales/20-seguimiento/2026-10-26-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Torres compartidas en zonas rurales
Código: PRY-204
Fecha de corte: 2026-10-26
Gerente: María Restrepo

Estado declarado
Rojo
Avance reportado: 38%

Lo que pasó en el periodo
- Se recibió el concepto del regulador sobre el uso del espectro

Presupuesto
COP
Aprobado 9.500.000.000
Comprometido 3.724.858.243
Ejecutado 2.903.191.099
Proyección al cierre 9.916.556.237

Riesgos abiertos
- El proveedor no ha confirmado la fecha de la última entrega
- Subasta de espectro aplazada por el regulador
