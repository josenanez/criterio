<!-- origen: PRY-200-despliegue-de-5g-en-ciudades-intermedias/20-seguimiento/2025-08-14-acta-recibo-ct-478-suministro-de-antenas-y-radios.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de recibo · Suministro de antenas y radios
Proyecto: PRY-200 · Despliegue de 5G en ciudades intermedias
Fecha de recibo: 2025-08-14
Recibido por: Óscar Ramírez
Se recibe a satisfacción el entregable Suministro de antenas y radios.
Contrato CT-478 · Fibra Óptica del Pacífico S.A.S..
