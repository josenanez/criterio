<!-- origen: PRY-209-apagado-de-la-red-3g/30-reuniones/2026-10-25-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Cambios · Apagado de la red 3G

Fecha: 2026-10-25

Asistentes: Liliana Torres, Jorge Medina

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Jorge Medina

Entregar el punto 35

2026-11-03
