<!-- origen: PRY-206-centro-de-operaciones-de-red-unificado/20-seguimiento/2026-08-02-acta-recibo-ct-381-suministro-de-antenas-y-radios.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de recibo · Suministro de antenas y radios

**Proyecto:** PRY-206 · Centro de operaciones de red unificado
**Fecha de recibo:** 2026-08-02
**Recibido por:** Javier Hoyos

Se recibe a satisfacción el entregable **Suministro de antenas y radios**.

Contrato CT-381 · Redes y Radio Andinas Ltda..
