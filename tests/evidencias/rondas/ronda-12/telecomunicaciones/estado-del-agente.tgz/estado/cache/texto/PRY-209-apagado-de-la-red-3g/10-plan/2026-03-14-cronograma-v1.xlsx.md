<!-- origen: PRY-209-apagado-de-la-red-3g/10-plan/2026-03-14-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de red aprobado | 2026-05-23 | 2026-05-23 | cerrado
Permisos de instalación obtenidos | 2026-07-23 | 2026-07-23 | cerrado
Sitios construidos | 2026-09-21 | 2026-09-21 | cerrado
Integración con la red | 2026-11-21 | 2026-11-21 | en curso
Lanzamiento comercial | 2027-01-20 | 2027-01-20 | en curso
