<!-- origen: PRY-210-conectividad-para-colegios-públicos/20-seguimiento/2026-10-27-solicitud-cambio-cc-01.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-01

**Proyecto:** PRY-210 · Conectividad para colegios públicos
**Fecha:** 2026-10-27
**Solicitante:** Felipe Arango

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +110 días sobre la línea base vigente |
| Costo | 220.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
