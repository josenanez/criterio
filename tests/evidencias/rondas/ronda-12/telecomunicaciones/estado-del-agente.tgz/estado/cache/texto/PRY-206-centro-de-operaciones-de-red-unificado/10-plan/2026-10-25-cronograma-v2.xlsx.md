<!-- origen: PRY-206-centro-de-operaciones-de-red-unificado/10-plan/2026-10-25-cronograma-v2.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de red aprobado | 2026-07-13 | 2026-07-13 | cerrado
Permisos de instalación obtenidos | 2026-10-28 | 2026-10-28 | en curso
Sitios construidos | 2027-02-12 | 2027-02-12 | en curso
Integración con la red | 2027-05-30 | 2027-05-30 | en curso
Lanzamiento comercial | 2027-09-14 | 2027-12-16 | en curso
