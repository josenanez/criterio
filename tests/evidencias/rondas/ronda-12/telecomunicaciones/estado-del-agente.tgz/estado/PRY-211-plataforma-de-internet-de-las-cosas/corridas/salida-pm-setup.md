## Listo — PRY-211 · Plataforma de internet de las cosas

Sesión sin interfaz: tomé la respuesta sugerida en cada pregunta.
- Proyecto y gerente: PRY-211, Jorge Medina, según el acta de constitución del 2026-01-05.
- Reunión de seguimiento: los miércoles, que es el día de las minutas. Las notas del 2026-10-28 dicen que la próxima es en dos semanas (2026-11-11), y la configuración ya trae esa fecha.
- Estado: `estado/PRY-211-plataforma-de-internet-de-las-cosas`, fuera de la carpeta de documentación y de `.criterio/`.
- Marca de la carpeta: dejé `_CRITERIO_PROYECTO.txt`, a nombre de José Francisco Ñáñez.

**Lo que miré:** 16 documentos · 6 minutas del comité semanal (2026-09-16 a 2026-10-21) y las notas del 2026-10-28 · la más reciente es del 2026-10-28. Leí todas las minutas, de la más vieja a la más nueva. Los 16 formatos se pudieron leer: md, pdf, xlsx y docx.

**Términos:** aceptados para la versión 0.12.1, a nombre de José Francisco Ñáñez, fecha 2026-10-28. La configuración ya traía esa aceptación y el script la da por vigente, así que no la registré de nuevo. Comprobante en `.criterio/terminos/aceptacion-criterio-project-0.12.1-2026-10-28.md` y `.pdf` · SHA-256 `999c8302506aa7d1`… (el del PDF).

Resumen de los términos, tal cual: *Criterio produce borradores de trabajo, no decisiones ni asesoría. Procesa los documentos que usted le indique y dice lo que muestran; no sabe lo que se habló fuera de ellos. Puede equivocarse, y por eso cada dato viene con la cita del documento de donde salió: la verificación es suya. Sus documentos se procesan en la infraestructura de la plataforma de IA, no solo en su equipo. Cada versión se prueba antes de publicarse; garantía y responsabilidad: licencia Apache 2.0. Cada versión se acepta de nuevo y deja un comprobante en Markdown y PDF con su huella SHA-256.* Nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal

### Lo que está abierto, y cuántas veces se ha movido

Son 26 compromisos en total: 25 abiertos o vencidos y 1 cerrado con acta. Los 7 que `compute` marca como reprogramados:

| Quién | Qué | Primera promesa | Fecha vigente | Veces movido |
|---|---|---|---|---|
| Gustavo Neira | Enviar el documento 1 | 2026-09-20 | 2026-12-26 | **6** |
| Javier Hoyos | Cerrar la prueba 2 | 2026-10-02 | 2026-12-12 | **5** |
| Camilo Beltrán | Actualizar la matriz 6 | 2026-10-16 | 2026-12-09 | **4** |
| Camilo Beltrán | Confirmar la fecha 7 | 2026-10-08 | 2026-12-12 | **4** |
| Rubén Cárdenas | Revisar el anexo 3 | 2026-10-05 | 2026-11-25 | **3** |
| Ricardo Salas | Aprobar el diseño 5 | 2026-10-15 | 2026-11-17 | **3** |
| Ricardo Salas | Entregar el punto 8 | 2026-10-20 | 2026-11-23 | **3** |

Citas: la primera promesa está en la minuta de la primera reunión donde aparece, y cada movimiento en la minuta que lo trae (`30-reuniones/2026-MM-DD-comite-semanal.md`). La última fecha de Gustavo Neira sale de `2026-10-28-notas-reunion.txt`: «lo de "enviar el documento 1" no alcanzó, se compromete para el 26/12/2026».

**Vencidos sin evidencia al 2026-10-28** (6):

| Quién | Qué | Para | Días |
|---|---|---|---|
| Felipe Arango | Confirmar la fecha 15 | 2026-10-19 | 9 |
| Felipe Arango | Validar el ambiente 20 | 2026-10-21 | 7 |
| Jorge Medina | Enviar el documento 17 | 2026-10-22 | 6 |
| Beatriz Cuéllar | Cerrar la prueba 18 | 2026-10-22 | 6 |
| Sandra Gil | Actualizar la matriz 22 | 2026-10-24 | 4 |
| Elena Duarte | Entregar el punto 24 | 2026-10-24 | 4 |

Citas: minutas del 2026-10-07 (15), 2026-10-14 (17, 18, 20) y 2026-10-21 (22, 24).

**Dicho pero sin acta:** el 2026-10-21 Carlos Peña dice que ya entregó «aprobar el diseño 13» y no se presentó acta. Lo dejé abierto, con fecha 2026-11-03.

**Cerrado con acta:** «Validar el ambiente 12» (Liliana Torres), acta de recibo del 2026-10-07.

### Sin fecha
- Laura Vélez: mandar el ajuste del presupuesto. Dijo «la otra semana», y eso no es una fecha. Cita: `2026-10-28-notas-reunion.txt`. No puede estar vencido, y por eso mismo es el que desaparece de los informes.

### Otras señales que levantó el cálculo
- **Fecha de cierre:** el cronograma vigente (2026-11-05) está 102 días después de la original (2026-07-26), que es el 53,1 %. La solicitud CC-01 pide +102 días y 204.000.000 COP, y sigue «pendiente de presentación al comité».
- **Avance declarado contra el plan:** Jorge Medina declara amarillo y 49 %. El cronograma declara los 5 hitos como cerrados, y eso da 51 puntos de diferencia. Cada uno de los dos números dice cosas distintas y no tomo partido.
- **Hitos cerrados sin acta:** «Diseño de red aprobado» (2026-02-22) e «Integración con la red» (2026-06-18). Hay acta de recibo solo para «Permisos de instalación obtenidos» y «Sitios construidos».
- **Proveedor (CT-707, Obras Civiles de Telecomunicaciones):** «Suministro de antenas y radios» (2026-03-26, 216 días) y «Bolsa de horas de ingeniería» (2026-06-05, 145 días) siguen pendientes según el contrato, sin acta de recibo.
- **Dicho en la reunión y no anotado:** que el proveedor podría no llegar con el equipo completo a la siguiente fase. Las notas dicen que nadie lo anotó como riesgo; lo registré en la ficha con esa marca.

### Qué le falta a tu carpeta
- Actas de recibo de los hitos «Diseño de red aprobado», «Integración con la red» y «Lanzamiento comercial», y de los dos entregables del proveedor.
- Una minuta con el mismo formato para el 2026-10-28: hoy son notas sueltas en la raíz del proyecto, fuera de `30-reuniones/`.
- En el acta de constitución: el alcance (hoy «Componente 1, 2, 3»), la autoridad del gerente, la fase y las dependencias. Quedaron como no encontrados.
- Lo facturado al proveedor, que no aparece en ningún documento.
- Estructura recomendada de `document-intake` como sugerencia: no moví, renombré ni creé nada dentro de tus documentos, salvo la marca de la carpeta.

**Cuándo vuelvo:** el miércoles 2026-11-11, que es la próxima reunión según las notas.
