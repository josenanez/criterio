## PRY-211 Plataforma de internet de las cosas · 2026-10-28

**Revisé:** 17 documentos · 17 aparecen como nuevos o cambiados porque es el primer barrido de esta carpeta (el índice no tenía historia), no porque hayan cambiado hoy · 0 minutas sin procesar: las 6 actas del comité y las notas de hoy ya estaban en la ficha desde `/pm-setup`, así que no extraje nada nuevo ni toqué la ficha.

### Lo que se venció solo
Nada cruzó un umbral desde la corrida de hoy. El estado de compromisos sigue siendo el que ya está en la ficha: 6 vencidos sin evidencia (Felipe Arango ×2, Jorge Medina, Beatriz Cuéllar, Sandra Gil, Elena Duarte), 7 reprogramados tres veces o más, 1 sin fecha (Laura Vélez).
Lo único que toca vigilar: **«Cerrar la prueba 10» (Gustavo Neira) vence hoy** y las notas de hoy no lo mencionan; si mañana no hay evidencia, entra a vencidos. Mañana también vence el punto 16 (Jorge Medina) y la fecha 23 (Camilo Beltrán), ambos el 2026-10-30.

### La reunión
Próximo comité el 2026-11-11, faltan 14 días: no toca agenda todavía. El informe toca el 2026-11-10. La agenda del 11-11 ya existe de hoy, no la vuelvo a ofrecer. Acta de la reunión de hoy: no hace falta; hay notas y ya están procesadas.

### Tu ficha publicada
Al día: `/pm-publish` corrió hoy después del último cambio de la ficha.

**Vuelvo el 2026-10-29.**
