Términos vigentes (v1.3, aceptados por José Francisco Ñáñez el 2026-10-28 para esta prueba, comprobante en `.criterio/terminos/`); no hizo falta mostrarlos de nuevo. Sin tope de tiempo en el argumento: tomo 45 minutos como respuesta sugerida. Reunión: 2026-11-11, `cycle.committee_next`. Los datos están al 2026-10-28; hay que recalcular los días de atraso cerca de la reunión.

## Reunión de seguimiento — PRY-211 Plataforma de internet de las cosas · 2026-11-11
11 puntos · 45 minutos · 13 personas requeridas (Neira, Hoyos, Beltrán, Cárdenas, Salas, Arango, Medina, Cuéllar, Gil, Duarte, Peña, Ramírez, Vélez)

### Lo que no se destraba solo

> **[1] Que se nombre qué bloquea «Enviar el documento 1» y se fije una fecha que Gustavo Neira pueda sostener, o que se decida quién lo releva** · 8 min · **Gustavo Neira, con Ricardo Salas (patrocinador)**
> Prometido para el 2026-12-26, y antes para el 12-12, el 11-29, el 11-10, el 10-20, el 10-02 y el 09-20 originalmente. Seis reprogramaciones. Hoy dijo que «no alcanzó» sin decir qué. La fecha cae después del cierre del cronograma v2 (2026-11-05).
> Fuente: `30-reuniones/2026-09-16-comite-semanal.md` (origen) hasta `2026-10-28-notas-reunion.txt`, línea 4
> **Si no se resuelve hoy:** la fecha vuelve a correrse y el documento sigue sin llegar a su destino. Lo único que el tiempo empeora es esto.

> **[2] Que se defina qué se hace con la prueba de velocidad en campo y quién cierra «la prueba 2»** · 7 min · **Javier Hoyos**
> Prometido para el 2026-10-02, y antes para el 10-09, el 10-28 (ya pasó), el 11-08 y el 11-22; hoy dice el 12-12. Cinco reprogramaciones. El informe de avance de hoy dice que la prueba de velocidad en campo no alcanzó el valor pactado y se repite; la incidencia no tiene dueño en la ficha. Las notas de hoy no mencionan este compromiso.
> Fuente: `30-reuniones/2026-09-16-comite-semanal.md` a `2026-10-21-comite-semanal.md`; `20-seguimiento/2026-10-28-informe-avance.md`
> **Si no se resuelve hoy:** el cierre de la prueba queda fuera de toda fecha del cronograma y la incidencia sigue sin dueño.

> **[3] Que Camilo Beltrán confirme una sola fecha para «la matriz 6» y «la fecha 7»** · 5 min · **Camilo Beltrán**
> Matriz 6: prometida para el 2026-10-16, y antes para el 10-24, el 11-06 y el 11-25; hoy dice el 12-09. Fecha 7: prometida para el 10-08, y antes para el 10-21, el 11-03 y el 11-21; hoy dice el 12-12. Cuatro reprogramaciones cada una, con las fechas corriéndose juntas.
> Fuente: `30-reuniones/2026-09-23-comite-semanal.md` a `2026-10-21-comite-semanal.md`
> **Si no se resuelve hoy:** el patrón de las dos fechas corridas en bloque sigue sin explicación.

> **[4] Que los compromisos reprogramados tres veces de Rubén Cárdenas y Ricardo Salas queden con fecha firme o pasen a decisión** · 5 min · **Rubén Cárdenas, Ricardo Salas**
> Anexo 3 (Cárdenas): 2026-10-05 → 10-24 → 11-06 → 11-25. Diseño 5 (Salas): 10-15 → 10-24 → 11-01 → 11-17. Punto 8 (Salas): 10-20 → 11-05 → 11-12 → 11-23. Tres reprogramaciones cada uno. Dos de ellos son del patrocinador, que va a estar.
> Fuente: `30-reuniones/2026-09-23-comite-semanal.md` a `2026-10-21-comite-semanal.md`
> **Si no se resuelve hoy:** el diseño 5 y el punto 8 siguen con fecha posterior al cierre del cronograma.

### Vencido sin evidencia
| Quién | Qué | Desde | Qué se necesita hoy | Min |
|---|---|---|---|---|
| Gustavo Neira | Cerrar la prueba 10 | 2026-10-28 | Documento de cierre o fecha nueva; las notas de hoy no lo mencionan | 1 |
| Felipe Arango | Confirmar la fecha 15 | 2026-10-19 | Fecha confirmada o razón; nunca se reprogramó | 1 |
| Felipe Arango | Validar el ambiente 20 | 2026-10-21 | Acta de validación o fecha; nunca se reprogramó | 1 |
| Jorge Medina | Enviar el documento 17 | 2026-10-22 | Documento enviado o fecha | 1 |
| Beatriz Cuéllar | Cerrar la prueba 18 | 2026-10-22 | Acta de cierre o fecha | 1 |
| Sandra Gil | Actualizar la matriz 22 | 2026-10-24 | Matriz actualizada o fecha | 1 |
| Elena Duarte | Entregar el punto 24 | 2026-10-24 | Entrega o fecha | 1 |
| Carlos Peña | Aprobar el diseño 13 (vence el 11-03) | dijo el 10-21 que ya lo entregó | El acta que lo respalde; no se presentó y dejó de aparecer en la tabla de abiertos | 1 |

Fuente de cada uno: `30-reuniones/2026-09-30-comite-semanal.md`, `2026-10-07-comite-semanal.md`, `2026-10-14-comite-semanal.md` y `2026-10-21-comite-semanal.md`, según el compromiso. Los de Neira, Arango, Medina, Cuéllar, Gil y Duarte vencieron antes del 10-28; el de Peña vence el 11-03.

### Se decide hoy o se atrasa
| Qué | Quién decide | Si no se decide | Min |
|---|---|---|---|
| CC-01: ampliación de alcance, +102 días sobre la línea base vigente y 204.000.000 COP adicionales; «pendiente de presentación al comité» desde el 2026-10-17 (`20-seguimiento/2026-10-17-solicitud-cambio-cc-01.md`). La autoridad que lo aprueba no está en la ficha (`identity.authority`: no encontrada) | Comité de Inversiones, con Ricardo Salas; si esta reunión no es ese comité, pasa a «No es de esta reunión» | Las fechas posteriores al cierre del 2026-11-05 siguen sin línea base que las cubra | 5 |
| Contrato CT-707 (Obras Civiles de Telecomunicaciones): suministro de antenas y radios (2026-03-26, 216 días) y bolsa de horas de ingeniería (2026-06-05, 145 días), ambos sin recibo. Lo facturado no está en el expediente (`vendors[0].invoiced` no encontrado). El responsable por parte del proyecto no está dicho; propongo a Óscar Ramírez por su revisión con el proveedor del 11-07, y es inferencia mía | Quien tenga la autoridad del contrato; no está dicho | Dos entregables vencidos siguen sin aceptación ni rechazo | 4 |
| Registrar como riesgo «el proveedor podría no llegar con el equipo completo para la siguiente fase», con dueño (`registered: false`, nadie lo anotó; las notas no dicen quién lo dijo ni a qué fase se refiere) (`2026-10-28-notas-reunion.txt`, línea 7) | Jorge Medina | Sigue fuera del registro; el informe de avance solo lista la concentración del conocimiento | 2 |
| Laura Vélez: «mandar el ajuste del presupuesto la otra semana», sin fecha (`2026-10-28-notas-reunion.txt`, línea 5). Que quede una fecha | Laura Vélez | Sigue sin poder vencerse | 1 |

### Vence antes de la próxima
| Quién | Qué | Para cuándo |
|---|---|---|
| Jorge Medina | Entregar el punto 16 | 2026-10-30 (reprogramado una vez, desde el 10-17) |
| Camilo Beltrán | Confirmar la fecha 23 | 2026-10-30 |
| Carlos Peña | Validar el ambiente 4 | 2026-11-03 (reprogramado una vez) |
| Carlos Peña | Aprobar el diseño 13 | 2026-11-03 (ver «Vencido sin evidencia») |
| Diana Molina | Revisar el anexo 19 | 2026-11-03 (reprogramado una vez) |
| Natalia Ospina | Aprobar el diseño 21 | 2026-11-06 |
| Óscar Ramírez | Revisión con el proveedor | 2026-11-07 |
| Natalia Ospina | Actualizar la matriz 14 | 2026-11-08 (reprogramado una vez) |

Los que no tengan evidencia para el 11-11 pasan a «Vencido sin evidencia» en esa fecha.

### No es de esta reunión
| Qué | Por qué | Dónde va |
|---|---|---|
| Hitos «Integración con la red», «Diseño de red aprobado» y «Lanzamiento comercial» figuran como cumplidos en el cronograma v2 sin documento de evidencia | Es de contraste de estado, no de una persona en la sala | `/pm-report` |
| Compromisos de Neira (12-26), Hoyos (12-12) y otros que caen después del cierre del cronograma v2 (2026-11-05) | Si el cierre no se mueve, es decisión de línea base, no de seguimiento | CC-01 y `/pm-commitments` para formularlo; subir a comité si excede la autoridad del gerente |
| Cadencia: la reunión de hoy dijo «próxima reunión en dos semanas» y la configuración dice comité semanal (próximo 11-11) | Hay que confirmar si el 11-11 es la fecha y si es semanal | Jorge Medina, antes de convocar |

### Anexo — sin cambios desde el [fecha]
No hay anexo: esta es la primera corrida sobre este proyecto y `diff` no tiene reunión anterior con la que comparar (`baseline_run`). Lo único cerrado en la ficha es «Validar el ambiente 12» (Liliana Torres), contra `20-seguimiento/2026-10-07-acta-recibo-12.md`.

Quedaron fuera por tiempo: ninguno. La suma es 45 minutos.
