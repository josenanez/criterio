# PRY-211 Plataforma de internet de las cosas — corte al 2026-10-28

> Sesión sin interfaz: no hubo a quién preguntarle la declaración. Se usa la que el gerente (Jorge Medina) ya dejó escrita en su informe de avance de hoy, `20-seguimiento/2026-10-28-informe-avance.md`. El agente no declara ni sugiere estado.

**Declara el gerente:** Amarillo · 49% · al 2026-10-28 (declaración de hoy, no vencida)
**Sustento documental:** sin sustento en el avance. El plan da 5 de 5 hitos cumplidos (100%) contra el 49% declarado, una brecha de 51 puntos. 2 de esos hitos no tienen evidencia. No hay documentos marcados como evidencia: 0 de evidencia, 5 de declaración, 191 sin marcar.
**Lo que el semáforo no explica:** atraso de tiempo (102 días, 53,1% contra la línea base original), avance contra plan, hitos «cumplidos» sin evidencia, compromisos vencidos, compromisos reprogramados y entregables de proveedor vencidos.

## Qué cambió esta semana
No hay comparación posible. Esta es la primera corrida de `pm-report` y el único snapshot es el de hoy, así que el diff contra la corrida anterior sale vacío (0 cambios). Esa ausencia no significa que no haya cambiado nada. Desde la próxima corrida este apartado compara contra el snapshot de hoy.

## Lo que sigue igual y sigue mal
Sin corrida anterior no se pueden contar los «días así» del informe. Estas son las desviaciones abiertas hoy, con la antigüedad que sí se puede medir.

| Qué | Desde | Días así |
|---|---|---|
| Entregable de proveedor «Suministro de antenas y radios» (CT-707), pendiente | vencía 2026-03-26 | 216 |
| Entregable de proveedor «Bolsa de horas de ingeniería» (CT-707), pendiente | vencía 2026-06-05 | 145 |
| Hito «Diseño de red aprobado» marcado cumplido sin evidencia | vencía 2026-02-22 | 248 |
| Hito «Integración con la red» marcado cumplido sin evidencia | vencía 2026-06-18 | 132 |
| Cierre contra la línea base original | 2026-07-26 | 102 |

## Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2026-07-26 | 2026-11-05 | +102 días (53,1%) contra la original y contra la vigente |
| Presupuesto | 3.300.000.000 COP aprobado | proyección 3.037.162.738 COP | −8,0% bajo lo aprobado |

Replanificaciones registradas: 0. Hay una sola línea base (v1, aprobada el 2026-01-05, cierre 2026-07-26). El cierre vigente (2026-11-05) está 102 días después y no hay una línea base nueva que lo respalde. Hay una solicitud de cambio, CC-01 (`2026-10-17-solicitud-cambio-cc-01.md`), con 0 días de tiempo aprobados y 0 sin autorizar. Por eso las desviaciones contra la original y contra la vigente salen iguales (102 días). El corrimiento no está registrado como replanificación.

### Hitos de las próximas cuatro semanas
| Hito | Base | Vigente | Evidencia |
|---|---|---|---|
| Lanzamiento comercial | 2026-07-26 | 2026-11-05 | No. Está marcado «cumplido» con la fecha en el futuro y sin evidencia. |

Hitos anteriores: «Permisos de instalación obtenidos» (2026-04-02) y «Sitios construidos» (2026-05-10) cumplidos con evidencia. «Diseño de red aprobado» e «Integración con la red» están marcados cumplidos sin evidencia.

## Las cifras
| Aprobado | Comprometido | Ejecutado | Proyectado | Disponible real |
|---|---|---|---|---|
| 3.300.000.000 | 1.710.711.399 (51,8%) | 1.847.540.267 (56,0%) | 3.037.162.738 | 1.589.288.601 |

El disponible real es aprobado menos comprometido. Ojo: lo ejecutado (1.847.540.267) supera lo comprometido (1.710.711.399) en 136.828.868 COP. Ejecutar más de lo que se comprometió es inconsistente y lo tiene que explicar quien lleva el presupuesto.

## Abierto
**Reprogramados, desde la peor:**
- Gustavo Neira, «Enviar el documento 1»: 6 veces. Original 2026-09-20, hoy 2026-12-26.
- Javier Hoyos, «Cerrar la prueba 2»: 5 veces. Original 2026-10-02, hoy 2026-12-12.
- Camilo Beltrán, «Actualizar la matriz 6»: 4 veces. Original 2026-10-16, hoy 2026-12-09.
- Camilo Beltrán, «Confirmar la fecha 7»: 4 veces. Original 2026-10-08, hoy 2026-12-12.
- Rubén Cárdenas, «Revisar el anexo 3»: 3 veces. Original 2026-10-05, hoy 2026-11-25.
- Ricardo Salas, «Aprobar el diseño 5»: 3 veces. Original 2026-10-15, hoy 2026-11-17.
- Ricardo Salas, «Entregar el punto 8»: 3 veces. Original 2026-10-20, hoy 2026-11-23.

Todos llegan al umbral de 3 reprogramaciones.

**Vencidos sin evidencia:**
- Felipe Arango, «Confirmar la fecha 15»: 9 días (2026-10-19, comité del 10-07).
- Felipe Arango, «Validar el ambiente 20»: 7 días (2026-10-21, comité del 10-14).
- Jorge Medina, «Enviar el documento 17»: 6 días (2026-10-22, comité del 10-14).
- Beatriz Cuéllar, «Cerrar la prueba 18»: 6 días (2026-10-22, comité del 10-14).
- Sandra Gil, «Actualizar la matriz 22»: 4 días (2026-10-24, comité del 10-21).
- Elena Duarte, «Entregar el punto 24»: 4 días (2026-10-24, comité del 10-21).

**Sin fecha:** Laura Vélez, «Mandar el ajuste del presupuesto» (notas del 2026-10-28).

**RAID sin movimiento:** la ficha no trae RAID con días sin movimiento. El informe de hoy declara un solo riesgo: concentración del conocimiento en una sola persona.

**Proveedor (Obras Civiles de Telecomunicaciones, CT-707):** 2 entregables, 0 aceptados, 2 vencidos y pendientes (antenas y radios, 216 días; bolsa de horas de ingeniería, 145 días). Aceptados sin documento: ninguno. Facturado: sin dato.

## Lo que necesito de alguien
- **Jorge Medina:** declarar si el amarillo sigue vigente a la vista de las señales de arriba. Registrar la replanificación al 2026-11-05, o decir por qué no hay línea base nueva.
- **Quien lleve el presupuesto:** explicar por qué lo ejecutado supera lo comprometido en 136.828.868 COP.
- **Gustavo Neira y Javier Hoyos:** fecha firme o decisión sobre sus compromisos, que llevan 6 y 5 reprogramaciones. **Esto excede al gerente y es material de comité:** CT-707 con dos entregables vencidos y sin aceptar, y la reprogramación repetida de compromisos. Se ofrece armar el punto de comité con la decisión formulada. El próximo comité es el 2026-11-11.
- **Quien tenga la evidencia:** documentos de sustento para «Diseño de red aprobado», «Integración con la red» y «Lanzamiento comercial».

## Lo que no se sabe
**Sin dato:** autoridad de aprobación del proyecto (`identity.authority`), fase (`identity.phase`) y monto facturado al proveedor (`vendors[0].invoiced`).
**Silencio:** último documento hace 0 días · última reunión hace 0 días. No hay silencio. El problema es que lo escrito no sustenta lo reportado.

---
Fuente: ficha `PRY-211.json`, cálculo y snapshot del 2026-10-28. 3 campos sin dato. Términos v1.3 (criterio-project 0.12.1), aceptados por José Francisco Ñáñez el 2026-10-28: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.12.1
