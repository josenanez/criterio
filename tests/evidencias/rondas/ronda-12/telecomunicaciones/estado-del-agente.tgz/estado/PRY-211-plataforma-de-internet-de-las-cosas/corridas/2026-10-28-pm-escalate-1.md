# Corrida del 2026-10-28 · pm-escalate

1 proyectos · 57 s · 20 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_rescheduled` | 7 |
| `commitment_overdue` | 6 |
| `milestone_met_without_evidence` | 2 |
| `vendor_deliverable_late` | 2 |
| `variance_time` | 1 |
| `progress_vs_plan` | 1 |
| `commitment_undated` | 1 |

Dos puntos: autoridad del gerente no declarada en el acta, y CC-01 (+102 días, 204 MM COP). Los 102 días coinciden con v1 (07-26) a v2 (11-05): ambigüedad de línea base no resuelta. impact devolvió 0 proyectos alcanzados porque no hay dependencias declaradas ni otras fichas; no se estimó el movimiento por proyecto.

Contra la corrida del 2026-10-28: +0 hallazgos.

## Lo que produjo

Términos vigentes (v1.3, aceptados por José Francisco Ñáñez el 2026-10-28 para esta prueba, comprobante en `.criterio/terminos/`); no hizo falta mostrarlos de nuevo. Sin tema en el argumento: tomo lo escalable que ya está marcado en la ficha. Salen dos puntos, en este orden.

## Para decisión — PRY-211 Plataforma de internet de las cosas · 2026-10-28

### Punto 1 — ¿Se declara por escrito qué puede decidir el gerente de PRY-211: sí o no?

Este es el primer punto porque `identity.authority` no se encontró: el acta del 2026-01-05 no declara la autoridad del gerente (límites de fecha, costo y alcance). Sin eso no se puede decir, para ningún otro punto, si excede la autoridad o no.

**Quién decide:** el acta no lo dice. Por lo que sí dice, el Comité de Inversiones aprobó el presupuesto y las fechas, y Ricardo Salas es patrocinador; que la adenda la firmen ellos es mi inferencia, no un dato del acta. · **Si no se decide hoy:** CC-01 llega al comité el 2026-11-11 sin que nadie pueda decir si el gerente debía presentarlo o resolverlo; el comité siguiente también.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Adenda al acta con umbrales (qué decide el gerente, qué el patrocinador, qué el comité) | Ninguno | Una redacción y una firma; no tengo estimación de días | Sin costo de proyecto declarado |
| B. Se confirma por escrito que todo cambio de línea base va al Comité de Inversiones y el gerente decide solo lo interno | Ninguno | Inmediato, queda en la minuta | Sin costo declarado; todo cambio menor espera al comité |

**Recomiendo:** A. Con B, cada ajuste de fecha espera un comité; con A queda dicho qué se resuelve sin subirlo. Los umbrales los pone el comité, no yo.

### Punto 2 — ¿Aprueba el Comité de Inversiones CC-01 (ampliación de alcance, +102 días, +204.000.000 COP): sí o no?

**Quién decide:** Comité de Inversiones, con Ricardo Salas. CC-01 dice «pendiente de presentación al comité» y el acta le asigna ese comité a la línea base. La facultad del gerente sobre el cambio no está declarada (punto 1). · **Si no se decide hoy:** el 2026-11-05 llega el cierre del cronograma v2 sin línea base aprobada que lo cubra, seis días antes del comité del 2026-11-11 (`cycle.committee_next`). CC-01 lleva pendiente 11 días al 2026-10-28 y llegaría a 25 el 11-11.

**Antes de llevarlo hay un dato que revisar.** El cambio dice «+102 días sobre la línea base vigente». En la ficha la única línea base registrada es la v1, con cierre el 2026-07-26. Esa fecha más 102 días da exactamente el 2026-11-05, que es el cierre del cronograma v2 (`10-plan/2026-10-28-cronograma-v2.xlsx`). Hay dos lecturas y no puedo distinguirlas con lo que hay:
- **Lectura 1:** los 102 días son contra la v1. Entonces CC-01 formaliza el atraso que el cronograma v2 ya trae, y el cierre queda en 2026-11-05.
- **Lectura 2:** los 102 días son contra la v2. Entonces el cierre pasa al 2027-02-15 (el cálculo de abajo está hecho así).

Tampoco dice qué se amplía: «Ampliación de alcance» es toda la descripción. Quien lo decida necesita eso por escrito.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar CC-01 | Se amplía; lo que se agrega no está descrito en CC-01 | +102 días. Cierre 2026-11-05 (lectura 1) o 2027-02-15 (lectura 2) | +204.000.000 COP. Lo declarado en el informe: proyección 3.037.162.738 COP; sumado, 3.241.162.738 COP contra 3.300.000.000 aprobados, si la proyección no incluía ya el cambio, que el informe no dice |
| B. Rechazar CC-01 | Se mantiene el del acta | El cronograma v2 (cierre 11-05) queda sin línea base aprobada; los compromisos del 11-23 al 12-26 siguen después de ese cierre | Sin adicional; no tengo el costo de no ampliar |
| C. Devolverlo para completar (qué se amplía, contra qué línea base se miden los 102 días) | Sin cambio | Una ronda más; el 11-05 pasa igual sin línea base aprobada | Sin adicional |

**Recomiendo:** C si los datos faltantes no llegan antes del 2026-11-11, y A si llegan y la lectura es la 1: en ese caso el atraso ya está en ejecución, los 204.000.000 COP caben en el aprobado según la proyección declarada, y aprobar deja la línea base v2 con fecha y aprobador. Esto es juicio sobre lo que dicen los documentos; el contenido del alcance ampliado no lo conozco.

### A quién alcanza
Ninguno que yo pueda mostrar. El cálculo (`impact`, 102 días) devolvió 0 proyectos alcanzados, 0 dependencias directas o indirectas y 0 sin confirmar. **Eso no significa que no haya:** el estado de esta carpeta tiene solo la ficha de PRY-211, y el acta dice «Dependencias declaradas: ninguna declarada». Si el proyecto depende de otro o alimenta a otro, no está escrito en ningún documento que yo haya leído.

| Proyecto | Gerente | ¿Sostiene su fecha? | Dependencia confirmada |
|---|---|---|---|
| (ninguno en la ficha) | — | No se puede decir | No hay dependencias declaradas |

### Mis hitos por los que pasa
El cálculo no devolvió ningún hito: los cinco de la ficha tienen fecha vigente hasta el 2026-11-05 y el cambio los mueve desde esa fecha. Con la lectura 2, el cierre pasa del 2026-11-05 al 2027-02-15. No calculo cuántos días se mueve cada hito intermedio: eso necesita holgura por actividad y la ficha no la tiene.

| Hito | Fecha vigente | En cuántos días |
|---|---|---|
| Lanzamiento comercial (cierre) | 2026-11-05 | +102 (a 2027-02-15 en la lectura 2; en la lectura 1 ya está incluido) |

### De dónde sale esto
- Autoridad no declarada: `00-gobierno/2026-01-05-acta-constitucion.md` (sin sección de autoridad; comité y patrocinador, aprobación del presupuesto y las fechas); ficha `identity.authority: not_found`.
- CC-01: `20-seguimiento/2026-10-17-solicitud-cambio-cc-01.md` (alcance, +102 días, 204.000.000 COP, «pendiente de presentación al comité»).
- Línea base v1, cierre 2026-07-26: acta de constitución. Cierre 2026-11-05: `10-plan/2026-10-28-cronograma-v2.xlsx`. La coincidencia de 102 días es cuenta mía entre esas dos fechas.
- Presupuesto y proyección: `20-seguimiento/2026-10-28-informe-avance.md`. De paso, ese informe tiene lo ejecutado (1.847.540.267 COP) por encima de lo comprometido (1.710.711.399 COP); no lo resuelvo aquí, va a `/pm-report`.
- Próximo comité 2026-11-11: configuración `cycle.committee_next`; las notas del 2026-10-28 dicen «próxima reunión en dos semanas» (`2026-10-28-notas-reunion.txt`, línea 8), lo que no coincide con comité semanal.
- Cálculo de impacto: `portafolio.py impact`, 102 días, corrida de hoy.

### Lo que queda fuera de este paquete
- **CT-707 (Obras Civiles de Telecomunicaciones):** dos entregables vencidos sin recibo y lo facturado no está en el expediente. Quién tiene la facultad sobre el contrato tampoco está dicho, así que depende del punto 1.
- **Compromisos reprogramados tres veces o más** (Neira 6, Hoyos 5, Cárdenas, Salas, Beltrán): varios caen después del cierre del cronograma v2. Su fecha depende de lo que decida el punto 2; el seguimiento va por `/pm-commitments`.
- **Esto no escala solo:** el paquete es tuyo para llevarlo al comité. La llamada a Salas sobre el punto 1 puede resolverlo antes.
