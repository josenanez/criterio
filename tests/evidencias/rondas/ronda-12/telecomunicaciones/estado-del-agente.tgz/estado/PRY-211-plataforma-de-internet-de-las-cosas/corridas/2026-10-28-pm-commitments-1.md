# Corrida del 2026-10-28 · pm-commitments

1 proyectos · 30 s · 20 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_rescheduled` | 7 |
| `commitment_overdue` | 6 |
| `milestone_met_without_evidence` | 2 |
| `vendor_deliverable_late` | 2 |
| `variance_time` | 1 |
| `progress_vs_plan` | 1 |
| `commitment_undated` | 1 |

Siete compromisos reprogramados tres veces o más (Gustavo Neira seis, Javier Hoyos cinco, Camilo Beltrán dos de cuatro, Rubén Cárdenas y Ricardo Salas tres); seis vencidos sin evidencia; uno sin fecha (Laura Vélez)

Contra la corrida del 2026-10-28: +0 hallazgos.

## Lo que produjo

## Compromisos — PRY-211 Plataforma de internet de las cosas · al 2026-10-28

24 compromisos abiertos: 6 vencidos sin evidencia, 7 reprogramados tres veces o más, 1 sin fecha. Ninguno se cierra en esta revisión: el expediente no trae un documento que respalde un cumplimiento nuevo.

### Se viene reprogramando

> **Gustavo Neira** · Enviar el documento 1
> Prometido para el 2026-09-20, y antes para el 10-02, el 10-20, el 11-10, el 11-29 y el 12-12; hoy dice el 12-26. **Seis reprogramaciones.**
> **Tres veces no es un problema de seguimiento: es un bloqueo que nadie ha nombrado.** En la reunión de hoy dijo que «no alcanzó» y no quedó claro qué (la entrega, el contenido o el plazo).

> **Javier Hoyos** · Cerrar la prueba 2
> Prometido para el 2026-10-02, y antes para el 10-09, el 10-28, el 11-08 y el 11-22; hoy dice el 12-12. **Cinco reprogramaciones.** La fecha del 10-28 ya la dejó pasar. El informe de avance de hoy dice que la prueba de velocidad en campo no alcanzó el valor pactado y se repite.

> **Camilo Beltrán** · Actualizar la matriz 6
> Prometido para el 2026-10-16, y antes para el 10-24, el 11-06 y el 11-25; hoy dice el 12-09. **Cuatro reprogramaciones.**

> **Camilo Beltrán** · Confirmar la fecha 7
> Prometido para el 2026-10-08, y antes para el 10-21, el 11-03 y el 11-21; hoy dice el 12-12. **Cuatro reprogramaciones.**

> **Rubén Cárdenas** · Revisar el anexo 3
> Prometido para el 2026-10-05, y antes para el 10-24 y el 11-06; hoy dice el 11-25. **Tres reprogramaciones.**

> **Ricardo Salas** · Aprobar el diseño 5
> Prometido para el 2026-10-15, y antes para el 10-24 y el 11-01; hoy dice el 11-17. **Tres reprogramaciones.**

> **Ricardo Salas** · Entregar el punto 8
> Prometido para el 2026-10-20, y antes para el 11-05 y el 11-12; hoy dice el 11-23. **Tres reprogramaciones.**

Camilo Beltrán y Ricardo Salas aparecen dos veces cada uno, y Camilo con las fechas corriéndose juntas.

### Vencidos sin evidencia
| Quién | Qué | Prometido para | Hace |
|---|---|---|---|
| Felipe Arango | Confirmar la fecha 15 | 2026-10-19 | 9 días |
| Felipe Arango | Validar el ambiente 20 | 2026-10-21 | 7 días |
| Jorge Medina | Enviar el documento 17 | 2026-10-22 | 6 días |
| Beatriz Cuéllar | Cerrar la prueba 18 | 2026-10-22 | 6 días |
| Sandra Gil | Actualizar la matriz 22 | 2026-10-24 | 4 días |
| Elena Duarte | Entregar el punto 24 | 2026-10-24 | 4 días |

Ninguno tiene documento de cierre en el expediente. Los dos primeros son de Felipe Arango y no tienen una sola reprogramación.

### Vencen esta semana
| Quién | Qué | Para cuándo |
|---|---|---|
| Gustavo Neira | Cerrar la prueba 10 | 2026-10-28 (hoy) |
| Jorge Medina | Entregar el punto 16 | 2026-10-30 (reprogramado una vez, desde el 10-17) |
| Camilo Beltrán | Confirmar la fecha 23 | 2026-10-30 |
| Carlos Peña | Validar el ambiente 4 | 2026-11-03 (reprogramado una vez, desde el 10-03) |
| Carlos Peña | Aprobar el diseño 13 | 2026-11-03 |
| Diana Molina | Revisar el anexo 19 | 2026-11-03 (reprogramado una vez, desde el 10-23) |

Sobre «Aprobar el diseño 13»: Carlos Peña dijo el 2026-10-21 que ya lo entregó; no hay acta ni documento que lo respalde (`30-reuniones/2026-10-21-comite-semanal.md`) y desde esa fecha dejó de aparecer en la tabla de abiertos. Sigue abierto.

Las notas de hoy no mencionan «Cerrar la prueba 10» (Gustavo Neira, vence hoy) ni «Cerrar la prueba 2» (Javier Hoyos).

### Sin fecha
| Quién | Qué | Dicho el |
|---|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto («la otra semana») | 2026-10-28 |

No puede estar vencido, y por eso mismo no aparece en ningún informe de vencidos.

### Cerrados desde la última revisión
Ninguno. El único cerrado de la ficha, «Validar el ambiente 12» (Liliana Torres), ya estaba cerrado contra `20-seguimiento/2026-10-07-acta-recibo-12.md`.

## Después
- Hay siete compromisos reprogramados tres veces o más. Puedo formularlos como decisión para el comité: qué se pide, qué pasa si no se decide y quién tiene la facultad. Empezaría por Gustavo Neira (seis) y Javier Hoyos (cinco). Eso excede la autoridad del gerente y por eso sube.
- Las fechas de Gustavo Neira (12-26) y Javier Hoyos (12-12) caen después del cierre vigente del cronograma (2026-11-05).
- Los compromisos de hoy están en la ficha, y el informe de avance no los toca. Si quiere que la PMO los vea, `/pm-publish`.
