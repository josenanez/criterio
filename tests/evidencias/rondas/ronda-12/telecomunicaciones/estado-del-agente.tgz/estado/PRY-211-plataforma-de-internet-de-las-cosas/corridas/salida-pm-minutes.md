# Acta — PRY-211 Plataforma de internet de las cosas · 2026-10-28
**Asistieron:** Beatriz Cuéllar, Camilo Beltrán, Carlos Peña, Diana Molina, Elena Duarte, Felipe Arango, Gustavo Neira, Javier Hoyos, Jorge Medina, Laura Vélez, Natalia Ospina, Ricardo Salas, Rubén Cárdenas, Sandra Gil, Óscar Ramírez · **Fuente:** `2026-10-28-notas-reunion.txt` · **Ausentes con tema en agenda:** ninguno (todos los dolientes de compromisos abiertos están en la lista; Laura Vélez y Óscar Ramírez aparecen por primera vez en el proyecto)

## Compromisos
| Quién | Qué | Para cuándo | |
|---|---|---|---|
| Gustavo Neira | Enviar el documento 1 | 2026-12-26 | **Reprogramado 6 veces.** Prometido originalmente para 2026-09-20; fechas intermedias: 10-02, 10-20, 11-10, 11-29, 12-12. Nota: «no alcanzó» (línea 4) |
| Óscar Ramírez | Revisión con el proveedor | 2026-11-07 | Nuevo (línea 6) |

### Sin fecha
| Quién | Qué |
|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto — dicho como «la otra semana» (línea 5), sin fecha; se guarda con `no_declarada` |

## Decisiones
Ninguna. Las notas no registran una decisión con quién la tomó y qué se descartó.

## Quedó sin decidir
Nada se dijo expresamente como pendiente de decisión; no se inventa.

## Intenciones sin doliente
Ninguna en estas notas.

## Dicho al pasar y no registrado
| Qué | Quién lo dijo | Categoría | Ya estaba en el RAID |
|---|---|---|---|
| «El proveedor podría no llegar con el equipo completo para la siguiente fase» (línea 7: «nadie lo anotó como riesgo») | No atribuido en las notas | Riesgo | **No.** Se guarda en el RAID con `registered: false` y sin dueño. Contexto: el contrato CT-707 (Obras Civiles de Telecomunicaciones) tiene 2 entregables sin recibo, con 216 y 145 días de atraso |

## Cerrado en esta reunión
Nada. Las notas no citan ningún documento de cierre.

## Lo que esta reunión contradice
| Campo | Dijo la reunión | Dice el expediente | Fuente y fecha de cada uno |
|---|---|---|---|
| Cadencia del comité | «Próxima reunión en dos semanas» (≈ 2026-11-11) | Comité semanal; próximo 2026-11-11 en la configuración | notas 2026-10-28 · `config.json` |

No cambió patrocinador, fecha de cierre ni comité. Observación aparte, que no es contradicción de un campo: las dos fechas nuevas de esta reunión (Óscar, 11-07; Gustavo, 12-26) caen **después** del cierre vigente del cronograma v2 (2026-11-05).

## Sin resolver de la transcripción
- «Gustavo Neira dice que lo de "enviar el documento 1" no alcanzó»: no queda claro qué no alcanzó (la entrega, el contenido o el plazo anterior).
- «Laura Vélez queda de mandar el ajuste del presupuesto la otra semana»: «la otra semana» no se convirtió en fecha.
- El riesgo del proveedor no dice quién lo comentó ni a qué «siguiente fase» se refiere.
- Las notas no mencionan «Cerrar la prueba 10» (Gustavo Neira), que vence hoy 2026-10-28, ni «Cerrar la prueba 2» (Javier Hoyos). Sin dicho, sin cierre: siguen abiertos.

## Recalculado
Sin `record_issues`. Compromisos abiertos: 6 vencidos sin evidencia, 7 reprogramados (máximo 6 veces), 1 sin fecha.
