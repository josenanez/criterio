# Plan — PRY-211 · Plataforma de internet de las cosas · borrador del 2026-10-28
**Desde:** acta de constitución del 2026-01-05 · **Criterio de éxito:** «Plataforma de internet de las cosas en producción y medido» (está declarado, pero no se puede verificar; ver abajo)

**Nota de contexto:** este proyecto ya tiene plan: `cronograma-v1` (2026-01-05) y `cronograma-v2` (2026-10-28). Este borrador sale del acta, no de esos cronogramas; los uso solo como referencia y lo digo en cada fila. Los términos vigentes (v1.3) los aceptó José Francisco Ñáñez el 2026-10-28.

## Lo que le falta al acta
| Qué | Consecuencia de planificar sin eso |
|---|---|
| **Alcance sin contenido:** «Componente 1, 2, 3» son marcadores, no componentes | No hay entregables de los que descomponer. Los nodos de abajo no salen del alcance del acta; solo hay estructura. |
| **Criterio de éxito sin umbral:** «en producción y medido» no dice qué se mide, con qué indicador ni qué valor | Nadie puede decir si el proyecto cumplió. «Medido» queda a la interpretación de quien cierre. |
| **Fuera de alcance vacío:** «Lo que otro proyecto cubre» no nombra ningún proyecto | No se sabe dónde acaba este proyecto. Es la puerta a la ampliación de alcance: CC-01 pide +102 días y +204.000.000 COP sin un borde contra el que compararla. |
| **Autoridad del gerente no declarada** | No se sabe qué puede decidir quien planifica y qué debe subir al patrocinador o al comité. |
| **Dependencias: «Ninguna declarada»** | Un proyecto con proveedor externo (CT-707) y producto asociado (conectividad IoT) no suele tener cero dependencias. Planificar así esconde las que existan. |
| **Objetivo del negocio sin medida:** «Entregar plataforma… para Mercadeo» | No hay un resultado de negocio que el plan deba proteger. |

Patrocinador: sí está (Ricardo Salas). Sigo con el plan marcando cada hueco; no lo relleno.

## WBS
Los hitos y entregables salen de `cronograma-v1`, el contrato CT-707 y las actas de recibo, **no del acta**. Por eso ningún nodo está marcado «del acta» en su contenido. El acta solo respalda el nodo 7. Quién acepta: el acta no lo dice para ningún entregable.

| # | Entregable | Quién lo acepta | De dónde sale | Duración |
|---|---|---|---|---|
| 1 | Diseño de red aprobado | Sin definir | Supuesto (hito en cronograma-v1, estado «cerrado»; sin acta de recibo en la carpeta) | — |
| 2 | Permisos de instalación obtenidos | Sin definir (el acta de recibo del 2026-10-16 la firma Jorge Medina como quien recibe) | Supuesto (cronograma-v1; acta de recibo 2026-10-16) | — |
| 3 | Suministro de antenas y radios | Sin definir (CT-707: se factura contra acta firmada por el gerente) | Supuesto (CT-707, comprometido 2026-03-26, estado «pendiente», 371.745.399 COP) | — |
| 4 | Bolsa de horas de ingeniería | Sin definir (ídem) | Supuesto (CT-707, comprometido 2026-06-05, estado «en curso», 371.745.399 COP) | — |
| 5 | Sitios construidos | Sin definir (acta de recibo 2026-10-28 firmada por Jorge Medina) | Supuesto (cronograma-v1; acta de recibo 2026-10-28) | — |
| 6 | Integración con la red | Sin definir | Supuesto (cronograma-v1, estado «cerrado»; sin acta de recibo en la carpeta) | — |
| 7 | Plataforma IoT en producción y medida | Sin definir (el acta no dice quién acepta) | **Del acta** (criterio de éxito) en cuanto a existir; el «medido» queda **sin definir** | — |
| 8 | Lanzamiento comercial | Sin definir | Supuesto (cronograma-v1; en v2 con fecha vigente 2026-11-05) | — |
| 9 | Componentes 1, 2 y 3 del alcance | Sin definir | **Sin definir.** El acta solo trae marcadores. No los hago coincidir con ningún nodo de arriba | — |

Nodos que **no** son entregables aceptables y por eso no los incluyo: «Gestión del proyecto», «Pruebas». Si las pruebas de velocidad en campo (informe 2026-10-28) son un entregable, alguien tiene que decirlo y decir quién las acepta.

## Orden
Es una propiedad del trabajo, sin fechas. Lo que sale de los documentos es esto:
- 1 (diseño) → 2 (permisos) → 5 (sitios construidos): es el orden de los hitos de `cronograma-v1`. Que el diseño preceda a los permisos es una suposición mía; el cronograma solo los lista en ese orden.
- 3 (antenas y radios) → 6 (integración con la red): supuesto. Sin equipos suministrados no hay integración, pero ningún documento lo dice.
- 5 + 6 → 7 → 8: supuesto de orden lógico.
- 4 (bolsa de horas) corre en paralelo; no hay documento que diga a qué nodo se carga.

Dependencias que el acta no declara y que el orden necesita: el proveedor de CT-707, y el proyecto «otro» del que habla «fuera de alcance».

## Supuestos sobre los que está construido
| Supuesto | Qué pasa si resulta falso |
|---|---|
| Los 8 nodos son los entregables del proyecto, aunque el acta no los nombra | Falta algo que el patrocinador espera (los «Componentes») o sobra algo que nadie aceptará |
| El orden diseño → permisos → sitios → integración → producción → lanzamiento es una cadena | Si hay trabajo en paralelo, el plan sobreestima el camino crítico; si hay dependencias ocultas, lo subestima |
| El gerente recibe todos los entregables | Si el patrocinador o el negocio deben aceptar, las actas de recibo vigentes no cierran nada |
| CT-707 cubre solo los nodos 3 y 4 | El resto del presupuesto (3.300.000.000 COP aprobados; 743.490.798 COP en CT-707) no tiene entregable asignado en ningún documento |
| «En producción y medido» tiene un indicador que alguien conoce | Sin indicador, el nodo 7 no se puede aceptar |

Estos pasan al RAID con doliente cuando el plan se apruebe.

## Sin definir
| Qué | Quién lo define |
|---|---|
| Los tres componentes del alcance | Ricardo Salas (patrocinador) con Jorge Medina |
| Qué es «medido» y con qué umbral | Ricardo Salas / Mercadeo (área dueña) |
| Quién acepta cada entregable | Ricardo Salas |
| Fuera de alcance: qué proyecto cubre qué | Ricardo Salas / Comité de Inversiones |
| Autoridad del gerente al planificar | Ricardo Salas / Comité de Inversiones |
| Dependencias | Jorge Medina, con el proveedor y el producto conectividad IoT |
| Las pruebas de velocidad en campo: ¿son entregable? | Jorge Medina |

## Proyectos análogos
Ninguno a la vista: la configuración de PRY-211 no apunta a una carpeta de fichas de la PMO. No traigo análogos y no estimo por analogía.

## Preguntas para el equipo
Una por duración vacía (todas lo están: ninguna sale de una fuente citable; CT-707 da fechas, no duraciones):
1. ¿Cuánto toma el diseño de red hasta la aprobación, y quién lo aprueba?
2. ¿Cuánto toma obtener los permisos y quién los recibe?
3. ¿Cuánto toma el suministro de antenas y radios? CT-707 lo comprometió para 2026-03-26 y sigue «pendiente».
4. ¿Cuántas horas de ingeniería quedan en la bolsa y a qué nodo se cargan?
5. ¿Cuánto toma construir los sitios restantes, si los hay?
6. ¿Cuánto toma la integración con la red?
7. ¿Cuánto toma poner la plataforma en producción y cuánto medirla?
8. ¿Cuánto toma repetir la prueba de velocidad en campo que no alcanzó el valor pactado?
9. ¿Cuánto toma el lanzamiento comercial?

## Para comprometer una fecha falta
- La disponibilidad real del equipo. Las notas del 2026-10-28 dicen que el proveedor podría no llegar con el equipo completo y nadie lo anotó como riesgo.
- La fecha del proveedor para el suministro de antenas y radios y para el equipo de la siguiente fase.
- La ventana de la sala de producción.
- La decisión sobre CC-01 (+102 días, +204.000.000 COP), que sigue «pendiente de presentación al comité». Hasta que se decida, no se sabe sobre qué línea base se planifica.

Ninguna de las cuatro está en un documento.

## Cosas que vi y no resuelvo
- `cronograma-v2` marca «Lanzamiento comercial» como «cerrado» con fecha vigente 2026-11-05, que es futura (hoy 2026-10-28); el informe de avance declara 49% y estado amarillo. No sé cuál de los tres dice lo cierto.
- La fecha vigente 2026-11-05 está 102 días después de la línea base 2026-07-26, la misma cifra que CC-01 pide sobre la línea base vigente. No sé si v2 ya incluye un cambio sin autorizar.
- Los hitos «Permisos» y «Sitios construidos» figuran como cerrados desde abril y mayo en el cronograma; sus actas de recibo son del 2026-10-16 y 2026-10-28.

## No comprometí ninguna fecha, no estimé duraciones y no asigné personas.
