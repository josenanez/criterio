Términos vigentes (v1.3, aceptados por José Francisco Ñáñez el 2026-10-28). Sesión sin interfaz: tomé la respuesta sugerida en cada pregunta.

Recalculé antes de publicar. La fecha de cierre vigente (2026-11-05) sale del cronograma v2 del 2026-10-28, el más nuevo; la del acta (2026-07-26) va en `plan.baseline`.

Publiqué la ficha en `documentos/proyectos/PRY-211-plataforma-de-internet-de-las-cosas/00-gobierno/ficha-pm.json`, con corte al 2026-10-28.

**Lleva:** campos con dato en identidad, plan, dinero, proveedor, cambios y compromisos · 3 sin decir en ninguna parte (`identity.authority`, `identity.phase`, `vendors[0].invoiced`) · declara **amarillo** al 2026-10-28 (49 % de avance)

**Lo más viejo que va ahí:** `vendors[0]` (nombre y contrato CT-707), del 2025-12-29 — no pasa de un año. Los datos de identidad (patrocinador Ricardo Salas, gerente Jorge Medina, comité) son del acta del 2026-01-05.

**Lo primero que verá la PMO:** declara amarillo, pero la ficha trae 102 días de atraso contra la línea base original (53,1 %), un avance declarado de 49 % frente a 5 de 5 hitos cumplidos, dos hitos cumplidos sin evidencia (Diseño de red aprobado, Integración con la red), 6 compromisos vencidos, 7 reprogramados y 2 entregables del proveedor vencidos sin recibo. El cambio CC-01 sigue pendiente de decisión.

No avisé a nadie: Vera la encontrará en su próximo barrido.
