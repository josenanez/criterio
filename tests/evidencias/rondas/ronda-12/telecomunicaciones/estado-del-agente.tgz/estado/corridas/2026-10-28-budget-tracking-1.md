# Corrida del 2026-10-28 · budget-tracking

13 proyectos · 35 s · 70 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `vendor_deliverable_late` | 10 |
| `commitment_overdue` | 9 |
| `progress_vs_plan` | 7 |
| `commitment_rescheduled` | 7 |
| `variance_time` | 5 |
| `declared_vs_evidence` | 3 |
| `rebaseline_unauthorized` | 3 |
| `commitment_undated` | 2 |
| `vendor_accepted_without_evidence` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `vendor_invoiced_without_delivery` | 1 |
| `variance_cost` | 1 |

Presupuesto de PRY-210 en COP: proyección 19.7% sobre el aprobado y ejecución (56.0%) por encima del avance que sustenta el plan. Dijo que no sabe: ninguna cifra salvo el aprobado tiene evidencia (son declaraciones del informe de avance), el ejecutado supera al comprometido sin explicación, y no hay proveedores registrados.

Contra la corrida del 2026-10-28: +0 hallazgos.

## Lo que produjo

Documentos de los que sale: ficha PRY-210 (estado/records/PRY-210.json) y salida de `portafolio.py compute`, fecha de cálculo 2026-10-28. Fuentes: acta de constitución (2026-05-14), informe de avance (2026-10-28), solicitud de cambio CC-01 (2026-10-27).

## Presupuesto — PRY-210 Conectividad para colegios públicos al 2026-10-28
**Moneda:** COP (única; no hay contratos en otra moneda ni conversión)

| | Monto (COP) | % del aprobado | Fuente | Fecha |
|---|---|---|---|---|
| Aprobado | 3.300.000.000 | 100% | Acta de constitución | 2026-05-14 |
| Comprometido | 1.565.215.894 | 47.4% | Informe de avance (declaración) | 2026-10-28 |
| Ejecutado | 1.847.276.551 | 56.0% | Informe de avance (declaración) | 2026-10-28 |
| Proyección al cierre | 3.951.444.314 | 19.7% por encima del aprobado | Informe de avance (declaración) | 2026-10-28 |

**Disponible real** (aprobado menos comprometido): 1.734.784.106 COP

Las tres cifras de ejecución salen de una declaración del informe de avance. Ningún documento contable o de evidencia las respalda (la ficha registra 0 fuentes de evidencia y 5 declaraciones).

### Contra la línea base
| | Original | Vigente | Desviación |
|---|---|---|---|
| Presupuesto aprobado | 3.300.000.000 | 3.300.000.000 | 0 aprobada |
| Proyección frente al aprobado | | | +19.7% |

Replanificaciones de presupuesto aprobadas: 0. Hay una solicitud pendiente, CC-01 (2026-10-27): 220.000.000 COP adicionales, ampliación de alcance, +110 días. Sin decisión ni decisor, así que la línea base de presupuesto sigue siendo la del acta. El script no calcula si los 220.000.000 cubren la diferencia entre proyección y aprobado, y no lo afirmo.

### Ejecución frente a avance
Ejecutado 56.0% · Hitos cumplidos 1 de 5 (y ese uno sin evidencia) · Avance declarado 50%, el plan sostiene entre 20% y 40%. El dinero ejecutado va por delante del avance que el plan respalda.

### Alertas
- **Proyección por encima del aprobado:** 3.951.444.314 contra 3.300.000.000 (+19.7%), sobre el umbral de 10%.
- **Ejecución por encima del avance:** 56.0% ejecutado contra 20–40% que sostiene el plan, con un avance declarado de 50% y 10 puntos por encima de lo que el plan sustenta.
- **Hito "Diseño de red aprobado"** (vencía 2026-08-18) figura como cumplido sin evidencia, hace 71 días.
- **Incoherencia entre cifras:** el ejecutado (1.847.276.551) es mayor que el comprometido (1.565.215.894, declarado). Normalmente lo ejecutado está contenido en lo comprometido. No lo corrijo ni lo interpreto: el informe de avance no explica la diferencia, y hay que pedírsela a quien lo firma.
- **Comprometido:** 47.4%, por debajo del umbral de 90%. Sin alerta por ese concepto.
- **Línea base de tiempo movida sin autorización:** 110 días (fecha de fin de 2027-07-28 a 2027-11-15) con 0 días autorizados. Es de cronograma, pero va junto con CC-01 pendiente.

### Sin dato
- Ninguna de las cuatro cifras está respaldada por un documento de evidencia (factura, ejecución presupuestal, contrato). Todas, salvo el aprobado, son declaraciones del mismo informe.
- Detalle por proveedor: la ficha no registra proveedores para este proyecto.
- Explicación de por qué el ejecutado supera al comprometido.

## Siguiente paso
La proyección excede el aprobado y ya existe CC-01 pendiente de decisión. Puedo evaluarla con change-control (alcance, tiempo y costo) cuando lo pidas.

---
Rigor: cifras copiadas de `compute` con todos sus dígitos; fuentes y fechas de la ficha; nada convertido de moneda; lo no declarado va como sin dato. Los términos están vigentes (v0.12.1, aceptados por José Francisco Ñáñez el 2026-10-28).
