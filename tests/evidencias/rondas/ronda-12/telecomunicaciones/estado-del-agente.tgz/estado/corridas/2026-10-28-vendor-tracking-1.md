# Corrida del 2026-10-28 · vendor-tracking

13 proyectos · 43 s · 70 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `vendor_deliverable_late` | 10 |
| `commitment_overdue` | 9 |
| `progress_vs_plan` | 7 |
| `commitment_rescheduled` | 7 |
| `variance_time` | 5 |
| `declared_vs_evidence` | 3 |
| `rebaseline_unauthorized` | 3 |
| `commitment_undated` | 2 |
| `vendor_accepted_without_evidence` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `vendor_invoiced_without_delivery` | 1 |
| `variance_cost` | 1 |

Cruce de CT-235 y CT-478 contra actas y facturas de PRY-200. Hallazgo: bolsa de horas de CT-478 aceptada y facturada (FV-1478) sin acta de recibo. Dijo que no sabía: vigencia, renovación y preaviso de ambos contratos, y a quién pertenece el compromiso vencido de Carlos Peña.

Contra la corrida del 2026-10-28: +0 hallazgos.

## Lo que produjo

**Sale de:** los dos contratos (CT-235 y CT-478, en `00-gobierno`), las dos actas de recibo de "Suministro de antenas y radios", las dos facturas (FV-2235 y FV-1478), el informe de avance del 2026-10-17 y la minuta del comité del 2026-10-19, todos de PRY-200. Las cifras salen de `portafolio.py compute` con corte 2026-10-28.

## Proveedores — PRY-200 Despliegue de 5G en ciudades intermedias al 2026-10-28

### Soporte de Red Continental — contrato CT-235
**Vigencia:** sin dato · **Preaviso de no renovación:** sin dato · **Vence el:** sin dato (el contrato solo trae entregables y condición de pago).

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Suministro de antenas y radios | 2025-08-04 · 265.104.460 | accepted | Acta de recibo 2025-08-18 (`20-seguimiento/2025-08-18-acta-recibo-ct-235-…md`) | FV-2235, 265.104.460 |
| Bolsa de horas de ingeniería | 2025-09-25 · 265.104.460 | pending, 398 días de atraso | ninguna | no |
| Tendido de fibra óptica | 2025-11-16 · 265.104.460 | pending, 346 días de atraso | ninguna | no |

Facturado en total: 265.104.460 (FV-2235, 2026-09-21). Es el monto de un solo entregable aceptado con acta.

### Fibra Óptica del Pacífico S.A.S. — contrato CT-478
**Vigencia:** sin dato · **Preaviso de no renovación:** sin dato · **Vence el:** sin dato.

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Suministro de antenas y radios | 2025-08-04 · 265.897.752 | accepted | Acta de recibo 2025-08-14 (`20-seguimiento/2025-08-14-acta-recibo-ct-478-…pdf`) | dentro de FV-1478 |
| Bolsa de horas de ingeniería | 2025-09-25 · 265.897.752 | accepted **sin evidencia** | ninguna; solo la columna "Estado: recibido" del propio contrato | dentro de FV-1478 |
| Tendido de fibra óptica | 2025-11-16 · 265.897.752 | pending, 346 días de atraso | ninguna | no |

Facturado en total: 531.795.504 (FV-1478, 2026-10-11), es decir, dos entregables.

### Dónde no cuadra
| Qué | Dice el contrato | Dice la evidencia | Fuentes |
|---|---|---|---|
| CT-478, "Bolsa de horas de ingeniería" | Estado "recibido"; se factura contra acta de recibo firmada por el gerente | No hay acta de recibo. La única acta de CT-478 es la de antenas y radios. FV-1478 cobra dos entregables. | `2025-06-06-contrato-ct-478.docx`, `2026-10-11-factura-ct-478.pdf`, `20-seguimiento/` |
| Aceptación del mismo entregable | CT-235 lo deja `pending` | CT-478 lo deja `accepted`; es el mismo concepto, con otro proveedor | los dos contratos |
| Alcance repetido | Los dos contratos comprometen los mismos tres entregables con las mismas fechas | Con la evidencia disponible no se sabe si es alcance dividido entre proveedores o duplicado | los dos contratos |
| Equipos de radio | El informe del 2026-10-17 dice que se reprogramó su llegada por demoras en aduana | Las dos actas de recibo de antenas y radios son de agosto de 2025 | `2026-10-17-informe-avance.md`, actas |

Las dos primeras filas son las que importan para pagar. De las dos últimas solo se señala la diferencia: no hay documento que diga a cuál equipo se refiere cada fuente.

Señal `vendor_invoiced_without_delivery`: no se levanta. Los dos proveedores tienen al menos un entregable aceptado con acta.

### Sin evidencia de recibo
| Entregable | Marcado como | Desde |
|---|---|---|
| Bolsa de horas de ingeniería (CT-478) | accepted | sin fecha de aceptación en ningún documento; la fecha comprometida era 2025-09-25 |

### Compromisos del proveedor vencidos
No hay compromisos de proveedor identificados. El único compromiso vencido de PRY-200 es de Carlos Peña, "Entregar el punto 26", prometido en la minuta del comité del 2026-10-19 para el 2026-10-06, con 22 días de vencido. La minuta no dice a qué organización pertenece Carlos Peña, ni qué es el "punto 26". No lo atribuyo a ningún proveedor.

### Sin dato
- Fecha de terminación, renovación automática y preaviso de CT-235 y CT-478: los contratos no los traen. Sin eso no puedo decir si algún preaviso vence antes del cierre del proyecto.
- El plan termina el 2025-12-19 y hoy es 2026-10-28; si el contrato sigue vigente es algo que ningún documento dice.
- Acta de recibo de la bolsa de horas de CT-478.
- Qué entregables cubre cada factura: ambas dicen "Entregables del contrato", sin detalle.
- El informe de avance del 2026-10-17 no explica estos puntos, y el comité del 2026-10-19 no trata a los proveedores.

## Después
FV-1478 está radicada en cuentas por pagar con un entregable sin acta de recibo, por 265.897.752 según el monto que el contrato asigna a ese entregable. Lo siguiente se puede llevar al comité del 2026-11-04: conseguir el acta o suspender ese pago hasta tenerla, y obtener las fechas de vigencia y preaviso de ambos contratos.

---
*Pie de rigor: borrador de trabajo, sin valor de decisión ni asesoría. Cada dato lleva el documento del que sale y la verificación es de quien lo lee. Lo que no está en la carpeta aparece como "sin dato". Los términos de uso vigentes (versión 1.3) los aceptó José Francisco Ñáñez el 2026-10-28.*
