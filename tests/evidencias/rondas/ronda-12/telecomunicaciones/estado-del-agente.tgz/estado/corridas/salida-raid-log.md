## RAID — portafolio (13 proyectos, PRY-199 a PRY-211) al 2026-10-28

**Sale de:** las fichas en `estado/records/` (sección RAID, 13 proyectos), los informes de avance, las actas de constitución (sección "Dependencias declaradas"), las minutas de comité y las notas de reunión del 2026-10-28 de PRY-211. Escala de valoración: no hay una definida por la organización; se usaría alta/media/baja, pero ningún ítem trae probabilidad ni impacto, así que quedan "sin valorar" (no los inventé).

11 riesgos · 0 supuestos · 17 incidencias · 5 dependencias (33 ítems, tras reclasificar)
33 sin doliente · 33 sin fecha de compromiso · 1 no registrado formalmente · 0 medibles "sin movimiento" (ver límites)

### Lo que no sé
- **Movimiento:** cada ficha tiene una sola lectura del informe de avance; no hay historial de cambios en el RAID, así que no puedo decir qué lleva "dos períodos sin movimiento". No lo afirmo ni lo descarto.
- **Doliente y fecha:** ningún ítem los trae, ni en el informe ni en las minutas. Es un hallazgo; no propongo nombres como si fueran un dato.
- **Supuestos:** ningún documento declara uno. Que no haya no significa que no existan (disponibilidad de personas, terceros, ambientes).
- **Texto repetido entre proyectos:** las mismas frases aparecen en proyectos sin relación evidente (p. ej. "la prueba de velocidad en campo no alcanzó el valor pactado" en PRY-199, cambio de mobiliario de la sala de espera; "permisos para instalar antenas" en PRY-207, facturación convergente, y PRY-203, core de voz). Puede ser texto de plantilla en los informes. Antes de usarlos en comité conviene confirmar con cada gerente que aplican a su proyecto.

### Necesitan decisión ahora
Criterio de escalamiento aplicado: afecta a otros proyectos del portafolio (el criterio de "sin movimiento" no se puede medir). Un mismo hecho está registrado por separado en varios proyectos y nadie lo gestiona como uno.

| Id | Tipo | Qué | Doliente | Desde | Por qué sube |
|---|---|---|---|---|---|
| PRY-200/PRY-201/PRY-204/PRY-206 | Incidencia (venía como riesgo) | Subasta de espectro aplazada por el regulador | sin doliente | informes 2026-10-17 a 10-26 | Afecta a 4 proyectos; ya ocurrió, no es riesgo |
| PRY-200/PRY-206/PRY-208 | Riesgo | Cambio en la norma de compartición de infraestructura que puede mover el alcance | sin doliente | informes 2026-10-17 a 10-25 | Afecta a 3 proyectos |
| PRY-203/PRY-207/PRY-209/PRY-210 | Dependencia (venía como riesgo) + incidencia | Permisos municipales para instalar antenas; la alcaldía detuvo la instalación en dos barrios diez días (PRY-203, 207, 210) | sin doliente | informes 2026-10-18 a 10-28 | Afecta a 4 proyectos; la parte detenida ya ocurrió |
| PRY-201/PRY-203/PRY-206/PRY-207 | Incidencia | El equipo perdió dos semanas por rotación del gerente de despliegue | sin doliente | informes 2026-10-17 a 10-25 | Mismo gerente o mismo hecho en 4 proyectos; confirmar si es la misma persona |
| PRY-200/PRY-205/PRY-209 | Incidencia | Se reprogramó la llegada de los equipos de radio por demoras en la aduana | sin doliente | informes 2026-10-17 a 10-26 | Afecta a 3 proyectos |

**Decisión que se le pide al comité** (próximo: 2026-11-04): nombrar un doliente único por cada uno de estos cinco hechos y una fecha de seguimiento. Es una propuesta de formulación; la asignación es del comité.

### Detectados en reuniones, no registrados
| Qué | Tipo | Dicho en | Fecha |
|---|---|---|---|
| El proveedor podría no llegar con el equipo completo para la siguiente fase («nadie lo anotó como riesgo») — PRY-211/2 | Riesgo | `PRY-211-plataforma-de-internet-de-las-cosas/2026-10-28-notas-reunion.txt` | 2026-10-28 |

Es el único. Revisé las minutas de comité de los 13 proyectos y las notas de PRY-211; el resto solo contiene compromisos, y los compromisos no son RAID. No inventé más. Nota: la ficha de PRY-211 ya lo trae con `registered: false`; falta que el gerente decida si lo formaliza.

### Reclasificados (9 ítems)
| Id | Estaba | Pasa a | Por qué |
|---|---|---|---|
| PRY-200/2, PRY-201/1, PRY-204/2, PRY-206/1: "Subasta de espectro aplazada por el regulador" | Riesgo | Incidencia | Ya fue aplazada: pasó. |
| PRY-204/1: "El proveedor no ha confirmado la fecha de la última entrega" | Riesgo | Dependencia | Depende de un tercero y está sin confirmar. |
| PRY-203/2, PRY-207/1, PRY-209/2, PRY-210/1: "Permisos municipales para instalar antenas" | Riesgo | Dependencia | Depende de la alcaldía, fuera del proyecto. **Es juicio mío**: si el gerente lo trata como riesgo de plazo, se revierte. |

### Sin doliente o sin fecha
Los 33 ítems. Los riesgos y dependencias no traen doliente ni fecha de mitigación; las incidencias no traen doliente ni fecha de inicio (`since`) y las de PRY-210 y PRY-211 ni la fecha de la fuente. Detalle por ítem en el registro completo.

### Dependencias en riesgo
Ninguna se puede cruzar: las 13 actas de constitución dicen "Ninguna declarada" en dependencias, así que no hay dependencia entre proyectos registrada con código. Las 5 dependencias de arriba son de terceros externos (alcaldía, proveedor) y están **declaradas, no acordadas**: ninguna contraparte las confirmó. Esto no prueba que los proyectos sean independientes: PRY-200, 201, 204 y 206 comparten el mismo hecho externo (el regulador), y varios proyectos comparten el mismo proveedor de despliegue o aduana. Dónde hay dependencias reales entre ellos, no está escrito.

| Id | Depende de | Confirmada | Qué pasó |
|---|---|---|---|
| PRY-204/1 | Proveedor (fecha de última entrega) | No | Sin fecha confirmada, informe 2026-10-26 |
| PRY-203/2, 207/1, 209/2, 210/1 | Alcaldía (permisos) | No | La alcaldía detuvo la instalación diez días en dos barrios (203, 207, 210) |

### Registro completo
Los ids son de esta corrida (código/orden en la ficha). Último movimiento = fecha del informe de donde sale; no hay otro.

| Id | Tipo | Qué | Prob. | Impacto | Doliente | Fecha | Último movimiento |
|---|---|---|---|---|---|---|---|
| PRY-199/1 | Riesgo | Concentración del conocimiento en una sola persona | sin valorar | sin valorar | — | — | 2026-10-26 |
| PRY-199/2 | Incidencia | La prueba de velocidad en campo no alcanzó el valor pactado y se repite | sin valorar | sin valorar | — | — | 2026-10-26 |
| PRY-200/1 | Riesgo | Cambio en la norma de compartición de infraestructura que puede mover el alcance | sin valorar | sin valorar | — | — | 2026-10-17 |
| PRY-200/2 | Incidencia | Subasta de espectro aplazada por el regulador (reclasificado: ya ocurrió) | sin valorar | sin valorar | — | — | 2026-10-17 |
| PRY-200/3 | Incidencia | La prueba de velocidad en campo no alcanzó el valor pactado y se repite | sin valorar | sin valorar | — | — | 2026-10-17 |
| PRY-200/4 | Incidencia | Se reprogramó la llegada de los equipos de radio por demoras en la aduana | sin valorar | sin valorar | — | — | 2026-10-17 |
| PRY-201/1 | Incidencia | Subasta de espectro aplazada por el regulador (reclasificado: ya ocurrió) | sin valorar | sin valorar | — | — | 2026-10-17 |
| PRY-201/2 | Riesgo | Concentración del conocimiento en una sola persona | sin valorar | sin valorar | — | — | 2026-10-17 |
| PRY-201/3 | Incidencia | El equipo perdió dos semanas por rotación del gerente de despliegue | sin valorar | sin valorar | — | — | 2026-10-17 |
| PRY-202/1 | Riesgo | Concentración del conocimiento en una sola persona | sin valorar | sin valorar | — | — | 2026-10-25 |
| PRY-203/1 | Riesgo | Concentración del conocimiento en una sola persona | sin valorar | sin valorar | — | — | 2026-10-18 |
| PRY-203/2 | Dependencia | Permisos municipales para instalar antenas (reclasificado: depende de la alcaldía) | sin valorar | sin valorar | — | — | 2026-10-18 |
| PRY-203/3 | Incidencia | El equipo perdió dos semanas por rotación del gerente de despliegue | sin valorar | sin valorar | — | — | 2026-10-18 |
| PRY-203/4 | Incidencia | La alcaldía detuvo la instalación de antenas en dos barrios durante diez días | sin valorar | sin valorar | — | — | 2026-10-18 |
| PRY-204/1 | Dependencia | El proveedor no ha confirmado la fecha de la última entrega (reclasificado: depende del proveedor) | sin valorar | sin valorar | — | — | 2026-10-26 |
| PRY-204/2 | Incidencia | Subasta de espectro aplazada por el regulador (reclasificado: ya ocurrió) | sin valorar | sin valorar | — | — | 2026-10-26 |
| PRY-205/1 | Riesgo | Concentración del conocimiento en una sola persona | sin valorar | sin valorar | — | — | 2026-10-23 |
| PRY-205/2 | Incidencia | Se reprogramó la llegada de los equipos de radio por demoras en la aduana | sin valorar | sin valorar | — | — | 2026-10-23 |
| PRY-206/1 | Incidencia | Subasta de espectro aplazada por el regulador (reclasificado: ya ocurrió) | sin valorar | sin valorar | — | — | 2026-10-25 |
| PRY-206/2 | Riesgo | Cambio en la norma de compartición de infraestructura que puede mover el alcance | sin valorar | sin valorar | — | — | 2026-10-25 |
| PRY-206/3 | Incidencia | El equipo perdió dos semanas por rotación del gerente de despliegue | sin valorar | sin valorar | — | — | 2026-10-25 |
| PRY-207/1 | Dependencia | Permisos municipales para instalar antenas (reclasificado: depende de la alcaldía) | sin valorar | sin valorar | — | — | 2026-10-20 |
| PRY-207/2 | Incidencia | El equipo perdió dos semanas por rotación del gerente de despliegue | sin valorar | sin valorar | — | — | 2026-10-20 |
| PRY-207/3 | Incidencia | La alcaldía detuvo la instalación de antenas en dos barrios durante diez días | sin valorar | sin valorar | — | — | 2026-10-20 |
| PRY-208/1 | Riesgo | Cambio en la norma de compartición de infraestructura que puede mover el alcance | sin valorar | sin valorar | — | — | 2026-10-21 |
| PRY-209/1 | Riesgo | Concentración del conocimiento en una sola persona | sin valorar | sin valorar | — | — | 2026-10-26 |
| PRY-209/2 | Dependencia | Permisos municipales para instalar antenas (reclasificado: depende de la alcaldía) | sin valorar | sin valorar | — | — | 2026-10-26 |
| PRY-209/3 | Incidencia | Se reprogramó la llegada de los equipos de radio por demoras en la aduana | sin valorar | sin valorar | — | — | 2026-10-26 |
| PRY-210/1 | Dependencia | Permisos municipales para instalar antenas (reclasificado: depende de la alcaldía) | sin valorar | sin valorar | — | — | 2026-10-28 |
| PRY-210/2 | Incidencia | La alcaldía detuvo la instalación de antenas en dos barrios durante diez días | sin valorar | sin valorar | — | — | sin fecha |
| PRY-211/1 | Riesgo | Concentración del conocimiento en una sola persona | sin valorar | sin valorar | — | — | 2026-10-28 |
| PRY-211/2 | Riesgo | El proveedor podría no llegar con el equipo completo para la siguiente fase **[no registrado formalmente]** | sin valorar | sin valorar | — | — | 2026-10-28 |
| PRY-211/3 | Incidencia | La prueba de velocidad en campo no alcanzó el valor pactado y se repite | sin valorar | sin valorar | — | — | sin fecha |

### Después
- **Subir a comité (2026-11-04):** los cinco hechos compartidos de la tabla "Necesitan decisión ahora", con la pregunta cerrada: ¿quién es el doliente único y para qué fecha?
- **Proponer doliente:** para los ítems de un solo proyecto, el candidato natural es el gerente de cada proyecto según su ficha; es una propuesta, no una asignación.
- **Formalizar o descartar** el riesgo del proveedor de PRY-211 (decide el gerente).
- **Pedir a cada gerente** que declare dependencias entre proyectos y supuestos, hoy en blanco.

*Pie de rigor: borrador de trabajo hecho solo con los documentos citados; no sé lo que se habló fuera de ellos. La verificación de cada dato es suya.*
