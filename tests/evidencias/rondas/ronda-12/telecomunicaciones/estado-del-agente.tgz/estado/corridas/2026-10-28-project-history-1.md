# Corrida del 2026-10-28 · project-history

13 proyectos · 64 s · 70 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `vendor_deliverable_late` | 10 |
| `commitment_overdue` | 9 |
| `progress_vs_plan` | 7 |
| `commitment_rescheduled` | 7 |
| `variance_time` | 5 |
| `declared_vs_evidence` | 3 |
| `rebaseline_unauthorized` | 3 |
| `commitment_undated` | 2 |
| `vendor_accepted_without_evidence` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `vendor_invoiced_without_delivery` | 1 |
| `variance_cost` | 1 |

Historia de PRY-206 sobre 10 documentos (2026-03-08 a 2026-10-26). 1 replanificación de 93 días sin autorización registrada, 0 cambios de gobierno, factura FV-1381 con 80.325.470 COP sobre lo recibido. No pudo fechar el punto de separación (un solo informe de estado) ni saber si CC-01 se trató fuera del acta.

Contra la corrida del 2026-10-28: +0 hallazgos.

## Lo que produjo

Términos vigentes (v1.3, aceptados por José Francisco Ñáñez el 2026-10-28): no hubo que registrarlos de nuevo.

## Historia · PRY-206 · Centro de operaciones de red unificado · 2026-03-08 a 2026-10-26

**Leí:** 10 documentos entre 2026-03-08 y 2026-10-26
**Trimestres sin un solo documento:** abril–junio de 2026 (el segundo trimestre completo). El primero solo tiene documentos de marzo.

### En una línea
El proyecto nació el 2026-03-18 con cierre al 2027-09-14 y 4.200.000.000 COP. Entre esa fecha y el 2026-08-02 la carpeta no tiene ningún documento de seguimiento. Entre el 2026-09-22 y el 2026-10-26 pasaron cinco cosas: se radicó una factura por más de lo recibido, se firmó el acta del diseño de red, se pidió una ampliación de alcance de +93 días, se movió el cierre al 2027-12-16 y se declaró 65 % de avance con un solo hito cerrado de cinco.

### Las cuatro cifras
| Replanificaciones | Atraso acumulado vs. original | Meses declarando sin sustento | Cambios de gobierno |
|---|---|---|---|
| 1 | 93 días (17.4 %) | No calculable: solo hay un informe de estado (2026-10-25) | 0 |

### Línea de tiempo
| Fecha | Documento | Qué cambió |
|---|---|---|
| 2026-03-08 | `00-gobierno/2026-03-08-contrato-ct-381.docx` | Contrato con Redes y Radio Andinas Ltda.: 4 entregables de 187.360.587 COP cada uno. Se factura contra acta de recibo firmada por el gerente. |
| 2026-03-18 | `00-gobierno/2026-03-18-acta-constitucion.docx` | Se aprueban 4.200.000.000 COP, inicio 2026-03-28 y cierre 2027-09-14. Patrocinadora Diana Molina, gerente Javier Hoyos, Comité de Producto. |
| 2026-03-18 | `10-plan/2026-03-18-cronograma-v1.xml` | Línea base v1: 5 hitos, el último (Lanzamiento comercial) el 2027-09-14. |
| 2026-08-02 | `20-seguimiento/2026-08-02-acta-recibo-ct-381-suministro-de-antenas-y-radios.md` | Javier Hoyos recibe "Suministro de antenas y radios". Se había comprometido para el 2026-07-23. |
| 2026-09-22 | `20-seguimiento/2026-09-22-factura-ct-381.pdf` | Factura FV-1381 por 267.686.057 COP, "Entregables del contrato CT-381", sin detalle por entregable. |
| 2026-10-16 | `20-seguimiento/2026-10-16-acta-recibo-diseño-de-red-aprobado.pdf` | Acta de recibo de "Diseño de red aprobado", hito que el cronograma fecha el 2026-07-13. |
| 2026-10-19 | `20-seguimiento/2026-10-19-solicitud-cambio-cc-01.md` | Javier Hoyos pide ampliación de alcance: +93 días y 186.000.000 COP adicionales. Autorización: "Pendiente de presentación al comité". |
| 2026-10-25 | `10-plan/2026-10-25-cronograma-v2.xlsx` | Línea base v2: Lanzamiento comercial pasa del 2027-09-14 al 2027-12-16. Los otros cuatro hitos no cambian. |
| 2026-10-25 | `20-seguimiento/2026-10-25-informe-avance.pdf` | Estado declarado Rojo, avance 65 %. Proyección al cierre 4.261.219.163 COP. |
| 2026-10-26 | `30-reuniones/2026-10-26-comite-semanal.docx` | Comité con Javier Hoyos y Diana Molina. Un compromiso: Ricardo Salas, "Entregar el punto 35", para el 2026-10-25. |

Anotación de fechas: el cronograma v1 (fechado 2026-03-18) ya muestra "Diseño de red aprobado" al 100 % y "cerrado", y el contrato (fechado 2026-03-08) ya marca "recibido" el primer entregable. Ambos hechos son posteriores a la fecha de sus documentos. Los archivos se editaron después de esa fecha o la fecha del nombre no es la del contenido. Esto lo debe aclarar quien los guarda.

### Replanificaciones
| Nº | Fecha | Fecha de cierre nueva | Motivo declarado | Documento que la aprobó |
|---|---|---|---|---|
| 1 | 2026-10-25 (v2) | 2027-12-16 (+93 días vs. 2027-09-14) | El cronograma v2 no declara motivo. CC-01 pide los mismos +93 días por una ampliación de alcance. | Ninguno. CC-01 está "pendiente de presentación al comité" y el acta del comité del 2026-10-26 no registra que se haya tratado ni aprobado. |

Contra la línea base vigente el atraso es 0 días, porque la vigente ya es la v2. Contra la original son 93 días. Los 93 días movidos no tienen autorización registrada. Esta es una replanificación sin aprobación documentada, no sin motivo: el motivo (ampliación de alcance) existe en CC-01, pero está sin autorizar.

### Gobierno
| Fecha | Qué cambió | Documento |
|---|---|---|
| — | Sin cambios de gobierno en los documentos. Patrocinadora, gerente y comité son los mismos en el acta de constitución (2026-03-18) y en el comité del 2026-10-26. | — |

Un solo dato de gobierno aparece en el acta de constitución y no se ha movido: producto asociado "No aplica". Sin producto asociado la ficha no tiene a quién cruzar con un producto.

### Compromisos que se repitieron
| Doliente | Qué | Veces | Fechas prometidas |
|---|---|---|---|
| Ricardo Salas | Entregar el punto 35 | 1 | 2026-10-25 (vencido hace 3 días a la fecha de corte, sin evidencia de entrega) |

Ningún compromiso se repitió: hay un solo acta de comité y un solo compromiso. Ricardo Salas no figura entre los asistentes de esa reunión, y el acta no dice qué es el "punto 35".

### Desde cuándo lo declarado no se sostiene
No se puede fechar un deslizamiento. La carpeta tiene un solo informe de estado, el del 2026-10-25, y sin serie anterior no hay desde cuándo medir.

Lo que sí se ve en ese único corte: declara 65 % de avance, y el plan sustenta entre 20 % y 40 % (1 hito cerrado de 5). El primer hito sin evidencia es "Permisos de instalación obtenidos", fechado para el 2026-10-28: sigue pendiente y no está vencido. El informe, además, no menciona la ampliación de alcance (CC-01) ni los 93 días de la nueva línea base, que estaban escritos seis y cero días antes. Sí reporta dos semanas perdidas por rotación del gerente de despliegue, un presupuesto con proyección 1,5 % sobre lo aprobado y dos riesgos abiertos (subasta de espectro aplazada, cambio en la norma de compartición de infraestructura).

Con el proveedor, la brecha empieza antes. El 2026-09-22 se radicó una factura por 267.686.057 COP. Hay un solo acta de recibo del contrato (187.360.587 COP, 2026-08-02). La diferencia es 80.325.470 COP facturados sin acta, contra la condición de pago del contrato.

### Lecciones ancladas a un hecho
1. **El hito se cierra por el plan, no por el recibo.** Hecho: "Diseño de red aprobado" figura cerrado el 2026-07-13 en el cronograma, y su acta de recibo es del 2026-10-16. Efecto: entre una fecha y otra, el cierre del hito no tenía documento que lo sustentara en la carpeta.
2. **Se facturó por encima de lo recibido.** Hecho: FV-1381 (2026-09-22) suma 267.686.057 COP y la única acta de recibo del contrato cubre 187.360.587 COP. Efecto: 80.325.470 COP radicados en cuentas por pagar sin acta que los respalde.
3. **Se movió la línea base antes de que el cambio llegara al comité.** Hecho: CC-01 (2026-10-19) queda "pendiente de presentación al comité"; el cronograma v2 con el cierre al 2027-12-16 es del 2026-10-25, y el comité del 2026-10-26 no deja registro de CC-01. Efecto: 93 días de atraso contra la línea base original, sin autorización.
4. **El alcance aprobado no permite medir una ampliación.** Hecho: el acta de constitución lista "Componente 1, 2, 3" y como fuera de alcance "Lo que otro proyecto cubre". Efecto: CC-01 pide ampliar un alcance que el acta no describe. Si se aprueba, no hay un alcance original contra el cual medir lo ampliado.

Esta historia dice qué quedó escrito y cuándo. No dice por qué ni de quién fue la decisión. Que el cronograma se moviera antes de la autorización, o que la factura saliera antes del acta, no indica intención. Esa conversación es de una persona, y tiene que ser con datos.

### Lo que no sé
- El primer semestre de 2026 está casi vacío en la carpeta (abril a julio sin ningún documento): puede ser que no pasó nada o que no se guardó.
- No sé si CC-01 se presentó al comité fuera del acta del 2026-10-26, ni si se aprobó verbalmente.
- No sé si el 65 % incluye trabajo que el plan no mide como hito.
- No sé si los 186.000.000 COP de CC-01 están dentro de la proyección de 4.261.219.163 COP.
- La ficha de PRY-206 no tiene producto, autoridad ni fase.

### Ofrezco
Llevar esta historia a un cierre o al comité del 2026-11-04, con la decisión sobre CC-01 y la factura FV-1381 como los dos puntos que requieren a alguien.

**Pie de rigor:** 10 documentos leídos en su versión de caché; la cita de cada dato apunta al original. Todas las cifras derivadas salen de `portafolio.py compute` con fecha de corte 2026-10-28. Las que no da el script (meses declarando sin sustento) no se calcularon.
