# Portafolio — 2026-10-28
13 proyectos · 10 con hallazgos (70 señales) · fichas cargadas: 13, todas con fecha 2026-10-28 (frescas) · términos 1.3 vigentes, aceptados por José Francisco Ñáñez el 2026-10-28.

Formato `html`: informe generado por `informe.py` en `reportes/` (23 páginas). Dos vistas con audiencias distintas:
- `reportes/index.html` — por campo, con la cadena de evidencia completa. Para quien va a actuar.
- `reportes/decisiones.html` — por decisión, para el patrocinador: solo lo que excede la facultad de la gerencia, como pregunta cerrada y con la consecuencia de no decidir.
- Además: una página por proyecto (`PRY-199.html` … `PRY-211.html`), por producto, `productos.html` y `proyectos.html`.
- El PDF sale de imprimir el HTML.

## Qué cambió desde la corrida anterior
Sin instantánea previa: esta es la primera corrida, el punto de partida. No hay delta. El diff contra la única instantánea (2026-10-28) devuelve 0 cambios.

## Contradicciones abiertas
Verdes contradichos por la evidencia: 3.
- PRY-201 Fibra hasta el hogar fase 3: declara verde (informe 2026-10-17); 4 hitos «cumplidos» sin evidencia, avance 51 % contra 5 de 5 hitos, entregables de proveedor vencidos.
- PRY-202 Modernización de la red de transporte: declara verde (informe 2026-10-25); 4 hitos sin evidencia, avance 52 % con 5 de 5 hitos cumplidos.
- PRY-207 Facturación convergente: declara verde (informe 2026-10-20); 2 hitos sin evidencia, avance 35 % con 4 de 4 hitos cumplidos.

## Hitos vencidos sin evidencia
Ningún hito pendiente venció. Lo que aparece es el caso contrario: hitos declarados cumplidos sin evidencia (20 en total).
| Proyecto | Hitos «cumplidos» sin evidencia | Más antiguo (días desde su fecha) |
|---|---|---|
| PRY-200 | 4 | Diseño de red aprobado, 465 |
| PRY-201 | 4 | Diseño de red aprobado, 352 |
| PRY-202 | 4 | Permisos de instalación, 370 |
| PRY-207 | 2 | Diseño de red aprobado, 442 |
| PRY-211 | 2 | Diseño de red aprobado, 248 |
| PRY-204 | 1 | Diseño de red aprobado, 125 |
| PRY-205 | 1 | Permisos de instalación, 60 |
| PRY-209 | 1 | Sitios construidos, 37 |
| PRY-210 | 1 | Diseño de red aprobado, 71 |

## Proyectos en silencio
Vacía: umbral de 15 días; el más callado es PRY-203, con 10 días.

## Dependencias en riesgo
`compute` no devolvió ninguna señal de dependencia; no se revisó a mano.

## Sin sustento
Avance declarado contra lo que sostiene el plan:
- Por debajo de lo declarado: PRY-200 (59 %), PRY-201 (51 %), PRY-202 (52 %), PRY-207 (35 %), PRY-211 (49 %): todos con todos sus hitos marcados cumplidos.
- Por encima de lo que el plan sostiene: PRY-206 (declara 65 %, el plan sostiene 20–40 %) y PRY-210 (declara 50 %, plan 20–40 %).

Proveedores:
- PRY-209: facturado 1.164.831.714 sin entrega registrada de 3 entregables (Obras Civiles de Telecomunicaciones).
- PRY-206: facturado 267.686.057 contra 187.360.587 aceptado, diferencia 80.325.470 (Redes y Radio Andinas).
- PRY-200: «Bolsa de horas de ingeniería» aceptada sin evidencia; 3 entregables vencidos hace 346–398 días.
- Entregables de proveedor vencidos también en PRY-201, PRY-209 y PRY-211.

## Vacíos de información
- Ningún proyecto tiene autoridad registrada (13 de 13 sin `authority`).
- 7 proyectos sin producto asignado: PRY-202, 203, 205, 206, 207, 209, 210.
- Compromisos sin fecha: PRY-210 (Natalia Ospina), PRY-211 (Laura Vélez).
- Sin problemas de estructura en las fichas.

## Estado general
| Proyecto | Desviación vs original | vs vigente | Replanificaciones | Señales |
|---|---|---|---|---|
| PRY-199 | 0 | 0 | 0 | 0 |
| PRY-200 | 0 | 0 | 0 | 10 |
| PRY-201 | 0 | 0 | 0 | 9 |
| PRY-202 | 0 | 0 | 0 | 6 |
| PRY-203 | 0 | 0 | 0 | 0 |
| PRY-204 | 0 | 0 | 0 | 2 |
| PRY-205 | +104 d (22,8 %) | 0 | 1 | 2 |
| PRY-206 | +93 d (17,4 %) | 0 | 1 | 5 |
| PRY-207 | 0 | 0 | 0 | 4 |
| PRY-208 | 0 | 0 | 0 | 0 |
| PRY-209 | +82 d (27,2 %) | 0 | 1 | 5 |
| PRY-210 | +110 d (25,6 %); costo +19,7 % (proyección 3.951.444.314 contra 3.300.000.000 aprobados) | 0 | 1 | 6 |
| PRY-211 | +102 d (53,1 %) | 0 | 1 | 21 |

Replanificaciones sin autorización: PRY-206 (93 d), PRY-210 (110 d), PRY-211 (102 d); ninguna aprobada.
PRY-211 concentra 21 señales: 6 compromisos vencidos, 7 reprogramados (el de Gustavo Neira, 6 veces), 2 entregables de proveedor vencidos.
Compromisos vencidos también en PRY-200 (22 d), PRY-204 (8 d) y PRY-206 (3 d).

## Necesito que confirmes
Ninguna: `compute` no marcó campos viejos (umbral 12 meses) y es la primera corrida.

---
Pie: criterio-portfolio 0.12.1 · fichas aplicadas: 13, fechadas 2026-10-28 · campos inciertos: no se contaron en esta corrida · términos 1.3: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.12.1
