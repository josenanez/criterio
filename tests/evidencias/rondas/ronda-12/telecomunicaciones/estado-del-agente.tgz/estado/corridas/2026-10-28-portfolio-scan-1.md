# Corrida del 2026-10-28 · portfolio-scan

13 proyectos · 92 documentos, 0 releídos y 92 sin cambio · 205 s · 70 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `vendor_deliverable_late` | 10 |
| `commitment_overdue` | 9 |
| `progress_vs_plan` | 7 |
| `commitment_rescheduled` | 7 |
| `variance_time` | 5 |
| `declared_vs_evidence` | 3 |
| `rebaseline_unauthorized` | 3 |
| `commitment_undated` | 2 |
| `vendor_accepted_without_evidence` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `vendor_invoiced_without_delivery` | 1 |
| `variance_cost` | 1 |

10 fichas nuevas (PRY-199 a 207 y 209), 66 documentos leídos, 26 sin cambio (PRY-208, 210, 211). Nada movido: no existe entrada/. 4 cronogramas .xml leídos vía texto.py. Mirar: 17 hitos cerrados sin acta, facturas sin acta de recibo (PRY-209, 200, 206), CC-01 de PRY-206 pendiente con cronograma v2 ya movido, 3 compromisos vencidos.

Contra la corrida del 2026-10-28: +43 hallazgos.

## Lo que produjo

## Barrido — 2026-10-28

Encontré 92 documentos en `documentos/proyectos`, repartidos en 13 carpetas de proyecto (PRY-199 a PRY-211). Formatos: 39 .md, 19 .docx, 16 .pdf, 9 .xlsx, 4 .xml, 3 .csv, 1 .json y 1 .txt. Términos vigentes (versión 1.3, aceptados por José Francisco Ñáñez el 2026-10-28); no hizo falta registrarlos otra vez. Configuración: `workers: 1`, así que los proyectos se leyeron uno tras otro, sin subagentes.

**Documentos:** 92 en la carpeta · 66 leídos · 26 sin cambio desde la corrida anterior (PRY-208, PRY-210 y PRY-211, no se abrieron) · 0 ilegibles
**Proyectos:** 13 con ficha · 10 nuevos (PRY-199 a PRY-207 y PRY-209) · 0 sin carpeta propia

### Nuevos
| Proyecto | Documentos | Campos encontrados | Campos sin dato |
|---|---|---|---|
| PRY-199 Cambio de mobiliario de la sala de espera | 6 | identidad, presupuesto, 5 hitos, 1 contrato, 1 compromiso | authority, phase, factura de CT-199 |
| PRY-200 Despliegue de 5G en ciudades intermedias | 11 | identidad, presupuesto, 5 hitos, 2 contratos con 2 facturas, 1 compromiso | authority, phase |
| PRY-201 Fibra hasta el hogar fase 3 | 6 | identidad, presupuesto, 5 hitos, 1 contrato, 1 compromiso | authority, phase, factura de CT-801 |
| PRY-202 Modernización de la red de transporte | 4 | identidad, presupuesto, 5 hitos | authority, phase, producto («No aplica»), contratos, minutas |
| PRY-203 Migración del core de voz a la nube | 2 | identidad, presupuesto, informe | authority, phase, producto («No aplica»), cronograma, contratos, minutas |
| PRY-204 Torres compartidas en zonas rurales | 4 | identidad, presupuesto, 3 hitos, 1 compromiso | authority, phase, contratos |
| PRY-205 Portabilidad numérica en línea | 7 | identidad, presupuesto, 4 hitos en 2 líneas base, CC-01, 1 compromiso | authority, phase, producto («No aplica»), contratos |
| PRY-206 Centro de operaciones de red unificado | 10 | identidad, presupuesto, 5 hitos en 2 versiones, 1 contrato con factura, CC-01, 1 compromiso | authority, phase, producto («No aplica») |
| PRY-207 Facturación convergente | 6 | identidad, presupuesto, 4 hitos, 1 compromiso | authority, phase, producto («No aplica»), contratos |
| PRY-209 Apagado de la red 3G | 10 | identidad, presupuesto, 5 hitos en 2 líneas base, 1 contrato con factura, CC-01, 1 compromiso | authority, phase, producto («No aplica») |

### Actualizados
| Proyecto | Qué cambió | Fuente |
|---|---|---|
| — | Ninguno. PRY-208, PRY-210 y PRY-211 no tuvieron documentos nuevos ni cambiados, y su ficha se conserva. | plan de lectura (`to_read` = 66, `unchanged` = 26) |

### Lo que hay que mirar (de las fichas nuevas)
Las cifras salen de las fichas; el cálculo y el semáforo los hace `portfolio-report`.

- **Hitos cerrados sin acta de recibo que lo pruebe:** 17. PRY-200, PRY-201 y PRY-202 tienen 4 cada uno (cada cronograma da 5 hitos como cerrados y solo hay 1 acta); PRY-207 tiene 2; PRY-204, PRY-205 y PRY-209 tienen 1.
- **Proyectos pasados de su fecha de cierre con avance reportado menor a 100%:** PRY-200 (cierre 2025-12-19, 59%, amarillo), PRY-207 (2026-01-03, 35%, verde), PRY-202 (2026-03-18, 52%, verde) y PRY-201 (2026-09-02, 51%, verde). En los cuatro el cronograma da por cerrado el hito final o el último.
- **Facturado contra lo recibido:**
  - PRY-209, CT-604: factura FV-1604 por 1.164.831.714 COP y ningún acta de recibo; los tres entregables siguen «pendiente».
  - PRY-200, CT-478: factura por 531.795.504 COP (dos entregables). Hay acta de uno solo; «Bolsa de horas de ingeniería» figura «recibido» en el contrato sin acta.
  - PRY-206, CT-381: factura por 267.686.057 COP; el único entregable con acta vale 187.360.587 COP.
  - PRY-200, CT-235: la factura (265.104.460 COP) coincide con el único entregable recibido, que tiene acta.
- **Entregables con fecha vencida y sin acta:** PRY-201 CT-801 (3 de 3), PRY-200 CT-235 (2) y CT-478 (1), PRY-209 CT-604 (2).
- **Cambios de alcance:**
  - PRY-206 CC-01 sigue «pendiente de presentación al comité», pero el cronograma v2 del 2026-10-25 ya mueve el lanzamiento de 2027-09-14 a 2027-12-16. La fecha de cierre queda `ambiguous`.
  - PRY-205 y PRY-209 CC-01 dicen «autorizada por el comité»; las minutas del 2026-10-21 y 2026-10-25 no los mencionan.
  - En PRY-205 y PRY-209 los informes de avance siguen con el presupuesto aprobado original.
- **Compromisos vencidos sin evidencia de cumplimiento:** 3.
  - PRY-200, Carlos Peña, «punto 26», para 2026-10-06.
  - PRY-204, Jorge Medina, «punto 8», para 2026-10-20.
  - PRY-206, Ricardo Salas, «punto 35», para 2026-10-25.
  - En los tres, la fecha es anterior a la minuta que los registra.
- **Cifras que no cuadran dentro del mismo informe:** en PRY-203 y PRY-206 el ejecutado declarado supera al comprometido declarado.
- **PRY-199:** el nombre habla de mobiliario de una sala de espera, pero el contrato es de antenas, ingeniería y fibra, y el hito es un diseño de red. El informe lo declara verde y dice que la prueba de velocidad en campo no alcanzó el valor pactado.

### No pude leer
| Archivo | Por qué |
|---|---|
| — | Ninguno. El inventario marcó 4 cronogramas .xml (PRY-200, 201, 204 y 206) como «formato que no se lee sin instalar algo»; `texto.py` los convirtió sin problema y los leí por su texto. La cita va al .xml original. |

### Movidos desde entrada/
| Archivo | A qué proyecto | Por qué |
|---|---|---|
| — | — | No existe carpeta `entrada/` en la documentación; no se movió nada. |

### Pendientes de clasificar
| Archivo | Por qué no pude decidir |
|---|---|
| — | Ninguno. |

---
criterio-portfolio 0.12.1 · fichas tocadas: 10 (PRY-199 a PRY-207 y PRY-209) · `not_found` en todas: `identity.authority` e `identity.phase`; además producto (6), cronograma (PRY-203), contratos (PRY-202, 203, 204, 205, 207), minutas (PRY-202, 203) y factura (PRY-199, 201). Términos: https://www.josenanez.com/es/agents/criterio-pmo/legal
