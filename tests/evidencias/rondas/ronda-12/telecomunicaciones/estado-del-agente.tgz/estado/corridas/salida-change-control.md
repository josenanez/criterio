Sale de la ficha `estado/records/PRY-200.json` (corte 2026-10-17, actualizada 2026-10-28) y del acta de constitución de 2025-06-03. Términos v1.3 vigentes, aceptados por José Francisco Ñáñez el 2026-10-28.

## Solicitud de cambio — PRY-200 Despliegue de 5G en ciudades intermedias — 2026-10-28

**Qué se pide:** mover 30 días la salida a producción. **Quién lo pide:** no consta en la solicitud (la invocación no lo dice). **Por qué:** no consta; no hay motivo escrito. Un cambio sin motivo ni solicitante no puede quedar como línea base nueva.

### Impacto
| Dimensión | Hoy | Con el cambio | Diferencia |
|---|---|---|---|
| Alcance | Componentes 1, 2 y 3 (acta, 2025-06-03) | Sin impacto declarado | No declarado |
| Tiempo | Cierre y «Lanzamiento comercial» 2025-12-19 (línea base v1, cronograma-v1.xml) | 2026-01-18 (cálculo del script: 2025-12-19 + 30 días) | +30 días |
| Costo | Aprobado 3.300.000.000 COP; proyección declarada 3.425.145.140 COP | Sin impacto declarado | No declarado |

**Quién absorbe lo que no se declaró:** el alcance y el costo se piden sin cambio mientras se corre la fecha 30 días. Un mes más de proveedores, bolsa de horas y equipo de proyecto con el mismo presupuesto se absorbe en margen del presupuesto —que ya está agotado: la proyección declarada excede lo aprobado en 125.145.140 COP (3,8 %)— o en horas no pagadas. Hay que decirlo y pedir el costo del mes adicional.

**Problema de fondo con la fecha pedida:** la fecha vigente (2025-12-19) venció hace 313 días y el nuevo cierre que sale de sumar 30 días (2026-01-18) venció hace 283. Mover «30 días» sobre una fecha ya vencida no describe el plan real. No se inventa una fecha nueva: hace falta que quien pide el cambio diga a qué fecha real se mueve y desde cuándo se sabía.

### Lo que la ficha dice y la evidencia no sostiene
- Los 5 hitos están declarados como cumplidos con sus fechas originales; 4 de 5 sin evidencia (Diseño de red, Permisos, Integración con la red, Lanzamiento comercial). Solo «Sitios construidos» tiene acta (2026-10-16, y su fecha de recibo es 12 meses posterior a la fecha del hito, 2025-10-04).
- Si «Lanzamiento comercial» estuviera cumplido, no habría nada que mover. El informe de avance del 2026-10-17 dice 59 % y estado amarillo: se contradice con 5/5 hitos cumplidos (brecha de 41 puntos).
- Entregables de proveedores vencidos y pendientes: Bolsa de horas (CT-235) 398 días, Tendido de fibra (CT-235 y CT-478) 346 días. CT-478 figura con la bolsa de horas aceptada sin evidencia.
- Líneas base: una sola (v1, 2025-06-03); 0 replanificaciones registradas; 0 cambios aprobados en la ficha. El atraso contra la original, medido por el script, sale 0 días porque la ficha nunca movió las fechas: eso no es puntualidad, es que el plan no se actualizó.
- Hay un compromiso vencido sin evidencia: Carlos Peña, «Entregar el punto 26», para 2026-10-06 (22 días).

### Efecto en el portafolio
Cálculo del script (`impact`, 30 días): **0 proyectos alcanzados**, 0 que no puedan sostener su fecha, 0 dependencias sin confirmar.

Ese cero solo dice que el acta declara «Ninguna declarada» como dependencias y la ficha tiene `dependencies: []`. **No prueba que no haya efecto**: el producto «planes 5G» y los proveedores CT-235 y CT-478 pueden afectar a otros proyectos que nadie declaró. Tampoco se sabe cuántos días se mueve cada actividad: la ficha no tiene holgura por actividad.

| Proyecto afectado | Cómo | Gerente |
|---|---|---|
| Ninguno declarado | — | Óscar Ramírez (gerente de PRY-200) |

### Quién decide
**Autoridad requerida:** no determinable. El campo de autoridad no existe en el acta (`identity.authority`: no encontrado). El acta solo nombra un **Comité de Cambios** como órgano y a Natalia Ospina como patrocinadora, sin umbrales de tiempo ni costo.
**Según:** acta de constitución 2025-06-03 (sin cláusula de autoridad).
**Va a comité:** sí, por defecto —es el órgano nombrado que aprobó el presupuesto y la línea base v1—, y el hallazgo de fondo es que no hay autoridad declarada que permita decidir si lo podría aprobar la patrocinadora o la gerencia sola. Último comité con documento: 2026-10-19 (asistentes Óscar Ramírez y Natalia Ospina); no trató este cambio. Próximo comité semanal en configuración: 2026-11-04.

### Si no se aprueba
El proyecto sigue con cierre 2025-12-19, ya vencido por 313 días. Seguiría reportándose en amarillo con 59 % contra un plan que dice 100 %, sin fecha creíble, con la proyección por encima del presupuesto aprobado (3.425.145.140 vs 3.300.000.000) y entregables de proveedores vencidos.

### Si se aprueba
**No se registra línea base nueva en esta corrida:** no hay aprobación ni documento que la autorice, y la fecha pedida no es una fecha real.
Si el comité la aprobara con los datos completos sería la línea base 2 — cierre [fecha real por definir] · presupuesto [a definir; hoy 3.300.000.000 COP aprobados] · motivo: [por escribir]. La v1 no se toca.
Desviación acumulada contra la línea base original: **tiempo** — contra 2025-12-19, ya hay al menos 313 días a la fecha de hoy sin que ningún documento los autorice, y aun con el cambio pedido (2026-01-18) la fecha quedaría 283 días en el pasado, sin una salida real; **costo** — +125.145.140 COP (+3,8 %) sobre lo aprobado según la proyección declarada, sin cambio aprobado que lo cubra.

### Qué no se sabe
- Quién pide el cambio, por qué y a qué fecha real se llevaría.
- El costo del mes adicional y cualquier impacto de alcance.
- La autoridad que decide, y si el Comité de Cambios tiene umbrales.
- Si otros proyectos dependen de la salida a producción de PRY-200.
- Si de verdad los hitos están cumplidos: faltan las evidencias de 4 de 5.

### Después
Se recomienda llevar el paquete al Comité de Cambios (2026-11-04), con solicitante, motivo, fecha real y costo del mes adicional, y con el mismo comité confirmando antes si los hitos declarados cumplidos son reales. Registrar la línea base 2 solo cuando esté aprobada por quien podía aprobarla.

---
Rigor: cifras de la ficha PRY-200 y cálculos del script `portafolio.py` (`impact`, `compute`); las fechas y montos citan el acta, el cronograma-v1 y el informe de avance del 2026-10-17. Lo declarado por el gerente se distingue de lo sustentado: ver «Lo que la ficha dice y la evidencia no sostiene». Todo lo marcado «no consta» no se supone.
