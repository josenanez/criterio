# Corrida del 2026-10-28 · document-index

13 proyectos · 8 s · 70 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `vendor_deliverable_late` | 10 |
| `commitment_overdue` | 9 |
| `progress_vs_plan` | 7 |
| `commitment_rescheduled` | 7 |
| `variance_time` | 5 |
| `declared_vs_evidence` | 3 |
| `rebaseline_unauthorized` | 3 |
| `commitment_undated` | 2 |
| `vendor_accepted_without_evidence` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `vendor_invoiced_without_delivery` | 1 |
| `variance_cost` | 1 |

92 documentos, todos sin cambio; nada que releer, sin renombrados, borrados ni citas rotas.

Contra la corrida del 2026-10-28: +0 hallazgos.

## Lo que produjo

Carpeta al 2026-10-28: 92 documentos, ninguno cambió. No hay nada que releer y no hay citas rotas.
