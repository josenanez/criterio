# Corrida del 2026-10-28 · status-report

13 proyectos · 30 s · 70 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `vendor_deliverable_late` | 10 |
| `commitment_overdue` | 9 |
| `progress_vs_plan` | 7 |
| `commitment_rescheduled` | 7 |
| `variance_time` | 5 |
| `declared_vs_evidence` | 3 |
| `rebaseline_unauthorized` | 3 |
| `commitment_undated` | 2 |
| `vendor_accepted_without_evidence` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `vendor_invoiced_without_delivery` | 1 |
| `variance_cost` | 1 |

Informe de PRY-201: verde declarado el 2026-10-17 contradicho por 3 señales (4 hitos cumplidos sin evidencia, avance 51 % frente a 100 % del plan, 3 entregables del proveedor vencidos). Dije que no sé la autoridad, la fase, lo facturado ni los responsables de RAID.

Contra la corrida del 2026-10-28: +0 hallazgos.

## Lo que produjo

*Informe generado desde la ficha `estado/records/PRY-201.json` (actualizada el 2026-10-28), con las cifras recalculadas por `portafolio.py compute` al 2026-10-28.*

## PRY-201 Fibra hasta el hogar fase 3 — estado al 2026-10-28

**Declara el gerente (Javier Hoyos):** verde · 51 % · al 2026-10-17 (11 días; la declaración no está vencida)
**Sustento documental:** contradicho
**Lo que el semáforo no explica:** `milestone_met_without_evidence`, `progress_vs_plan`, `vendor_deliverable_late`
**Último documento:** 2026-10-23 (5 días) · **Última reunión:** 2026-10-23 (comité semanal)

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2026-09-02 | 2026-09-02 | 0 días (sin replanificar) |
| Presupuesto | COP 6.800.000.000 | COP 6.800.000.000 | La proyección declarada es COP 6.982.625.535, 2,7 % por encima |

Replanificaciones: 0. La fecha de cierre pasó hace 56 días y la línea base sigue sin moverse, mientras el avance declarado es 51 %. La desviación en días es 0 porque nadie ha movido la fecha, no porque el proyecto vaya a tiempo.

Dinero (todo declarado en el informe del 2026-10-17, ninguna cifra respaldada por un documento de evidencia): comprometido COP 3.572.592.598 (52,5 %), ejecutado COP 3.369.704.705 (49,6 %), disponible real COP 3.227.407.402.

### Hitos
| Hito | Base | Vigente | Estado | Evidencia |
|---|---|---|---|---|
| Diseño de red aprobado | 2025-11-10 | 2025-11-10 | Declarado cumplido | Sin evidencia (352 días) |
| Permisos de instalación obtenidos | 2026-01-23 | 2026-01-23 | Cumplido | Acta de recibo del 2026-10-22 |
| Sitios construidos | 2026-04-07 | 2026-04-07 | Declarado cumplido | Sin evidencia (204 días) |
| Integración con la red | 2026-06-20 | 2026-06-20 | Declarado cumplido | Sin evidencia (130 días) |
| Lanzamiento comercial | 2026-09-02 | 2026-09-02 | Declarado cumplido | Sin evidencia (56 días) |

Cuatro de los cinco hitos figuran como cumplidos sin un documento que lo sustente.

### Dónde no coincide
- **Avance contra plan:** el gerente declara 51 % (informe del 2026-10-17). Con los cinco hitos dados por cumplidos, el plan respalda 100 %. La diferencia es de 49 puntos (`progress_vs_plan`, dirección: atrasado). Los hitos dicen una cosa y el porcentaje otra, y el informe no explica cuál es la correcta.
- **Verde contra proveedor:** el informe del 2026-10-17 reporta verde. El contrato CT-801 con Infraestructura de Torres del Sur S.A.S. tiene sus 3 entregables pendientes, ninguno aceptado y ninguno con evidencia de recibo: antenas y radios, 324 días de atraso; bolsa de horas de ingeniería, 222; tendido de fibra óptica, 121. El monto aceptado es 0. La factura no se encontró.
- **Verde contra hitos:** los cuatro hitos sin evidencia de arriba (`declared_vs_evidence`).

### Abierto
**Riesgos e incidencias sin movimiento:** hay 2 riesgos y 1 incidencia, todos tomados del informe del 2026-10-17 y ninguno con responsable ni fecha de apertura, así que los días sin movimiento no se pueden calcular.
- Riesgo: subasta de espectro aplazada por el regulador.
- Riesgo: concentración del conocimiento en una sola persona.
- Incidencia: el equipo perdió dos semanas por rotación del gerente de despliegue.

**Compromisos vencidos:** ninguno. Hay uno abierto: Beatriz Cuéllar, «entregar el punto 16», para el 2026-10-31 (dicho el 2026-10-23, sin reprogramaciones).
**Dependencias sin confirmar:** ninguna registrada en la ficha.
**Cambios de alcance, tiempo o costo:** ninguno registrado, ni aprobado ni pendiente.

### Sin dato
- Autoridad de decisión (`identity.authority`) y fase (`identity.phase`): no encontradas.
- Facturado del proveedor (`vendors[0].invoiced`): no hay factura.
- Responsable de los 2 riesgos y de la incidencia.
- 13 campos de identidad, plan y presupuesto vienen del acta de agosto de 2025 y tienen 14 meses, sobre el umbral de 12.

Con la desviación en 0 días solo porque la línea base no se ha movido, y un verde que 3 señales contradicen, ofrezco preparar el punto de comité del 2026-11-04. Como no hay replanificación formal, también puedo preparar la solicitud de cambio. Ninguna de las dos se hizo en esta corrida.

---
**Pie:** criterio-portfolio 0.12.1 · ficha de PRY-201 con fecha 2026-10-28 (declaración del gerente al 2026-10-17) · campos inciertos: autoridad, fase, facturado, responsables de RAID · términos v1.3 aceptados por José Francisco Ñáñez el 2026-10-28: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.12.1
