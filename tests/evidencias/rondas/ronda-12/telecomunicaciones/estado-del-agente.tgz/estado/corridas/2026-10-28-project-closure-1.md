# Corrida del 2026-10-28 · project-closure

13 proyectos · 64 s · 70 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `vendor_deliverable_late` | 10 |
| `commitment_overdue` | 9 |
| `progress_vs_plan` | 7 |
| `commitment_rescheduled` | 7 |
| `variance_time` | 5 |
| `declared_vs_evidence` | 3 |
| `rebaseline_unauthorized` | 3 |
| `commitment_undated` | 2 |
| `vendor_accepted_without_evidence` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `vendor_invoiced_without_delivery` | 1 |
| `variance_cost` | 1 |

Cierre de PRY-200 no sustentado: sin declaración de terminado ni evidencia de producción y medición; 4 de 5 hitos cerrados sin evidencia; 0 replanificaciones; RAID abierto sin doliente. No se archivó. Sin dato: definición de componentes, punto 26, acta de recibo de la bolsa de horas de CT-478, presupuesto ejecutado final.

Contra la corrida del 2026-10-28: +0 hallazgos.

## Lo que produjo

Criterio, cierre de PRY-200. Sale de la ficha `estado/records/PRY-200.json`, de la salida de `compute` del 2026-10-28 y de los 11 documentos de la carpeta del proyecto (acta de constitución, dos contratos, cronograma v1, dos actas de recibo, dos facturas, informe de avance del 2026-10-17 y acta del comité del 2026-10-19). Es un borrador de trabajo: la verificación es suya, y cada dato lleva su fuente.

Términos vigentes: v1.3, aceptados por José Francisco Ñáñez el 2026-10-28 (comprobante ya registrado, no se volvió a registrar).

## Cierre — PRY-200 Despliegue de 5G en ciudades intermedias — 2026-10-28

**Resultado en una línea:** no hay una declaración de terminado ni evidencia de que el proyecto terminó. Hoy no se puede cerrar por cumplimiento. Solo se podría cerrar por decisión del Comité de Cambios, y esa decisión no existe en los documentos.

### Contra lo comprometido
**Criterio de éxito:** "Despliegue de 5G en ciudades intermedias en producción y medido." (acta de constitución, 2025-06-03, `00-gobierno/2025-06-03-acta-constitucion.docx`).
**Se cumplió:** no se puede determinar. Ningún documento muestra producción ni medición. Lo único que apunta a medición es el informe de avance del 2026-10-17, que dice que la prueba de velocidad en campo no alcanzó el valor pactado y se repite.

El informe de avance (2026-10-17, Óscar Ramírez) declara estado **amarillo** y **59%** de avance. Lo que sustentan los hitos es otra cosa: el cronograma v1 marca los 5 hitos como cerrados y al 100%, pero solo uno tiene evidencia.

| Entregable comprometido (hito) | Fecha línea base | Estado | Evidencia |
|---|---|---|---|
| Diseño de red aprobado | 2025-07-20 | Declarado cerrado | Ninguna. Declarado en el cronograma v1 |
| Permisos de instalación obtenidos | 2025-08-27 | Declarado cerrado | Ninguna. Declarado en el cronograma v1 |
| Sitios construidos | 2025-10-04 | Cerrado | `20-seguimiento/2026-10-16-acta-recibo-sitios-construidos.pdf` (recibo del 2026-10-16, Óscar Ramírez) |
| Integración con la red | 2025-11-11 | Declarado cerrado | Ninguna. Declarado en el cronograma v1 |
| Lanzamiento comercial | 2025-12-19 | Declarado cerrado | Ninguna. Declarado en el cronograma v1 |

Cuatro hitos cerrados sin evidencia, según `compute`. Esos hitos vencieron hace 465, 427, 351 y 313 días, en el orden de la tabla. El avance declarado (59%) está 41,0 puntos por debajo de lo que el plan da por cumplido (100%).

El hito "Sitios construidos" tiene fecha de línea base 2025-10-04 y acta de recibo del 2026-10-16. La fecha de la línea base nunca se movió.

Alcance del acta: "Componente 1; Componente 2; Componente 3". Son marcadores sin descripción. Por eso no se puede contrastar entregado contra comprometido por componente.

### Fuera de alcance final
| Qué quedó fuera | Decidido por | Cuándo |
|---|---|---|
| Sin dato. Ningún documento registra un recorte de alcance | n/d | n/d |

El acta solo excluye "Lo que otro proyecto cubre". El control de cambios no tiene ningún cambio registrado (0 cambios). El riesgo "Cambio en la norma de compartición de infraestructura que puede mover el alcance" sigue abierto en el informe del 2026-10-17.

### Números finales
| | Original | Vigente | Final | Desviación vs original |
|---|---|---|---|---|
| Fecha de cierre | 2025-12-19 | 2025-12-19 | Sin fecha de cierre. Lanzamiento comercial sin evidencia | `compute` da 0 días. Ese 0 mide que nadie replanificó. No mide que no haya atraso: el cierre venció hace 313 días |
| Presupuesto (COP) | 3.300.000.000 | 3.300.000.000 | Sin cifra final. Proyección declarada: 3.425.145.140 | Proyección 3,8 % sobre lo aprobado |

Replanificaciones: 0. Hay una sola línea base (v1, 2025-06-03, aprobación inicial del Comité de Cambios), así que original y vigente son la misma.

Presupuesto, tal como lo declara el informe del 2026-10-17 (cifras declaradas, no sustentadas por un documento contable):
- Aprobado: 3.300.000.000.
- Comprometido: 2.493.745.794 (75,6 %).
- Ejecutado: 1.136.310.608 (34,4 %).
- Disponible real: 806.254.206.

No hay un presupuesto ejecutado final. El proyecto sigue gastando.

### RAID al cierre
**Materializados:**
- La prueba de velocidad en campo no alcanzó el valor pactado y se repite. Sin responsable ni fecha de inicio.
- Reprogramación de la llegada de los equipos de radio por demoras en aduana. Sin responsable ni fecha de inicio.

**No materializados:** ninguno se puede afirmar. Los dos riesgos registrados siguen abiertos en el informe del 2026-10-17.

**Abiertos, con doliente:**
- Riesgo: cambio en la norma de compartición de infraestructura. **Sin doliente.**
- Riesgo: subasta de espectro aplazada por el regulador. **Sin doliente.**
- Las dos incidencias anteriores. **Sin doliente.**
- Compromiso de Carlos Peña, "Entregar el punto 26", para el 2026-10-06. Vencido hace 22 días. Se registró en el comité del 2026-10-19 sin nueva fecha ni evidencia de cumplimiento. Tiene responsable, pero no hay evidencia de entrega.
- Entregables de proveedores vencidos y pendientes:
  - CT-235, Soporte de Red Continental: "Bolsa de horas de ingeniería" (vencía 2025-09-25, 398 días) y "Tendido de fibra óptica" (vencía 2025-11-16, 346 días).
  - CT-478, Fibra Óptica del Pacífico: "Tendido de fibra óptica" (vencía 2025-11-16, 346 días).
- "Bolsa de horas de ingeniería" de CT-478 figura como recibida en el contrato, pero no hay acta de recibo en la carpeta.
- Facturación: CT-478 tiene facturados 531.795.504 (FV-1478, 2026-10-11) contra dos entregables que se dicen recibidos. El contrato exige acta de recibo firmada por el gerente para facturar cada entregable. Existe el acta de "Suministro de antenas y radios" (2025-08-14) y falta la de la bolsa de horas. CT-235 tiene facturados 265.104.460 (FV-2235, 2026-09-21), cubiertos por un entregable con acta (2025-08-18).

Un proyecto con 2 riesgos, 2 incidencias y 3 entregables de proveedor abiertos, sin doliente, no está cerrado.

### Lecciones
Solo entran las que se pueden anclar a un hecho documentado.

| Qué pasó | Cuándo | Efecto | Qué haríamos distinto |
|---|---|---|---|
| El cronograma v1 se aprobó una vez y nunca se replanificó. El hito "Sitios construidos" tiene línea base 2025-10-04 y acta de recibo 2026-10-16 | Línea base 2025-06-03. Acta 2026-10-16 | La línea base sigue diciendo que los 5 hitos están cerrados al 100 %. El informe del 2026-10-17 declara 59 %. El atraso medido contra el original da 0 y el cierre venció hace 313 días | Replanificar con aprobación del comité cuando el hito se corre, para que la desviación contra la original se vea |
| Hitos marcados como cerrados sin acta ni evidencia: diseño de red, permisos, integración con la red y lanzamiento comercial | Fechas de línea base 2025-07-20, 2025-08-27, 2025-11-11 y 2025-12-19 | El avance del plan no se puede sustentar, y no hay manera de saber si el proyecto está en producción | Exigir el acta de recibo en el momento de cerrar cada hito, como se hizo con "Sitios construidos" |
| CT-478 se facturó por dos entregables recibidos con un solo acta de recibo en la carpeta, pese a que el contrato lo exige por cada entregable | Factura 2026-10-11 | 531.795.504 COP radicados en cuentas por pagar sin soporte completo según la carpeta | Revisar el acta antes de radicar la factura |

Otros posibles aprendizajes no entran por falta de fecha, doliente o efecto documentados: la aduana (sin fecha del hecho), la prueba de velocidad en campo (sin fecha del hecho) y el compromiso del punto 26 (no dice qué es "el punto 26").

### Sin dato
- Declaración de que el proyecto terminó, y quién la hace. No existe.
- Evidencia de producción y medición (criterio de éxito).
- Definición de los Componentes 1, 2 y 3 del alcance.
- Qué es el "punto 26" del compromiso de Carlos Peña.
- Responsable de cada riesgo y cada incidencia.
- Fecha de inicio de las dos incidencias.
- Autoridad que aprueba el proyecto (campo `authority`) y fase (campo `phase`): no aparecen en ningún documento.
- Presupuesto ejecutado final y cifras de un documento contable. Todo lo financiero viene del informe de avance, que es una declaración.
- Actas de recibo de "Bolsa de horas de ingeniería" de CT-478 y de los entregables pendientes de ambos contratos.
- Nada posterior al 2026-10-19: es el último documento de la carpeta.

## Qué hacer con esto
No se mueve la carpeta a `archivo/` ni se congela la ficha. Estas serían las condiciones para cerrar:
1. Que el Comité de Cambios (con Natalia Ospina como patrocinadora y Óscar Ramírez como gerente) declare el proyecto terminado por cumplimiento, o decida cerrarlo por decisión con el criterio de éxito sin cumplir. Eso quedaría en un acta.
2. Que se aporte la evidencia de los 4 hitos sin sustento.
3. Que cada riesgo, incidencia y entregable abierto tenga un doliente con nombre.
4. Que se resuelva el acta de recibo de CT-478 antes de pagar FV-1478.

---
Pie de rigor: borrador de trabajo, no decisión ni asesoría. Cifras copiadas de `compute` del 2026-10-28 y de los documentos citados. Lo que no estaba documentado se declaró como "sin dato". No se conoce lo que se habló fuera de los documentos. Verifique cada cita contra el original.
