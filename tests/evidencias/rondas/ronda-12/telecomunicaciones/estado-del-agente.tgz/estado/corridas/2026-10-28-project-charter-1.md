# Corrida del 2026-10-28 · project-charter

13 proyectos · 25 s · 70 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `vendor_deliverable_late` | 10 |
| `commitment_overdue` | 9 |
| `progress_vs_plan` | 7 |
| `commitment_rescheduled` | 7 |
| `variance_time` | 5 |
| `declared_vs_evidence` | 3 |
| `rebaseline_unauthorized` | 3 |
| `commitment_undated` | 2 |
| `vendor_accepted_without_evidence` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `vendor_invoiced_without_delivery` | 1 |
| `variance_cost` | 1 |

Revisión del acta PRY-203 (2025-11-30): faltan autoridad del gerente, supuestos, restricciones, hitos, cadencia y quién mide el éxito; alcance, exclusiones y objetivo son genéricos. No se sabe si el informe (antenas) corresponde al proyecto ni si hay más documentos fuera de la carpeta.

Contra la corrida del 2026-10-28: +0 hallazgos.

## Lo que produjo

Acta previa: sí, del 2025-11-30 (aprobada por el Comité de Inversiones). Términos vigentes (v1.3, aceptados por José Francisco Ñáñez el 2026-10-28; no se registró de nuevo).

## Acta — PRY-203 Migración del core de voz a la nube
**Estado:** existe, del 2025-11-30 (`00-gobierno/2025-11-30-acta-constitucion.docx`)

### Qué falta
| Campo | Estado | Consecuencia |
|---|---|---|
| Autoridad del gerente | No existe: el acta no dice hasta qué monto ni qué cambio de alcance decide Mauricio Pérez sin comité | Cualquier desvío va al Comité de Inversiones. Hoy la proyección al cierre es 1.235.285.263 COP contra 1.200.000.000 aprobados (+35.285.263, ~2,9%) y nadie puede decir si el gerente puede absorberlo. |
| Objetivo de negocio | Presente pero es la solución reescrita: "Entregar migración del core de voz a la nube para Mercadeo" | Sin beneficio ni cifra, no se puede juzgar si el proyecto vale la pena cuando se atrasa o cuesta más. |
| Alcance | "Componente 1, 2, 3" sin nombre ni contenido | No hay contra qué evaluar un cambio de alcance; control de cambios no tiene base. |
| Exclusiones | "Lo que otro proyecto cubre", sin decir qué ni cuál proyecto | Parece declarada y no excluye nada verificable. |
| Patrocinador | Javier Hoyos (con nombre) | Cumple. Falta decir qué decide él frente al gerente. |
| Supuestos y restricciones | No existen | El informe de avance ya trae dos riesgos (permisos municipales, conocimiento concentrado en una persona) que nacen de supuestos nunca escritos. |
| Dependencias | "Ninguna declarada" | Declarar ninguna en una migración de core de voz es poco creíble; el informe habla de permisos municipales, que es una dependencia externa. |
| Criterio de éxito | "En producción y medido", sin métrica, umbral ni quién mide | No se puede cerrar el proyecto contra algo que no se puede medir. |
| Cadencia del comité | No existe (solo se nombra el comité) | No se sabe cuándo se revisa ni cuándo se escala. |
| Hitos | No existen; solo inicio 2025-12-10 y cierre 2026-11-27 | Con 59% reportado a 30 días del cierre, no hay hitos contra los cuales verificar el avance. |

### Contenido
**Objetivo de negocio:** pendiente de definir. El acta solo dice "Entregar migración del core de voz a la nube para Mercadeo" (acta, Objetivo del negocio), que describe la solución.
**Alcance:** pendiente de definir. El acta lista "Componente 1, 2, 3" sin contenido (acta, Alcance).
**Exclusiones:** pendiente de definir. El acta dice "Lo que otro proyecto cubre" (acta, Fuera de alcance), sin especificar.
**Patrocinador:** Javier Hoyos · **Gerente:** Mauricio Pérez (acta)
**Autoridad del gerente:** pendiente de definir. No está en ningún documento.
**Comité al que reporta:** Comité de Inversiones (acta) · **Cadencia:** pendiente de definir.
**Supuestos:** pendiente de definir · **Restricciones:** pendiente de definir. Presupuesto aprobado 1.200.000.000 COP y fechas 2025-12-10 a 2026-11-27 (acta) son los únicos límites declarados.
**Criterio de éxito:** "Migración del core de voz a la nube en producción y medido" (acta) · **Lo mide:** pendiente de definir.
**Hitos principales:** pendiente de definir.

### Cosas que el acta y el informe no concilian
- Área dueña Mercadeo para una migración de core de voz: raro; confirmar con el patrocinador si es el dueño real.
- El informe (2026-10-18) habla de instalación de antenas y permisos municipales, que no corresponden a una migración a la nube. Puede ser texto de otro proyecto; no lo interpreto, queda para confirmar.
- Informe: ejecutado (484.949.082) mayor que comprometido (467.181.006), lo que no debería pasar.
- Informe sin fecha de cierre re-proyectada: faltan 30 días con 59% de avance.

### Después
- El acta quedó sin autoridad declarada: ofrezco llevar esa definición al Comité de Inversiones (próximo comité: 2026-11-04). Es una decisión, no un trámite.
- Los dos riesgos del informe y la ausencia de supuestos se pueden pasar al registro RAID (`/raid-log`); no lo hice sin que lo pidas.

No sé: lo que se haya hablado fuera de estos dos documentos, ni si existe un plan o contrato de PRY-203 que no esté en la carpeta (solo hay acta e informe).

Pie de rigor: borrador de trabajo, no decisión ni asesoría. Cada dato cita el documento del que sale; la verificación es tuya.
