# Corrida del 2026-10-28 · product-view

13 proyectos · 30 s · 70 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `vendor_deliverable_late` | 10 |
| `commitment_overdue` | 9 |
| `progress_vs_plan` | 7 |
| `commitment_rescheduled` | 7 |
| `variance_time` | 5 |
| `declared_vs_evidence` | 3 |
| `rebaseline_unauthorized` | 3 |
| `commitment_undated` | 2 |
| `vendor_accepted_without_evidence` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `vendor_invoiced_without_delivery` | 1 |
| `variance_cost` | 1 |

Producto con un solo proyecto (PRY-201); sin sección de producto. Declarado verde con 4 de 5 hitos cumplidos sin evidencia y 3 entregables de proveedor vencidos. 7 proyectos sin producto declarado. No sé si PRY-201 comparte producto con ellos.

Contra la corrida del 2026-10-28: +0 hallazgos.

## Lo que produjo

**Fuente:** fichas del estado (`estado/records`, 13 proyectos), recalculadas con `portafolio.py compute`, al 2026-10-28. Términos vigentes (v1.3, aceptados por José Francisco Ñáñez el 2026-10-28), no hizo falta registrarlos de nuevo.

## Producto «internet por fibra» al 2026-10-28

«Internet por fibra» tiene un solo proyecto: **PRY-201 Fibra hasta el hogar fase 3**. La vista por producto no aporta nada ahí, así que no armo una sección aparte; lo que sigue es la ficha del proyecto, tal como la calcula el script.

| Producto | Proyectos | Con alertas | Fecha más tardía | Aprobado | Comprometido |
|---|---|---|---|---|---|
| internet por fibra | 1 (PRY-201) | 9 alertas | 2026-09-02 (PRY-201; ya pasada) | COP 6.800.000.000 | COP 3.572.592.598 |

Dinero de PRY-201 (trae las cuatro cifras): ejecutado COP 3.369.704.705 (49,6 %), comprometido 52,5 % del aprobado, proyección COP 6.982.625.535 (2,7 % sobre lo aprobado), disponible real COP 3.227.407.402.

**Lo que hay que ver (PRY-201):**
- **Declarado verde (informe del 2026-10-17), no sostenido por la evidencia.** El informe declara 51 % de avance. Los hitos dicen 5 de 5 cumplidos, pero **4 de los 5 figuran cumplidos sin evidencia**: Diseño de red aprobado (vencía 2025-11-10, 352 días), Sitios construidos (2026-04-07, 204 días), Integración con la red (2026-06-20, 130 días) y Lanzamiento comercial (2026-09-02, 56 días). Solo «Permisos de instalación obtenidos» tiene evidencia. Entre el 51 % declarado y lo que dice el plan hay 49 puntos.
- **Proveedor Infraestructura de Torres del Sur S.A.S. (CT-801):** 3 entregables, 0 aceptados, los 3 pendientes y vencidos: Suministro de antenas y radios (324 días), Bolsa de horas de ingeniería (222 días) y Tendido de fibra óptica (121 días). Lo facturado no está declarado en la ficha.
- Fecha final vencida: 2026-09-02, sin replanificación ni cambios registrados (0 replanificaciones, 0 cambios), así que la desviación contra la línea base es 0 días. Esa cifra no mide atraso real, porque la fecha nunca se movió.
- Sin autoridad de aprobación (`identity.authority`) ni fase declaradas. 13 campos de identidad, plan y dinero tienen 14 meses de antigüedad.
- Silencio: 5 días desde el último documento, no hay silencio.

**Dependencias internas:** ninguna, porque el producto tiene un solo proyecto. No hay nada que llevar al comité de producto por este lado.

**Fecha comprometida del producto:** 2026-09-02, de PRY-201. Ya venció hace 56 días.

### Proyectos sin producto declarado
Son 7 de los 13 proyectos del portafolio, y ninguno suma al producto de nadie. Nadie puede responder por el conjunto al que sirven.

| Proyecto | Área dueña |
|---|---|
| PRY-202 Modernización de la red de transporte | Compras |
| PRY-203 Migración del core de voz a la nube | Mercadeo |
| PRY-205 Portabilidad numérica en línea | Seguridad de la información |
| PRY-206 Centro de operaciones de red unificado | Seguridad de la información |
| PRY-207 Facturación convergente | Compras |
| PRY-209 Apagado de la red 3G | Despliegue |
| PRY-210 Conectividad para colegios públicos | Tecnología |

Dos observaciones sobre el resto del portafolio: PRY-199 declara «PRD-299», que es un código y no el nombre de un producto, así que conviene confirmarlo. Y el cálculo no trae el dinero de los proyectos de otros productos en esta vista, que solo cubre el pedido.

**Qué no sé:** si PRY-201 comparte producto con alguno de los 7 proyectos sin producto. Esa pregunta solo la contesta quien declare el producto de esos proyectos.

*Pie de rigor: cada cifra sale de `portafolio.py compute`; las citas están en las fichas del estado. Es un borrador de trabajo, no una decisión; la verificación es de quien lo lee.*
