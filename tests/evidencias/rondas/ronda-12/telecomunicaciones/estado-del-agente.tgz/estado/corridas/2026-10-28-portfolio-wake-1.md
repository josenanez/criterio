# Corrida del 2026-10-28 · portfolio-wake

13 proyectos · 27 s · 70 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `vendor_deliverable_late` | 10 |
| `commitment_overdue` | 9 |
| `progress_vs_plan` | 7 |
| `commitment_rescheduled` | 7 |
| `variance_time` | 5 |
| `declared_vs_evidence` | 3 |
| `rebaseline_unauthorized` | 3 |
| `commitment_undated` | 2 |
| `vendor_accepted_without_evidence` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `vendor_invoiced_without_delivery` | 1 |
| `variance_cost` | 1 |

Barrido: 92 documentos sin cambios, nada que releer. Peticiones: ninguna. Confirmación: 5 campos preguntados (autoridad en PRY-204, 205, 206, 210; producto en PRY-205), sin respuesta en prueba sin interfaz. No se escribió nada en las fichas.

Contra la corrida del 2026-10-28: +0 hallazgos.

## Lo que produjo

## 2026-10-28

**Revisé:** 92 documentos · 0 cambiaron · 0 proyectos recalculados

Términos vigentes (v1.3, aceptados por José Francisco Ñáñez el 2026-10-28): no hubo que registrar nada nuevo.
Barrido: sin documentos nuevos, cambiados, renombrados ni borrados; sin citas rotas. No hay nada que releer.
Peticiones: ninguna en el servidor.

### Lo que cruzó un umbral
Nada. No se recalculó ningún proyecto, así que no hay señal nueva.

### Preguntas
Primera confirmación (no se había corrido antes): cinco campos vacíos en las fichas, elegidos por importancia (proyectos en rojo primero). Nadie respondió en esta prueba sin interfaz; quedan preguntadas hoy, 2026-10-28, y no se repiten.

1. **PRY-204** (rojo) — autoridad que aprueba: no aparece en ningún documento.
2. **PRY-205** (rojo) — autoridad que aprueba: no aparece en ningún documento.
3. **PRY-206** (rojo) — autoridad que aprueba: no aparece en ningún documento.
4. **PRY-210** (rojo) — autoridad que aprueba: no aparece en ningún documento.
5. **PRY-205** (rojo) — producto al que sirve: no aparece en ningún documento.

Nada de esto se escribió en las fichas: la respuesta tiene que llegar en un documento.

**Vuelvo el 2026-10-29.**
