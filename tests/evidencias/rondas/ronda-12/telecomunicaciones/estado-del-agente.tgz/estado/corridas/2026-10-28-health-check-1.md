# Corrida del 2026-10-28 · health-check

13 proyectos · 86 s · 70 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `vendor_deliverable_late` | 10 |
| `commitment_overdue` | 9 |
| `progress_vs_plan` | 7 |
| `commitment_rescheduled` | 7 |
| `variance_time` | 5 |
| `declared_vs_evidence` | 3 |
| `rebaseline_unauthorized` | 3 |
| `commitment_undated` | 2 |
| `vendor_accepted_without_evidence` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `vendor_invoiced_without_delivery` | 1 |
| `variance_cost` | 1 |

Diagnóstico de PRY-200 sobre 11 documentos: 5 sostenidas, 12 sin sustento, 3 contradichas. Dijo que no sabe: autoridad del gerente, fecha de cierre vigente, origen del comprometido, acta de la Bolsa de horas CT-478, y el tramo 2025-08-18 a 2026-09-21 sin documentos.

Contra la corrida del 2026-10-28: +0 hallazgos.

## Lo que produjo

Términos vigentes (v1.3, aceptados por José Francisco Ñáñez el 2026-10-28; comprobante ya registrado, no se repitió el registro).

## Diagnóstico · PRY-200 · Despliegue de 5G en ciudades intermedias · 2026-10-28

**Leí:** 11 documentos · de 2025-05-26 a 2026-10-19 · formatos: docx (4), pdf (4), md (2), xml de Microsoft Project (1). Ninguno ilegible. Leí el texto convertido que guarda el caché; cada cita apunta al original. Busqué menciones del proyecto en el resto de `documentos/`: ningún otro documento nombra PRY-200 ni el "punto 26".
**No pude leer:** nada. Pero la carpeta no tiene registro RAID, solicitudes de cambio, actas de comité con decisiones ni ficha de avance anterior al 2026-10-17.

### Dictamen
**Sostenido:** 5 afirmaciones · **Sin sustento:** 12 · **Contradicho:** 3 (20 evaluadas)

Desde esta carpeta solo se puede afirmar lo que dice el acta de constitución (patrocinador, gerente, comité, presupuesto aprobado, fechas), que se recibió el suministro de antenas y radios de ambos contratos y que se recibió "Sitios construidos" el 2026-10-16. Todo lo demás es declaración del gerente o un cronograma que se contradice con ese informe: de las cifras y estados del informe de avance, ninguna tiene documento de evidencia (0 de 7 declaraciones con evidencia). El cronograma v1 es el único plan y fecha su cierre en 2025-12-19; en la carpeta no hay replanificación ni solicitud de cambio, así que el proyecto sigue en ejecución 313 días después de su fecha de cierre sin que ningún documento lo explique.

### Gobierno
| | Qué dice el documento | Fuente |
|---|---|---|
| Patrocinador | Natalia Ospina | acta de constitución 2025-06-03 |
| Gerente | Óscar Ramírez | acta de constitución 2025-06-03 |
| Autoridad declarada | **No está.** El acta no dice qué puede aprobar el gerente | acta de constitución 2025-06-03 |
| Comité | Comité de Cambios; aprobó el presupuesto y la línea base el 2025-06-03. Una sola minuta (2026-10-19), con asistentes Óscar Ramírez y Natalia Ospina, sin decisiones registradas | acta 2025-06-03; comité 2026-10-19 |

Sin autoridad declarada no hay desviación aprobada: las fechas del cronograma son fechas que alguien escribió. Además, el acta declara "Ninguna" como dependencia, el alcance es "Componente 1; Componente 2; Componente 3" y la exclusión es "Lo que otro proyecto cubre": ninguno define nada verificable.

### Contra el plan
Hay línea base: v1, aprobada el 2025-06-03 por el Comité de Cambios, cierre 2025-12-19. Replanificaciones: 0. Desviación contra la original: 0 días; contra la vigente: 0 días. Esos ceros no significan que el proyecto esté a tiempo: significan que nadie movió las fechas. El cronograma marca los cinco hitos al 100% y "cerrado", mientras el informe del 2026-10-17 declara 59%. El avance que el plan soporta es 100%; el declarado es 59%, una diferencia de 41.0 puntos. Con evidencia hay 1 de 5 hitos.

### Hitos vencidos sin evidencia
| Hito | Fecha | Días | Qué documento se esperaría |
|---|---|---|---|
| Diseño de red aprobado | 2025-07-20 | 465 | Acta de recibo o aprobación del diseño |
| Permisos de instalación obtenidos | 2025-08-27 | 427 | Permisos o acta de recibo |
| Integración con la red | 2025-11-11 | 351 | Acta de recibo de la integración |
| Lanzamiento comercial | 2025-12-19 | 313 | Evidencia de producción y medición (criterio de éxito del acta) |

"Sitios construidos" sí tiene acta (2026-10-16), pero la línea base lo fechaba el 2025-10-04 y el cronograma sigue diciendo 2025-10-04: el acta es de más de un año después. El script no calcula esos días, así que no escribo la cifra.

### Dinero (COP, todo declarado en el informe del 2026-10-17; aprobado, del acta)
| Aprobado | Comprometido | Ejecutado | Proyección | Disponible real |
|---|---|---|---|---|
| 3.300.000.000 | 2.493.745.794 (75.6%) | 1.136.310.608 (34.4%) | 3.425.145.140 (3.8% sobre lo aprobado) | 806.254.206 |

- El umbral de comprometido es 90%; está en 75.6%, no lo cruza. La proyección supera lo aprobado y ningún documento autoriza ese exceso ni lo explica.
- Los contratos de la carpeta (CT-235 y CT-478) no respaldan el comprometido declarado por sí solos, y las dos facturas radicadas no coinciden con el ejecutado declarado. Ningún documento da el desglose.
- **Proveedores.** CT-235 (Soporte de Red Continental): 1 de 3 entregables recibido; facturado 265.104.460, igual al entregable con acta. Atrasados: Bolsa de horas de ingeniería (2025-09-25, 398 días) y Tendido de fibra óptica (2025-11-16, 346 días). CT-478 (Fibra Óptica del Pacífico): contrato marca 2 de 3 recibidos, pero solo hay acta del Suministro; la Bolsa de horas figura "recibida" sin acta, y la factura FV-1478 (2026-10-11) cobra 531.795.504, es decir dos entregables. Tendido de fibra atrasado 346 días. La condición de pago de ambos contratos exige acta firmada por el gerente.

### Lo que se dijo y nadie registró
- **Compromiso vencido:** Carlos Peña, "Entregar el punto 26", para 2026-10-06; vencido hace 22 días. Se anotó en el comité del 2026-10-19, es decir, cuando ya estaba vencido. Carlos Peña no figura entre los asistentes y "punto 26" no está definido en ningún documento.
- **Incidencias sin dueño ni fecha de inicio** (solo en el informe): la prueba de velocidad en campo no alcanzó el valor pactado y se repite (el valor pactado no está en ningún documento); reprogramación de equipos de radio por aduana.
- **Riesgos sin dueño:** cambio en la norma de compartición de infraestructura que puede mover el alcance; subasta de espectro aplazada. Existen solo en el informe, no hay registro RAID. El acta declara cero dependencias, pero la aduana y el regulador lo son.

### Contradicho
| Afirmación | Documento A | Documento B |
|---|---|---|
| Avance 59% y proyecto en ejecución | Informe de avance 2026-10-17 | Cronograma v1: cinco hitos al 100%, "cerrado", incluido el Lanzamiento comercial de 2025-12-19 |
| Sitios construidos cerrado el 2025-10-04 | Cronograma v1 | Acta de recibo del 2026-10-16 |
| Se reprogramó la llegada de equipos de radio | Informe 2026-10-17 | Actas de recibo del Suministro de antenas y radios (2025-08-14 y 2025-08-18). Puede ser otro lote, pero ningún documento lo dice |

### Sin sustento
- Estado "amarillo": no hay criterio documentado y las señales abiertas no figuran en el informe (compromiso vencido, hitos sin evidencia, diferencia de avance, entregables de proveedor atrasados).
- Comprometido, ejecutado y proyección al cierre (tres cifras).
- La prueba de velocidad no alcanzó el valor pactado.
- Los dos riesgos del informe (norma de compartición, subasta de espectro).
- Cuatro hitos "cerrados": Diseño de red, Permisos, Integración con la red, Lanzamiento comercial.
- Bolsa de horas de CT-478 "recibida" y facturada, sin acta.

### Lo que esta carpeta no permite saber
- **Si el proyecto está en el plazo que se le dio:** sin replanificación ni solicitud de cambio, no se sabe cuál es la fecha de cierre vigente ni quién la aprobó.
- **Cuánta autoridad tiene el gerente:** el acta no la declara, así que no se puede saber si podía aprobar lo que se movió, ni lo que se facturó.
- **Si se pagó o se puede pagar lo facturado en CT-478:** falta el acta de la Bolsa de horas.
- **De dónde sale el comprometido:** faltan contratos u órdenes más allá de CT-235 y CT-478.
- **Qué pasó entre 2025-08-18 y 2026-09-21:** la carpeta no tiene ningún documento en ese tramo. Esto es silencio de la carpeta, no se puede decir si es del proyecto o de quien la alimenta. Hoy el silencio es de 9 días, bajo el umbral de 15.
- **Si el despliegue está en producción y medido** (criterio de éxito): no hay ningún documento de producción ni de medición.
- **Datos vencidos:** 13 campos del acta tienen 16 meses de antigüedad, por encima del umbral de 12; no se han reconfirmado. Faltan además autoridad y fase.

No recomiendo detener, continuar ni reestructurar: eso lo decide quien tiene la facultad. Puedo preparar el punto de comité con la lista de lo que falta, o llevar las tres contradicciones al gerente como preguntas, una por una.

*Pie de rigor: todo lo anterior sale de 11 documentos de la carpeta del proyecto, leídos el 2026-10-28; las cifras derivadas se copian de `portafolio.py compute`. Es un borrador de trabajo, no una decisión ni asesoría; la verificación contra los originales es suya.*
