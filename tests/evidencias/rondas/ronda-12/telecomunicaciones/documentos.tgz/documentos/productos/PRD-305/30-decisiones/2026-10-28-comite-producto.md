# Comité de producto · Colocación en el borde

**Fecha:** 2026-10-28
**Asistentes:** Camilo Beltrán

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4500 | Requerimiento REQ-4500 | Liliana Torres | se verifica en producción | — | propuesto | 2026-09-13 | — |
| REQ-4501 | Requerimiento REQ-4501 | Carlos Peña | se verifica en producción | — | aceptado | 2026-06-02 | — |
| REQ-4502 | Requerimiento REQ-4502 | Natalia Ospina | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-07 | — |
| REQ-4503 | Requerimiento REQ-4503 | Gustavo Neira | — | Cliente entrevistado | aceptado | 2026-08-10 | — |
| REQ-4504 | Requerimiento REQ-4504 | Gustavo Neira | — | Cliente entrevistado | aceptado | 2026-08-17 | — |
| REQ-4505 | Requerimiento REQ-4505 | Óscar Ramírez | se verifica en producción | Cliente entrevistado | propuesto | 2026-08-06 | — |
| REQ-4506 | Requerimiento REQ-4506 | Rubén Cárdenas | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-27 | — |
| REQ-4507 | Requerimiento REQ-4507 | María Restrepo | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-22 | — |
| REQ-4508 | Requerimiento REQ-4508 | Beatriz Cuéllar | — | Cliente entrevistado | aceptado | 2026-08-18 | — |
| REQ-4509 | Requerimiento REQ-4509 | Diana Molina | se verifica en producción | — | aceptado | 2026-04-15 | — |
| REQ-4510 | Requerimiento REQ-4510 | sin asignar | se verifica en producción | — | propuesto | 2026-05-16 | — |
| REQ-4511 | Requerimiento REQ-4511 | Diana Molina | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-26 | — |
| REQ-4512 | Requerimiento REQ-4512 | María Restrepo | se verifica en producción | — | aceptado | 2026-05-16 | — |
| REQ-4513 | Requerimiento REQ-4513 | Laura Vélez | se verifica en producción | Cliente entrevistado | aceptado | 2026-09-13 | — |

## Decisiones

- Se mantiene el plan
