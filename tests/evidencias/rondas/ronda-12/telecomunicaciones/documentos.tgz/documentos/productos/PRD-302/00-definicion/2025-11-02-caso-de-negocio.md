# Caso de negocio · Arriendo de torres

**Código:** PRD-302
**Fecha:** 2025-11-02
**Preparado por:** Carlos Peña

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 92.480 | Caso de negocio, 2025-11-02 |

## Retorno esperado

Retorno esperado en 24 meses.
