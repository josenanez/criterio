# Caso de negocio · Colocación en el borde

**Código:** PRD-305
**Fecha:** 2026-05-02
**Preparado por:** Camilo Beltrán

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 122.019 | Caso de negocio, 2026-05-02 |

## Retorno esperado

Retorno esperado en 24 meses.
