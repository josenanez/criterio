# Comité de producto · Planes empresariales

**Fecha:** 2026-10-28
**Asistentes:** Gustavo Neira

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4800 | Requerimiento REQ-4800 | Diana Molina | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-14 | — |
| REQ-4801 | Requerimiento REQ-4801 | Diana Molina | — | Cliente entrevistado | propuesto | 2026-08-18 | — |
| REQ-4802 | Requerimiento REQ-4802 | Laura Vélez | se verifica en producción | — | aceptado | 2026-05-01 | — |
| REQ-4803 | Requerimiento REQ-4803 | Natalia Ospina | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-05 | — |
| REQ-4804 | Requerimiento REQ-4804 | Camilo Beltrán | se verifica en producción | — | propuesto | 2026-04-25 | — |
| REQ-4805 | Requerimiento REQ-4805 | Natalia Ospina | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-28 | — |
| REQ-4806 | Requerimiento REQ-4806 | Elena Duarte | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-01 | — |
| REQ-4807 | Requerimiento REQ-4807 | Natalia Ospina | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-27 | — |
| REQ-4808 | Requerimiento REQ-4808 | Diana Molina | se verifica en producción | Cliente entrevistado | propuesto | 2026-06-15 | — |
| REQ-4809 | Requerimiento REQ-4809 | Carlos Peña | — | Cliente entrevistado | aceptado | 2026-08-19 | — |
| REQ-4810 | Requerimiento REQ-4810 | Mauricio Pérez | se verifica en producción | — | aceptado | 2026-04-03 | — |
| REQ-4811 | Requerimiento REQ-4811 | Jorge Medina | se verifica en producción | — | aceptado | 2026-08-31 | — |
| REQ-4812 | Requerimiento REQ-4812 | Liliana Torres | se verifica en producción | — | propuesto | 2026-08-27 | — |
| REQ-4813 | Requerimiento REQ-4813 | Javier Hoyos | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-20 | — |
| REQ-2035 | Requerimiento REQ-2035 | Mauricio Pérez | — | Cliente entrevistado | aceptado | 2026-10-14 | — |

## Decisiones

- Se mantiene el plan
