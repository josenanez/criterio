# Definición de producto · Planes prepago

**Código:** PRD-307
**Gerente de producto:** Javier Hoyos
**Segmento:** Operadores mayoristas
**Fecha de la definición:** 2025-10-07

## El problema

El segmento Operadores mayoristas no tiene planes prepago.

## La propuesta

- Propuesta principal

## Supuestos

- **El espectro se asigna en la fecha prevista** · declarado el 2026-09-24 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
