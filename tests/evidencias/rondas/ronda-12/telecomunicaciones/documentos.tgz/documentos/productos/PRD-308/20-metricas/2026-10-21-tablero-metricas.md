# Tablero de métricas · Planes empresariales

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-21

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 60.464 | 2026-10-21 |
