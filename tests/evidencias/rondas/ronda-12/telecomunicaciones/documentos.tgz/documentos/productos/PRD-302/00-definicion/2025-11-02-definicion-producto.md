# Definición de producto · Arriendo de torres

**Código:** PRD-302
**Gerente de producto:** Carlos Peña
**Segmento:** Operadores mayoristas
**Fecha de la definición:** 2025-11-02

## El problema

El segmento Operadores mayoristas no tiene arriendo de torres.

## La propuesta

- Propuesta principal

## Supuestos

- **La demanda de planes crece como dice el caso** · declarado el 2026-07-24 · verificado con el concepto jurídico de cumplimiento del 2026-08-24 (anexo «Verificación del supuesto» del 2026-08-24)

## Proyectos que lo construyen

- Ninguno declarado
