# Tablero de métricas · Conectividad IoT

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-23

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 116.075 | 2026-10-23 |
