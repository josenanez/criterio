# Caso de negocio · Planes 5G

**Código:** PRD-300
**Fecha:** 2026-04-20
**Preparado por:** Sandra Gil

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 242.251 | Caso de negocio, 2026-04-20 |

## Retorno esperado

Retorno esperado en 24 meses.
