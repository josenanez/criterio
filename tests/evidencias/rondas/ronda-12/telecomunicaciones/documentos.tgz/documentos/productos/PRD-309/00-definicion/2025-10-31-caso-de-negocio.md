# Caso de negocio · Roaming regional

**Código:** PRD-309
**Fecha:** 2025-10-31
**Preparado por:** Camilo Beltrán

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 57.186 | Caso de negocio, 2025-10-31 |

## Retorno esperado

Retorno esperado en 24 meses.
