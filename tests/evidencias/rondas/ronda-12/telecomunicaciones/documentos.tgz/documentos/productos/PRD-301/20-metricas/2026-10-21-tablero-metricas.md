# Tablero de métricas · Internet por fibra

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-21

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 42.727 | 2026-10-21 |
