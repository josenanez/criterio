# Definición de producto · Planes 5G

**Código:** PRD-300
**Gerente de producto:** Sandra Gil
**Segmento:** Hogares
**Fecha de la definición:** 2026-04-20

## El problema

El segmento Hogares no tiene planes 5g.

## La propuesta

- Propuesta principal

## Supuestos

- **El espectro se asigna en la fecha prevista** · declarado el 2026-08-28 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
