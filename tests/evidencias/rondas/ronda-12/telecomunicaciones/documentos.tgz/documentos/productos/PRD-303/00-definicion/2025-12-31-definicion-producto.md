# Definición de producto · Redes privadas

**Código:** PRD-303
**Gerente de producto:** Javier Hoyos
**Segmento:** Operadores mayoristas
**Fecha de la definición:** 2025-12-31

## El problema

El segmento Operadores mayoristas no tiene redes privadas.

## La propuesta

- Propuesta principal

## Supuestos

- **La demanda de planes crece como dice el caso** · declarado el 2026-05-21 · verificado con la medición del piloto del 2026-06-16 (anexo «Verificación del supuesto» del 2026-06-16)

## Proyectos que lo construyen

- Ninguno declarado
