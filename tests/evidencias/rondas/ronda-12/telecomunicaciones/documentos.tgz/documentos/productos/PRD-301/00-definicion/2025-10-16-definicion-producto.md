# Definición de producto · Internet por fibra

**Código:** PRD-301
**Gerente de producto:** Liliana Torres
**Segmento:** Operadores mayoristas
**Fecha de la definición:** 2025-10-16

## El problema

El segmento Operadores mayoristas no tiene internet por fibra.

## La propuesta

- Propuesta principal

## Supuestos

- **El proveedor cumple el tiempo pactado** · declarado el 2026-05-01 · verificado con la medición del piloto del 2026-08-28 (anexo «Verificación del supuesto» del 2026-08-28)

## Proyectos que lo construyen

- Ninguno declarado
