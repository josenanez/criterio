# Definición de producto · Televisión IP

**Código:** PRD-306
**Gerente de producto:** Gustavo Neira
**Segmento:** Grandes empresas
**Fecha de la definición:** 2026-03-07

## El problema

El segmento Grandes empresas no tiene televisión ip.

## La propuesta

- Propuesta principal

## Supuestos

- **El proveedor cumple el tiempo pactado** · declarado el 2026-08-11 · verificado con el documento técnico del proveedor del 2026-09-19 (anexo «Verificación del supuesto» del 2026-09-19)

## Proyectos que lo construyen

- Ninguno declarado
