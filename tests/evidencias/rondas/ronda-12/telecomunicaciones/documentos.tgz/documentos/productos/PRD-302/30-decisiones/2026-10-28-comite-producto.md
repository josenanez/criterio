# Comité de producto · Arriendo de torres

**Fecha:** 2026-10-28
**Asistentes:** Carlos Peña

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4200 | Requerimiento REQ-4200 | Felipe Arango | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-01 | — |
| REQ-4201 | Requerimiento REQ-4201 | Beatriz Cuéllar | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-07 | — |
| REQ-4202 | Requerimiento REQ-4202 | Mauricio Pérez | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-26 | — |
| REQ-4203 | Requerimiento REQ-4203 | Liliana Torres | se verifica en producción | Cliente entrevistado | aceptado | 2026-09-04 | — |
| REQ-4204 | Requerimiento REQ-4204 | Liliana Torres | se verifica en producción | — | propuesto | 2026-06-18 | — |
| REQ-4205 | Requerimiento REQ-4205 | Beatriz Cuéllar | — | Cliente entrevistado | propuesto | 2026-05-14 | — |
| REQ-4206 | Requerimiento REQ-4206 | Sandra Gil | se verifica en producción | — | aceptado | 2026-05-03 | — |
| REQ-4207 | Requerimiento REQ-4207 | Rubén Cárdenas | se verifica en producción | Cliente entrevistado | propuesto | 2026-05-09 | — |
| REQ-4208 | Requerimiento REQ-4208 | Felipe Arango | se verifica en producción | — | propuesto | 2026-07-18 | — |
| REQ-4209 | Requerimiento REQ-4209 | Elena Duarte | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-07 | — |
| REQ-4210 | Requerimiento REQ-4210 | María Restrepo | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-03 | — |
| REQ-4211 | Requerimiento REQ-4211 | Natalia Ospina | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-24 | — |
| REQ-4212 | Requerimiento REQ-4212 | Gustavo Neira | se verifica en producción | Cliente entrevistado | propuesto | 2026-06-04 | — |
| REQ-4213 | Requerimiento REQ-4213 | Elena Duarte | — | Cliente entrevistado | aceptado | 2026-07-29 | — |
| REQ-4214 | Requerimiento REQ-4214 | Sandra Gil | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-08 | — |
| REQ-4215 | Requerimiento REQ-4215 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-29 | — |
| REQ-2037 | Requerimiento REQ-2037 | Andrés Lozano | se verifica en producción | — | aceptado | 2026-10-11 | — |

## Decisiones

- Se mantiene el plan
