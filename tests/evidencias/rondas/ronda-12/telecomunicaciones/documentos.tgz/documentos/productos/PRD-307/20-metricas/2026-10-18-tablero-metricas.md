# Tablero de métricas · Planes prepago

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-18

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 76.597 | 2026-10-18 |
