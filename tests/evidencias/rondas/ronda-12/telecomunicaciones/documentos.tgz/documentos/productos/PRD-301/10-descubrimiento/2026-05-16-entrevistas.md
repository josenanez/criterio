# Entrevistas · Internet por fibra

**Ronda:** Ronda · 2026-05-16
**Realizadas por:** Liliana Torres

### Cliente entrevistado · 2026-05-16

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
