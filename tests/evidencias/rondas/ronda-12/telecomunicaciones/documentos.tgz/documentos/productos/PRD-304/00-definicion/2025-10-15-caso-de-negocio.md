# Caso de negocio · Conectividad IoT

**Código:** PRD-304
**Fecha:** 2025-10-15
**Preparado por:** Natalia Ospina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 167.875 | Caso de negocio, 2025-10-15 |

## Retorno esperado

Retorno esperado en 24 meses.
