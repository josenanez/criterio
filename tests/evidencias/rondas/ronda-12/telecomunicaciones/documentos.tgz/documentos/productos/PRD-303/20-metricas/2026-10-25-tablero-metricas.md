# Tablero de métricas · Redes privadas

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-25

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 55.613 | 2026-10-25 |
