# Entrevistas · Colocación en el borde

**Ronda:** Ronda · 2026-01-29
**Realizadas por:** Camilo Beltrán

### Cliente entrevistado · 2026-01-29

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
