# Caso de negocio · Internet por fibra

**Código:** PRD-301
**Fecha:** 2025-10-16
**Preparado por:** Liliana Torres

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 52.949 | Caso de negocio, 2025-10-16 |

## Retorno esperado

Retorno esperado en 24 meses.
