# Caso de negocio · Solicitud de uniformes de técnicos

**Código:** PRD-299
**Fecha:** 2026-07-30
**Preparado por:** Felipe Arango

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 120.000 | Caso de negocio, 2026-07-30 |

## Retorno esperado

Retorno esperado en 24 meses.
