# Tablero de métricas · Arriendo de torres

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-22

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 80.881 | 2026-10-22 |
