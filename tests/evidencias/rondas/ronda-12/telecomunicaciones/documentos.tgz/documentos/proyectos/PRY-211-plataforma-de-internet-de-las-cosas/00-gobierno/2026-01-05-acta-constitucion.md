# Acta de constitución · Plataforma de internet de las cosas

**Código:** PRY-211
**Área dueña:** Mercadeo
**Patrocinador:** Ricardo Salas
**Gerente de proyecto:** Jorge Medina
**Comité:** Comité de Inversiones
**Producto asociado:** conectividad IoT
**Fecha de aprobación:** 2026-01-05

## Objetivo del negocio

Entregar plataforma de internet de las cosas para Mercadeo.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**3.300.000.000 COP**, aprobado por Comité de Inversiones el 2026-01-05.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-01-15 |
| Cierre | 2026-07-26 |

## Criterio de éxito

Plataforma de internet de las cosas en producción y medido.

## Dependencias declaradas

- Ninguna declarada
