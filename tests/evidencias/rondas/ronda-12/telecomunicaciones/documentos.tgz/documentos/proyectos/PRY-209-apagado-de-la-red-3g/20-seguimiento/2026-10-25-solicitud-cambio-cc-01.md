# Solicitud de cambio CC-01

**Proyecto:** PRY-209 · Apagado de la red 3G
**Fecha:** 2026-10-25
**Solicitante:** Liliana Torres

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +82 días sobre la línea base vigente |
| Costo | 164.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
