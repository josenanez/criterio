# Solicitud de cambio CC-01

**Proyecto:** PRY-208 · Red privada para empresas
**Fecha:** 2026-10-28
**Solicitante:** Felipe Arango

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +76 días sobre la línea base vigente |
| Costo | 152.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
