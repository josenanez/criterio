# Comité de Cambios · Fibra hasta el hogar fase 3

**Fecha:** 2026-10-23
**Asistentes:** Javier Hoyos, Natalia Ospina

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Beatriz Cuéllar | Entregar el punto 16 | 2026-10-31 |
