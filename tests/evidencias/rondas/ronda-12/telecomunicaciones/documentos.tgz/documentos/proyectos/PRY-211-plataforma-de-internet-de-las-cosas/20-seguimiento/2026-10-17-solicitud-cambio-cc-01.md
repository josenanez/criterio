# Solicitud de cambio CC-01

**Proyecto:** PRY-211 · Plataforma de internet de las cosas
**Fecha:** 2026-10-17
**Solicitante:** Jorge Medina

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +102 días sobre la línea base vigente |
| Costo | 204.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
