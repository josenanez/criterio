# Informe de avance · Fibra hasta el hogar fase 3

**Código:** PRY-201
**Fecha de corte:** 2026-10-17
**Gerente:** Javier Hoyos

## Estado declarado

**Verde**

Avance reportado: **51%**

## Lo que pasó en el periodo

- El equipo perdió dos semanas por rotación del gerente de despliegue

## Presupuesto

| | COP |
|---|---|
| Aprobado | 6.800.000.000 |
| Comprometido | 3.572.592.598 |
| Ejecutado | 3.369.704.705 |
| Proyección al cierre | 6.982.625.535 |

## Riesgos abiertos

- Subasta de espectro aplazada por el regulador
- Concentración del conocimiento en una sola persona
