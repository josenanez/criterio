# Acta de constitución · Portabilidad numérica en línea

**Código:** PRY-205
**Área dueña:** Seguridad de la información
**Patrocinador:** Jorge Medina
**Gerente de proyecto:** Diana Molina
**Comité:** Comité de Cambios
**Producto asociado:** No aplica
**Fecha de aprobación:** 2026-01-03

## Objetivo del negocio

Entregar portabilidad numérica en línea para Seguridad de la información.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**9.500.000.000 COP**, aprobado por Comité de Cambios el 2026-01-03.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-01-13 |
| Cierre | 2027-04-14 |

## Criterio de éxito

Portabilidad numérica en línea en producción y medido.

## Dependencias declaradas

- Ninguna declarada
