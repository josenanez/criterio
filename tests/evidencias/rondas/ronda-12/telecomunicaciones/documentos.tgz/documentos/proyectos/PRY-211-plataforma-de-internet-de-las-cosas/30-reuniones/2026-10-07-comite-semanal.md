# Comité de Inversiones · Plataforma de internet de las cosas

**Fecha:** 2026-10-07
**Asistentes:** Camilo Beltrán, Carlos Peña, Felipe Arango, Gustavo Neira, Javier Hoyos, Jorge Medina, Natalia Ospina, Ricardo Salas, Rubén Cárdenas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Gustavo Neira | Enviar el documento 1 | 2026-11-10 |
| Javier Hoyos | Cerrar la prueba 2 | 2026-11-08 |
| Rubén Cárdenas | Revisar el anexo 3 | 2026-10-24 |
| Carlos Peña | Validar el ambiente 4 | 2026-10-03 |
| Ricardo Salas | Aprobar el diseño 5 | 2026-11-01 |
| Camilo Beltrán | Actualizar la matriz 6 | 2026-11-06 |
| Camilo Beltrán | Confirmar la fecha 7 | 2026-11-03 |
| Ricardo Salas | Entregar el punto 8 | 2026-11-05 |
| Carlos Peña | Enviar el documento 9 | 2026-11-03 |
| Gustavo Neira | Cerrar la prueba 10 | 2026-10-28 |
| Rubén Cárdenas | Revisar el anexo 11 | por definir |
| Carlos Peña | Aprobar el diseño 13 | 2026-11-03 |
| Natalia Ospina | Actualizar la matriz 14 | 2026-10-25 |
| Felipe Arango | Confirmar la fecha 15 | 2026-10-19 |
| Jorge Medina | Entregar el punto 16 | 2026-10-17 |

## Cerrados en esta reunión

- Validar el ambiente 12 (Liliana Torres): recibido, acta de recibo del 2026-10-07.
