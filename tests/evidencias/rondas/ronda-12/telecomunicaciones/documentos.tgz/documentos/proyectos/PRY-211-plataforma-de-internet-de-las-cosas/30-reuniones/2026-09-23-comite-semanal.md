# Comité de Inversiones · Plataforma de internet de las cosas

**Fecha:** 2026-09-23
**Asistentes:** Camilo Beltrán, Carlos Peña, Gustavo Neira, Javier Hoyos, Jorge Medina, Ricardo Salas, Rubén Cárdenas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Gustavo Neira | Enviar el documento 1 | 2026-10-02 |
| Javier Hoyos | Cerrar la prueba 2 | 2026-10-09 |
| Rubén Cárdenas | Revisar el anexo 3 | 2026-10-24 |
| Carlos Peña | Validar el ambiente 4 | 2026-10-03 |
| Ricardo Salas | Aprobar el diseño 5 | 2026-10-15 |
| Camilo Beltrán | Actualizar la matriz 6 | 2026-10-16 |
| Camilo Beltrán | Confirmar la fecha 7 | 2026-10-08 |
| Ricardo Salas | Entregar el punto 8 | 2026-10-20 |
