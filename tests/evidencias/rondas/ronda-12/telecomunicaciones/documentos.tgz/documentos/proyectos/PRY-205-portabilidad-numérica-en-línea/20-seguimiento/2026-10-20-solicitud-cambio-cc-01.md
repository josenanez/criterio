# Solicitud de cambio CC-01

**Proyecto:** PRY-205 · Portabilidad numérica en línea
**Fecha:** 2026-10-20
**Solicitante:** Diana Molina

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +104 días sobre la línea base vigente |
| Costo | 208.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
