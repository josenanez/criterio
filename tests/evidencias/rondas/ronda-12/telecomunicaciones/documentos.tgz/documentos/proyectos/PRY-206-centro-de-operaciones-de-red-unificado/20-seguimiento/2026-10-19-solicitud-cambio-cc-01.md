# Solicitud de cambio CC-01

**Proyecto:** PRY-206 · Centro de operaciones de red unificado
**Fecha:** 2026-10-19
**Solicitante:** Javier Hoyos

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +93 días sobre la línea base vigente |
| Costo | 186.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
