# Informe de avance · Red privada para empresas

**Código:** PRY-208
**Fecha de corte:** 2026-10-21
**Gerente:** Felipe Arango

## Estado declarado

**Amarillo**

Avance reportado: **79%**

## Lo que pasó en el periodo

- Se recibió el concepto del regulador sobre el uso del espectro

## Presupuesto

| | COP |
|---|---|
| Aprobado | 3.300.000.000 |
| Comprometido | 1.246.115.336 |
| Ejecutado | 1.057.657.328 |
| Proyección al cierre | 3.320.169.600 |

## Riesgos abiertos

- Cambio en la norma de compartición de infraestructura que puede mover el alcance
