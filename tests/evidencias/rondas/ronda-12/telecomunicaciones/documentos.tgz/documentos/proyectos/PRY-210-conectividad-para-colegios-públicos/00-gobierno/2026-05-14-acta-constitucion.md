# Acta de constitución · Conectividad para colegios públicos

**Código:** PRY-210
**Área dueña:** Tecnología
**Patrocinador:** Mauricio Pérez
**Gerente de proyecto:** Felipe Arango
**Comité:** Comité de Cambios
**Producto asociado:** No aplica
**Fecha de aprobación:** 2026-05-14

## Objetivo del negocio

Entregar conectividad para colegios públicos para Tecnología.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**3.300.000.000 COP**, aprobado por Comité de Cambios el 2026-05-14.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-05-24 |
| Cierre | 2027-07-28 |

## Criterio de éxito

Conectividad para colegios públicos en producción y medido.

## Dependencias declaradas

- Ninguna declarada
