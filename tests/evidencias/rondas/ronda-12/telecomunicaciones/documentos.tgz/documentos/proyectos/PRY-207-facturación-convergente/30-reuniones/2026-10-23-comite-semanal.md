# Comité de Inversiones · Facturación convergente

**Fecha:** 2026-10-23
**Asistentes:** Liliana Torres, Sandra Gil

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Laura Vélez | Entregar el punto 23 | 2026-11-22 |
