# Solicitud de cambio CC-01

**Proyecto:** PRY-210 · Conectividad para colegios públicos
**Fecha:** 2026-10-27
**Solicitante:** Felipe Arango

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +110 días sobre la línea base vigente |
| Costo | 220.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
