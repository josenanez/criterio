# Acta de recibo · Suministro de antenas y radios

**Proyecto:** PRY-206 · Centro de operaciones de red unificado
**Fecha de recibo:** 2026-08-02
**Recibido por:** Javier Hoyos

Se recibe a satisfacción el entregable **Suministro de antenas y radios**.

Contrato CT-381 · Redes y Radio Andinas Ltda..
