# Comité de Cambios · Portabilidad numérica en línea

**Fecha:** 2026-10-21
**Asistentes:** Diana Molina, Jorge Medina

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Liliana Torres | Entregar el punto 34 | 2026-11-07 |
