# Acta de recibo · Suministro de antenas y radios

**Proyecto:** PRY-200 · Despliegue de 5G en ciudades intermedias
**Fecha de recibo:** 2025-08-18
**Recibido por:** Óscar Ramírez

Se recibe a satisfacción el entregable **Suministro de antenas y radios**.

Contrato CT-235 · Soporte de Red Continental.
