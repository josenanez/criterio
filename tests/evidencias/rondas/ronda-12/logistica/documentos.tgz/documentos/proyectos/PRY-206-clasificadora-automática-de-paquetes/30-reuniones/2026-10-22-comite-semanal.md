# Comité de Tecnología · Clasificadora automática de paquetes

**Fecha:** 2026-10-22
**Asistentes:** Gustavo Neira, Gustavo Neira

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Jorge Medina | Entregar el punto 23 | por definir |
