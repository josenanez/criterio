# Comité de Operaciones · Seguimiento satelital de la flota

**Fecha:** 2026-10-22
**Asistentes:** Ricardo Salas, Mauricio Pérez

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Felipe Arango | Entregar el punto 26 | 2026-10-21 |
| Beatriz Cuéllar | Entregar el punto 19 | 2026-10-23 |
