# Comité de Operaciones · Sistema de gestión de bodegas

**Fecha:** 2026-10-18
**Asistentes:** Andrés Lozano, Carlos Peña

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Paula Céspedes | Entregar el punto 31 | 2026-11-13 |
