# Acta de constitución · Flota eléctrica de última milla

**Código:** PRY-202
**Área dueña:** Compras
**Patrocinador:** Laura Vélez
**Gerente de proyecto:** Sandra Gil
**Comité:** Comité de Inversiones
**Producto asociado:** entregas en el día
**Fecha de aprobación:** 2025-07-08

## Objetivo del negocio

Entregar flota eléctrica de última milla para Compras.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**9.500.000.000 COP**, aprobado por Comité de Inversiones el 2025-07-08.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-07-18 |
| Cierre | 2026-09-11 |

## Criterio de éxito

Flota eléctrica de última milla en producción y medido.

## Dependencias declaradas

- Ninguna declarada
