# Informe de avance · Consolidación de cargas regionales

**Código:** PRY-209
**Fecha de corte:** 2026-10-11
**Gerente:** Camilo Beltrán

## Estado declarado

**Verde**

Avance reportado: **26%**

## Lo que pasó en el periodo

- Se ajustó el plan de arranque con el cliente ancla

## Presupuesto

| | COP |
|---|---|
| Aprobado | 1.200.000.000 |
| Comprometido | 317.031.376 |
| Ejecutado | 180.165.796 |
| Proyección al cierre | 1.174.530.340 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
