# Informe de avance · Sistema de gestión de bodegas

**Código:** PRY-201
**Fecha de corte:** 2026-10-23
**Gerente:** Andrés Lozano

## Estado declarado

**Verde**

Avance reportado: **69%**

## Lo que pasó en el periodo

- Se acordó con operaciones cómo se mide el nivel de servicio de cada ruta
- Se reprogramó la llegada de las estanterías por demoras del importador

## Presupuesto

| | COP |
|---|---|
| Aprobado | 800.000.000 |
| Comprometido | 320.203.724 |
| Ejecutado | 301.085.494 |
| Proyección al cierre | 777.230.222 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
