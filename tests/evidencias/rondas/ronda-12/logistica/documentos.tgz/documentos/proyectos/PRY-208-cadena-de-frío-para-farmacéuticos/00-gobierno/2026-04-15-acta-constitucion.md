# Acta de constitución · Cadena de frío para farmacéuticos

**Código:** PRY-208
**Área dueña:** Transporte
**Patrocinador:** Gustavo Neira
**Gerente de proyecto:** Sandra Gil
**Comité:** Comité de Clientes
**Producto asociado:** logística de frío
**Fecha de aprobación:** 2026-04-15

## Objetivo del negocio

Entregar cadena de frío para farmacéuticos para Transporte.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**6.800.000.000 COP**, aprobado por Comité de Clientes el 2026-04-15.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-04-25 |
| Cierre | 2026-12-07 |

## Criterio de éxito

Cadena de frío para farmacéuticos en producción y medido.

## Dependencias declaradas

- Ninguna declarada
