# Acta de constitución · Centro de distribución del norte

**Código:** PRY-200
**Área dueña:** Tecnología
**Patrocinador:** Diana Molina
**Gerente de proyecto:** Gustavo Neira
**Comité:** Comité de Operaciones
**Producto asociado:** almacenamiento para terceros
**Fecha de aprobación:** 2026-04-12

## Objetivo del negocio

Entregar centro de distribución del norte para Tecnología.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**1.200.000.000 COP**, aprobado por Comité de Operaciones el 2026-04-12.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-04-22 |
| Cierre | 2027-09-14 |

## Criterio de éxito

Centro de distribución del norte en producción y medido.

## Dependencias declaradas

- Ninguna declarada
