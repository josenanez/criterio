# Comité de Inversiones · Flota eléctrica de última milla

**Fecha:** 2026-10-22
**Asistentes:** Sandra Gil, Laura Vélez

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Liliana Torres | Entregar el punto 13 | 2026-10-18 |
