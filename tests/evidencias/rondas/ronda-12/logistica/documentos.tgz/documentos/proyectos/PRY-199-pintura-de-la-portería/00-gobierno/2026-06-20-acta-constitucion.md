# Acta de constitución · Pintura de la portería

**Código:** PRY-199
**Área dueña:** Operaciones
**Patrocinador:** María Restrepo
**Gerente de proyecto:** Andrés Lozano
**Comité:** Comité de Operaciones
**Producto asociado:** PRD-299
**Fecha de aprobación:** 2026-06-20

## Objetivo del negocio

Entregar pintura de la portería para Operaciones.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**2.400.000.000 COP**, aprobado por Comité de Operaciones el 2026-06-20.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-06-30 |
| Cierre | 2027-12-27 |

## Criterio de éxito

Pintura de la portería en producción y medido.

## Dependencias declaradas

- Ninguna declarada
