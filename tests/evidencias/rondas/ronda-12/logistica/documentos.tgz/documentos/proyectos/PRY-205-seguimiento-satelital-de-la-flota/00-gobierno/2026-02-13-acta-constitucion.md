# Acta de constitución · Seguimiento satelital de la flota

**Código:** PRY-205
**Área dueña:** Comercio exterior
**Patrocinador:** Mauricio Pérez
**Gerente de proyecto:** Ricardo Salas
**Comité:** Comité de Operaciones
**Producto asociado:** No aplica
**Fecha de aprobación:** 2026-02-13

## Objetivo del negocio

Entregar seguimiento satelital de la flota para Comercio exterior.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**800.000.000 COP**, aprobado por Comité de Operaciones el 2026-02-13.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-02-23 |
| Cierre | 2027-08-08 |

## Criterio de éxito

Seguimiento satelital de la flota en producción y medido.

## Dependencias declaradas

- Ninguna declarada
