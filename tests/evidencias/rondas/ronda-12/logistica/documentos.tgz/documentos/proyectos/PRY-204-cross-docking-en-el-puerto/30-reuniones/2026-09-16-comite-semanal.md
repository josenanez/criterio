# Comité de Inversiones · Cross docking en el puerto

**Fecha:** 2026-09-16
**Asistentes:** Beatriz Cuéllar, Camilo Beltrán, Liliana Torres, María Restrepo, Ricardo Salas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Beatriz Cuéllar | Enviar el documento 1 | 2026-10-06 |
| Camilo Beltrán | Cerrar la prueba 2 | 2026-09-27 |
| María Restrepo | Revisar el anexo 3 | por definir |
| Ricardo Salas | Validar el ambiente 4 | 2026-10-05 |
