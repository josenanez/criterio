# Solicitud de cambio CC-01

**Proyecto:** PRY-200 · Centro de distribución del norte
**Fecha:** 2026-10-19
**Solicitante:** Gustavo Neira

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +25 días sobre la línea base vigente |
| Costo | 50.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
