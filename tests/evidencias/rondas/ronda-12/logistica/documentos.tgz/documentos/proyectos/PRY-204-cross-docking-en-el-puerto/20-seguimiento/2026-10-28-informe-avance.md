# Informe de avance · Cross docking en el puerto

**Código:** PRY-204
**Fecha de corte:** 2026-10-28
**Gerente:** Liliana Torres

## Estado declarado

**Verde**

Avance reportado: **53%**

## Lo que pasó en el periodo

- Se ajustó el plan de arranque con el cliente ancla
- Un paro de transportadores detuvo los despachos durante seis días

## Presupuesto

| | COP |
|---|---|
| Aprobado | 18.000.000.000 |
| Comprometido | 9.340.126.765 |
| Ejecutado | 3.101.575.940 |
| Proyección al cierre | 16.752.476.829 |

## Riesgos abiertos

- Paros de transportadores en las vías principales
