# Comité de Inversiones · Cross docking en el puerto

**Fecha:** 2026-09-30
**Asistentes:** Beatriz Cuéllar, Camilo Beltrán, Carlos Peña, Felipe Arango, Jorge Medina, Liliana Torres, María Restrepo, Mauricio Pérez, Rubén Cárdenas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Beatriz Cuéllar | Enviar el documento 1 | 2026-11-03 |
| Camilo Beltrán | Cerrar la prueba 2 | 2026-10-29 |
| María Restrepo | Revisar el anexo 3 | 2026-10-25 |
| Rubén Cárdenas | Actualizar la matriz 6 | 2026-10-19 |
| Beatriz Cuéllar | Confirmar la fecha 7 | 2026-10-14 |
| Mauricio Pérez | Entregar el punto 8 | 2026-10-02 |
| Carlos Peña | Enviar el documento 9 | por definir |
| Felipe Arango | Cerrar la prueba 10 | 2026-10-26 |
| Jorge Medina | Revisar el anexo 11 | 2026-10-14 |
| Rubén Cárdenas | Validar el ambiente 12 | 2026-10-08 |

## Cerrados en esta reunión

- Validar el ambiente 4 (Ricardo Salas): recibido, acta de recibo del 2026-09-30.

## Lo que se dijo

- Camilo Beltrán dice que ya entregó «aprobar el diseño 5». No se presentó acta.
