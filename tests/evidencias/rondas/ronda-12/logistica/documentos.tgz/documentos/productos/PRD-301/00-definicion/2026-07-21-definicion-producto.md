# Definición de producto · Entregas en el día

**Código:** PRD-301
**Gerente de producto:** Javier Hoyos
**Segmento:** Farmacéuticas
**Fecha de la definición:** 2026-07-21

## El problema

El segmento Farmacéuticas no tiene entregas en el día.

## La propuesta

- Propuesta principal

## Supuestos

- **La operación actual no se detiene durante el arranque** · declarado el 2026-07-03 · verificado con el concepto jurídico de cumplimiento del 2026-09-09 (anexo «Verificación del supuesto» del 2026-09-09)

## Proyectos que lo construyen

- Ninguno declarado
