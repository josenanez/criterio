# Caso de negocio · Distribución a tiendas

**Código:** PRD-309
**Fecha:** 2026-01-30
**Preparado por:** Camilo Beltrán

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 109.418 | Caso de negocio, 2026-01-30 |

## Retorno esperado

Retorno esperado en 24 meses.
