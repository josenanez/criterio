# Tablero de métricas · Transporte de carga masiva

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-21

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 191.834 | 2026-10-21 |
