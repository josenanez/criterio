# Definición de producto · Devoluciones

**Código:** PRD-306
**Gerente de producto:** Camilo Beltrán
**Segmento:** Importadores
**Fecha de la definición:** 2026-02-13

## El problema

El segmento Importadores no tiene devoluciones.

## La propuesta

- Propuesta principal

## Supuestos

- **El precio del combustible se sostiene** · declarado el 2026-08-16 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
