# Caso de negocio · Depósito aduanero

**Código:** PRD-305
**Fecha:** 2026-04-30
**Preparado por:** Andrés Lozano

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 141.653 | Caso de negocio, 2026-04-30 |

## Retorno esperado

Retorno esperado en 24 meses.
