# Definición de producto · Logística de frío

**Código:** PRD-303
**Gerente de producto:** Ricardo Salas
**Segmento:** Farmacéuticas
**Fecha de la definición:** 2026-05-27

## El problema

El segmento Farmacéuticas no tiene logística de frío.

## La propuesta

- Propuesta principal

## Supuestos

- **El precio del combustible se sostiene** · declarado el 2026-08-30 · verificado con la medición del piloto del 2026-09-06 (anexo «Verificación del supuesto» del 2026-09-06)

## Proyectos que lo construyen

- Ninguno declarado
