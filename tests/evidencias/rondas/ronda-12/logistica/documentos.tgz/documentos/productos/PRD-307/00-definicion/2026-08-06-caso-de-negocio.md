# Caso de negocio · Transporte de carga masiva

**Código:** PRD-307
**Fecha:** 2026-08-06
**Preparado por:** Gustavo Neira

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 192.212 | Caso de negocio, 2026-08-06 |

## Retorno esperado

Retorno esperado en 24 meses.
