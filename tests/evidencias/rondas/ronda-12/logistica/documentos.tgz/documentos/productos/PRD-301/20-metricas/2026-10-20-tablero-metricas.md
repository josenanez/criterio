# Tablero de métricas · Entregas en el día

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-20

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 241.909 | 2026-10-20 |
