# Tablero de métricas · Almacenamiento para terceros

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-23

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 206.690 | 2026-10-23 |
