# Comité de producto · Cross docking

**Fecha:** 2026-10-28
**Asistentes:** Jorge Medina

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4200 | Requerimiento REQ-4200 | Elena Duarte | se verifica en producción | Cliente entrevistado | propuesto | 2026-09-06 | — |
| REQ-4201 | Requerimiento REQ-4201 | Liliana Torres | se verifica en producción | Cliente entrevistado | aceptado | 2026-09-13 | — |
| REQ-4202 | Requerimiento REQ-4202 | Carlos Peña | — | Cliente entrevistado | aceptado | 2026-07-25 | — |
| REQ-4203 | Requerimiento REQ-4203 | Carlos Peña | se verifica en producción | Cliente entrevistado | propuesto | 2026-09-09 | — |
| REQ-4204 | Requerimiento REQ-4204 | Felipe Arango | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-24 | — |
| REQ-4205 | Requerimiento REQ-4205 | Paula Céspedes | se verifica en producción | Cliente entrevistado | propuesto | 2026-08-21 | — |
| REQ-4206 | Requerimiento REQ-4206 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-09-02 | — |
| REQ-4207 | Requerimiento REQ-4207 | Beatriz Cuéllar | — | Cliente entrevistado | aceptado | 2026-06-14 | — |
| REQ-4208 | Requerimiento REQ-4208 | Sandra Gil | — | Cliente entrevistado | aceptado | 2026-08-23 | — |
| REQ-4209 | Requerimiento REQ-4209 | Laura Vélez | se verifica en producción | Cliente entrevistado | propuesto | 2026-05-25 | — |
| REQ-4210 | Requerimiento REQ-4210 | María Restrepo | se verifica en producción | — | aceptado | 2026-07-09 | — |
| REQ-4211 | Requerimiento REQ-4211 | Carlos Peña | se verifica en producción | — | aceptado | 2026-05-25 | — |
| REQ-4212 | Requerimiento REQ-4212 | Carlos Peña | se verifica en producción | Cliente entrevistado | propuesto | 2026-08-06 | — |
| REQ-4213 | Requerimiento REQ-4213 | Ricardo Salas | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-30 | — |

## Decisiones

- Se mantiene el plan
