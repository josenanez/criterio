# Tablero de métricas · Distribución a tiendas

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-27

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 114.769 | 2026-10-27 |
