# Definición de producto · Transporte de carga masiva

**Código:** PRD-307
**Gerente de producto:** Gustavo Neira
**Segmento:** Retail
**Fecha de la definición:** 2026-08-06

## El problema

El segmento Retail no tiene transporte de carga masiva.

## La propuesta

- Propuesta principal

## Supuestos

- **Los permisos de operación salen a tiempo** · declarado el 2026-07-21 · verificado con el concepto jurídico de cumplimiento del 2026-08-21 (anexo «Verificación del supuesto» del 2026-08-21)

## Proyectos que lo construyen

- Ninguno declarado
