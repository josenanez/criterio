# Entrevistas · Transporte de carga masiva

**Ronda:** Ronda · 2026-03-12
**Realizadas por:** Gustavo Neira

### Cliente entrevistado · 2026-03-12

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
