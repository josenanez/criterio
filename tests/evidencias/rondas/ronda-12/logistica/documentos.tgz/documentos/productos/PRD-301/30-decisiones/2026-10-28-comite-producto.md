# Comité de producto · Entregas en el día

**Fecha:** 2026-10-28
**Asistentes:** Javier Hoyos

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4100 | Requerimiento REQ-4100 | Andrés Lozano | se verifica en producción | Cliente entrevistado | propuesto | 2026-06-29 | — |
| REQ-4101 | Requerimiento REQ-4101 | Gustavo Neira | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-21 | — |
| REQ-4102 | Requerimiento REQ-4102 | Ricardo Salas | — | Cliente entrevistado | propuesto | 2026-09-09 | — |
| REQ-4103 | Requerimiento REQ-4103 | Paula Céspedes | se verifica en producción | — | aceptado | 2026-07-23 | — |
| REQ-4104 | Requerimiento REQ-4104 | Carlos Peña | se verifica en producción | Cliente entrevistado | propuesto | 2026-08-24 | — |
| REQ-4105 | Requerimiento REQ-4105 | Jorge Medina | — | — | aceptado | 2026-07-28 | — |
| REQ-4106 | Requerimiento REQ-4106 | Camilo Beltrán | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-27 | — |
| REQ-4107 | Requerimiento REQ-4107 | Gustavo Neira | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-12 | — |
| REQ-4108 | Requerimiento REQ-4108 | Gustavo Neira | se verifica en producción | Cliente entrevistado | propuesto | 2026-06-01 | — |
| REQ-4109 | Requerimiento REQ-4109 | Mauricio Pérez | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-10 | — |
| REQ-4110 | Requerimiento REQ-4110 | Felipe Arango | se verifica en producción | Cliente entrevistado | propuesto | 2026-08-09 | — |
| REQ-4111 | Requerimiento REQ-4111 | sin asignar | — | — | aceptado | 2026-07-17 | — |
| REQ-4112 | Requerimiento REQ-4112 | María Restrepo | se verifica en producción | — | aceptado | 2026-08-23 | — |
| REQ-4113 | Requerimiento REQ-4113 | Ricardo Salas | se verifica en producción | — | aceptado | 2026-05-29 | — |

## Decisiones

- Se mantiene el plan
