# Caso de negocio · Logística de frío

**Código:** PRD-303
**Fecha:** 2026-05-27
**Preparado por:** Ricardo Salas

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 70.118 | Caso de negocio, 2026-05-27 |

## Retorno esperado

Retorno esperado en 24 meses.
