# Entrevistas · Puntos de recogida

**Ronda:** Ronda · 2026-08-02
**Realizadas por:** Rubén Cárdenas

### Cliente entrevistado · 2026-08-02

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
