# Definición de producto · Depósito aduanero

**Código:** PRD-305
**Gerente de producto:** Andrés Lozano
**Segmento:** Importadores
**Fecha de la definición:** 2026-04-30

## El problema

El segmento Importadores no tiene depósito aduanero.

## La propuesta

- Propuesta principal

## Supuestos

- **El proveedor cumple el tiempo pactado** · declarado el 2026-05-29 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
