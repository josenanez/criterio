# Entrevistas · Entregas en el día

**Ronda:** Ronda · 2026-09-13
**Realizadas por:** Javier Hoyos

### Cliente entrevistado · 2026-09-13

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
