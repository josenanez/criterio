# Definición de producto · Puntos de recogida

**Código:** PRD-304
**Gerente de producto:** Rubén Cárdenas
**Segmento:** Retail
**Fecha de la definición:** 2026-06-13

## El problema

El segmento Retail no tiene puntos de recogida.

## La propuesta

- Propuesta principal

## Supuestos

- **El precio del combustible se sostiene** · declarado el 2026-10-09 · verificado con la medición del piloto del 2026-10-10 (anexo «Verificación del supuesto» del 2026-10-10)

## Proyectos que lo construyen

- Ninguno declarado
