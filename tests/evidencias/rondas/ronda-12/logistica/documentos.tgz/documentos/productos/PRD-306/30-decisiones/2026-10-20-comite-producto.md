# Comité de producto · Devoluciones

**Fecha:** 2026-10-20
**Asistentes:** Camilo Beltrán

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4600 | Requerimiento REQ-4600 | sin asignar | se verifica en producción | — | propuesto | 2026-07-09 | — |
| REQ-4601 | Requerimiento REQ-4601 | Natalia Ospina | se verifica en producción | Cliente entrevistado | propuesto | 2026-06-23 | — |
| REQ-4602 | Requerimiento REQ-4602 | Liliana Torres | — | — | aceptado | 2026-07-01 | — |
| REQ-4603 | Requerimiento REQ-4603 | Camilo Beltrán | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-26 | — |
| REQ-4604 | Requerimiento REQ-4604 | Carlos Peña | se verifica en producción | Cliente entrevistado | propuesto | 2026-09-07 | — |
| REQ-4605 | Requerimiento REQ-4605 | Óscar Ramírez | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-17 | — |
| REQ-4606 | Requerimiento REQ-4606 | Mauricio Pérez | se verifica en producción | — | aceptado | 2026-08-13 | — |
| REQ-4607 | Requerimiento REQ-4607 | Sandra Gil | — | Cliente entrevistado | aceptado | 2026-04-18 | — |
| REQ-4608 | Requerimiento REQ-4608 | Sandra Gil | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-03 | — |
| REQ-4609 | Requerimiento REQ-4609 | Rubén Cárdenas | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-05 | — |
| REQ-4610 | Requerimiento REQ-4610 | Diana Molina | — | — | aceptado | 2026-04-21 | — |
| REQ-4611 | Requerimiento REQ-4611 | Ricardo Salas | se verifica en producción | — | aceptado | 2026-06-07 | — |
| REQ-4612 | Requerimiento REQ-4612 | Beatriz Cuéllar | se verifica en producción | Cliente entrevistado | aceptado | 2026-09-02 | — |
| REQ-4613 | Requerimiento REQ-4613 | Mauricio Pérez | se verifica en producción | Cliente entrevistado | aceptado | 2026-09-03 | — |

## Decisiones

- Se mantiene el plan
