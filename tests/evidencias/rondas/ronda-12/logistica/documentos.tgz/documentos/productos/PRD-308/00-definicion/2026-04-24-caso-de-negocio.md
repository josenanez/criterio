# Caso de negocio · Paquetería empresarial

**Código:** PRD-308
**Fecha:** 2026-04-24
**Preparado por:** María Restrepo

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 131.933 | Caso de negocio, 2026-04-24 |

## Retorno esperado

Retorno esperado en 24 meses.
