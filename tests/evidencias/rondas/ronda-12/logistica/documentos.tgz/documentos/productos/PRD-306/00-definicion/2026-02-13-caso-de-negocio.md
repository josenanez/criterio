# Caso de negocio · Devoluciones

**Código:** PRD-306
**Fecha:** 2026-02-13
**Preparado por:** Camilo Beltrán

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 167.227 | Caso de negocio, 2026-02-13 |

## Retorno esperado

Retorno esperado en 24 meses.
