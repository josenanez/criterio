# Tablero de métricas · Cross docking

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-20

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 48.422 | 2026-10-20 |
