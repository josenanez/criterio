# Caso de negocio · Puntos de recogida

**Código:** PRD-304
**Fecha:** 2026-06-13
**Preparado por:** Rubén Cárdenas

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 234.010 | Caso de negocio, 2026-06-13 |

## Retorno esperado

Retorno esperado en 24 meses.
