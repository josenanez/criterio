# Entrevistas · Depósito aduanero

**Ronda:** Ronda · 2026-02-09
**Realizadas por:** Andrés Lozano

### Cliente entrevistado · 2026-02-09

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
