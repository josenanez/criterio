# Comité de producto · Puntos de recogida

**Fecha:** 2026-10-16
**Asistentes:** Rubén Cárdenas

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4400 | Requerimiento REQ-4400 | Andrés Lozano | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-30 | — |
| REQ-4401 | Requerimiento REQ-4401 | Óscar Ramírez | — | Cliente entrevistado | aceptado | 2026-07-03 | — |
| REQ-4402 | Requerimiento REQ-4402 | Beatriz Cuéllar | se verifica en producción | Cliente entrevistado | propuesto | 2026-05-23 | — |
| REQ-4403 | Requerimiento REQ-4403 | Rubén Cárdenas | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-07 | — |
| REQ-4404 | Requerimiento REQ-4404 | Jorge Medina | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-17 | — |
| REQ-4405 | Requerimiento REQ-4405 | Elena Duarte | se verifica en producción | Cliente entrevistado | aceptado | 2026-09-05 | — |
| REQ-4406 | Requerimiento REQ-4406 | Óscar Ramírez | — | Cliente entrevistado | aceptado | 2026-05-29 | — |
| REQ-4407 | Requerimiento REQ-4407 | Felipe Arango | — | Cliente entrevistado | aceptado | 2026-08-18 | — |
| REQ-4408 | Requerimiento REQ-4408 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-12 | — |
| REQ-4409 | Requerimiento REQ-4409 | Elena Duarte | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-16 | — |
| REQ-4410 | Requerimiento REQ-4410 | María Restrepo | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-20 | — |
| REQ-4411 | Requerimiento REQ-4411 | sin asignar | se verifica en producción | — | aceptado | 2026-07-25 | — |
| REQ-4412 | Requerimiento REQ-4412 | Paula Céspedes | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-28 | — |
| REQ-4413 | Requerimiento REQ-4413 | Laura Vélez | se verifica en producción | Cliente entrevistado | propuesto | 2026-09-09 | — |
| REQ-2028 | Requerimiento REQ-2028 | María Restrepo | se verifica en producción | Cliente entrevistado | aceptado | 2026-10-09 | — |

## Decisiones

- Se mantiene el plan
