# Corrida · 2026-10-28-budget-tracking-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:budget-tracking portafolio

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-28; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-28T21:41:00 · **Fin:** 2026-10-28T21:42:26 · **Duración:** 85 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `budget-tracking` | 13 | — | 70 | 49 | Presupuesto de 13 proyectos en COP, cifras de compute. Sin línea base de presupuesto ni replanificaciones de presupuesto (not_found). Comprometido menor que ejecutado en PRY-200, 202 y 208: disponible real no confiable. Proyección sobre aprobado en PRY-202, 207 y 206, bajo el umbral de 10%. Sin totales de portafolio: el script no los da. |

Por señal (`budget-tracking`): `milestone_met_without_evidence` 16, `commitment_overdue` 9, `declared_vs_evidence` 7, `progress_vs_plan` 5, `commitment_undated` 3, `commitment_rescheduled` 3, `variance_time` 2, `silent` 2, `change_without_baseline` 1, `rebaseline_unauthorized` 1

## Lo que el agente mostró

## Presupuesto — Portafolio Logística al 2026-10-28

Revisé los 13 proyectos (PRY-199 a PRY-211). Todo está en COP y no convertí nada. El aprobado sale del acta de cada proyecto. Comprometido, ejecutado y proyección salen del último informe de avance, y son declaraciones del gerente. Ninguna alerta de presupuesto cruza un umbral.

- **Comprometido sobre el umbral de 90%:** ningún proyecto lo pasa. El más alto es PRY-211, con 75.2% comprometido y 198350098 de disponible real.
- **Proyección sobre el aprobado:** PRY-202 (+4.5%), PRY-207 (+4.2%) y PRY-206 (+0.6%). Ninguna llega al umbral de 10%, pero las tres exceden lo aprobado.
- **Ejecutado mayor que comprometido:** pasa en PRY-200, PRY-202 y PRY-208. El informe no define "comprometido". Si incluye lo ya ejecutado, las cifras están mal. Si es lo que falta por causar, el disponible real de esos tres está sobrestimado. No lo puedo resolver desde los documentos.
- **Avance declarado frente a ejecución:**
  - PRY-207 declara 24% de avance con 3 de 3 hitos cumplidos y 38.3% ejecutado.
  - PRY-208 lleva 57.6% ejecutado frente a 43% declarado.
  - PRY-204 lleva 17.2% ejecutado frente a 53% declarado.
  - PRY-200, PRY-201 y PRY-206 declaran entre 69% y 77% con 28.6% a 47.3% ejecutado, y tienen hitos cumplidos sin evidencia.
- **Aprobado viejo:** PRY-202, PRY-207 y PRY-204 tienen un aprobado de 12 a 16 meses, sin ningún movimiento de presupuesto declarado.
- **Sin dato:**
  - No hay línea base de presupuesto en ninguna ficha. No pude dar original, vigente ni desviación de costo.
  - Las replanificaciones de presupuesto están en `not_found`. Las que aparecen en `compute` son de cronograma.
  - No sumé el portafolio, porque el script no entrega totales de dinero.

**Siguiente paso:** puedo preparar la solicitud de cambio de PRY-202, PRY-207 o PRY-206, que exceden el aprobado. También puedo armar el detalle por proveedor de PRY-211, que es el que más cerca está del tope.

Los términos estaban vigentes (v1.3, aceptados por José Francisco Ñáñez el 2026-10-28), así que no hubo que registrarlos de nuevo. La corrida quedó registrada como `2026-10-28-budget-tracking-1`.

Archivos en `/home/claude/r12/logistica/espacio/estado/corridas/`:
- salida-budget-tracking.md
