# Corrida · 2026-10-28-portfolio-report-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-report html

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-28; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-28T21:53:34 · **Fin:** 2026-10-28T21:54:07 · **Duración:** 33 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-report` | 13 | 74 | 18 | 49 | 7 verdes contradichos; PRY-204 con 13 señales; PRY-207 y PRY-209 en silencio |

Por señal (`portfolio-report`): `milestone_met_without_evidence` 16, `commitment_overdue` 9, `declared_vs_evidence` 7, `progress_vs_plan` 5, `commitment_undated` 3, `commitment_rescheduled` 3, `variance_time` 2, `silent` 2, `change_without_baseline` 1, `rebaseline_unauthorized` 1

## Lo que el agente mostró

# Portafolio — 2026-10-28

El informe HTML quedó generado en `/home/claude/r12/logistica/espacio/reportes` (23 páginas). Cargué 13 fichas de `estado/records/` con la instantánea del 2026-10-28, así que no hay fichas viejas. Los términos v1.3 ya estaban vigentes, aceptados por José Francisco Ñáñez el 2026-10-28, y no hizo falta registrarlos de nuevo.

**Qué cambió:** nada. La instantánea previa es de hoy y el diff dio 0 diferencias, así que esta corrida es el punto de partida.

**Resultado:** de los 13 proyectos, 10 tienen hallazgos, 49 señales en total.
- **Verdes contradichos:** 7 proyectos se declaran en verde y la evidencia no lo sostiene (PRY-201, 204, 205, 206, 207, 208 y 209).
- **En silencio:** PRY-207 (22 días) y PRY-209 (17 días).
- **Desviación de tiempo:**
  - PRY-201: +40 días contra la línea base original.
  - PRY-206: +94 días, con una replanificación sin autorización.
- **Cambio sin línea base:** PRY-203.
- **PRY-204:** concentra 13 señales, entre ellas 5 compromisos vencidos, 2 sin fecha y 3 reprogramados.
- **Hitos cumplidos sin evidencia:** 16 en total.
- **Sin señales:** PRY-199, 210 y 211.
- **Autoridad de aprobación:** ningún proyecto la tiene registrada (13 de 13).
- **Sin producto asignado:** 7 proyectos (PRY-201, 203, 205, 206, 207, 209 y 211).

**Qué vista va a quién:**
- `index.html`: vista por campo, con la cadena de evidencia completa. Es para quien va a actuar.
- `decisiones.html`: vista por decisión, con preguntas cerradas y la consecuencia de no decidir. Es para el patrocinador.
- También hay una página por proyecto. El PDF sale de imprimir el HTML.

**Confirmación del mes:** no se generó. Es una sesión de prueba sin interfaz y nadie podía responder.

**Corrida registrada:** `2026-10-28-portfolio-report-1`. Tardó 18 segundos y no hubo que releer ninguno de los 74 documentos. Lo que te mostré quedó en `estado/corridas/salida-portfolio-report.md`.

**Pie:** criterio-portfolio 0.12.1 · fichas del 2026-10-28 · campos inciertos: no los listé aparte, están en cada página de proyecto · términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.12.1

**Siguiente paso:** el comité es el 2026-10-31. Puedo preparar el material de comité, o entrar al detalle de PRY-204, PRY-206 y los dos proyectos en silencio.
