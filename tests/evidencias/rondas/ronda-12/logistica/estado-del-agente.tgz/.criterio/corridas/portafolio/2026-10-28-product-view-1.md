# Corrida · 2026-10-28-product-view-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:product-view entregas en el día

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-28; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-28T21:52:43 · **Fin:** 2026-10-28T21:53:29 · **Duración:** 45 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-view` | 13 | — | 30 | 49 | Producto de un solo proyecto (PRY-202): sin sección de grupo. Señaló 4 hitos cumplidos sin evidencia, avance 80% contra plan 100%, fecha de fin vencida, 7 proyectos sin producto. No sabe el área dueña de esos 7 ni si existe evidencia fuera de la carpeta. |

Por señal (`product-view`): `milestone_met_without_evidence` 16, `commitment_overdue` 9, `declared_vs_evidence` 7, `progress_vs_plan` 5, `commitment_undated` 3, `commitment_rescheduled` 3, `variance_time` 2, `silent` 2, `change_without_baseline` 1, `rebaseline_unauthorized` 1

## Lo que el agente mostró

**Entregas en el día** tiene un solo proyecto, PRY-202 Flota eléctrica de última milla. Por eso no armé una sección de grupo para el producto y dejé el proyecto tal cual. Todas las cifras salen de `compute` al 2026-10-28.

- **Avance contra plan:** el proyecto declara 80 % y los cuatro hitos del plan figuran como cumplidos. El plan sostiene 100 %, así que el avance declarado queda 20 puntos por debajo.
- **Hitos sin evidencia:** los cuatro hitos «cumplidos» no tienen documento de recibo en la carpeta.
- **Fecha de fin:** la fecha comprometida del producto es 2026-09-11, que ya venció hace 47 días. El gerente declara amarillo al 2026-10-25, y ese informe no explica nada de lo anterior.
- **Compromiso vencido:** Liliana Torres debía «Entregar el punto 13» el 2026-10-18.
- **Dinero:** las cuatro cifras están.

| Concepto | COP | % |
|---|---|---|
| Aprobado | 9.500.000.000 | |
| Ejecutado | 5.644.787.990 | 59,4 % |
| Comprometido | 2.718.494.817 | 28,6 % |
| Proyección | 9.926.714.164 | 4,5 % sobre lo aprobado |

- **Sin producto declarado:** siete de los 13 proyectos no declaran producto: PRY-201, 203, 205, 206, 207, 209 y 211. El cálculo no entrega su área dueña, así que no la escribí. El producto de PRY-199 aparece como «PRD-299», un código, y conviene confirmar si es un producto real.
- **Lo que no sé:** si hay evidencia de recibo de los hitos fuera de la carpeta, qué pasó después del informe del 2026-10-25, y el área dueña de esos siete proyectos. No releí los documentos fuente en esta corrida. Dependo de lo que dicen las fichas.

Los términos ya estaban vigentes a nombre de José Francisco Ñáñez, 2026-10-28, así que no hubo que registrarlos de nuevo. La corrida quedó registrada como `2026-10-28-product-view-1`.

Archivos en `/home/claude/r12/logistica/espacio/estado/corridas/`:
- `salida-product-view.md`
