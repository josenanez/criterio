# Corrida · 2026-10-28-product-publish-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-publish (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-28; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-28T21:21:15 · **Fin:** 2026-10-28T21:21:46 · **Duración:** 31 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-publish` | 15 | — | 17 | 35 | No se publicó: no hay carpeta de productos publicados configurada; la ficha quedó calculada pero sin escribir |

Por señal (`product-publish`): `requirement_untraced` 13, `evidence_stale` 11, `requirement_without_acceptance` 6, `requirement_accepted_without_evidence` 3, `requirement_undecided` 2

## Lo que el agente mostró

No publiqué la ficha de PRD-303 (Logística de frío), porque no hay una carpeta de productos publicados. La configuración no tiene esa ruta y en el espacio no existe ninguna carpeta `publicados`. No creé una ni inventé la ruta. Acordar el sitio común es una conversación de la organización, no algo que este comando pueda resolver.

Los términos ya estaban vigentes (versión 0.12.1, aceptados por José Francisco Ñáñez el 2026-10-28). No hizo falta registrarlos de nuevo.

**Lo que la ficha llevaría, con corte al 2026-10-28** (calculado, no escrito en ningún sitio):
- **Requerimientos:** 15 (13 aceptados, 2 propuestos).
- **Proyectos:** 0. Ningún requerimiento tiene proyecto asignado, así que otro producto no podría cruzar con este por proyecto compartido.
- **Métricas afirmadas:** 1.
- **Segmento declarado:** Farmacéuticas.
- **Métrica:** `volumen_mensual` = 70118. Sale de `documentos/productos/PRD-303/00-definicion/2026-05-27-caso-de-negocio.md` (2026-05-27). No hay serie medida con la que contrastarla.

La corrida quedó registrada como `2026-10-28-product-publish-1`, con la salida guardada en `estado-producto/PRD-303/corridas/salida-product-publish.md`. Registra 35 hallazgos sobre los requerimientos (13 sin trazar a un proyecto, 11 con evidencia de hace 12 meses o más, 6 aceptados sin criterio de aceptación, 3 aceptados sin evidencia, 2 sin decidir).

Para publicar, hay que indicar la carpeta común de fichas de producto (por ejemplo `productos/publicados/`) y volver a correr `/product-publish`.
