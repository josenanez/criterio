# Corrida · 2026-10-28-portfolio-wake-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-wake (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-28; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-28T21:54:11 · **Fin:** 2026-10-28T21:55:55 · **Duración:** 104 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-wake` | 13 | — | 31 | 49 | Barrido: 74 documentos sin cambios, 0 recalculos. Confirmación: 5 preguntas formuladas, sin respuesta (prueba sin interfaz). Sin peticiones. No sé si las fichas sin autoridad reflejan un vacío real o un documento fuera de la carpeta. |

Por señal (`portfolio-wake`): `milestone_met_without_evidence` 16, `commitment_overdue` 9, `declared_vs_evidence` 7, `progress_vs_plan` 5, `commitment_undated` 3, `commitment_rescheduled` 3, `variance_time` 2, `silent` 2, `change_without_baseline` 1, `rebaseline_unauthorized` 1

## Lo que el agente mostró

Revisé la carpeta: 74 documentos, ninguno cambió, y no hay peticiones pendientes. Hoy tocaban el barrido y la confirmación mensual.

- **Términos:** ya estaban vigentes (v1.3, aceptados por José Francisco Ñáñez el 2026-10-28), así que no los registré de nuevo.
- **Umbrales:** nada nuevo cruzó uno desde el informe de portafolio de hoy. Siguen abiertas las 49 señales de ese informe. Las más cargadas son PRY-204, con 13, y PRY-207 y PRY-209, en silencio.
- **Confirmación:** formulé las cinco preguntas, que siguen sin respuesta porque esta prueba no tiene interfaz. Son:
  - la autoridad de aprobación de PRY-204 (ninguno de los 13 proyectos la tiene registrada);
  - si se mantiene el verde de PRY-204;
  - la replanificación de PRY-206 sin autorización (+94 días);
  - el cambio de PRY-203 sin línea base;
  - el producto sin asignar de PRY-201.
- **No sé** si la falta de autoridad en las fichas es un vacío real o un documento que está fuera de la carpeta.
- **Registro:** dejé constancia del barrido y de la confirmación, y guardé la corrida en `estado/corridas/salida-portfolio-wake.md` (31 segundos).

Vuelvo el **2026-10-29**. Ese día toca el informe de comité, porque el comité es el 2026-10-31.

## Respuesta 2

El mapa de Rostrum quedó en `.criterio/rostrum/config.json`, con 3 entradas de la familia pmo y la organización "Logística": Vera (portafolio), Samuel (PRY-204) y Alba (PRD-303). Los términos 1.3 quedaron aceptados por José Francisco Ñáñez el 2026-10-28, y los comprobantes están en `.criterio/terminos/`.

Samuel y Alba no tienen marca en su carpeta de documentos. Se marcan con `/criterio-project:pm-setup` y `/criterio-product:product-setup`. Para levantar el portal, corre `/criterio-server:server-start`.

## Respuesta 3

Rostrum está corriendo en **http://127.0.0.1:8788/**. Lo levanté en la forma «para mirarlo un rato»: solo escucha en este equipo y no tiene autenticación.

- **Puerto:** el 8787 ya lo usaba otro servidor de Rostrum. Ese sirve otro mapa, con Samuel en PRY-211, Alba en PRD-306 y productos de telecomunicaciones. No es el de este espacio, así que usé el 8788.
- **Términos:** están vigentes (versión 1.3, aceptada el 2026-10-28 por José Francisco Ñáñez). No tuve que mostrarlos ni registrarlos de nuevo.
- **Mapa:** coincide con el disco, sin entradas nuevas, desaparecidas ni sin estado. Tiene tres entradas: Vera (portafolio), Samuel (PRY-204) y Alba (PRD-303).
- **Informe de la PMO:** ya existía en `reportes/`, así que no corrí `portfolio-report`.

| Ruta | Qué muestra |
|---|---|
| `/` | La portada, con una puerta por familia y el formulario de peticiones |
| `/pmo`, `/decisiones` | El informe de la PMO y el material del comité |
| `/proyectos` | 13 proyectos, de PRY-199 a PRY-211 |
| `/productos` | 6 productos |
| `/corridas` | 33 corridas registradas, de todos los agentes |
| `/estado.json` | De cuándo es lo de cada agente. Ninguno tiene peticiones abiertas ni una última corrida registrada |

Las rutas `/familia/…`, `/vence` y `/caso/…` de la lista general no salieron en las direcciones que imprimió el servidor. Aquí solo hay familia PMO y no las probé.

Para pasar los enlaces: `/` al patrocinador, `/decisiones` al comité y `/proyectos` a quien pregunta por un proyecto. El informe se generó el 2026-10-29 (hora UTC), y cada página indica su fecha.

Si después quieren que quede corriendo para el patrocinador, hay que pedir tres cosas a la organización:
- un host y un puerto dentro de la red;
- publicarlo detrás de su control de acceso, porque el servidor no autentica;
- mantener el equipo encendido.

Para eso se usaría `--abierto`.

El servidor sigue activo en segundo plano. El registro está en `/tmp/claude-0/-home-claude-r12-logistica-espacio/692b0e4d-0e89-5e8d-a391-2cabbf233557/scratchpad/rostrum.log`.
