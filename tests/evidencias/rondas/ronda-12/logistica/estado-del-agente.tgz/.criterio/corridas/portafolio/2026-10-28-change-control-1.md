# Corrida · 2026-10-28-change-control-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:change-control PRY-205 mover la salida a producción 30 días

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-28; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-205

**Inicio:** 2026-10-28T21:43:25 · **Fin:** 2026-10-28T21:44:32 · **Duración:** 67 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `change-control` | 13 | — | 47 | 49 | Evaluó mover 30 días el arranque de PRY-205 (2027-08-08 a 2027-09-07). Impacto en portafolio: ninguno declarado. No sabía: quién pide, motivo, costo, autoridad de cambios (no declarada en el acta), vigencia de CT-540, hitos intermedios. |

Por señal (`change-control`): `milestone_met_without_evidence` 16, `commitment_overdue` 9, `declared_vs_evidence` 7, `progress_vs_plan` 5, `commitment_undated` 3, `commitment_rescheduled` 3, `variance_time` 2, `silent` 2, `change_without_baseline` 1, `rebaseline_unauthorized` 1

## Lo que el agente mostró

**La solicitud de cambio de PRY-205 quedó evaluada, pero no se puede aprobar todavía.** La petición no dice quién la hace ni por qué, y el acta no declara quién tiene autoridad para cambios de tiempo o costo. Los términos ya estaban vigentes (v1.3, aceptados por José Francisco Ñáñez el 2026-10-28), así que no los registré de nuevo.

- **Qué se pide:** el hito «Arranque de la operación» pasaría del 2027-08-08 al 2027-09-07, que son los 30 días pedidos. Es una lectura mía de «salida a producción»: el acta define el éxito como «en producción y medido».
- **Línea base:** hay una sola, la v1 del 2026-02-13, así que no hay replanificaciones previas. Aprobar el cambio crearía la línea base 2 y dejaría la v1 intacta.
- **Alcance:** no hay cambio declarado, pero el acta tampoco detalla los componentes, así que no hay con qué comprobarlo.
- **Costo:** no viene en la solicitud y no lo estimé. Hoy hay 59,2 millones COP (7,4 %) entre la proyección al cierre (740,8 millones) y lo aprobado (800 millones). No sé si 30 días más caben ahí.
- **Efecto en el portafolio:** el cálculo no encuentra proyectos que dependan de PRY-205, ni directa ni indirectamente. Eso solo dice que nadie declaró una dependencia, no que no existan. Tampoco sabe cuántos días se movería cada hito.
- **Quién decide:** va al Comité de Operaciones por defecto, porque fue quien aprobó la línea base. El próximo comité es el 2026-10-31.
- **Hallazgos sobre el estado actual:**
  - El informe del 2026-10-18 declara verde y 46 %, pero cuenta una prueba de inventario fallida y dos semanas perdidas.
  - Dos hitos figuran como cumplidos sin acta de recibo en la carpeta del proyecto.
  - Hay dos compromisos del comité del 2026-10-22 sin evidencia de cumplimiento: el del punto 26 ya venció y el del punto 19 sigue abierto.
  - Los hitos, el contrato CT-540 y el informe hablan de bodega, estanterías y vehículos eléctricos, no de seguimiento satelital.
  - El contrato no dice su vigencia, y el proveedor no ha confirmado la fecha de su última entrega.

Para llevarlo al comité faltan cuatro cosas. Ricardo Salas o Mauricio Pérez tienen que escribir la solicitud con motivo y cifra de costo, y confirmar con el proveedor la vigencia de CT-540. También hay que adjuntar las actas de los dos hitos, y el comité tiene que declarar la autoridad de cambios del proyecto. Si lo aprueban, registro la línea base 2 con ese documento como fuente.

La corrida quedó registrada (`2026-10-28-change-control-1`). Su señal más relevante para este caso: el cambio de PRY-206 sin línea base nueva, que no tiene relación con PRY-205.

Archivos en `/home/claude/r12/logistica/espacio/estado/corridas/`:
- `salida-change-control.md`
- `2026-10-28-change-control-1.md`
