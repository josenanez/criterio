# Corrida · 2026-10-28-project-history-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-history PRY-200

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-28; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-200

**Inicio:** 2026-10-28T21:44:40 · **Fin:** 2026-10-28T21:45:42 · **Duración:** 62 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-history` | 13 | — | 47 | 49 | Historia de PRY-200 sobre 6 documentos (2026-04-12 a 2026-10-27). 1 replanificación (+25 días, 4.9%), sin motivo documentado ni acta de aprobación. No pudo fechar el deslizamiento: hay un solo estado declarado. Sin documentos en 2026-T3. |

Por señal (`project-history`): `milestone_met_without_evidence` 16, `commitment_overdue` 9, `declared_vs_evidence` 7, `progress_vs_plan` 5, `commitment_undated` 3, `commitment_rescheduled` 3, `variance_time` 2, `silent` 2, `change_without_baseline` 1, `rebaseline_unauthorized` 1

## Lo que el agente mostró

## Historia · PRY-200 Centro de distribución del norte · 2026-04-12 a 2026-10-27

**Leí:** 6 documentos entre 2026-04-12 y 2026-10-27.
**Trimestres sin documentos:** 2026-T3. No hay nada entre el cronograma v1 (2026-04-12) y la solicitud de cambio CC-01 (2026-10-19).

Los términos ya estaban vigentes (v1.3, aceptados por José Francisco Ñáñez el 2026-10-28), así que no los registré de nuevo.

**En una línea:** el proyecto arrancó el 2026-04-12 con cierre previsto para 2027-09-14. Todo lo demás está escrito en los últimos diez días. El 2026-10-19 una solicitud de cambio pide +25 días y 50.000.000 COP. El 2026-10-27 llegan un cronograma v2, con cierre el 2027-10-09, y un informe que declara Rojo con 76% de avance. El plan solo sustenta entre 25% y 50%.

| Replanificaciones | Atraso vs. original | Meses declarando sin sustento | Cambios de gobierno |
|---|---|---|---|
| 1 | 25 días (4.9%) | No calculable: hay un solo estado declarado | 0 |

- **Replanificación:** el cronograma v2 mueve "Pruebas con carga real" del 2027-09-14 al 2027-10-09 y no declara motivo. La CC-01 dice "autorizada por el comité", sin fecha ni comité nombrado, y no hay acta que la apruebe. Los 25 días coinciden con la CC-01, así que el atraso no autorizado es 0 días. Falta la constancia de la autorización.
- **Hito sin evidencia:** "Diseño de la operación aprobado" figura cerrado desde el 2026-08-27, sin documento de aprobación. Lleva 62 días así.
- **Compromiso vencido:** Camilo Beltrán debía entregar el punto 15 el 2026-10-02. El comité lo registró el 2026-10-24, con 22 días de vencido, y hoy lleva 26. No hay acta de recibo. Ningún compromiso se repitió.
- **Gobierno:** sin cambios de patrocinador, gerente ni comité. La ficha no tiene autoridad ni fase del proyecto.
- **Lo declarado:** el estado es Rojo, así que el problema no está oculto. Lo que no cuadra es el 76% de avance.
- **Presupuesto:** el aprobado sigue en 1.200.000.000 COP aunque la CC-01 agrega 50.000.000. Ejecutado: 47.3%. Comprometido: 29.7%.

**Lo que no sé:**
- Los informes anteriores al 2026-10-27, que son lo único que permitiría fechar el deslizamiento.
- Quién autorizó la CC-01 y cuándo.
- Si el paro de transportadores y la rotación del jefe de bodega motivaron la replanificación.

No atribuyo intención: que el 76% no tenga sustento no dice que alguien lo inflara. Puedo llevar esto al comité, que tendría que ratificar la CC-01 con acta, o al cierre del proyecto.

La corrida quedó registrada como `2026-10-28-project-history-1`. Lo que te mostré está guardado en `estado/corridas/salida-project-history.md`, junto con una versión más completa. El script midió 47 segundos pero no pudo medir el número de documentos leídos.
