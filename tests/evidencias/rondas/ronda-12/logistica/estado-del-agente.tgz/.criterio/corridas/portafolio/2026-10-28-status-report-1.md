# Corrida · 2026-10-28-status-report-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:status-report PRY-207

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-28; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-207

**Inicio:** 2026-10-28T21:38:46 · **Fin:** 2026-10-28T21:39:35 · **Duración:** 49 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `status-report` | 13 | — | 34 | 49 | Informe de PRY-207: verde declarado contradicho por silencio de 22 días, brecha de 76.0 puntos entre avance y plan, y 3 hitos cumplidos sin evidencia. Sin dato: producto, autoridad, fase, reuniones y dueños de riesgos. |

Por señal (`status-report`): `milestone_met_without_evidence` 16, `commitment_overdue` 9, `declared_vs_evidence` 7, `progress_vs_plan` 5, `commitment_undated` 3, `commitment_rescheduled` 3, `variance_time` 2, `silent` 2, `change_without_baseline` 1, `rebaseline_unauthorized` 1

## Lo que el agente mostró

## PRY-207 · Portal de clientes con trazabilidad — estado al 2026-10-28

El verde que declara el gerente no se sostiene con los documentos. Los términos ya estaban vigentes (v1.3, aceptados por José Francisco Ñáñez el 2026-10-28), así que no los registré de nuevo.

**Lo que declara el gerente (Jorge Medina):** verde, 24% de avance, al 2026-10-06. La declaración tiene 22 días.

**Lo que no explica el verde:**
- **Silencio:** 22 días sin documentos nuevos, y el umbral es 15.
- **Avance contra plan:** el gerente declara 24% y el plan sostiene 100% (3 de 3 hitos). La brecha es de 76.0 puntos.
- **Hitos:** los tres figuran como cumplidos y ninguno tiene evidencia de cumplimiento. Les faltan 342, 205 y 68 días de evidencia.

**Contra el plan:**
- **Cierre:** 2026-08-21 en la línea base original y en la vigente, sin replanificaciones. Esa fecha ya pasó hace 68 días.
- **Presupuesto:**

  | Concepto | COP |
  |---|---|
  | Aprobado | 9.500.000.000 |
  | Comprometido | 6.597.325.946 (69.4%) |
  | Ejecutado | 3.638.979.753 (38.3%) |
  | Proyección al cierre | 9.899.993.006 (4.2% sobre lo aprobado, umbral 10%) |

**Abierto:**
- **Riesgos sin dueño, probabilidad, impacto ni fecha:** el proveedor no ha confirmado la fecha de la última entrega, y hay paros de transportadores en las vías principales.
- **Incidencia:** la prueba de exactitud de inventario no alcanzó el valor pactado y se repite. Tampoco trae dueño ni fecha.
- **Compromisos vencidos:** ninguno, pero no hay actas de reuniones, así que no hay compromisos que seguir.

**Sin dato:**
- Producto, autoridad y fase del proyecto.
- Última reunión.
- Dueños de los riesgos y la incidencia.
- Los datos del acta y del cronograma tienen 16 meses de antigüedad.

El proyecto puede ir al comité del 2026-10-31. Si quieres, preparo el punto de comité.

El informe completo está en `/home/claude/r12/logistica/espacio/estado/corridas/salida-status-report.md`. La corrida quedó registrada como `2026-10-28-status-report-1`, con 34 segundos medidos por el script.

Criterio · criterio-portfolio 0.12.1 · ficha `PRY-207.json` del 2026-10-28 · términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.12.1
