**Acta previa:** sí, existe: acta de constitución del 2026-04-20 (`PRY-210-puntos-de-recogida-en-estaciones/00-gobierno/2026-04-20-acta-constitucion.docx`). Términos v1.3 vigentes (aceptados por José Francisco Ñáñez el 2026-10-28); no hizo falta registrarlos de nuevo.

## Acta — PRY-210 Puntos de recogida en estaciones
**Estado:** existe, del 2026-04-20

### Qué falta
| Campo | Estado | Consecuencia |
|---|---|---|
| Autoridad del gerente | **No está.** El acta no dice hasta qué monto ni qué cambio de alcance o fecha decide Mauricio Pérez sin comité. | Cualquier ajuste de los 3.300.000.000 COP o de las fechas sube al Comité de Tecnología, porque nadie puede decir que el gerente podía decidirlo solo. |
| Objetivo de negocio | **Es la solución, no el negocio.** "Entregar puntos de recogida en estaciones para Tecnología". | No hay resultado de negocio contra el cual decidir si el proyecto valió la pena ni qué recortar si falta plata. |
| Alcance | **Vacío en la práctica.** "Componente 1, 2, 3", sin descripción. | No se puede verificar qué entregó el proyecto ni detectar un cambio de alcance: no hay línea base de alcance. |
| Exclusiones | **Declaradas pero sin contenido.** "Lo que otro proyecto cubre", sin decir cuál proyecto ni qué. | Un traslape con otro proyecto no se puede ver ni discutir; la exclusión no excluye nada concreto. |
| Patrocinador | Cumple: Felipe Arango (persona con nombre). | — |
| Supuestos y restricciones | **No están.** El acta solo tiene "Dependencias declaradas: Ninguna". | Con 49% reportado y un riesgo abierto sobre un proveedor, "ninguna dependencia" es poco creíble; el acta no sirve para contrastar nada de esto. |
| Criterio de éxito | **No es medible ni tiene quién lo mida.** "En producción y medido", sin métrica, umbral ni responsable. | El cierre no tiene contra qué compararse: cualquier resultado se puede declarar éxito. |
| Hitos principales | **No están.** Solo inicio (2026-04-30) y cierre (2026-10-15). | Sin hitos, el avance de 49% no se puede contrastar con nada; el único punto verificable es la fecha final. |
| Comité y cadencia | Comité de Tecnología, nombrado. **Cadencia no declarada.** | No se sabe cada cuánto debe revisarse el proyecto. |

### Contenido
**Objetivo de negocio:** pendiente de definir. Lo que dice el acta es solo la solución: "Entregar puntos de recogida en estaciones para Tecnología" (acta, 2026-04-20).
**Alcance:** "Componente 1, 2 y 3", sin detalle (acta, 2026-04-20). Pendiente de definir.
**Exclusiones:** "Lo que otro proyecto cubre" (acta, 2026-04-20). Pendiente de nombrar cuál proyecto y qué.
**Patrocinador:** Felipe Arango · **Gerente:** Mauricio Pérez (acta, 2026-04-20)
**Autoridad del gerente:** pendiente de definir. No figura en ningún documento de la carpeta.
**Comité al que reporta:** Comité de Tecnología (acta, 2026-04-20) · **Cadencia:** pendiente de definir.
**Presupuesto aprobado:** 3.300.000.000 COP, por el Comité de Tecnología el 2026-04-20 (acta).
**Supuestos:** pendiente de definir. · **Restricciones:** pendiente de definir. Dependencias: "Ninguna declarada" (acta).
**Criterio de éxito:** "Puntos de recogida en estaciones en producción y medido" (acta). Sin métrica. · **Lo mide:** pendiente de definir.
**Hitos principales:** pendiente de definir. Solo inicio 2026-04-30 y cierre 2026-10-15 (acta).

### Lo que ya pesa hoy por estos vacíos
El cierre comprometido era el 2026-10-15. Hoy es 2026-10-28 y el informe de avance del 2026-10-24 declara verde con 49% (informe de avance, 2026-10-24). No hay en la carpeta ningún cambio aprobado ni nueva fecha. Como el acta no define la autoridad del gerente, no se puede saber si moverla era decisión suya o del comité; hoy no la ha decidido nadie que conste en documentos. El informe además registra un riesgo abierto, que el proveedor no ha confirmado la fecha de la última entrega, sin dueño ni fecha. La carpeta no contiene otros documentos de este proyecto (ni cronograma, ni minutas, ni contrato de proveedor), así que lo que se habló fuera de estos dos documentos no lo sé.

### Siguiente paso
- El acta quedó sin autoridad declarada. Ofrezco llevar esa definición al Comité de Tecnología como decisión (monto y tipo de cambio que Mauricio Pérez puede resolver solo), junto con la fecha de cierre vencida. En esta sesión no hay quién responda; lo dejo ofrecido.
- Ofrezco pasar al registro RAID el riesgo del proveedor y "no hay dependencias" como supuesto sin verificar.

*Pie de rigor: borrador de trabajo basado solo en los dos documentos de la carpeta de PRY-210; cada dato lleva su fuente y la verificación es suya. No sé lo que se haya hablado fuera de esos documentos. Ningún campo pendiente fue completado por mí.*
