# Corrida del 2026-10-28 · document-index

13 proyectos · 7 s · 49 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 16 |
| `commitment_overdue` | 9 |
| `declared_vs_evidence` | 7 |
| `progress_vs_plan` | 5 |
| `commitment_undated` | 3 |
| `commitment_rescheduled` | 3 |
| `variance_time` | 2 |
| `silent` | 2 |
| `change_without_baseline` | 1 |
| `rebaseline_unauthorized` | 1 |

74 documentos, ninguno cambió; nada que releer ni citas rotas. No se leyó contenido de documentos.

Contra la corrida del 2026-10-28: +0 hallazgos.

## Lo que produjo

Carpeta al 2026-10-28: 74 documentos, todos sin cambio. No hay nada que releer ni citas rotas.
