Parto de la ficha `estado/records/PRY-205.json` (actualizada 2026-10-28) y de los documentos citados en ella. Términos vigentes: v1.3, aceptados por José Francisco Ñáñez el 2026-10-28; no hubo que registrarlos de nuevo.

## Solicitud de cambio — PRY-205 Seguimiento satelital de la flota — 2026-10-28

**Qué se pide:** mover 30 días la salida a producción. Lo leo como el hito «Arranque de la operación» (2027-08-08 → 2027-09-07), porque el criterio de éxito del acta es «en producción y medido».
**Quién lo pide:** no consta. La solicitud no lo dice y no hay solicitud de cambio en la carpeta del proyecto (`changes: []`).
**Por qué:** no consta. El informe del 2026-10-18 trae tres hechos que podrían ser el motivo, pero ningún documento los une a este cambio, así que no los adopto como causa:
- La prueba de exactitud de inventario no alcanzó el valor pactado y se repite.
- El equipo perdió dos semanas por la rotación del jefe de bodega.
- Se ajustó el plan de arranque con el cliente ancla.

### Línea base de partida
Hay una sola, la v1 del 2026-02-13 («Aprobación del acta de constitución»), con cierre el 2027-08-08. No hay replanificaciones previas. Con esto, la línea base original y la vigente son la misma.

### Impacto
| Dimensión | Hoy | Con el cambio | Diferencia |
|---|---|---|---|
| Alcance | Componentes 1, 2 y 3 (el acta no los detalla) | Sin cambio declarado | 0 declarada |
| Tiempo | Cierre 2027-08-08 | Cierre 2027-09-07 | +30 días (+30 contra la original) |
| Costo | Aprobado 800.000.000 COP; comprometido 501.957.533; ejecutado 326.910.807; proyección al cierre 740.846.224 | No declarado | **Sin dato** |

Quién absorbe lo que no se declaró:
- **Costo:** la solicitud no trae cifra, y no la invento. Hoy hay 59.153.776 COP (7,4 %) entre la proyección y lo aprobado. No sé si 30 días más de equipo y de bodega caben ahí. Falta la tarifa del equipo y los costos que corren por mes, y ningún documento los da. Si nadie lo declara, se absorbe en ese margen o en horas no pagadas.
- **Alcance:** el acta no detalla los componentes, así que no se puede comprobar que el alcance no cambie. Un alcance «sin cambio» sobre componentes que nadie describió es una afirmación que no tiene contra qué verificarse.
- **Hitos intermedios:** no sé si «Adecuación de la bodega terminada» (2027-01-08) y «Pruebas con carga real» (2027-04-24) se mueven también o si solo se corre el último tramo. El cálculo de impacto los lista como hitos por los que pasa el cambio, no como hitos que se movieron.

### Efecto en el portafolio
| Proyecto afectado | Cómo | Gerente |
|---|---|---|
| Ninguno | El cálculo (`portafolio.py impact`) no encuentra proyectos que dependan de PRY-205, ni directa ni indirectamente. `cannot_hold_date`: 0. Dependencias sin confirmar: 0. | — |

Ese «ninguno» solo dice que **nadie declaró** una dependencia. El acta de PRY-205 dice «Ninguna declarada» y su ficha no tiene dependencias registradas (`raid.dependencies: []`). No prueba que no existan. El cálculo tampoco dice cuántos días se mueve cada hito: eso necesita holgura por actividad, y la ficha de portafolio no la tiene.

**Contrato CT-540** (Estanterías Industriales del Valle S.A.S.). Sus tres entregables están pactados con fecha y monto de 79.548.107 COP cada uno:
- Suministro de estanterías: 2026-07-19, recibido con acta del 2026-07-30 y facturado.
- Bolsa de horas de ingeniería: 2026-12-12, pendiente.
- Arriendo de vehículos eléctricos: 2027-05-07, pendiente.

Moverle 30 días al arranque no cambia por sí solo estas fechas. Pero el contrato que tengo no dice su vigencia ni si los entregables están atados a la fecha de arranque. Hay que revisarlo con el proveedor antes de decidir.

El informe además dice que «el proveedor no ha confirmado la fecha de la última entrega». Esa última entrega cae después del 2027-05-07 y antes de un arranque que se movería a septiembre. Un riesgo ya abierto se vuelve más probable de materializarse con este cambio.

### Quién decide
**Autoridad requerida:** no se puede determinar. La ficha marca `identity.authority` como no encontrada y el acta no declara umbrales de autoridad para cambios de tiempo ni de costo.
**Según:** acta de constitución del 2026-02-13. Solo dice que el Comité de Operaciones aprobó el presupuesto y que el patrocinador es Mauricio Pérez.
**Va a comité:** **sí, por defecto.** Sin autoridad delegada, lo único comprobable es que el Comité de Operaciones aprobó la línea base. Le corresponde decidir quien la aprobó. Esa ausencia de autoridad declarada es el hallazgo de fondo de esta solicitud. El próximo comité de la configuración es el 2026-10-31.

### Lo que la evidencia dice del estado actual (relevante para decidir)
- **Estado declarado:** verde, 46 % (informe del 2026-10-18, con 10 días de antigüedad). Es una declaración del gerente.
- **Lo que el mismo informe cuenta:** una prueba fallida que se repite y dos semanas perdidas. Con eso, «verde» y un cambio de fecha pedido 10 días después no se sostienen juntos sin explicación.
- **Hitos cerrados sin evidencia en la carpeta de PRY-205:** la ficha marca «Diseño de la operación aprobado» (2026-06-09) y «Permisos de operación obtenidos» (2026-09-23) como cumplidos, pero la carpeta no trae el acta de recibo de ninguno (`evidence: null`). Las actas con esos nombres están en las carpetas de PRY-199, PRY-204, PRY-206 y PRY-208, no en esta. El estado «cumplido» viene del cronograma, que es una declaración.
- **Compromisos del comité del 2026-10-22:**
  - Felipe Arango, «Entregar el punto 26», para el 2026-10-21. La fecha es anterior a la del comité donde se registró y no hay acta de recibo.
  - Beatriz Cuéllar, «Entregar el punto 19», para el 2026-10-23, abierto.
  - Ninguno dice qué es el «punto» ni a qué entregable corresponde.
- **Inconsistencia de contenido:** el proyecto se llama «Seguimiento satelital de la flota», pero los hitos son de adecuación de bodega, el contrato es de estanterías y arriendo de vehículos eléctricos, y el informe habla de exactitud de inventario. Sospecho una mezcla de plantillas, o que el nombre no describe el alcance real. Ninguna de las dos cosas se resuelve con estos documentos.

### Si no se aprueba
El proyecto sigue con cierre el 2027-08-08 y una prueba de exactitud de inventario que no pasó. Si no se recupera el tiempo perdido, esa fecha se incumple sin que haya una solicitud formal ni una línea base que lo refleje, y el atraso aparecería recién como desviación contra una línea base que nunca se actualizó. Eso es lo que este mecanismo existe para evitar.

### Si se aprueba
Línea base 2 — cierre 2027-09-07 · presupuesto: **no declarado**, por lo que no puedo escribir un monto. Quedaría en 800.000.000 COP mientras no se apruebe otro · motivo: pendiente de que lo declare quien pide (los tres hechos de arriba son candidatos, no motivo registrado).
La v1 no se toca. El conteo de replanificaciones pasa de 0 a 1.
Desviación acumulada contra la línea base original: **+30 días** en tiempo · **costo: sin dato**. Quedaría una sola replanificación, así que contra la original y contra la vigente la diferencia de tiempo sería de 30 días y 0 días respectivamente.
Reconciliación: hoy `changes.baseline_moved_days` = 0 y no hay cambios aprobados, así que no hay días sin autorizar. Si alguien mueve la fecha sin que se apruebe este cambio, esos 30 días saldrían como `unauthorized_days`.

### Qué no sé
- Quién pide el cambio y por qué.
- El costo de 30 días adicionales.
- Si se mueven los hitos intermedios.
- Si la vigencia del contrato CT-540 cubre el nuevo cierre.
- Qué autoridad tiene el gerente para aprobar cambios de tiempo.
- Si hay proyectos fuera de esta carpeta que dependan del arranque.

### Antes del comité del 2026-10-31
1. Que Ricardo Salas (gerente) o Mauricio Pérez (patrocinador) escriba la solicitud con motivo y cifra de costo.
2. Que confirme con Estanterías Industriales del Valle la vigencia de CT-540 y la fecha de la última entrega.
3. Que adjunte las actas de recibo de los dos hitos marcados como cumplidos.
4. Que el comité declare, por primera vez, la autoridad de cambios del proyecto.

Si el comité lo aprueba, puedo registrar la línea base 2 con el documento que lo apruebe como fuente. Hasta entonces no la registro.

---
*Rigor:* el cálculo de impacto salió del script y no de una estimación. Los documentos leídos son los de la carpeta de PRY-205 (acta, contrato CT-540, cronograma v1, informe del 2026-10-18, comité del 2026-10-22), por su caché de texto; los PDF de informe y factura los leí en texto convertido, no en el original. No leí las carpetas de los demás proyectos, solo el resultado del cálculo sobre sus fichas. No inferí nombres ni cifras de costo.
