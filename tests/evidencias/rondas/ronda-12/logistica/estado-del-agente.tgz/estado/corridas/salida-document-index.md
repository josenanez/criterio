Carpeta al 2026-10-28: 74 documentos, todos sin cambio. No hay nada que releer ni citas rotas.
