## RAID — Portafolio Logística al 2026-10-28

**De dónde sale:** las 13 fichas de `estado/records/` (PRY-199 a PRY-211), las 13 actas de constitución (sección «Dependencias declaradas»), las minutas de comité de PRY-199, 200, 201, 202, 204, 205 y 206, y las notas de reunión de PRY-204 del 2026-10-28. No releí los informes de avance: tomé lo que la ficha ya extrajo de ellos.

**Escala de valoración:** ninguna ficha trae probabilidad ni impacto. Usaría alta/media/baja, pero no las asigné: no hay base documental para hacerlo.

**13 riesgos · 0 supuestos · 17 incidencias · 6 dependencias** (tras reclasificar)
**36 sin doliente · 36 sin fecha · 0 evaluables por falta de movimiento · 1 no registrado formalmente** (aparte de los 36)

- Los 36 ítems registrados no tienen doliente, fecha de vencimiento, probabilidad ni impacto. Ninguna ficha recoge la fecha del último movimiento. Es un hallazgo y no lo rellené.
- «Sin movimiento en dos períodos» no se puede evaluar: es la primera ficha de cada proyecto y no hay RAID anterior contra el cual comparar.
- Cero supuestos en todo el portafolio. Es una ausencia de registro, no la prueba de que no se esté asumiendo nada.
- Cero dependencias registradas. Las 13 actas de constitución dicen «Ninguna declarada».

### Necesitan decisión ahora

| Id | Tipo | Qué | Doliente | Desde | Por qué sube |
|---|---|---|---|---|---|
| PRY-199-I2 · PRY-206-I1 | Incidencia | Hallazgo de seguridad en la operación de montacargas | sin doliente | 2026-10-26 · 2026-10-27 | Seguridad abierta sin doliente ni fecha. No cumple un criterio formal de escalamiento: sube por su naturaleza, y esa decisión es tuya. Dos fichas con casi el mismo texto: verificar si es el mismo hallazgo. |
| PRY-204-R2 | Riesgo (no registrado) | El proveedor podría no llegar con el equipo completo para la siguiente fase | sin doliente | 2026-10-28 | Proyecto de 18.000 M COP declarado en verde; hito «Pruebas con carga real» el 2027-01-14. Hay una «Revisión con el proveedor» comprometida por Óscar Ramírez para el 2026-11-07, la mitigación natural, pero nadie la ató a un riesgo. El patrocinador y el gerente son la misma persona (Liliana Torres): no hay a quién escalar dentro del proyecto. |
| PRY-200-I1 · PRY-202-I1 · PRY-204-I1 · PRY-203-R1 · PRY-204-R1 · PRY-207-R2 | Incidencia / riesgo | Paro de transportadores (ocurrido en 200, 202 y 204; amenaza en 203, 204 y 207) | sin doliente | 2026-10-06 a 2026-10-28 | Afecta a cinco proyectos. Cumple «afecta a otro proyecto del portafolio». |
| PRY-199-I1 · PRY-201-I1 · PRY-203-I1 · PRY-208-I2 | Incidencia | Reprogramación de la llegada de las estanterías por demoras del importador | sin doliente | 2026-10-23 a 2026-10-26 | Afecta a cuatro proyectos. PRY-199 tiene el contrato CT-199 con entrega de estanterías el 2026-11-27, pendiente. Cumple «afecta a otro proyecto». |
| PRY-199-D1 · 201-D1 · 205-D1 · 206-D1 · 207-D1 · 210-D1 | Dependencia (reclasificada) | El proveedor no ha confirmado la fecha de la última entrega | sin doliente | 2026-10-06 a 2026-10-27 | Dependencia declarada, no acordada. Seis proyectos con el mismo texto. |

Que varias fichas repitan el mismo texto exacto en proyectos que no se parecen no confirma que sea un solo hecho. Hay estanterías en PRY-203 (ruteo dinámico) y montacargas en PRY-199 (pintura de la portería). Puede ser un problema común real o texto copiado de una plantilla. No lo pude verificar con los documentos. Si es plantilla, estas filas bajan de «decisión ahora» a «verificar».

### Detectados en reuniones, no registrados

| Qué | Tipo | Dicho en | Fecha |
|---|---|---|---|
| Se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase; «nadie lo anotó como riesgo» | Riesgo | PRY-204, `2026-10-28-notas-reunion.txt` | 2026-10-28 |

Es el único. Las minutas de PRY-199, 200, 201, 202, 205 y 206 y las seis de PRY-204 anteriores al 28 de octubre solo traen asistentes, temario y tabla de compromisos. PRY-203, 207, 208, 209, 210 y 211 no tienen minutas en la carpeta, así que ahí no se pudo buscar nada.

### Sin doliente o sin fecha

Los 36 ítems registrados, sin excepción: sin doliente y sin fecha. No los repito uno por uno; están en el registro completo. Propuesta de doliente, que solo propongo y no asigno: el gerente de cada proyecto, para que confirme o redirija.

### Dependencias en riesgo

| Id | Depende de | Confirmada | Qué pasó |
|---|---|---|---|
| (ninguna registrada con código de proyecto) | — | — | No hay dependencias entre proyectos declaradas, así que no hay cruce posible. |

Las 13 actas excluyen «Lo que otro proyecto cubre» sin nombrar cuál. Esa frase señala una dependencia implícita en cada proyecto que nadie codificó. Puede ser texto de plantilla; si no lo es, hay que preguntar a cada gerente de qué proyecto habla.

Las seis dependencias reclasificadas (proveedor sin confirmar fecha) son externas: ninguna depende de un proyecto del portafolio. Solo PRY-199 (CT-199) y PRY-205 (CT-540) tienen un contrato en la ficha; el proveedor de ambos es Estanterías Industriales del Valle S.A.S. En PRY-201, 206, 207 y 210 la ficha no identifica al proveedor.

### Reclasificaciones

- **6 riesgos pasan a dependencia** (PRY-199, 201, 205, 206, 207, 210): «El proveedor no ha confirmado la fecha de la última entrega». Depende de un tercero y está sin confirmar, así que es una dependencia declarada y no un riesgo.
- **PRY-209-I1** «Se ajustó el plan de arranque con el cliente ancla»: dudosa como incidencia, porque no dice qué afecta. Parece un cambio de plan y su sitio sería control de cambios. Lo dejo como incidencia hasta que el gerente aclare.
- **PRY-211-R1** «Temporada alta que no permite detener la operación»: parece una restricción o un supuesto, más que un riesgo. No lo moví.

### Fuera del RAID, pero salió al leer

PRY-207 (fin plan 2026-08-21, declarado verde, 24 %), PRY-210 (fin plan 2026-10-15, verde, 49 %), PRY-202 (2026-09-11, amarillo, 80 %) y PRY-211 (2026-09-21, amarillo, 69 %) tienen la fecha de fin de la línea base vencida y avance declarado menor al 100 %. Las cuatro fichas tienen una sola línea base y ningún cambio aprobado. Eso es un atraso sin incidencia registrada. Corresponde a `/health-check` y `/baseline-variance`; lo dejo anotado y no lo meto en el RAID.

### Registro completo

Probabilidad e impacto: sin dato en todos. Doliente y fecha: sin dato en todos. Último movimiento: sin dato; la fuente es el informe de avance de la fecha indicada.

| Id | Tipo | Qué | Prob. | Impacto | Doliente | Fecha | Último movimiento |
|---|---|---|---|---|---|---|---|
| PRY-199-D1 | Dependencia (era riesgo) | Proveedor no ha confirmado la fecha de la última entrega | — | — | — | — | sin dato (2026-10-26) |
| PRY-199-I1 | Incidencia | Se reprogramó la llegada de las estanterías por demoras del importador | — | — | — | — | sin dato (2026-10-26) |
| PRY-199-I2 | Incidencia | Hallazgo de seguridad en la operación de montacargas | — | — | — | — | sin dato (2026-10-26) |
| PRY-200-R1 | Riesgo | Cambio en la norma de pesos y dimensiones que puede mover el alcance | — | — | — | — | sin dato (2026-10-27) |
| PRY-200-I1 | Incidencia | Un paro de transportadores detuvo los despachos durante seis días | — | — | — | — | sin dato (2026-10-27) |
| PRY-200-I2 | Incidencia | El equipo perdió dos semanas por rotación del jefe de bodega | — | — | — | — | sin dato (2026-10-27) |
| PRY-201-D1 | Dependencia (era riesgo) | Proveedor no ha confirmado la fecha de la última entrega | — | — | — | — | sin dato (2026-10-23) |
| PRY-201-I1 | Incidencia | Se reprogramó la llegada de las estanterías por demoras del importador | — | — | — | — | sin dato (2026-10-23) |
| PRY-202-R1 | Riesgo | Concentración del conocimiento en una sola persona | — | — | — | — | sin dato (2026-10-25) |
| PRY-202-R2 | Riesgo | Cambio en la norma de pesos y dimensiones que puede mover el alcance | — | — | — | — | sin dato (2026-10-25) |
| PRY-202-I1 | Incidencia | Un paro de transportadores detuvo los despachos durante seis días | — | — | — | — | sin dato (2026-10-25) |
| PRY-203-R1 | Riesgo | Paros de transportadores en las vías principales | — | — | — | — | sin dato (2026-10-25) |
| PRY-203-R2 | Riesgo | Concentración del conocimiento en una sola persona | — | — | — | — | sin dato (2026-10-25) |
| PRY-203-I1 | Incidencia | Se reprogramó la llegada de las estanterías por demoras del importador | — | — | — | — | sin dato (2026-10-25) |
| PRY-204-R1 | Riesgo | Paros de transportadores en las vías principales | — | — | — | — | sin dato (2026-10-28) |
| PRY-204-R2 | Riesgo (no registrado formalmente) | El proveedor podría no llegar con el equipo completo para la siguiente fase | — | — | — | — | dicho 2026-10-28 |
| PRY-204-I1 | Incidencia | Un paro de transportadores detuvo los despachos durante seis días | — | — | — | — | sin dato (2026-10-28) |
| PRY-205-D1 | Dependencia (era riesgo) | Proveedor no ha confirmado la fecha de la última entrega (contrato CT-540) | — | — | — | — | sin dato (2026-10-18) |
| PRY-205-R1 | Riesgo | Concentración del conocimiento en una sola persona | — | — | — | — | sin dato (2026-10-18) |
| PRY-205-I1 | Incidencia | La prueba de exactitud de inventario no alcanzó el valor pactado y se repite | — | — | — | — | sin dato (2026-10-18) |
| PRY-205-I2 | Incidencia | El equipo perdió dos semanas por rotación del jefe de bodega | — | — | — | — | sin dato (2026-10-18) |
| PRY-206-D1 | Dependencia (era riesgo) | Proveedor no ha confirmado la fecha de la última entrega | — | — | — | — | sin dato (2026-10-27) |
| PRY-206-R1 | Riesgo | Cambio en la norma de pesos y dimensiones que puede mover el alcance | — | — | — | — | sin dato (2026-10-27) |
| PRY-206-I1 | Incidencia | Hallazgo de seguridad en la operación de montacargas | — | — | — | — | sin dato (2026-10-27) |
| PRY-206-I2 | Incidencia | La prueba de exactitud de inventario no alcanzó el valor pactado y se repite | — | — | — | — | sin dato (2026-10-27) |
| PRY-207-D1 | Dependencia (era riesgo) | Proveedor no ha confirmado la fecha de la última entrega | — | — | — | — | sin dato (2026-10-06) |
| PRY-207-R1 | Riesgo | Paros de transportadores en las vías principales | — | — | — | — | sin dato (2026-10-06) |
| PRY-207-I1 | Incidencia | La prueba de exactitud de inventario no alcanzó el valor pactado y se repite | — | — | — | — | sin dato (2026-10-06) |
| PRY-208-R1 | Riesgo | Concentración del conocimiento en una sola persona | — | — | — | — | sin dato (2026-10-24) |
| PRY-208-I1 | Incidencia | La prueba de exactitud de inventario no alcanzó el valor pactado y se repite | — | — | — | — | sin dato (2026-10-24) |
| PRY-208-I2 | Incidencia | Se reprogramó la llegada de las estanterías por demoras del importador | — | — | — | — | sin dato (2026-10-24) |
| PRY-209-R1 | Riesgo | Concentración del conocimiento en una sola persona | — | — | — | — | sin dato (2026-10-11) |
| PRY-209-I1 | Incidencia (dudosa) | Se ajustó el plan de arranque con el cliente ancla | — | — | — | — | sin dato (2026-10-11) |
| PRY-210-D1 | Dependencia (era riesgo) | Proveedor no ha confirmado la fecha de la última entrega | — | — | — | — | sin dato (2026-10-24) |
| PRY-211-R1 | Riesgo | Temporada alta que no permite detener la operación | — | — | — | — | sin dato (2026-10-27) |
| PRY-211-R2 | Riesgo | Concentración del conocimiento en una sola persona | — | — | — | — | sin dato (2026-10-27) |
| PRY-211-I1 | Incidencia | La prueba de exactitud de inventario no alcanzó el valor pactado y se repite | — | — | — | — | sin dato (2026-10-27) |

Los ids (D1, R1, I1…) los asigné yo para esta salida; no vienen de los documentos.

### Después

¿Subo a comité lo de «Necesitan decisión ahora», con la decisión formulada para cada fila? ¿Propongo doliente por ítem? Solo propongo: el gerente de cada proyecto como candidato, para que confirme. Comité semanal siguiente: 2026-10-31.

### Lo que esta corrida no sabe

- No sé quién es doliente de nada: ninguna fuente lo dice.
- No sé si los textos repetidos entre proyectos son un mismo hecho o plantilla.
- No sé qué se habló fuera de los documentos.
- No pude buscar riesgos no registrados en PRY-203 ni en PRY-207 a 211: no hay minutas.
- Criterio generado por un agente: puede equivocarse; la verificación contra las citas es tuya.
