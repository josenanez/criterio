# Corrida del 2026-10-28 · project-history

13 proyectos · 47 s · 49 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 16 |
| `commitment_overdue` | 9 |
| `declared_vs_evidence` | 7 |
| `progress_vs_plan` | 5 |
| `commitment_undated` | 3 |
| `commitment_rescheduled` | 3 |
| `variance_time` | 2 |
| `silent` | 2 |
| `change_without_baseline` | 1 |
| `rebaseline_unauthorized` | 1 |

Historia de PRY-200 sobre 6 documentos (2026-04-12 a 2026-10-27). 1 replanificación (+25 días, 4.9%), sin motivo documentado ni acta de aprobación. No pudo fechar el deslizamiento: hay un solo estado declarado. Sin documentos en 2026-T3.

Contra la corrida del 2026-10-28: +0 hallazgos.

## Lo que produjo

## Historia · PRY-200 Centro de distribución del norte · 2026-04-12 a 2026-10-27

**Leí:** 6 documentos entre 2026-04-12 y 2026-10-27
**Trimestres sin un solo documento:** 2026-T3 (julio a septiembre). Entre el cronograma v1 (2026-04-12) y la solicitud CC-01 (2026-10-19) no hay ningún documento: seis meses sin rastro.

*(Términos vigentes: v1.3, aceptados por José Francisco Ñáñez el 2026-10-28; no hizo falta registrarlos de nuevo.)*

### En una línea
El proyecto arrancó el 2026-04-12 con un acta y un cronograma v1 de cierre 2027-09-14, y no vuelve a dejar documentos hasta el 2026-10-19, cuando una solicitud de cambio (CC-01) pide +25 días y 50.000.000 COP. El 2026-10-27 aparecen a la vez un cronograma v2 (cierre 2027-10-09) y un informe de avance que declara Rojo con 76% de avance, mientras el plan solo sustenta entre 25% y 50%. Toda la historia visible ocurre en los últimos diez días; lo anterior es un vacío, no una calma.

### Las cuatro cifras
| Replanificaciones | Atraso acumulado vs. original | Meses declarando sin sustento | Cambios de gobierno |
|---|---|---|---|
| 1 | 25 días (4.9%) | No calculable: hay un solo estado declarado (2026-10-27); falta la serie de informes anteriores | 0 detectados |

### Línea de tiempo
| Fecha | Documento | Qué cambió |
|---|---|---|
| 2026-04-12 | 00-gobierno/2026-04-12-acta-constitucion.md | Se aprueba el proyecto: 1.200.000.000 COP, inicio 2026-04-22, cierre 2027-09-14. Patrocinadora Diana Molina, gerente Gustavo Neira, Comité de Operaciones. Alcance escrito como "Componente 1, 2, 3"; dependencias: "ninguna declarada" |
| 2026-04-12 | 10-plan/2026-04-12-cronograma-v1.xlsx | Línea base v1: 4 hitos, el último (Pruebas con carga real) el 2027-09-14 |
| 2026-10-19 | 20-seguimiento/2026-10-19-solicitud-cambio-cc-01.md | Gustavo Neira pide ampliación de alcance: +25 días sobre la línea base vigente y +50.000.000 COP. Dice "Autorizada por el comité", sin fecha ni nombre del comité |
| 2026-10-24 | 30-reuniones/2026-10-24-comite-semanal.docx | Comité registra dos compromisos: Camilo Beltrán (punto 15, para 2026-10-02) y Rubén Cárdenas (punto 5, para 2026-11-02). El tema "Avance" no trae contenido |
| 2026-10-27 | 10-plan/2026-10-27-cronograma-v2.xml | Línea base v2: "Pruebas con carga real" pasa de 2027-09-14 a 2027-10-09. Los demás hitos no se mueven |
| 2026-10-27 | 20-seguimiento/2026-10-27-informe-avance.pdf | Estado declarado Rojo, avance 76%. Cita un paro de transportadores (6 días) y dos semanas perdidas por rotación del jefe de bodega. Presupuesto: comprometido 356.719.796, ejecutado 567.287.101, proyección 1.142.507.560 |

### Replanificaciones
| Nº | Fecha | Fecha de cierre nueva | Motivo declarado | Documento que la aprobó |
|---|---|---|---|---|
| 1 | 2026-10-27 (fecha del cronograma v2) | 2027-10-09 (desde 2027-09-14; +25 días) | Sin motivo documentado en el cronograma v2. La CC-01 pide los mismos +25 días por "ampliación de alcance", pero ningún documento une una con la otra | CC-01 dice "autorizada por el comité" sin fecha ni comité nombrado; no hay acta que lo apruebe |

Los 25 días coinciden con los de la CC-01, de modo que el atraso no autorizado calculado es 0 días. Lo que falta es la constancia de la autorización, no el cuadre de los días. El informe del 2026-10-27 habla del paro y de la rotación, pero no los presenta como causa del cambio de fecha; esa relación no se afirma aquí.

### Gobierno
| Fecha | Qué cambió | Documento |
|---|---|---|
| — | Sin cambios de patrocinador, gerente ni comité en los documentos leídos. Diana Molina y Gustavo Neira figuran en el acta (2026-04-12) y en el comité (2026-10-24) | — |

Hay un hueco de gobierno distinto a un cambio: la ficha no tiene autoridad ni fase del proyecto (no aparecen en ningún documento).

### Compromisos que se repitieron
| Doliente | Qué | Veces | Fechas prometidas |
|---|---|---|---|
| Ninguno se repitió | — | — | — |

Un compromiso sí está vencido sin evidencia: Camilo Beltrán, "Entregar el punto 15", prometido para 2026-10-02, 26 días vencido al 2026-10-28. La fecha es anterior a la del comité donde se registró (2026-10-24) y no hay acta de recibo. El de Rubén Cárdenas (2026-11-02) sigue abierto.

### Desde cuándo lo declarado no se sostiene
No se puede fechar un deslizamiento: solo existe un estado declarado (2026-10-27) y ningún informe anterior. Lo que sí se ve en esa fecha:
- Primer hito sin evidencia: "Diseño de la operación aprobado", previsto para 2026-08-27 y marcado cerrado en el cronograma, sin documento de aprobación. Lleva 62 días así.
- Avance declarado 76% frente a 1 de 4 hitos cerrados (el plan sustenta entre 25% y 50%): diferencia de 26 puntos hacia arriba.
- Presupuesto: ejecutado 47.3% y comprometido 29.7% del aprobado; la proyección al cierre (1.142.507.560) queda 4.8% por debajo del aprobado. El presupuesto aprobado sigue en 1.200.000.000: la CC-01 agrega 50.000.000 COP y ningún documento actualiza esa cifra.
- Se declaró Rojo, de modo que lo declarado no esconde el problema; lo que no cuadra es el 76%.

### Lecciones ancladas a un hecho
- **Hecho:** no hay un solo documento entre 2026-04-12 y 2026-10-19. **Efecto:** la historia del proyecto en ese lapso no se puede reconstruir y el cierre del hito de diseño (2026-08-27) quedó sin respaldo.
- **Hecho:** la CC-01 (2026-10-19) dice "autorizada por el comité" sin fecha ni nombre, y el cronograma v2 es de 2026-10-27. **Efecto:** el cambio de línea base existe en un archivo, pero su aprobación no se puede verificar.
- **Hecho:** el compromiso de Camilo Beltrán (vence 2026-10-02) se registró el 2026-10-24, 22 días después de su fecha. **Efecto:** nació vencido; el comité lo anotó cuando ya no se podía cumplir a tiempo.
- **Hecho:** el acta de constitución tiene alcance "Componente 1, 2, 3", exclusiones genéricas y "ninguna dependencia". **Efecto:** la CC-01 amplía un alcance que nunca se describió, así que no hay con qué medir lo que se amplió.

### Lo que no sé
- La serie de informes anteriores al 2026-10-27, que es lo único que fecharía el deslizamiento.
- Quién autorizó la CC-01 y cuándo.
- Si el paro y la rotación del informe motivaron la replanificación.

### Después
La historia da para una conversación con datos y no atribuye intención: que el 76% no tenga sustento no dice que alguien lo inflara. Si quiere, la llevo al comité (hay una decisión pendiente: ratificar o no la CC-01 con acta) o al cierre del proyecto.

*Pie de rigor: borrador de trabajo; cada dato cita su documento en la ficha `estado/records/PRY-200.json`. Las cifras derivadas salen de `portafolio.py compute` (2026-10-28). La verificación es suya.*
