**Fuente:** fichas de `estado/records`, recalculadas con `portafolio.py compute` al 2026-10-28 (13 proyectos, 6 productos). Términos vigentes (v0.12.1), aceptados por José Francisco Ñáñez el 2026-10-28.

## Productos al 2026-10-28 — «entregas en el día»

El producto **entregas en el día** tiene un solo proyecto (PRY-202). La vista por producto no agrega nada sobre la ficha del proyecto, así que no armo la sección de grupo: va el proyecto tal cual.

| Producto | Proyectos | Con alertas | Fecha más tardía | Aprobado | Comprometido |
|---|---|---|---|---|---|
| entregas en el día | 1 (PRY-202) | 1 de 1 (6 alertas) | 2026-09-11, ya vencida hace 47 días | COP 9.500.000.000 | COP 2.718.494.817 |

### entregas en el día
**Proyectos:** PRY-202 Flota eléctrica de última milla.

**Lo que hay que ver:**
- **Avance declarado vs. plan:** declara 80 %. Los cuatro hitos del plan están marcados como cumplidos y la curva del plan para hoy sostiene 100 %. Hay 20 puntos de diferencia, con el avance por debajo del plan.
- **Hitos «cumplidos» sin evidencia:** los cuatro. Ninguno tiene documento de recibo en la carpeta:
  - Diseño de la operación aprobado (vencía 2025-10-31, hace 362 días)
  - Permisos de operación obtenidos (2026-02-13, hace 257 días)
  - Adecuación de la bodega terminada (2026-05-29, hace 152 días)
  - Pruebas con carga real (2026-09-11, hace 47 días)
- **Compromiso vencido:** Liliana Torres, «Entregar el punto 13», vencía el 2026-10-18 (10 días). Sale del acta 2026-10-22-comite-semanal.md.
- **Lo que declara el gerente:** amarillo, al 2026-10-25 (informe de avance en PDF). El informe no da cuenta de las tres señales anteriores.
- **Contradicción interna sin resolver:** la fecha de fin del plan (2026-09-11) ya pasó, el proyecto declara 80 % y todos sus hitos figuran cumplidos. Las dos cosas no pueden ser ciertas a la vez. No hay línea base nueva ni solicitud de cambio que explique la diferencia (0 replanificaciones, 0 cambios).
- **Dinero (las cuatro cifras están):**
  - Aprobado: COP 9.500.000.000
  - Ejecutado: COP 5.644.787.990 (59,4 %)
  - Comprometido: COP 2.718.494.817 (28,6 %)
  - Proyección: COP 9.926.714.164 (4,5 % sobre lo aprobado, bajo el umbral de 10 %)
  - Disponible real: COP 6.781.505.183
  - Ojo: lo ejecutado sube a 59,4 % mientras el avance declarado es 80 % y el plan ya debería estar cerrado.
- **Datos de ficha con más de 12 meses:** 12 campos de identidad y plan provienen del documento del 2025-07-08 (15 meses). Faltan `identity.authority` e `identity.phase`.

**Dependencias internas:** ninguna, porque es un solo proyecto. Tampoco hay dependencias declaradas con otros productos.

**Fecha comprometida del producto:** 2026-09-11, del único proyecto (PRY-202). No hay base para decir cuándo termina de verdad: sin evidencia en los cuatro hitos, no se sabe cuál es el estado real.

### Proyectos sin producto declarado
Siete de los 13 proyectos no declaran producto. La consecuencia es que nadie puede responder por el conjunto al que sirven, y no entran en ninguna vista por producto. El cálculo no entrega el área dueña de estos proyectos, así que no la escribo.

| Proyecto | Área dueña |
|---|---|
| PRY-201 Sistema de gestión de bodegas | no consta en el cálculo |
| PRY-203 Ruteo dinámico de vehículos | no consta en el cálculo |
| PRY-205 Seguimiento satelital de la flota | no consta en el cálculo |
| PRY-206 Clasificadora automática de paquetes | no consta en el cálculo |
| PRY-207 Portal de clientes con trazabilidad | no consta en el cálculo |
| PRY-209 Consolidación de cargas regionales | no consta en el cálculo |
| PRY-211 Facturación electrónica de fletes | no consta en el cálculo |

Además, el producto de PRY-199 está declarado como «PRD-299», un código y no un nombre. Conviene confirmar si corresponde a un producto real.

## Pie de rigor
- Toda cifra sale de `portafolio.py compute` del 2026-10-28.
- No leí los documentos fuente de nuevo en esta corrida. Dependo de lo que dicen las fichas, y la verificación contra los documentos citados es de quien decide.
- No sé: si hay evidencia de recibo de los hitos fuera de la carpeta, qué pasó en el proyecto después del informe del 2026-10-25, y el área dueña de los siete proyectos sin producto.
- Las fichas del 2025-07-08 no distinguen evidencia de declaración (15 fuentes sin marcar), así que la solidez de los datos de identidad y plan es baja.
- Como el producto tiene un solo proyecto, no hay decisión de comité de producto que proponer. La que sí hace falta es del proyecto: que PRY-202 sustente sus hitos o reconozca el atraso.
