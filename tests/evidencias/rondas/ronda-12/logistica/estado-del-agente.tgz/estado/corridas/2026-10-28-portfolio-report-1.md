# Corrida del 2026-10-28 · portfolio-report

13 proyectos · 74 documentos, 0 releídos y 74 sin cambio · 18 s · 49 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 16 |
| `commitment_overdue` | 9 |
| `declared_vs_evidence` | 7 |
| `progress_vs_plan` | 5 |
| `commitment_undated` | 3 |
| `commitment_rescheduled` | 3 |
| `variance_time` | 2 |
| `silent` | 2 |
| `change_without_baseline` | 1 |
| `rebaseline_unauthorized` | 1 |

El informe quedó en `/home/claude/r12/logistica/espacio/reportes/index.html`.

7 verdes contradichos; PRY-204 con 13 señales; PRY-207 y PRY-209 en silencio

Contra la corrida del 2026-10-28: +0 hallazgos.

## Lo que produjo

# Portafolio — 2026-10-28
13 proyectos · 10 con hallazgos (49 señales) · fichas de `estado/records/`, última instantánea 2026-10-28

Términos v1.3 vigentes (aceptados por José Francisco Ñáñez, 2026-10-28). Formato `html`: informe armado por `informe.py`, no pegado aquí.

## Qué cambió desde 2026-10-28
Sin cambios desde la corrida anterior (la instantánea previa es de hoy; 0 diferencias).

## Lo que cruzó umbral (salida de `compute`)
- Verdes contradichos por la evidencia: 7 (PRY-201, 204, 205, 206, 207, 208, 209).
- En silencio (> 15 días): PRY-207 (22 días), PRY-209 (17 días).
- Desviación de tiempo > 10 %: PRY-201 (+40 días vs original), PRY-206 (+94 días; replanificación sin autorización).
- Cambio sin línea base: PRY-203.
- PRY-204 concentra 13 señales: 5 compromisos vencidos, 2 sin fecha, 3 reprogramados.
- Hitos cumplidos sin evidencia: PRY-200, 201, 202 (4), 204, 205 (2), 206, 207 (3), 208 (2).
- Avance inferior al plan: PRY-200, 202, 204, 207, 208.
- Sin señales: PRY-199, 210, 211.
- Ningún proyecto tiene autoridad de aprobación registrada (13 de 13).
- Proyectos sin producto asignado: PRY-201, 203, 205, 206, 207, 209, 211.

## Dónde quedó
`/home/claude/r12/logistica/espacio/reportes` — 23 páginas. `index.html` (por campo, con cadena de evidencia; para quien actúa) y `decisiones.html` (por decisión; para el patrocinador), más una página por proyecto. El PDF sale de imprimir el HTML.

## Necesito que confirmes
No se generó la confirmación mensual en esta corrida de prueba sin interfaz.
