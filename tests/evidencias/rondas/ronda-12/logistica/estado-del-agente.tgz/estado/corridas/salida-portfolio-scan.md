## Barrido — 2026-10-28

Términos vigentes (v1.3, familia 0.12.1), aceptados por José Francisco Ñáñez el 2026-10-28; no hubo que volver a registrarlos.

**Documentos:** 74 en la carpeta · 39 leídos · 35 sin cambio desde la corrida anterior · 0 ilegibles
**Proyectos:** 13 en la carpeta · 10 releídos y con ficha nueva en esta corrida · 3 sin cambio (PRY-200, PRY-204, PRY-206 conservan la ficha anterior) · 0 sin carpeta propia

Plan ejecutado tal cual: 1 lote de 10 proyectos, uno tras otro en esta conversación (`workers: 1`), sin subagentes. 39 de 74 documentos leídos; nada diferido. Cada ficha se escribió y se selló al terminar su proyecto.

### Nuevos
| Proyecto | Documentos | Campos encontrados | Campos sin dato |
|---|---|---|---|
| PRY-199 Pintura de la portería | 6 | identidad, plan, 5 hitos, presupuesto, contrato CT-199 (3 entregables), 1 compromiso | autoridad, fase, facturado |
| PRY-201 Sistema de gestión de bodegas | 6 | identidad, 2 líneas base, 3 hitos, presupuesto, CC-01, 1 compromiso | producto («No aplica»), autoridad, fase |
| PRY-202 Flota eléctrica de última milla | 4 | identidad, plan, 4 hitos, presupuesto, 2 riesgos, 1 compromiso | autoridad, fase |
| PRY-203 Ruteo dinámico de vehículos | 3 | identidad, presupuesto, CC-01 | producto («No aplica»), autoridad, fase, hitos (no hay cronograma) |
| PRY-205 Seguimiento satelital de la flota | 7 | identidad, plan, 5 hitos, presupuesto, contrato CT-540, factura, 2 compromisos | producto («No aplica»), autoridad, fase |
| PRY-207 Portal de clientes con trazabilidad | 3 | identidad, plan, 3 hitos, presupuesto | producto («No aplica»), autoridad, fase |
| PRY-208 Cadena de frío para farmacéuticos | 4 | identidad, plan, 4 hitos, presupuesto | autoridad, fase |
| PRY-209 Consolidación de cargas regionales | 2 | identidad, presupuesto, riesgo | producto («No aplica»), autoridad, fase, hitos |
| PRY-210 Puntos de recogida en estaciones | 2 | identidad, presupuesto, riesgo | autoridad, fase, hitos |
| PRY-211 Facturación electrónica de fletes | 2 | identidad, presupuesto, 2 riesgos | producto («No aplica»), autoridad, fase, hitos |

(Son «nuevos» porque ninguno tenía ficha en `estado/records/`; las únicas fichas previas eran las de PRY-200, PRY-204 y PRY-206.)

### Actualizados
| Proyecto | Qué cambió | Fuente |
|---|---|---|
| — | Ninguno: PRY-200, PRY-204 y PRY-206 no tienen documentos nuevos ni cambiados, así que no se abrieron. | plan de lectura |

### Lo que hay que mirar (contradicciones y vacíos de prueba)
- **Hitos declarados cerrados sin acta que lo pruebe** (la declaración se conserva, la prueba falta): PRY-201 (2 de 3), PRY-202 (4 de 4), PRY-205 (2 de 5), PRY-207 (3 de 3), PRY-208 (2 de 4). Con acta: PRY-199 («Diseño de la operación aprobado») y PRY-208 («Permisos de operación obtenidos»).
- **PRY-207:** declara verde y 24 % de avance, pero su cronograma tiene sus 3 hitos al 100 % cerrados y la fecha de cierre (2026-08-21) ya pasó; ninguna nueva fecha ni solicitud de cambio.
- **PRY-202:** cierre comprometido 2026-09-11 vencido, sigue en 80 % y amarillo, sin cambio de línea base. Ejecutado (5.644.787.990) supera lo comprometido (2.718.494.817) según el propio informe.
- **PRY-210 y PRY-211:** cierre comprometido (2026-10-15 y 2026-09-21) ya pasó; ambos siguen declarando avance parcial (49 % y 69 %), sin cronograma ni cambio registrado.
- **PRY-201:** CC-01 (+40 días, +80 M COP, «autorizada por el comité» sin nombrar cuál) está reflejada en el cronograma v2 (cierre 2026-10-28 → 2026-12-07). El presupuesto aprobado sigue en 800 M COP en el informe del 23-oct; el costo adicional no aparece incorporado.
- **PRY-203:** CC-01 aprobada (+40 días, +80 M COP) pero no hay cronograma que la refleje; la fecha vigente sigue siendo la del acta (2026-12-28).
- **PRY-199:** el informe declara comprometido 1.080 M COP; el único contrato de la carpeta (CT-199) suma 432 M COP, todos sus entregables pendientes. El contrato es de estanterías, vehículos eléctricos e ingeniería, que no corresponde a una pintura de portería. Dato a confirmar con el gerente.
- **PRY-205:** una factura (FV-1540, 79.548.107 COP) contra un entregable con acta de recibo (Suministro de estanterías): consistente. Los otros dos entregables no están facturados.
- **Compromisos vencidos sin evidencia:** PRY-202 Liliana Torres (punto 13, 2026-10-18); PRY-205 Felipe Arango (punto 26, 2026-10-21). En ambos la fecha prometida es anterior a la del comité que la registró. Abiertos: PRY-199 Carlos Peña (2026-11-17), PRY-201 Paula Céspedes (2026-11-13), PRY-205 Beatriz Cuéllar (2026-10-23). Ninguno de los responsables de estos compromisos figura entre los asistentes de su comité.
- **Campos sin dato en las 10 fichas:** «autoridad» y «fase». «Producto» queda vacío donde el acta dice «No aplica» (PRY-201, 203, 205, 207, 209, 211).
- **Personas en varios proyectos:** Sandra Gil gerencia PRY-202 y PRY-208; Andrés Lozano, PRY-199 y PRY-201.

### No pude leer
| Archivo | Por qué |
|---|---|
| (ninguno) | El inventario marcó 5 cronogramas `.xml` como «formato que no se lee sin instalar algo» (PRY-200 v2, PRY-204 v1, PRY-206 v1 y v2, PRY-207 v1). `texto.py` los convirtió todos (0 ilegibles). Solo el de PRY-207 estaba en el plan y lo leí; los otros cuatro pertenecen a proyectos sin cambio y no se releyeron. |

### Movidos desde entrada/
| Archivo | A qué proyecto | Por qué |
|---|---|---|
| (ninguno) | — | No existe carpeta `entrada/` en `documentos/`. |

### Pendientes de clasificar
| Archivo | Por qué no pude decidir |
|---|---|
| `PRY-204-cross-docking-en-el-puerto/2026-10-28-notas-reunion.txt` | Está suelto en la raíz del proyecto, no en `30-reuniones/`. Pertenece a PRY-204 sin ambigüedad, pero ese proyecto no entró en este plan (la ficha y el archivo ya constaban como vistos) y no lo moví. |

### Otras notas
- PRY-204 tiene `ficha-pm.json` (ficha de su gerente) y su propio estado; no se tocó.
- Las cuentas (desviaciones, vencimientos, silencio) las calcula el script en `snapshot` y en el informe, no esta ficha.
