# Corrida del 2026-10-28 · vendor-tracking

13 proyectos · 30 s · 49 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 16 |
| `commitment_overdue` | 9 |
| `declared_vs_evidence` | 7 |
| `progress_vs_plan` | 5 |
| `commitment_undated` | 3 |
| `commitment_rescheduled` | 3 |
| `variance_time` | 2 |
| `silent` | 2 |
| `change_without_baseline` | 1 |
| `rebaseline_unauthorized` | 1 |

Sin contrato ni proveedor en la carpeta de PRY-207: no se hizo el cruce contrato/entrega/factura. Solo consta un riesgo del informe 2026-10-06 (proveedor sin fecha de última entrega). Dicho como sin dato: contrato, vigencia, preaviso, facturas, actas de recibo.

Contra la corrida del 2026-10-28: +0 hallazgos.

## Lo que produjo

**Sale de:** la ficha `estado/records/PRY-207.json`, el acta de constitución (`00-gobierno/2025-06-26-acta-constitucion.docx`), el cronograma v1 (`10-plan/2025-06-26-cronograma-v1.xml`) y el informe de avance del 2026-10-06 (`20-seguimiento/2026-10-06-informe-avance.pdf`), más la salida de `portafolio.py compute` al 2026-10-28. Términos vigentes (v1.3, aceptados por José Francisco Ñáñez el 2026-10-28).

## Proveedores — PRY-207 Portal de clientes con trazabilidad al 2026-10-28

**No se puede hacer el cruce contrato / entrega / factura. El contrato de ningún proveedor está en la carpeta del proyecto.** Sin el contrato, cualquier lista de entregables sería una lista de supuestos, así que no la armo.

### Qué hay en la carpeta
| Documento | Qué dice de proveedores |
|---|---|
| Acta de constitución (2025-06-26) | Nada. Dependencias declaradas: "Ninguna declarada". |
| Cronograma v1 (2025-06-26) | Solo 3 hitos del proyecto; ninguno es un entregable de proveedor. |
| Informe de avance (2026-10-06) | Una línea, en riesgos abiertos: "El proveedor no ha confirmado la fecha de la última entrega". No nombra al proveedor, ni el contrato, ni el entregable. |

El script confirma lo mismo: `vendors` está vacío para PRY-207, y `commitments_overdue`, `commitments_undated` y `dependencies` también.

### Dónde no cuadra
Con una sola fuente no hay cruce. Lo único que se puede decir es esto:

| Qué | Dice el contrato | Dice la evidencia | Fuentes |
|---|---|---|---|
| Existencia de un proveedor con entregas pendientes | Sin dato: no hay contrato | El informe admite una "última entrega" sin fecha confirmada | informe de avance 2026-10-06; acta sin dependencias |
| Dependencias | Sin dato | El acta declara "ninguna", el informe reporta un riesgo por un proveedor | acta de constitución; informe de avance |

La contradicción es que el acta no declara dependencias y el informe de avance sí depende de una entrega de un proveedor.

### Sin evidencia de recibo
No hay entregables de proveedor registrados, así que no hay nada que marcar. Lo más cercano son los tres hitos del proyecto que el script marca como `milestone_met_without_evidence`. Son hitos del proyecto, no entregables contractuales de un proveedor, y no puedo atribuirlos a ninguno:

| Hito | Marcado como | Vencimiento | Días desde entonces |
|---|---|---|---|
| Diseño de la operación aprobado | met (sin evidencia) | 2025-11-20 | 342 |
| Permisos de operación obtenidos | met (sin evidencia) | 2026-04-06 | 205 |
| Adecuación de la bodega terminada | met (sin evidencia) | 2026-08-21 | 68 |

### Compromisos del proveedor vencidos
Sin dato. No hay minutas ni reuniones con el proveedor en la carpeta; `commitments_overdue` está vacío.

### Contexto que sí calculó el script
- Presupuesto en COP: aprobado 9.500.000.000; comprometido 6.597.325.946 (69,4 %); ejecutado 3.638.979.753 (38,3 %); proyección 9.899.993.006 (4,2 % sobre lo aprobado); disponible real 2.902.674.054. El informe no dice cuánto de lo comprometido es del proveedor.
- Estado declarado: verde, avance 24 %, al 2026-10-06. El script marca la declaración como contradicha por tres señales: `silent` (22 días sin documentos nuevos, desde 2026-10-06), `progress_vs_plan` (el plan sustenta 100 % frente al 24 % declarado, brecha de 76,0 puntos) y `milestone_met_without_evidence`.
- La fecha de cierre comprometida (2026-08-21) ya pasó. Con 3 de 3 hitos en estado "cumplido" sin evidencia, el avance de 24 % no cuadra con el cronograma.

### Sin dato
- **Contrato(s) del proveedor:** no están en la carpeta. No tengo vigencia, fecha de terminación, renovación automática ni preaviso de no renovación. No puedo decir si hay un preaviso por vencer; si lo hay, hoy no lo veo.
- **Identidad del proveedor** y el entregable de "la última entrega".
- **Facturas y montos de proveedor:** ninguno declarado. No puedo levantar `vendor_invoiced_without_delivery` ni ninguna otra señal de factura adelantada.
- **Actas de recibo o correos de aceptación:** ninguno.

### Qué sugiero
1. Pedir a Jorge Medina (gerente) el contrato del proveedor, sus anexos y el acta de recibo de lo ya entregado, y dejarlos en `00-gobierno`.
2. Pedir la fecha de la "última entrega" y qué factura se emitió contra ella.
3. Cuando el contrato esté, repetir `/vendor-tracking PRY-207`. Mientras tanto, llevar a comité lo que sí está documentado: informe en verde con 22 días de silencio, tres hitos sin evidencia y la fecha de cierre ya vencida.

*Rigor: lo anterior sale solo de los tres documentos citados y del cálculo del script. No sé lo que se haya hablado fuera de ellos. Es un borrador de trabajo y la verificación contra los originales es suya.*
