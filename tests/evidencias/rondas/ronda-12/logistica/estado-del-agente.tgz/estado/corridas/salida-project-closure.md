Fuente: ficha `estado/records/PRY-202.json`, salida de `portafolio.py compute` (corte 2026-10-28) y los documentos de PRY-202: acta de constitución (2025-07-08), cronograma v1 (2025-07-08), informe de avance (2026-10-25) y comité semanal (2026-10-22). Términos v1.3 vigentes, aceptados por José Francisco Ñáñez el 2026-10-28.

## Cierre — PRY-202 Flota eléctrica de última milla — 2026-10-28

**Conclusión previa: el proyecto no está en condiciones de cerrarse contra su criterio de éxito.** Nadie lo ha declarado terminado: el último informe (2026-10-25, Sandra Gil) lo reporta en **Amarillo, con 80 % de avance**, y la fecha de cierre comprometida (2026-09-11) pasó hace 47 días. Lo que sigue es el cierre posible con la evidencia que existe, no un acta de cierre.

### Contra lo comprometido
**Criterio de éxito:** "Flota eléctrica de última milla en producción y medido." (acta de constitución, 2025-07-08). Está declarado, pero no tiene umbral, métrica ni fecha de medición: no dice qué es "medido".
**Se cumplió:** **no se puede determinar.** No hay ningún documento que muestre la flota en producción ni una medición. El informe de avance solo dice que se acordó con operaciones *cómo* se mide el nivel de servicio de cada ruta; es decir, la medición aún se estaba definiendo el 2026-10-25.

| Entregable comprometido | Estado | Evidencia |
|---|---|---|
| Componente 1 | Sin detalle en el acta | Ninguna |
| Componente 2 | Sin detalle en el acta | Ninguna |
| Componente 3 | Sin detalle en el acta | Ninguna |
| Hito: Diseño de la operación aprobado (2025-10-31) | Declarado cumplido, sin evidencia | Ningún acta de recibo |
| Hito: Permisos de operación obtenidos (2026-02-13) | Declarado cumplido, sin evidencia | Ningún acta de recibo |
| Hito: Adecuación de la bodega terminada (2026-05-29) | Declarado cumplido, sin evidencia | Ningún acta de recibo |
| Hito: Pruebas con carga real (2026-09-11) | Declarado cumplido, sin evidencia | Ningún acta de recibo |

Hallazgo: los 4 hitos del cronograma figuran como cumplidos (4 de 4, el plan respalda 100 %) y aun así el informe declara 80 %. La diferencia es de 20.0 puntos. O el avance está subdeclarado o los hitos no equivalen a lo que se pactó; con estos documentos no se puede decir cuál. Los alcances "Componente 1, 2 y 3" no permiten contrastar qué se entregó.

### Fuera de alcance final
| Qué quedó fuera | Decidido por | Cuándo |
|---|---|---|
| Del acta: "Lo que otro proyecto cubre" (no nombra proyecto) | Acta de constitución | 2025-07-08 |
| Recortes durante la ejecución | Sin registro: 0 solicitudes de cambio en la ficha | — |

No hay recorte de alcance registrado. Tampoco hay constancia de que no haya ocurrido: la carpeta no tiene control de cambios.

### Números finales
| | Original | Vigente | Final | Desviación vs original |
|---|---|---|---|---|
| Fecha de cierre | 2026-09-11 | 2026-09-11 | Sin cierre declarado | 0 días contra la línea base; 47 días desde la fecha comprometida sin cierre |
| Presupuesto (COP) | 9.500.000.000 | 9.500.000.000 | Sin cierre; proyección 9.926.714.164 | Proyección 4.5 % sobre el aprobado |

Replanificaciones: **0**. Hay una sola línea base (v1, aprobada 2025-07-08).

Presupuesto del informe del 2026-10-25: ejecutado 5.644.787.990 (59.4 % del aprobado), comprometido 2.718.494.817 (28.6 %), disponible real 6.781.505.183. Nota: la desviación de fecha de 0 días no significa que se cumplió el plazo; significa que el cronograma nunca se replanificó, pese a que la fecha venció. Eso contradice el estado "Amarillo" con 80 % y una proyección de gasto que aún llega a 9.926.714.164.

### RAID al cierre
**Materializados:** una incidencia: un paro de transportadores detuvo los despachos durante seis días (informe 2026-10-25). Sin responsable ni fecha de inicio registrados.
**No materializados:** ninguno se puede afirmar. Los dos riesgos abiertos no tienen probabilidad, impacto, responsable ni fecha: concentración del conocimiento en una sola persona; cambio en la norma de pesos y dimensiones que puede mover el alcance.
**Abiertos, con doliente:** ninguno tiene doliente. Aparte, un compromiso vencido: "Entregar el punto 13", Liliana Torres, para 2026-10-18, 10 días vencido; se registró en el comité del 2026-10-22, que es posterior a la fecha prometida, no hay acta de recibo y Liliana Torres no figura entre los asistentes. Lo que queda abierto sin doliente no está cerrado.

### Lecciones
No se registra ninguna. Los documentos no permiten anclar un aprendizaje a un hecho, fecha y efecto, y una lección genérica sería un lugar común. Lo que sí está documentado, sin efecto medible aún: el paro de seis días (sin fecha) y los hitos que se reportaron cumplidos sin acta de recibo.

### Sin dato
- Declaración de terminación del proyecto y quién la hace.
- Evidencia de recibo de los 4 hitos.
- Qué es "medido" en el criterio de éxito.
- Detalle de los Componentes 1, 2 y 3.
- Fecha del paro de transportadores y su efecto en el cronograma.
- Fecha del concepto de la autoridad aduanera sobre la bodega y su resultado.
- Responsable de los riesgos y de la incidencia.
- Fase y autoridad del proyecto (campos no encontrados en la ficha).
- Presupuesto final: solo hay ejecutado parcial y proyección.

### Después
No ofrezco mover la carpeta a `archivo/` ni congelar la ficha: el proyecto no está declarado terminado y sigue en el barrido. Condición para reabrir el cierre: que Sandra Gil o Laura Vélez declaren la terminación y aporten actas de recibo de los hitos y la medición del criterio de éxito.

---
**Pie de rigor.** Borrador de trabajo, no decisión ni asesoría; Criterio solo ve los documentos indicados y puede equivocarse. Cada dato lleva su fuente arriba; la verificación es de quien lo usa. Cifras derivadas copiadas de `portafolio.py compute`.
