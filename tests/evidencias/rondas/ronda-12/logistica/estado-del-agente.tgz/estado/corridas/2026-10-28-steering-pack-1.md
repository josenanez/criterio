# Corrida del 2026-10-28 · steering-pack

13 proyectos · 103 s · 49 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 16 |
| `commitment_overdue` | 9 |
| `declared_vs_evidence` | 7 |
| `progress_vs_plan` | 5 |
| `commitment_undated` | 3 |
| `commitment_rescheduled` | 3 |
| `variance_time` | 2 |
| `silent` | 2 |
| `change_without_baseline` | 1 |
| `rebaseline_unauthorized` | 1 |

Paquete de 7 decisiones, 8 escalamientos y anexo sobre las 13 fichas. No sé: autoridad de cambios (vacía en las 13), quién aprobó cada CC-01, costo de los cambios sin cifra, si los textos repetidos del RAID son un hecho o plantilla, ni qué se decidió en el comité anterior (no hay acta).

Contra la corrida del 2026-10-28: +0 hallazgos.

## Lo que produjo

Cargué las 13 fichas de `estado/records/` (PRY-199 a PRY-211), todas con fecha de corte 2026-10-28, y recalculé con `portafolio.py compute`. Términos vigentes: v1.3, aceptados por José Francisco Ñáñez el 2026-10-28; no hubo que registrarlos de nuevo. Para los cambios y el RAID usé también lo que ya dejaron las corridas de hoy (`salida-change-control.md`, `salida-raid-log.md`). No releí los documentos de los proyectos en esta corrida.

# Comité de proyectos — 2026-10-31 (material preparado el 2026-10-28)
7 decisiones · 8 escalamientos sin decisión asociada · 10 de 13 proyectos con hallazgos (49 señales abiertas)

**Antes de leer las decisiones:** las 13 fichas tienen `identity.authority` vacío (`no_authority: 13`). Ningún documento dice quién aprueba cambios de tiempo o de costo. Por eso la decisión 1 va primero: sin ella, las demás se las lleva el comité que aprobó la línea base de cada proyecto, que en las fichas son cinco distintos (Operaciones, Inversiones, Tecnología, Clientes, Seguridad).

## Decisiones del comité anterior
| Decisión | Fecha | Qué pasó | Estado |
|---|---|---|---|
| Sin dato | — | No hay acta de un comité anterior en las carpetas ni decisiones registradas en las fichas. Las únicas decisiones que aparecen son tres solicitudes de cambio aprobadas (CC-01 de PRY-200, PRY-201 y PRY-203) por «el comité (no se nombra cuál)». | Sin cierre posible |

No puedo decir qué se decidió ni qué se hizo con ello. Es el primer ciclo con este material: el comité decide hoy sin historial.

## Decisiones de hoy

### [1] ¿Quién tiene la facultad de aprobar cambios de tiempo y de costo en cada proyecto, y con qué umbrales?
**Proyecto:** los 13 · **Quién decide:** no se puede determinar con los documentos; lo único comprobable es que cada comité aprobó la línea base de sus proyectos · **Si no se decide hoy:** las decisiones 2, 3 y 5 se toman sin saber si el comité tiene la facultad, y los cambios ya aprobados por «el comité» sin nombre siguen sin autor verificable.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Cada comité declara su autoridad y umbrales por escrito | Sin cambio | Una sesión de declaración | Sin dato |
| B. Un solo comité de portafolio decide todo cambio | Sin cambio | Más cola en un solo punto | Sin dato |
| C. Seguir por defecto con el comité que aprobó la línea base | Sin cambio | Ninguno | Ninguno, y la ausencia de autoridad sigue |
**Recomendación:** A. Es lo que menos cambia y deja el dato donde las fichas lo piden. Con B se cambia la gobernanza de cinco comités por una decisión que el comité no está en posición de verificar hoy.

### [2] PRY-206 — ¿Se aprueba CC-01 (+94 días, 188.000.000 COP adicionales, ampliación de alcance) que hoy está pendiente pero cuya línea base ya se movió?
**Proyecto:** PRY-206 Clasificadora automática de paquetes (gerente y patrocinador: Gustavo Neira) · **Quién decide:** Comité de Tecnología según la ficha, sujeto a la decisión 1 · **Si no se decide hoy:** los 94 días siguen contando como `unauthorized_days: 94` y el proyecto sigue declarado en verde sobre una fecha que nadie aprobó.
Hechos del cálculo: desviación de tiempo contra la original 94 días (17,7 %, umbral 10 %); la línea base se movió 94 días y se autorizaron 0; el hito «Permisos de operación obtenidos» figura cumplido sin evidencia hace 68 días; avance declarado 77 %, el plan sustenta entre 50 y 75 %; disponible real 448.942.641 COP.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar CC-01 | Ampliado | +94 días, cierre 2027-08-16 | +188.000.000 COP sobre 800.000.000 aprobados; el desglose no está en los documentos |
| B. Rechazar y restituir la línea base | Sin ampliación | Vuelve a la fecha original; si el equipo la puede cumplir, sin dato | 0 adicional |
| C. Devolver para sustentar | Sin cambio hasta que se decida | Sigue la desviación sin autorizar | Sin dato |
**Recomendación:** C, con la evidencia del hito de permisos y el desglose de los 188.000.000 COP como condición para volver al comité. Aprobar ahora ratificaría con efecto retroactivo una fecha sin motivo ni costo sustentados; rechazar ahora decide sin saber si la fecha original era viable.

### [3] PRY-203 — ¿Se ratifica CC-01 (+40 días, 80.000.000 COP) y se ordena registrar la línea base nueva?
**Proyecto:** PRY-203 Ruteo dinámico de vehículos (gerente: Elena Duarte; patrocinador: Camilo Beltrán) · **Quién decide:** Comité de Tecnología según la ficha; la solicitud dice aprobada por «el comité (no se nombra cuál)» · **Si no se decide hoy:** el cambio queda aprobado sin línea base: `baseline_moved_days: 0` contra 40 días aprobados, y la desviación del proyecto se mide contra una fecha que ya no es la acordada.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Ratificar y registrar línea base 2 (cierre 2026-12-28) | Ampliado | +40 días | +80.000.000 COP |
| B. Desconocer la aprobación por falta de autor identificable | Sin ampliación | Vuelve a la fecha original | 0 adicional |
**Recomendación:** A, pero solo después de la decisión 1: si el comité no tiene la facultad, la ratificación no vale. La v1 de la línea base no se toca; la nueva se agrega.

### [4] PRY-204 — ¿Se designa un patrocinador o revisor distinto del gerente, y se exige re-declarar el estado, en un proyecto de 18.000.000.000 COP declarado en verde?
**Proyecto:** PRY-204 Cross docking en el puerto (gerente y patrocinadora: Liliana Torres) · **Quién decide:** Comité de Inversiones según la ficha · **Si no se decide hoy:** nadie dentro del proyecto puede escalar lo que el proyecto no resuelve, y 5 compromisos vencidos más 3 reprogramados hasta 6 veces siguen bajo un estado verde.
Hechos del cálculo: 13 señales abiertas; avance declarado 53 %, el plan sustenta entre 75 y 100 % (22 puntos por detrás); 5 compromisos vencidos (de 5 a 29 días); «Enviar el documento 1» reprogramado 6 veces, «Cerrar la prueba 2» 5 veces, «Revisar el anexo 3» 3 veces; 2 compromisos sin fecha; hito «Diseño de la operación aprobado» cumplido sin evidencia hace 258 días; comprometido 9.340.126.765 COP (51,9 %), ejecutado 3.101.575.940 COP (17,2 %). Riesgo dicho en la reunión del 2026-10-28 y no registrado: el proveedor podría no llegar con el equipo completo.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Designar revisor independiente y pedir estado re-declarado con evidencia | Sin cambio | Pocos días de trabajo del revisor; sin dato de cuántos | Sin dato |
| B. Mantener y vigilar con el tablero | Sin cambio | Ninguno | Ninguno |
**Recomendación:** A. El proyecto concentra el mayor presupuesto aprobado del portafolio y el estado declarado no coincide con ninguna de las cifras que lo rodean.

### [5] ¿Qué hacer con los cuatro proyectos cuya fecha de fin ya pasó con avance declarado menor al 100 %: PRY-207, PRY-202, PRY-211 y PRY-210?
**Proyecto:** PRY-207 (fin 2026-08-21, 24 %, 22 días sin informe), PRY-202 (fin 2026-09-11, 80 %), PRY-211 (fin 2026-09-21, 69 %), PRY-210 (fin 2026-10-15, 49 %) · **Quién decide:** comités de Clientes, Inversiones y Tecnología según la ficha de cada uno, sujeto a la decisión 1 · **Si no se decide hoy:** son cuatro atrasos sin solicitud de cambio ni línea base nueva (`replans: 0` en PRY-202 y PRY-207); se acumulan como atraso silencioso.
Dato de PRY-207: declarado verde con 24 %, y el plan sustenta 100 % (76 puntos de brecha); presupuesto 9.500.000.000 COP, comprometido 69,4 %.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Exigir una solicitud de cambio formal por proyecto antes del próximo comité | Sin cambio hasta que se presente | El que cada solicitud declare | El que cada solicitud declare |
| B. Suspender el proyecto hasta que haya fecha sustentada | Detenido | Detenido | Se detiene lo no comprometido; lo comprometido sigue |
| C. Dejar la fecha vencida como está | Sin cambio | Atraso sin autorizar | Sin dato |
**Recomendación:** A para los cuatro; B queda como opción para PRY-207 si el próximo informe no llega, porque es el que lleva 22 días en silencio (umbral 15) y el mayor desfase.

### [6] ¿Quién es el doliente del hallazgo de seguridad en la operación de montacargas (PRY-199 y PRY-206)?
**Proyecto:** PRY-199 Pintura de la portería (incidencia desde 2026-10-26) y PRY-206 (desde 2026-10-27) · **Quién decide:** Comité de Seguridad es el único con ese nombre entre los de las fichas, pero ninguno de los dos proyectos lo tiene como comité; sujeto a la decisión 1 · **Si no se decide hoy:** una incidencia de seguridad sigue abierta sin doliente ni fecha.
No sé si son un mismo hallazgo: los dos textos son casi iguales y los proyectos no se parecen.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Nombrar un doliente único para ambos | Sin cambio | Sin dato | Sin dato |
| B. Un doliente por proyecto (su gerente) | Sin cambio | Sin dato | Sin dato |
**Recomendación:** B hoy y verificar en una semana si es el mismo hallazgo; si lo es, pasa a A. Asignar uno solo sin saberlo es decidir sobre un supuesto.

### [7] ¿Quién es el doliente de los hechos que cruzan proyectos: paro de transportadores, reprogramación de estanterías y dependencia del proveedor?
**Proyecto:** paro de transportadores en 6 proyectos (200, 202, 204 ocurrido; 203, 204, 207 amenaza); reprogramación de estanterías en 4 (199, 201, 203, 208); «el proveedor no ha confirmado la última entrega» en 6 (199, 201, 205, 206, 207, 210) · **Quién decide:** el comité de portafolio, porque ninguno de los proyectos puede resolver lo del otro · **Si no se decide hoy:** cada gerente trata el mismo hecho por su lado y ninguno de los 36 ítems registrados tiene doliente.
Advertencia: el mismo texto exacto en proyectos que no se parecen puede ser un mismo hecho o texto copiado de una plantilla. No pude verificarlo. Si es plantilla, este punto baja a «verificar».
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Un doliente por hecho, con fecha de primera respuesta | Sin cambio | Sin dato | Sin dato |
| B. Verificar primero si es un solo hecho o plantilla y decidir en el siguiente comité | Sin cambio | Una semana | Ninguno |
**Recomendación:** B. La verificación cuesta una semana; asignar doliente sobre texto que puede ser plantilla puede mandar a alguien a resolver un problema que no existe en su proyecto.

## Escalamientos sin decisión asociada
| Proyecto | Qué | Desde cuándo | Qué se necesita |
|---|---|---|---|
| PRY-205 | Se habló de mover 30 días el arranque (2027-08-08 a 2027-09-07) sin solicitud en la carpeta, sin quién la pide ni costo; hitos de diseño y permisos cumplidos sin evidencia (141 y 35 días); 2 compromisos vencidos | Informe 2026-10-18 | Que Ricardo Salas o Mauricio Pérez presenten la solicitud con motivo y cifra de costo; el contrato CT-540 con el proveedor, su vigencia |
| PRY-200 | CC-01 aprobado (+25 días, 50.000.000 COP); declarado rojo, 76 % de avance contra 25–50 % que sustenta el plan; compromiso «Entregar el punto 15» vencido 26 días (Camilo Beltrán) | 2026-10-19 | Que se sustente el avance; que Camilo Beltrán cierre o reprograme el compromiso |
| PRY-201 | CC-01 aprobado (+40 días, 80.000.000 COP); desviación de tiempo 16,3 % contra la original; declarado verde con dos hitos cumplidos sin evidencia (164 y 82 días) | 2026-10-20 | Evidencia de los dos hitos; que el estado se re-declare |
| PRY-208 | Declarado verde, 43 % de avance contra 75–100 % que sustenta el plan (32 puntos); dos hitos cumplidos sin evidencia (130 y 16 días) | Informe 2026-10-24 | Evidencia de los hitos o corregir el estado |
| PRY-209 | 17 días sin informe (umbral 15), declarado verde | Desde 2026-10-11 | Informe de avance |
| PRY-202 | Compromiso «Entregar el punto 13» vencido 10 días (Liliana Torres); cuatro hitos cumplidos sin evidencia; la ficha tiene datos de identidad de hace 15 meses | Comité 2026-10-22 | Evidencia de los hitos; confirmar identidad y presupuesto |
| PRY-205 | Compromisos vencidos: Felipe Arango (7 días) y Beatriz Cuéllar (5 días) | Comité 2026-10-22 | Cierre o reprogramación con fecha |
| PRY-204 y PRY-206 | Compromisos sin fecha: Carlos Peña, Laura Vélez (PRY-204), Jorge Medina (PRY-206) | 2026-09-30 a 2026-10-28 | Una fecha por compromiso |

## Para conocimiento
- PRY-199 Pintura de la portería: sin señales de cálculo; hallazgo de seguridad sin doliente (decisión 6).
- PRY-210 Puntos de recogida: sin señales de cálculo; fin plan 2026-10-15 vencido (decisión 5).
- PRY-211 Facturación electrónica de fletes: amarillo, 69 %; fin plan 2026-09-21 vencido (decisión 5).
- Siete proyectos declaran verde con señales abiertas que el informe no menciona (`green_contradicted: 7`); están en el anexo.

## Anexo
**Estado por proyecto (cifras del cálculo, 2026-10-28).**
| Proyecto | Declarado | Avance declarado | Lo que el plan sustenta | Días sin informe | Señales abiertas |
|---|---|---|---|---|---|
| PRY-199 | verde | 20 % | 20–40 % | 2 | 0 |
| PRY-200 | rojo | 76 % | 25–50 % | 1 | 3 |
| PRY-201 | verde | 69 % | 67–100 % | 5 | 4 |
| PRY-202 | amarillo | 80 % | 100 % | 3 | 6 |
| PRY-203 | rojo | 38 % | sin hitos en la ficha | 3 | 1 |
| PRY-204 | verde | 53 % | 75–100 % | 0 | 13 |
| PRY-205 | verde | 46 % | 40–60 % | 6 | 5 |
| PRY-206 | verde | 77 % | 50–75 % | 1 | 5 |
| PRY-207 | verde | 24 % | 100 % | 22 | 6 |
| PRY-208 | verde | 43 % | 75–100 % | 4 | 4 |
| PRY-209 | verde | 26 % | sin hitos en la ficha | 17 | 2 |
| PRY-210 | verde | 49 % | sin hitos en la ficha | 4 | 0 |
| PRY-211 | amarillo | 69 % | sin hitos en la ficha | 1 | 0 |

**Dinero.** Ningún proyecto supera el umbral de costo (10 %): la mayor proyección sobre lo aprobado es +4,5 % en PRY-202 y +4,2 % en PRY-207. PRY-202 lleva ejecutado 59,4 % contra 100 % del plan en hitos; PRY-208, 57,6 % ejecutado contra 43 % de avance declarado.

**Contradicciones abiertas.** Siete estados verdes con señales que el informe no recoge (PRY-201, 204, 205, 206, 207, 208, 209). El proyecto PRY-205 se llama «Seguimiento satelital de la flota» pero sus hitos, contrato (estanterías y arriendo de vehículos eléctricos) e informe hablan de bodega e inventario; puede ser plantilla mezclada o un nombre que no describe el alcance.

**Vacíos de información.**
- Autoridad de cambios: vacía en las 13 fichas.
- Los 36 ítems RAID registrados no tienen doliente ni fecha; no hay supuestos ni dependencias entre proyectos registrados.
- Sin minutas en PRY-203, 207, 208, 209, 210 y 211: no se pudo buscar nada dicho en reuniones.
- Fase del proyecto, vacía en las 13 fichas.
- Hitos y vigencia del contrato CT-540 y CT-199: sin dato; la factura de CT-540 coincide con lo aceptado (79.548.107 COP).
- Datos de identidad de PRY-202, PRY-204 y PRY-207 con 12 a 16 meses de antigüedad (umbral 12).

---
*Pie.* Versión 0.12.1 · fichas aplicadas: las 13 de `estado/records/`, corte 2026-10-28 · campos inciertos: autoridad de cambios (13), fase (13), quién aprobó cada CC-01, costo de los cambios que no lo declaran, si los textos repetidos del RAID son un mismo hecho o plantilla, y el historial del comité anterior · Material de trabajo, no decisión ni asesoría; la verificación contra las citas es tuya · Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal
