Informe de la ficha `estado/records/PRY-207.json` (actualizada el 2026-10-28), con cifras recalculadas el 2026-10-28.

## PRY-207 · Portal de clientes con trazabilidad — estado al 2026-10-28

**Declara el gerente (Jorge Medina):** verde · 24% · al 2026-10-06 (hace 22 días; fuente: `20-seguimiento/2026-10-06-informe-avance.pdf`)
**Sustento documental:** contradicho. La alerta `declared_vs_evidence` está abierta: el verde no explica tres señales.
**Lo que el semáforo no explica:**
- `silent`: 22 días sin documentos nuevos, y el umbral es 15.
- `progress_vs_plan`: el gerente declara 24% y el plan sostiene 100% (3 de 3 hitos), una brecha de 76.0 puntos. El avance declarado queda por detrás del plan.
- `milestone_met_without_evidence`: los 3 hitos aparecen cumplidos y ninguno tiene evidencia de cumplimiento.

**Último documento:** 2026-10-06 · **Última reunión:** sin dato. La carpeta no tiene actas ni transcripciones de reuniones.

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2026-08-21 | 2026-08-21 | 0 días contra la original y contra la vigente |
| Presupuesto aprobado | COP 9.500.000.000 | COP 9.500.000.000 | proyección 4.2% sobre lo aprobado (umbral 10%) |

Presupuesto: comprometido COP 6.597.325.946 (69.4%), ejecutado COP 3.638.979.753 (38.3%), proyección al cierre COP 9.899.993.006, disponible real COP 2.902.674.054.

Replanificaciones: 0. Hay una sola línea base (v1, aprobada el 2025-06-26 con el acta de constitución). La fecha de cierre no se movió, pero ya pasó hace 68 días y el avance declarado es 24%.

### Hitos
| Hito | Base | Vigente | Estado | Evidencia |
|---|---|---|---|---|
| Diseño de la operación aprobado | 2025-11-20 | 2025-11-20 | cumplido sin evidencia (342 días) | ninguna |
| Permisos de operación obtenidos | 2026-04-06 | 2026-04-06 | cumplido sin evidencia (205 días) | ninguna |
| Adecuación de la bodega terminada | 2026-08-21 | 2026-08-21 | cumplido sin evidencia (68 días) | ninguna |

### Dónde no coincide
- **Avance:** el informe del 2026-10-06 declara 24% de avance. El cronograma v1 del 2025-06-26 pone los 3 hitos con fecha anterior al 2026-08-21, y la ficha los marca como cumplidos. Un 24% declarado y tres hitos de tres cumplidos no son compatibles.
- **Semáforo:** el informe declara verde. El mismo informe cuenta que la prueba de exactitud de inventario no alcanzó el valor pactado y se repite, y lista dos riesgos abiertos sin dueño ni fecha.
- **Hitos:** ningún documento acredita el cumplimiento de ninguno de los tres. El único soporte es el cronograma de 2025, que es el plan y no un recibo.

### Abierto
**Riesgos e incidencias sin movimiento:**
- Riesgo: el proveedor no ha confirmado la fecha de la última entrega (sin dueño, probabilidad, impacto ni fecha; citado del informe del 2026-10-06).
- Riesgo: paros de transportadores en las vías principales (sin dueño, probabilidad, impacto ni fecha; mismo informe).
- Incidencia: la prueba de exactitud de inventario no alcanzó el valor pactado y se repite (sin dueño ni fecha de inicio; mismo informe).

Los días sin movimiento no se pueden contar: ninguno trae fecha de último movimiento.
**Compromisos vencidos:** ninguno. Tampoco hay compromisos registrados, porque no hay reuniones documentadas.
**Dependencias sin confirmar:** ninguna registrada. El riesgo del proveedor apunta a una dependencia externa sin fecha.

### Sin dato
- `identity.product`, `identity.authority` e `identity.phase`: no aparecen en ningún documento.
- Última reunión y compromisos: sin actas.
- Dueño, probabilidad, impacto y último movimiento de cada riesgo e incidencia.
- Proveedores: ninguno registrado.
- Campos con más de 12 meses de antigüedad, todos del acta y el cronograma del 2025-06-26 (16 meses): código, nombre, área, sponsor, gerente, comité, fechas de inicio y cierre, alcance, exclusiones y presupuesto aprobado.
- El alcance dice «Componente 1, 2 y 3 (sin detalle)».

### Siguiente paso
La brecha de avance, los tres hitos sin evidencia y el silencio de 22 días justifican llevar el caso al comité (próximo: 2026-10-31). Puedo preparar el punto de comité si lo pides. No hay cambio de alcance ni de fechas que formalizar: no hay solicitudes de cambio.

---
Criterio · criterio-portfolio 0.12.1 · ficha aplicada: `PRY-207.json`, actualizada el 2026-10-28 · declaración del gerente del 2026-10-06 · campos inciertos: los de «Sin dato» · términos v1.3, aceptados por José Francisco Ñáñez el 2026-10-28: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.12.1
