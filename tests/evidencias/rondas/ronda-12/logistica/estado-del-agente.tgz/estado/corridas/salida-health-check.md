## Diagnóstico · PRY-202 Flota eléctrica de última milla · 2026-10-28

**Leí:** 4 documentos · 2025-07-08 a 2026-10-25 · formatos: Markdown (2), XLSX (1), PDF (1)
**No pude leer:** ninguno. El cronograma XLSX lo leí por su texto convertido en caché (`estado/cache/texto/…/2025-07-08-cronograma-v1.xlsx.md`), no abriendo el original. Busqué el proyecto en las minutas y documentos de los otros 12 proyectos y en la caché de texto: ningún otro documento lo menciona.

Términos: vigentes (v1.3, aceptados por José Francisco Ñáñez el 2026-10-28); no hubo que registrar nada nuevo.

### Dictamen
**Sostenido:** 4 afirmaciones · **Sin sustento:** 10 · **Contradicho:** 1

Desde esta carpeta solo se puede afirmar quién gobierna el proyecto, cuánto se aprobó y qué fechas se comprometieron en el acta de 2025-07-08, y que en el comité del 2026-10-22 se registró un compromiso que ya estaba vencido. Todo lo demás —el estado amarillo, el 80 %, los cuatro hitos cerrados, el dinero comprometido y ejecutado, los hechos del periodo— viene de documentos que escribe quien reporta, y ninguno trae un documento de evidencia detrás (0 de 15 datos de la ficha están marcados como evidencia; 15 sin marcar). El avance declarado además choca con el cronograma del propio proyecto. El proyecto está 47 días pasado de su fecha de cierre comprometida (2026-09-11) sin replanificación ni solicitud de cambio.

### Gobierno
| | Qué dice el documento | Fuente |
|---|---|---|
| Patrocinador | Laura Vélez | acta de constitución 2025-07-08 |
| Gerente | Sandra Gil | acta de constitución 2025-07-08 |
| Autoridad declarada | **No está.** El acta no dice qué puede decidir la gerente en tiempo ni en dinero | acta de constitución 2025-07-08 |
| Comité | Comité de Inversiones (aprobó el presupuesto el 2025-07-08) | acta de constitución 2025-07-08 |

Sin autoridad declarada no hay desviación aprobada: hay fechas que alguien escribió. El acta tampoco da alcance real (“Componente 1, 2, 3”), ni fuera de alcance (“lo que otro proyecto cubre”), ni dependencias (“ninguna declarada”). Producto asociado: entregas en el día. Los datos de gobierno tienen 15 meses de antigüedad, sobre el umbral de 12.

### Contra el plan
Hay una línea base: v1, aprobada el 2025-07-08 con el acta, cierre 2026-09-11 (cronograma v1). No hay replanificaciones (0), ni solicitudes de cambio (0), ni línea base vigente distinta de la original: la desviación de fecha contra la original y contra la vigente es 0 días **porque nadie movió las fechas**, no porque se haya cumplido el plan.

Observación sobre el cronograma: el archivo está fechado 2025-07-08 y nombrado “v1”, pero marca como “cerrado” hitos con fecha hasta 2026-09-11. O el estado se editó después sobre el mismo archivo sin versionar, o la fecha del archivo no es la de su última edición. Ninguna de las dos cosas es evidencia de cierre.

### Las cuatro cifras
Ver “Dinero”. Proyección 9.926.714.164 contra aprobado 9.500.000.000: **4,5 % por encima**, bajo el umbral de 10 %. Ejecutado 59,4 % del aprobado; comprometido 28,6 %. Con 80 % de avance declarado y 59,4 % de ejecución, el informe no explica la diferencia.

### Hitos vencidos sin evidencia
Todos están marcados “cerrado” en el cronograma, pero ninguno tiene documento de respaldo en la carpeta.

| Hito | Fecha | Días | Qué documento se esperaría |
|---|---|---|---|
| Diseño de la operación aprobado | 2025-10-31 | 362 | Diseño aprobado con acta o firma del patrocinador |
| Permisos de operación obtenidos | 2026-02-13 | 257 | Los permisos o resoluciones de la autoridad |
| Adecuación de la bodega terminada | 2026-05-29 | 152 | Acta de recibo de la adecuación |
| Pruebas con carga real | 2026-09-11 | 47 | Informe de pruebas con resultados |

### Dinero
| Aprobado | Comprometido | Ejecutado | Proyección | Disponible real |
|---|---|---|---|---|
| 9.500.000.000 COP | 2.718.494.817 COP | 5.644.787.990 COP | 9.926.714.164 COP | 6.781.505.183 COP |

Solo el aprobado tiene respaldo (acta). Comprometido, ejecutado y proyección salen del informe de avance del 2026-10-25, sin ningún soporte financiero. El “disponible real” es aprobado menos comprometido, tal como lo calcula el script; si “comprometido” incluye lo ejecutado, no cuadra, porque lo ejecutado es mayor que lo comprometido. El informe no define el término, así que esa cifra no se puede leer con certeza.

### Lo que se dijo y nadie registró
- **Compromiso vencido:** Liliana Torres, “Entregar el punto 13”, para 2026-10-18; vencido hace 10 días (minuta del 2026-10-22). Se registró en el comité cuatro días después de la fecha prometida, no hay acta de recibo, y Liliana Torres no figura entre los asistentes. “Punto 13” no se define en ningún documento.
- **Dependencias no registradas:** el acta dice “ninguna declarada”, pero el informe habla de un concepto de la autoridad aduanera sobre la bodega y de un posible cambio en la norma de pesos y dimensiones que puede mover el alcance. Ambos son dependencias externas fuera del registro.
- **Riesgos sin dueño:** los dos riesgos del informe (concentración del conocimiento en una persona; cambio en la norma de pesos y dimensiones) no tienen responsable, probabilidad, impacto ni fecha.
- **Incidencia sin dueño ni inicio:** paro de transportadores con despachos detenidos seis días. No se dice si movió fechas o costos; no hay solicitud de cambio.
- La minuta del 2026-10-22 lista “Avance” y “Compromisos” como temas, sin contenido sobre el avance: no registra qué se dijo del 80 %, del estado ni del vencimiento del cierre.

### Contradicho
| Afirmación | Documento A | Documento B |
|---|---|---|
| Avance | Informe de avance 2026-10-25: 80 % y estado amarillo | Cronograma v1: los 4 hitos “cerrados” (el plan sostendría 100 %, 20 puntos más) |

Ninguno de los dos documentos tiene evidencia detrás, así que no se puede decir cuál es el cierto; solo que no pueden serlo ambos.

### Sin sustento
1. Estado amarillo (sin criterio de por qué amarillo y no rojo, con el cierre vencido).
2–5. Los cuatro hitos “cerrados” (sin documento de evidencia).
6. Paro de transportadores de seis días.
7. Concepto de la autoridad aduanera sobre la bodega recibido.
8. Acuerdo con operaciones sobre cómo se mide el nivel de servicio de cada ruta.
9. Comprometido, ejecutado y proyección al cierre (una afirmación por cada cifra, contada como una).
10. Los dos riesgos abiertos, como estado real (están declarados, no se puede verificar que existan ni que no haya otros).

### Sostenido
1. Patrocinador, gerente y comité (acta).
2. Presupuesto aprobado de 9.500.000.000 COP por el Comité de Inversiones el 2025-07-08 (acta).
3. Inicio 2025-07-18 y cierre comprometido 2026-09-11 (acta y cronograma v1).
4. Que en el comité del 2026-10-22 se registró el compromiso de Liliana Torres (minuta). Que se cumpla o no, no está sostenido.

### Lo que esta carpeta no permite saber
- **Si el proyecto terminó o va al 80 %:** sin informe de pruebas ni acta de recibo, no hay base para decidir cuál cifra es la cierta ni si el cierre ya ocurrió.
- **Cuánto se ha gastado de verdad:** sin extracto financiero o ejecución presupuestal, el 59,4 % ejecutado y la proyección son una declaración.
- **Si el atraso está aprobado:** no hay autoridad declarada, ni solicitud de cambio, ni replanificación; el cierre de 2026-09-11 pasó hace 47 días.
- **Qué es el “punto 13” y quién es Liliana Torres en el proyecto:** sin eso el compromiso vencido no se puede ligar a ningún entregable.
- **Qué incluye el alcance:** “Componente 1, 2 y 3” no dice qué se entrega, así que no se puede medir un avance físico.
- **Si el paro movió fechas o costos:** no hay solicitud de cambio.

### Pie de rigor
Cifras derivadas copiadas de `portafolio.py compute` (corte 2026-10-28). Todo lo declarado va señalado como declarado. Este diagnóstico no recomienda detener, continuar ni reestructurar; eso lo decide quien tiene la facultad.

**Siguiente paso, si lo quiere:** preparar el punto de comité con la lista de lo que falta, o llevar a Sandra Gil las contradicciones como preguntas, una por una (primero: ¿80 % o 4 de 4 hitos cerrados?).
