# Corrida del 2026-10-28 · portfolio-setup

3 proyectos · 74 documentos, 39 releídos y 35 sin cambio · 162 s · 21 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_overdue` | 6 |
| `milestone_met_without_evidence` | 3 |
| `commitment_undated` | 3 |
| `commitment_rescheduled` | 3 |
| `progress_vs_plan` | 2 |
| `declared_vs_evidence` | 2 |
| `variance_time` | 1 |
| `rebaseline_unauthorized` | 1 |

0 preguntas (sesión sin interfaz, respuestas sugeridas); sin cronómetro de conversación; primer resultado sobre 3 proyectos (PRY-204, PRY-200, PRY-206): 21 señales, ninguna ficha con record_issues; términos aceptados por José Francisco Ñáñez; carpeta marcada

Primera corrida: no hay una anterior contra la cual comparar.

## Lo que produjo

## Listo — Logística

Soy Vera, el agente PMO de Criterio. Proceso la documentación que ya tienes y digo qué no se sostiene.

**Miré:** 74 documentos en 13 proyectos · formatos: .md (38), .pdf (13), .docx (9), .xlsx (6), .xml (5), .csv (1), .json (1), .txt (1) · más reciente: 2026-10-28
**Eres:** PMO del portafolio (sugerido: hay varios proyectos)
**Te aviso:** dos días antes del comité; los comités son semanales, así que el próximo es el 2026-10-31 (fecha deducida del último comité, 2026-10-24)
**En:** presentación (sugerido; se guarda como `html`, el formato que usa la configuración)
**Términos:** aceptados por José Francisco Ñáñez para la versión 0.12.1 (términos 1.3), el 2026-10-28 · comprobante en `.criterio/terminos/aceptacion-criterio-portfolio-0.12.1-2026-10-28.md` y `.pdf` · SHA-256 del texto de los términos af83e6e855d68d95…
**Carpeta marcada:** `documentos/proyectos/_CRITERIO_PORTAFOLIO.txt` (respuesta sugerida: sí)
**Configuración:** `.criterio/portafolio/config.json` · estado en `estado/` · informes en `reportes/`

### Probé con tres proyectos

Los tres con documentación más reciente: PRY-204 (2026-10-28), PRY-200 y PRY-206 (2026-10-27). Entre los de 2026-10-27 elegí los dos con más documentos. Lo que sigue sale de `compute`.

| Proyecto | Documentos | Qué supe | Qué no está |
|---|---|---|---|
| PRY-204 Cross docking en el puerto | 22 | Gerente y patrocinador: Liliana Torres (acta 2025-10-13). Aprobado COP 18.000.000.000; comprometido 9.340.126.765; ejecutado 3.101.575.940; proyección 16.752.476.829 (informe 2026-10-28). Cierre 2027-01-14, una sola línea base. Declara verde, 53%. | Facultad del gerente (`authority`), fase, acta de recibo del hito «Diseño de la operación aprobado». |
| PRY-200 Centro de distribución del norte | 6 | Gerente Gustavo Neira, patrocinadora Diana Molina. Aprobado COP 1.200.000.000; comprometido 356.719.796; ejecutado 567.287.101; proyección 1.142.507.560. Cierre pasó de 2027-09-14 a 2027-10-09 (+25 días, dos líneas base, CC-01). Declara rojo, 76%. | Facultad del gerente, fase, acta de recibo del hito «Diseño de la operación aprobado». |
| PRY-206 Clasificadora automática de paquetes | 7 | Gerente y patrocinador: Gustavo Neira. Aprobado COP 800.000.000; comprometido 351.057.359; ejecutado 228.656.878; proyección 804.712.675. Cierre pasó de 2027-05-14 a 2027-08-16 (+94 días, dos líneas base). Declara verde, 77%. | Producto (el acta dice «No aplica»), facultad del gerente, fase. |

### Hallazgos (señales levantadas por `compute`)

**PRY-206 · el plan se movió antes de que el comité viera el cambio.**
- `rebaseline_unauthorized`: la línea base se movió 94 días y ningún documento de la carpeta los autoriza. CC-01 (+94 días, COP 188.000.000) está «pendiente de presentación al comité». No es que alguien lo haya hecho sin permiso: es que no hay documento que lo autorice, y conviene preguntar.
- `variance_time`: 94 días (17,7 %) contra la línea base original.
- `milestone_met_without_evidence`: «Permisos de operación obtenidos» (2026-08-21) figura cerrado al 100 % en el cronograma y no hay acta de recibo.
- `declared_vs_evidence`: el informe del 2026-10-27 declara **verde** y las tres señales anteriores no están reconocidas en él.
- `commitment_undated`: Jorge Medina, «Entregar el punto 23», prometido «por definir» (comité 2026-10-22).

**PRY-204 · verde declarado, con compromisos que se corren y sin prueba.**
- `commitment_rescheduled`: «Enviar el documento 1» (Beatriz Cuéllar) se ha reprogramado 6 veces, del 2026-10-06 al 2027-01-06. «Cerrar la prueba 2» (Camilo Beltrán) lleva 5, del 2026-09-27 al 2026-12-09. «Revisar el anexo 3» (María Restrepo) lleva 3. Casi siempre eso indica un bloqueo que nadie ha nombrado, no un problema de seguimiento. Ojo con la fecha del documento 1: las notas dicen «06/01/2027» y la leí día/mes, que es lo que sigue la secuencia (+14 días).
- `commitment_overdue` (5, sin acta de recibo): Camilo Beltrán «Aprobar el diseño 5» (venció 2026-09-29), Mauricio Pérez «Entregar el punto 8» (2026-10-02) y Jorge Medina «Revisar el anexo 11» (2026-10-14). Los tres dijeron en comité que ya lo habían entregado y nadie presentó acta. Además, Andrés Lozano «Cerrar la prueba 18» (2026-10-18) y Ricardo Salas «Validar el ambiente 20» (2026-10-23) siguen en la tabla del comité sin acta.
- `commitment_undated` (2): Carlos Peña «Enviar el documento 9» y Laura Vélez «Mandar el ajuste del presupuesto» («la otra semana», que no es una fecha).
- `milestone_met_without_evidence`: «Diseño de la operación aprobado» (2026-02-12) está cerrado en el cronograma y no hay acta de recibo, hace 258 días.
- `progress_vs_plan`: declara 53 % y el plan sostiene entre 75 % y 100 % (3 de 4 hitos cumplidos), así que el avance declarado va 22 puntos por debajo.
- `declared_vs_evidence`: el informe declara **verde** y las cuatro señales anteriores no están reconocidas en él.
- Dicho en reunión y sin registrar: el proveedor podría no llegar con el equipo completo para la siguiente fase (notas del 2026-10-28). Quedó en el registro de riesgos de la ficha.
- Esta carpeta trae `ficha-pm.json`. La guardé aparte en `pm_record` y no coincidió con mi lectura en ningún campo que `compute` contraste (`pm_vs_pmo`: ninguna señal).

**PRY-200 · rojo declarado; el cambio sí cuadra.**
- `commitment_overdue`: Camilo Beltrán, «Entregar el punto 15», con fecha 2026-10-02, registrado en el comité del 2026-10-24 (la fecha es anterior al comité; sin acta).
- `milestone_met_without_evidence`: «Diseño de la operación aprobado» (2026-08-27) cerrado y sin acta.
- `progress_vs_plan`: declara 76 % y el plan sostiene entre 25 % y 50 %, es decir, va por encima de lo que muestran los hitos.
- CC-01 (+25 días, COP 50.000.000) figura «autorizada por el comité», y los 25 días coinciden con lo que se movió la línea base (`unauthorized_days`: 0). El comité del 2026-10-24 no la menciona.
- Para revisar a mano, aunque `compute` no lo levantó: el informe muestra comprometido (356.719.796) por debajo de ejecutado (567.287.101), que no debería pasar.

**Los tres:** ninguna acta dice hasta qué monto puede decidir el gerente sin subir a comité (`no_authority`: 3), y ninguna da la fase.

### El portafolio completo
10 proyectos más (PRY-199, 201, 202, 203, 205, 207, 208, 209, 210, 211) y unos 50 documentos por leer, en 2 lotes uno tras otro. Son unos 3 o 4 minutos por proyecto con lo que vi (estimado mío, no medido): del orden de 30 a 40 minutos.

### Lo que le falta a tu carpeta
Ninguno es bloqueante.
- **Cinco cronogramas en `.xml`** que el script no sabe leer sin instalar algo (PRY-200 v2, PRY-204 v1, PRY-206 v1 y v2, PRY-207 v1). Los leí como texto, pero en un barrido los habría perdido.
- **Facultad del gerente:** falta en las tres actas que leí.
- **Actas de recibo:** los hitos de diseño de PRY-200 y PRY-204 están cerrados sin acta, y el de permisos de PRY-206 también.
- **Las actas dan el alcance como «Componente 1, 2 y 3»**, sin detalle, y el único fuera de alcance es «lo que otro proyecto cubre».
- **Fechas en los compromisos:** varios dicen «por definir» o «la otra semana».
- **PRY-204:** `2026-10-28-notas-reunion.txt` está suelta en la raíz del proyecto, fuera de `30-reuniones/`. Además, en el comité de PRY-206 (2026-10-22) Gustavo Neira aparece dos veces como asistente.
- **`estado/PRY-204-cross-docking-en-el-puerto/`:** hay una carpeta de estado de un agente de proyecto dentro de `estado/`. No la toqué.
- La fecha del próximo comité la deduje de los comités semanales; corrígela si es otra.
