## 2026-10-28

**Revisé:** 74 documentos · 0 cambiaron · 0 proyectos recalculados. Sin citas rotas, sin renombrados ni borrados. Peticiones del servidor: ninguna.

Términos v1.3 ya vigentes (aceptados por José Francisco Ñáñez el 2026-10-28); no se registraron de nuevo.

### Lo que cruzó un umbral
Nada nuevo desde el último informe de portafolio (hoy). Siguen abiertas las señales ya reportadas, por ejemplo PRY-204 con 13 señales y PRY-207 y PRY-209 en silencio.

### Preguntas (confirmación mensual, 5 campos; primera vez, sin respuesta en esta prueba sin interfaz)
1. **Autoridad de aprobación** de PRY-204: la ficha dice `not_found`. Es el vacío más extendido, porque 13 de 13 proyectos no la tienen registrada. ¿Quién aprueba cambios de línea base?
2. **Estado declarado de PRY-204**: verde con 53 % de avance (informe del 2026-10-28), pero la evidencia lo contradice, con 5 compromisos vencidos. ¿Se mantiene el verde?
3. **Línea base de PRY-206**: replanificación de +94 días sin autorización registrada. ¿Existe un documento de aprobación que no esté en la carpeta?
4. **Cambio de PRY-203** sin línea base. ¿Hay una solicitud de cambio aprobada?
5. **Producto de PRY-201** (y de otros 6 proyectos): sin producto asignado. ¿A qué producto pertenece?

Respuesta sugerida para la prueba: ninguna, porque nadie responde. Se dejan como preguntadas el 2026-10-28, sin respuesta.

**Vuelvo el 2026-10-29.**
