# Corrida del 2026-10-28 · budget-tracking

13 proyectos · 70 s · 49 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 16 |
| `commitment_overdue` | 9 |
| `declared_vs_evidence` | 7 |
| `progress_vs_plan` | 5 |
| `commitment_undated` | 3 |
| `commitment_rescheduled` | 3 |
| `variance_time` | 2 |
| `silent` | 2 |
| `change_without_baseline` | 1 |
| `rebaseline_unauthorized` | 1 |

Presupuesto de 13 proyectos en COP, cifras de compute. Sin línea base de presupuesto ni replanificaciones de presupuesto (not_found). Comprometido menor que ejecutado en PRY-200, 202 y 208: disponible real no confiable. Proyección sobre aprobado en PRY-202, 207 y 206, bajo el umbral de 10%. Sin totales de portafolio: el script no los da.

Contra la corrida del 2026-10-28: +0 hallazgos.

## Lo que produjo

## Presupuesto — Portafolio Logística al 2026-10-28
**Moneda:** COP (los 13 proyectos; no hubo conversión)

**De qué sale:** `compute` del 2026-10-28 sobre las 13 fichas de `estado/records/` (PRY-199 a PRY-211). El aprobado sale del acta de constitución de cada proyecto; comprometido, ejecutado y proyección salen del último informe de avance. Son declaraciones del gerente de cada proyecto: ningún documento de contabilidad o de contratos las respalda en esta corrida.

### Las cuatro cifras por proyecto (COP)

| Proyecto | Aprobado | Comprometido | Ejecutado | Proyección | % ejec. | % comp. | Disponible real | Proy. sobre aprobado |
|---|---|---|---|---|---|---|---|---|
| PRY-199 Pintura de la portería | 2400000000 | 1080000000 | 720000000 | 2400000000 | 30.0 | 45.0 | 1320000000 | 0.0% |
| PRY-200 Centro de distribución del norte | 1200000000 | 356719796 | 567287101 | 1142507560 | 47.3 | 29.7 | 843280204 | -4.8% |
| PRY-201 Sistema de gestión de bodegas | 800000000 | 320203724 | 301085494 | 777230222 | 37.6 | 40.0 | 479796276 | -2.8% |
| PRY-202 Flota eléctrica de última milla | 9500000000 | 2718494817 | 5644787990 | 9926714164 | 59.4 | 28.6 | 6781505183 | +4.5% |
| PRY-203 Ruteo dinámico de vehículos | 1200000000 | 457383823 | 386347588 | 1148623615 | 32.2 | 38.1 | 742616177 | -4.3% |
| PRY-204 Cross docking en el puerto | 18000000000 | 9340126765 | 3101575940 | 16752476829 | 17.2 | 51.9 | 8659873235 | -6.9% |
| PRY-205 Seguimiento satelital de la flota | 800000000 | 501957533 | 326910807 | 740846224 | 40.9 | 62.7 | 298042467 | -7.4% |
| PRY-206 Clasificadora automática de paquetes | 800000000 | 351057359 | 228656878 | 804712675 | 28.6 | 43.9 | 448942641 | +0.6% |
| PRY-207 Portal de clientes con trazabilidad | 9500000000 | 6597325946 | 3638979753 | 9899993006 | 38.3 | 69.4 | 2902674054 | +4.2% |
| PRY-208 Cadena de frío para farmacéuticos | 6800000000 | 2354740734 | 3920161615 | 6668978882 | 57.6 | 34.6 | 4445259266 | -1.9% |
| PRY-209 Consolidación de cargas regionales | 1200000000 | 317031376 | 180165796 | 1174530340 | 15.0 | 26.4 | 882968624 | -2.1% |
| PRY-210 Puntos de recogida en estaciones | 3300000000 | 1848655634 | 851163591 | 3075995761 | 25.8 | 56.0 | 1451344366 | -6.8% |
| PRY-211 Facturación electrónica de fletes | 800000000 | 601649902 | 195355132 | 763082585 | 24.4 | 75.2 | 198350098 | -4.6% |

Disponible real = aprobado menos comprometido, tal como lo calcula el script. No sumo el portafolio: `compute` no entrega totales de dinero y no escribo una cifra derivada que el script no dé.

**Fuentes y fechas.** Aprobado (acta de constitución): PRY-199 2026-06-20 · PRY-200 2026-04-12 · PRY-201 2026-02-15 · PRY-202 2025-07-08 · PRY-203 2026-03-17 · PRY-204 2025-10-13 · PRY-205 2026-02-13 · PRY-206 2025-11-19 · PRY-207 2025-06-26 · PRY-208 2026-04-15 · PRY-209 2026-04-06 · PRY-210 2026-04-20 · PRY-211 2026-01-30. Comprometido, ejecutado y proyección (informe de avance, mismo documento para las tres): PRY-199 2026-10-26 · PRY-200 2026-10-27 · PRY-201 2026-10-23 · PRY-202 2026-10-25 · PRY-203 2026-10-25 · PRY-204 2026-10-28 · PRY-205 2026-10-18 · PRY-206 2026-10-27 · PRY-207 2026-10-06 · PRY-208 2026-10-24 · PRY-209 2026-10-11 · PRY-210 2026-10-24 · PRY-211 2026-10-27. Las rutas completas están en cada ficha (`money.*.source`).

### Contra la línea base
No hay línea base de presupuesto en ninguna ficha: solo existe el aprobado del acta, sin versiones, así que no se puede dar original, vigente ni desviación de costo. Lo más cercano es la proyección frente al aprobado (última columna), que es una declaración, no una desviación medida contra una línea base.
Replanificaciones de presupuesto: `not_found`. Las que reporta `compute` son de cronograma (PRY-200: 1, PRY-201: 1, PRY-206: 1; las demás 0) y no hay campo de costo en el bloque de cambios. PRY-200, PRY-201, PRY-203 y PRY-206 tienen una solicitud de cambio registrada, pero no se lee de ellas ningún impacto en costo.

### Ejecución frente a avance
Avance declarado en el informe, junto al % ejecutado (no calculo diferencias: no las da el script):

| Proyecto | Avance declarado | Hitos cumplidos | % ejecutado |
|---|---|---|---|
| PRY-199 | 20.0 | 1 de 5 | 30.0 |
| PRY-200 | 76.0 | 1 de 4 | 47.3 |
| PRY-201 | 69.0 | 2 de 3 | 37.6 |
| PRY-202 | 80.0 | 4 de 4 | 59.4 |
| PRY-204 | 53.0 | 3 de 4 | 17.2 |
| PRY-205 | 46.0 | 2 de 5 | 40.9 |
| PRY-206 | 77.0 | 2 de 4 | 28.6 |
| PRY-207 | 24.0 | 3 de 3 | 38.3 |
| PRY-208 | 43.0 | 3 de 4 | 57.6 |

PRY-203, PRY-209, PRY-210 y PRY-211: `compute` no trae el cruce de avance contra hitos, así que no hay lectura.

Lectura, en lo que sí se ve:
- **PRY-207:** declara 24% de avance con los 3 hitos cumplidos y 38.3% ejecutado. Las cifras no se corresponden entre sí; además lleva señal de silencio y su último informe es del 2026-10-06.
- **PRY-208:** 57.6% ejecutado frente a 43% declarado. Ejecución por encima del avance.
- **PRY-204:** 17.2% ejecutado, 53% declarado y 51.9% comprometido. Ejecución muy por debajo del avance declarado y del comprometido puede ser trabajo hecho y no causado, que aparecería de golpe; o puede ser avance inflado. Con el aprobado de 18000000000 es el de mayor monto del portafolio.
- **PRY-200, PRY-201, PRY-206:** declaran 76%, 69% y 77% de avance y han ejecutado 47.3%, 37.6% y 28.6%. Los tres tienen hitos marcados como cumplidos sin evidencia, así que el avance declarado no se sostiene en los documentos.
- **PRY-202:** 4 de 4 hitos cumplidos (todos sin evidencia), avance declarado 80% y 59.4% ejecutado.

### Alertas
- **Comprometido sobre el umbral (90%):** ninguno. El más alto es PRY-211 con 75.2%, con 198350098 disponibles; después PRY-207 con 69.4% y PRY-205 con 62.7%.
- **Proyección por encima del aprobado:** PRY-202 (+4.5%), PRY-207 (+4.2%) y PRY-206 (+0.6%). Ninguna llega al umbral de 10%, pero las tres exceden lo aprobado. PRY-202 y PRY-207 son los dos de 9500000000.
- **Ejecutado por encima del comprometido:** PRY-200 (567287101 contra 356719796), PRY-202 (5644787990 contra 2718494817) y PRY-208 (3920161615 contra 2354740734). Si "comprometido" incluye lo ya ejecutado, esas cifras son imposibles y alguna está mal; si el informe usa "comprometido" para lo que falta por causar, el disponible real de esos tres está sobrestimado, porque restaría solo una parte del gasto. No puedo saber cuál es: el informe no define el término. El disponible real de PRY-200, PRY-202 y PRY-208 no es confiable hasta que el gerente lo aclare.
- **Aprobado viejo:** el aprobado de PRY-202 (acta de 2025-07-08, 15 meses), PRY-207 (2025-06-26, 16 meses) y PRY-204 (2025-10-13, 12 meses) supera el umbral de 12 meses. No hay ninguna modificación de presupuesto declarada desde entonces; es el mismo caso de los dos proyectos con proyección sobre el aprobado (PRY-202, PRY-207).
- **Informes de presupuesto viejos:** PRY-207 (2026-10-06) y PRY-209 (2026-10-11) son los más antiguos, y ambos están marcados en silencio.- **Proyección:** en todos los casos es una declaración del gerente con la misma fecha que el comprometido y el ejecutado. Ninguna es más vieja que un movimiento de presupuesto porque no hay movimientos declarados.

### Sin dato
- Línea base de presupuesto (original y vigente) en los 13 proyectos, y por tanto la desviación de costo.
- Replanificaciones de presupuesto y su motivo.
- Definición de "comprometido" en los informes de avance.
- Respaldo contable o de contratos de las cifras de comprometido y ejecutado: salen solo del informe de avance.
- Facturado por proveedor (`vendors[].invoiced`) en PRY-199.
- Tasa de cambio: no aplica, todo está en COP.
- Autoridad que aprueba el presupuesto (`identity.authority`) en los 13 proyectos.

### Después
La proyección de PRY-202, PRY-207 y PRY-206 excede el aprobado: puedo preparar la solicitud de cambio de cada uno si quieres. Con el comprometido en 75.2%, el detalle por proveedor de PRY-211 es lo más útil de ver primero.

---
*Rigor:* cifras copiadas de `compute` del 2026-10-28; las de gasto son declaraciones de informes de avance, sin contraste contra contabilidad. Nada se convirtió de moneda. Lo que no está declarado va en "Sin dato". Verificar con el gerente de cada proyecto antes de usar en comité.
