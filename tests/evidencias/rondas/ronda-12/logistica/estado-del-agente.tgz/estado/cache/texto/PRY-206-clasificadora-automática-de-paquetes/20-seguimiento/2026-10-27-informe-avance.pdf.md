<!-- origen: PRY-206-clasificadora-automática-de-paquetes/20-seguimiento/2026-10-27-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Clasificadora automática de paquetes
Código: PRY-206
Fecha de corte: 2026-10-27
Gerente: Gustavo Neira

Estado declarado
Verde
Avance reportado: 77%

Lo que pasó en el periodo
- Se levantó un hallazgo de seguridad en la operación de montacargas
- La prueba de exactitud de inventario no alcanzó el valor pactado y se repite

Presupuesto
COP
Aprobado 800.000.000
Comprometido 351.057.359
Ejecutado 228.656.878
Proyección al cierre 804.712.675

Riesgos abiertos
- El proveedor no ha confirmado la fecha de la última entrega
- Cambio en la norma de pesos y dimensiones que puede mover el alcance
