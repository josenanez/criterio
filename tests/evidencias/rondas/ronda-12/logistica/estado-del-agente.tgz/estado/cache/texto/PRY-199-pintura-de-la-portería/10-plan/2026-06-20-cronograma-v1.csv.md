<!-- origen: PRY-199-pintura-de-la-portería/10-plan/2026-06-20-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño de la operación aprobado,2026-10-17,2026-10-17,cerrado
Permisos de operación obtenidos,2027-02-03,2027-02-03,en curso
Adecuación de la bodega terminada,2027-05-23,2027-05-23,en curso
Pruebas con carga real,2027-09-09,2027-09-09,en curso
Arranque de la operación,2027-12-27,2027-12-27,en curso
