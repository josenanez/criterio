<!-- origen: PRY-204-cross-docking-en-el-puerto/10-plan/2025-10-13-cronograma-v1.xml · convertidor: project -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Cronograma · Microsoft Project · Cronograma

**Inicio:** — · **Fin:** — · **Fecha de estado:** —

## Tareas

| ID | EDT | Tarea | Inicio | Fin | Línea base: fin | Avance | Tipo | Predecesoras | Recursos |
|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | Diseño de la operación aprobado | 2026-02-12 | 2026-02-12 | 2026-02-12 | 100% | hito | — | — |
| 2 | 2 | Permisos de operación obtenidos | 2026-06-04 | 2026-06-04 | 2026-06-04 | 100% | hito | 1FS | — |
| 3 | 3 | Adecuación de la bodega terminada | 2026-09-24 | 2026-09-24 | 2026-09-24 | 100% | hito | 2FS | — |
| 4 | 4 | Pruebas con carga real | 2027-01-14 | 2027-01-14 | 2027-01-14 | 50% | hito | 3FS | — |

## Hitos

| Hito | Línea base | Vigente | Estado |
|---|---|---|---|
| Diseño de la operación aprobado | 2026-02-12 | 2026-02-12 | cerrado |
| Permisos de operación obtenidos | 2026-06-04 | 2026-06-04 | cerrado |
| Adecuación de la bodega terminada | 2026-09-24 | 2026-09-24 | cerrado |
| Pruebas con carga real | 2027-01-14 | 2027-01-14 | en curso |
