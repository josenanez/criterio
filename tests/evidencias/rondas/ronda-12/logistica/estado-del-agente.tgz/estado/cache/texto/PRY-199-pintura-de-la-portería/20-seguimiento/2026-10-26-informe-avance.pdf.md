<!-- origen: PRY-199-pintura-de-la-portería/20-seguimiento/2026-10-26-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Pintura de la portería
Código: PRY-199
Fecha de corte: 2026-10-26
Gerente: Andrés Lozano

Estado declarado
Verde
Avance reportado: 20%

Lo que pasó en el periodo
- Se reprogramó la llegada de las estanterías por demoras del importador
- Se acordó con operaciones cómo se mide el nivel de servicio de cada ruta
- Se levantó un hallazgo de seguridad en la operación de montacargas

Presupuesto
COP
Aprobado 2.400.000.000
Comprometido 1.080.000.000
Ejecutado 720.000.000
Proyección al cierre 2.400.000.000

Riesgos abiertos
- El proveedor no ha confirmado la fecha de la última entrega
