<!-- origen: PRY-200-centro-de-distribución-del-norte/10-plan/2026-10-27-cronograma-v2.xml · convertidor: project -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Cronograma · Microsoft Project · Cronograma

**Inicio:** — · **Fin:** — · **Fecha de estado:** —

## Tareas

| ID | EDT | Tarea | Inicio | Fin | Línea base: fin | Avance | Tipo | Predecesoras | Recursos |
|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | Diseño de la operación aprobado | 2026-08-27 | 2026-08-27 | 2026-08-27 | 100% | hito | — | — |
| 2 | 2 | Permisos de operación obtenidos | 2027-01-02 | 2027-01-02 | 2027-01-02 | 50% | hito | 1FS | — |
| 3 | 3 | Adecuación de la bodega terminada | 2027-05-09 | 2027-05-09 | 2027-05-09 | 50% | hito | 2FS | — |
| 4 | 4 | Pruebas con carga real | 2027-10-09 | 2027-10-09 | 2027-09-14 | 50% | hito | 3FS | — |

## Hitos

| Hito | Línea base | Vigente | Estado |
|---|---|---|---|
| Diseño de la operación aprobado | 2026-08-27 | 2026-08-27 | cerrado |
| Permisos de operación obtenidos | 2027-01-02 | 2027-01-02 | en curso |
| Adecuación de la bodega terminada | 2027-05-09 | 2027-05-09 | en curso |
| Pruebas con carga real | 2027-09-14 | 2027-10-09 | en curso |
