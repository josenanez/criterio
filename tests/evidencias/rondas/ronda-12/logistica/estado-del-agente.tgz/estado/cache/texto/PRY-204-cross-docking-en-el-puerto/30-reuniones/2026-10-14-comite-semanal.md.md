<!-- origen: PRY-204-cross-docking-en-el-puerto/30-reuniones/2026-10-14-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Inversiones · Cross docking en el puerto

**Fecha:** 2026-10-14
**Asistentes:** Andrés Lozano, Beatriz Cuéllar, Camilo Beltrán, Elena Duarte, Felipe Arango, Liliana Torres, María Restrepo, Paula Céspedes, Ricardo Salas, Rubén Cárdenas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Beatriz Cuéllar | Enviar el documento 1 | 2026-12-05 |
| Camilo Beltrán | Cerrar la prueba 2 | 2026-12-01 |
| María Restrepo | Revisar el anexo 3 | 2026-11-06 |
| Rubén Cárdenas | Actualizar la matriz 6 | 2026-10-30 |
| Felipe Arango | Cerrar la prueba 10 | 2026-10-26 |
| Rubén Cárdenas | Validar el ambiente 12 | 2026-10-08 |
| Andrés Lozano | Aprobar el diseño 13 | 2026-10-11 |
| Elena Duarte | Entregar el punto 16 | 2026-10-17 |
| María Restrepo | Enviar el documento 17 | 2026-10-31 |
| Andrés Lozano | Cerrar la prueba 18 | 2026-10-18 |
| Paula Céspedes | Revisar el anexo 19 | 2026-11-10 |
| Ricardo Salas | Validar el ambiente 20 | 2026-10-23 |

## Cerrados en esta reunión

- Confirmar la fecha 7 (Beatriz Cuéllar): recibido, acta de recibo del 2026-10-14.
- Actualizar la matriz 14 (Beatriz Cuéllar): recibido, acta de recibo del 2026-10-14.
- Confirmar la fecha 15 (Paula Céspedes): recibido, acta de recibo del 2026-10-14.

## Lo que se dijo

- Mauricio Pérez dice que ya entregó «entregar el punto 8». No se presentó acta.
