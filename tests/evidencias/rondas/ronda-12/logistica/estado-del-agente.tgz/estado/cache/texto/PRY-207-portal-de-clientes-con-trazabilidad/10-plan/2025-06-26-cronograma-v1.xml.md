<!-- origen: PRY-207-portal-de-clientes-con-trazabilidad/10-plan/2025-06-26-cronograma-v1.xml · convertidor: project -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Cronograma · Microsoft Project · Cronograma

**Inicio:** — · **Fin:** — · **Fecha de estado:** —

## Tareas

| ID | EDT | Tarea | Inicio | Fin | Línea base: fin | Avance | Tipo | Predecesoras | Recursos |
|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | Diseño de la operación aprobado | 2025-11-20 | 2025-11-20 | 2025-11-20 | 100% | hito | — | — |
| 2 | 2 | Permisos de operación obtenidos | 2026-04-06 | 2026-04-06 | 2026-04-06 | 100% | hito | 1FS | — |
| 3 | 3 | Adecuación de la bodega terminada | 2026-08-21 | 2026-08-21 | 2026-08-21 | 100% | hito | 2FS | — |

## Hitos

| Hito | Línea base | Vigente | Estado |
|---|---|---|---|
| Diseño de la operación aprobado | 2025-11-20 | 2025-11-20 | cerrado |
| Permisos de operación obtenidos | 2026-04-06 | 2026-04-06 | cerrado |
| Adecuación de la bodega terminada | 2026-08-21 | 2026-08-21 | cerrado |
