<!-- origen: PRY-205-seguimiento-satelital-de-la-flota/30-reuniones/2026-10-22-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Operaciones · Seguimiento satelital de la flota

**Fecha:** 2026-10-22
**Asistentes:** Ricardo Salas, Mauricio Pérez

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Felipe Arango | Entregar el punto 26 | 2026-10-21 |
| Beatriz Cuéllar | Entregar el punto 19 | 2026-10-23 |
