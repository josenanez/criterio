<!-- origen: PRY-201-sistema-de-gestión-de-bodegas/00-gobierno/2026-02-15-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Sistema de gestión de bodegas

Código: PRY-201

Área dueña: Seguridad y Salud en el Trabajo

Patrocinador: Carlos Peña

Gerente de proyecto: Andrés Lozano

Comité: Comité de Operaciones

Producto asociado: No aplica

Fecha de aprobación: 2026-02-15

Objetivo del negocio

Entregar sistema de gestión de bodegas para Seguridad y Salud en el Trabajo.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

800.000.000 COP, aprobado por Comité de Operaciones el 2026-02-15.

Fechas comprometidas

Fecha

Inicio

2026-02-25

Cierre

2026-10-28

Criterio de éxito

Sistema de gestión de bodegas en producción y medido.

Dependencias declaradas

• Ninguna declarada
