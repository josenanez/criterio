<!-- origen: PRY-211-facturación-electrónica-de-fletes/20-seguimiento/2026-10-27-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Facturación electrónica de fletes
Código: PRY-211
Fecha de corte: 2026-10-27
Gerente: Gustavo Neira

Estado declarado
Amarillo
Avance reportado: 69%

Lo que pasó en el periodo
- La prueba de exactitud de inventario no alcanzó el valor pactado y se repite

Presupuesto
COP
Aprobado 800.000.000
Comprometido 601.649.902
Ejecutado 195.355.132
Proyección al cierre 763.082.585

Riesgos abiertos
- Temporada alta que no permite detener la operación
- Concentración del conocimiento en una sola persona
