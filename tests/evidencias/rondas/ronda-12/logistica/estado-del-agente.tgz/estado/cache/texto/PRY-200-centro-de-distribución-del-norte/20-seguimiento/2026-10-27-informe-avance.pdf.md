<!-- origen: PRY-200-centro-de-distribución-del-norte/20-seguimiento/2026-10-27-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Centro de distribución del norte
Código: PRY-200
Fecha de corte: 2026-10-27
Gerente: Gustavo Neira

Estado declarado
Rojo
Avance reportado: 76%

Lo que pasó en el periodo
- Un paro de transportadores detuvo los despachos durante seis días
- El equipo perdió dos semanas por rotación del jefe de bodega

Presupuesto
COP
Aprobado 1.200.000.000
Comprometido 356.719.796
Ejecutado 567.287.101
Proyección al cierre 1.142.507.560

Riesgos abiertos
- Cambio en la norma de pesos y dimensiones que puede mover el alcance
