<!-- origen: PRY-209-consolidación-de-cargas-regionales/00-gobierno/2026-04-06-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Consolidación de cargas regionales

Código: PRY-209

Área dueña: Calidad

Patrocinador: Felipe Arango

Gerente de proyecto: Camilo Beltrán

Comité: Comité de Seguridad

Producto asociado: No aplica

Fecha de aprobación: 2026-04-06

Objetivo del negocio

Entregar consolidación de cargas regionales para Calidad.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

1.200.000.000 COP, aprobado por Comité de Seguridad el 2026-04-06.

Fechas comprometidas

Fecha

Inicio

2026-04-16

Cierre

2027-03-24

Criterio de éxito

Consolidación de cargas regionales en producción y medido.

Dependencias declaradas

• Ninguna declarada
