<!-- origen: PRY-210-puntos-de-recogida-en-estaciones/00-gobierno/2026-04-20-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Puntos de recogida en estaciones

Código: PRY-210

Área dueña: Tecnología

Patrocinador: Felipe Arango

Gerente de proyecto: Mauricio Pérez

Comité: Comité de Tecnología

Producto asociado: puntos de recogida

Fecha de aprobación: 2026-04-20

Objetivo del negocio

Entregar puntos de recogida en estaciones para Tecnología.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

3.300.000.000 COP, aprobado por Comité de Tecnología el 2026-04-20.

Fechas comprometidas

Fecha

Inicio

2026-04-30

Cierre

2026-10-15

Criterio de éxito

Puntos de recogida en estaciones en producción y medido.

Dependencias declaradas

• Ninguna declarada
