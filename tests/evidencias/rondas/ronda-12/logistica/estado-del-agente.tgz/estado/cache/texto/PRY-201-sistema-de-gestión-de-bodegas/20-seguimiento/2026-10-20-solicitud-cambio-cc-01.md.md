<!-- origen: PRY-201-sistema-de-gestión-de-bodegas/20-seguimiento/2026-10-20-solicitud-cambio-cc-01.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-01

**Proyecto:** PRY-201 · Sistema de gestión de bodegas
**Fecha:** 2026-10-20
**Solicitante:** Andrés Lozano

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +40 días sobre la línea base vigente |
| Costo | 80.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
