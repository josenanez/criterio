<!-- origen: PRY-206-clasificadora-automática-de-paquetes/10-plan/2025-11-19-cronograma-v1.xml · convertidor: project -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Cronograma · Microsoft Project · Cronograma

**Inicio:** — · **Fin:** — · **Fecha de estado:** —

## Tareas

| ID | EDT | Tarea | Inicio | Fin | Línea base: fin | Avance | Tipo | Predecesoras | Recursos |
|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | Diseño de la operación aprobado | 2026-04-10 | 2026-04-10 | 2026-04-10 | 100% | hito | — | — |
| 2 | 2 | Permisos de operación obtenidos | 2026-08-21 | 2026-08-21 | 2026-08-21 | 100% | hito | 1FS | — |
| 3 | 3 | Adecuación de la bodega terminada | 2027-01-01 | 2027-01-01 | 2027-01-01 | 50% | hito | 2FS | — |
| 4 | 4 | Pruebas con carga real | 2027-05-14 | 2027-05-14 | 2027-05-14 | 50% | hito | 3FS | — |

## Hitos

| Hito | Línea base | Vigente | Estado |
|---|---|---|---|
| Diseño de la operación aprobado | 2026-04-10 | 2026-04-10 | cerrado |
| Permisos de operación obtenidos | 2026-08-21 | 2026-08-21 | cerrado |
| Adecuación de la bodega terminada | 2027-01-01 | 2027-01-01 | en curso |
| Pruebas con carga real | 2027-05-14 | 2027-05-14 | en curso |
