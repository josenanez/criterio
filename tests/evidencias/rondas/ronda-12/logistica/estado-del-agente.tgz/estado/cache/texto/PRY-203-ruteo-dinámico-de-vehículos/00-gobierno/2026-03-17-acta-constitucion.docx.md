<!-- origen: PRY-203-ruteo-dinámico-de-vehículos/00-gobierno/2026-03-17-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Ruteo dinámico de vehículos

Código: PRY-203

Área dueña: Centros de distribución

Patrocinador: Camilo Beltrán

Gerente de proyecto: Elena Duarte

Comité: Comité de Tecnología

Producto asociado: No aplica

Fecha de aprobación: 2026-03-17

Objetivo del negocio

Entregar ruteo dinámico de vehículos para Centros de distribución.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

1.200.000.000 COP, aprobado por Comité de Tecnología el 2026-03-17.

Fechas comprometidas

Fecha

Inicio

2026-03-27

Cierre

2026-12-28

Criterio de éxito

Ruteo dinámico de vehículos en producción y medido.

Dependencias declaradas

• Ninguna declarada
