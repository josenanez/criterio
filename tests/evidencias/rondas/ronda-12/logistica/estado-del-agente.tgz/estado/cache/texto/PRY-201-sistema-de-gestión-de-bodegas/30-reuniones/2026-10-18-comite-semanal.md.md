<!-- origen: PRY-201-sistema-de-gestión-de-bodegas/30-reuniones/2026-10-18-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Operaciones · Sistema de gestión de bodegas

**Fecha:** 2026-10-18
**Asistentes:** Andrés Lozano, Carlos Peña

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Paula Céspedes | Entregar el punto 31 | 2026-11-13 |
