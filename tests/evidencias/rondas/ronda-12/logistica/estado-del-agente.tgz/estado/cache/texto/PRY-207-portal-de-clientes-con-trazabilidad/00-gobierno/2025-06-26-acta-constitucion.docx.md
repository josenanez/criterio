<!-- origen: PRY-207-portal-de-clientes-con-trazabilidad/00-gobierno/2025-06-26-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Portal de clientes con trazabilidad

Código: PRY-207

Área dueña: Transporte

Patrocinador: Natalia Ospina

Gerente de proyecto: Jorge Medina

Comité: Comité de Clientes

Producto asociado: No aplica

Fecha de aprobación: 2025-06-26

Objetivo del negocio

Entregar portal de clientes con trazabilidad para Transporte.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

9.500.000.000 COP, aprobado por Comité de Clientes el 2025-06-26.

Fechas comprometidas

Fecha

Inicio

2025-07-06

Cierre

2026-08-21

Criterio de éxito

Portal de clientes con trazabilidad en producción y medido.

Dependencias declaradas

• Ninguna declarada
