<!-- origen: PRY-208-cadena-de-frío-para-farmacéuticos/10-plan/2026-04-15-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la operación aprobado | 2026-06-20 | 2026-06-20 | cerrado
Permisos de operación obtenidos | 2026-08-16 | 2026-08-16 | cerrado
Adecuación de la bodega terminada | 2026-10-12 | 2026-10-12 | cerrado
Pruebas con carga real | 2026-12-07 | 2026-12-07 | en curso
