<!-- origen: PRY-203-ruteo-dinámico-de-vehículos/20-seguimiento/2026-10-25-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Ruteo dinámico de vehículos
Código: PRY-203
Fecha de corte: 2026-10-25
Gerente: Elena Duarte

Estado declarado
Rojo
Avance reportado: 38%

Lo que pasó en el periodo
- Se reprogramó la llegada de las estanterías por demoras del importador
- Se ajustó el plan de arranque con el cliente ancla

Presupuesto
COP
Aprobado 1.200.000.000
Comprometido 457.383.823
Ejecutado 386.347.588
Proyección al cierre 1.148.623.615

Riesgos abiertos
- Paros de transportadores en las vías principales
- Concentración del conocimiento en una sola persona
