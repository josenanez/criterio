<!-- origen: PRY-201-sistema-de-gestión-de-bodegas/10-plan/2026-02-15-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la operación aprobado | 2026-05-17 | 2026-05-17 | cerrado
Permisos de operación obtenidos | 2026-08-07 | 2026-08-07 | cerrado
Adecuación de la bodega terminada | 2026-10-28 | 2026-10-28 | en curso
