<!-- origen: PRY-205-seguimiento-satelital-de-la-flota/20-seguimiento/2026-10-18-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Seguimiento satelital de la flota
Código: PRY-205
Fecha de corte: 2026-10-18
Gerente: Ricardo Salas

Estado declarado
Verde
Avance reportado: 46%

Lo que pasó en el periodo
- Se ajustó el plan de arranque con el cliente ancla
- La prueba de exactitud de inventario no alcanzó el valor pactado y se repite
- El equipo perdió dos semanas por rotación del jefe de bodega

Presupuesto
COP
Aprobado 800.000.000
Comprometido 501.957.533
Ejecutado 326.910.807
Proyección al cierre 740.846.224

Riesgos abiertos
- El proveedor no ha confirmado la fecha de la última entrega
- Concentración del conocimiento en una sola persona
