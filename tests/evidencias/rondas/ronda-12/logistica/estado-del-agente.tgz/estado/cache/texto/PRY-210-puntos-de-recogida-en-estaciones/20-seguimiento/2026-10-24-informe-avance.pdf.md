<!-- origen: PRY-210-puntos-de-recogida-en-estaciones/20-seguimiento/2026-10-24-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Puntos de recogida en estaciones
Código: PRY-210
Fecha de corte: 2026-10-24
Gerente: Mauricio Pérez

Estado declarado
Verde
Avance reportado: 49%

Lo que pasó en el periodo
- Se acordó con operaciones cómo se mide el nivel de servicio de cada ruta

Presupuesto
COP
Aprobado 3.300.000.000
Comprometido 1.848.655.634
Ejecutado 851.163.591
Proyección al cierre 3.075.995.761

Riesgos abiertos
- El proveedor no ha confirmado la fecha de la última entrega
