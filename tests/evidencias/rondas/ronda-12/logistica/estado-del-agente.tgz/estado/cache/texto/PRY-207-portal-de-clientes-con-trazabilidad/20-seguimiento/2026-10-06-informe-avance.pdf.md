<!-- origen: PRY-207-portal-de-clientes-con-trazabilidad/20-seguimiento/2026-10-06-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Portal de clientes con trazabilidad
Código: PRY-207
Fecha de corte: 2026-10-06
Gerente: Jorge Medina

Estado declarado
Verde
Avance reportado: 24%

Lo que pasó en el periodo
- La prueba de exactitud de inventario no alcanzó el valor pactado y se repite
- Se ajustó el plan de arranque con el cliente ancla
- Se acordó con operaciones cómo se mide el nivel de servicio de cada ruta

Presupuesto
COP
Aprobado 9.500.000.000
Comprometido 6.597.325.946
Ejecutado 3.638.979.753
Proyección al cierre 9.899.993.006

Riesgos abiertos
- El proveedor no ha confirmado la fecha de la última entrega
- Paros de transportadores en las vías principales
