<!-- origen: PRY-206-clasificadora-automática-de-paquetes/30-reuniones/2026-10-22-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Tecnología · Clasificadora automática de paquetes

**Fecha:** 2026-10-22
**Asistentes:** Gustavo Neira, Gustavo Neira

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Jorge Medina | Entregar el punto 23 | por definir |
