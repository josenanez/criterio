<!-- origen: PRY-204-cross-docking-en-el-puerto/30-reuniones/2026-10-21-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Inversiones · Cross docking en el puerto

**Fecha:** 2026-10-21
**Asistentes:** Andrés Lozano, Beatriz Cuéllar, Camilo Beltrán, Elena Duarte, Javier Hoyos, Laura Vélez, Liliana Torres, María Restrepo, Natalia Ospina, Ricardo Salas, Rubén Cárdenas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Beatriz Cuéllar | Enviar el documento 1 | 2026-12-23 |
| Camilo Beltrán | Cerrar la prueba 2 | 2026-12-09 |
| María Restrepo | Revisar el anexo 3 | 2026-11-26 |
| Rubén Cárdenas | Actualizar la matriz 6 | 2026-11-18 |
| Andrés Lozano | Aprobar el diseño 13 | 2026-10-28 |
| Andrés Lozano | Cerrar la prueba 18 | 2026-10-18 |
| Ricardo Salas | Validar el ambiente 20 | 2026-10-23 |
| Natalia Ospina | Aprobar el diseño 21 | 2026-11-13 |
| Laura Vélez | Actualizar la matriz 22 | 2026-10-28 |
| Elena Duarte | Confirmar la fecha 23 | 2026-11-06 |
| Javier Hoyos | Entregar el punto 24 | 2026-11-08 |

## Cerrados en esta reunión

- Cerrar la prueba 10 (Felipe Arango): recibido, acta de recibo del 2026-10-21.
- Validar el ambiente 12 (Rubén Cárdenas): recibido, acta de recibo del 2026-10-21.
- Entregar el punto 16 (Elena Duarte): recibido, acta de recibo del 2026-10-21.
- Enviar el documento 17 (María Restrepo): recibido, acta de recibo del 2026-10-21.
- Revisar el anexo 19 (Paula Céspedes): recibido, acta de recibo del 2026-10-21.
