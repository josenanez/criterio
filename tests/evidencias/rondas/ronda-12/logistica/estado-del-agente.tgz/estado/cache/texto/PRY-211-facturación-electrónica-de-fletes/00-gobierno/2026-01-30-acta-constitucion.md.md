<!-- origen: PRY-211-facturación-electrónica-de-fletes/00-gobierno/2026-01-30-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Facturación electrónica de fletes

**Código:** PRY-211
**Área dueña:** Centros de distribución
**Patrocinador:** Beatriz Cuéllar
**Gerente de proyecto:** Gustavo Neira
**Comité:** Comité de Clientes
**Producto asociado:** No aplica
**Fecha de aprobación:** 2026-01-30

## Objetivo del negocio

Entregar facturación electrónica de fletes para Centros de distribución.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**800.000.000 COP**, aprobado por Comité de Clientes el 2026-01-30.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-02-09 |
| Cierre | 2026-09-21 |

## Criterio de éxito

Facturación electrónica de fletes en producción y medido.

## Dependencias declaradas

- Ninguna declarada
