<!-- origen: PRY-203-ruteo-dinámico-de-vehículos/20-seguimiento/2026-10-18-solicitud-cambio-cc-01.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-01

**Proyecto:** PRY-203 · Ruteo dinámico de vehículos
**Fecha:** 2026-10-18
**Solicitante:** Elena Duarte

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +40 días sobre la línea base vigente |
| Costo | 80.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
