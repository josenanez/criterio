<!-- origen: PRY-206-clasificadora-automática-de-paquetes/00-gobierno/2025-11-19-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Clasificadora automática de paquetes

**Código:** PRY-206
**Área dueña:** Transporte
**Patrocinador:** Gustavo Neira
**Gerente de proyecto:** Gustavo Neira
**Comité:** Comité de Tecnología
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-11-19

## Objetivo del negocio

Entregar clasificadora automática de paquetes para Transporte.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**800.000.000 COP**, aprobado por Comité de Tecnología el 2025-11-19.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-11-29 |
| Cierre | 2027-05-14 |

## Criterio de éxito

Clasificadora automática de paquetes en producción y medido.

## Dependencias declaradas

- Ninguna declarada
