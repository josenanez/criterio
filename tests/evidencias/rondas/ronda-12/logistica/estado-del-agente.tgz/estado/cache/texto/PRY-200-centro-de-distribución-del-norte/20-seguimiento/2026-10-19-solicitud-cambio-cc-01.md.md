<!-- origen: PRY-200-centro-de-distribución-del-norte/20-seguimiento/2026-10-19-solicitud-cambio-cc-01.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-01

**Proyecto:** PRY-200 · Centro de distribución del norte
**Fecha:** 2026-10-19
**Solicitante:** Gustavo Neira

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +25 días sobre la línea base vigente |
| Costo | 50.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
