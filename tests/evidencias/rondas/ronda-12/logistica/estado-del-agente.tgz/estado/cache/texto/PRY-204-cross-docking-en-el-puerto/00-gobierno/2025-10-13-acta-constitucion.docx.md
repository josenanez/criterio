<!-- origen: PRY-204-cross-docking-en-el-puerto/00-gobierno/2025-10-13-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Cross docking en el puerto

Código: PRY-204

Área dueña: Seguridad y Salud en el Trabajo

Patrocinador: Liliana Torres

Gerente de proyecto: Liliana Torres

Comité: Comité de Inversiones

Producto asociado: cross docking

Fecha de aprobación: 2025-10-13

Objetivo del negocio

Entregar cross docking en el puerto para Seguridad y Salud en el Trabajo.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

18.000.000.000 COP, aprobado por Comité de Inversiones el 2025-10-13.

Fechas comprometidas

Fecha

Inicio

2025-10-23

Cierre

2027-01-14

Criterio de éxito

Cross docking en el puerto en producción y medido.

Dependencias declaradas

• Ninguna declarada
