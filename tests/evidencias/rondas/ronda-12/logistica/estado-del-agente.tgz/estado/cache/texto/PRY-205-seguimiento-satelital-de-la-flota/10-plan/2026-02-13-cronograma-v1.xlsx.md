<!-- origen: PRY-205-seguimiento-satelital-de-la-flota/10-plan/2026-02-13-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la operación aprobado | 2026-06-09 | 2026-06-09 | cerrado
Permisos de operación obtenidos | 2026-09-23 | 2026-09-23 | cerrado
Adecuación de la bodega terminada | 2027-01-08 | 2027-01-08 | en curso
Pruebas con carga real | 2027-04-24 | 2027-04-24 | en curso
Arranque de la operación | 2027-08-08 | 2027-08-08 | en curso
