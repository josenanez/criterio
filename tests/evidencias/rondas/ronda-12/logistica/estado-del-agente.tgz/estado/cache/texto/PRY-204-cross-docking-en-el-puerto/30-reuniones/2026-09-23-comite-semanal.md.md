<!-- origen: PRY-204-cross-docking-en-el-puerto/30-reuniones/2026-09-23-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Inversiones · Cross docking en el puerto

**Fecha:** 2026-09-23
**Asistentes:** Beatriz Cuéllar, Camilo Beltrán, Liliana Torres, María Restrepo, Mauricio Pérez, Ricardo Salas, Rubén Cárdenas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Beatriz Cuéllar | Enviar el documento 1 | 2026-10-18 |
| Camilo Beltrán | Cerrar la prueba 2 | 2026-10-09 |
| María Restrepo | Revisar el anexo 3 | 2026-10-11 |
| Ricardo Salas | Validar el ambiente 4 | 2026-10-05 |
| Camilo Beltrán | Aprobar el diseño 5 | 2026-09-29 |
| Rubén Cárdenas | Actualizar la matriz 6 | 2026-10-19 |
| Beatriz Cuéllar | Confirmar la fecha 7 | 2026-10-14 |
| Mauricio Pérez | Entregar el punto 8 | 2026-10-02 |
