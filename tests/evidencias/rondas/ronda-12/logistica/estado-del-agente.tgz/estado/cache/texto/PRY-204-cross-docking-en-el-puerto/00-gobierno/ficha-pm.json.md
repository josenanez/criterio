<!-- origen: PRY-204-cross-docking-en-el-puerto/00-gobierno/ficha-pm.json · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

{
 "schema_version": "0.2",
 "identity": {
 "code": {
 "value": "PRY-204",
 "source": "00-gobierno/2025-10-13-acta-constitucion.docx",
 "source_date": "2025-10-13",
 "state": "found"
 },
 "name": {
 "value": "Cross docking en el puerto",
 "source": "00-gobierno/2025-10-13-acta-constitucion.docx",
 "source_date": "2025-10-13",
 "state": "found"
 },
 "aliases": [],
 "business_area": {
 "value": "Seguridad y Salud en el Trabajo",
 "source": "00-gobierno/2025-10-13-acta-constitucion.docx",
 "source_date": "2025-10-13",
 "state": "found"
 },
 "product": {
 "value": "cross docking",
 "source": "00-gobierno/2025-10-13-acta-constitucion.docx",
 "source_date": "2025-10-13",
 "state": "found"
 },
 "authority": {
 "value": null,
 "source": "00-gobierno/2025-10-13-acta-constitucion.docx",
 "source_date": "2025-10-13",
 "state": "not_found"
 },
 "sponsor": {
 "value": "Liliana Torres",
 "source": "00-gobierno/2025-10-13-acta-constitucion.docx",
 "source_date": "2025-10-13",
 "state": "found"
 },
 "manager": {
 "value": "Liliana Torres",
 "source": "00-gobierno/2025-10-13-acta-constitucion.docx",
 "source_date": "2025-10-13",
 "state": "found"
 },
 "committee": {
 "value": "Comité de Inversiones",
 "source": "00-gobierno/2025-10-13-acta-constitucion.docx",
 "source_date": "2025-10-13",
 "state": "found"
 },
 "phase": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 }
 },
 "declared": {
 "status": "verde",
 "progress_pct": 53,
 "as_of": "2026-10-28",
 "source": "20-seguimiento/2026-10-28-informe-avance.md",
 "source_kind": "declaration"
 },
 "plan": {
 "start_date": {
 "value": "2025-10-23",
 "source": "00-gobierno/2025-10-13-acta-constitucion.docx",
 "source_date": "2025-10-13",
 "state": "found"
 },
 "end_date": {
 "value": "2027-01-14",
 "source": "10-plan/2025-10-13-cronograma-v1.xml",
 "source_date": "2025-10-13",
 "state": "found"
 },
 "baseline": [
 {
 "version": 1,
 "approved_on": "2025-10-13",
 "start_date": "2025-10-23",
 "end_date": "2027-01-14",
 "reason": "Aprobación del acta de constitución",
 "source": "00-gobierno/2025-10-13-acta-constitucion.docx"
 }
 ],
 "milestones": [
 {
 "name": "Diseño de la operación aprobado",
 "baseline_date": "2026-02-12",
 "current_date": "2026-02-12",
 "state": "met",
 "evidence": null,
 "source": "10-plan/2025-10-13-cronograma-v1.xml",
 "source_date": "2025-10-13"
 },
 {
 "name": "Permisos de operación obtenidos",
 "baseline_date": "2026-06-04",
 "current_date": "2026-06-04",
 "state": "met",
 "evidence": "20-seguimiento/2026-10-17-acta-recibo-permisos-de-operación-obtenidos.pdf",
 "source": "10-plan/2025-10-13-cronograma-v1.xml",
 "source_date": "2025-10-13"
 },
 {
 "name": "Adecuación de la bodega terminada",
 "baseline_date": "2026-09-24",
 "current_date": "2026-09-24",
 "state": "met",
 "evidence": "20-seguimiento/2026-10-28-acta-recibo-adecuación-de-la-bodega-terminada.md",
 "source": "10-plan/2025-10-13-cronograma-v1.xml",
 "source_date": "2025-10-13"
 },
 {
 "name": "Pruebas con carga real",
 "baseline_date": "2027-01-14",
 "current_date": "2027-01-14",
 "state": "pending",
 "evidence": null,
 "source": "10-plan/2025-10-13-cronograma-v1.xml",
 "source_date": "2025-10-13"
 }
 ],
 "scope_summary": {
 "value": "Componente 1, 2 y 3 (sin detalle)",
 "source": "00-gobierno/2025-10-13-acta-constitucion.docx",
 "source_date": "2025-10-13",
 "state": "found"
 },
 "exclusions": {
 "value": "Lo que otro proyecto cubre",
 "source": "00-gobierno/2025-10-13-acta-constitucion.docx",
 "source_date": "2025-10-13",
 "state": "found"
 }
 },
 "money": {
 "currency": "COP",
 "approved": {
 "value": 18000000000,
 "source": "00-gobierno/2025-10-13-acta-constitucion.docx",
 "source_date": "2025-10-13",
 "state": "found"
 },
 "committed": {
 "value": 9340126765,
 "source": "20-seguimiento/2026-10-28-informe-avance.md",
 "source_date": "2026-10-28",
 "state": "found"
 },
 "executed": {
 "value": 3101575940,
 "source": "20-seguimiento/2026-10-28-informe-avance.md",
 "source_date": "2026-10-28",
 "state": "found"
 },
 "projection": {
 "value": 16752476829,
 "source": "20-seguimiento/2026-10-28-informe-avance.md",
 "source_date": "2026-10-28",
 "state": "found"
 }
 },
 "vendors": [],
 "raid": {
 "risks": [
 {
 "what": "Paros de transportadores en las vías principales",
 "owner": null,
 "source": "20-seguimiento/2026-10-28-informe-avance.md",
 "source_date": "2026-10-28"
 },
 {
 "what": "El proveedor podría no llegar con el equipo completo para la siguiente fase (dicho en reunión, nadie lo registró)",
 "owner": null,
 "source": "2026-10-28-notas-reunion.txt",
 "source_date": "2026-10-28"
 }
 ],
 "assumptions": [],
 "issues": [
 {
 "what": "Un paro de transportadores detuvo los despachos durante seis días",
 "since": null,
 "owner": null,
 "source": "20-seguimiento/2026-10-28-informe-avance.md",
 "source_date": "2026-10-28"
 }
 ],
 "dependencies": []
 },
 "changes": [],
 "commitments": [
 {
 "who": "Beatriz Cuéllar",
 "what": "Enviar el documento 1",
 "due_date": "2027-01-06",
 "original_due_date": "2026-10-06",
 "stated_on": "2026-09-16",
 "source": "30-reuniones/2026-09-16-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-18",
 "stated_on": "2026-09-23",
 "source": "30-reuniones/2026-09-23-comite-semanal.md"
 },
 {
 "due_date": "2026-11-03",
 "stated_on": "2026-09-30",
 "source": "30-reuniones/2026-09-30-comite-semanal.md"
 },
 {
 "due_date": "2026-11-15",
 "stated_on": "2026-10-07",
 "source": "30-reuniones/2026-10-07-comite-semanal.md"
 },
 {
 "due_date": "2026-12-05",
 "stated_on": "2026-10-14",
 "source": "30-reuniones/2026-10-14-comite-semanal.md"
 },
 {
 "due_date": "2026-12-23",
 "stated_on": "2026-10-21",
 "source": "30-reuniones/2026-10-21-comite-semanal.md"
 },
 {
 "due_date": "2027-01-06",
 "stated_on": "2026-10-28",
 "source": "2026-10-28-notas-reunion.txt"
 }
 ],
 "note": "Notas del 2026-10-28: 'no alcanzó, se compromete para el 06/01/2027' (leído día/mes)"
 },
 {
 "who": "Camilo Beltrán",
 "what": "Cerrar la prueba 2",
 "due_date": "2026-12-09",
 "original_due_date": "2026-09-27",
 "stated_on": "2026-09-16",
 "source": "30-reuniones/2026-09-16-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-09",
 "stated_on": "2026-09-23",
 "source": "30-reuniones/2026-09-23-comite-semanal.md"
 },
 {
 "due_date": "2026-10-29",
 "stated_on": "2026-09-30",
 "source": "30-reuniones/2026-09-30-comite-semanal.md"
 },
 {
 "due_date": "2026-11-13",
 "stated_on": "2026-10-07",
 "source": "30-reuniones/2026-10-07-comite-semanal.md"
 },
 {
 "due_date": "2026-12-01",
 "stated_on": "2026-10-14",
 "source": "30-reuniones/2026-10-14-comite-semanal.md"
 },
 {
 "due_date": "2026-12-09",
 "stated_on": "2026-10-21",
 "source": "30-reuniones/2026-10-21-comite-semanal.md"
 }
 ]
 },
 {
 "who": "María Restrepo",
 "what": "Revisar el anexo 3",
 "due_date": "2026-11-26",
 "original_due_date": "2026-10-11",
 "stated_on": "2026-09-16",
 "source": "30-reuniones/2026-09-16-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-25",
 "stated_on": "2026-09-30",
 "source": "30-reuniones/2026-09-30-comite-semanal.md"
 },
 {
 "due_date": "2026-11-06",
 "stated_on": "2026-10-07",
 "source": "30-reuniones/2026-10-07-comite-semanal.md"
 },
 {
 "due_date": "2026-11-26",
 "stated_on": "2026-10-21",
 "source": "30-reuniones/2026-10-21-comite-semanal.md"
 }
 ],
 "note": "Prometido sin fecha el 2026-09-16; la primera fecha (2026-10-11) se dijo el 2026-09-23"
 },
 {
 "who": "Ricardo Salas",
 "what": "Validar el ambiente 4",
 "due_date": "2026-10-05",
 "original_due_date": "2026-10-05",
 "stated_on": "2026-09-16",
 "source": "30-reuniones/2026-09-16-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-09-30-acta-recibo-4.md"
 },
 {
 "who": "Camilo Beltrán",
 "what": "Aprobar el diseño 5",
 "due_date": "2026-09-29",
 "original_due_date": "2026-09-29",
 "stated_on": "2026-09-23",
 "source": "30-reuniones/2026-09-23-comite-semanal.md",
 "state": "open",
 "reschedules": [],
 "note": "2026-09-30: dice que ya lo entregó, no se presentó acta; desaparece de la tabla desde esa reunión"
 },
 {
 "who": "Rubén Cárdenas",
 "what": "Actualizar la matriz 6",
 "due_date": "2026-11-18",
 "original_due_date": "2026-10-19",
 "stated_on": "2026-09-23",
 "source": "30-reuniones/2026-09-23-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-30",
 "stated_on": "2026-10-14",
 "source": "30-reuniones/2026-10-14-comite-semanal.md"
 },
 {
 "due_date": "2026-11-18",
 "stated_on": "2026-10-21",
 "source": "30-reuniones/2026-10-21-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Beatriz Cuéllar",
 "what": "Confirmar la fecha 7",
 "due_date": "2026-11-01",
 "original_due_date": "2026-10-14",
 "stated_on": "2026-09-23",
 "source": "30-reuniones/2026-09-23-comite-semanal.md",
 "state": "met",
 "reschedules": [
 {
 "due_date": "2026-11-01",
 "stated_on": "2026-10-07",
 "source": "30-reuniones/2026-10-07-comite-semanal.md"
 }
 ],
 "evidence": "20-seguimiento/2026-10-14-acta-recibo-7.md"
 },
 {
 "who": "Mauricio Pérez",
 "what": "Entregar el punto 8",
 "due_date": "2026-10-02",
 "original_due_date": "2026-10-02",
 "stated_on": "2026-09-23",
 "source": "30-reuniones/2026-09-23-comite-semanal.md",
 "state": "open",
 "reschedules": [],
 "note": "2026-10-14: dice que ya lo entregó, no se presentó acta; desaparece de la tabla desde esa reunión"
 },
 {
 "who": "Carlos Peña",
 "what": "Enviar el documento 9",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-09-30",
 "source": "30-reuniones/2026-09-30-comite-semanal.md",
 "state": "open",
 "reschedules": [],
 "note": "2026-10-07: dice que ya lo entregó, no se presentó acta; desaparece de la tabla"
 },
 {
 "who": "Felipe Arango",
 "what": "Cerrar la prueba 10",
 "due_date": "2026-10-26",
 "original_due_date": "2026-10-26",
 "stated_on": "2026-09-30",
 "source": "30-reuniones/2026-09-30-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-10-21-acta-recibo-10.md"
 },
 {
 "who": "Jorge Medina",
 "what": "Revisar el anexo 11",
 "due_date": "2026-10-14",
 "original_due_date": "2026-10-14",
 "stated_on": "2026-09-30",
 "source": "30-reuniones/2026-09-30-comite-semanal.md",
 "state": "open",
 "reschedules": [],
 "note": "2026-10-07: dice que ya lo entregó, no se presentó acta; desaparece de la tabla"
 },
 {
 "who": "Rubén Cárdenas",
 "what": "Validar el ambiente 12",
 "due_date": "2026-10-08",
 "original_due_date": "2026-10-08",
 "stated_on": "2026-09-30",
 "source": "30-reuniones/2026-09-30-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-10-21-acta-recibo-12.md"
 },
 {
 "who": "Andrés Lozano",
 "what": "Aprobar el diseño 13",
 "due_date": "2026-10-28",
 "original_due_date": "2026-10-11",
 "stated_on": "2026-10-07",
 "source": "30-reuniones/2026-10-07-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-28",
 "stated_on": "2026-10-21",
 "source": "30-reuniones/2026-10-21-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Beatriz Cuéllar",
 "what": "Actualizar la matriz 14",
 "due_date": "2026-10-26",
 "original_due_date": "2026-10-26",
 "stated_on": "2026-10-07",
 "source": "30-reuniones/2026-10-07-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-10-14-acta-recibo-14.md"
 },
 {
 "who": "Paula Céspedes",
 "what": "Confirmar la fecha 15",
 "due_date": "2026-10-25",
 "original_due_date": "2026-10-25",
 "stated_on": "2026-10-07",
 "source": "30-reuniones/2026-10-07-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-10-14-acta-recibo-15.md"
 },
 {
 "who": "Elena Duarte",
 "what": "Entregar el punto 16",
 "due_date": "2026-10-17",
 "original_due_date": "2026-10-17",
 "stated_on": "2026-10-07",
 "source": "30-reuniones/2026-10-07-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-10-21-acta-recibo-16.md"
 },
 {
 "who": "María Restrepo",
 "what": "Enviar el documento 17",
 "due_date": "2026-10-31",
 "original_due_date": "2026-10-31",
 "stated_on": "2026-10-14",
 "source": "30-reuniones/2026-10-14-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-10-21-acta-recibo-17.md"
 },
 {
 "who": "Andrés Lozano",
 "what": "Cerrar la prueba 18",
 "due_date": "2026-10-18",
 "original_due_date": "2026-10-18",
 "stated_on": "2026-10-14",
 "source": "30-reuniones/2026-10-14-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Paula Céspedes",
 "what": "Revisar el anexo 19",
 "due_date": "2026-11-10",
 "original_due_date": "2026-11-10",
 "stated_on": "2026-10-14",
 "source": "30-reuniones/2026-10-14-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-10-21-acta-recibo-19.md"
 },
 {
 "who": "Ricardo Salas",
 "what": "Validar el ambiente 20",
 "due_date": "2026-10-23",
 "original_due_date": "2026-10-23",
 "stated_on": "2026-10-14",
 "source": "30-reuniones/2026-10-14-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Natalia Ospina",
 "what": "Aprobar el diseño 21",
 "due_date": "2026-11-13",
 "original_due_date": "2026-11-13",
 "stated_on": "2026-10-21",
 "source": "30-reuniones/2026-10-21-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Laura Vélez",
 "what": "Actualizar la matriz 22",
 "due_date": "2026-10-28",
 "original_due_date": "2026-10-28",
 "stated_on": "2026-10-21",
 "source": "30-reuniones/2026-10-21-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Elena Duarte",
 "what": "Confirmar la fecha 23",
 "due_date": "2026-11-06",
 "original_due_date": "2026-11-06",
 "stated_on": "2026-10-21",
 "source": "30-reuniones/2026-10-21-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Javier Hoyos",
 "what": "Entregar el punto 24",
 "due_date": "2026-11-08",
 "original_due_date": "2026-11-08",
 "stated_on": "2026-10-21",
 "source": "30-reuniones/2026-10-21-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Laura Vélez",
 "what": "Mandar el ajuste del presupuesto",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-10-28",
 "source": "2026-10-28-notas-reunion.txt",
 "state": "open",
 "reschedules": [],
 "note": "Notas del 2026-10-28: 'la otra semana'; sin fecha"
 },
 {
 "who": "Óscar Ramírez",
 "what": "Revisión con el proveedor",
 "due_date": "2026-11-07",
 "original_due_date": "2026-11-07",
 "stated_on": "2026-10-28",
 "source": "2026-10-28-notas-reunion.txt",
 "state": "open",
 "reschedules": []
 }
 ],
 "meta": {
 "record_updated": "2026-10-28",
 "documents_seen": [],
 "fields_not_found": [
 "identity.authority",
 "identity.phase"
 ],
 "open_conflicts": [],
 "sealed": false,
 "read_scope": "las 6 minutas del comité (2026-09-16 a 2026-10-21), las notas del 2026-10-28, 10 actas de recibo, informe de avance, acta de constitución y cronograma"
 }
}
