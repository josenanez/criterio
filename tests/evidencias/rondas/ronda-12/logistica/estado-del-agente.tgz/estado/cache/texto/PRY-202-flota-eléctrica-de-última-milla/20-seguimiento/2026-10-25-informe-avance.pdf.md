<!-- origen: PRY-202-flota-eléctrica-de-última-milla/20-seguimiento/2026-10-25-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Flota eléctrica de última milla
Código: PRY-202
Fecha de corte: 2026-10-25
Gerente: Sandra Gil

Estado declarado
Amarillo
Avance reportado: 80%

Lo que pasó en el periodo
- Un paro de transportadores detuvo los despachos durante seis días
- Se recibió el concepto de la autoridad aduanera sobre la bodega
- Se acordó con operaciones cómo se mide el nivel de servicio de cada ruta

Presupuesto
COP
Aprobado 9.500.000.000
Comprometido 2.718.494.817
Ejecutado 5.644.787.990
Proyección al cierre 9.926.714.164

Riesgos abiertos
- Concentración del conocimiento en una sola persona
- Cambio en la norma de pesos y dimensiones que puede mover el alcance
