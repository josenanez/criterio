<!-- origen: PRY-206-clasificadora-automática-de-paquetes/20-seguimiento/2026-10-25-solicitud-cambio-cc-01.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-01

**Proyecto:** PRY-206 · Clasificadora automática de paquetes
**Fecha:** 2026-10-25
**Solicitante:** Gustavo Neira

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +94 días sobre la línea base vigente |
| Costo | 188.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
