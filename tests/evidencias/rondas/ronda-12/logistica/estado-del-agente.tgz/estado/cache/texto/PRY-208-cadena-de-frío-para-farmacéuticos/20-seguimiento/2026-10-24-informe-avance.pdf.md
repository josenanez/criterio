<!-- origen: PRY-208-cadena-de-frío-para-farmacéuticos/20-seguimiento/2026-10-24-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Cadena de frío para farmacéuticos
Código: PRY-208
Fecha de corte: 2026-10-24
Gerente: Sandra Gil

Estado declarado
Verde
Avance reportado: 43%

Lo que pasó en el periodo
- La prueba de exactitud de inventario no alcanzó el valor pactado y se repite
- Se reprogramó la llegada de las estanterías por demoras del importador

Presupuesto
COP
Aprobado 6.800.000.000
Comprometido 2.354.740.734
Ejecutado 3.920.161.615
Proyección al cierre 6.668.978.882

Riesgos abiertos
- Concentración del conocimiento en una sola persona
