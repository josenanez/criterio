<!-- origen: PRY-200-centro-de-distribución-del-norte/10-plan/2026-04-12-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la operación aprobado | 2026-08-27 | 2026-08-27 | cerrado
Permisos de operación obtenidos | 2027-01-02 | 2027-01-02 | en curso
Adecuación de la bodega terminada | 2027-05-09 | 2027-05-09 | en curso
Pruebas con carga real | 2027-09-14 | 2027-09-14 | en curso
