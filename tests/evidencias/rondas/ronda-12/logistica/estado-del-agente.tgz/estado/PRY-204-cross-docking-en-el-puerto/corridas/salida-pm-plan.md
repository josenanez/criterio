# Plan — PRY-204 Cross docking en el puerto · borrador del 2026-10-28
**Desde:** acta de constitución del 2025-10-13 (`00-gobierno/2025-10-13-acta-constitucion.docx`) · **Criterio de éxito:** «Cross docking en el puerto en producción y medido.» (acta). No dice medido contra qué, ni quién lo mide.

*Contexto que cambia la lectura:* el proyecto no está arrancando. El acta tiene un año, el informe del 2026-10-28 declara 53 % y verde, y ya existe el cronograma v1 (línea base 1, 2025-10-13). Este borrador es una re-descomposición sobre el acta, no el plan original. No crea línea base nueva.

## Lo que le falta al acta
| Qué | Consecuencia de planificar sin eso |
|---|---|
| **Alcance sin contenido:** «Componente 1 / 2 / 3» y nada más | No hay entregables que descomponer. Los nodos terminales de abajo no salen del acta; quedan «sin definir». Es el hueco más caro. |
| **Fuera de alcance:** «Lo que otro proyecto cubre» (sin decir cuál) | No se puede trazar la frontera con otro proyecto. Cualquier nodo dudoso puede ser de este o del otro. |
| **Criterio de éxito sin métrica:** «en producción y medido» | No se sabe qué entra ni qué cuenta como «medido»; el último hito del cronograma (pruebas con carga real) no equivale a «en producción y medido». |
| **Autoridad no declarada en el acta** (la configuración dice Comité de Inversiones, pero eso lo puso el setup, no el acta) | No se sabe qué puede decidir la gerente al planificar y qué debe subir. |
| **Patrocinador = gerente** (Liliana Torres en ambos roles) | No hay un patrocinador distinto a quien llevar excepciones; solo queda el Comité. |
| **Dependencias: «Ninguna declarada»**, pero las notas del 2026-10-28 hablan de un proveedor y el informe de un «cliente ancla» | El plan nace sin las dependencias externas que ya se mencionan. Ni proveedor ni cliente ancla están en el acta. |
| **Quién acepta cada entregable:** no figura en ningún sitio | Los nodos terminales no tienen aceptante verificable (ver WBS). |

## WBS
| # | Entregable | Quién lo acepta | De dónde sale | Duración |
|---|---|---|---|---|
| 1 | Diseño de la operación aprobado | sin definir | Supuesto (cronograma v1, hito; no está en el acta) | vacía |
| 2 | Permisos de operación obtenidos | sin definir (la autoridad que los emite, no consta) | Supuesto (cronograma v1; hay acta de recibo en PDF) | vacía |
| 3 | Adecuación de la bodega terminada | sin definir | Supuesto (cronograma v1; hay acta de recibo del 2026-10-28) | vacía |
| 4 | Pruebas con carga real | sin definir | Supuesto (cronograma v1) | vacía |
| 5 | Componente 1 | sin definir | Sin definir (el acta solo dice «Componente 1») | vacía |
| 6 | Componente 2 | sin definir | Sin definir | vacía |
| 7 | Componente 3 | sin definir | Sin definir | vacía |
| 8 | Cross docking en producción | sin definir | Del acta (criterio de éxito: «en producción»), sin detalle | vacía |
| 9 | Medición de resultados del cross docking | sin definir | Del acta («y medido»); qué se mide y contra qué es sin definir | vacía |

Notas: no sé si los componentes 1–3 se solapan con los hitos 1–4 o son otra cosa; no los mapeo por lo razonable. Las fechas de línea base del cronograma v1 existen para los hitos 1–4, pero son fechas, no duraciones, y no las traigo aquí como estimación.

## Orden
- 1 → 2 → 3 → 4: así lo encadena el cronograma v1 (cada hito es predecesor del siguiente).
- 8 necesita presumiblemente 4, y 9 necesita 8: es lo que dice el criterio de éxito leído en orden, pero **ningún documento lo enlaza**; es un supuesto.
- 5, 6, 7: no se puede ordenar nada sin saber qué son. Sin definir.
- Sin fechas.

## Supuestos sobre los que está construido
| Supuesto | Qué pasa si resulta falso |
|---|---|
| Los 4 hitos del cronograma v1 son el esqueleto de entregables del proyecto | Si los componentes 1–3 son otra cosa, la WBS omite trabajo que sí está en alcance. |
| «En producción» y «medido» son entregables propios (nodos 8 y 9), posteriores a las pruebas | Si el proyecto termina en las pruebas, el criterio de éxito del acta pide más de lo que el plan construye. |
| El orden 4 → 8 → 9 | Si producción puede ir en paralelo con pruebas, la ruta cambia. |
| El proveedor mencionado en las notas pertenece a este proyecto y su fase siguiente está dentro del alcance | Si es de otro proyecto (el «otro proyecto» de las exclusiones), el riesgo de equipo incompleto no es de este plan. |
| La gerente puede aprobar este plan sin pasar por el Comité | El acta no lo dice; si hay que subirlo, el borrador no sirve como plan aprobado. |

## Sin definir
| Qué | Quién lo define |
|---|---|
| Contenido de los componentes 1, 2 y 3 | Quien escribió el acta o el Comité de Inversiones; el acta no lo nombra |
| Qué proyecto cubre lo «fuera de alcance» | Comité de Inversiones / PMO |
| Qué significa «medido» (indicador, línea de base, quién lo mide) | Área dueña (Seguridad y Salud en el Trabajo) y patrocinador |
| Quién acepta cada entregable | Patrocinador; hoy es la misma persona que la gerente |
| Qué puede decidir la gerente sin subir | Comité de Inversiones |
| Rol del proveedor y del «cliente ancla» en el alcance | Gerente con el Comité; no hay contrato ni dependencia declarada en la carpeta |

## Proyectos análogos
Ninguno a la vista. La configuración no apunta a una carpeta de fichas de la PMO, y la única ficha disponible es la de este mismo proyecto. Esa es la respuesta correcta: no hay estimación por analogía y no la invento. (Dato propio, no análogo: el cronograma v1 tiene una sola línea base, sin replanificaciones registradas.)

## Preguntas para el equipo
1. ¿Qué entregables concretos son los componentes 1, 2 y 3 y quién recibe cada uno? ¿Cuánto toma cada uno?
2. ¿Cuánto toma pasar de pruebas con carga real a «en producción»?
3. ¿Cuánto toma la medición, qué se mide y cuánto tiempo hace falta observar para decir «medido»?
4. ¿Cuánto toma el trabajo que falta de los hitos 1–4 que aún no tiene cierre pleno (las pruebas están al 50 % según el cronograma)?
5. ¿Qué proyecto cubre lo que el acta deja fuera y dónde está el borde?
6. ¿El proveedor y el cliente ancla están dentro del alcance? ¿Con qué contrato y qué fecha?
7. ¿Quién acepta las pruebas, producción y la medición?
8. ¿Qué parte de la «siguiente fase» depende de que el proveedor llegue con el equipo completo?

## Para comprometer una fecha falta
- La disponibilidad real del equipo (no hay asignaciones en ningún documento).
- La fecha y el compromiso del proveedor para la siguiente fase (no hay contrato en la carpeta; las notas dicen que podría no llegar completo).
- La ventana de la sala de producción / operación del puerto, y la fecha del cliente ancla.
- Además: el contenido de los componentes y la definición de «medido». Sin eso no hay qué fechar.

## Después
Cuando el plan se apruebe: registrarlo como línea base (la original ya es la de 2025-10-13; esta sería una vigente, sin borrar la anterior) y pasar los supuestos al RAID con doliente. Hoy el RAID tiene dos riesgos y un incidente sin doliente y cero supuestos.
