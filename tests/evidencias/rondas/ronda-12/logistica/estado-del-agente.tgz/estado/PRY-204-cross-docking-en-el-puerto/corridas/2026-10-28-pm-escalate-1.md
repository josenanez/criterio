# Corrida del 2026-10-28 · pm-escalate

1 proyectos · 41 s · 13 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_overdue` | 5 |
| `commitment_rescheduled` | 3 |
| `commitment_undated` | 2 |
| `progress_vs_plan` | 1 |
| `milestone_met_without_evidence` | 1 |
| `declared_vs_evidence` | 1 |

Dos puntos de decisión: (1) autoridad de la gerente no declarada en el acta; (2) documento 1 (6 reprogramaciones) y prueba 2 (5). Sin costos de opciones en el expediente; impact no corrido (no hay días ni dependencias declaradas); relación con el hito Pruebas con carga real sin confirmar.

Contra la corrida del 2026-10-28: +0 hallazgos.

## Lo que produjo

## Para decisión — Cross docking en el puerto (PRY-204) · 2026-10-28

**Términos:** vigentes (v1.3), aceptados por José Francisco Ñáñez el 2026-10-28; no hizo falta registrarlos de nuevo.

Sin argumento, tomé lo que ya estaba marcado como escalable: la agenda del 11-04 deja dos cosas fuera de la reunión por exceder la autoridad del gerente (Beatriz y Camilo). Antes de formularlas, el acta manda un primer punto.

---

### Punto 1 — ¿Qué puede decidir la gerente del proyecto?

**Pregunta cerrada:** ¿El Comité de Inversiones declara por escrito, como adenda al acta del 2025-10-13, lo que la gerente puede decidir sin subir al comité (reasignar responsables, mover fechas de compromisos, recortar alcance, comprometer presupuesto)? *Sí / No.*

**Quién decide:** Comité de Inversiones (aprobó el acta y el presupuesto) · **Si no se decide hoy:** el 2026-11-04 (próximo comité) el punto 2 llega sin que nadie pueda decir si le toca a la gerente o al comité, y se devuelve. Beatriz Cuéllar y Camilo Beltrán siguen reprogramando mientras tanto: 2 y 3 semanas por reunión.

**Por qué es el primero:** el acta no declara la autoridad de la gerente. Tiene Comité, patrocinador y gerente, pero ningún límite de decisión. Además el patrocinador y la gerente son la misma persona (Liliana Torres), así que no hay una instancia intermedia que la declare por omisión. Un gerente que no sabe qué puede decidir escala todo o no escala nada.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Sí: adenda al acta con los límites de la gerente | Sin cambio | Una sesión del comité; no hay fecha comprometida para la adenda | No está en el expediente |
| B. No: el comité decide cada caso | Sin cambio | Cada reasignación o fecha movida espera al comité semanal (siguiente: 2026-11-04) | No está en el expediente |

**Recomiendo:** A. Con B, un compromiso reprogramado seis veces tarda una semana más en cada decisión, y ese es justo el patrón que hoy no se corta.

---

### Punto 2 — Qué hacer con el documento 1 (Beatriz) y la prueba 2 (Camilo)

**Pregunta cerrada:** Para el documento 1 y la prueba 2, ¿se autoriza que la gerente **reasigne** el entregable a otro responsable si el 2026-11-04 el dueño actual no nombra por escrito qué lo bloquea y una fecha con acta de recibo? *Sí / No / Recortar el alcance de esos dos entregables.*

**Quién decide:** no se puede decir según el acta (ver punto 1). Si la adenda del punto 1 le da la facultad de reasignar a la gerente, es de ella y no se sube. Si no, es del Comité de Inversiones. · **Si no se decide hoy:** el 2026-11-04. Otro corrimiento de 2 o 3 semanas del documento 1 desde el 2027-01-06 cruza el cierre comprometido (2027-01-14), que está 8 días después de esa fecha.

**Lo que dice el expediente (cifras calculadas de las fechas citadas):**
- Documento 1 (Beatriz Cuéllar): 6 reprogramaciones, de 2026-10-06 a 2027-01-06 (92 días) y ninguna con motivo registrado. La fecha de las notas del 10-28 es «06/01/2027», que leí día/mes; en mes/día sería 2027-06-01, cinco meses después del cierre.
- Prueba 2 (Camilo Beltrán): 5 reprogramaciones, de 2026-09-27 a 2026-12-09 (73 días).
- Diseño 5 (Camilo): vencido desde 2026-09-29; dijo el 09-30 que ya lo entregó y no hay acta.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Mantener a los responsables y exigir bloqueo + fecha con acta el 11-04 | Sin cambio | Sin cambio en el plan; el documento 1 queda a 8 días del cierre | No está en el expediente |
| B. Reasignar el entregable | Sin cambio | No está en el expediente: no sé cuánto tarda otra persona en empezar | No está en el expediente |
| C. Recortar el alcance de esos entregables | Menor, sin definir qué sale | No está en el expediente | No está en el expediente |

**Recomiendo:** A hasta el 2026-11-04 y B si ese día no hay bloqueo nombrado ni acta. Con 6 y 5 reprogramaciones sin motivo, otra fecha sin motivo no informa nada; lo que se necesita saber es de qué depende cada uno. C no la recomiendo porque no hay de dónde sacar qué recortar: el acta lista «Componente 1, 2 y 3» sin detalle.

---

### A quién alcanza

No calculé el efecto con `impact`. Ese cálculo parte de un cambio de fecha en días y aquí no hay ninguno decidido: lo que se pregunta es quién ejecuta, no cuánto se mueve el cierre. Tampoco hay en el expediente otros proyectos ni dependencias: el acta dice «Ninguna declarada», así que no puedo decir qué proyectos alcanza. Si el comité decide mover una fecha, el cálculo se corre con esos días.

| Proyecto | Gerente | ¿Sostiene su fecha? | Dependencia confirmada |
|---|---|---|---|
| Sin datos: ninguna dependencia declarada | — | — | — |

### Mis hitos por los que pasa

No sé cuáles. El cronograma tiene el hito «Pruebas con carga real» (2027-01-14, pendiente) y la ficha no dice de qué entregables depende. Esa relación del documento 1 y la prueba 2 con el hito queda sin confirmar: es una pregunta para Liliana Torres antes del comité.

| Hito | Fecha vigente | En cuántos días |
|---|---|---|
| Pruebas con carga real (relación con documento 1 y prueba 2: no confirmada) | 2027-01-14 | Sin calcular |

### Lo que este paquete no sabe

- Los costos de las opciones: no están en ningún documento del expediente.
- Qué bloquea a Beatriz y a Camilo. Nadie lo registró.
- Si el comité es el 11-04 (configuración) o el 11-11 (las notas del 10-28 dicen «en dos semanas»).
- El hito «Diseño de la operación aprobado» figura cumplido sin acta; es un tema para `/pm-report`, no de este paquete.

### De dónde sale esto
- Autoridad no declarada, comité, patrocinador = gerente, cierre 2027-01-14, «Ninguna declarada» en dependencias: `00-gobierno/2025-10-13-acta-constitucion.docx` y `10-plan/2025-10-13-cronograma-v1.xml`.
- Reprogramaciones del documento 1 y la prueba 2, diseño 5: minutas `30-reuniones/2026-09-16` a `2026-10-21-comite-semanal.md` y `2026-10-28-notas-reunion.txt`, líneas 4 y 8.
- Qué excede la autoridad: `estado/…/corridas/salida-pm-agenda.md`, sección «No es de esta reunión».
- Días entre fechas: cálculo mío sobre las fechas de la ficha (`records/PRY-204.json`).

### Después
Este paquete no escala solo: llevarlo al comité es de Liliana Torres. Si el comité decide, la decisión con su fecha y documento entra a la ficha.
