# Cross docking en el puerto (PRY-204) — semana del 2026-10-21 al 2026-10-28

*Sesión sin interfaz: nadie respondió la pregunta de la declaración. No se propuso ningún estado. Se tomó como declaración la que la gerente ya dejó escrita en su informe de avance de hoy.*

**Declara la gerente (Liliana Torres):** Verde · 53 % · al 2026-10-28 (`20-seguimiento/2026-10-28-informe-avance.md`)
**Sustento documental:** contradicho
**Lo que el semáforo no explica:** compromisos vencidos, compromisos reprogramados, hito dado por cumplido sin evidencia, avance declarado por debajo de lo que el plan ya exige.

## Qué cambió esta semana
No hay corrida anterior contra la cual comparar: esta es la primera, el diff sale vacío (0 cambios). Todo lo que sigue es el estado de partida, no una variación.

## Lo que sigue igual y sigue mal
Sin corrida previa no se pueden contar los días «así» de cada cosa; se muestran los días contra su fecha de vencimiento.

| Qué | Desde | Días así |
|---|---|---|
| Hito «Diseño de la operación aprobado» marcado cumplido, sin documento | vencía 2026-02-12 | 258 |
| Camilo Beltrán — Aprobar el diseño 5 | 2026-09-29 | 29 |
| Mauricio Pérez — Entregar el punto 8 | 2026-10-02 | 26 |
| Jorge Medina — Revisar el anexo 11 | 2026-10-14 | 14 |
| Andrés Lozano — Cerrar la prueba 18 | 2026-10-18 | 10 |
| Ricardo Salas — Validar el ambiente 20 | 2026-10-23 | 5 |

## Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2027-01-14 | 2027-01-14 | 0 días |
| Presupuesto | 18.000.000.000 COP | 18.000.000.000 COP | proyección 16.752.476.829 (−6,9 %) |

Replanificaciones: 0. Una sola línea base (v1, aprobada 2025-10-13). Cero desviación en fechas con tres de cuatro hitos «cumplidos» y un avance de 53 %: el plan dice que a hoy debería haber entre 75 % y 100 %; la brecha es de 22 puntos. Que no haya replanificación no prueba que vaya a tiempo: ninguna fecha se ha movido, pero el avance no la acompaña.

### Hitos de las próximas cuatro semanas
| Hito | Base | Vigente | Evidencia |
|---|---|---|---|
| (ninguno en las próximas cuatro semanas) | | | |

Siguiente hito: «Pruebas con carga real», 2027-01-14, pendiente. Hitos ya cumplidos: «Permisos de operación obtenidos» (2026-06-04, con acta de recibo) y «Adecuación de la bodega terminada» (2026-09-24, con acta de recibo); «Diseño de la operación aprobado» figura cumplido sin documento.

## Las cifras (COP)
| Aprobado | Comprometido | Ejecutado | Proyectado | Disponible real |
|---|---|---|---|---|
| 18.000.000.000 | 9.340.126.765 (51,9 %) | 3.101.575.940 (17,2 %) | 16.752.476.829 | 8.659.873.235 |

Disponible real = aprobado − comprometido (no aprobado − ejecutado, que daría 14.898.424.060).

## Abierto
**Reprogramados:**
- Beatriz Cuéllar — Enviar el documento 1: 6 veces, original 2026-10-06, hoy 2027-01-06.
- Camilo Beltrán — Cerrar la prueba 2: 5 veces, original 2026-09-27, hoy 2026-12-09.
- María Restrepo — Revisar el anexo 3: 3 veces, original 2026-10-11, hoy 2026-11-26.

**Vencidos sin evidencia:** los cinco de la tabla de arriba.
**Sin fecha:** Carlos Peña — Enviar el documento 9 (comité 2026-09-30); Laura Vélez — Mandar el ajuste del presupuesto (notas 2026-10-28).
**RAID sin movimiento:** el único riesgo del informe (paros de transportadores) no trae fecha ni dueño; no se pudo medir su antigüedad.
**Proveedor:** sin proveedores registrados.

## Lo que necesito de alguien
- Liliana Torres: decir si mantiene el verde frente a las cuatro señales de arriba, o corregirlo. La decisión es suya.
- Camilo Beltrán y Beatriz Cuéllar: dos compromisos con 5 y 6 reprogramaciones; superan el umbral de 3 y son material de comité (el Comité de Inversiones es la autoridad declarada, pero en la ficha figura sin autoridad).
- Quien aprobó el diseño de la operación: aportar el documento que sustente el hito de febrero.
- Laura Vélez y Carlos Peña: poner fecha a sus compromisos.

## Lo que no se sabe
**Sin dato:** autoridad del proyecto (`identity.authority`) y fase (`identity.phase`). Trece campos de identidad y plan vienen del acta de 2025-10-13 y tienen 12 meses de antigüedad.
**Silencio:** último documento hace 0 días (informe de avance y acta de recibo, 2026-10-28) · última reunión hace 0 días (notas del 2026-10-28; último comité formal, 2026-10-21, hace 7 días).

---
Origen: ficha de PRY-204, corte 2026-10-28, 2 campos sin dato. Fuentes sin marcar como evidencia o declaración: 15 de 15. Términos v1.3 aceptados por José Francisco Ñáñez el 2026-10-28: https://www.josenanez.com/es/agents/criterio-pmo/legal

**Siguiente paso posible:** hay dos compromisos reprogramados más de tres veces y la declaración quedó contradicha por la evidencia; ofrezco armar el punto de comité con la decisión formulada y publicar la ficha con `/pm-publish`.
