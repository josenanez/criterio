# Acta — Cross docking en el puerto (PRY-204) · 2026-10-28

**Asistieron:** Andrés Lozano, Beatriz Cuéllar, Camilo Beltrán, Elena Duarte, Javier Hoyos, Laura Vélez, Liliana Torres, María Restrepo, Natalia Ospina, Ricardo Salas, Rubén Cárdenas, Óscar Ramírez · **Fuente:** `2026-10-28-notas-reunion.txt` (notas de 5 líneas, no transcripción) · **Ausentes con tema en agenda:** ninguno de los que hablaron. Siguen ausentes, con compromisos abiertos sin acta y sin que la reunión los tocara: Mauricio Pérez (punto 8), Jorge Medina (anexo 11), Carlos Peña (documento 9, sin fecha).

**Términos:** vigentes (v1.3), aceptados por José Francisco Ñáñez el 2026-10-28; no hizo falta registrarlos de nuevo.

## Compromisos
| Quién | Qué | Para cuándo | |
|---|---|---|---|
| Beatriz Cuéllar | Enviar el documento 1 («no alcanzó, se compromete para el 06/01/2027», nota línea 4) | 2027-01-06 (*leído día/mes, ver «Sin resolver»*) | **Reprogramado 6 veces.** Original 2026-10-06 → 10-18 → 11-03 → 11-15 → 12-05 → 12-23 → 2027-01-06. Misma persona, misma promesa: no es compromiso nuevo |
| Óscar Ramírez | Revisión con el proveedor («queda para el 2026-11-07», línea 6) | 2026-11-07 (sábado) | Nuevo. Primera aparición de Óscar en el proyecto |

### Sin fecha
| Quién | Qué |
|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto («la otra semana», línea 5). Sin fecha: no se le inventó una |

## Decisiones
Ninguna. Las notas no registran ninguna decisión con quién la tomó y qué se descartó.

## Quedó sin decidir
Las notas no dicen qué quedó abierto de forma explícita. Lo único cercano es el riesgo del proveedor (abajo): se comentó, y nadie decidió registrarlo ni tratarlo.

## Intenciones sin doliente
Ninguna en estas notas.

## Dicho al pasar y no registrado
| Qué | Quién lo dijo | Categoría | Ya estaba en el RAID |
|---|---|---|---|
| «El proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo» (línea 7) | No atribuido: «se comentó». Las notas no dicen quién | Riesgo (de proveedor / recursos) | **No.** Ni en las 6 minutas anteriores ni en el informe de avance del 10-28, que solo lista paros de transportadores. Entra a la ficha sin dueño |

## Cerrado en esta reunión
Nada. Las notas no citan ningún documento que cierre algo. Las actas de recibo del 10-28 (adecuación de la bodega) y del 10-17 (permisos) son hitos del cronograma, no cierres de esta reunión.

## Lo que esta reunión contradice
| Campo | Dijo la reunión | Dice el expediente | Fuente y fecha de cada uno |
|---|---|---|---|
| Cadencia del comité | «Próxima reunión en dos semanas» (≈ 2026-11-11) | Comité semanal; próximo 2026-11-04 (configuración) | Notas 2026-10-28 · `config.json` |

No cambió el patrocinador, la fecha de cierre ni el comité de gobierno. Sin contradicciones de campos de la ficha.

## Sin resolver de la transcripción
- «se compromete para el **06/01/2027**»: se leyó 6 de enero de 2027 (día/mes), coherente con la serie anterior (…12-23 → 01-06, pasos de 2 a 3 semanas). En formato mes/día sería 1 de junio de 2027. Confirmar con Beatriz Cuéllar.
- «Óscar Ramírez: revisión con el proveedor, queda para el 2026-11-07»: no queda claro si Óscar hace la revisión o si solo se agendó. Se registró como compromiso suyo. El 11-07 es sábado.
- «Laura Vélez queda de mandar el ajuste del presupuesto la otra semana»: «otra semana» podría ser la del 11-02, pero no es una fecha.
- «Beatriz Cuéllar dice que lo de “enviar el documento 1” no alcanzó»: las notas no dan motivo.

## Recálculo (`compute`)
Sin `record_issues`. Con lo que entró: 5 vencidos sin acta (Camilo Beltrán 29 días, Mauricio Pérez 26, Jorge Medina 14, Andrés Lozano 10, Ricardo Salas 5), 2 sin fecha (Carlos Peña, Laura Vélez), 3 reprogramados 3 veces o más (Beatriz Cuéllar 6, Camilo Beltrán 5, María Restrepo 3). El informe declara verde 53% y el cálculo lo contradice: el plan sustenta 75–100% (3 de 4 hitos), y «Diseño de la operación aprobado» está declarado cumplido sin acta. Dos compromisos vencen hoy y las notas no los mencionan: Andrés Lozano (diseño 13, ya movido una vez) y Laura Vélez (matriz 22).

## Siguiente
`/pm-commitments` para el seguimiento completo. `/pm-publish` no es necesario por contradicciones de campos, pero la ficha ya incorpora el riesgo del proveedor y el compromiso de Beatriz reprogramado por sexta vez; si la PMO debe enterarse, publica. El acta no se escribió en la carpeta de reuniones: guárdala tú.
