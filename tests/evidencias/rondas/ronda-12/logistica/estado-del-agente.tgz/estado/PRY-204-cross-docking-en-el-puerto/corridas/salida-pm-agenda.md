## Reunión de seguimiento — Cross docking en el puerto (PRY-204) · 2026-11-04
8 puntos · 35 minutos (de 40 disponibles; no hay duración configurada, supuse 40) · 8 personas requeridas

**Términos:** vigentes (v1.3), aceptados por José Francisco Ñáñez el 2026-10-28; no hizo falta registrarlos de nuevo.

**Antes de convocar:** las notas del 10-28 dicen «próxima reunión en dos semanas» (≈ 11-11); la configuración dice comité semanal, próximo 2026-11-04. Esta agenda es para el 11-04. Si la reunión es el 11-11, los puntos de abajo se mantienen y envejecen una semana más.

**Qué no pude comparar:** `diff` no tiene snapshot previo (primera corrida), así que no puedo decir qué cambió desde la reunión anterior. La agenda sale del estado de la ficha al 2026-10-28, no de un diff. Y las reprogramaciones y vencimientos se cuentan al 10-28: si hubo movimiento entre el 10-28 y el 11-04, no está en el expediente.

### Lo que no se destraba solo

> **1. Que Beatriz diga qué bloquea el documento 1 y confirme la fecha (6 de enero o 1 de junio de 2027)** · 6 min · **Beatriz Cuéllar**
> Prometido para el 2027-01-06, y antes para el 12-23, 12-05, 11-15, 11-03, 10-18 y 10-06. Seis reprogramaciones, ninguna con motivo registrado.
> Fuente: notas 2026-10-28 y minutas del comité 09-23, 09-30, 10-07, 10-14, 10-21. La fecha «06/01/2027» se leyó día/mes; en mes/día sería 2027-06-01.
> **Si no se resuelve hoy:** sigue corriendo de 2 a 3 semanas por reunión sin que nadie sepa de qué depende.

> **2. Que Camilo diga qué bloquea la prueba 2 y entregue el acta del diseño 5** · 7 min · **Camilo Beltrán**
> Prueba 2: prometida para el 12-09, y antes para el 12-01, 11-13, 10-29, 10-09 y 09-27 (cinco reprogramaciones). Diseño 5: vencido desde el 09-29 (36 días al 11-04); dijo el 09-30 que ya lo entregó y no hay acta.
> Fuente: minutas del comité 09-16, 09-23, 09-30, 10-07, 10-14, 10-21.
> **Si no se resuelve hoy:** la prueba 2 sigue moviéndose y el diseño 5 sigue sin existir en el expediente.

> **3. Que María diga qué necesita para revisar el anexo 3** · 4 min · **María Restrepo**
> Prometido para el 11-26, y antes para el 11-06, 10-25 y 10-11. Tres reprogramaciones.
> Fuente: minutas del comité 09-23, 09-30, 10-07, 10-21.
> **Si no se resuelve hoy:** la fecha del 11-26 se vuelve la cuarta.

### Vencido sin evidencia
| Quién | Qué | Desde | Qué se necesita hoy | Min |
|---|---|---|---|---|
| Andrés Lozano | Cerrar la prueba 18 | 2026-10-18 | Acta de recibo o nueva fecha con motivo. Además, «Aprobar el diseño 13» (movido del 10-11 al 10-28) no tiene acta al 10-28 | 4 |
| Ricardo Salas | Validar el ambiente 20 | 2026-10-23 | Acta de recibo o nueva fecha con motivo | 3 |
| Laura Vélez | Actualizar la matriz 22 (venció el 10-28) | 2026-10-28 | Acta de recibo; y una fecha para «mandar el ajuste del presupuesto», que dijo «la otra semana» | 4 |

Fuente: minutas del comité 10-14 (prueba 18, ambiente 20) y 10-21 (diseño 13, matriz 22); notas 2026-10-28 (ajuste del presupuesto).

### Se decide hoy o se atrasa
| Qué | Quién decide | Si no se decide | Min |
|---|---|---|---|
| Registrar o no el riesgo «el proveedor podría no llegar con el equipo completo para la siguiente fase», con dueño y plan; y qué se hace en la revisión con el proveedor | Liliana Torres, con Óscar Ramírez (revisión con el proveedor, 11-07, sábado: confirmar si es sábado de verdad y si Óscar la hace o solo se agendó) | El riesgo sigue sin dueño; se dijo en la reunión del 10-28 y no está en el informe de avance ni en las seis minutas anteriores | 5 |

Fuente: notas 2026-10-28, línea 7 (dicho sin atribuir, «nadie lo anotó como riesgo»).

### Vence antes de la próxima
Nada con fecha entre el 10-28 y el 11-04. Lo que vence justo después: Elena Duarte (confirmar la fecha 23, 11-06), Óscar Ramírez (revisión con el proveedor, 11-07), Javier Hoyos (entregar el punto 24, 11-08).

### No es de esta reunión
| Qué | Por qué | Dónde va |
|---|---|---|
| Mauricio Pérez (punto 8, vencido 10-02), Jorge Medina (anexo 11, vencido 10-14), Carlos Peña (documento 9, sin fecha) | Dijeron que ya lo entregaron, no hay acta, y no estuvieron el 10-28. Sin ellos en la sala nadie puede moverlo | Pregunta directa pidiendo el acta antes de la reunión. Entran a la agenda solo si confirman asistencia |
| Qué hacer con Beatriz (6 reprogramaciones) y Camilo (5): reasignar, recortar alcance, cancelar | Excede la autoridad del gerente | `/pm-escalate` para el Comité de Inversiones. Los puntos 1 y 2 sirven para nombrar el bloqueo, no para decidir eso |
| Hito «Diseño de la operación aprobado» declarado cumplido sin acta | No tiene doliente en el expediente | Liliana busca el acta; luego `/pm-report` |
| Informe de avance en verde, 53 %, contra el cálculo (compromisos vencidos y reprogramados; el plan sustenta 75–100 % por hitos) | El estado lo declara Liliana, no se discute en reunión | `/pm-report` |

### Anexo — estado al 2026-10-28 (no hay snapshot anterior para decir «sin cambios desde»)
Dentro de plazo, sin repasar en la reunión:
- Rubén Cárdenas · actualizar la matriz 6 · 2026-11-18 (movido 2 veces)
- Natalia Ospina · aprobar el diseño 21 · 2026-11-13
- Elena Duarte · confirmar la fecha 23 · 2026-11-06
- Javier Hoyos · entregar el punto 24 · 2026-11-08
- Óscar Ramírez · revisión con el proveedor · 2026-11-07 (ver punto de decisión)
- Cerrados con acta: 9 compromisos (ver `/pm-commitments`)

### Después
La agenda no convoca a nadie: citar es tuyo. Tras la reunión, `/pm-minutes` sobre las notas o la transcripción.
