## Listo — PRY-204 · Cross docking en el puerto

**Lo que miré:** 21 documentos · 6 minutas del comité (2026-09-16 a 2026-10-21) más las notas del 2026-10-28 · la última del 2026-10-28
**Términos:** aceptados por José Francisco Ñáñez para la versión 0.12.1 · comprobante en `.criterio/terminos/aceptacion-criterio-project-0.12.1-2026-10-28.md` y `.pdf` · SHA-256 62edf7d640b4f27387dbb6fc8540d4f0657cb02e968cb8dafd8e05bb449d7bae (md) y 999c8302506aa7d14a79e56e60c62af7d63c4f0330561dabef6ae7175d572690 (pdf)

Preguntas (todas con la respuesta sugerida, sin interlocutor): 1) Liliana Torres, gerente de PRY-204, según el acta de constitución. 2) Reunión de seguimiento los miércoles (todas las minutas caen en miércoles). 3) Estado en `estado/PRY-204-cross-docking-en-el-puerto`. 4) Términos: sí, dado de antemano por José Francisco Ñáñez. Marca `_CRITERIO_PROYECTO.txt`: no la dejé (nadie la autorizó).

Leí las 6 minutas en orden, de la más vieja a la más nueva, y las 10 actas de recibo. De los 26 compromisos que aparecen, 9 están cerrados con acta y 17 siguen abiertos.

### Lo que está abierto, y cuántas veces se ha movido
| Quién | Qué | Para cuándo | Movimientos |
|---|---|---|---|
| Beatriz Cuéllar | Enviar el documento 1 | 2027-01-06 (min. 2026-10-28) | **6 veces**; original 2026-10-06 → 10-18 → 11-03 → 11-15 → 12-05 → 12-23 → 2027-01-06 |
| Camilo Beltrán | Cerrar la prueba 2 | 2026-12-09 (min. 2026-10-21) | **5 veces**; original 2026-09-27 → 10-09 → 10-29 → 11-13 → 12-01 → 12-09 |
| María Restrepo | Revisar el anexo 3 | 2026-11-26 (min. 2026-10-21) | **3 veces**; prometido sin fecha el 09-16, primera fecha 2026-10-11 → 10-25 → 11-06 → 11-26 |
| Rubén Cárdenas | Actualizar la matriz 6 | 2026-11-18 (min. 2026-10-21) | 2 veces; original 2026-10-19 → 10-30 → 11-18 |
| Andrés Lozano | Aprobar el diseño 13 | 2026-10-28 (min. 2026-10-21) | 1 vez; original 2026-10-11 |
| Camilo Beltrán | Aprobar el diseño 5 | 2026-09-29 (min. 2026-09-23) | **Vencido 29 días sin acta.** El 09-30 dijo que ya lo entregó; no hay acta |
| Mauricio Pérez | Entregar el punto 8 | 2026-10-02 (min. 2026-09-23) | **Vencido 26 días sin acta.** El 10-14 dijo que ya lo entregó; no hay acta |
| Jorge Medina | Revisar el anexo 11 | 2026-10-14 (min. 2026-09-30) | **Vencido 14 días sin acta.** El 10-07 dijo que ya lo entregó; no hay acta |
| Andrés Lozano | Cerrar la prueba 18 | 2026-10-18 (min. 2026-10-14) | **Vencido 10 días sin acta**; sigue en la tabla del 10-21 con la misma fecha |
| Ricardo Salas | Validar el ambiente 20 | 2026-10-23 (min. 2026-10-14) | **Vencido 5 días sin acta**; sigue en la tabla del 10-21 con la misma fecha |
| Natalia Ospina | Aprobar el diseño 21 | 2026-11-13 (min. 2026-10-21) | — |
| Laura Vélez | Actualizar la matriz 22 | 2026-10-28 (min. 2026-10-21) | vence hoy |
| Elena Duarte | Confirmar la fecha 23 | 2026-11-06 (min. 2026-10-21) | — |
| Javier Hoyos | Entregar el punto 24 | 2026-11-08 (min. 2026-10-21) | — |
| Óscar Ramírez | Revisión con el proveedor | 2026-11-07 (notas 2026-10-28) | — |

Cerrados con acta: ambiente 4, fecha 7, prueba 10, ambiente 12, matriz 14, fecha 15, punto 16, documento 17, anexo 19.

### Sin fecha
Nadie los fechó, así que no pueden estar vencidos y por eso desaparecen de los informes:
- **Carlos Peña** — Enviar el documento 9 (min. 2026-09-30, «por definir»). El 10-07 dijo que ya lo entregó; no hay acta, y sale de la tabla.
- **Laura Vélez** — Mandar el ajuste del presupuesto (notas 2026-10-28: «la otra semana»).

### Lo que el cálculo levantó además
- **El estado declarado es verde (53%) y el cálculo lo contradice**: 3 de 4 hitos del cronograma están cumplidos, así que el plan sustenta entre 75% y 100%; la diferencia es de 22 puntos. Además hay 5 compromisos vencidos, 3 reprogramados 3 veces o más y un hito cumplido sin acta, que el informe no menciona.
- **Hito sin acta:** «Diseño de la operación aprobado» (2026-02-12), declarado cumplido en el cronograma y sin acta de recibo en la carpeta.
- **Presupuesto (COP):** aprobado 18.000.000.000 · comprometido 9.340.126.765 (51,9%) · ejecutado 3.101.575.940 (17,2%) · proyección al cierre 16.752.476.829 (−6,9% sobre lo aprobado).
- **Dicho en la reunión y sin registrar:** el 10-28 se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase. Nadie lo anotó como riesgo; lo dejé en la ficha, sin dueño.

### Qué le falta a tu carpeta
- Acta de recibo del hito «Diseño de la operación aprobado» y de los compromisos que dicen haber entregado (diseño 5, punto 8, documento 9, anexo 11): sin ellas un compromiso cumplido se ve igual que uno incumplido.
- El cronograma es el v1 de 2025-10-13 y su archivo `.xml` no lo lee el inventario automático (lo leí a mano); no hay una versión más reciente.
- El acta de constitución no dice la facultad del gerente (hasta qué monto decide sin subir a comité) ni la etapa; Liliana Torres figura como patrocinadora y como gerente.
- Las notas del 2026-10-28 están sueltas en la raíz del proyecto; la estructura recomendada las pone en `30-reuniones/`. No moví nada.

**Cuándo vuelvo:** el miércoles 2026-11-04, según la cadencia semanal. Ojo: las notas del 10-28 dicen «próxima reunión en dos semanas» (2026-11-11); si es así, dímelo y ajusto la cadencia.
