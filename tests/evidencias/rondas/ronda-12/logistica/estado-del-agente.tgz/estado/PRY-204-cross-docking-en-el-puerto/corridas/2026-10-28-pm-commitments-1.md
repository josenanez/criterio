# Corrida del 2026-10-28 · pm-commitments

1 proyectos · 31 s · 13 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_overdue` | 5 |
| `commitment_rescheduled` | 3 |
| `commitment_undated` | 2 |
| `progress_vs_plan` | 1 |
| `milestone_met_without_evidence` | 1 |
| `declared_vs_evidence` | 1 |

Beatriz Cuéllar (6) y Camilo Beltrán (5) reprogramados por encima del umbral; María Restrepo (3); 5 vencidos sin acta, 3 de ellos con entrega dicha y no documentada

Contra la corrida del 2026-10-28: +0 hallazgos.

## Lo que produjo

## Compromisos — Cross docking en el puerto (PRY-204) · al 2026-10-28

**Términos:** vigentes (v1.3), aceptados por José Francisco Ñáñez el 2026-10-28; no hizo falta registrarlos de nuevo.

26 compromisos en la ficha: 9 cerrados con documento, 17 abiertos. De los abiertos: 3 se vienen reprogramando, 5 están vencidos sin evidencia, 2 vencen esta semana y 2 no tienen fecha; los otros 5 están dentro de plazo (uno, Rubén Cárdenas · matriz 6, ya movido dos veces, a 11-18).

### Se viene reprogramando
> **Beatriz Cuéllar** · Enviar el documento 1
> Prometido para el 2026-10-06, y antes para el 10-18, 11-03, 11-15, 12-05, 12-23, y ahora 2027-01-06. **Seis reprogramaciones.**
> (La fecha «06/01/2027» se leyó día/mes, coherente con la serie; en mes/día sería 2027-06-01. Falta confirmarlo con ella.)

> **Camilo Beltrán** · Cerrar la prueba 2
> Prometido para el 2026-09-27, y antes para el 10-09, 10-29, 11-13, 12-01, y ahora 12-09. **Cinco reprogramaciones.**
> Además tiene vencido «Aprobar el diseño 5» (abajo).

> **María Restrepo** · Revisar el anexo 3
> Prometido para el 2026-10-11 (primera fecha, dicha el 09-23; el 09-16 se prometió sin fecha, no cuenta como reprogramación), y antes para el 10-25, 11-06, y ahora 11-26. **Tres reprogramaciones.**

**Más de tres veces no es un problema de seguimiento: es un bloqueo que nadie ha nombrado.** Beatriz y Camilo son los dos casos más claros.

### Vencidos sin evidencia
| Quién | Qué | Prometido para | Hace |
|---|---|---|---|
| Camilo Beltrán | Aprobar el diseño 5 | 2026-09-29 | 29 días |
| Mauricio Pérez | Entregar el punto 8 | 2026-10-02 | 26 días |
| Jorge Medina | Revisar el anexo 11 | 2026-10-14 | 14 días |
| Andrés Lozano | Cerrar la prueba 18 | 2026-10-18 | 10 días |
| Ricardo Salas | Validar el ambiente 20 | 2026-10-23 | 5 días |

Camilo, Mauricio y Jorge dijeron que ya lo habían entregado; no hay acta de recibo ni nada en el expediente que lo respalde, y desaparecieron de la tabla de las reuniones. Siguen abiertos. Mauricio y Jorge tampoco estuvieron en la reunión de hoy.

### Vencen esta semana
| Quién | Qué | Para cuándo |
|---|---|---|
| Andrés Lozano | Aprobar el diseño 13 (ya movido del 10-11 al 10-28) | 2026-10-28 (hoy) |
| Laura Vélez | Actualizar la matriz 22 | 2026-10-28 (hoy) |

Las notas de hoy no mencionan ninguno de los dos. Lo que sigue: Óscar Ramírez, revisión con el proveedor, 2026-11-07 (sábado).

### Sin fecha
| Quién | Qué | Dicho el |
|---|---|---|
| Carlos Peña | Enviar el documento 9 (dice que ya lo entregó; sin acta) | 2026-09-30 |
| Laura Vélez | Mandar el ajuste del presupuesto («la otra semana») | 2026-10-28 |

No pueden estar vencidos y por eso se cuentan aparte. El de Carlos lleva casi un mes.

### Cerrados desde la última revisión
Cerrados contra documento (9):
- Ricardo Salas · Validar el ambiente 4 → `20-seguimiento/2026-09-30-acta-recibo-4.md`
- Beatriz Cuéllar · Confirmar la fecha 7 (reprogramado una vez) → `2026-10-14-acta-recibo-7.md`
- Beatriz Cuéllar · Actualizar la matriz 14 → `2026-10-14-acta-recibo-14.md`
- Paula Céspedes · Confirmar la fecha 15 → `2026-10-14-acta-recibo-15.md`
- Felipe Arango · Cerrar la prueba 10 → `2026-10-21-acta-recibo-10.md`
- Rubén Cárdenas · Validar el ambiente 12 → `2026-10-21-acta-recibo-12.md`
- Elena Duarte · Entregar el punto 16 → `2026-10-21-acta-recibo-16.md`
- María Restrepo · Enviar el documento 17 → `2026-10-21-acta-recibo-17.md`
- Paula Céspedes · Revisar el anexo 19 → `2026-10-21-acta-recibo-19.md`

### Contexto
El informe de avance del 10-28 declara verde y 53 %. Con lo anterior, `compute` señala el verde contradicho por compromisos vencidos, reprogramados y un hito («Diseño de la operación aprobado») declarado cumplido sin acta.

### Siguiente
- Beatriz Cuéllar (6 veces) y Camilo Beltrán (5) superan con holgura el umbral de reprogramación: ofrezco formularlos como decisión para el comité del 2026-11-04 con `/pm-escalate` (qué se pide, qué pasa si no se decide, quién tiene la facultad). Eso excede la autoridad del gerente.
- Los compromisos cambiaron lo que la ficha decía: `/pm-publish` para que la PMO lo vea.
