Publiqué la ficha en `/home/claude/r12/logistica/espacio/documentos/proyectos/PRY-204-cross-docking-en-el-puerto/00-gobierno/ficha-pm.json`, con corte al 2026-10-28.

**Lleva:** 15 campos con dato · 2 sin decir en ninguna parte (`identity.authority`, `identity.phase`) · declara **verde** al 2026-10-28

**Lo más viejo que va ahí:** los 13 campos de identidad, plan y `money.approved`, todos del acta de constitución y el cronograma v1 del 2025-10-13 — pasan de un año (12 meses cumplidos).

**Fecha de cierre:** `plan.end_date` = 2027-01-14, tomada del único cronograma que hay (v1). No hay uno más nuevo; la línea base es la misma, sin diferencia.

**Lo primero que la PMO va a mirar:** la declaración dice verde, pero las señales no la sostienen:
- Avance declarado 53 %; el plan sostiene entre 75 % y 100 % (3 de 4 hitos cumplidos, brecha de 22 puntos).
- El hito «Diseño de la operación aprobado» (2026-02-12) figura cumplido sin evidencia (258 días).
- 5 compromisos vencidos sin evidencia, 2 sin fecha y 3 reprogramados (hasta 6 veces).

La declaración sigue siendo tuya; la ficha la marca como declarada.

Nota: esta corrida se hizo sin interfaz, así que no hubo pregunta de confirmación; el argumento «confirmar» se tomó como el sí.
