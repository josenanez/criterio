> **Borrador de trabajo, no es la especificación aprobada.** Lo escribió el agente desde el registro; lo cierra el gerente de producto, Ricardo Salas (autoridad: Comité de producto, según la configuración). El agente no puede aprobarlo.

# Especificación — Logística de frío (PRD-303) · borrador del 2026-10-28

**Resumen honesto:** el registro tiene 13 requerimientos aceptados y de ninguno se conoce qué es. Los títulos son el propio ID («Requerimiento REQ-4300»), y el campo «necesidad» está en `not_found` en los 13. Por eso **no se redactó ninguna sección de comportamiento**: inventarla sería rellenar con lo razonable. Lo que sigue es el alcance que sale del registro, lo poco que se puede verificar, y los vacíos con su dueño.

## Qué problema resuelve
«El segmento Farmacéuticas no tiene logística de frío.» (`00-definicion/2026-05-27-definicion-producto.md`, 2026-05-27). Segmento: Farmacéuticas. La propuesta de la definición dice solo «Propuesta principal»: no describe nada. El criterio de éxito del producto **no está dicho en ninguna parte** (`success: not_found`).

## Alcance
### Entra
Los 13 requerimientos en estado `aceptado` según el acta del comité del 2026-10-15 (`30-decisiones/2026-10-15-comite-producto.docx`), identificados solo por ID: REQ-4300, 4301, 4302, 4303, 4304, 4305, 4306, 4307, 4310, 4311, 4312, 4313 y REQ-2028.
(Ninguno está en `en_construccion`.)

### No entra
- **REQ-4308** (Óscar Ramírez) y **REQ-4309** (Mauricio Pérez): están `propuesto`; nadie decidió nada, y especificarlos sería escribir el documento dos veces.
- Todo lo que no tenga requerimiento registrado: la definición habla de «logística de frío» para farmacéuticas, pero ningún documento dice qué parte de eso se hace y qué parte no. **La frontera del producto no está decidida**; esta lista de exclusiones es la que sale del registro, no del producto.
- Diseño técnico, estimaciones, costos y fechas (no son de esta especificación).

## Comportamiento
**No redactado.** Para ninguno de los 13 requerimientos hay título real ni necesidad en palabras de quien la tiene (REQ-4300…4313, REQ-2028: `need: not_found`). Una sección de comportamiento escrita hoy sería invención del agente. Se redactará cuando el gerente de producto o cada doliente aporte el enunciado del problema.

## Criterios de aceptación
Lo único que el acta trae como criterio es la frase «se verifica en producción». Aparece en 7 de 13 requerimientos.

| Criterio | Requerimiento | Cómo se verifica | ¿Se puede medir hoy? |
|---|---|---|---|
| «se verifica en producción» | REQ-4304, 4305, 4307, 4311, 4312, 4313, 2028 | **No es verificable como está escrito:** no dice qué se observa, con qué umbral ni quién lo certifica. Dos personas mirando lo construido no llegarían necesariamente a la misma respuesta. | No. Además, no hay evidencia de que la organización mida algo en producción para este producto; no existe proyecto que lo construya. |
| *(ninguno)* | REQ-4300, 4301, 4302, 4303, 4306, 4310 | Sin criterio de aceptación en el registro. | — |

No se propone un umbral (p. ej. un percentil o una temperatura) porque no hay documento que lo sustente; hacerlo sería decidir por el equipo. Para una cadena de frío farmacéutica lo natural sería un criterio sobre temperatura y trazabilidad, pero eso es una hipótesis del agente, no un hallazgo del registro.

## Supuestos sobre los que está escrita
| Supuesto | Verificado | Quién lo verificaría |
|---|---|---|
| «El precio del combustible se sostiene» (declarado 2026-08-30) | **Registrado como verificado, pero sin sustento visible.** El anexo del 2026-09-06 dice «se confirmó», afirma ser la evidencia completa y no trae la medición del piloto. Además, la definición está fechada 2026-05-27 y declara un supuesto del 2026-08-30: el documento fue editado después de su fecha o la fecha es incorrecta. | Ricardo Salas (autor de la definición): aportar la medición del piloto. |
| Cifra del caso de negocio: `volumen_mensual` = 70.118 (2026-05-27) | No verificado: sin serie medida ni fuente más allá del propio caso; el retorno dice solo «Retorno esperado en 24 meses», sin monto. | Ricardo Salas, con la fuente de datos. |
| Los requerimientos de otros dolientes parten de la entrevista del 2025-10-13 | La entrevista no nombra ningún requerimiento (ver Vacíos). | Ricardo Salas (realizó la entrevista). |

## Vacíos
| Qué falta decidir | Consecuencia de no decidirlo | Quién lo cierra |
|---|---|---|
| Enunciado real de los 13 requerimientos (título y necesidad) | No se puede escribir comportamiento ni dos personas pueden acordar qué se construye | Cada doliente: Ricardo Salas (4300, 4303), Beatriz Cuéllar (4301, 4311, 2028), Elena Duarte (4302), Óscar Ramírez (4304, 4310), Laura Vélez (4305), Gustavo Neira (4306), Rubén Cárdenas (4307, 4313), Mauricio Pérez (4312) |
| Criterio de aceptación en REQ-4300, 4301, 4302, 4303, 4306, 4310 | Aceptados sin saber cuándo están terminados | Sus dolientes; Ricardo Salas como gerente |
| Criterio verificable en lugar de «se verifica en producción» (7 REQ) | La discusión de si quedó bien se tiene después de construirlo | Los dolientes de esos 7, con Ricardo Salas |
| Criterio de éxito del producto (`success: not_found`) | No hay cómo saber si el producto funcionó | Ricardo Salas / Comité de producto |
| Evidencia de demanda: REQ-4301, 4312 y 2028 no tienen ninguna; los otros 10 se apoyan en una sola entrevista anónima del 2025-10-13 («Lo necesito y hoy no lo tengo»), que no nombra ningún requerimiento y ya tiene unos 12,5 meses (umbral configurado: 12) | Aceptados sin demanda sustentada; la evidencia vigente es de un solo cliente sin nombre | Ricardo Salas |
| Proyecto que ejecuta cada requerimiento: la definición dice «Ninguno declarado» y la columna del acta está vacía en los 13 | Nadie construye lo aceptado; la especificación no tiene destinatario | Comité de producto (por vía de `/criterio-product:product-charter`) |
| Casos borde: no definidos porque no hay comportamiento (p. ej. qué pasa ante una ruptura de la cadena de frío o pérdida de conexión de un sensor, solo como ejemplos de preguntas, no como requisitos) | Lo no decidido lo decide quien construye | Ricardo Salas con los dolientes |
| Obligaciones normativas: ningún documento del registro las menciona y **no se hizo el barrido normativo**. El producto toca distribución farmacéutica y registro de temperatura; qué normas aplican es una pregunta abierta, no una conclusión | Riesgo de construir sin saber qué obligaciones hay | Ricardo Salas, con quien lleve cumplimiento (el nombre no está en los documentos) |
| Lo que otro equipo debe hacer: ningún documento nombra a otro equipo ni un acuerdo con él | Dependencias ocultas | Ricardo Salas |
| Quién decidió: `decision.who` vacío en los 13; el acta lista como asistente solo a Ricardo Salas, y la única decisión escrita es «Se mantiene el plan», pero no existe ningún plan en la documentación | Decisiones sin responsable identificable; la autoridad «Comité de producto» no queda acreditada por el acta | Comité de producto |
| Prioridad: `not_found` en los 13 | Sin orden de construcción | Ricardo Salas |

## Requerimientos aceptados que esta especificación no cubre
Los 13 figuran en el alcance, pero **ninguno tiene sección de comportamiento**:

| REQ | Título | Por qué no |
|---|---|---|
| REQ-4300 | Requerimiento REQ-4300 | Sin necesidad ni criterio de aceptación |
| REQ-4301 | Requerimiento REQ-4301 | Sin necesidad, criterio ni evidencia |
| REQ-4302 | Requerimiento REQ-4302 | Sin necesidad ni criterio de aceptación |
| REQ-4303 | Requerimiento REQ-4303 | Sin necesidad ni criterio de aceptación |
| REQ-4304 | Requerimiento REQ-4304 | Sin necesidad; criterio no verificable |
| REQ-4305 | Requerimiento REQ-4305 | Sin necesidad; criterio no verificable |
| REQ-4306 | Requerimiento REQ-4306 | Sin necesidad ni criterio de aceptación |
| REQ-4307 | Requerimiento REQ-4307 | Sin necesidad; criterio no verificable |
| REQ-4310 | Requerimiento REQ-4310 | Sin necesidad ni criterio de aceptación |
| REQ-4311 | Requerimiento REQ-4311 | Sin necesidad; criterio no verificable |
| REQ-4312 | Requerimiento REQ-4312 | Sin necesidad ni evidencia; criterio no verificable |
| REQ-4313 | Requerimiento REQ-4313 | Sin necesidad; criterio no verificable |
| REQ-2028 | Requerimiento REQ-2028 | Sin necesidad ni evidencia; criterio no verificable. Además, el ID (serie 2028) no sigue la numeración 43xx del resto y su decisión figura desde 2026-10-07 |

---
**Pie:** sale del registro `estado-producto/PRD-303/requirements/` (15 archivos; 13 aceptados cubiertos en el alcance, 0 con comportamiento redactado; 2 propuestos excluidos), actualizado el 2026-10-28 y construido sobre documentos fechados entre 2025-10-13 y 2026-10-15. Términos vigentes (v1.3, aceptados por José Francisco Ñáñez, 2026-10-28): https://www.josenanez.com/es/agents/criterio-pmo/legal

**Después:** `/criterio-product:product-charter` no se ofrece todavía: no hay vacíos cerrados ni criterio de éxito.
