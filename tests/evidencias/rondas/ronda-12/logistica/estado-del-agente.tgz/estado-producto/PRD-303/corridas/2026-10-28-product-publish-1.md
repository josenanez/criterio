# Corrida del 2026-10-28 · product-publish

PRD-303 · 15 requerimientos · 17 s · 35 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 13 |
| `evidence_stale` | 11 |
| `requirement_without_acceptance` | 6 |
| `requirement_accepted_without_evidence` | 3 |
| `requirement_undecided` | 2 |

No se publicó: no hay carpeta de productos publicados configurada; la ficha quedó calculada pero sin escribir

Contra la corrida del 2026-10-28: +0 hallazgos.

## Lo que produjo

No publiqué la ficha de PRD-303: no hay carpeta de productos publicados configurada ni existente (la configuración, `.criterio/producto/PRD-303/config.json`, no tiene esa ruta, y no hay ninguna carpeta `publicados` en el espacio). Sin un sitio común acordado esto no sirve, y acordarlo es una conversación de la organización, no un comando. No creé ninguna carpeta ni inventé una ruta.

Términos: vigentes (versión 0.12.1, aceptados por José Francisco Ñáñez el 2026-10-28); no hizo falta registrarlos de nuevo.

**Lo que la ficha llevaría, con corte al 2026-10-28** (calculado con `compute` y `publish`; no se escribió en ningún sitio):

**Lleva:** 15 requerimientos (13 aceptados, 2 propuestos) · 0 proyectos · 1 métrica afirmada
**Segmento declarado:** Farmacéuticas
**Métricas:** volumen_mensual = 70118, de `documentos/productos/PRD-303/00-definicion/2026-05-27-caso-de-negocio.md` (2026-05-27); sin serie medida, así que sin contraste.

Antes de publicar conviene saber que ningún requerimiento tiene proyecto asignado (0 de 15 trazados), de modo que otro producto no podría cruzar por proyecto compartido.

Para publicar: indicar la carpeta común de fichas de producto (por ejemplo `productos/publicados/`) y volver a correr `/product-publish`.
