## Registro — Logística de frío (PRD-303) · al 2026-10-28
15 requerimientos · 13 decididos · 76.9% con evidencia · 0% con proyecto que lo ejecuta

> Sobre el 0%: no hay fichas de proyecto para cruzar (no se pasó `--fichas`), así que ningún requerimiento tiene proyecto confirmado. Es «sin confirmar», no «confirmado que nadie lo construye». `/product-trace` lo aclara.
> Los títulos del registro son genéricos («Requerimiento REQ-43xx»): la extracción no los recogió.

### Se va a construir y nadie lo pidió
| REQ | Título | Estado | Doliente |
|---|---|---|---|
| REQ-2028 | Requerimiento REQ-2028 | aceptado (2026-10-07) | Beatriz Cuéllar |
| REQ-4301 | Requerimiento REQ-4301 | aceptado (2026-08-06) | Beatriz Cuéllar |
| REQ-4312 | Requerimiento REQ-4312 | aceptado (2026-05-14) | Mauricio Pérez |

Ninguno trae una sola cita de quien lo pidió.

### Decidido y nadie lo está construyendo
Los 13 aceptados (REQ-2028, 4300–4307, 4310–4313) no tienen proyecto asociado. Ver la nota sobre el 0%: sin fichas, no confirmado.

### Sin doliente, o con un área en vez de una persona
Ninguno. Los 15 tienen una persona como doliente.

### Sin criterio de aceptación
| REQ | Título | Estado |
|---|---|---|
| REQ-4300 | Requerimiento REQ-4300 | aceptado |
| REQ-4301 | Requerimiento REQ-4301 | aceptado |
| REQ-4302 | Requerimiento REQ-4302 | aceptado |
| REQ-4303 | Requerimiento REQ-4303 | aceptado |
| REQ-4306 | Requerimiento REQ-4306 | aceptado |
| REQ-4310 | Requerimiento REQ-4310 | aceptado |

(Los propuestos no se cuentan: REQ-4308 tampoco lo tiene y no es hallazgo.)

### Decidido sin documento que lo respalde
Los 13 aceptados citan el mismo documento: `30-decisiones/2026-10-15-comite-producto.docx`. Pero en ninguno consta **quién decidió**, y las fechas de decisión (de 2026-04-05 a 2026-10-07) son anteriores a la fecha del documento (2026-10-15).
| REQ | Quién decidió | Cuándo |
|---|---|---|
| REQ-4303 | no consta | 2026-04-05 |
| REQ-4313 | no consta | 2026-04-10 |
| REQ-4312 | no consta | 2026-05-14 |
| REQ-4302 | no consta | 2026-04-23 |
| REQ-4305 | no consta | 2026-05-13 |
| REQ-4300 | no consta | 2026-05-17 |
| REQ-4310 | no consta | 2026-05-28 |
| REQ-4306 | no consta | 2026-07-30 |
| REQ-4307 | no consta | 2026-08-05 |
| REQ-4301 | no consta | 2026-08-06 |
| REQ-4304 | no consta | 2026-08-10 |
| REQ-4311 | no consta | 2026-08-11 |
| REQ-2028 | no consta | 2026-10-07 |

### Lleva meses y nadie lo decide
| REQ | Título | Propuesto hace | Quién tiene la facultad |
|---|---|---|---|
| REQ-4309 | Requerimiento REQ-4309 | 95 días (2026-07-25) | Comité de producto (según la configuración; revisión mensual) |
| REQ-4308 | Requerimiento REQ-4308 | 61 días (2026-08-28) | Comité de producto |

Umbral: 60 días. Propongo que el comité los decida —aceptar o descartar—, no cerrarlos por viejos. Doliente de cada uno: Mauricio Pérez (4309), Óscar Ramírez (4308).

### Evidencia vieja
Es la misma entrevista para todos: Cliente entrevistado, 2025-10-13, «Lo necesito y hoy no lo tengo.» (tema: Necesidad principal). Hace 12 meses. La entrevista **no nombra** ninguno de los requerimientos; es la más cercana.
| REQ | Lo más nuevo que lo sostiene | Hace |
|---|---|---|
| REQ-4300, 4302, 4303, 4304, 4305, 4306, 4307, 4309, 4310, 4311, 4313 (11) | entrevista 2025-10-13 | 12 meses |

Esta es la lectura que más importa: el 76.9% «con evidencia» descansa en una sola frase genérica de un cliente.

## Por estado
| propuesto | aceptado | en construcción | entregado | descartado |
|---|---|---|---|---|
| 2 | 13 | 0 | 0 | 0 |

### Quién cierra qué
- Evidencia de REQ-2028, 4301, 4312: sus dolientes (Beatriz Cuéllar, Mauricio Pérez).
- Criterios de aceptación: Ricardo Salas (4300, 4303), Elena Duarte (4302), Gustavo Neira (4306), Óscar Ramírez (4310), Beatriz Cuéllar (4301).
- Quién decidió: el Comité de producto, desde su acta del 2026-10-15.
- Proyecto que ejecuta: Ricardo Salas (gerente de producto).

Después: ofrezco `/product-trace` (13 decididos sin proyecto confirmado). Ninguno está listo para `/product-charter`: todos los aceptados con criterio y evidencia (4304, 4305, 4307, 4311, 4313) tienen evidencia de hace 12 meses que no los nombra.
