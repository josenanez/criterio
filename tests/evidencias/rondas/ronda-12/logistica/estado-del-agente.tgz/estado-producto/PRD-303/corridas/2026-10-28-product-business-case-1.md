# Corrida del 2026-10-28 · product-business-case

PRD-303 · 15 requerimientos · 32 s · 35 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 13 |
| `evidence_stale` | 11 |
| `requirement_without_acceptance` | 6 |
| `requirement_accepted_without_evidence` | 3 |
| `requirement_undecided` | 2 |

Armó la estructura del caso de negocio de PRD-303: 1 cifra declarada (volumen_mensual 70.118) sin origen ni serie medida, 0 de 1 con fuente. Dijo que no sabe: costo de construir, retorno, criterio de éxito, autoridad, la medición del piloto y la propuesta. Sin otros productos publicados para cruzar.

Contra la corrida del 2026-10-28: +0 hallazgos.

## Lo que produjo

# Caso de negocio — Logística de frío (PRD-303) · borrador del 2026-10-28
**Desde:** la definición del 2026-05-27 y el caso de negocio del mismo día · **Cifras con fuente:** 0 de 1 (la única cifra cita el documento donde está escrita; no hay origen)

Términos v1.3 ya vigentes (aceptados por José Francisco Ñáñez el 2026-10-28); no hubo que registrar nada.

## Qué problema resuelve, y para quién
«El segmento Farmacéuticas no tiene logística de frío.» Para el segmento Farmacéuticas, completo. (`00-definicion/2026-05-27-definicion-producto.md`, 2026-05-27.)
Lo único que lo sostiene es una entrevista del 2025-10-13 a un «Cliente entrevistado» sin nombre: «Lo necesito y hoy no lo tengo.» (`10-descubrimiento/2025-10-13-entrevistas.md`). Evidencia débil y de hace 12 meses; la entrevista no dice que ese cliente sea farmacéutico.

## Qué se construye
La definición dice solo «Propuesta principal»: **no dice qué se construye.** Lo decidido está en el registro de requerimientos (acta `30-decisiones/2026-10-15-comite-producto.docx`):

| Requerimiento | Estado | Evidencia de demanda |
|---|---|---|
| REQ-4300, 4302, 4303, 4304, 4305, 4306, 4307, 4310, 4311, 4313 (10) | aceptado | Solo la entrevista del 2025-10-13, que no nombra ninguno; el acta los atribuye a «Cliente entrevistado» |
| REQ-2028, REQ-4301, REQ-4312 (3) | aceptado | **Ninguna.** Ni una cita de quien lo pidió |

Quedan fuera del caso REQ-4308 y REQ-4309 (propuestos, sin decidir hace 61 y 95 días). En ningún aceptado consta quién decidió, y las fechas de decisión (2026-04-05 a 2026-10-07) son anteriores al acta (2026-10-15). Seis aceptados no tienen criterio de aceptación (4300, 4301, 4302, 4303, 4306, 4310). Los títulos del registro son genéricos.

## Las cifras
| Cifra | Valor | Clase | De dónde sale | De cuándo |
|---|---|---|---|---|
| volumen_mensual | 70.118 | **Declarada** | Caso de negocio (`00-definicion/2026-05-27-caso-de-negocio.md`), que se cita a sí mismo como fuente; sin estudio, contrato ni conteo | 2026-05-27 |
| Retorno esperado | «en 24 meses» | **Supuesta** (no es cifra: sin valor, base de cálculo ni supuestos) | Nadie la ha afirmado con número | 2026-05-27 |

No hay ninguna cifra **medida**.

### Donde la cifra declarada y la medida no coinciden
| Métrica | Declarada | Medida | Las dos fuentes y fechas |
|---|---|---|---|
| volumen_mensual | 70.118 (caso de negocio, 2026-05-27) | **No existe serie medida** | No hay contraste posible. No es contradicción: nadie mide lo que el caso afirmó. Umbral configurado: 20 % |

## Los costos
| Concepto | Valor | De dónde sale |
|---|---|---|
| Costo de construir | **Vacío** | Ningún documento |
| Contratos / cotizaciones | **Vacío** | Ningún documento |
| Costo declarado del equipo | **Vacío** | Ningún documento |

**El costo de construir es el primer vacío.** Sin él no hay caso de negocio que evaluar: hay una propuesta.

## Supuestos sobre los que se sostiene
| Supuesto | Qué pasa si resulta falso | Quién lo verificaría |
|---|---|---|
| El precio del combustible se sostiene (declarado 2026-08-30) | El caso no dice cómo depende del combustible, así que no se puede decir qué cambia; ese vínculo tampoco está escrito | Quien tenga la medición del piloto del 2026-09-06. El anexo de esa fecha dice «se confirmó» pero no trae la medición ni cifra alguna, y «se sostiene» no dice cuánto ni por cuánto tiempo |
| Todo el segmento Farmacéuticas carece de logística de frío | El problema se reduce a un cliente | Ricardo Salas (gerente de producto) |
| El volumen mensual es 70.118 (supuesta en la práctica: se sostiene en sí misma) | Cualquier cifra derivada cae | Nadie asignado |
| Retorno esperado en 24 meses | Sin base, no hay qué falsar | Nadie asignado |

## Vacíos
| Qué falta | Por qué importa | Quién lo produce |
|---|---|---|
| Costo de construir y operar | Sin costo no hay caso evaluable | El negocio (Ricardo Salas) con finanzas |
| Origen del 70.118 | Es la única cifra y no tiene de dónde salió | Ricardo Salas |
| Retorno: cifra, base de cálculo y supuestos | «Retorno en 24 meses» no es verificable | El negocio |
| Qué se construye (la propuesta) | La definición dice solo «Propuesta principal» | Ricardo Salas |
| Qué pasa si no se hace | El comité no puede comparar | El negocio |
| Alternativas consideradas | No hay ninguna escrita | El negocio |
| Criterio de éxito, métrica y fecha de corte | Sin él el producto no se puede cerrar meses después | Ricardo Salas / Comité de producto |
| Quién decide | Ningún documento nombra autoridad (la configuración dice «Comité de producto») | Comité de producto |
| Quién decidió cada requerimiento aceptado | No consta en el acta | Comité de producto |
| Medición del piloto del 2026-09-06 | Es la única verificación de un supuesto y no está en la carpeta | Quien hizo el piloto |
| Serie medida de volumen | Sin ella el 70.118 no se puede contrastar | El sistema donde el producto vive |
| País y obligaciones sanitarias | La definición no nombra país; la logística de frío farmacéutica suele tener reglas propias. Revisión jurídica, sin opinión aquí | Jurídico |
| Proyecto que lo construye | «Ninguno declarado» | Ricardo Salas |

## Cómo se sabrá si funcionó
**No está declarado.** No hay criterio de éxito, ni métrica, ni fecha de corte. Sin esto el producto no se puede cerrar meses después.

## Si hay otros productos publicados
No hay otros productos publicados a la vista en este espacio; el cruce de `/product-overlap` no se pudo hacer. Queda pendiente si luego aparecen.

## Después
- Pasar los supuestos (combustible, segmento completo, volumen, retorno) al seguimiento con **assumption-tracking**: dentro del caso nadie los vuelve a mirar.
- `/product-charter` no corresponde todavía: faltan criterio de éxito, autoridad y costo.
- Este documento no calcula rentabilidad ni recomienda aprobar o rechazar; decide quien tiene la autoridad.
