## Logística de frío (PRD-303) · 2026-10-28

**Primera revisión del registro: no hay corte anterior** (`last: null`), así que no se puede separar lo nuevo de lo viejo. Lo que sigue es la línea base; desde la próxima corrida solo se reportará lo que cruce un umbral después de este corte. Vuelvo el 2026-11-27.

Términos v1.3 ya vigentes (aceptados por José Francisco Ñáñez, 2026-10-28); no se registró nada nuevo.

### Cruzó un umbral sin que nadie hiciera nada
| Qué | REQ | Cuánto lleva | Qué se necesita | Quién |
|---|---|---|---|---|
| Sin decidir (umbral 60 días) | REQ-4309 | 95 días (planteado 2026-07-25) | Que alguien con facultad lo decida; llevarlo al comité | Mauricio Pérez (doliente); decide el Comité de producto |
| Sin decidir (umbral 60 días) | REQ-4308 | 61 días (planteado 2026-08-28) | Ídem; lleva un día sobre el umbral | Óscar Ramírez (doliente); decide el Comité de producto |
| Evidencia vencida (12 meses) | 11 requerimientos: REQ-4300, 4302, 4303, 4304, 4305, 4306, 4307, 4309, 4310, 4311, 4313 | Toda sale de la misma entrevista del 2025-10-13, que cumple 12 meses | Una entrevista nueva o confirmar vigencia. Sin ella, la afirmación «el cliente lo necesita» queda sin sustento en la definición. La entrevista además no nombra ninguno de los requerimientos; solo es la más cercana. | Ricardo Salas (gerente de producto) |

### Aceptados que nadie está construyendo
- Los 13 requerimientos aceptados están sin traza a un proyecto (`traced` 0 %).
- Se leyeron 13 fichas en `estado/records` (PRY-199 a PRY-211) y ninguna nombra PRD-303. Por eso ninguna traza se da por confirmada.

### Aceptados sin sustento
- Sin evidencia de demanda: REQ-2028, REQ-4301 y REQ-4312.
- Sin criterio de aceptación: REQ-4300, 4301, 4302, 4303, 4306 y 4310.

### Lo que el registro no sabe
- **Éxito de la definición:** no está definido en ningún documento.
- **Autoridad:** la configuración dice «Comité de producto», pero el cálculo la devuelve vacía; conviene confirmar quién decide formalmente.
- **Afirmación del negocio:** `volumen_mensual` = 70.118 (caso de negocio, 2026-05-27) no tiene medición contra la cual contrastarla, así que no se puede decir si el negocio y los datos coinciden.
- **Supuestos sin verificar:** ninguno abierto en este corte.

### Del descubrimiento
Los 5 documentos están sin cambios desde el último sellado: no hay nada que releer ni documentos nuevos.

Observación técnica: el chequeo de citas marca como «no resueltas» 7 citas de la definición. Las rutas apuntan a archivos que existen (`documentos/productos/PRD-303/00-definicion/…`), así que parece un desajuste de cómo se resuelve la ruta, no un documento borrado. Conviene confirmarlo.

**Vuelvo el 2026-11-27.**
