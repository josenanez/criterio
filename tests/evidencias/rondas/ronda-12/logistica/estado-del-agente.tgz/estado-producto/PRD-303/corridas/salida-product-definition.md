## Definición — Logística de frío (PRD-303) · contrastada al 2026-10-28
**Documento:** `00-definicion/2026-05-27-definicion-producto.md` (con el caso de negocio del mismo día) · **del** 2026-05-27 · 7 afirmaciones

Términos v1.3 ya vigentes (aceptados por José Francisco Ñáñez el 2026-10-28); no hubo que registrar nada.

### Lo que la evidencia contradice
Nada. Ninguna fuente dice lo contrario de lo que afirma la definición. Eso no quiere decir que esté sostenida: casi todo cae en las secciones de abajo.

### El negocio y los datos
Ninguna métrica pasa del umbral (20 %), porque no hay ninguna medida con la cual compararla. Ver la sección siguiente.

### Afirmaciones numéricas que nadie mide
| Afirma | De qué documento | No hay serie |
|---|---|---|
| `volumen_mensual` = 70.118 | Caso de negocio, 2026-05-27 (`00-definicion/2026-05-27-caso-de-negocio.md`) | No hay ninguna serie medida. No es contradicción: nadie está midiendo lo que el caso afirmó. |

### No está dicho en ninguna parte
- **La propuesta.** La definición dice solo «Propuesta principal»; no dice qué se va a construir ni para qué.
- **De dónde sale el 70.118.** El caso de negocio lo cita a sí mismo («Caso de negocio, 2026-05-27»). No hay estudio, contrato ni conteo detrás.
- **Qué significa «Retorno esperado en 24 meses».** No trae cifra, base de cálculo ni supuestos.
- **Que *todo* el segmento Farmacéuticas carezca de logística de frío.** La definición lo afirma de todo el segmento. El único respaldo es un cliente sin nombre, y la entrevista no dice que sea farmacéutico.
- **Criterio de éxito.** No existe.
- **Quién decide.** El registro no encuentra autoridad en los documentos. La configuración nombra al «Comité de producto», pero ningún documento de la definición lo dice.
- **Qué proyecto lo construye.** La definición dice «Ninguno declarado», y 0 de 13 requerimientos aceptados están trazados a un proyecto.

### Sostenida por un supuesto
| Supuesto | Días sin verificar | Qué haría falta para verificarlo |
|---|---|---|
| El precio del combustible se sostiene | 0 según el registro (marcado como verificado) | Ver nota abajo: la verificación existe de nombre, pero el anexo no trae la medición. Haría falta la medición del piloto del 2026-09-06 con su cifra, y un umbral escrito (por ejemplo, hasta qué precio o en qué periodo «se sostiene»). |

**Nota sobre este supuesto.**
- El anexo del 2026-09-06 dice que «este anexo es esa evidencia» y que «se confirmó». No trae la medición del piloto ni ninguna cifra. Se remite a una medición que no está en la carpeta.
- Está declarado como verificado, pero lo único que lo respalda es la palabra «se confirmó».
- «Se sostiene» no dice cuánto ni por cuánto tiempo. Escrito así, no se puede desmentir.
- El supuesto lleva fecha de declaración 2026-08-30, posterior a la fecha de la definición (2026-05-27). La definición se editó después de su fecha y no lo dice.

### Sostenida por evidencia
| Afirmación | Sostenida por | De cuándo | Qué tan fuerte |
|---|---|---|---|
| «El segmento Farmacéuticas no tiene logística de frío» | Entrevista a «Cliente entrevistado»: «Lo necesito y hoy no lo tengo.» (`10-descubrimiento/2025-10-13-entrevistas.md`) | 2025-10-13 | Débil. Es una sola persona, sin nombre, que dice que lo necesita. No hay pago, compromiso ni piloto. |

### Evidencia que ya envejeció
| Afirmación | Lo más nuevo que la sostiene | Hace |
|---|---|---|
| El problema del segmento (y 11 requerimientos que se apoyan en la misma entrevista) | Entrevista del 2025-10-13 | 12 meses, el umbral configurado |

La entrevista no nombra ninguno de esos requerimientos; el acta del comité del 2026-10-15 los atribuye a «Cliente entrevistado».

### Lo normativo que toca
| Qué toca | País | Obligación | Norma | Estado |
|---|---|---|---|---|
| Nada de lo que la definición dice roza datos personales, pagos, consumidor financiero ni retención de información | No declarado | — | — | No tengo la norma a la vista |

La definición no nombra país. Que no aparezca un tema en el texto no quiere decir que no exista una obligación (la logística de frío de farmacéuticos suele tener reglas sanitarias propias). Eso queda para revisión jurídica; este barrido no dice si algo cumple.

### Lo que falta para cerrar la definición
- **Problema:** está (una línea, sin cuantificar).
- **Para quién:** está (Farmacéuticas, segmento completo).
- **Criterio de éxito:** **falta.** Sin él el producto no se puede cerrar, porque el cierre se juzga contra él meses después.
- **Quién decide:** **falta** en los documentos.

Datos del cálculo para la conversación con el comité: de 15 requerimientos, 13 aceptados y 2 propuestos sin decidir (REQ-4308 lleva 61 días; REQ-4309, 95 días, ambos sobre el umbral de 60). Eso se trata en `/product-requirements`.

**Siguiente paso posible:** el supuesto del combustible, mientras no se anexe la medición, es candidato a riesgo con doliente (raid-taxonomy). `/product-charter` no corresponde todavía, porque la definición no tiene criterio de éxito ni autoridad.
