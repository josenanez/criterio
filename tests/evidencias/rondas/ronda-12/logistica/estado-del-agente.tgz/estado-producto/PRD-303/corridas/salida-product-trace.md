## Trazabilidad — Logística de frío (PRD-303) · al 2026-10-28
13 decididos · 0 con proyecto · 0 confirmados contra la ficha · 0 entregados

### Decidido y nadie lo está construyendo
Ningún requerimiento aceptado nombra un proyecto (`traces.project` vacío en los 13). La cadena se rompe en el eslabón decisión → proyecto. Decisión: acta `documentos/productos/PRD-303/30-decisiones/2026-10-15-comite-producto.docx`; en ninguno consta «por quién» (decision.who vacío).

| REQ | Título | Decidido el | Por quién | Doliente |
|---|---|---|---|---|
| REQ-4313 | Requerimiento REQ-4313 | 2026-04-10 | no consta | Rubén Cárdenas |
| REQ-4303 | Requerimiento REQ-4303 | 2026-04-05 | no consta | Ricardo Salas |
| REQ-4302 | Requerimiento REQ-4302 | 2026-04-23 | no consta | Elena Duarte |
| REQ-4305 | Requerimiento REQ-4305 | 2026-05-13 | no consta | Laura Vélez |
| REQ-4312 | Requerimiento REQ-4312 | 2026-05-14 | no consta | Mauricio Pérez |
| REQ-4300 | Requerimiento REQ-4300 | 2026-05-17 | no consta | Ricardo Salas |
| REQ-4310 | Requerimiento REQ-4310 | 2026-05-28 | no consta | Óscar Ramírez |
| REQ-4306 | Requerimiento REQ-4306 | 2026-07-30 | no consta | Gustavo Neira |
| REQ-4307 | Requerimiento REQ-4307 | 2026-08-05 | no consta | Rubén Cárdenas |
| REQ-4301 | Requerimiento REQ-4301 | 2026-08-06 | no consta | Beatriz Cuéllar |
| REQ-4304 | Requerimiento REQ-4304 | 2026-08-10 | no consta | Óscar Ramírez |
| REQ-4311 | Requerimiento REQ-4311 | 2026-08-11 | no consta | Beatriz Cuéllar |
| REQ-2028 | Requerimiento REQ-2028 | 2026-10-07 | no consta | Beatriz Cuéllar |

Nota: la fecha de decisión registrada de varios REQ (abril–agosto) es anterior a la del acta que se cita como fuente (2026-10-15); conviene revisarlo en el registro.

### La traza no se confirma
Ninguno: no hay trazas declaradas que confirmar, porque ningún REQ dice qué proyecto lo ejecuta.

### Lo que un proyecto construye y el registro no tiene
Ninguno encontrado. La única ficha disponible (PRY-204, Cross docking en el puerto) declara como producto «cross docking», no PRD-303 (`documentos/proyectos/PRY-204-cross-docking-en-el-puerto/00-gobierno/ficha-pm.json`). Ninguna otra ficha nombra a PRD-303.

### La cadena completa
Sin eslabones completos: 13 REQ aceptados llegan hasta la decisión y se detienen. Los 2 propuestos (REQ-4308, 61 días; REQ-4309, 95 días) siguen sin decidir y no entran en la cadena.

### Sin fichas a la vista
Existen 13 carpetas de proyecto (PRY-199 a PRY-211), pero solo PRY-204 tiene ficha publicada. Para los otros 12 no se pudo confirmar nada: puede que ejecuten parte del producto y no estén publicadas. Ninguna traza se da por confirmada.
