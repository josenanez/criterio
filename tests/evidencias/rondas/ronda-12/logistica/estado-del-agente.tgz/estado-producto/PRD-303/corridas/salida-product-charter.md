# Acta de constitución — REQ-4300 · borrador del 2026-10-28
**Producto:** PRD-303 Logística de frío · **Requerimientos:** REQ-4300

> **Aviso antes de leer:** REQ-4300 no pasa la verificación del paso 1. Le faltan criterios de aceptación y la autoridad del gerente no está declarada. Sesión sin interfaz: tomé la respuesta sugerida —seguir marcando cada falta como vacío del acta, sin rellenarla— y por eso el borrador existe. Con estos vacíos no recomiendo firmarlo tal cual.

## Qué problema resuelve
«El segmento Farmacéuticas no tiene logística de frío.» (`documentos/productos/PRD-303/00-definicion/2026-05-27-definicion-producto.md`, 2026-05-27).
Qué parte de ese problema cubre REQ-4300: **no consta.** El registro no tiene la necesidad del requerimiento (`need`: no encontrada) y su título es genérico («Requerimiento REQ-4300»).

## Criterio de éxito
**Vacío.** REQ-4300 no tiene criterios de aceptación: la columna del acta del comité trae «—» (`30-decisiones/2026-10-15-comite-producto.docx`). La definición del producto tampoco declara criterio de éxito (`definition.success`: no encontrado). Sin esto el cierre no se puede juzgar meses después. No lo redacto yo: lo cierra Ricardo Salas.

## Alcance
### Entra
| REQ | Título | Evidencia que lo sostiene |
|---|---|---|
| REQ-4300 | Requerimiento REQ-4300 (título genérico, no recogido) | Cliente entrevistado, 2025-10-13: «Lo necesito y hoy no lo tengo.» (`10-descubrimiento/2025-10-13-entrevistas.md`). **La entrevista no nombra este requerimiento**; es la más cercana. El acta del comité lo atribuye a «Cliente entrevistado». Tiene 12 meses y es una sola frase genérica. |

### No entra
| REQ | Título | Por qué no |
|---|---|---|
| REQ-2028, 4301–4313 | Los otros 14 requerimientos del registro | Esta acta es solo de REQ-4300. Si van en el mismo proyecto, se agregan a esta acta antes de firmarla; no los dejo entrar por omisión. |

La razón de exclusión de cada uno por separado **no consta** en ningún documento. Lo dicho arriba es solo el límite de este borrador.

## Gobierno
- **Patrocinador:** no consta en ningún documento.
- **Gerente propuesto:** no consta. Ricardo Salas es el gerente de producto y doliente de REQ-4300 (acta del comité, 2026-10-15); que sea también gerente del proyecto es una decisión que no me toca proponer con la evidencia actual.
- **Comité:** Comité de producto (`config.json` y acta del 2026-10-15). Asistente registrado en esa acta: Ricardo Salas, nadie más.
- **Autoridad del gerente del proyecto:** **vacío.** La autoridad del producto no está declarada en la definición (`identity.authority`: no encontrada). Es el campo que más cuesta después: un gerente que no sabe qué puede decidir escala todo o no escala nada.
- **Quién decidió aceptar REQ-4300:** no consta. El acta del comité fecha la aceptación en 2026-05-17, cinco meses antes del propio documento (2026-10-15), y no dice quién decidió. Su único acuerdo es «Se mantiene el plan».

## Supuestos que se llevan al proyecto
| Supuesto | Verificado | Se convierte en riesgo de |
|---|---|---|
| El precio del combustible se sostiene (declarado 2026-08-30) | Dice que sí: el anexo del 2026-09-06 afirma «se confirmó», pero no trae la medición del piloto ni dice de dónde sale. Se sostiene en la palabra del anexo. | Doliente: **por designar** (gerente del proyecto). Se registra como riesgo con la verificación pendiente de evidencia. |
| Volumen mensual de 70.118 (cifra del caso de negocio, 2026-05-27) | No. La única fuente es el propio caso de negocio; no hay serie medida en `metrics/`. | Doliente: **por designar.** Es una cifra del negocio, no mía. |

Además: el «retorno esperado en 24 meses» del caso de negocio no trae cifra. No hay con qué medirlo.

## Restricciones normativas sin resolver
| Qué toca | Obligación | Norma | Estado |
|---|---|---|---|
| Nada declarado | Ningún documento de PRD-303 menciona obligación normativa | — | **No barrido.** Es logística de frío para el segmento Farmacéuticas y es razonable que haya obligaciones. No las inventé ni las descarté; el barrido no se ha corrido. |

## Vacíos de este acta
| Qué falta | Consecuencia de firmar sin eso | Quién lo cierra |
|---|---|---|
| Criterios de aceptación de REQ-4300 | El proyecto no tiene criterio de éxito; el cierre no se podrá juzgar | Ricardo Salas (doliente) |
| Criterio de éxito del producto | Igual: nada contra qué medir el proyecto | Ricardo Salas |
| Autoridad del gerente | El proyecto no sabrá qué puede decidir y qué escalar | Comité de producto |
| Quién decidió aceptar, y cuándo | La decisión no es trazable; la fecha es anterior al documento que la respalda | Comité de producto |
| Evidencia de demanda específica | Se construye sobre una frase genérica de hace 12 meses que no nombra el requerimiento | Ricardo Salas |
| Patrocinador y gerente del proyecto | No hay a quién entregar la ficha | Quien tenga la facultad de asignarlos |
| Barrido normativo | Obligaciones sin descubrir hasta que cuesten | Quien corra el barrido |
| Título y necesidad de REQ-4300 | Nadie sabe con precisión qué se construye | Ricardo Salas |

---
**Esto es un borrador.** Lo firma una persona con facultad para hacerlo; no consta quién, y no la nombro. **La ficha del proyecto no se creó** y se crea solo después de la firma. El estado declarado no lo escribo ni entonces.

**Después:** cuando haya firma y un gerente de proyecto, esa persona instala `criterio-project` y corre `/pm-setup`. Con su `/pm-publish`, `/product-trace` podrá confirmar la traza, y Alba sabrá si PRD-303 se está construyendo sin preguntarle a nadie.
