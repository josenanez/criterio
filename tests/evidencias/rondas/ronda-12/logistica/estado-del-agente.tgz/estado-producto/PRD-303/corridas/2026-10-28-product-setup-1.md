# Corrida del 2026-10-28 · product-setup

PRD-303 · 15 requerimientos · 30 s · 35 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 13 |
| `evidence_stale` | 11 |
| `requirement_without_acceptance` | 6 |
| `requirement_accepted_without_evidence` | 3 |
| `requirement_undecided` | 2 |

0 preguntas a la persona (sesión sin interfaz, respuestas sugeridas); minutos hasta el primer resultado no medidos; 5 documentos, 15 requerimientos levantados; sin serie medida, sin criterio de éxito, 0 proyectos, evidencia de demanda vencida

Primera corrida: no hay una anterior contra la cual comparar.

## Lo que produjo

## Listo — Logística de frío (PRD-303)

**Lo que miré:** 5 documentos · 1 de descubrimiento (una ronda de entrevistas, 2025-10-13, con una sola cita) · la definición del 2026-05-27 · el acta del comité de producto del 2026-10-15 (.docx, leído) · lo más reciente es del 2026-10-15. Todo se pudo leer.
**Términos:** aceptados por José Francisco Ñáñez para la versión 1.3 (familia 0.12.1), fecha 2026-10-28 · comprobante en `.criterio/terminos/aceptacion-criterio-product-0.12.1-2026-10-28.md` y `.pdf` · SHA-256 `0436c0ebf441ef53`…
**Configuración:** `.criterio/producto/PRD-303/config.json` · estado en `estado-producto/PRD-303` (la carpeta `estado/` es de otro agente y no se tocó). Verificada: ok.
**Registro levantado:** la ficha del producto y 15 requerimientos (13 aceptados, 2 propuestos), todos tal como los dice el acta.

### Lo que tu definición afirma, y qué lo sostiene
| Afirmación | Sostenida por | De cuándo |
|---|---|---|
| «El segmento Farmacéuticas no tiene logística de frío» | Una sola cita de un «cliente entrevistado» sin nombre: «Lo necesito y hoy no lo tengo.» No dice que sea una farmacéutica ni que hable de frío | 2025-10-13 |
| «Propuesta principal» | Nada: es un texto de relleno, no una propuesta | — |
| volumen_mensual = 70.118 | Solo el propio caso de negocio; ninguna serie medida | 2026-05-27 |
| «Retorno esperado en 24 meses» | Nada: no hay cifra ni cálculo | 2026-05-27 |
| «El precio del combustible se sostiene» (supuesto) | El supuesto declarado el 2026-08-30 y un anexo que dice «se confirmó» | 2026-09-06 |

### Lo que no está dicho en ninguna parte
- Que las farmacéuticas, como segmento, carezcan de logística de frío: ningún documento lo afirma con datos ni lo nombra.
- Cuál es la propuesta: el documento dice «Propuesta principal» y nada más.
- Qué es éxito: no hay criterio de éxito (`success` queda sin dato).
- De dónde sale 70.118 al mes y qué mide.
- Cómo se llega al retorno de 24 meses.
- Quién tiene la autoridad de decidir qué se construye: el acta es de un «Comité de producto» y solo registra a Ricardo Salas como asistente; no dice quién decidió. En la configuración quedó «Comité de producto» como propuesta, no como dato de un documento.
- El problema de cada uno de los 15 requerimientos: todos se llaman «Requerimiento REQ-xxxx» y ninguno dice qué se necesita.
- Qué plan «se mantiene» (la decisión del acta): no hay plan en la carpeta.
- Cifras del recálculo: 15 requerimientos; 10 con evidencia (76,9 %); 0 con proyecto que los ejecute (0,0 %). Señales: 3 aceptados sin evidencia (REQ-2028, REQ-4301, REQ-4312), 6 aceptados sin criterio de aceptación, 13 aceptados sin proyecto, 11 con evidencia vencida, 2 propuestos sin decidir (REQ-4308 con 61 días, REQ-4309 con 95 días).
- Contraste de cifras con datos medidos: **no hay serie medida a la vista.** Nadie está midiendo lo que el caso de negocio afirmó, así que no se puede calcular ninguna desviación.

### Supuestos sobre los que está escrita
- Uno solo, declarado: «El precio del combustible se sostiene» (declarado el 2026-08-30, tres meses después de la definición). Figura como verificado con «la medición del piloto del 2026-09-06», pero el anexo que dice ser esa evidencia solo trae «se confirmó»: no trae la medición. Se registra como verificado según el documento y con esa reserva.
- No declara supuesto alguno sobre que el cliente pagaría, el volumen o el retorno.

### Qué le falta a tu carpeta
- Las transcripciones completas de las entrevistas: hoy hay una ronda con una sola cita, y diez requerimientos se apoyan en ella. Es del 2025-10-13 y ya cumple los 12 meses: toda la evidencia de demanda está vencida.
- La serie del volumen mensual con su fuente (carpeta de métricas).
- Las decisiones del comité con quién decidió; sin eso, un requerimiento aceptado no se distingue de uno que nadie revisó.
- REQ-2028 sigue otra numeración que los demás (REQ-43xx) y fue aceptado el 2026-10-07: conviene confirmar que es de este producto.
- Ningún proyecto declarado: 13 aceptados y ninguno con quien los construya.
- No dejé la marca `_CRITERIO_PRODUCTO.txt` en tu carpeta: no la pidió nadie y es lo único que un agente escribiría dentro de tus documentos.

### Después
`/product-discovery` sobre el material de entrevistas: ahí los temas se vuelven requerimientos con la cita de quién los pidió.
