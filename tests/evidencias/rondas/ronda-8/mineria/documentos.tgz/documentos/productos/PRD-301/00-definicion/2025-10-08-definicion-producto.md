# Definición de producto · Alerta de taludes

**Código:** PRD-301
**Gerente de producto:** Diana Molina
**Segmento:** Operadores
**Fecha de la definición:** 2025-10-08

## El problema

El segmento Operadores no tiene alerta de taludes.

## La propuesta

- Propuesta principal

## Supuestos

- **Operaciones adopta la herramienta** · declarado el 2026-07-18 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
