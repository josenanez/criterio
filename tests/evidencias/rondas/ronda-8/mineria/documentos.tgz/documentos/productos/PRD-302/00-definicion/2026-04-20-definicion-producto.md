# Definición de producto · Despacho de flota

**Código:** PRD-302
**Gerente de producto:** Rubén Cárdenas
**Segmento:** Comunidad
**Fecha de la definición:** 2026-04-20

## El problema

El segmento Comunidad no tiene despacho de flota.

## La propuesta

- Propuesta principal

## Supuestos

- **El proveedor cumple el tiempo pactado** · declarado el 2026-04-04 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
