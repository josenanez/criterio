# Caso de negocio · Reporte ambiental

**Código:** PRD-307
**Fecha:** 2026-06-27
**Preparado por:** Óscar Ramírez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 103.037 | Caso de negocio, 2026-06-27 |

## Retorno esperado

Retorno esperado en 24 meses.
