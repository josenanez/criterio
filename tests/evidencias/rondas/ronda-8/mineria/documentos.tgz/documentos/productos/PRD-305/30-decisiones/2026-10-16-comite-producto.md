# Comité de producto · Alerta de fatiga

**Fecha:** 2026-10-16
**Asistentes:** Elena Duarte

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4500 | Requerimiento REQ-4500 | Javier Hoyos | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-10 | — |
| REQ-4501 | Requerimiento REQ-4501 | sin asignar | se verifica en producción | Cliente entrevistado | propuesto | 2026-03-18 | — |
| REQ-4502 | Requerimiento REQ-4502 | Sandra Gil | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-03 | — |
| REQ-4503 | Requerimiento REQ-4503 | Camilo Beltrán | se verifica en producción | — | aceptado | 2026-05-14 | — |
| REQ-4504 | Requerimiento REQ-4504 | Mauricio Pérez | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-27 | — |
| REQ-4505 | Requerimiento REQ-4505 | sin asignar | se verifica en producción | Cliente entrevistado | propuesto | 2026-03-30 | — |
| REQ-4506 | Requerimiento REQ-4506 | Natalia Ospina | se verifica en producción | — | aceptado | 2026-06-04 | — |
| REQ-4507 | Requerimiento REQ-4507 | Natalia Ospina | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-07 | — |
| REQ-4508 | Requerimiento REQ-4508 | Felipe Arango | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-17 | — |
| REQ-4509 | Requerimiento REQ-4509 | sin asignar | se verifica en producción | Cliente entrevistado | propuesto | 2026-03-19 | — |
| REQ-4510 | Requerimiento REQ-4510 | Ricardo Salas | se verifica en producción | — | propuesto | 2026-07-23 | — |
| REQ-4511 | Requerimiento REQ-4511 | Carlos Peña | se verifica en producción | Cliente entrevistado | propuesto | 2026-04-03 | — |
| REQ-4512 | Requerimiento REQ-4512 | Mauricio Pérez | — | Cliente entrevistado | propuesto | 2026-06-03 | — |
| REQ-4513 | Requerimiento REQ-4513 | Jorge Medina | — | Cliente entrevistado | aceptado | 2026-04-09 | — |

## Decisiones

- Se mantiene el plan
