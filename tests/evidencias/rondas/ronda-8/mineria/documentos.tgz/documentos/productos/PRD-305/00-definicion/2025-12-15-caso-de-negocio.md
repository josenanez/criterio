# Caso de negocio · Alerta de fatiga

**Código:** PRD-305
**Fecha:** 2025-12-15
**Preparado por:** Elena Duarte

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 109.357 | Caso de negocio, 2025-12-15 |

## Retorno esperado

Retorno esperado en 24 meses.
