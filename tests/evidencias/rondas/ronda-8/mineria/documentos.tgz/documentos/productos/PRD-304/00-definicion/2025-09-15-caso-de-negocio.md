# Caso de negocio · Trazabilidad

**Código:** PRD-304
**Fecha:** 2025-09-15
**Preparado por:** Andrés Lozano

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 240.425 | Caso de negocio, 2025-09-15 |

## Retorno esperado

Retorno esperado en 24 meses.
