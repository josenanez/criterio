# Caso de negocio · Monitoreo de flota

**Código:** PRD-300
**Fecha:** 2026-04-13
**Preparado por:** Javier Hoyos

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 222.248 | Caso de negocio, 2026-04-13 |

## Retorno esperado

Retorno esperado en 24 meses.
