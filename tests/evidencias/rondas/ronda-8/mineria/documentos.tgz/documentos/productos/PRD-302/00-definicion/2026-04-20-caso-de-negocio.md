# Caso de negocio · Despacho de flota

**Código:** PRD-302
**Fecha:** 2026-04-20
**Preparado por:** Rubén Cárdenas

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 119.002 | Caso de negocio, 2026-04-20 |

## Retorno esperado

Retorno esperado en 24 meses.
