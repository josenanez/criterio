# Definición de producto · Trazabilidad

**Código:** PRD-304
**Gerente de producto:** Andrés Lozano
**Segmento:** Operadores
**Fecha de la definición:** 2025-09-15

## El problema

El segmento Operadores no tiene trazabilidad.

## La propuesta

- Propuesta principal

## Supuestos

- **Operaciones adopta la herramienta** · declarado el 2026-07-24 · verificado con la medición del piloto del 2026-09-26 (anexo «Verificación del supuesto» del 2026-09-26)

## Proyectos que lo construyen

- Ninguno declarado
