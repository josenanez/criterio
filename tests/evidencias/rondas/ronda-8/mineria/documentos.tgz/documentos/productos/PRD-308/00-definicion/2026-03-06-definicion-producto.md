# Definición de producto · Permisos de trabajo digitales

**Código:** PRD-308
**Gerente de producto:** Liliana Torres
**Segmento:** Comunidad
**Fecha de la definición:** 2026-03-06

## El problema

El segmento Comunidad no tiene permisos de trabajo digitales.

## La propuesta

- Propuesta principal

## Supuestos

- **La red de la mina soporta el volumen** · declarado el 2026-04-23 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
