# Caso de negocio · Inspección con drones

**Código:** PRD-309
**Fecha:** 2026-02-18
**Preparado por:** Felipe Arango

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 203.532 | Caso de negocio, 2026-02-18 |

## Retorno esperado

Retorno esperado en 24 meses.
