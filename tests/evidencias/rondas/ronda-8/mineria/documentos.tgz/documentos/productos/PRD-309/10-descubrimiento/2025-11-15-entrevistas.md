# Entrevistas · Inspección con drones

**Ronda:** Ronda · 2025-11-15
**Realizadas por:** Felipe Arango

### Cliente entrevistado · 2025-11-15

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
