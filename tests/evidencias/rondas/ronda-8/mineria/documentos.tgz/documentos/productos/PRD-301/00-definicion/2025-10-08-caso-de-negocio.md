# Caso de negocio · Alerta de taludes

**Código:** PRD-301
**Fecha:** 2025-10-08
**Preparado por:** Diana Molina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 224.009 | Caso de negocio, 2025-10-08 |

## Retorno esperado

Retorno esperado en 24 meses.
