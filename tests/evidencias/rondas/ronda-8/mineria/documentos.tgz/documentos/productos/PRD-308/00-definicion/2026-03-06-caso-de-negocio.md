# Caso de negocio · Permisos de trabajo digitales

**Código:** PRD-308
**Fecha:** 2026-03-06
**Preparado por:** Liliana Torres

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 228.473 | Caso de negocio, 2026-03-06 |

## Retorno esperado

Retorno esperado en 24 meses.
