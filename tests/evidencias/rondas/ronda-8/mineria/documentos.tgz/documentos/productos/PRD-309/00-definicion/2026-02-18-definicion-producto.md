# Definición de producto · Inspección con drones

**Código:** PRD-309
**Gerente de producto:** Felipe Arango
**Segmento:** Comunidad
**Fecha de la definición:** 2026-02-18

## El problema

El segmento Comunidad no tiene inspección con drones.

## La propuesta

- Propuesta principal

## Supuestos

- **El ahorro se sostiene sin inversión adicional** · declarado el 2026-07-17 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
