# Tablero de métricas · Permisos de trabajo digitales

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-08

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 184.880 | 2026-10-08 |
