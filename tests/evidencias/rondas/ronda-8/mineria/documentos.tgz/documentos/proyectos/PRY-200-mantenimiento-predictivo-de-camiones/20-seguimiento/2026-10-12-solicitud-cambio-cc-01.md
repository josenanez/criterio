# Solicitud de cambio CC-01

**Proyecto:** PRY-200 · Mantenimiento predictivo de camiones
**Fecha:** 2026-10-12
**Solicitante:** Rubén Cárdenas

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +104 días sobre la línea base vigente |
| Costo | 208.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
