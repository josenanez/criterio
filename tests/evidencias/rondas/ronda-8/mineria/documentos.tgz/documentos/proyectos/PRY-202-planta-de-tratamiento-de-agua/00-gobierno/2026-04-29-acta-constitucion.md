# Acta de constitución · Planta de tratamiento de agua

**Código:** PRY-202
**Área dueña:** Geología
**Patrocinador:** Gustavo Neira
**Gerente de proyecto:** Paula Céspedes
**Comité:** Comité de Operaciones
**Producto asociado:** No aplica
**Fecha de aprobación:** 2026-04-29

## Objetivo del negocio

Entregar planta de tratamiento de agua para Geología.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**18.000.000.000 COP**, aprobado por Comité de Operaciones el 2026-04-29.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-05-09 |
| Cierre | 2026-11-09 |

## Criterio de éxito

Planta de tratamiento de agua en producción y medido.

## Dependencias declaradas

- Ninguna declarada
