# Informe de avance · Monitoreo de taludes

**Código:** PRY-204
**Fecha de corte:** 2026-10-17
**Gerente:** Beatriz Cuéllar

## Estado declarado

**Verde**

Avance reportado: **45%**

## Lo que pasó en el periodo

- Se levantó un hallazgo en la auditoría de seguridad
- El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite

## Presupuesto

| | COP |
|---|---|
| Aprobado | 800.000.000 |
| Comprometido | 434.957.088 |
| Ejecutado | 361.778.067 |
| Proyección al cierre | 765.155.217 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
