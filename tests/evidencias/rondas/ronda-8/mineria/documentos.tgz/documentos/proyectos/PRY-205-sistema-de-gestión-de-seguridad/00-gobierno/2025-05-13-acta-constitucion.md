# Acta de constitución · Sistema de gestión de seguridad

**Código:** PRY-205
**Área dueña:** Planta de procesamiento
**Patrocinador:** Jorge Medina
**Gerente de proyecto:** Gustavo Neira
**Comité:** Comité de Operaciones
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-05-13

## Objetivo del negocio

Entregar sistema de gestión de seguridad para Planta de procesamiento.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**800.000.000 COP**, aprobado por Comité de Operaciones el 2025-05-13.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-05-23 |
| Cierre | 2026-03-19 |

## Criterio de éxito

Sistema de gestión de seguridad en producción y medido.

## Dependencias declaradas

- Ninguna declarada
