# Acta de constitución · Programa de relacionamiento comunitario

**Código:** PRY-210
**Área dueña:** Logística
**Patrocinador:** Jorge Medina
**Gerente de proyecto:** Paula Céspedes
**Comité:** Comité de Tecnología
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-11-19

## Objetivo del negocio

Entregar programa de relacionamiento comunitario para Logística.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**2.400.000.000 COP**, aprobado por Comité de Tecnología el 2025-11-19.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-11-29 |
| Cierre | 2026-12-25 |

## Criterio de éxito

Programa de relacionamiento comunitario en producción y medido.

## Dependencias declaradas

- Ninguna declarada
