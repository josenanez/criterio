# Informe de avance · Mantenimiento predictivo de camiones

**Código:** PRY-200
**Fecha de corte:** 2026-10-09
**Gerente:** Rubén Cárdenas

## Estado declarado

**Rojo**

Avance reportado: **36%**

## Lo que pasó en el periodo

- Se actualizó el presupuesto de la obra con el área de compras
- Las lluvias detuvieron el montaje durante diez días

## Presupuesto

| | COP |
|---|---|
| Aprobado | 800.000.000 |
| Comprometido | 624.011.195 |
| Ejecutado | 163.775.869 |
| Proyección al cierre | 883.635.954 |

## Riesgos abiertos

- Ventana de parada de planta definida por operaciones
- Concentración del conocimiento en una sola persona
