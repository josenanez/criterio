# Comité de Inversiones · Mantenimiento predictivo de camiones

**Fecha:** 2026-10-05
**Asistentes:** Rubén Cárdenas, Ricardo Salas

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Paula Céspedes | Entregar el punto 8 | 2026-11-09 |
