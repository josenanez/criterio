# Comité de Operaciones · Ampliación de la relavera

**Fecha:** 2026-09-12
**Asistentes:** Andrés Lozano, Felipe Arango, María Restrepo, Mauricio Pérez, Paula Céspedes, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Paula Céspedes | Enviar el documento 1 | 2026-09-22 |
| María Restrepo | Cerrar la prueba 2 | 2026-09-25 |
| Felipe Arango | Revisar el anexo 3 | 2026-09-10 |
| Felipe Arango | Validar el ambiente 4 | 2026-10-22 |
| Andrés Lozano | Aprobar el diseño 5 | 2026-09-22 |
| Mauricio Pérez | Actualizar la matriz 6 | 2026-09-15 |
| Mauricio Pérez | Confirmar la fecha 7 | 2026-10-09 |
| Óscar Ramírez | Entregar el punto 8 | por definir |
