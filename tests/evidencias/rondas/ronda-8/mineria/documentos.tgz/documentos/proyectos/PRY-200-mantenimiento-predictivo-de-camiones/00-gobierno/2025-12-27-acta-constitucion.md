# Acta de constitución · Mantenimiento predictivo de camiones

**Código:** PRY-200
**Área dueña:** Planta de procesamiento
**Patrocinador:** Ricardo Salas
**Gerente de proyecto:** Rubén Cárdenas
**Comité:** Comité de Inversiones
**Producto asociado:** monitoreo de flota
**Fecha de aprobación:** 2025-12-27

## Objetivo del negocio

Entregar mantenimiento predictivo de camiones para Planta de procesamiento.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**800.000.000 COP**, aprobado por Comité de Inversiones el 2025-12-27.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-01-06 |
| Cierre | 2027-04-11 |

## Criterio de éxito

Mantenimiento predictivo de camiones en producción y medido.

## Dependencias declaradas

- Ninguna declarada
