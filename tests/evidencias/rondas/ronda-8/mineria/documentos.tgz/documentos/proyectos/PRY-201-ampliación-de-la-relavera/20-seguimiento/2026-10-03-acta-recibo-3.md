# Acta de recibo · Revisar el anexo 3

**Proyecto:** PRY-201 · Ampliación de la relavera
**Fecha de recibo:** 2026-10-03
**Recibido por:** Mauricio Pérez

Se recibe a satisfacción: **Revisar el anexo 3**, compromiso de Felipe Arango.
