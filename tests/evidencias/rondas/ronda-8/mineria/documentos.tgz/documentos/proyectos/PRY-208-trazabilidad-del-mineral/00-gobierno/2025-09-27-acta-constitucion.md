# Acta de constitución · Trazabilidad del mineral

**Código:** PRY-208
**Área dueña:** Tecnología
**Patrocinador:** Sandra Gil
**Gerente de proyecto:** Laura Vélez
**Comité:** Comité de Seguridad
**Producto asociado:** trazabilidad
**Fecha de aprobación:** 2025-09-27

## Objetivo del negocio

Entregar trazabilidad del mineral para Tecnología.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**9.500.000.000 COP**, aprobado por Comité de Seguridad el 2025-09-27.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-10-07 |
| Cierre | 2026-08-31 |

## Criterio de éxito

Trazabilidad del mineral en producción y medido.

## Dependencias declaradas

- Ninguna declarada
