# Informe de avance · Sistema de gestión de seguridad

**Código:** PRY-205
**Fecha de corte:** 2026-10-13
**Gerente:** Gustavo Neira

## Estado declarado

**Rojo**

Avance reportado: **68%**

## Lo que pasó en el periodo

- El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite
- Se levantó un hallazgo en la auditoría de seguridad
- Se recibió el permiso ambiental pendiente desde el trimestre anterior

## Presupuesto

| | COP |
|---|---|
| Aprobado | 800.000.000 |
| Comprometido | 595.392.641 |
| Ejecutado | 230.242.278 |
| Proyección al cierre | 901.106.299 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
