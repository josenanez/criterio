# Comité de Inversiones · Control de polvo en vías

**Fecha:** 2026-10-12
**Asistentes:** Sandra Gil, Jorge Medina

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Sandra Gil | Entregar el punto 33 | 2026-10-29 |
