# Corrida del 2026-10-17 · product-charter

PRD-304 · 16 requerimientos · 35 s · 40 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 14 |
| `requirement_untraced` | 11 |
| `requirement_without_acceptance` | 5 |
| `requirement_undecided` | 5 |
| `requirement_without_owner` | 3 |
| `requirement_accepted_without_evidence` | 2 |

Borrador de acta para REQ-4400 con 9 vacíos: sin criterios de aceptación, doliente, quién lo aceptó, autoridad ni patrocinador; evidencia de demanda no nombra el requerimiento; supuesto verificado con una medición que no está en la carpeta. Sin firma no se creó la ficha.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

# Acta de constitución — Requerimiento REQ-4400 (Trazabilidad) · borrador del 2026-10-17
**Producto:** PRD-304 Trazabilidad · **Requerimientos:** REQ-4400

> Pregunta de verificación (sin interfaz): el requerimiento no pasa dos de las cuatro condiciones previas. Respuesta sugerida tomada: **seguir, marcando cada falta como vacío del acta, sin rellenar nada**.

## Verificación previa

| Condición | Resultado | Cita |
|---|---|---|
| Aceptado (no propuesto) | **Sí, con reparo:** figura «aceptado», pero ningún documento dice quién lo decidió (`decision.who` vacío). El acta del comité solo registra «Se mantiene el plan». | `30-decisiones/2026-09-16-comite-producto.docx` |
| Criterios de aceptación verificables | **Falta.** La celda del acta del comité es «—». | `30-decisiones/2026-09-16-comite-producto.docx` |
| Evidencia de demanda con cita | **Débil.** El acta atribuye el pedido a un «cliente entrevistado» sin nombre; la entrevista (2025-10-15) tiene una sola cita, «Lo necesito y hoy no lo tengo.», que no nombra este requerimiento. Es evidencia del producto, no de REQ-4400. | `10-descubrimiento/2025-10-15-entrevistas.md` |
| Autoridad declarada en la definición | **Falta.** La definición no la dice. «Comité de producto» sale del título del acta, no de un texto que diga quién decide qué se construye. | `00-definicion/2025-09-15-definicion-producto.md` |

## Qué problema resuelve
«El segmento Operadores no tiene trazabilidad.» (`00-definicion/2025-09-15-definicion-producto.md`, 2025-09-15). La propuesta está con texto de relleno («Propuesta principal»): no está descrita. De REQ-4400 mismo no hay necesidad escrita: el título es genérico («Requerimiento REQ-4400») y el campo `need` no existe en ningún documento.

## Criterio de éxito
**No está dicho.** La definición no declara éxito del producto y REQ-4400 no tiene criterios de aceptación. Sin esto el cierre del proyecto no se podrá juzgar. No se propone uno: lo cierra el gerente de producto.

## Alcance
### Entra
| REQ | Título | Evidencia que lo sostiene |
|---|---|---|
| REQ-4400 | Requerimiento REQ-4400 (sin título descriptivo) | Cita de entrevista sin nombre que no menciona el requerimiento (2025-10-15). Desde 2026-07-08, doliente «sin asignar», sin proyecto que lo ejecute. |

### No entra
| REQ | Título | Por qué no |
|---|---|---|
| REQ-4401 a REQ-4415 | (los otros 15 del registro) | No se pidieron en este acta. Ningún documento dice que estén excluidos ni por qué: la razón de exclusión de cada uno la tiene que dar quien decide el alcance. |

## Gobierno
- **Patrocinador:** no está dicho en ningún documento.
- **Gerente propuesto del proyecto:** no está dicho. El único nombre es Andrés Lozano, gerente de **producto** y único asistente del comité (`00-definicion/2025-09-15-definicion-producto.md`, `30-decisiones/2026-09-16-comite-producto.docx`). No se le propone como gerente de proyecto: asignar a una persona le toca a quien tiene la autoridad.
- **Comité:** Comité de producto, tomado del título del acta (2026-09-16).
- **Autoridad del gerente:** no está dicha.
- **Doliente de REQ-4400:** «sin asignar».

## Supuestos que se llevan al proyecto
| Supuesto | Verificado | Se convierte en riesgo de |
|---|---|---|
| Operaciones adopta la herramienta (declarado 2026-07-24) | Marcado «verificado» por un anexo del 2026-09-26 que dice «se confirmó» y cita una medición del piloto **que no está en la carpeta**. No se puede comprobar; se lleva como no verificado. | Sin doliente: lo asigna quien firma. |

## Restricciones normativas sin resolver
| Qué toca | Obligación | Norma | Estado |
|---|---|---|---|
| Nada identificado en los documentos leídos | — | — | No se hizo barrido normativo: la definición no describe datos, pagos ni retención, así que no hay de qué anclarlo. No equivale a «no hay obligaciones». |

## Vacíos de este acta
| Qué falta | Consecuencia de firmar sin eso | Quién lo cierra |
|---|---|---|
| Criterios de aceptación de REQ-4400 | El proyecto arranca sin criterio de éxito; el cierre no se podrá juzgar. | Gerente de producto (Andrés Lozano) con el doliente |
| Doliente del requerimiento | Nadie responde por qué se pidió ni valida el resultado. | Gerente de producto |
| Quién aceptó el requerimiento | No hay decisión rastreable de que se construya. | Comité de producto |
| Evidencia de demanda específica de REQ-4400 | Se construye sobre una cita general sin nombre. | Gerente de producto |
| Autoridad del gerente del proyecto | Escala todo o no escala nada. | Comité de producto |
| Patrocinador y gerente del proyecto | No hay quién firme ni quién reciba la ficha. | Quien tenga la autoridad |
| Criterio de éxito del producto y propuesta descrita | No hay contra qué medir. | Gerente de producto |
| Retorno esperado: el caso de negocio dice «Retorno esperado en 24 meses.» sin cifra; el volumen mensual (240.425) no trae medición propia | Presupuesto y retorno sin base. | Dueño del caso de negocio |
| Medición del piloto que sustenta el supuesto | El supuesto se lleva sin sustento. | Gerente de producto |

---
**Esto es un borrador.** Lo firma quien tenga la autoridad sobre qué se construye; hoy ningún documento dice quién es (se sugiere el Comité de producto). **La ficha del proyecto no se crea: sin firma y con estos vacíos, `portafolio.py init` no se corrió.** El estado declarado nunca lo escribe este comando.

**Qué sigue:** tras la firma, el gerente del proyecto instala `criterio-project` y corre `/pm-setup`; cuando publique su ficha con `/pm-publish`, `/product-trace` podrá confirmar la traza, y Alba sabrá si el producto se construye sin preguntarle a nadie.
