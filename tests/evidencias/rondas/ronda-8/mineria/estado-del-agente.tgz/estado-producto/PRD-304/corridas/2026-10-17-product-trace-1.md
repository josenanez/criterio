# Corrida del 2026-10-17 · product-trace

PRD-304 · 16 requerimientos · 32 s · 40 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 14 |
| `requirement_untraced` | 11 |
| `requirement_without_acceptance` | 5 |
| `requirement_undecided` | 5 |
| `requirement_without_owner` | 3 |
| `requirement_accepted_without_evidence` | 2 |

11 requerimientos decididos y ninguno tiene proyecto; PRY-208 dice ejecutar 'trazabilidad' y ningún REQ lo nombra

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## Trazabilidad — Trazabilidad (PRD-304) · al 2026-10-17
11 decididos · 0 con proyecto · 0 confirmados contra la ficha · 0 entregados

Fichas leídas: las 13 de `estado/records` (PRY-199 a PRY-211). Ninguna de las 11 trazas llega a confirmarse porque ningún requerimiento nombra un proyecto.

### Decidido y nadie lo está construyendo
Los 11 requerimientos aceptados tienen `traces.project = null`. En todos, el registro no dice por quién se decidió (`decision.who` vacío); la fuente de la decisión es `documentos/productos/PRD-304/30-decisiones/2026-09-16-comite-producto.docx`.

| REQ | Título | Decidido el | Por quién |
|---|---|---|---|
| REQ-4409 | Requerimiento REQ-4409 | 2026-04-08 | no consta |
| REQ-4402 | Requerimiento REQ-4402 | 2026-04-20 | no consta |
| REQ-4414 | Requerimiento REQ-4414 | 2026-06-18 | no consta |
| REQ-4403 | Requerimiento REQ-4403 | 2026-07-06 | no consta |
| REQ-4400 | Requerimiento REQ-4400 | 2026-07-08 | no consta |
| REQ-4412 | Requerimiento REQ-4412 | 2026-07-14 | no consta |
| REQ-4401 | Requerimiento REQ-4401 | 2026-07-19 | no consta |
| REQ-4413 | Requerimiento REQ-4413 | 2026-07-25 | no consta |
| REQ-4410 | Requerimiento REQ-4410 | 2026-08-04 | no consta |
| REQ-4404 | Requerimiento REQ-4404 | 2026-08-11 | no consta |
| REQ-4406 | Requerimiento REQ-4406 | 2026-08-18 | no consta |

El más antiguo lleva 192 días decidido (REQ-4409) sin proyecto.

### La traza no se confirma
Ninguna: no hay trazas declaradas que confirmar, porque ningún requerimiento dice qué proyecto lo ejecuta.

### Lo que un proyecto construye y el registro no tiene
| Proyecto | Su ficha dice que ejecuta este producto | Ningún REQ lo nombra |
|---|---|---|
| PRY-208 Trazabilidad del mineral | Sí: campo producto = «trazabilidad» (acta de constitución del 2025-09-27) | Sí: los 16 REQ tienen proyecto vacío |

La coincidencia es por nombre de producto («trazabilidad»), no por código PRD-304: la ficha no trae el código. Puede ser este producto u otro que se llame igual; hay que ir a ver. Es además un hallazgo del lado del registro: PRY-208 existe desde 2025-09-27 y ninguno de los requerimientos decididos en 2026 lo menciona.

### La cadena completa
| REQ | Estado | Decisión | Proyecto | Confirmado | Entregables |
|---|---|---|---|---|---|
| REQ-4400 | aceptado | 2026-07-08 | — | no | — |
| REQ-4401 | aceptado | 2026-07-19 | — | no | — |
| REQ-4402 | aceptado | 2026-04-20 | — | no | — |
| REQ-4403 | aceptado | 2026-07-06 | — | no | — |
| REQ-4404 | aceptado | 2026-08-11 | — | no | — |
| REQ-4406 | aceptado | 2026-08-18 | — | no | — |
| REQ-4409 | aceptado | 2026-04-08 | — | no | — |
| REQ-4410 | aceptado | 2026-08-04 | — | no | — |
| REQ-4412 | aceptado | 2026-07-14 | — | no | — |
| REQ-4413 | aceptado | 2026-07-25 | — | no | — |
| REQ-4414 | aceptado | 2026-06-18 | — | no | — |
| REQ-4405, 4407, 4408, 4411, 4415 | propuesto (sin decidir, 71 a 178 días) | — | — | — | — |

La cadena se rompe en el segundo eslabón: hay decisión citada pero no hay proyecto.

### Sin fichas a la vista
No aplica: están las 13 fichas. Lo que falta no es la ficha sino el dato en el registro.
