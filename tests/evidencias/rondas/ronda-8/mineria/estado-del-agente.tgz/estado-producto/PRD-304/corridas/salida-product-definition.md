## Definición — Trazabilidad (PRD-304) · contrastada al 2026-10-17
**Documento:** `00-definicion/2025-09-15-definicion-producto.md` y `00-definicion/2025-09-15-caso-de-negocio.md` · **del** 2025-09-15 · 8 afirmaciones

(Términos vigentes: aceptados por José Francisco Ñáñez el 2026-10-17, versión 0.3.13; no se volvieron a registrar.)

### Lo que la evidencia contradice
Nada. Ninguna fuente dice lo contrario de lo que afirma la definición. Esto no es un respaldo: abajo se ve que casi nada tiene con qué contrastarse.

### El negocio y los datos
Ninguna métrica pasa del umbral (20 %), porque ninguna tiene serie medida. La carpeta `estado-producto/PRD-304/metrics` está vacía.

### Afirmaciones numéricas que nadie mide
| Afirma | De qué documento | No hay serie |
|---|---|---|
| `volumen_mensual` = 240.425 | Caso de negocio, 2025-09-15 | No hay serie. La «fuente» que cita el caso es el mismo caso de negocio. |
| `retorno_esperado` = «Retorno esperado en 24 meses» | Caso de negocio, 2025-09-15 | No hay cifra declarada ni serie: es una frase sin número. |

### No está dicho en ninguna parte
- **Criterio de éxito.** Ningún documento lo dice (`success: not_found`).
- **Quién decide qué se construye.** «Comité de producto» sale del título del acta del 2026-09-16, no de un documento que lo establezca.
- **La propuesta.** El campo dice «Propuesta principal»: es texto de relleno, la solución no está descrita.
- **Que el cliente entrevistado sea del segmento Operadores.** La entrevista no lo dice.
- **Qué tan grande es el problema** (cuántos Operadores, con qué frecuencia).
- **Cuánto pagaría alguien** o si alguien ya pagó por algo parecido.
- **Cómo se calculó el retorno** ni sobre qué costo.
- **Qué proyecto lo construye.** La definición dice «Ninguno declarado».
- **Qué cuenta como «adopta la herramienta»** (umbral, plazo, porcentaje de Operaciones).

### Sostenida por un supuesto
| Supuesto | Días sin verificar | Qué haría falta para verificarlo |
|---|---|---|
| «Operaciones adopta la herramienta» (declarado el 2026-07-24) | 0 pendientes: el anexo del 2026-09-26 lo da por verificado | Poner en la carpeta la medición del piloto del 2026-09-26, que el anexo cita pero no está, y fijar qué nivel de uso cuenta como adopción. Sin eso el «se confirmó» no se puede revisar. |

Dos observaciones sobre este supuesto: (1) está fechado el 2026-07-24 dentro de una definición fechada el 2025-09-15, es decir, el documento se editó después de su fecha y no lo dice; (2) «Operaciones» no es «Operadores», el segmento del problema, y la definición no explica la relación.

### Sostenida por evidencia
| Afirmación | Sostenida por | De cuándo | Qué tan fuerte |
|---|---|---|---|
| «El segmento Operadores no tiene trazabilidad» | Una entrevista: «Lo necesito y hoy no lo tengo.» — Cliente entrevistado (sin nombre), `10-descubrimiento/2025-10-15-entrevistas.md` | 2025-10-15 | Débil: es lo que una persona dijo que necesita, no hay compra ni uso; el entrevistado no tiene nombre; no dice que sea Operador; es una sola voz. |

### Evidencia que ya envejeció
| Afirmación | Lo más nuevo que la sostiene | Hace |
|---|---|---|
| «El segmento Operadores no tiene trazabilidad» | Entrevista del 2025-10-15 | 12 meses (umbral: 12) |

Es también la única evidencia de demanda de los 14 requerimientos que citan al «cliente entrevistado»: todos heredan la misma entrevista envejecida.

### Lo normativo que toca
| Qué toca | País | Obligación | Norma | Estado |
|---|---|---|---|---|
| Nada nombrado | No declarado | — | — | **No tengo la norma a la vista.** La definición no menciona datos personales, pagos, consumidor financiero ni retención de información, y no dice en qué país opera. Un producto de trazabilidad puede tocar retención de registros; eso lo decide quien conoce la propuesta, que aquí no está descrita. No se afirma ni que cumpla ni que no. Esto va a revisión jurídica. |

### Lo que falta para cerrar la definición
- **Criterio de éxito:** no está. Sin él la definición no se puede cerrar, porque el cierre se juzgaría contra él.
- **Quién decide:** solo inferido del título de un acta.
- **Problema y para quién:** están escritos (una frase y «Operadores»), pero con una sola entrevista de hace 12 meses.
- **Propuesta:** falta describirla.

### Contexto del cálculo
Alertas del registro de requerimientos: 14 con evidencia vieja, 11 aceptados sin proyecto que los construya, 5 aceptados sin criterio de aceptación, 5 propuestos sin decidir (71 a 178 días), 3 sin doliente, 2 aceptados sin evidencia (REQ-4401, REQ-4414). Se detallan en la corrida de requerimientos.

### Después
El supuesto de adopción tiene verificación declarada, así que no corresponde convertirlo en riesgo todavía. La definición no está cerrada (falta el criterio de éxito), por lo que no se ofrece `/product-charter`.
