## Trazabilidad (PRD-304) · 2026-10-17

**Primera revisión con corte:** no había corte anterior (`snapshots/` vacío, `last: null`), así que `crossed` no se puede calcular. Lo que sigue es la línea base: lo que hoy está abierto, que el próximo corte usará para decir qué es nuevo.

Términos: ya vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17). No se pidió nada.

### Lo que toca: `review`
- **Documentos de la carpeta:** los 5 conservan el mismo hash que en el registro. No hay documentos nuevos ni cambiados: no se ofrece `/product-discovery` ni `/product-definition`.
- **Registro:** 16 requerimientos (11 aceptados, 5 propuestos). 40 hallazgos.

### Lo que necesita decisión (para el comité)
| Qué | REQ | Cuánto lleva | Qué se necesita | Quién |
|---|---|---|---|---|
| Propuesto sin decidir (umbral 60 d) | REQ-4415 | 178 d | Decisión del comité; doliente: Andrés Lozano | Comité de producto |
| | REQ-4408 | 143 d | Ídem; doliente: Óscar Ramírez | Comité de producto |
| | REQ-4405 | 140 d | Ídem; **sin doliente** | Comité de producto |
| | REQ-4411 | 95 d | Ídem; doliente: Laura Vélez | Comité de producto |
| | REQ-4407 | 71 d | Ídem; doliente: Diana Molina | Comité de producto |
| Aceptado y nadie lo construye | los 11 aceptados (el más viejo, REQ-4409: 192 d desde su decisión) | 0 con proyecto | Decidir qué proyecto los ejecuta, o si PRY-208 es ese proyecto | Comité de producto |

El registro no dice por quién se decidió ninguno de los 11 aceptados (`decision.who` vacío); el acta del comité del 2026-09-16 es la fuente.

### Aceptados con huecos
- Sin evidencia de demanda: REQ-4401, REQ-4414.
- Sin criterio de aceptación: REQ-4400, 4402, 4404, 4410, 4414.
- Sin doliente: REQ-4400, 4405, 4414. REQ-4414 acumula los tres vacíos.

### Evidencia que se queda sin sustento (`evidence_stale`, 14 REQ)
Toda la evidencia de demanda es una sola entrevista del 2025-10-15, anónima («cliente entrevistado») y que no nombra ningún requerimiento. Cumple 12 meses hoy. Queda sin sustento que **alguien pidió estos requerimientos**, no solo un documento viejo.

### Las trazas
Ninguna se confirma: ningún REQ declara proyecto. Fichas leídas: las 13 de `estado/records`. PRY-208 «Trazabilidad del mineral» dice ejecutar «trazabilidad», pero la coincidencia es por nombre, no por código PRD-304: hay que ir a ver si es este producto.

### Definición
- Criterio de éxito: no está en ninguna parte.
- `retorno_esperado`: sin cifra. `volumen_mensual` (240.425): sin medición con la cual contrastar.
- Supuesto «Operaciones adopta la herramienta»: figura verificado, pero el anexo cita una medición del piloto que no está en la carpeta.

**Vuelvo el 2026-11-16.**
