# Corrida del 2026-10-17 · product-requirements

PRD-304 · 16 requerimientos · 43 s · 40 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 14 |
| `requirement_untraced` | 11 |
| `requirement_without_acceptance` | 5 |
| `requirement_undecided` | 5 |
| `requirement_without_owner` | 3 |
| `requirement_accepted_without_evidence` | 2 |

5 propuestos sin decidir (60+ días), 11 aceptados sin traza a proyecto ni quién decidió, REQ-4401 y REQ-4414 sin evidencia

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## Registro — Trazabilidad (PRD-304) · al 2026-10-17
16 requerimientos · 11 decididos · 81.8% con evidencia · 0% con proyecto que lo ejecuta

Aclaraciones antes de leer:
- No hay fichas de proyecto (la carpeta `estado/` está vacía), así que ningún requerimiento tiene proyecto confirmado. El 0% significa «no se pudo confirmar», no que se haya comprobado que nadie lo construye.
- El 81.8% (9 de 11 decididos) cuenta una sola evidencia: una cita genérica de un «cliente entrevistado» del 2025-10-15 («Lo necesito y hoy no lo tengo.»). El mismo registro anota que la entrevista no nombra ninguno de estos requerimientos. Es evidencia en el papel, pero no sostiene ningún requerimiento en concreto.
- Los 16 títulos son genéricos («Requerimiento REQ-44xx»). Salen del acta del comité del 2026-09-16.

### Se va a construir y nadie lo pidió
| REQ | Título | Estado | Doliente |
|---|---|---|---|
| REQ-4401 | Requerimiento REQ-4401 | aceptado | Javier Hoyos |
| REQ-4414 | Requerimiento REQ-4414 | aceptado | sin doliente |

REQ-4401 y REQ-4414 no tienen ninguna cita de quien los pidió. Los otros nueve aceptados tienen la misma cita genérica, que no los nombra (ver «Evidencia vieja»).

### Decidido y nadie lo está construyendo
Sin fichas de proyecto no se puede afirmar nada. Los 11 aceptados figuran sin traza a proyecto:

| REQ | Título | Decidido el |
|---|---|---|
| REQ-4409 | Requerimiento REQ-4409 | 2026-04-08 |
| REQ-4402 | Requerimiento REQ-4402 | 2026-04-20 |
| REQ-4414 | Requerimiento REQ-4414 | 2026-06-18 |
| REQ-4403 | Requerimiento REQ-4403 | 2026-07-06 |
| REQ-4400 | Requerimiento REQ-4400 | 2026-07-08 |
| REQ-4412 | Requerimiento REQ-4412 | 2026-07-14 |
| REQ-4401 | Requerimiento REQ-4401 | 2026-07-19 |
| REQ-4413 | Requerimiento REQ-4413 | 2026-07-25 |
| REQ-4410 | Requerimiento REQ-4410 | 2026-08-04 |
| REQ-4404 | Requerimiento REQ-4404 | 2026-08-11 |
| REQ-4406 | Requerimiento REQ-4406 | 2026-08-18 |

Quién lo cerraría: Andrés Lozano, con las fichas de PRY-208 y de los demás proyectos. `/product-trace` es el siguiente paso.

### Sin doliente, o con un área en vez de una persona
| REQ | Título | Dice |
|---|---|---|
| REQ-4400 | Requerimiento REQ-4400 | no encontrado (aceptado) |
| REQ-4414 | Requerimiento REQ-4414 | no encontrado (aceptado) |
| REQ-4405 | Requerimiento REQ-4405 | no encontrado (propuesto) |

Quién lo cerraría: Andrés Lozano, gerente del producto, designa a la persona.

### Sin criterio de aceptación
Solo los decididos:

| REQ | Título | Estado |
|---|---|---|
| REQ-4400 | Requerimiento REQ-4400 | aceptado |
| REQ-4402 | Requerimiento REQ-4402 | aceptado |
| REQ-4404 | Requerimiento REQ-4404 | aceptado |
| REQ-4410 | Requerimiento REQ-4410 | aceptado |
| REQ-4414 | Requerimiento REQ-4414 | aceptado |

Quién lo cerraría: el doliente de cada uno. REQ-4400 y REQ-4414 primero necesitan doliente.

### Decidido sin documento que lo respalde
Los 11 aceptados citan el acta del comité del 2026-09-16 como documento. Ninguno registra quién decidió; el campo «quién» está vacío en los 11.

| REQ | Quién decidió | Cuándo |
|---|---|---|
| los 11 aceptados (arriba) | no registrado | fechas de arriba |

Dato que hay que mirar: el acta es del 2026-09-16, pero las 11 decisiones tienen fecha anterior, entre abril y agosto de 2026. El acta las registró después de decididas y no dice quién las decidió. La autoridad que el producto tiene configurada es el Comité de producto.

### Lleva meses y nadie lo decide
Umbral configurado: 60 días. Los cinco propuestos lo pasan.

| REQ | Título | Propuesto hace | Quién tiene la facultad |
|---|---|---|---|
| REQ-4415 | Requerimiento REQ-4415 | 178 días | Comité de producto |
| REQ-4408 | Requerimiento REQ-4408 | 143 días | Comité de producto |
| REQ-4405 | Requerimiento REQ-4405 | 140 días | Comité de producto |
| REQ-4411 | Requerimiento REQ-4411 | 95 días | Comité de producto |
| REQ-4407 | Requerimiento REQ-4407 | 71 días | Comité de producto |

La facultad viene de la configuración del producto (autoridad: Comité de producto), no de un documento que la otorgue. Propuesta: decidir estos cinco en el próximo comité mensual. No se cierran por viejos.

### Evidencia vieja
Umbral configurado: 12 meses. La evidencia más nueva de los 14 requerimientos que citan evidencia es la misma entrevista del 2025-10-15 (cumple 12 meses en estos días):

REQ-4400, 4402, 4403, 4404, 4405, 4406, 4407, 4408, 4409, 4410, 4411, 4412, 4413 y 4415. Es una sola cita del cliente, repetida en cada uno.

### Por estado
| propuesto | aceptado | en construcción | entregado | descartado |
|---|---|---|---|---|
| 5 | 11 | 0 | 0 | 0 |

Al propuesto no se le exige evidencia ni criterio de aceptación; por eso los cinco propuestos solo aparecen en «Lleva meses» (y REQ-4405 por no tener doliente).

### Cifras de la corrida
Señales: 3 sin doliente · 5 sin criterio de aceptación · 14 evidencia vieja · 11 sin traza · 2 aceptados sin evidencia (REQ-4401, REQ-4414) · 5 sin decidir.

Fuera del registro: el caso de negocio declara `volumen_mensual` = 240425 (2025-09-15) sin medición que lo contraste. `retorno_esperado` no tiene cifra, y la definición no tiene criterio de éxito.

### Después
Hay 11 requerimientos decididos sin proyecto confirmado: `/product-trace` (necesita las fichas de los proyectos). Ninguno aceptado tiene a la vez doliente, criterio y evidencia propia, así que `/product-charter` todavía no aplica; REQ-4403, 4406, 4409, 4412 y 4413 son los más cercanos (con doliente y criterio, y con la evidencia genérica).
