**No publiqué la ficha de PRD-304 (Trazabilidad).** La configuración (`.criterio/producto/PRD-304/config.json`) no trae carpeta de productos publicados: solo `paths.documents` y `paths.state`. Sin un sitio común acordado esto no sirve, y acordarlo es una conversación de la organización, no un comando. No inventé una ruta ni creé ninguna carpeta.

**Lo que habría llevado (corte al 2026-10-17):** 16 requerimientos (11 aceptados, 5 propuestos) · 0 proyectos · 2 métricas afirmadas
**Segmento declarado:** Operadores
**Métricas:**
- `volumen_mensual`: 240425, de `documentos/productos/PRD-304/00-definicion/2025-09-15-caso-de-negocio.md` (2025-09-15)
- `retorno_esperado`: sin cifra declarada, del mismo documento

**Advertencias antes de publicar:** ninguno de los 16 requerimientos tiene proyecto (0 % trazados), así que la ficha no permitiría cruzar por proyecto compartido. Solo se podrían cruzar la métrica `volumen_mensual` y el segmento Operadores.

**Para publicar:** definir la carpeta común de fichas publicadas y añadirla a la configuración; luego se vuelve a correr `/product-publish`.
