# Corrida del 2026-10-17 · product-business-case

PRD-304 · 16 requerimientos · 39 s · 40 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 14 |
| `requirement_untraced` | 11 |
| `requirement_without_acceptance` | 5 |
| `requirement_undecided` | 5 |
| `requirement_without_owner` | 3 |
| `requirement_accepted_without_evidence` | 2 |

Borrador del caso de negocio de PRD-304: 1 de 2 cifras con fuente (volumen_mensual 240.425, declarada); sin cifra medida. Dijo que no sabe: costo de construir y de operar, valor del retorno, definición del volumen, la medición del piloto, criterio de éxito, alternativas, y demanda por requerimiento. Sin otros productos publicados para cruzar.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

# Caso de negocio — Trazabilidad (PRD-304) · borrador del 2026-10-17
**Desde:** la definición del 2025-09-15 · **Cifras con fuente:** 1 de 2

> Términos vigentes (versión 1.1), aceptados por José Francisco Ñáñez el 2026-10-17; no hizo falta registrarlos de nuevo. Las respuestas a las preguntas de la sesión son las sugeridas.

## Qué problema resuelve, y para quién
«El segmento Operadores no tiene trazabilidad.» Segmento: Operadores. (`00-definicion/2025-09-15-definicion-producto.md`, 2025-09-15.)
La propuesta que describe la definición es «Propuesta principal», que es texto de relleno: la propuesta no está descrita.

## Qué se construye
Entran los 11 requerimientos decididos (aceptados). Los 5 propuestos (REQ-4405, 4407, 4408, 4411, 4415) quedan fuera del alcance del caso.

| Requerimiento | Estado | Evidencia de demanda |
|---|---|---|
| REQ-4400 | aceptado desde 2026-07-08 | «Lo necesito y hoy no lo tengo.» — cliente entrevistado sin nombre (entrevistas 2025-10-15); la entrevista no nombra el requerimiento |
| REQ-4401 | aceptado desde 2026-07-19 | Ninguna. Sin cita de quién lo pidió |
| REQ-4402 | aceptado desde 2026-04-20 | La misma cita genérica |
| REQ-4403 | aceptado desde 2026-07-06 | La misma cita genérica |
| REQ-4404 | aceptado desde 2026-08-11 | La misma cita genérica |
| REQ-4406 | aceptado desde 2026-08-18 | La misma cita genérica |
| REQ-4409 | aceptado desde 2026-04-08 | La misma cita genérica |
| REQ-4410 | aceptado desde 2026-08-04 | La misma cita genérica |
| REQ-4412 | aceptado desde 2026-07-14 | La misma cita genérica |
| REQ-4413 | aceptado desde 2026-07-25 | La misma cita genérica |
| REQ-4414 | aceptado desde 2026-06-18 | Ninguna. El acta tampoco dice quién lo pidió |

Nueve de los 11 tienen doliente; REQ-4400 y REQ-4414 no. Ninguno de los aceptados tiene proyecto que lo ejecute, y el acta no dice quién los aceptó. Todos los aceptados que tienen cita remiten a una sola frase de un solo entrevistado, de 2025-10-15.

## Las cifras
| Cifra | Valor | Clase | De dónde sale | De cuándo |
|---|---|---|---|---|
| volumen_mensual | 240.425 | **Declarada** | Caso de negocio (Andrés Lozano) | 2025-09-15 |
| Retorno esperado | sin valor: el texto solo dice «Retorno esperado en 24 meses.» | **Sin cifra** (va a vacíos) | Caso de negocio | 2025-09-15 |
| Adopción por Operaciones | «se confirmó» | **Supuesta, verificación no sustentada** | Anexo de verificación del 2026-09-26, que cita una medición del piloto que no está en la carpeta | 2026-09-26 |

No hay ninguna cifra **medida**: no existe una serie con fuente y corte para este producto. El 240.425 no dice a qué se refiere (transacciones, operaciones, trazas) ni cómo se calculó; su única fuente es el mismo caso de negocio que lo afirma.

### Donde la cifra declarada y la medida no coinciden
No hay cifra medida con la cual contrastar `volumen_mensual`. Con el umbral de 20 % del que parte la configuración (`claim_gap_pct`), la comparación no se puede hacer hoy. Se anota como vacío.

## Los costos
| Concepto | Valor | De dónde sale |
|---|---|---|
| Costo de construir | **Sin fuente** | Ningún documento: ni contrato, ni cotización, ni costo declarado del equipo |
| Costo de operar | **Sin fuente** | — |

**El costo de construir es el primer vacío.** Sin él lo que hay es una propuesta, no un caso de negocio que evaluar.

## Supuestos sobre los que se sostiene
| Supuesto | Qué pasa si resulta falso | Quién lo verificaría |
|---|---|---|
| Operaciones adopta la herramienta (declarado 2026-07-24; el anexo del 2026-09-26 dice «se confirmó») | No se puede decir con esta evidencia: no hay cifra de adopción en el caso. Hay que fijar qué volumen depende de esa adopción | Quien hizo la medición del piloto; hoy no hay medición en la carpeta, así que el «confirmado» no se puede comprobar |
| El volumen mensual de 240.425 se alcanzará | Cae todo lo que dependa de él | Nadie lo ha respaldado: es declarado, sin base |
| El retorno llega dentro de 24 meses | Sin cifra de retorno ni de costo no hay forma de decir qué lo desmentiría | Andrés Lozano, que preparó el caso |

## Vacíos
| Qué falta | Por qué importa | Quién lo produce |
|---|---|---|
| Costo de construir y de operar | Sin él no hay caso de negocio que evaluar | Quien administre el presupuesto del producto; hoy no está nombrado |
| Valor y base del retorno esperado | «Retorno esperado en 24 meses» no es una cifra | Andrés Lozano, con el negocio |
| Qué mide `volumen_mensual` y cómo se calculó | Una cifra sin definición no se puede contrastar con una serie | Andrés Lozano |
| La medición del piloto del 2026-09-26 | Es lo único que sostiene el supuesto de adopción y no está en la carpeta | Quien corrió el piloto |
| Una serie medida del producto | Sin ella no se puede cruzar lo declarado con lo medido | El sistema donde el producto vive |
| Criterio de éxito | La definición no lo trae (`success`: no encontrado) | Andrés Lozano, con el comité de producto |
| Qué pasa si no se hace | No está en ningún documento | Andrés Lozano |
| Alternativas consideradas | No están en ningún documento | Andrés Lozano |
| Demanda por requerimiento | Los 9 aceptados con cita comparten una frase genérica; REQ-4401 y REQ-4414 no tienen ninguna | Quien hizo las entrevistas, o el comité |
| Doliente de REQ-4400 y REQ-4414 | Aceptados sin nadie responsable | Comité de producto |
| Quién decidió el alcance | El acta dice «Se mantiene el plan» y no nombra quién acepta | Comité de producto |

## Cómo se sabrá si funcionó
**No está declarado.** La definición no trae criterio de éxito, métrica ni fecha de corte. Sin esto el producto no se puede cerrar meses después. Lo que falta es la métrica, el valor objetivo y una fecha de corte, y lo debe fijar quien tenga autoridad sobre el producto (Comité de producto).

## Si hay otros productos publicados
No hay ninguna ficha de producto publicada a la vista. Existen carpetas de otros nueve productos (PRD-299 a PRD-309), pero ninguna cifra de ellas coincide con 240.425; el cruce con `/product-overlap` queda pendiente hasta que se publiquen.

## Lo que este documento no hace
No proyecta ingresos, no calcula retorno ni recuperación, no rellena vacíos con valores de referencia del sector y no recomienda aprobar ni rechazar.

## Después
Ofrezco pasar los tres supuestos de la tabla al seguimiento con **assumption-tracking**. Si el caso se aprueba, el paso siguiente es `/product-charter`.
