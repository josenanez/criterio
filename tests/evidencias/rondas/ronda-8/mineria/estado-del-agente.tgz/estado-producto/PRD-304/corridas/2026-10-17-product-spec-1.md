# Corrida del 2026-10-17 · product-spec

PRD-304 · 16 requerimientos · 40 s · 40 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 14 |
| `requirement_untraced` | 11 |
| `requirement_without_acceptance` | 5 |
| `requirement_undecided` | 5 |
| `requirement_without_owner` | 3 |
| `requirement_accepted_without_evidence` | 2 |

Borrador de especificación de PRD-304: 11 aceptados cubiertos solo por referencia; ninguno tiene necesidad descrita. Dijo que no sabía: necesidad, criterio verificable, quién decidió, medición del piloto, obligaciones normativas.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

# Especificación — Trazabilidad (PRD-304) · borrador del 2026-10-17

> **Borrador.** Lo escribe el agente; lo cierra Andrés Lozano (gerente de producto) con el Comité de producto como autoridad. Este agente no aprueba ni firma.

**Resultado en una línea:** el registro no permite escribir una especificación de comportamiento. Ninguno de los 11 requerimientos aceptados tiene descrita su necesidad, ni título propio (todos se llaman «Requerimiento REQ-44xx»). Lo que sigue es el armazón con los huecos a la vista; no los rellené con lo razonable.

## Alcance

### Entra
Los 11 requerimientos en estado `aceptado` (ninguno está en `en_construccion`). Entran por referencia: no hay texto de necesidad que convertir en comportamiento.

REQ-4400, REQ-4401, REQ-4402, REQ-4403, REQ-4404, REQ-4406, REQ-4409, REQ-4410, REQ-4412, REQ-4413, REQ-4414.
Fuente de la aceptación: acta del Comité de producto del 2026-09-16 (`30-decisiones/2026-09-16-comite-producto.docx`).

### No entra
- **REQ-4405, REQ-4407, REQ-4408, REQ-4411, REQ-4415** — siguen en `propuesto`; nadie los ha decidido. Especificarlos sería escribir el documento dos veces.
- **Arquitectura, diseño, estimación, costo y fecha** — este comando no los decide.
- **Propuesta del producto** — la definición solo dice «Propuesta principal», texto de relleno: la propuesta no está descrita (`00-definicion/2025-09-15-definicion-producto.md`). No puedo delimitar el alcance del producto a partir de ella.
- **Retorno esperado** — el caso de negocio dice «Retorno esperado en 24 meses» sin cifra (`00-definicion/2025-09-15-caso-de-negocio.md`).

## Criterios de aceptación

El único criterio que existe en el registro es «se verifica en producción». No pasa la prueba de las dos personas: no dice qué se observa, con qué umbral ni quién lo mide. **No lo reescribí con una métrica inventada.**

| Criterio | Requerimiento | Cómo se verifica | ¿Se puede medir hoy? |
|---|---|---|---|
| «se verifica en producción» | REQ-4401, 4403, 4406, 4409, 4412, 4413 | No definido: el texto no dice qué se observa ni con qué umbral | No verificable todavía: sin umbral ni método |
| (ninguno) | REQ-4400, 4402, 4404, 4410, 4414 | — | — (falta el criterio) |

Fuente de los criterios: acta del 2026-09-16.

## Supuestos sobre los que está escrita

| Supuesto | Verificado | Quién lo verificaría |
|---|---|---|
| Operaciones adopta la herramienta | Declarado como verificado, **sin sustento en la carpeta**. El anexo del 2026-09-26 dice «se confirmó» y cita «la medición del piloto del 2026-09-26», que no está entre los documentos. Además, la definición es del 2025-09-15 pero el supuesto trae fecha 2026-07-24: la definición fue editada después de su fecha o la fecha es otra. | Sin dueño nombrado. Lo sustenta quien tenga la medición del piloto; el registro no dice quién. Propongo a Andrés Lozano como quien la aporta, a confirmar. |
| El segmento «Operadores» es quien tiene el problema | No verificado. La única evidencia es una cita anónima: «Lo necesito y hoy no lo tengo.» (entrevista del 2025-10-15, más de 12 meses, supera el umbral de `evidence_stale_months`). | Sin dueño nombrado. |

## Vacíos

| Qué falta decidir | Consecuencia de no decidirlo | Quién lo cierra |
|---|---|---|
| **Necesidad de cada requerimiento (11/11).** `need` no está en ninguno; los títulos son genéricos. | No se puede escribir ninguna sección de comportamiento; cualquier texto sería del agente. | Dolientes de cada REQ (ver tabla del final); Andrés Lozano coordina. |
| **Criterio de aceptación ausente** en REQ-4400, 4402, 4404, 4410, 4414 (5). | No hay forma de saber cuándo están terminados. | REQ-4402: Natalia Ospina; 4404: Jorge Medina; 4410: Mauricio Pérez. **REQ-4400 y 4414: sin dueño.** |
| **Criterio no verificable** («se verifica en producción») en 6 REQ. | Dos personas distintas pueden llegar a respuestas opuestas. | Javier Hoyos (4401), Diana Molina (4403, 4406), Elena Duarte (4409), Felipe Arango (4412), Natalia Ospina (4413). |
| **Doliente ausente** en REQ-4400 y REQ-4414 (acta: «sin asignar»), ambos `aceptado`. | Aceptado sin nadie responsable. | Comité de producto asigna; Andrés Lozano lo lleva. |
| **Quién decidió la aceptación:** el campo `decision.who` es nulo en los 11. El acta lista como asistente solo a Andrés Lozano, y la única decisión escrita es «Se mantiene el plan». | La aceptación no queda atribuida a nadie; el acta no la sustenta con una decisión explícita. | Comité de producto, en la próxima acta. |
| **Aceptado sin evidencia de demanda:** REQ-4401 y REQ-4414 no tienen evidencia alguna (4414 además no dice quién lo pidió). Los otros 9 se apoyan en una cita anónima que, según el registro, no menciona el requerimiento. | Aceptados sin solicitante identificable. | Andrés Lozano (realizó las entrevistas). |
| **Prioridad** sin definir en los 11. | El orden de construcción lo decide quien construye por omisión. | Andrés Lozano / Comité de producto. |
| **Criterio de éxito del producto** (`success`): no encontrado. | No hay contra qué medir el producto completo. | Andrés Lozano. |
| **Proyecto que lo ejecuta:** «—» en los 11; la definición dice «Ninguno declarado». | Nadie construye lo aceptado, o se construye sin ficha. Se verá con `/criterio-product:product-trace`. | Comité de producto / PMO. |
| **Dependencias con otros equipos:** ningún documento dice qué debe hacer otro equipo. No afirmo que no existan. | No puedo decir si hay algo sin acordar. | Andrés Lozano confirma. |
| **Casos borde:** ningún documento define comportamiento fuera del caso normal. | Quedará decidido por quien construya. | Dolientes de cada REQ. |
| **Obligaciones normativas:** no se hizo barrido. La definición no menciona datos personales, pagos ni retención de información, pero tampoco describe qué datos trata «trazabilidad». Sin eso no puedo decir si aplica algo. No es una conclusión de que no aplique. | Posible obligación sin revisar. | Quien en la organización responda por cumplimiento; Andrés Lozano lo plantea. |
| **Cifra del caso de negocio:** `volumen_mensual` 240.425, sin metodología ni fuente más allá del propio caso. No se verificó contra datos medidos. | La escala de la solución descansa en un dato declarado. | Andrés Lozano (autor del caso). |

## Requerimientos aceptados que esta especificación no cubre

Ninguno quedó fuera por decisión mía, pero **ninguno tiene sección de comportamiento**: cubrirlos exigiría la necesidad, que el registro no tiene.

| REQ | Título | Por qué no tiene sección de contenido |
|---|---|---|
| REQ-4400 | Requerimiento REQ-4400 | Sin necesidad, sin criterio, sin doliente. |
| REQ-4401 | Requerimiento REQ-4401 | Sin necesidad; criterio no verificable; sin evidencia. |
| REQ-4402 | Requerimiento REQ-4402 | Sin necesidad ni criterio. |
| REQ-4403 | Requerimiento REQ-4403 | Sin necesidad; criterio no verificable. |
| REQ-4404 | Requerimiento REQ-4404 | Sin necesidad ni criterio. |
| REQ-4406 | Requerimiento REQ-4406 | Sin necesidad; criterio no verificable. |
| REQ-4409 | Requerimiento REQ-4409 | Sin necesidad; criterio no verificable. |
| REQ-4410 | Requerimiento REQ-4410 | Sin necesidad ni criterio. |
| REQ-4412 | Requerimiento REQ-4412 | Sin necesidad; criterio no verificable. |
| REQ-4413 | Requerimiento REQ-4413 | Sin necesidad; criterio no verificable. |
| REQ-4414 | Requerimiento REQ-4414 | Sin necesidad, criterio, doliente, solicitante ni evidencia. |

## Después

No ofrezco `/criterio-product:product-charter`: la especificación no tiene vacíos cerrados ni criterio de éxito del producto.

---
**Pie.** Sale del registro de `estado-producto/PRD-304/requirements/` (16 requerimientos; 11 aceptados cubiertos por referencia, 5 propuestos fuera), actualizado el 2026-10-17; la fuente de estado es el acta del 2026-09-16 (la más reciente) y el anexo del 2026-09-26. Términos v1.1 aceptados por José Francisco Ñáñez el 2026-10-17; nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.13
