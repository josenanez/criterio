# Corrida · 2026-10-17-product-definition-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-definition (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T17:27:38 · **Fin:** 2026-10-17T17:28:25 · **Duración:** 47 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-definition` | 16 | — | 31 | 40 | La evidencia no contradice la definición, pero casi nada la sostiene: una entrevista de hace 12 meses, cifras sin serie y sin criterio de éxito |

Por señal (`product-definition`): `evidence_stale` 14, `requirement_untraced` 11, `requirement_without_acceptance` 5, `requirement_undecided` 5, `requirement_without_owner` 3, `requirement_accepted_without_evidence` 2

## Lo que el agente mostró

La evidencia no contradice la definición de Trazabilidad (PRD-304), pero casi nada la sostiene. La corrida quedó registrada como `2026-10-17-product-definition-1` y tardó 31 segundos. Los términos ya estaban vigentes a nombre de José Francisco Ñáñez (2026-10-17), así que no los registré de nuevo.

- **Contradicciones:** ninguna. No hay serie medida, así que no hay con qué contrastar las cifras (la carpeta `metrics` está vacía).
- **Cifras que nadie mide:**
  - `volumen_mensual` = 240.425: el caso de negocio cita como fuente a sí mismo.
  - `retorno_esperado`: es una frase sin número.
- **Sostenida por evidencia:** el problema («Operadores no tiene trazabilidad») descansa en una sola entrevista del 2025-10-15, de un cliente sin nombre que no dice ser Operador. Tiene 12 meses, justo en el umbral de evidencia vieja. Los 14 requerimientos que citan al «cliente entrevistado» heredan esa misma entrevista.
- **No está dicho en ninguna parte:**
  - el criterio de éxito;
  - quién decide (solo sale del título del acta);
  - la propuesta, que es texto de relleno;
  - el tamaño del problema;
  - cuánto pagaría alguien;
  - qué proyecto lo construye.
- **Supuesto «Operaciones adopta la herramienta»:**
  - El anexo del 2026-09-26 dice «se confirmó», pero cita una medición del piloto que no está en la carpeta.
  - El supuesto está fechado 2026-07-24 dentro de una definición fechada 2025-09-15.
  - Para verificarlo hace falta poner esa medición en la carpeta y fijar qué cuenta como adopción.
- **Normativo:** no tengo la norma a la vista. La definición no menciona datos personales ni pagos y no dice el país. No afirmo ni que cumpla ni que no.
- **Para cerrar la definición:** falta el criterio de éxito, así que no ofrecí `/product-charter`.

La salida completa está en `estado-producto/PRD-304/corridas/salida-product-definition.md`.
