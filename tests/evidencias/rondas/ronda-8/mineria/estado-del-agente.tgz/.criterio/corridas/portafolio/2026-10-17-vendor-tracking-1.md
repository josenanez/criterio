# Corrida · 2026-10-17-vendor-tracking-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:vendor-tracking PRY-203

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-203

**Inicio:** 2026-10-17T17:52:56 · **Fin:** 2026-10-17T17:53:43 · **Duración:** 46 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `vendor-tracking` | 13 | — | 31 | 52 | Cruce CT-235 vs FV-1235: factura de 35.834.032 COP sin acta de recibo ni entregable aceptado; licenciamiento vencido 37 días; informe declara verde. Dije que no sé: vigencia y preaviso del contrato, qué cubre la factura, de quién son los equipos del campamento. |

Por señal (`vendor-tracking`): `milestone_met_without_evidence` 15, `declared_vs_evidence` 7, `commitment_overdue` 6, `variance_time` 4, `progress_vs_plan` 4, `variance_cost` 3, `rebaseline_unauthorized` 3, `commitment_undated` 2, `commitment_rescheduled` 2, `vendor_deliverable_late` 2, `vendor_invoiced_without_delivery` 2, `vendor_accepted_without_evidence` 1, `silent` 1

## Lo que el agente mostró

La corrida de `/vendor-tracking PRY-203` terminó y quedó registrada. El hallazgo principal: hay una factura de 35.834.032 COP sin acta de recibo y sin ningún entregable aceptado.

**Proveedor:** Montajes Industriales Ltda., contrato CT-235.

- **Factura sin acta:** FV-1235 (2026-10-01) está radicada en cuentas por pagar. El contrato dice que cada entregable se factura contra acta de recibo firmada por el gerente del proyecto. Esa acta no está en la carpeta.
- **Licenciamiento vencido:** debía entregarse el 2026-09-10 y sigue pendiente, 37 días tarde, sin evidencia de entrega.
- **Bolsa de horas de ingeniería:** vence el 2026-12-12, también sin evidencia.
- **Estado declarado:** el informe del 2026-10-13 dice verde (36%) y no menciona la factura ni el licenciamiento vencido.
- **Equipos en el campamento:** el informe dice que el proveedor los entregó, pero ninguno de los dos entregables de CT-235 es un equipo. No sé si esos equipos respaldan la factura.
- **Compromisos:** no hay compromisos del proveedor vencidos. Los dos del comité del 2026-10-14 siguen abiertos. El acta no dice si Carlos Peña y Camilo Beltrán son del proveedor, así que no se los atribuí.

**Lo que no sé:**
- Vigencia, renovación y preaviso del contrato: CT-235 no los declara, así que no pude revisar el vencimiento.
- Qué entregable cubre la factura.

Recomendé llevar lo de la factura al comité del 2026-10-21 y pedir el acta de recibo, o frenar el pago hasta que exista.

Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17), así que no los registré de nuevo. Las cifras derivadas salen de `compute`.

Archivos en `/home/claude/banco/ronda-8/mineria/espacio/estado/corridas/`:
- `salida-vendor-tracking.md`
- `2026-10-17-vendor-tracking-1.md`
