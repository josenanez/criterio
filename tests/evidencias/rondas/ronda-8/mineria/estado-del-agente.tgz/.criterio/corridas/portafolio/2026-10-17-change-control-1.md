# Corrida · 2026-10-17-change-control-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:change-control PRY-203 mover la salida a producción 30 días

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-203

**Inicio:** 2026-10-17T17:53:48 · **Fin:** 2026-10-17T17:54:48 · **Duración:** 60 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `change-control` | 13 | — | 45 | 52 | Solicitud de mover 30 días la salida a producción de PRY-203 (cierre 2027-02-17 a 2027-03-19), leída como cierre porque el cronograma no tiene hito de salida. Impacto en portafolio: 0 alcanzados, porque el acta declara cero dependencias; no se afirma que no existan. No sabe: quién pide, motivo, costo del mes, autoridad del gerente (no declarada, va a comité por defecto). Anomalía marcada: factura de 35.834.032 COP del entregable de licenciamiento, vencido y sin acta de recibo en la ficha. |

Por señal (`change-control`): `milestone_met_without_evidence` 15, `declared_vs_evidence` 7, `commitment_overdue` 6, `variance_time` 4, `progress_vs_plan` 4, `variance_cost` 3, `rebaseline_unauthorized` 3, `commitment_undated` 2, `commitment_rescheduled` 2, `vendor_deliverable_late` 2, `vendor_invoiced_without_delivery` 2, `vendor_accepted_without_evidence` 1, `silent` 1

## Lo que el agente mostró

La solicitud de cambio de PRY-203 (Despacho automático de flota) está lista y la corrida quedó registrada. El texto completo está en `estado/corridas/salida-change-control.md`.

**Antes de empezar.** Los términos ya estaban vigentes (v1.1, aceptados el 2026-10-17 por José Francisco Ñáñez), así que no hubo nada que registrar.

**Qué se movería.** El cronograma no tiene un hito de «salida a producción». Lo leí como el cierre, que coincide con «Pruebas en operación»: pasaría del 2027-02-17 al 2027-03-19 (+30 días). Si querías mover otro hito, dímelo.

**Resultado:**
- **Línea base:** la v1 del 2026-05-30 es la única, sin cambios previos.
- **Efecto en el portafolio:** no alcanza a ningún proyecto, porque el acta declara cero dependencias. Eso no prueba que no existan. Conviene preguntar a Jorge Medina si PRY-206 (red LTE) o PRY-207 (gemelo digital) se relacionan con este proyecto.
- **Costo:** no se puede calcular. Falta cuánto cuesta un mes más, y el margen entre lo aprobado y la proyección es de solo 12,2 millones de COP (1,5 %).
- **Quién decide:** la autoridad del gerente no está declarada en el acta; ese es el hallazgo de fondo. Por defecto va al Comité de Tecnología, cuyo próximo comité semanal es el 2026-10-21.
- **Si se aprueba:** nacería la línea base 2 con cierre 2027-03-19, presupuesto por definir y una desviación de +30 días contra la original.
- **Lo que la solicitud no dice:** quién la pide y por qué, ni si respeta la ventana de parada de planta.

**Anomalía aparte.** El 2026-10-01 se facturaron 35.834.032 COP, el monto exacto del entregable de licenciamiento. Ese entregable venció el 2026-09-10 y sigue pendiente, y la ficha no tiene el acta de recibo que exige el contrato. Antes del comité hay que preguntar qué se pagó y contra qué acta.

La corrida quedó como `2026-10-17-change-control-1` (45 segundos, caso PRY-203).
