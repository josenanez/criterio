# Corrida · 2026-10-17-product-view-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:product-view trazabilidad

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T18:01:15 · **Fin:** 2026-10-17T18:02:01 · **Duración:** 45 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-view` | 13 | — | 32 | 52 | Producto con un solo proyecto (PRY-208): sin sección de producto. 0 alertas, pero 0 datos con evidencia y 12 campos con fuente de 13 meses; lo declarado (verde, 90 %) no se pudo contrastar. 7 proyectos sin producto declarado. |

Por señal (`product-view`): `milestone_met_without_evidence` 15, `declared_vs_evidence` 7, `commitment_overdue` 6, `variance_time` 4, `progress_vs_plan` 4, `variance_cost` 3, `rebaseline_unauthorized` 3, `commitment_undated` 2, `commitment_rescheduled` 2, `vendor_deliverable_late` 2, `vendor_invoiced_without_delivery` 2, `vendor_accepted_without_evidence` 1, `silent` 1

## Lo que el agente mostró

## Producto «trazabilidad» al 2026-10-17

Salgo de las fichas del estado, recalculadas hoy con `compute`. Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17), así que no hubo que registrarlos otra vez.

**«Trazabilidad» tiene un solo proyecto: PRY-208, Trazabilidad del mineral.** La vista por producto no aporta nada con un solo proyecto, así que no armé sección de producto. Esto es lo que dice el cálculo de PRY-208:

- **Alertas:** 0. Lleva 5 días en silencio, sin replanificaciones y con 0 días de desviación contra la línea base.
- **Fecha comprometida:** 2026-08-31. Es anterior a la fecha de corte, pero el cálculo no la marca como atraso.
- **Dinero:** las cuatro cifras están presentes, en COP.
  - Aprobado: 9.500.000.000.
  - Comprometido: 7.472.735.712 (78,7 %).
  - Ejecutado: 4.421.982.097 (46,5 %).
  - Proyección: 9.004.783.007 (−5,2 % sobre lo aprobado).
- **Lo declarado:** verde y 90,0 % de avance, según el informe del 2026-10-12.
- **Dependencias:** ninguna registrada, así que no hay nada que llevar al comité de producto.

**Lo que el cero de alertas no prueba:**
- **Sin evidencia:** ningún dato de la ficha está respaldado por evidencia. Hay 2 de declaración y 16 sin marcar, así que el verde y el 90 % son lo que el gerente declara y no pude contrastarlos.
- **Datos viejos:** 12 campos de identidad y plan tienen fuente del 2025-09-27 (13 meses, por encima del umbral de 12).
- **Campos faltantes:** autoridad y fase.
- **Proveedores:** no hay ninguno registrado, así que no hay entregables que contrastar.

**Proyectos sin producto declarado:** 7 de los 13 no traen producto: PRY-201, 202, 205, 206, 209, 210 y 211. Nadie responde por el conjunto al que sirven. No di el área dueña porque `compute` no la entrega. PRY-199 declara «PRD-299», un código y no un nombre como los demás.

La corrida quedó registrada como `2026-10-17-product-view-1`, con el texto completo en `estado/corridas/salida-product-view.md`.

Esto es un borrador de trabajo, no una decisión ni asesoría. Verifica cada dato contra la cita de su ficha. Los documentos se procesan en la infraestructura de la plataforma de IA.
