# Corrida · 2026-10-17-portfolio-wake-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-wake (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T18:03:00 · **Fin:** 2026-10-17T18:03:47 · **Duración:** 47 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-wake` | 13 | — | 33 | 52 | Barrido sin cambios (72 documentos); 23 citas pm_record de PRY-201 marcadas source_missing aunque los archivos existen (ruta sin prefijo de carpeta); 5 preguntas de confirmación sin respuesta; no revisé peticiones del servidor |

Por señal (`portfolio-wake`): `milestone_met_without_evidence` 15, `declared_vs_evidence` 7, `commitment_overdue` 6, `variance_time` 4, `progress_vs_plan` 4, `variance_cost` 3, `rebaseline_unauthorized` 3, `commitment_undated` 2, `commitment_rescheduled` 2, `vendor_deliverable_late` 2, `vendor_invoiced_without_delivery` 2, `vendor_accepted_without_evidence` 1, `silent` 1

## Lo que el agente mostró

Hoy tocaban el barrido diario y la confirmación periódica. Corrieron los dos, y el barrido no encontró nada nuevo. Los términos ya estaban vigentes (v0.3.13), aceptados por José Francisco Ñáñez el 2026-10-17, así que no hubo que pedir ni registrar nada.

- **Barrido:** los 72 documentos están igual que en la corrida anterior. No hay nuevos, cambiados, renombrados ni borrados, así que no recalculé ningún proyecto.
- **Citas de PRY-201:** el índice marca 23 campos de `pm_record` como `source_missing`. Los archivos citados sí existen en la carpeta del proyecto. La causa probable es que esas citas van sin el prefijo de carpeta `PRY-201-ampliación-de-la-relavera/`, y las demás fichas sí lo llevan. No lo corregí, porque la ficha del gerente no la escribe el agente. Queda anotado como pregunta abierta.
- **Confirmación:** formulé cinco preguntas sobre PRY-201: fase, producto, autoridad de cambios, estado declarado (verde, 29 %) y fecha de fin (2027-05-10, frente a 2027-02-03 en la línea base original). Nadie las puede responder en esta sesión, así que quedan sin respuesta y no se repiten hasta la próxima confirmación.
- **Peticiones del servidor:** no las revisé, porque hoy no tocaban.
- **Informe de comité:** llega el 2026-10-19, para el comité del 2026-10-21.

Dejé registrado que se corrieron el barrido y la confirmación. La corrida quedó guardada con el texto completo en `/home/claude/banco/ronda-8/mineria/espacio/estado/corridas/salida-portfolio-wake.md`. El script midió 33 segundos y 13 proyectos. No pudo medir el número de documentos. Contó 52 hallazgos abiertos en total, que son lo que ya había en las fichas, no algo que cruzara un umbral hoy.

Vuelvo el 2026-10-18.
