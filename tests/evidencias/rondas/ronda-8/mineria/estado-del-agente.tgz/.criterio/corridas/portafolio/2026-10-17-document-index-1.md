# Corrida · 2026-10-17-document-index-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:document-index (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T17:48:47 · **Fin:** 2026-10-17T17:49:13 · **Duración:** 26 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `document-index` | 13 | — | 13 | 52 | 72 documentos, ninguno por releer; 23 citas de PRY-201 no resuelven aunque los archivos existen en disco (posible diferencia de ruta o tilde, sin verificar). No se tocó ninguna ficha. |

Por señal (`document-index`): `milestone_met_without_evidence` 15, `declared_vs_evidence` 7, `commitment_overdue` 6, `variance_time` 4, `progress_vs_plan` 4, `variance_cost` 3, `rebaseline_unauthorized` 3, `commitment_undated` 2, `commitment_rescheduled` 2, `vendor_deliverable_late` 2, `vendor_invoiced_without_delivery` 2, `vendor_accepted_without_evidence` 1, `silent` 1

## Lo que el agente mostró

## Carpeta al 2026-10-17

**Documentos:** 72 · **Sin cambio:** 72 · **Hay que releer:** 0

Los términos ya estaban vigentes a nombre de José Francisco Ñáñez, así que no hizo falta registrarlos de nuevo.

- **Cambió el contenido:** ninguno.
- **Solo se reguardó:** ninguno.
- **Renombrado o movido:** ninguno.
- **Ya no está:** ninguno.
- **Formatos que no se pudieron leer:** el índice no reportó ninguno. Este comando cuenta y compara, no lee contenido.

### Citas que dejaron de resolver
El índice marca 23 citas de PRY-201 como fuente no encontrada, sobre tres documentos:

| Documento citado | Campos afectados |
|---|---|
| `00-gobierno/2026-03-06-acta-constitucion.docx` | 10: código, nombre, área, sponsor, gerente, comité, fecha de inicio, alcance, exclusiones y presupuesto aprobado |
| `20-seguimiento/2026-10-09-informe-avance.md` | 6: estado declarado, % de avance, moneda, comprometido, ejecutado y proyección |
| `10-plan/2026-10-09-cronograma-v2.xlsx` | 7: fecha de fin y nombre y estado de los 3 hitos |

Los tres archivos sí existen en la carpeta `PRY-201-ampliación-de-la-relavera/`, y el índice no los marca como borrados ni renombrados. Mi hipótesis es que la cita está escrita sin el nombre de la carpeta del proyecto, o que la tilde de «ampliación» no coincide. No lo verifiqué, y no toqué ninguna ficha.

### Qué sigue
No hay documentos por releer, así que no hace falta `/portfolio-scan`. Lo único abierto son esas 23 citas de PRY-201; corregirlas es decisión de quien mantiene la ficha.

La corrida quedó registrada como `2026-10-17-document-index-1`, con la salida guardada en `estado/corridas/salida-document-index.md`. Tardó 13 segundos.
