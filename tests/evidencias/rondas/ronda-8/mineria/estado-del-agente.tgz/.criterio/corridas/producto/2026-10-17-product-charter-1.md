# Corrida · 2026-10-17-product-charter-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-charter REQ-4400

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** REQ-4400

**Inicio:** 2026-10-17T17:30:31 · **Fin:** 2026-10-17T17:31:21 · **Duración:** 49 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-charter` | 16 | — | 35 | 40 | Borrador de acta para REQ-4400 con 9 vacíos: sin criterios de aceptación, doliente, quién lo aceptó, autoridad ni patrocinador; evidencia de demanda no nombra el requerimiento; supuesto verificado con una medición que no está en la carpeta. Sin firma no se creó la ficha. |

Por señal (`product-charter`): `evidence_stale` 14, `requirement_untraced` 11, `requirement_without_acceptance` 5, `requirement_undecided` 5, `requirement_without_owner` 3, `requirement_accepted_without_evidence` 2

## Lo que el agente mostró

Terminé el borrador del acta de REQ-4400 y la corrida quedó registrada, pero **no creé la ficha del proyecto**: el acta no está firmada.

**Qué se hizo**
- Los términos (v1.1) ya estaban vigentes y aceptados por José Francisco Ñáñez el 2026-10-17, así que no registré nada nuevo.
- REQ-4400 no pasa las condiciones previas. Como no había nadie a quien preguntar, tomé la respuesta sugerida: seguir y marcar cada falta como vacío del acta, sin rellenarla.

**Vacíos principales** (el acta lista nueve)
- **Criterios de aceptación:** no tiene.
- **Doliente:** figura «sin asignar».
- **Quién lo aceptó:** el acta del comité solo dice «Se mantiene el plan».
- **Autoridad, patrocinador y gerente del proyecto:** ningún documento los dice.
- **Evidencia de demanda:** la entrevista tiene una cita sin nombre que no menciona REQ-4400.
- **Supuesto «Operaciones adopta la herramienta»:** figura verificado con una medición del piloto que no está en la carpeta, así que lo llevé como no verificado.
- **Normativa:** no se hizo barrido normativo, porque los documentos no dan de qué anclarlo.
- **Retorno esperado:** el caso de negocio no trae cifra.

Los otros 15 requerimientos quedaron en «No entra» sin razón, porque ningún documento dice por qué. No propuse gerente del proyecto; Andrés Lozano es el gerente de producto.

**Siguiente paso:** el acta debe firmarla quien tenga la autoridad sobre qué se construye; se sugiere el Comité de producto. Después se crea la ficha, y el gerente del proyecto instala `criterio-project` y corre `/pm-setup`.

**Archivos** (en `estado-producto/PRD-304/corridas/`)
- `salida-product-charter.md`
- `2026-10-17-product-charter-1.md`
