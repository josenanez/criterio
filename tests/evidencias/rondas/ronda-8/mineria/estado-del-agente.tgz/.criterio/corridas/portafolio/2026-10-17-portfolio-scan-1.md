# Corrida · 2026-10-17-portfolio-scan-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-scan (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T17:45:22 · **Fin:** 2026-10-17T17:48:43 · **Duración:** 201 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-scan` | 13 | 72 | 186 | 52 | 10 fichas nuevas (PRY-199, 200, 202, 203, 205, 207-211) leídas y selladas; PRY-201, 204 y 206 sin cambio. Nada movido: no existe entrada/. Nada ilegible. Mirar: PRY-200 línea base movida antes de autorizar el cambio; facturas sin acta en PRY-203 y PRY-211; PRY-205, 208 y 209 sin cronograma y con cierre vencido; 22 citas de PRY-201 en pm_record no resuelven. |

Por señal (`portfolio-scan`): `milestone_met_without_evidence` 15, `declared_vs_evidence` 7, `commitment_overdue` 6, `variance_time` 4, `progress_vs_plan` 4, `variance_cost` 3, `rebaseline_unauthorized` 3, `commitment_undated` 2, `commitment_rescheduled` 2, `vendor_deliverable_late` 2, `vendor_invoiced_without_delivery` 2, `vendor_accepted_without_evidence` 1, `silent` 1

## Lo que el agente mostró

Terminé el barrido. Dejé 10 fichas nuevas escritas y selladas, de PRY-199, 200, 202, 203, 205 y 207 a 211.

- **Documentos:** hay 72 en 13 proyectos. Leí 46 y los otros 26 no habían cambiado. Todos se pudieron leer.
- **Sin cambio:** PRY-201, 204 y 206 ya tenían ficha sellada y no los toqué.
- **Términos:** ya estaban vigentes (v1.1), aceptados por José Francisco Ñáñez el 2026-10-17. No registré nada nuevo.
- **Nada que mover:** no existe la carpeta `entrada/`.
- **Campos sin dato:** autoridad y fase faltan en las 10 fichas. El producto falta en 5. PRY-205, 208 y 209 no tienen cronograma.

El script calculó 52 señales en el portafolio, 7 de ellas con el semáforo declarado contradicho por los documentos. Lo más importante de las 10 fichas nuevas:

- **PRY-200:** el cronograma v2 mueve el montaje 104 días antes de que el comité vea la solicitud de cambio CC-01 (pendiente).
- **PRY-203 y PRY-211:** hay facturas radicadas sin acta de recibo de ningún entregable.
- **PRY-210:** el CC-01 dice «autorizada por el comité», pero no dice quién ni cuándo. Lo ejecutado supera lo comprometido.
- **PRY-205, 208 y 209:** el cierre del acta ya pasó (marzo y agosto de 2026) y ningún documento lo reprograma.
- **Compromisos:** 6 de los 7 de las minutas están a nombre de personas que no asistieron a esa reunión.

En PRY-201, 22 citas de la ficha `pm_record` no resuelven porque son relativas a la carpeta del proyecto. Esa ficha es del gerente, así que las dejé sin tocar.

La salida completa quedó en `estado/corridas/salida-portfolio-scan.md`, y la corrida está registrada como `2026-10-17-portfolio-scan-1`. Con 13 fichas ya puedo generar el informe consolidado con `/criterio-portfolio:portfolio-report`. No lo generé.

Versión 0.3.13. Términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.13
