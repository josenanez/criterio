# Corrida · 2026-10-17-project-charter-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-charter PRY-208 revisar

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-208

**Inicio:** 2026-10-17T17:57:55 · **Fin:** 2026-10-17T17:58:38 · **Duración:** 43 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-charter` | 13 | — | 27 | 52 | Revisión del acta de PRY-208 (2025-09-27). Faltan autoridad del gerente, objetivo medible, supuestos, hitos y cadencia; exclusiones y alcance vacíos. Señalé cierre vencido (2026-08-31) con estado verde al 2026-10-12 y avance 90% frente a 46,5% ejecutado. No sé si hay autoridad definida fuera de la carpeta ni si el cierre se movió en otro documento. |

Por señal (`project-charter`): `milestone_met_without_evidence` 15, `declared_vs_evidence` 7, `commitment_overdue` 6, `variance_time` 4, `progress_vs_plan` 4, `variance_cost` 3, `rebaseline_unauthorized` 3, `commitment_undated` 2, `commitment_rescheduled` 2, `vendor_deliverable_late` 2, `vendor_invoiced_without_delivery` 2, `vendor_accepted_without_evidence` 1, `silent` 1

## Lo que el agente mostró

Revisé el acta de PRY-208 (Trazabilidad del mineral). Tiene huecos serios, y el más grave es que no declara la autoridad del gerente.

Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17), así que no los registré de nuevo. La revisión se apoya solo en dos documentos: el acta del 2025-09-27 y el informe de avance del 2026-10-12.

**Qué falta en el acta y qué consecuencia tiene**
- **Autoridad de Laura Vélez:** no está en ningún documento de la carpeta. Sin un umbral de monto y de cambios de alcance, todo cambio sube al comité o se decide sin autoridad escrita. Ya pasó: el informe dice que se reprogramó la parada de planta y no hay registro de quién lo aprobó.
- **Objetivo de negocio:** dice "Entregar trazabilidad del mineral para Tecnología". Es la solución, no un resultado medible.
- **Alcance:** son "Componente 1, 2 y 3", sin describir ninguno.
- **Exclusiones:** dicen "Lo que otro proyecto cubre", sin nombrar el proyecto.
- **Criterio de éxito:** dice "en producción y medido", sin métrica y sin decir quién mide.
- **Supuestos y restricciones:** no hay sección. La parada de planta, definida por operaciones, aparece como riesgo en el informe pero nunca como supuesto.
- **Dependencias:** el acta dice "Ninguna declarada", y la parada de planta depende de operaciones.
- **Hitos y cadencia de reporte al comité:** tampoco están.
- **Lo que sí cumple:** el patrocinador (Sandra Gil) tiene nombre.

**Lo que salió del informe al revisar el acta**
- El cierre comprometido era el 2026-08-31. El informe del 2026-10-12 reporta 90 % y estado verde, 42 días después, sin ningún cambio aprobado en la carpeta.
- Se ha ejecutado 46,5 % del presupuesto y comprometido 78,7 %. Un avance de 90 % no cuadra con eso salvo que lo que falta sea barato, y el informe no lo explica.
- Los dos riesgos abiertos no tienen responsable.

**Lo que no sé:** si hay una autoridad definida fuera de la carpeta, si el cierre se movió en otro documento, y qué proyecto cubre lo excluido.

**Siguientes pasos que propongo**
- Llevar la definición de autoridad al Comité de Seguridad del 2026-10-21.
- Pasar los supuestos y la dependencia con operaciones al registro RAID con `/raid-log`.
- Abrir un control de cambios por el cierre vencido con `/change-control`.

La corrida quedó registrada como `2026-10-17-project-charter-1`. El texto completo de la revisión está en `/home/claude/banco/ronda-8/mineria/espacio/estado/corridas/salida-project-charter.md`.
