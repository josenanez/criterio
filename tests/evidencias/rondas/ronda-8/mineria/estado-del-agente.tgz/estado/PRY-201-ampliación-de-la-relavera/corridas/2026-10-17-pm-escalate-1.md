# Corrida del 2026-10-17 · pm-escalate

1 proyectos · 66 s · 14 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_overdue` | 6 |
| `commitment_undated` | 2 |
| `commitment_rescheduled` | 2 |
| `variance_time` | 1 |
| `milestone_met_without_evidence` | 1 |
| `vendor_accepted_without_evidence` | 1 |
| `declared_vs_evidence` | 1 |

Paquete de 3 puntos: autoridad no declarada en el acta, CC-01 (+96 días, +192M COP) con opciones, y dos compromisos reprogramados más de 3 veces. No sé: fecha en que la falta de decisión cuesta, alcance real de CC-01, si la proyección incluye el CC, otros proyectos dependientes (el estado solo tiene PRY-201). impact aplicó 96 días sobre un cierre que ya los incluye; no se usó la cifra 2027-08-14.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

*Términos vigentes (v1.1), aceptados por José Francisco Ñáñez el 2026-10-17. Sesión sin interfaz: nadie respondió preguntas; no se pasó tema, así que se tomó lo ya marcado como escalable (informe de la semana).*

## Para decisión — PRY-201 Ampliación de la relavera · 2026-10-17

Tres puntos, en este orden. El primero va primero porque sin él los otros dos pueden llegar a quien no los puede decidir.

---

### 1. ¿Qué cambios sobre la línea base decide el gerente solo y cuáles exigen al comité?

**El acta del 2026-03-06 no declara la autoridad del gerente.** Dice quién es el patrocinador (María Restrepo), el gerente (Mauricio Pérez) y el comité (Comité de Operaciones), y que ese comité aprobó el presupuesto. No dice qué puede decidir el gerente ni quién aprueba un cambio de alcance, tiempo o costo. Todo lo que sigue en este paquete supone que decide el Comité de Operaciones; es una inferencia mía, no un dato del acta.

**Quién decide:** el patrocinador, María Restrepo, o el comité, con la respuesta escrita en el acta · **Si no se decide hoy:** no hay fecha en los documentos. Mientras no se declare, cada cambio (empezando por CC-01) queda sin dueño verificable de su aprobación.

**Pregunta cerrada:** *¿Confirma el Comité de Operaciones que aprueba los cambios sobre la línea base de PRY-201, y que el gerente decide solo hasta [umbral en días y en COP que fije el comité]?* Sí / No / Sí con otro umbral.

---

### 2. ¿Se aprueba CC-01 (+96 días y +192.000.000 COP) con la ampliación de alcance que pide?

**Quién decide:** Comité de Operaciones, por inferencia (ver punto 1) · **Si no se decide hoy:** no hay fecha de vencimiento en los documentos y no la invento. Lo que sí hay: **el cronograma v2 (2026-10-09) ya trae el cierre al 2027-05-10, antes de cualquier aprobación**, y la solicitud dice «Pendiente de presentación al comité»; no estuvo en el comité del 2026-10-10. Cada semana sin decidir se opera sobre una fecha que nadie aprobó. *Mauricio Pérez debe poner aquí la fecha real en que la falta de decisión cuesta algo (oferta del proveedor, hito, contrato). Sin ella el punto se aplaza.*

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| **A. Aprobar CC-01** | Ampliación; el CC no dice cuáles componentes, solo «Ampliación de alcance» | Cierre 2027-02-03 → **2027-05-10** (+96 días, +29,6 % sobre la original; umbral 10 %). Pasa a ser la línea base 2; la 1 no se toca | +192.000.000 COP: aprobado 4.200.000.000 → 4.392.000.000. La proyección del informe (4.269.105.906) puede incluir o no el CC; si no lo incluye, el total sería 4.461.105.906, **69.105.906 por encima** de lo ya ampliado. No consta cuál de las dos |
| **B. Rechazar CC-01** | Se mantiene Componentes 1, 2 y 3 | Vuelve a 2027-02-03 y hay que deshacer el cronograma v2 (hito «Licencia y permisos» 2027-05-10 → 2027-02-03). No sé si eso es alcanzable: el expediente no lo dice | Sin los 192.000.000. Proyección 4.269.105.906 (+1,6 % sobre lo aprobado; disponible real 672.855.634) |
| **C. Devolver CC-01 incompleto, con plazo** | Se pide el detalle de qué agrega | Sigue vigente 2027-05-10 sin aprobar hasta la nueva presentación | Sin costo directo; el costo es operar sobre una fecha no aprobada |

**Recomiendo:** **A condicionada** — aprobar si Mauricio trae al comité el detalle de los componentes que agrega y dice si la proyección ya incluye los 192.000.000; si llega sin eso, **C con fecha**. No recomiendo B por falta de datos: no sé qué costaría deshacer v2. Es criterio mío sobre lo que dice el expediente; el comité decide.

**Faltas de la solicitud en sí:** no describe el alcance nuevo, no trae motivo ni desglose del costo, y está firmada solo por el solicitante (Mauricio Pérez). Ese es el vacío que más pesa en la decisión.

---

### 3. Dos compromisos reprogramados más de tres veces: ¿se mantiene la fecha o se reasigna?

| Compromiso | Responsable | Original → hoy | Veces |
|---|---|---|---|
| Enviar el documento 1 | Paula Céspedes | 2026-09-14 → 2026-11-26 | 6 |
| Cerrar la prueba 2 | María Restrepo (patrocinadora) | 2026-09-12 → 2026-11-28 | 5 |

**Quién decide:** el comité sobre Paula Céspedes; sobre la prueba 2 el responsable es la patrocinadora, así que quien la destraba está en la sala y no por encima de ella. · **Si no se decide hoy:** no hay consecuencia con fecha en los documentos; el compromiso sigue moviéndose. Qué depende de cada uno tampoco consta.

**Pregunta cerrada:** *¿Se acepta 2026-11-26 y 2026-11-28 como fechas firmes (una más que se mueva sube a decisión de reasignar), o se reasigna ahora?* Firmes / Reasignar.
**Recomiendo:** firmes con la regla de la próxima reprogramación, porque ninguna de las dos tiene evidencia de que la causa sea la persona y no lo que le falta.

---

### A quién alcanza
| Proyecto | Gerente | ¿Sostiene su fecha? | Dependencia confirmada |
|---|---|---|---|
| Ninguno en el estado | — | — | — |

El cálculo (`impact`, 96 días) no encuentra otros proyectos alcanzados, pero **el estado solo contiene PRY-201**, así que no puedo decir que no haya ninguno. El acta declara «Dependencias: Ninguna declarada» y como fuera de alcance «lo que otro proyecto cubre» sin nombrarlo. **Quien conozca el portafolio debe confirmar si otro proyecto depende de la relavera.** Y el cálculo no dice cuántos días se mueve cada alcanzado: necesita holgura por actividad, que la ficha no tiene.

### Mis hitos por los que pasa
| Hito | Fecha vigente | En cuántos días |
|---|---|---|
| Ingeniería de detalle aprobada | 2026-10-18 | 1 |
| Licencia y permisos obtenidos | 2027-05-10 (base 2027-02-03) | 205 |

Advertencia sobre la cifra: la herramienta aplica los 96 días sobre la fecha de cierre de la ficha, que **ya es la del cronograma v2 (2027-05-10)**, y devuelve 2027-08-14. Eso cuenta el cambio dos veces y no lo uso. Lo correcto es 2027-02-03 + 96 días = 2027-05-10. «Ingeniería de detalle» no la mueve CC-01: sale porque vence mañana y no tiene evidencia de cumplimiento.

### De dónde sale esto
- Autoridad no declarada; comité, patrocinador, presupuesto aprobado, fechas y «Dependencias: Ninguna declarada»: `00-gobierno/2026-03-06-acta-constitucion.docx`.
- CC-01 (+96 días, +192.000.000 COP, «Pendiente de presentación al comité»): `20-seguimiento/2026-10-05-solicitud-cambio-cc-01.md`.
- Cierre 2027-05-10 ya en vigor, base 2027-02-03: `10-plan/2026-10-09-cronograma-v2.xlsx` y `10-plan/2026-03-06-cronograma-v1.xlsx`.
- Comprometido, ejecutado, proyección, estado verde: `20-seguimiento/2026-10-09-informe-avance.md`. Disponible real (aprobado menos comprometido) 4.200.000.000 − 3.527.144.366 = 672.855.634.
- Reprogramaciones: `30-reuniones/2026-09-05` a `2026-10-10-comite-semanal.md` y `2026-10-17-notas-reunion.txt`.
- Próxima reunión: la configuración dice 2026-10-24 y las notas de hoy dicen «en dos semanas» (2026-10-31); no coinciden. Hay que confirmar a qué comité se lleva esto.

### Lo que no sé
La fecha en que la falta de decisión cuesta algo; qué componentes agrega CC-01; si la proyección incluye los 192.000.000; si otro proyecto depende de este; cuánto cuesta deshacer el cronograma v2. Este comando no escala solo ni decide: el paquete es de Mauricio Pérez para llevarlo.
