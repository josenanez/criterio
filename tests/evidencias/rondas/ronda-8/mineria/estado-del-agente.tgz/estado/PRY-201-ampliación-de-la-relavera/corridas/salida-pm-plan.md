# Plan — PRY-201 Ampliación de la relavera · borrador del 2026-10-17
**Desde:** el acta de constitución del 2026-03-06 (`00-gobierno/2026-03-06-acta-constitucion.docx`) · **Criterio de éxito:** «Ampliación de la relavera en producción y medido.» (acta)

Términos: ya estaban vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17). No hubo que registrarlos de nuevo.

Dos cosas antes de leer: (1) el proyecto ya está en ejecución —inicio 2026-03-16, ingeniería básica cerrada— y ya existen un cronograma v1 y uno v2, así que esto no es el «primer» plan sino el plan reconstruido desde el acta, para ver qué sostiene el acta y qué no; (2) no hay ninguna fecha comprometida en este borrador. Las dos fechas del acta (inicio 2026-03-16, cierre 2027-02-03) son suyas y se citan, no se tocan.

## Lo que le falta al acta
| Qué | Consecuencia de planificar sin eso |
|---|---|
| **El alcance es un marcador:** «Componente 1 / Componente 2 / Componente 3» | No hay entregables que descomponer. Cualquier WBS por debajo del nivel de los tres componentes sería inventada. |
| **La exclusión es vacía:** «Lo que otro proyecto cubre» (sin decir cuál proyecto ni qué) | No se puede decidir si algo cae dentro o fuera; el primer cambio de alcance se discute sin referencia. |
| **Sin autoridad declarada** | No se sabe qué puede decidir el gerente al planificar y qué debe subir. |
| **Criterio de éxito sin medida:** «en producción y medido» — qué se mide, con qué indicador y umbral, no está | «Medido» no se puede aceptar ni rechazar; el cierre queda a discreción de quien lo mire. |
| **Dependencias: «Ninguna declarada»** | El orden de abajo es mío (supuesto), no del acta. Una relavera con licencias y permisos probablemente depende de algo externo; el acta no lo dice. |
| **Sin quién acepta cada entregable** | Hay patrocinadora (María Restrepo) pero el acta no dice que ella acepte entregables. Los nodos quedan sin aceptante. |

Sí está: patrocinadora (María Restrepo), gerente (Mauricio Pérez), comité (Comité de Operaciones), presupuesto aprobado (4.200.000.000 COP, 2026-03-06). Producto asociado: «No aplica».

## WBS
| # | Entregable | Quién lo acepta | De dónde sale | Duración |
|---|---|---|---|---|
| 1 | Ingeniería básica aprobada | sin definir | supuesto — figura en el cronograma v1/v2 (hito cerrado, 2026-07-02), no en el acta | — (hecho; inicio 2026-03-16 del acta → 2026-07-02 del cronograma) |
| 2 | Ingeniería de detalle aprobada | sin definir | supuesto — cronograma v1/v2 (2026-10-18, en curso), no en el acta | vacía |
| 3 | Licencia y permisos obtenidos | sin definir | supuesto — cronograma v1/v2 (v1: 2027-02-03; v2: 2027-05-10), no en el acta | vacía |
| 4 | Componente 1 | sin definir | del acta, **solo el nombre**; qué es, sin definir | vacía |
| 5 | Componente 2 | sin definir | del acta, solo el nombre | vacía |
| 6 | Componente 3 | sin definir | del acta, solo el nombre | vacía |
| 7 | Ampliación en producción | sin definir | del acta (criterio de éxito), sin descomponer | vacía |
| 8 | Medición de la ampliación en producción | sin definir | del acta («y medido»), sin indicador | vacía |

Los nodos 4–8 no son terminales aceptables todavía: ninguno dice qué recibe alguien. Los nodos 1–3 son aceptables si se confirma quién firma. No agregué nodos de construcción, pruebas o puesta en marcha: nadie los ha dicho.

## Orden
Sin fechas. Las dependencias no están declaradas en el acta; lo siguiente es supuesto salvo donde se indica:
- 1 → 2: del orden de los hitos del cronograma (la detalle sigue a la básica).
- 2 → 3: supuesto — que los permisos se tramitan sobre la ingeniería de detalle. No está en ningún documento leído.
- 3 → 7: supuesto — que no se entra en producción sin licencia y permisos.
- 7 → 8: del criterio de éxito (primero producción, luego medido).
- 4, 5, 6: sin orden definible; no se sabe qué son ni de qué dependen.

## Supuestos sobre los que está construido
| Supuesto | Qué pasa si resulta falso |
|---|---|
| Los tres hitos del cronograma (ingeniería básica, detalle, licencia y permisos) son entregables del proyecto aceptables por alguien | La WBS pierde sus únicos nodos concretos. |
| 2 → 3 y 3 → 7 (orden de arriba) | Si los permisos van en paralelo o hay obras previas, la ruta y cualquier fecha cambian. |
| «Componentes 1–3» son entregables y no fases ni áreas | Si son fases, la descomposición por entregable queda por rehacer. |
| «En producción y medido» se refiere a una medición posterior a la puesta en marcha | Si la medición es una condición previa (p. ej. de diseño), el nodo 8 va antes. |

Estos pasan a riesgos del proyecto en cuanto el plan se apruebe.

## Sin definir
| Qué | Quién lo define |
|---|---|
| Qué son los Componentes 1, 2 y 3 | Patrocinadora (María Restrepo) — el acta es de ella |
| Qué excluye «lo que otro proyecto cubre» y de qué proyecto se habla | Patrocinadora / Comité de Operaciones |
| Qué se mide, con qué indicador, umbral y por quién, para «medido» | Patrocinadora |
| Quién acepta cada entregable | Patrocinadora / Comité de Operaciones |
| Autoridad del gerente al planificar | Comité de Operaciones |
| Dependencias externas (permisos, proveedor, otros proyectos) | Gerente, con el equipo |
| Entregables entre ingeniería de detalle y «en producción» (obra, pruebas, puesta en marcha) | Gerente, con ingeniería |
| Proveedor y contrato (la ficha tampoco los tiene) | Gerente |

## Proyectos análogos
Ninguno a la vista. La configuración de este proyecto no apunta a una carpeta de fichas de la PMO, así que no busqué análogos. Es la respuesta correcta y evita una falsa precisión: no hay referencia de duración ni de desviación para traer.

Lo que sí está en la propia carpeta del proyecto, como hecho y no como estimación: el hito «Licencia y permisos obtenidos» pasó de 2027-02-03 (cronograma v1) a 2027-05-10 (cronograma v2), +96 días; y existe la solicitud de cambio CC-01 (2026-10-05, +96 días, +192.000.000 COP, decisión pendiente). El cronograma v2 ya trae la fecha 2027-05-10 sin que CC-01 tenga decisión registrada, y esa fecha queda 96 días después del cierre del acta (2027-02-03).

## Preguntas para el equipo
1. Ingeniería de detalle (nodo 2): ¿cuánto falta para la aprobación, si el hito vigente es el 2026-10-18 y hoy es 2026-10-17?
2. Licencia y permisos (nodo 3): ¿cuánto toma el trámite y quién lo controla — la autoridad ambiental, un tercero, el proyecto?
3. Componente 1 (nodo 4): ¿qué es y cuánto toma?
4. Componente 2 (nodo 5): ¿qué es y cuánto toma?
5. Componente 3 (nodo 6): ¿qué es y cuánto toma?
6. Puesta en producción (nodo 7): ¿qué se hace entre la ingeniería de detalle y producción, y cuánto toma cada parte?
7. Medición (nodo 8): ¿qué se mide, durante cuánto tiempo hace falta medir antes de poder decir «medido»?
8. ¿Quién acepta cada uno de los ocho nodos?

## Para comprometer una fecha falta
- **La disponibilidad real del equipo.** No está en ningún documento leído.
- **La fecha del proveedor.** La ficha no tiene proveedor ni contrato; el informe del 2026-10-09 y las notas del 2026-10-17 dicen que el proveedor no ha confirmado la fecha de la última entrega y que podría no llegar con el equipo completo.
- **La ventana de la sala de producción / de la operación** donde la ampliación entra a producción.
- **La decisión de CC-01**, que cambia la línea base si se aprueba.
- **Las respuestas de «Sin definir»**, empezando por qué son los tres componentes.

Cuando el plan se apruebe, queda ofrecido registrarlo como línea base original y pasar los supuestos al RAID con doliente. Hoy no hay plan aprobado: no creo línea base.
