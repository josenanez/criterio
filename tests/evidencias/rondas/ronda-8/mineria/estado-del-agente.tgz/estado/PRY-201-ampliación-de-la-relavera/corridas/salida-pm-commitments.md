## Compromisos — Ampliación de la relavera (PRY-201) · al 2026-10-17

Términos: ya vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17); no hubo que registrar nada nuevo.

### Se viene reprogramando

> **Paula Céspedes** · Enviar el documento 1
> Prometido para el 2026-11-26, y antes para el 11-12, el 11-01, el 10-21, el 10-12 y el 09-22. El original era el 2026-09-14.
> **Seis reprogramaciones no son un problema de seguimiento: son un bloqueo que nadie ha nombrado.**
> Fuentes: comités del 09-05, 09-12, 09-19, 09-26, 10-03, 10-10 y notas del 10-17.

> **María Restrepo** · Cerrar la prueba 2
> Prometido para el 2026-11-28, y antes para el 11-14, el 10-25, el 10-10 y el 09-25. El original era el 2026-09-12.
> **Cinco reprogramaciones, el mismo caso.** Quien promete es además la patrocinadora del proyecto (acta de constitución).

Ninguna otra llega a tres reprogramaciones (umbral de la configuración: 3).

### Vencidos sin evidencia
| Quién | Qué | Prometido para | Hace |
|---|---|---|---|
| Mauricio Pérez | Actualizar la matriz 6 | 2026-09-15 | 32 días |
| Óscar Ramírez | Entregar el punto 8 | 2026-10-02 | 15 días |
| Gustavo Neira | Validar el ambiente 20 | 2026-10-08 | 9 días |
| Óscar Ramírez | Revisar el anexo 19 | 2026-10-11 | 6 días |
| Jorge Medina | Entregar el punto 24 | 2026-10-13 | 4 días |
| Andrés Lozano | Aprobar el diseño 5 | 2026-10-15 | 2 días (ya reprogramado dos veces: 10-01 y 10-15) |

Ninguno tiene acta de recibo ni entregable en el expediente. La matriz 6 se prometió el 09-15 en el comité del 09-12, y las minutas del 09-19, 09-26, 10-03 y 10-10 la repiten con esa misma fecha vencida, sin reprogramarla.

### Vencen hoy y esta semana (hasta el comité del 2026-10-24)
| Quién | Qué | Para cuándo |
|---|---|---|
| Felipe Arango | Cerrar la prueba 10 | 2026-10-17 (hoy; ya reprogramada una vez, original 10-06) |
| Sandra Gil | Confirmar la fecha 15 | 2026-10-17 (hoy; ya reprogramada una vez, original 10-07) |
| Felipe Arango | Entregar el punto 16 | 2026-10-19 (ya reprogramado una vez, original 10-12) |
| Gustavo Neira | Aprobar el diseño 21 | 2026-10-19 |
| Laura Vélez | Aprobar el diseño 13 | 2026-10-21 (ya reprogramado una vez, original 09-30) |
| Felipe Arango | Validar el ambiente 12 | 2026-10-22 (ya reprogramado una vez, original 10-12) |

Felipe Arango tiene tres compromisos abiertos que ya se movieron una vez cada uno (prueba 10, punto 16, ambiente 12) y todos caen esta semana.

### Sin fecha
| Quién | Qué | Dicho el |
|---|---|---|
| María Restrepo | Revisar el anexo 11 | 2026-09-19 («por definir»; sigue sin fecha en la minuta del 09-26) |
| Laura Vélez | Mandar el ajuste del presupuesto | 2026-10-17 («la otra semana» no es una fecha; no se le calculó una) |

No pueden estar vencidos; por eso se cuentan aparte. En el comité del 10-03 María Restrepo dijo que ya había entregado el anexo 11 y no se presentó acta: **sigue abierto, sin documento que lo respalde.**

### Cerrados desde la última revisión
Los cierres son contra acta de recibo, todas del 2026-10-03:
- Felipe Arango · Revisar el anexo 3 → `20-seguimiento/2026-10-03-acta-recibo-3.md`
- Felipe Arango · Validar el ambiente 4 (reprogramado dos veces) → `20-seguimiento/2026-10-03-acta-recibo-4.md`
- Mauricio Pérez · Confirmar la fecha 7 → `20-seguimiento/2026-10-03-acta-recibo-7.md`
- Sandra Gil · Actualizar la matriz 14 → `20-seguimiento/2026-10-03-acta-recibo-14.md`

## Lo que el cálculo dice del informe del 2026-10-09
El informe declara **verde**. El cálculo lo contradice con cuatro señales: compromisos vencidos, compromisos reprogramados, un hito marcado cumplido sin evidencia (Ingeniería básica aprobada, 107 días) y 96 días de atraso contra la línea base original (29,6 %).

## Corrección que hice en la ficha
«Entregar el punto 8» (Óscar Ramírez) y «Cerrar la prueba 18» (Javier Hoyos) estaban con `original_due_date: no_declarada`. Se prometieron «por definir» y la fecha llegó después (09-19 y 10-10), así que esa es su primera fecha y no una reprogramación. Quedaron con original 2026-10-02 y 2026-10-25. Recalculado sin `record_issues`.

## Después
- **Ofrezco formular como decisión para el comité** el documento 1 (Paula Céspedes, 6 reprogramaciones) y la prueba 2 (María Restrepo, 5). Qué se pide, qué pasa si no se decide y quién tiene la facultad exceden la autoridad del gerente. Con `/pm-escalate` queda armada si la quieres.
- `/pm-publish` no hace falta: esta corrida no cambió ningún campo que la PMO lea, solo dos fechas originales internas de compromisos.
- Este comando no le escribe a nadie; perseguir cada compromiso es del gerente.
