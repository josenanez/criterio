## Ampliación de la relavera (PRY-201) · 2026-10-17

Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17); no hubo que registrar nada nuevo.

**Revisé:** 17 documentos · 17 nuevos para el índice (primer barrido, `last: null`) · 1 minuta nueva (`2026-10-17-notas-reunion.txt`), que ya estaba extraída en la ficha por `/pm-minutes` hoy; no la volví a extraer ni dejé copias en el estado.

### Lo que se venció solo
Corte 2026-10-17, 14 señales (`compute`). El informe del 2026-10-09 declara **verde**; cuatro señales no lo acompañan.
- **Vencidos sin evidencia (6):** Mauricio Pérez, matriz 6, hace 32 días · Óscar Ramírez, punto 8, hace 15 · Gustavo Neira, ambiente 20, hace 9 · Óscar Ramírez, anexo 19, hace 6 · Jorge Medina, punto 24, hace 4 · Andrés Lozano, diseño 5, hace 2 (`30-reuniones/…`).
- **Sin fecha (2):** María Restrepo, anexo 11; Laura Vélez, ajuste del presupuesto («la otra semana», `2026-10-17-notas-reunion.txt`).
- **Reprogramados al umbral (2):** Paula Céspedes, documento 1, 6 veces (original 2026-09-14, hoy 2026-11-26); María Restrepo, prueba 2, 5 veces (original 2026-09-12, hoy 2026-11-28).
- **Hito dado por cumplido sin evidencia:** Ingeniería básica aprobada (2026-07-02).
- **Atraso:** 96 días (29,6 %) contra la línea base original.
- **Vence hoy:** Felipe Arango, prueba 10, y Sandra Gil, fecha 15; sin acta de recibo todavía.
- **Riesgo dicho y no registrado** (proveedor sin equipo completo): quedó en la ficha sin responsable.

### La reunión
Comité semanal, próximo 2026-10-24 (en 7 días). Todavía no toca agenda, ni informe: el informe sale el 2026-10-23. Pendiente de confirmar: las notas de hoy dicen «próxima reunión en dos semanas» (2026-10-31), y la configuración dice semanal; no la cambié.

### Tu ficha publicada
Al día: se publicó hoy a las 17:41 y la ficha no cambió desde entonces.

**Vuelvo el 2026-10-18.**
