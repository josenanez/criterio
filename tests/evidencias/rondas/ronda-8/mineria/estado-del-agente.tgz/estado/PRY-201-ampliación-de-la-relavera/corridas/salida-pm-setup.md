## Listo — PRY-201 · Ampliación de la relavera

Soy Samuel. Proceso lo que pasa en tu proyecto y llevo la cuenta de lo que se prometió en cada reunión.

Preguntas de la configuración, sin quien las respondiera (sesión de prueba), con la respuesta sugerida:
1. Quién eres y qué proyecto es: Mauricio Pérez, gerente de PRY-201 Ampliación de la relavera (del acta de constitución).
2. Reunión de seguimiento: los sábados, semanal (los nombres de las minutas caen en sábado). Próxima propuesta: 2026-10-24. Las notas del 17-oct dicen «próxima reunión en dos semanas» (2026-10-31): la cadencia semanal queda como propuesta y se corrige si cambió.
3. Dónde guardo lo que encuentro: `estado/PRY-201-ampliación-de-la-relavera`.
4. Términos: José Francisco Ñáñez los acepta, indicado en el argumento de la prueba.

**Lo que miré:** 16 documentos · 6 minutas (comités del 2026-09-05 al 2026-10-10, las leídas de la más vieja a la más nueva) más las notas de reunión del 2026-10-17 · la última del 2026-10-17. Leí 26 compromisos en total. Todos los formatos se pudieron leer. Las dos hojas del cronograma se leyeron sin errores.
**Términos:** aceptados para la versión 0.3.13 (términos 1.1) por José Francisco Ñáñez · comprobante en `.criterio/terminos/aceptacion-criterio-project-0.3.13-2026-10-17.md` y `.pdf` · SHA-256 b8d0cca7fea66fcb… (el .md) · 28e9cfed31cb47fb… (el .pdf)

Resumen de los términos, tal cual: «Criterio produce borradores de trabajo, no decisiones ni asesoría. Procesa los documentos que usted le indique y dice lo que muestran; no sabe lo que se habló fuera de ellos. Puede equivocarse, y por eso cada dato viene con la cita del documento de donde salió: la verificación es suya. Sus documentos se procesan en la infraestructura de la plataforma de IA, no solo en su equipo. Cada versión se certifica antes de publicarse; garantía y responsabilidad: licencia Apache 2.0. Cada versión se acepta de nuevo y deja un comprobante en Markdown y PDF con su huella SHA-256.» Nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal

### Lo que está abierto, y cuántas veces se ha movido
De los 26 compromisos, 4 están cerrados con acta de recibo (anexo 3, ambiente 4, fecha 7, matriz 14) y 22 siguen abiertos.

| Quién | Qué | Para cuándo | Veces movido |
|---|---|---|---|
| Paula Céspedes | Enviar el documento 1 | 2026-11-26 (era 2026-09-14) | 6 · 09-22, 10-12, 10-21, 11-01, 11-12, 11-26 · notas 2026-10-17 |
| María Restrepo | Cerrar la prueba 2 | 2026-11-28 (era 2026-09-12) | 5 · 09-25, 10-10, 10-25, 11-14, 11-28 · comité 2026-10-10 |
| Andrés Lozano | Aprobar el diseño 5 | 2026-10-15 — **vencido hace 2 días, sin acta** (era 2026-09-22) | 2 · comité 2026-10-10 |
| Mauricio Pérez | Actualizar la matriz 6 | 2026-09-15 — **vencido hace 32 días, sin acta** | 0 · dicho el 2026-09-12 y repetido sin cambio hasta el 2026-10-10 |
| Óscar Ramírez | Entregar el punto 8 | 2026-10-02 — **vencido hace 15 días, sin acta** | 0 · comité 2026-10-10 |
| Gustavo Neira | Validar el ambiente 20 | 2026-10-08 — **vencido hace 9 días, sin acta** | 0 · comité 2026-10-10 |
| Óscar Ramírez | Revisar el anexo 19 | 2026-10-11 — **vencido hace 6 días, sin acta** | 0 · comité 2026-10-10 |
| Jorge Medina | Entregar el punto 24 | 2026-10-13 — **vencido hace 4 días, sin acta** | 0 · comité 2026-10-10 |
| Liliana Torres | Enviar el documento 9 | 2026-11-16 (era 2026-10-11) | 2 · comité 2026-10-10 |
| Laura Vélez | Aprobar el diseño 13 | 2026-10-21 (era 2026-09-30) | 1 · comité 2026-10-10 |
| Felipe Arango | Validar el ambiente 12 | 2026-10-22 (era 2026-10-12) | 1 · comité 2026-10-03 |
| Felipe Arango | Cerrar la prueba 10 | 2026-10-17, hoy (era 2026-10-06) | 1 · comité 2026-10-10 |
| Sandra Gil | Confirmar la fecha 15 | 2026-10-17, hoy (era 2026-10-07) | 1 · comité 2026-10-03 |
| Felipe Arango | Entregar el punto 16 | 2026-10-19 (era 2026-10-12) | 1 · comité 2026-10-03 |
| Andrés Lozano | Enviar el documento 17 | 2026-10-30 (era 2026-10-17) | 1 · comité 2026-10-10 |
| Gustavo Neira | Aprobar el diseño 21 | 2026-10-19 | 0 · comité 2026-10-10 |
| Javier Hoyos | Cerrar la prueba 18 | 2026-10-25 (no tenía fecha al principio) | 0 · comité 2026-10-10 |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-27 | 0 · notas 2026-10-17 |
| Mauricio Pérez | Actualizar la matriz 22 | 2026-11-05 | 0 · comité 2026-10-10 |
| Andrés Lozano | Confirmar la fecha 23 | 2026-11-04 | 0 · comité 2026-10-10 |

Dos de esos compromisos se movieron cinco veces o más (documento 1 y prueba 2): es lo que más pesa en la lista. La señal «declarado verde contra la evidencia» la levantó el cálculo: el informe del 2026-10-09 declara verde y las señales de vencidos, reprogramados, hito sin acta y desviación de tiempo no están reflejadas en él. Esa conversación es tuya.

### Sin fecha
- María Restrepo — Revisar el anexo 11 (comité 2026-09-19, «por definir»). En el comité del 2026-10-03 dijo que ya lo entregó; **no se presentó acta**, así que sigue abierto. Desapareció de la lista desde esa reunión, sin cerrarse.
- Laura Vélez — Mandar el ajuste del presupuesto (notas 2026-10-17: «la otra semana»; no es una fecha).

### Otras señales que levantó el cálculo
- Fecha de cierre vigente 2027-05-10 (cronograma v2) contra 2027-02-03 del acta: 96 días, 29,6 %. La solicitud de cambio CC-01 (+96 días, 192.000.000 COP) sigue **pendiente de presentarse al comité**; el cronograma v2 ya trae la fecha nueva, y el informe del 2026-10-09 no la menciona.
- Hito «Ingeniería básica aprobada» (2026-07-02) figura cerrado en el cronograma, sin acta que lo pruebe (107 días).
- Entregable «Equipos en el campamento» del proveedor: declarado entregado, pendiente de aceptación, sin acta. El script lo marca sin evidencia de aceptación.
- Presupuesto: aprobado 4.200.000.000 COP; comprometido 3.527.144.366 (84,0 %); ejecutado 1.393.552.576 (33,2 %); proyección 4.269.105.906 (1,6 % sobre lo aprobado). Esa proyección no incluye los 192.000.000 de CC-01 (no lo dice el informe; lo noto sin calcular el total).
- Riesgo dicho en la reunión del 2026-10-17 y no registrado: el proveedor podría no llegar con el equipo completo para la siguiente fase. Quedó en la ficha con esa cita.

### Qué le falta a tu carpeta
- Actas de recibo del hito «Ingeniería básica aprobada» y de los equipos del proveedor: sin ellas lo cumplido se ve igual que lo incumplido.
- La autoridad del gerente (hasta qué monto y qué cambio decide sin comité), la fase y el nombre del proveedor no aparecen en ningún documento.
- El acta de constitución no declara dependencias («Ninguna declarada»), y las notas del 2026-10-17 son un `.txt` suelto en la raíz del proyecto, fuera de `30-reuniones/`.
- Una minuta formal del 2026-10-17; las notas no traen compromisos de los demás asistentes, así que lo que sigue abierto se toma del comité del 2026-10-10.
- Anexo: la ficha quedó sin sellar (leí las minutas y no el proyecto entero).

**Cuándo vuelvo:** el sábado 2026-10-24 (reunión semanal; si es en dos semanas, el 2026-10-31).
