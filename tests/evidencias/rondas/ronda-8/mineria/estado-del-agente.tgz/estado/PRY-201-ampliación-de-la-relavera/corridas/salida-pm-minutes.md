# Acta — Ampliación de la relavera (PRY-201) · 2026-10-17
**Asistieron:** Andrés Lozano, Felipe Arango, Gustavo Neira, Javier Hoyos, Jorge Medina, Laura Vélez, Liliana Torres, María Restrepo, Mauricio Pérez, Paula Céspedes, Sandra Gil, Óscar Ramírez (12; los mismos del comité del 2026-10-10) · **Fuente:** `2026-10-17-notas-reunion.txt` · **Ausentes con tema en agenda:** ninguno (las notas no traen agenda)

Términos: ya estaban vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17); no hubo que registrar nada nuevo. Resumen: https://www.josenanez.com/es/agents/criterio-pmo/legal

## Compromisos
| Quién | Qué | Para cuándo | |
|---|---|---|---|
| Paula Céspedes | Enviar el documento 1 | 2026-11-26 | **Reprogramado 6 veces** (original 2026-09-14; 09-22, 10-12, 10-21, 11-01, 11-12, 11-26). Nota 4: «no alcanzó», «se compromete para el 26/11/2026» |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-27 | Nuevo. Nota 6 |

### Sin fecha
| Quién | Qué |
|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto — «la otra semana» (nota 5) no es una fecha; no se le calculó una |

## Decisiones
Ninguna. Las notas no registran ninguna decisión.

## Quedó sin decidir
| Qué | Por qué | Quién tiene la facultad |
|---|---|---|
| Si el riesgo del proveedor se registra y quién lo lleva | «Nadie lo anotó como riesgo» (nota 7) | No consta en los documentos |

## Intenciones sin doliente
Ninguna.

## Dicho al pasar y no registrado
| Qué | Quién lo dijo | Categoría | Ya estaba en el RAID |
|---|---|---|---|
| «El proveedor podría no llegar con el equipo completo para la siguiente fase» (nota 7) | No consta; las notas dicen «se comentó» | Riesgo | No. El informe del 2026-10-09 registra otro, «el proveedor no ha confirmado la fecha de la última entrega», que habla de la fecha, no del equipo completo. Queda en la ficha sin responsable |

## Cerrado en esta reunión
Nada. No se presentó ningún documento.

## Lo que esta reunión contradice
| Campo | Dijo la reunión | Dice el expediente | Fuente y fecha de cada uno |
|---|---|---|---|
| Próximo comité | «Próxima reunión en dos semanas» (2026-10-31) | Semanal, próximo 2026-10-24 | Notas 2026-10-17 · `config.json` (cadencia que propuso la configuración) |

La cadencia es un dato de configuración, no de la ficha. Lo dejo sin cambiar hasta que confirmes cuál rige.

## Sin resolver de la transcripción
- «Lo de enviar el documento 1 no alcanzó»: el plazo vigente era 2026-11-12, que aún no llega. No queda claro a qué plazo se refiere ni si hay otro anterior.
- «Revisión con el proveedor, queda para el 2026-10-27»: no dice si es una reunión o un entregable, ni si había una fecha previa.
- «Se comentó…»: sin autor, no se sabe quién advirtió el riesgo.
- Las notas no mencionan ninguno de los otros 20 compromisos abiertos, así que no se dan por cumplidos ni se reprograman.

## Recálculo
`compute` no trae `record_issues`. En la ficha corregí un dato mío: la «Revisión con el proveedor» tenía `original_due_date: no_declarada` y tiene fecha desde la primera vez, así que su original es 2026-10-27. Con la ficha completa: 26 compromisos, 22 abiertos, 6 vencidos sin acta (matriz 6 hace 32 días, punto 8 hace 15, ambiente 20 hace 9, anexo 19 hace 6, punto 24 hace 4, diseño 5 hace 2), 2 sin fecha (anexo 11 y presupuesto) y 2 reprogramados 5 veces o más (documento 1 y prueba 2). El informe del 2026-10-09 declara verde y el cálculo lo contradice. Pendiente de revisar: «Cerrar la prueba 18» (Javier Hoyos) y «Entregar el punto 8» (Óscar Ramírez) también traen `original_due_date: no_declarada` con fecha puesta después. Eso viene de las minutas anteriores y no lo toqué.

## Después
`/pm-commitments` para el seguimiento completo. `/pm-publish` no hace falta: ningún campo de la ficha cambió por esta reunión. Esta acta sale en la conversación y la guardas tú; no la escribí en tu carpeta de reuniones.
