# PRY-201 Ampliación de la relavera — semana del 2026-10-10 al 2026-10-17

*Términos vigentes (v1.1), aceptados por José Francisco Ñáñez el 2026-10-17. Sesión sin interfaz: nadie respondió a la pregunta de declaración.*

**Declara el gerente (Mauricio Pérez):** sin declaración nueva en esta corrida. La última que consta es **verde · 29 % · al 2026-10-09** (hace 8 días, vigente según el umbral de 14), tomada de `20-seguimiento/2026-10-09-informe-avance.md`. No la propuse ni la cambié: si el gerente quiere declarar otra, la línea queda suya.
**Sustento documental:** contradicho. Cero fuentes de evidencia; dos son declaración y 21 no están marcadas.
**Lo que el semáforo no explica:** desviación de tiempo (variance_time), hito cumplido sin evidencia, compromisos vencidos, compromisos reprogramados.

## Qué cambió esta semana
No hay comparación posible: es la primera corrida de informe y el diff contra la corrida anterior no trae cambios (0). Por eso no hay "estaba / está". Lo que entró desde la última lectura son dos compromisos sin fecha, uno de ellos de las notas de hoy (`2026-10-17-notas-reunion.txt`), y un riesgo dicho en esa reunión que nadie registró.

## Lo que sigue igual y sigue mal
| Qué | Desde | Días así |
|---|---|---|
| Hito «Ingeniería básica aprobada» declarado cumplido, sin evidencia | vencía 2026-07-02 | 107 |
| Compromiso Mauricio Pérez: Actualizar la matriz 6 | 2026-09-15 | 32 |
| Compromiso Óscar Ramírez: Entregar el punto 8 | 2026-10-02 | 15 |
| Compromiso Gustavo Neira: Validar el ambiente 20 | 2026-10-08 | 9 |
| Compromiso Óscar Ramírez: Revisar el anexo 19 | 2026-10-11 | 6 |
| Compromiso Jorge Medina: Entregar el punto 24 | 2026-10-13 | 4 |
| Compromiso Andrés Lozano: Aprobar el diseño 5 | 2026-10-15 | 2 |
| Incidencia: hallazgo de la auditoría de seguridad, sin responsable | 2026-10-09 | 8 |

## Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2027-02-03 | 2027-05-10 | **+96 días (29,6 %)**, umbral 10 % |
| Presupuesto | 4.200.000.000 COP | proyección 4.269.105.906 COP | +1,6 % (umbral 10 %) |

Replanificaciones registradas: **0**. El cronograma v2 (2026-10-09) ya trae el cierre al 2027-05-10, pero no hay línea base nueva aprobada. La solicitud CC-01 (2026-10-05) pide +96 días y 192.000.000 COP, y sigue **pendiente de decisión**. La fecha vigente se movió antes de que nadie decidiera.

Avance declarado 29 % frente a un plan que sustenta entre 33 % y 67 % según hitos (1 de 3 cumplido): brecha de 4 puntos. Eso no basta para marcar rojo, pero el único hito cumplido no tiene evidencia.

### Hitos de las próximas cuatro semanas
| Hito | Base | Vigente | Evidencia |
|---|---|---|---|
| Ingeniería de detalle aprobada | 2026-10-18 | 2026-10-18 | ninguna; pendiente, vence mañana |

## Las cifras
| Aprobado | Comprometido | Ejecutado | Proyectado | Disponible real |
|---|---|---|---|---|
| 4.200.000.000 | 3.527.144.366 (84,0 %) | 1.393.552.576 (33,2 %) | 4.269.105.906 | **672.855.634** |

El disponible real es aprobado menos comprometido, no aprobado menos ejecutado (que sería 2.806.447.424). La proyección ya supera lo aprobado, y CC-01 sumaría 192.000.000 COP sobre un disponible de 672.855.634.

## Abierto
**Reprogramados:** Paula Céspedes, «Enviar el documento 1», **6 veces** (original 2026-09-14, hoy 2026-11-26). María Restrepo, «Cerrar la prueba 2», **5 veces** (original 2026-09-12, hoy 2026-11-28). Ambos pasan el umbral de 3.
**Vencidos sin evidencia:** los seis de la tabla de arriba.
**Sin fecha:** María Restrepo, «Revisar el anexo 11» (comité 2026-09-19). Laura Vélez, «Mandar el ajuste del presupuesto» (notas de hoy).
**RAID sin movimiento:** tres riesgos y una incidencia, ninguno con responsable. Son la concentración del conocimiento en una persona, la fecha de última entrega sin confirmar por el proveedor, el riesgo de que el proveedor no llegue con el equipo completo (dicho en reunión, nunca registrado) y el hallazgo de seguridad. No hay fecha de último movimiento para calcular días.
**Proveedor:** «Equipos en el campamento» figura como entregado y aceptado, sin documento de recibo. El proveedor no tiene nombre, contrato ni monto facturado en la ficha.

## Lo que necesito de alguien
- **Mauricio Pérez:** declarar de nuevo el estado, con la evidencia de arriba a la vista. Cerrar o reprogramar «Actualizar la matriz 6».
- **Comité (excede al gerente):** decidir CC-01 (+96 días, +192.000.000 COP). Está pendiente y el cronograma ya asume el cambio.
- **Paula Céspedes y María Restrepo:** fecha firme o decisión de escalar. Llevan 6 y 5 reprogramaciones.
- **Quien tenga el acta de ingeniería básica:** aportar la evidencia del hito del 2026-07-02.
- **Responsable para cada riesgo e incidencia del RAID**, empezando por el hallazgo de seguridad.

Hay material para punto de comité: reprogramado más de 3 veces y desviación de tiempo por encima del umbral. La declaración quedó contradicha por la evidencia, así que corresponde `/pm-publish`. No los armé: se ofrecen.

## Lo que no se sabe
**Sin dato:** producto, autoridad y fase del proyecto; nombre del proveedor, referencia de contrato y valor facturado.
**Silencio:** último documento: hoy (notas de reunión del 2026-10-17). Última reunión de comité: 2026-10-10, hace 7 días. El tablero no calcula los días de silencio (`days_silent` vacío), así que estas cifras salen de los nombres de archivo.

---
*Ficha: `records/PRY-201.json`, cortada al 2026-10-17; fuentes de la declaración al 2026-10-09. Campos sin dato: 6. Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.13*
