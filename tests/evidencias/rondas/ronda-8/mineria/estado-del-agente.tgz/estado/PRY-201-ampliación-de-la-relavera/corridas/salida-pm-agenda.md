## Reunión de seguimiento — Ampliación de la relavera (PRY-201) · 2026-10-24
7 puntos · 45 minutos · 9 personas requeridas

Términos: ya vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17); no hubo que registrar nada nuevo.

**Fecha:** tomé el 2026-10-24, el comité semanal de la configuración. Las notas del 10-17 dicen «próxima reunión en dos semanas» (10-31). Si rige esa, la fecha de la agenda cambia y los plazos de abajo se recalculan. Se decide en el punto 5.
**Base de comparación:** esta es la primera corrida, no hay foto anterior (`diff` marca línea de partida). No puedo decir «sin cambios desde»; el anexo es solo lo que no necesita a nadie en la sala.

### Lo que no se destraba solo

> **[1] Que quede nombrado qué bloquea «Enviar el documento 1», o que se decida escalarlo** · 8 min · **Paula Céspedes**
> Prometido para el 2026-11-26, y antes para el 11-12, el 11-01, el 10-21, el 10-12, el 09-22. El original era el 2026-09-14: 73 días de corrimiento y seis reprogramaciones.
> Pregunta de entrada: las notas del 10-17 dicen que «no alcanzó», pero el plazo vigente era el 11-12, que no había llegado. No queda claro a qué plazo se refiere.
> Fuente: comités del 09-05, 09-12, 09-19, 09-26, 10-03, 10-10 y notas del 10-17.
> **Si no se resuelve hoy:** la séptima fecha se pone sin que nadie sepa qué falta. No consta en los documentos qué depende de este documento; Paula tiene que decirlo.

> **[2] Que quede nombrado qué bloquea «Cerrar la prueba 2», y fecha o acta para el anexo 11** · 8 min · **María Restrepo** (también patrocinadora, según el acta de constitución)
> Prometido para el 2026-11-28, y antes para el 11-14, el 10-25, el 10-10, el 09-25. El original era el 2026-09-12: 77 días y cinco reprogramaciones.
> Segunda parte: «Revisar el anexo 11» sigue sin fecha desde el 09-19. En el comité del 10-03 dijo que ya lo había entregado y no se presentó acta.
> Fuente: comités del 09-05 al 10-10; comité del 10-03.
> **Si no se resuelve hoy:** un compromiso del patrocinador que se mueve cada semana le enseña al resto que mover fechas no cuesta nada. Si el bloqueo depende de una decisión que solo ella puede tomar, es de comité y se formula con `/pm-escalate`.

### Vencido sin evidencia
Más viejo primero. Ninguno tiene acta de recibo ni entregable en el expediente.

| Quién | Qué | Desde | Qué se necesita hoy | Min |
|---|---|---|---|---|
| Mauricio Pérez | Actualizar la matriz 6 | 2026-09-15 (32 días al 10-17) | Fecha firme o entrega. Las minutas del 09-19, 09-26, 10-03 y 10-10 la repiten vencida sin reprogramarla. Es el gerente: lo dice él. | 2 |
| Óscar Ramírez | Entregar el punto 8 (2026-10-02) y revisar el anexo 19 (2026-10-11) | 15 y 6 días | Entrega o nueva fecha para los dos | 3 |
| Gustavo Neira | Validar el ambiente 20 | 2026-10-08 (9 días) | Entrega o nueva fecha | 2 |
| Jorge Medina | Entregar el punto 24 | 2026-10-13 (4 días) | Entrega o nueva fecha | 2 |
| Andrés Lozano | Aprobar el diseño 5 | 2026-10-15 (2 días; ya reprogramado en 10-01 y 10-15) | Que no llegue a tres: aprobación o qué lo impide | 2 |

Los días son al 10-17. Se recalculan con `/pm-commitments` el 10-23.

### Se decide hoy o se atrasa

| Qué | Quién decide | Si no se decide | Min |
|---|---|---|---|
| Qué fecha rige: comité semanal del 10-24 o «en dos semanas» (10-31) | El gerente (config contra notas del 10-17) | La agenda y los plazos se calculan contra una fecha que no es | 1 |
| Solicitud de cambio CC-01: ampliación de alcance, +96 días, +192.000.000 COP. Estado: «Pendiente de presentación al comité» (2026-10-05). | No consta quién tiene la facultad; `decided_by` está vacío. La patrocinadora asiste. | El cronograma v2 (2026-10-09) ya termina el 2027-05-10, que son los 96 días sobre el 2027-02-03 de la línea base original. El plan trabaja con un cambio sin aprobar. | 8 |
| Si el riesgo «el proveedor podría no llegar con el equipo completo» se registra y quién lo lleva | No consta. Nadie lo anotó (nota 7 del 10-17); en el RAID ya hay otro riesgo del proveedor, sin responsable, que habla de la fecha de entrega | Sigue sin doliente. Los dos riesgos del proveedor del RAID están sin responsable | 3 |
| Fecha para «Mandar el ajuste del presupuesto» («la otra semana» no es una fecha) | Laura Vélez | Sigue sin fecha, así que no puede vencerse | 1 |

### Vence antes de la próxima
Al 10-24 se re-corre `due`. Lo que no tenga acta para entonces pasa a vencido sin evidencia.

| Quién | Qué | Para cuándo |
|---|---|---|
| Felipe Arango | Cerrar la prueba 10 | 2026-10-17 (hoy; ya reprogramada una vez, original 10-06) |
| Sandra Gil | Confirmar la fecha 15 | 2026-10-17 (hoy; ya reprogramada una vez, original 10-07). Opcional en sala si llega con acta |
| Felipe Arango | Entregar el punto 16 | 2026-10-19 (ya reprogramado una vez, original 10-12) |
| Gustavo Neira | Aprobar el diseño 21 | 2026-10-19 |
| Laura Vélez | Aprobar el diseño 13 | 2026-10-21 (ya reprogramado una vez, original 09-30) |
| Felipe Arango | Validar el ambiente 12 | 2026-10-22 (ya reprogramado una vez, original 10-12) |
| (hito, sin responsable en la ficha) | Ingeniería de detalle aprobada | 2026-10-18, pendiente |

Felipe Arango tiene tres compromisos que ya se movieron una vez y caen todos en la semana: 5 min, juntos, para esto (en el total de 45).

### No es de esta reunión

| Qué | Por qué | Dónde va |
|---|---|---|
| La causa de fondo de las seis y cinco reprogramaciones (puntos 1 y 2) si resulta ser una decisión o recurso fuera del gerente | Qué se pide, qué pasa si no se decide y quién tiene la facultad exceden la autoridad del gerente | `/pm-escalate` y material de comité |
| Cambio de la línea base si se aprueba CC-01 | La línea base es de solo agregar y la mueve el control de cambios, no la reunión | `/baseline-variance` después de la decisión |
| El hito «Ingeniería básica aprobada» marcado cumplido sin evidencia (107 días) y el informe del 10-09 en verde | No necesita a nadie en la sala; es contraste del informe contra la evidencia | `/pm-report` |

### Anexo
No hay foto previa, así que esto no es «sin cambios desde»: es lo abierto que hoy no necesita a nadie en la sala. Una línea cada uno, no se repasa.
- Liliana Torres · Enviar el documento 9 · 2026-11-16 (reprogramado dos veces: 10-28 y 11-16; original 10-11)
- Andrés Lozano · Enviar el documento 17 · 2026-10-30 (reprogramado una vez; original 10-17)
- Javier Hoyos · Cerrar la prueba 18 · 2026-10-25
- Óscar Ramírez · Revisión con el proveedor · 2026-10-27 (nuevo; las notas no dicen si es reunión o entregable)
- Andrés Lozano · Confirmar la fecha 23 · 2026-11-04
- Mauricio Pérez · Actualizar la matriz 22 · 2026-11-05

### Personas requeridas (9)
Paula Céspedes, María Restrepo, Mauricio Pérez, Óscar Ramírez, Gustavo Neira, Jorge Medina, Andrés Lozano, Laura Vélez y Felipe Arango. No hay punto propio para Sandra Gil (opcional), Javier Hoyos ni Liliana Torres.

## Después
- Cuando termine, `/pm-minutes` sobre las notas; los compromisos que salgan entran a `/pm-commitments` con su cita.
- Con `/pm-escalate` queda formulado el documento 1 y la prueba 2 si el bloqueo excede al gerente.
- Este comando no convoca a nadie; citar a la reunión es del gerente.
