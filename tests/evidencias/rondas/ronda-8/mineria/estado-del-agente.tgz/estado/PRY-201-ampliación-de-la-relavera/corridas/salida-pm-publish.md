Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17); no hubo que registrar nada.

Recalculé la ficha antes de publicar (`compute`, corte 2026-10-17). La fecha de cierre vigente es **2027-05-10**, tomada del último hito del cronograma v2 (2026-10-09); la del acta, **2027-02-03**, va en `plan.baseline`. Hay 96 días de atraso contra la línea base original.

**Lo que voy a publicar:** 23 campos con dato · 6 sin decir en ninguna parte (producto, autoridad, fase, y del proveedor: nombre, referencia de contrato y facturado) · el estado declarado es **verde** al 2026-10-09, escrito por el gerente.

Esa declaración queda marcada como declarada. Con el corte de hoy, cuatro señales no la acompañan: compromisos vencidos, compromisos reprogramados, un hito dado por cumplido sin evidencia y el atraso de 96 días.

La carpeta de gobierno ya existía, así que no hubo que crearla.

Publiqué la ficha en `/home/claude/banco/ronda-8/mineria/espacio/documentos/proyectos/PRY-201-ampliación-de-la-relavera/00-gobierno/ficha-pm.json`, con corte al 2026-10-17.

**Lleva:** 23 campos con dato · 6 sin decir en ninguna parte · declara **verde** al 2026-10-09

**Lo más viejo que va ahí:** identity.sponsor, identity.manager, identity.committee, plan.start_date, money.approved y plan.scope_summary, del 2026-03-06 (acta de constitución) — no pasa de un año.
