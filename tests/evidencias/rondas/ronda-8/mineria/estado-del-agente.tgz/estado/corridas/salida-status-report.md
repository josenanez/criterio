Ficha: `estado/records/PRY-209.json`, actualizada el 2026-10-17. Cálculos de `portafolio.py compute`, as_of 2026-10-17. Términos vigentes (v1.1, familia 0.3.13), aceptados por José Francisco Ñáñez el 2026-10-17.

## PRY-209 — Electrificación de equipos — estado al 2026-10-17

**Declara el gerente (Rubén Cárdenas):** verde · 36% · al 2026-09-25 (22 días de antigüedad)
**Sustento documental:** sin sustento. Fuentes marcadas como evidencia: 0; como declaración: 2; sin marcar: 15. El único documento posterior al acta es el propio informe de avance del gerente.
**Lo que el semáforo no explica:** `silent` (22 días sin documento nuevo, desde 2026-09-25; el umbral es 15).
**Último documento:** 2026-09-25 (informe de avance) · **Última reunión:** sin dato — la carpeta no contiene actas ni transcripciones de reunión.

Alerta activa `declared_vs_evidence`: el gerente declara verde y hay una señal que ese verde no cubre.

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2026-08-29 | 2026-08-29 | 0 días (original y vigente) |
| Presupuesto aprobado | 6.800.000.000 COP | 6.800.000.000 COP | proyección 6.850.769.572 COP: +0,7 % sobre lo aprobado |

Replanificaciones: 0. No hay cambios registrados.

Presupuesto (COP, informe del 2026-09-25): comprometido 3.691.737.469 (54,3 %), ejecutado 2.547.469.156 (37,5 %), disponible real 3.108.262.531.

La fecha de cierre vigente (2026-08-29) es anterior a la fecha de este informe y el avance declarado es 36 %. La línea base no se ha movido, así que la desviación calculada es 0 días aunque el plazo ya pasó: el script no la mide porque nadie replanificó. Que el plazo haya vencido con ese avance no lo explica ningún documento de la carpeta.

### Hitos
Sin dato. La ficha no tiene hitos: el acta no trae cronograma y la carpeta no tiene ninguno ("no hay cronograma en la carpeta"). Sin hitos no se puede comparar el 36 % declarado contra lo que el plan sostiene.

### Dónde no coincide
- **Declarado:** verde, 36 % (informe de avance, 2026-09-25).
- **Documentos:** el mismo informe reporta una incidencia abierta —«El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite»— desde 2026-09-25, y dos riesgos (concentración del conocimiento en una sola persona; bloqueo de la vía de acceso a la mina). Un ensayo fallido que se repite no es obviamente compatible con verde; el semáforo no dice por qué lo es.
- Desde esa fecha no hay ningún documento. Un verde de hace 22 días, con el plazo contractual ya pasado, no es un verde sustentado.

### Abierto
**Riesgos e incidencias sin movimiento:** ambos riesgos y la incidencia datan del informe del 2026-09-25 y ninguno tiene dueño (owner: sin dato). 22 días sin movimiento.
**Compromisos vencidos:** ninguno registrado (la ficha no tiene compromisos; no hay minutas de las que extraerlos).
**Dependencias sin confirmar:** ninguna registrada.

### Sin dato
- Producto, autoridad y fase del proyecto (`not_found`).
- Hitos y cronograma.
- Última reunión y compromisos (no hay actas).
- Dueños de los dos riesgos y de la incidencia.
- Proveedores: ninguno en la ficha.
- Campos de identidad, plan y presupuesto aprobado con fuente de 2025-05-15 (17 meses; umbral 12): código, nombre, área, patrocinador, gerente, comité, fechas de inicio y fin, alcance, exclusiones y presupuesto aprobado. Pueden haber cambiado y no hay documento posterior que lo diga.

### Después
No hay desviación sobre el umbral en lo calculado, pero sí silencio y una declaración que los documentos no sostienen. Puedo preparar el punto para el comité (próximo: 2026-10-21) pidiendo al gerente un informe actualizado, el cronograma, y los dueños de los riesgos. No he preparado nada.

---
criterio-portfolio 0.3.13 · ficha PRY-209 del 2026-10-17 (declaración del 2026-09-25) · campos inciertos: los 11 listados en «Sin dato» con fuente de 2025 más producto, autoridad y fase · Términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.13
