# Corrida del 2026-10-17 · project-closure

13 proyectos · 43 s · 52 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 15 |
| `declared_vs_evidence` | 7 |
| `commitment_overdue` | 6 |
| `variance_time` | 4 |
| `progress_vs_plan` | 4 |
| `variance_cost` | 3 |
| `rebaseline_unauthorized` | 3 |
| `commitment_undated` | 2 |
| `commitment_rescheduled` | 2 |
| `vendor_deliverable_late` | 2 |
| `vendor_invoiced_without_delivery` | 2 |
| `vendor_accepted_without_evidence` | 1 |
| `silent` | 1 |

Borrador de cierre de PRY-204: nadie declara el cierre; criterio de éxito no determinable; desviación 40 días (18,7 %) vs original, v2 sin autorización; CC-01 pendiente; sin doliente en 3 RAID abiertos; no se movió a archivo. No sé si el proyecto terminó ni qué son los componentes 1-3.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

**Ficha y documentos de los que sale:** `estado/records/PRY-204.json` (actualizada 2026-10-17) y los 5 documentos de `PRY-204-monitoreo-de-taludes`: acta de constitución (2025-08-19), cronogramas v1 y v2, solicitud de cambio CC-01 (2026-10-06) e informe de avance (2026-10-17). Las cifras salen de `portafolio.py compute` con corte 2026-10-17.

**Términos:** ya vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17). No se volvieron a registrar.

## Cierre — PRY-204 Monitoreo de taludes — 2026-10-17

> **Lo primero:** en la documentación nadie declara que el proyecto terminó. El informe de avance del 2026-10-17 lo reporta en **verde, 45 %**, con una solicitud de cambio sin decidir. Esto es un **borrador de acta de cierre** para que alguien decida si se cierra. No es un cierre por cumplimiento.

### Contra lo comprometido
**Criterio de éxito:** "Monitoreo de taludes en producción y medido" (acta de constitución, 2025-08-19).
**Se cumplió:** **no se puede determinar.** Ningún documento muestra el monitoreo en producción ni una medición. El único dato cercano es el informe de avance, que dice que "el primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite". Eso apunta a que no se ha cumplido.

| Entregable comprometido | Estado | Evidencia |
|---|---|---|
| Componente 1 | Sin dato | El acta no lo describe más allá del nombre. |
| Componente 2 | Sin dato | Igual. |
| Componente 3 | Sin dato | Igual. |
| Hito: Ingeniería básica aprobada (2025-11-08) | "cerrado" en el cronograma v2 | Ninguna: no hay documento de aprobación. Señal `milestone_met_without_evidence`, 343 días. |
| Hito: Ingeniería de detalle aprobada (2026-01-18) | "cerrado" en el cronograma v2 | Ninguna. 272 días. |
| Hito: Licencia y permisos obtenidos (línea base 2026-03-31; vigente 2026-05-10) | "cerrado" en el cronograma v2 | Ninguna. 160 días. |

El cronograma solo tiene 3 hitos, y ninguno es la puesta en producción ni la medición que pide el criterio de éxito. Los 3 aparecen cerrados mientras el avance declarado es 45 %. El plan sostiene entre 100 % y 100 %, así que hay 55 puntos de diferencia (`progress_vs_plan`).

### Fuera de alcance final
| Qué quedó fuera | Decidido por | Cuándo |
|---|---|---|
| El acta excluye "lo que otro proyecto cubre", sin decir cuál proyecto ni qué | Sin dato | 2025-08-19 (acta) |
| Ampliación de alcance pedida en CC-01 | **Sin decisión**: pendiente de presentación al comité | Solicitada el 2026-10-06 |

No hay alcance recortado con decisión registrada. Tampoco puedo decir si se recortó algo, porque el alcance se define como "Componentes 1, 2 y 3" sin detalle.

### Números finales
| | Original | Vigente | Final | Desviación vs original |
|---|---|---|---|---|
| Fecha de cierre | 2026-03-31 | 2026-05-10 | **Sin fecha real de cierre** | +40 días (18,7 %) |
| Presupuesto (COP) | 800.000.000 | 800.000.000 | Ejecutado a hoy 361.778.067 (45,2 %); comprometido 434.957.088 (54,4 %); proyección al cierre 765.155.217 (−4,4 %) | Sin dato de ejecución final |

Replanificaciones: **1.**

- **Contra la línea base original** (2026-03-31) la desviación es de 40 días, 18,7 %. Supera el umbral del 10 %. Contra la vigente (2026-05-10) es de 0 días, porque la vigente se movió.
- La v2 del cronograma lleva fecha 2026-10-17 y no dice motivo ni aprobación. El script marca `rebaseline_unauthorized`: se movieron 40 días y hay 0 autorizados. La única solicitud de cambio, CC-01, está pendiente y pide "+40 días sobre la línea base vigente". Los documentos no relacionan CC-01 con el desplazamiento de la v2, así que no afirmo que sea el mismo cambio.
- La fecha vigente (2026-05-10) ya pasó, y no hay evidencia de que el proyecto haya terminado.
- El presupuesto no tiene replanificación. El costo de CC-01 (80.000.000 COP adicionales) no está aprobado y no lo sumo a nada.
- Las cifras de dinero son declaradas en el informe de avance. No hay facturas ni extractos que las respalden.

### RAID al cierre
**Materializados:** el informe no lo dice. Hay dos hechos ocurridos en el periodo: un hallazgo de la auditoría de seguridad y el ensayo de disponibilidad no alcanzado. Ninguno está clasificado como riesgo materializado ni se vincula a un riesgo previo, porque no existía un registro RAID anterior.
**No materializados:** sin dato.
**Abiertos, con doliente:** **ninguno tiene doliente con nombre, así que ninguno puede darse por cerrado.**

| Tipo | Qué | Desde | Doliente |
|---|---|---|---|
| Riesgo | El proveedor no ha confirmado la fecha de la última entrega | Sin fecha | **Sin doliente** |
| Incidencia | Hallazgo levantado en la auditoría de seguridad | 2026-10-17 | **Sin doliente** |
| Incidencia | El primer ensayo de disponibilidad no alcanzó lo pactado y se repite | 2026-10-17 | **Sin doliente** |
| Cambio | CC-01, ampliación de alcance, pendiente | 2026-10-06 | **Sin decisor** |

El proveedor del riesgo no figura en la ficha, que tiene `vendors: []`. No hay contrato ni entregables que contrastar.

### Lecciones
No hay ninguna que se pueda sustentar con la documentación disponible. Estas son las que se pueden anclar a un hecho, y son sobre el control del proyecto, no sobre el trabajo:

| Qué pasó | Cuándo | Efecto | Qué haríamos distinto |
|---|---|---|---|
| El cronograma v2 movió "Licencia y permisos obtenidos" de 2026-03-31 a 2026-05-10, sin motivo ni aprobación escritos | v2 fechada 2026-10-17 | La fecha final se corrió 40 días (18,7 %) sin autorización. La desviación vs la original se ve solo si se compara con la v1 | Registrar el motivo y la aprobación en el momento en que se corre una línea base. Tener la v2 desde antes de la fecha vencida |
| Los 3 hitos se reportan como cerrados sin documento de aprobación | Hitos de 2025-11-08, 2026-01-18 y 2026-05-10 | Con 3 de 3 hitos "cerrados" y 45 % declarado, nadie puede decir cuánto falta | Exigir el documento de aprobación como condición para marcar un hito como cumplido |
| El informe de avance declara verde con una desviación del 18,7 % y un ensayo fallido | 2026-10-17 | El estado reportado no coincide con las señales (`declared_vs_evidence`) | Contrastar el estado declarado con las señales antes de publicarlo |

Las dos primeras son lecciones de control, no de ejecución técnica. No hay base documentada para decir por qué el ensayo falló ni por qué se retrasó la licencia.

### Sin dato
- Si el proyecto terminó y quién lo declara. No existe acta ni declaración de cierre.
- Estado del criterio de éxito: si hay monitoreo en producción y si se midió.
- Qué son los componentes 1, 2 y 3.
- Qué proyecto cubre lo que el acta excluye.
- Motivo y aprobador de la v2 del cronograma.
- Fecha real de terminación y gasto final.
- Autoridad que aprueba el cierre y fase del proyecto (campos `identity.authority` e `identity.phase` no encontrados).
- Evidencia de las aprobaciones de ingeniería básica y de detalle, y de la licencia.
- Dolientes de las 2 incidencias y del riesgo abierto.

### Después
La carpeta **no** se mueve a `archivo/` ni se congela la ficha: eso corresponde a un proyecto cerrado, y este no lo está. Cuando el comité decida el cierre, o decida CC-01, se vuelve a correr esta herramienta.

*Pie de rigor: borrador de trabajo de Criterio. Se apoya solo en los 5 documentos citados. Ninguno es evidencia independiente de ejecución: el avance, el presupuesto y los estados de los hitos son declaraciones del gerente. La verificación es suya.*
