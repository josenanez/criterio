## Diagnóstico · PRY-204 Monitoreo de taludes · 2026-10-17

**Leí:** 5 documentos de la carpeta del proyecto · de 2025-08-19 a 2026-10-17 · formatos: .docx (1), .csv (2), .md (2). Además leí los 5 documentos del producto PRD-301 «Alerta de taludes» (2025-10-08 a 2026-10-15; .md y .docx), porque el acta asocia ese producto al proyecto, y busqué el código y el nombre en el texto de las demás carpetas (.md, .txt, .csv).
**No pude leer:** nada de lo que existe se quedó sin leer. Dos límites de la búsqueda cruzada: no abrí el contenido de los .docx de otros proyectos, así que una mención de PRY-204 dentro de uno de ellos no habría aparecido; y la ficha previa del proyecto (`estado/records/PRY-204.json`) la abrí para orientarme, pero cada dato de abajo sale de los documentos, no de ella.

### Dictamen
**Sostenido:** 3 afirmaciones · **Sin sustento:** 7 · **Contradicho:** 3

Desde esta carpeta se puede afirmar quién gobierna el proyecto, cuánto se aprobó y que hay una solicitud de cambio pendiente. No se puede afirmar el estado verde ni el 45%: el informe de avance, que es la única fuente de ambos, está contradicho por el cronograma y por la solicitud de cambio, y ninguno de los tres hitos que el cronograma da por cerrados tiene un documento que lo respalde. La carpeta sí permite dictaminar que el verde no se sostiene; no permite decir cuál es el estado real.

### Gobierno
| | Qué dice el documento | Fuente |
|---|---|---|
| Patrocinador | Jorge Medina | Acta de constitución 2025-08-19 |
| Gerente | Beatriz Cuéllar | Acta de constitución 2025-08-19; informe de avance 2026-10-17 |
| Autoridad declarada | **No declarada.** El acta no dice qué puede aprobar el gerente ni quién aprueba replanificaciones | Acta de constitución 2025-08-19 |
| Comité | Comité de Seguridad, que aprobó el presupuesto el 2025-08-19 | Acta de constitución 2025-08-19 |

Sin autoridad declarada no hay desviación aprobada: las fechas nuevas son fechas que alguien escribió. La carpeta no tiene actas ni minutas del comité (no existe `30-reuniones`).

### Contra el plan
- **Línea base original (v1, 2025-08-19):** cierre 2026-03-31. Inicio 2025-08-29 según el acta; el csv no trae inicio.
- **Vigente (v2, archivo del 2026-10-17):** el hito «Licencia y permisos obtenidos» pasa de 2026-03-31 a 2026-05-10, y con él el cierre. **Motivo de la replanificación: no está en ningún documento.** El csv no trae aprobación ni aprobador; la fecha de aprobación que figura es la del archivo.
- **Desviación en tiempo:** +40 días contra la original, 18.7 %, sobre el umbral de 10 % de la configuración. Contra la vigente: 0 días. Replanificaciones: 1.
- **Autorizados: 0 de 40 días.** La única solicitud de cambio, CC-01 (2026-10-06, Beatriz Cuéllar), pide +40 días «sobre la línea base vigente» y +80.000.000 COP, y dice «Pendiente de presentación al comité». El cronograma ya refleja los 40 días antes de que el comité haya visto el cambio. Los documentos no dicen si los 40 días de CC-01 son los mismos que ya están en v2 o son adicionales a ellos.
- **La fecha vigente de cierre (2026-05-10) ya pasó hace 160 días** y el proyecto sigue abierto. El cronograma tiene solo tres hitos, los tres «cerrado», y ninguno para los componentes 1, 2 y 3 ni para el criterio de éxito del acta («monitoreo de taludes en producción y medido»). Ningún documento dice cuándo se espera terminar.

### Hitos vencidos sin evidencia
Los tres hitos figuran como «cerrado» en el cronograma, y ninguno tiene un documento que lo respalde en la carpeta. Los días son desde la fecha vigente hasta el corte.

| Hito | Fecha | Días | Qué documento se esperaría |
|---|---|---|---|
| Ingeniería básica aprobada | 2025-11-08 | 343 | Acta o carta de aprobación de la ingeniería básica |
| Ingeniería de detalle aprobada | 2026-01-18 | 272 | Acta o carta de aprobación de la ingeniería de detalle |
| Licencia y permisos obtenidos | 2026-05-10 (original 2026-03-31) | 160 | Resolución o licencia de la autoridad que otorga el permiso |

### Dinero
Moneda: COP. Cifras de ejecución y proyección: solo del informe de avance, sin soporte contable en la carpeta.

| Aprobado | Comprometido | Ejecutado | Proyección | Disponible real |
|---|---|---|---|---|
| 800.000.000 | 434.957.088 (54.4 %) | 361.778.067 (45.2 %) | 765.155.217 (−4.4 % vs aprobado) | 365.042.912 |

- El 45.2 % ejecutado coincide con el 45 % de avance declarado; el informe no dice con qué se mide ese avance.
- La proyección no dice si incluye los 80.000.000 COP de CC-01, que está pendiente.
- Comprometido está lejos del umbral de 90 %; no hay alerta de dinero.

### Lo que se dijo y nadie registró
No hay minutas en la carpeta, así que de ellas no sale nada. Lo que el informe de avance menciona y ningún registro recoge:
- **Dependencia no declarada:** el acta dice «Ninguna declarada», pero el informe habla de un proveedor que no ha confirmado la fecha de la última entrega. No hay contrato, entregables ni facturas del proveedor en la carpeta. El riesgo no tiene dueño.
- **Dos incidencias sin dueño ni fecha:** un hallazgo de la auditoría de seguridad (sin informe de auditoría ni descripción), y el primer ensayo de disponibilidad de los equipos que «no alcanzó lo pactado y se repite» (sin lo pactado, sin resultado, sin fecha del nuevo ensayo).
- **Compromisos:** ninguno registrado.
- **Producto:** el acta asocia el producto «alerta de taludes»; PRD-301 tiene ese nombre, pero el acta no cita su código. PRD-301 dice «Proyectos que lo construyen: ninguno declarado», y los 14 requerimientos de su comité del 2026-10-15 tienen «—» en «Proyecto que lo ejecuta» (dos tienen como doliente a Beatriz Cuéllar: REQ-4100 y REQ-4111). Ningún requerimiento está ligado a PRY-204.

### Contradicho
| Afirmación | Documento A | Documento B |
|---|---|---|
| Estado verde | Informe de avance 2026-10-17: «Verde» | Cronograma v1 → v2: +40 días (18.7 %) sin aprobación; CC-01 pendiente; y el propio informe reporta un hallazgo de auditoría y un ensayo que no alcanzó lo pactado |
| Avance 45 % | Informe de avance 2026-10-17: 45 % | Cronograma v2: 3 de 3 hitos cerrados (el plan sostendría 100 %); o el avance está mal, o el cronograma está incompleto. Los documentos no dicen cuál |
| El cronograma v2 es el vigente | Cronograma v2, archivo del 2026-10-17, con cierre 2026-05-10 | CC-01 (2026-10-06): el cambio de tiempo está «pendiente de presentación al comité» |

### Sin sustento
Nada en la carpeta lo contradice y nada lo respalda:
1. **Hito «Ingeniería básica aprobada» cerrado.**
2. **Hito «Ingeniería de detalle aprobada» cerrado.**
3. **Hito «Licencia y permisos obtenidos» cerrado.**
4. **Comprometido 434.957.088, ejecutado 361.778.067 y proyección 765.155.217:** no hay ejecución presupuestal, facturas ni contratos.
5. **Hallazgo levantado en la auditoría de seguridad.**
6. **Primer ensayo de disponibilidad no alcanzó lo pactado.**
7. **El proveedor no ha confirmado la fecha de la última entrega.**

### Lo que esta carpeta no permite saber
- **Quién aprueba replanificaciones:** sin autoridad declarada no se puede decir si los 40 días son una desviación aprobada o una fecha escrita sin aprobación. Eso depende de una respuesta del patrocinador o del comité.
- **Si los tres hitos se cumplieron de verdad:** sin esa evidencia no se puede medir el avance real ni confirmar el 100 % que sugiere el plan.
- **Qué hay en los «Componentes 1, 2 y 3»:** el acta no los describe, así que el avance no se puede medir contra el alcance.
- **Cuándo termina el proyecto:** la fecha vigente pasó hace 160 días y no hay otra. No se puede calcular un atraso futuro.
- **Qué pactó el proveedor y qué se le ha pagado:** sin contrato ni entregables no se puede cruzar lo entregado con lo ejecutado.
- **Qué se pactó para el ensayo de disponibilidad y qué midió:** sin eso no se puede saber la gravedad de la incidencia.
- **Qué dijo el comité:** sin minutas no se sabe si CC-01 se presentó ni qué se decidió.
- **Fase actual del proyecto:** no está declarada en ningún documento.
- **Si la proyección incluye CC-01:** sin eso no se sabe si el cierre previsto está dentro o por encima de los 800.000.000 aprobados.
- **Cuánto vale el dato:** los datos de gobierno, alcance y presupuesto aprobado tienen 14 meses (acta de 2025-08-19), por encima del umbral de 12 meses.

### Cierre
Esto es un borrador de trabajo con la cita al documento de cada dato; la verificación es de quien lo recibe. No recomiendo detener, continuar ni reestructurar: eso lo decide quien tiene la facultad. Puedo llevar las tres contradicciones al gerente como preguntas, una por una, o preparar el punto de comité con la lista de lo que falta.
