Salgo de: las 13 fichas de `estado/records` (PRY-199 a PRY-211, todas con corte 2026-10-17), los informes de avance que las fichas citan, las 13 actas de comité y las notas de reunión del 2026-10-17 de PRY-201 (texto en caché), y las 13 actas de constitución (sección «Dependencias declaradas»). Los términos están vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17).

## RAID — Portafolio de proyectos mineros al 2026-10-17
12 riesgos · 0 supuestos · 17 incidencias · 10 dependencias (39 ítems)
39 sin doliente · 39 sin fecha · 0 evaluables por «sin movimiento» (ver nota) · 1 no registrado formalmente

Escala: ningún documento valora probabilidad ni impacto. No inventé una; las columnas quedan en «—».

### Necesitan decisión ahora
| Id | Tipo | Qué | Doliente | Desde | Por qué sube |
|---|---|---|---|---|---|
| PRY-205-I1, PRY-205-I2 | Incidencia | El ensayo de disponibilidad no alcanzó lo pactado y se repite; hallazgo en la auditoría de seguridad | Sin doliente | 2026-10-13 | Proyecto en rojo, sin doliente ni fecha de resolución, y con fin de plan 2026-03-19 ya vencido |
| PRY-205-D1 | Dependencia | El proveedor no ha confirmado la fecha de la última entrega | Sin doliente | 2026-10-13 | Misma razón; es una dependencia declarada, no acordada |
| PRY-210-I1, PRY-210-D1 | Incidencia, dependencia | Equipos entregados pendientes de aceptación; proveedor sin fecha de la última entrega | Sin doliente | 2026-10-14 | Proyecto en rojo, sin doliente. CC-01 (+58 días, 116.000.000 COP) figura aprobada |
| PRY-200-I1 | Incidencia | Las lluvias detuvieron el montaje diez días | Sin doliente | 2026-10-09 | Proyecto en rojo. CC-01 (+104 días, 208.000.000 COP) sigue pendiente de decisión |
| PRY-201-R2, PRY-201-D1 | Riesgo (no registrado), dependencia | El proveedor podría no llegar con el equipo completo para la siguiente fase; no ha confirmado la fecha de la última entrega | Sin doliente | 2026-10-09 y 2026-10-17 | El estado declarado es verde y no hay doliente. CC-01 (+96 días, 192.000.000 COP) sigue pendiente. Hay un compromiso abierto de Óscar Ramírez, «Revisión con el proveedor», para 2026-10-27 |

### Detectados en reuniones, no registrados
| Qué | Tipo | Dicho en | Fecha |
|---|---|---|---|
| El proveedor podría no llegar con el equipo completo para la siguiente fase | Riesgo | PRY-201, notas de reunión («nadie lo anotó como riesgo») | 2026-10-17 |

Es el único. Busqué en las 13 actas de comité y en las notas frases de riesgo, condición o dependencia («si no», «depende de», «podría», «problemas», «bloqueo», «pendiente de» y similares) y no apareció ningún otro. No inventé ninguno. La ficha de PRY-201 ya lo recoge, sin doliente, pero no está en el informe de avance del 2026-10-09, que es el registro formal.

### Sin doliente o sin fecha
Los 39 ítems carecen de doliente y de fecha de resolución o revisión. No relleno ninguno. Las incidencias traen la fecha «desde» del informe en que aparecen, pero no una fecha de cierre. El detalle por ítem está en el registro completo.

### Dependencias en riesgo
| Id | Depende de | Confirmada | Qué pasó |
|---|---|---|---|
| (ninguna) | — | — | Las 13 actas de constitución dicen «Dependencias declaradas: Ninguna declarada», y ninguna ficha trae una dependencia con código de proyecto. **No puedo hacer el cruce entre proyectos.** No afirmo que no existan dependencias: afirmo que ninguna está declarada. |

Reclasifiqué 10 ítems que las fichas llevan como «riesgos». Ya no son inciertos, dependen de un tercero, y por eso son dependencias:
- **«El proveedor no ha confirmado la fecha de la última entrega»** (PRY-201, 204, 205, 210). Depende de un tercero y la fecha está sin confirmar. Es dependencia declarada, no acordada. Contraparte: proveedor, sin código de proyecto ni contrato citado en la ficha.
- **«Ventana de parada de planta definida por operaciones»** (PRY-200, 202, 203, 206, 207, 208). La decide un área ajena al proyecto. En PRY-206 el informe dice además que la parada ya se reprogramó (PRY-206-I2), es decir, esa dependencia ya golpeó.

### Registro completo
Todos los ítems tienen doliente «—», fecha «—» y probabilidad e impacto «—». «Último movimiento» es la fecha del informe donde aparece el ítem.

| Id | Tipo | Qué | Último movimiento |
|---|---|---|---|
| PRY-199-R1 | Riesgo | Cambio en la licencia ambiental que puede mover el alcance | 2026-10-15 |
| PRY-199-I1 | Incidencia | El equipo perdió dos semanas por rotación de un ingeniero clave | 2026-10-15 |
| PRY-199-I2 | Incidencia | El primer ensayo de disponibilidad no alcanzó lo pactado y se repite | 2026-10-15 |
| PRY-200-R1 | Riesgo | Concentración del conocimiento en una sola persona | 2026-10-09 |
| PRY-200-D1 | Dependencia (reclasificada) | Ventana de parada de planta definida por operaciones | 2026-10-09 |
| PRY-200-I1 | Incidencia | Las lluvias detuvieron el montaje diez días | 2026-10-09 |
| PRY-201-R1 | Riesgo | Concentración del conocimiento en una sola persona | 2026-10-09 |
| PRY-201-R2 | Riesgo (no registrado formalmente) | El proveedor podría no llegar con el equipo completo para la siguiente fase | 2026-10-17 |
| PRY-201-D1 | Dependencia (reclasificada) | El proveedor no ha confirmado la fecha de la última entrega | 2026-10-09 |
| PRY-201-I1 | Incidencia | Hallazgo levantado en la auditoría de seguridad | 2026-10-09 |
| PRY-202-D1 | Dependencia (reclasificada) | Ventana de parada de planta definida por operaciones | 2026-10-12 |
| PRY-202-I1 | Incidencia | El equipo perdió dos semanas por rotación de un ingeniero clave | 2026-10-12 |
| PRY-203-R1 | Riesgo | Cambio en la licencia ambiental que puede mover el alcance | 2026-10-13 |
| PRY-203-D1 | Dependencia (reclasificada) | Ventana de parada de planta definida por operaciones | 2026-10-13 |
| PRY-203-I1 | Incidencia | Hallazgo en la auditoría de seguridad | 2026-10-13 |
| PRY-203-I2 | Incidencia | El proveedor entregó los equipos en el campamento, pendientes de aceptación | 2026-10-13 |
| PRY-204-D1 | Dependencia (reclasificada) | El proveedor no ha confirmado la fecha de la última entrega | 2026-10-17 |
| PRY-204-I1 | Incidencia | Hallazgo levantado en la auditoría de seguridad | 2026-10-17 |
| PRY-204-I2 | Incidencia | El primer ensayo de disponibilidad no alcanzó lo pactado y se repite | 2026-10-17 |
| PRY-205-D1 | Dependencia (reclasificada) | El proveedor no ha confirmado la fecha de la última entrega | 2026-10-13 |
| PRY-205-I1 | Incidencia | El primer ensayo de disponibilidad no alcanzó lo pactado y se repite | 2026-10-13 |
| PRY-205-I2 | Incidencia | Hallazgo en la auditoría de seguridad | 2026-10-13 |
| PRY-206-R1 | Riesgo | Concentración del conocimiento en una sola persona | 2026-10-16 |
| PRY-206-D1 | Dependencia (reclasificada) | Ventana de parada de planta definida por operaciones | 2026-10-16 |
| PRY-206-I1 | Incidencia | Hallazgo levantado en la auditoría de seguridad | 2026-10-16 |
| PRY-206-I2 | Incidencia | Se reprogramó la parada de planta por la ventana de mantenimiento | 2026-10-16 |
| PRY-207-R1 | Riesgo | Concentración del conocimiento en una sola persona | 2026-09-24 |
| PRY-207-D1 | Dependencia (reclasificada) | Ventana de parada de planta definida por operaciones | 2026-09-24 |
| PRY-207-I1 | Incidencia | El equipo perdió dos semanas por rotación de un ingeniero clave | 2026-09-24 |
| PRY-208-R1 | Riesgo | Bloqueo de la vía de acceso a la mina | 2026-10-12 |
| PRY-208-D1 | Dependencia (reclasificada) | Ventana de parada de planta definida por operaciones | 2026-10-12 |
| PRY-209-R1 | Riesgo | Concentración del conocimiento en una sola persona | 2026-09-25 |
| PRY-209-R2 | Riesgo | Bloqueo de la vía de acceso a la mina | 2026-09-25 |
| PRY-209-I1 | Incidencia | El primer ensayo de disponibilidad no alcanzó lo pactado y se repite | 2026-09-25 |
| PRY-210-R1 | Riesgo | Cambio en la licencia ambiental que puede mover el alcance | 2026-10-14 |
| PRY-210-D1 | Dependencia (reclasificada) | El proveedor no ha confirmado la fecha de la última entrega | 2026-10-14 |
| PRY-210-I1 | Incidencia | El proveedor entregó los equipos en el campamento, pendientes de aceptación | 2026-10-14 |
| PRY-211-R1 | Riesgo | Concentración del conocimiento en una sola persona | 2026-10-15 |
| PRY-211-I1 | Incidencia | Se levantó un hallazgo en la auditoría de seguridad | 2026-10-15 |

### Lo que no sé
- **«Sin movimiento en dos períodos»:** no lo puedo evaluar. Hay un solo corte registrado (2026-10-17) y ningún historial del RAID. Por eso no marco ningún ítem como estancado.
- **Mitigaciones vencidas:** no hay mitigaciones registradas en ningún documento, así que no hay ninguna que pueda estar vencida.
- **Supuestos:** no hay ninguno registrado. No levanté supuestos sin que nadie los dijera. En un portafolio con proveedores sin fecha confirmada y licencias en cambio, suelen existir; conviene preguntarlo a los gerentes.
- **Redacción repetida:** varios ítems tienen idéntica redacción en proyectos distintos. «Hallazgo en la auditoría de seguridad» está en 6 proyectos, el ensayo de disponibilidad en 4 y la rotación de ingeniero en 3. Puede ser lo mismo contado varias veces o plantilla. No lo verifiqué.
- **Proveedores:** cinco proyectos (201, 203, 204, 205, 210) hablan de «el proveedor». Las fichas no identifican si es el mismo, así que no puedo decir si hay una exposición común.
- **Proyectos con fin de plan vencido:** PRY-204 (2026-05-10), PRY-205 (2026-03-19), PRY-208 (2026-08-31) y PRY-209 (2026-08-29) siguen reportando ítems abiertos después de su fecha de fin. No lo valoré aquí; lo señalo porque afecta cómo se leen sus ítems.
- **Lectura de las actas:** busqué riesgos dichos al pasar con una búsqueda por frases en el texto de las actas, no las leí una por una. Un riesgo dicho sin ninguna de esas palabras se me puede haber escapado.

Pie de rigor: esto es un borrador de trabajo, no una decisión. Cada ítem sale del documento citado en su ficha; verifíquelo contra el original antes de formalizarlo. No sé lo que se habló fuera de esos documentos.

Para escalar al comité: PRY-205 (I1, I2, D1), PRY-210 (I1, D1), PRY-200 (I1) y PRY-201 (R2, D1) son los que propongo llevar: estando sin doliente no hay a quién exigirle respuesta, y no puedo comprobar el resto de criterios de escalamiento. Puedo preparar esos ítems con la decisión formulada. También puedo proponer doliente para los 39 ítems, como propuesta y sin asignarlo, si lo pide.
