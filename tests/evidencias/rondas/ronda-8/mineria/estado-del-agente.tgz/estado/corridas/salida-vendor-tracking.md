**Sale de:** contrato CT-235 (`00-gobierno/2026-05-24-contrato-ct-235.docx`), factura FV-1235 (`20-seguimiento/2026-10-01-factura-ct-235.pdf`), informe de avance (`20-seguimiento/2026-10-13-informe-avance.md`), comité (`30-reuniones/2026-10-14-comite-semanal.docx`), cronograma v1 y acta de constitución, más la salida de `portafolio.py compute` al 2026-10-17. Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17).

## Proveedores — PRY-203 Despacho automático de flota al 2026-10-17

### Montajes Industriales Ltda. — contrato CT-235
**Vigencia:** el contrato se firmó el 2026-05-24; no declara fecha de inicio ni de fin · **Preaviso de no renovación:** no declarado · **Vence el:** no declarado (el último entregable vence el 2026-12-12)

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento del software (35.834.032 COP) | 2026-09-10 | `pending`, vencido hace 37 días | Ninguna: no hay acta de recibo | Ver abajo |
| Bolsa de horas de ingeniería (35.834.032 COP) | 2026-12-12 | `pending`, aún no vence | Ninguna | Ver abajo |

Entregables aceptados: 0 de 2. Facturado: 35.834.032 COP (FV-1235, 2026-10-01, radicada en cuentas por pagar). El monto aceptado es 0.

### Dónde no cuadra
| Qué | Dice el contrato | Dice la evidencia | Fuentes |
|---|---|---|---|
| Factura FV-1235 por 35.834.032 COP | "Cada entregable se factura contra acta de recibo firmada por el gerente del proyecto" | No hay acta de recibo en la carpeta. El contrato marca ambos entregables como pendientes. La factura dice "Entregables del contrato CT-235" y no nombra cuál. | CT-235; FV-1235 |
| Licenciamiento vencido | Comprometido para 2026-09-10 | Sin evidencia de entrega. El script marca `vendor_invoiced_without_delivery` y `vendor_deliverable_late` (37 días). | CT-235; `compute` |
| Equipos en el campamento | Los entregables de CT-235 son licenciamiento y bolsa de horas; ninguno es equipo | El informe dice que "el proveedor entregó los equipos en el campamento, pendientes de aceptación". No se sabe si esos equipos son de CT-235 ni si respaldan la factura. | CT-235; informe 2026-10-13 |
| Estado declarado | — | El informe declara **verde** (36%) sin mencionar la factura ni el licenciamiento vencido. El script lo marca `declared_vs_evidence`. | Informe 2026-10-13; `compute` |

### Sin evidencia de recibo
| Entregable | Marcado como | Desde |
|---|---|---|
| Licenciamiento del software | `pending` (contrato). La factura lo cobra, pero no lo prueba. | Vencido desde 2026-09-10 |
| Bolsa de horas de ingeniería | `pending` | Vence el 2026-12-12 |

Ningún entregable está declarado entregado o aceptado sin documento (`accepted_without_evidence` = 0). El problema es el inverso: hay una factura y ningún entregable aceptado.

### Compromisos del proveedor vencidos
Ninguno vencido. El comité del 2026-10-14 registra dos compromisos, ambos abiertos:
| Qué | Prometido en | Para | Días |
|---|---|---|---|
| Entregar el punto 7 (Carlos Peña) | Comité 2026-10-14 | 2026-10-28 | No vencido |
| Entregar el punto 35 (Camilo Beltrán) | Comité 2026-10-14 | 2026-11-03 | No vencido |

El acta no dice a qué organización pertenecen Carlos Peña y Camilo Beltrán, ni qué son los "puntos" 7 y 35. No los atribuyo al proveedor.

### Sin dato
- Vigencia, fecha de terminación, renovación automática y preaviso de CT-235: el contrato no los declara, así que no puedo decir si el preaviso vence antes del cierre del proyecto (2027-02-17).
- Qué entregable cubre la factura FV-1235 y si hay una orden de pago.
- Si los equipos entregados en el campamento pertenecen a CT-235.
- Monto total del contrato: no figura como cifra en el contrato; solo los dos montos por entregable.

### Después
La factura FV-1235 está radicada en cuentas por pagar contra un contrato que exige acta de recibo, y esa acta no existe en la carpeta. Recomiendo llevarlo al Comité de Tecnología del 2026-10-21 y pedir al gerente (Jorge Medina) el acta de recibo, o que se frene el pago hasta que exista.

*Pie de rigor: borrador de trabajo, no decisión ni asesoría. Cifras copiadas de `compute`; la verificación contra los originales es suya.*
