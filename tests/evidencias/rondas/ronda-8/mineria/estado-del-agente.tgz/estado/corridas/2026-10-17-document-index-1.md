# Corrida del 2026-10-17 · document-index

13 proyectos · 13 s · 52 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 15 |
| `declared_vs_evidence` | 7 |
| `commitment_overdue` | 6 |
| `variance_time` | 4 |
| `progress_vs_plan` | 4 |
| `variance_cost` | 3 |
| `rebaseline_unauthorized` | 3 |
| `commitment_undated` | 2 |
| `commitment_rescheduled` | 2 |
| `vendor_deliverable_late` | 2 |
| `vendor_invoiced_without_delivery` | 2 |
| `vendor_accepted_without_evidence` | 1 |
| `silent` | 1 |

72 documentos, ninguno por releer; 23 citas de PRY-201 no resuelven aunque los archivos existen en disco (posible diferencia de ruta o tilde, sin verificar). No se tocó ninguna ficha.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## Carpeta al 2026-10-17

**Documentos:** 72 · **Sin cambio:** 72 · **Hay que releer:** 0

### Cambió el contenido
Ninguno.

### Solo se reguardó
Ninguno. 0 documentos.

### Renombrado o movido
Ninguno.

### Ya no está
Ninguno.

### Citas que dejaron de resolver
23 citas de PRY-201, sobre 3 documentos. El índice las marca como fuente no encontrada.

| Proyecto | Campo | Documento citado |
|---|---|---|
| PRY-201 | identity.code, name, business_area, sponsor, manager, committee (6 campos) | 00-gobierno/2026-03-06-acta-constitucion.docx |
| PRY-201 | plan.start_date, scope_summary, exclusions; money.approved (4 campos) | 00-gobierno/2026-03-06-acta-constitucion.docx |
| PRY-201 | declared.status, declared.progress_pct; money.currency, committed, executed, projection (6 campos) | 20-seguimiento/2026-10-09-informe-avance.md |
| PRY-201 | plan.end_date; plan.milestones[0..2].name y .state (7 campos) | 10-plan/2026-10-09-cronograma-v2.xlsx |

Lo que se vio al revisar: los tres archivos existen en la carpeta de PRY-201 (`PRY-201-ampliación-de-la-relavera/…`) y no figuran como borrados ni renombrados. Es probable que la cita esté escrita sin el nombre de la carpeta del proyecto, o que la tilde de «ampliación» no coincida. Es una hipótesis: no la verifiqué ni toqué ninguna ficha.

### Formatos que no se pudieron leer
Ninguno reportado por el índice. Este comando no lee contenido.

### Qué sigue
No hay documentos por releer, así que no hace falta `/portfolio-scan`. Lo único abierto son las 23 citas de PRY-201; corregirlas es decisión de quien mantiene la ficha.
