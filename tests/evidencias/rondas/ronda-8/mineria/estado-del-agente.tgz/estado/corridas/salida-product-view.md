## Producto «trazabilidad» al 2026-10-17

**Fuente:** fichas del estado, recalculadas con `portafolio.py compute` (as_of 2026-10-17). Términos vigentes: v1.1, aceptados por José Francisco Ñáñez el 2026-10-17.

**«Trazabilidad» tiene un solo proyecto (PRY-208, Trazabilidad del mineral).** La vista por producto no aporta nada aquí, así que no armo sección de producto: se lee como un proyecto.

Lo que dice el cálculo de PRY-208, sin agregar nada:

- Alertas: 0. Días en silencio: 5. Replanificaciones: 0. Desviación contra la línea base original y la vigente: 0 días.
- Fecha comprometida: 2026-08-31 (es la del único proyecto, por tanto la del producto). Ya es anterior a la fecha de corte; el cálculo no la marca como atraso porque no hay línea base más tardía contra la cual medirla.
- Dinero (COP, las cuatro cifras presentes): aprobado 9.500.000.000; comprometido 7.472.735.712 (78,7 %); ejecutado 4.421.982.097 (46,5 %); proyección 9.004.783.007 (−5,2 % sobre el aprobado); disponible real 2.027.264.288.
- Lo declarado: verde, 90,0 % de avance, informe del 2026-10-12 (`PRY-208-trazabilidad-del-mineral/20-seguimiento/2026-10-12-informe-avance.pdf`).
- Dependencias: ninguna registrada. Por tanto, no hay dependencias internas que llevar al comité de producto.

**Lo que no sé / lo que el cero de alertas no prueba:**

- La ficha tiene 0 datos sustentados en evidencia: 2 de declaración y 16 sin marcar. El verde y el 90 % son lo que el gerente declara; el cálculo no encontró contra qué contrastarlos, y eso no es lo mismo que haberlos confirmado.
- 12 campos de identidad y plan tienen fuente del 2025-09-27 (13 meses, por encima del umbral de 12): código, nombre, área, producto, sponsor, gerente, comité, fechas, alcance, exclusiones y monto aprobado.
- Faltan `identity.authority` y `identity.phase`.
- No hay proveedores registrados en la ficha (`vendors` vacío): no hay entregables contractuales que contrastar.

### Proyectos sin producto declarado (hallazgo de gobierno del portafolio)

7 de los 13 proyectos no traen `identity.product`: PRY-201, PRY-202, PRY-205, PRY-206, PRY-209, PRY-210 y PRY-211. El cálculo no entrega el área dueña de estos proyectos, así que no la escribo; está en sus fichas. Consecuencia: nadie puede responder por el conjunto al que sirven. Además, PRY-199 declara el producto «PRD-299», que es un código y no un nombre como los demás; conviene confirmar si es el mismo esquema de nombres.

---
**Pie de rigor:** cifras copiadas de `compute`, sin recalcular a mano. Es un borrador de trabajo, no una decisión ni asesoría; cada dato debe verificarse contra la cita de su ficha. Los documentos se procesan en la infraestructura de la plataforma de IA.
