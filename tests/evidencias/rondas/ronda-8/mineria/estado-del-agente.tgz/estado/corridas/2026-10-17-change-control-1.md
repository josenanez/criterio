# Corrida del 2026-10-17 · change-control

13 proyectos · 45 s · 52 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 15 |
| `declared_vs_evidence` | 7 |
| `commitment_overdue` | 6 |
| `variance_time` | 4 |
| `progress_vs_plan` | 4 |
| `variance_cost` | 3 |
| `rebaseline_unauthorized` | 3 |
| `commitment_undated` | 2 |
| `commitment_rescheduled` | 2 |
| `vendor_deliverable_late` | 2 |
| `vendor_invoiced_without_delivery` | 2 |
| `vendor_accepted_without_evidence` | 1 |
| `silent` | 1 |

Solicitud de mover 30 días la salida a producción de PRY-203 (cierre 2027-02-17 a 2027-03-19), leída como cierre porque el cronograma no tiene hito de salida. Impacto en portafolio: 0 alcanzados, porque el acta declara cero dependencias; no se afirma que no existan. No sabe: quién pide, motivo, costo del mes, autoridad del gerente (no declarada, va a comité por defecto). Anomalía marcada: factura de 35.834.032 COP del entregable de licenciamiento, vencido y sin acta de recibo en la ficha.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

Sale de la ficha `estado/records/PRY-203.json` (corte del informe: 2026-10-13). Términos vigentes: v1.1, aceptados el 2026-10-17 por José Francisco Ñáñez.

## Solicitud de cambio — PRY-203 Despacho automático de flota — 2026-10-17

**Qué se pide:** mover la salida a producción 30 días. **Quién lo pide:** no consta en ningún documento. **Por qué:** no consta.

**Una precisión sobre la fecha.** El cronograma no tiene un hito llamado «salida a producción». El último hito es «Pruebas en operación» (2027-02-17), que coincide con el cierre del acta. El criterio de éxito del acta dice «en producción y medido». Leo la solicitud como mover ese cierre 30 días: **2027-02-17 → 2027-03-19**. Si lo que se mueve es otro hito, hay que decirlo.

**Línea base vigente:** v1, aprobada el 2026-05-30 (cierre 2027-02-17, 800.000.000 COP). Es la única. No hay cambios previos, ni replanificaciones, ni días sin autorizar que reconciliar.

### Impacto
| Dimensión | Hoy | Con el cambio | Diferencia |
|---|---|---|---|
| Alcance | Componentes 1, 2 y 3 (el acta no da más detalle) | Sin cambio declarado | Ninguna declarada |
| Tiempo | Cierre 2027-02-17 | Cierre 2027-03-19 | +30 días (+11,9 % sobre los 253 días de plan) |
| Costo | Aprobado 800.000.000 · comprometido 458.388.139 · ejecutado 180.007.183 · proyección 787.823.857 | **No declarado** | **No se puede calcular** |

**Quién absorbe cada dimensión sin impacto declarado.**
- **Costo.** El margen entre lo aprobado y la proyección es de 12.176.143 COP (1,5 %). Treinta días más de equipo de proyecto, y quizá de proveedor, tienen que salir de ahí o de una ampliación. Nadie dijo cuánto cuesta un mes. La solicitud, así como llegó, lo deja absorber a quien menos margen tiene. No pongo una cifra, porque ningún documento permite calcularla.
- **Alcance.** Si el cambio solo mueve fecha, nadie ajusta alcance. Pero el informe reporta un riesgo abierto: «cambio en la licencia ambiental que puede mover el alcance». Ese riesgo no tiene dueño.

### Efecto en el portafolio
| Proyecto afectado | Cómo | Gerente |
|---|---|---|
| Ninguno | El cálculo de impacto no alcanza a nadie, ni directa ni indirectamente | — |

Lo que significa y lo que no:
- El acta declara «Ninguna» dependencia. Ninguna otra ficha ni documento del portafolio menciona a PRY-203. Con lo declarado, nadie sale afectado, ni nadie queda sin poder sostener su fecha, ni hay dependencia sin confirmar.
- **Eso no prueba que no haya dependencias.** Prueba que ninguna se declaró. Un despacho automático de flota en una mina suele tocar comunicaciones, sistemas de planta y otros equipos. Con el portafolio actual (PRY-199 a PRY-211) conviene preguntar a Jorge Medina si PRY-206 (red LTE en mina) o PRY-207 (gemelo digital) alimentan o consumen este proyecto. No lo afirmo: no hay documento que lo diga.
- El cálculo tampoco dice cuántos días se mueve cada hito intermedio. Eso necesita holgura por actividad, y la ficha no la tiene. Los hitos por los que pasa el cambio son tres: Licencia y permisos (2026-11-08, en 22 días), Montaje e instalación (2026-12-28, en 72 días) y Pruebas en operación (2027-02-17, en 123 días). **No digo que todos se muevan 30 días.**

### Quién decide
**Autoridad requerida:** no se puede determinar. El campo de autoridad está sin declarar: el acta no dice qué tolerancia de tiempo o de costo tiene el gerente, ni a partir de cuánto hay que subir. Este es el hallazgo de fondo.
**Según:** lo único que consta es que el **Comité de Tecnología** aprobó el presupuesto y el acta (2026-05-30), y que el patrocinador es Javier Hoyos. De ahí se deduce que quien aprobó la línea base es quien debería aprobar su cambio. Es una deducción, no una cláusula.
**Va a comité:** **sí, por defecto.** Sin autoridad declarada, el gerente no tiene respaldo documental para aprobarlo solo, y un movimiento de 30 días sobre una línea base única cambia el compromiso que aprobó el comité. El próximo comité semanal está fijado para 2026-10-21.

### Si no se aprueba
El proyecto sigue con cierre 2027-02-17 y se reporta verde (36 % de avance a 2026-10-13). Sin embargo:
- Hay tres hitos pendientes en 123 días y un permiso ambiental que el informe dice recibido, mientras el hito «Licencia y permisos obtenidos» sigue «en curso» con fecha 2026-11-08.
- Hay un hallazgo abierto en la auditoría de seguridad, sin dueño ni fecha.
- Los equipos están en el campamento sin acta de aceptación.
- El entregable «Licenciamiento del software» venció el 2026-09-10 y sigue pendiente. Aun así, el 2026-10-01 se facturaron 35.834.032 COP, que es el monto exacto de ese entregable. El contrato exige acta de recibo firmada por el gerente, y la ficha no tiene evidencia de ella. Pregunta para revisar antes del comité: **¿qué se pagó y contra qué acta?**

Quien pide el cambio debería decir cuál de estos hechos lo motiva. Si es la ventana de parada de planta (riesgo sin dueño), el cambio responde a una restricción externa. Si es atraso, el estado verde está mal y el cambio es una replanificación que hay que reportar como tal.

### Si se aprueba
**Línea base 2** — cierre 2027-03-19 · presupuesto: **sin definir** (hoy 800.000.000 COP; falta el costo de los 30 días) · motivo: **sin motivo documentado**; hay que escribirlo.
La v1 no se toca. Desde ahí el conteo de replanificaciones sube a 1 y toda desviación se reporta contra dos referencias. Hay que dejar el documento que aprobó la v2 (acta del comité) y su fecha.
**Desviación acumulada contra la línea base original:** tiempo **+30 días** (cierre 2027-03-19 contra 2027-02-17) · costo **sin cálculo** (hoy, la proyección está 1,5 % por debajo de lo aprobado, y ese margen no cubre un mes sin decir cuánto es).

### Lo que esta solicitud no sabe
- Quién la pide y por qué.
- Cuánto cuesta un mes más.
- Si hay dependencias que nadie declaró.
- Cuál es la autoridad del gerente.
- Cuál es la ventana de parada de planta y si el cambio la respeta.
- Si el contrato CT-235 con Montajes Industriales tiene vigencia que se cruce con la nueva fecha: el documento no trae vencimiento.

### Después
Llevar el paquete al comité del 2026-10-21 con la pregunta cerrada: *¿aprueba mover el cierre de PRY-203 a 2027-03-19, con qué presupuesto adicional, si lo hay?* Antes, pedir a Jorge Medina el motivo, el costo del mes y las dependencias. Cuando el comité apruebe, se registra la línea base 2 con el acta que la aprobó.

*Pie de rigor: borrador de trabajo, no una decisión ni una asesoría. Cada dato sale de la ficha PRY-203.json y de los documentos citados en ella (acta de constitución 2026-05-30, cronograma v1, contrato CT-235, informe de avance 2026-10-13, comité 2026-10-14). La verificación es de quien decide.*
