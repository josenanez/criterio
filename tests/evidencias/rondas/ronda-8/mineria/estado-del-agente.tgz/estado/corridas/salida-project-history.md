## Historia · PRY-200 Mantenimiento predictivo de camiones · 2025-12-27 a 2026-10-12

**Leí:** 6 documentos entre 2025-12-27 y 2026-10-12 (4 en Markdown: acta, informe de avance, solicitud de cambio CC-01, comité; 2 cronogramas .xlsx: v1 y v2)
**Trimestres sin un solo documento:** 2026-T1, 2026-T2 y 2026-T3 (de enero a septiembre de 2026 no hay ningún documento fechado). Todo lo demás está en 2025-12-27 y entre 2026-10-05 y 2026-10-12.

*Términos: vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17); no hizo falta registrar una aceptación nueva.*

### En una línea
El proyecto se aprobó el 2025-12-27 con cierre el 2027-04-11 y 800.000.000 COP. Durante nueve meses no dejó ningún documento. En octubre de 2026 aparecen de golpe cuatro: un cronograma v2 (2026-10-09) que ya mueve el cierre al 2027-07-24, un informe de avance en rojo con 36%, un comité (2026-10-05) donde no consta ninguna decisión sobre fechas, y una solicitud de cambio CC-01 (2026-10-12) que sigue pendiente de presentarse al comité. La fecha ya se movió; la autorización no existe en los documentos.

### Las cuatro cifras
| Replanificaciones | Atraso acumulado vs. original | Meses declarando sin sustento | Cambios de gobierno |
|---|---|---|---|
| 1 | 104 días (22.6%) | No calculable: hay una sola declaración de estado (2026-10-09), no una serie | 0 visibles |

Cifras copiadas de `portafolio.py compute` (as_of 2026-10-17). Atraso contra la línea vigente: 0 días, porque la vigente ya absorbió el movimiento.

### Línea de tiempo
| Fecha | Documento | Qué cambió |
|---|---|---|
| 2025-12-27 | `00-gobierno/2025-12-27-acta-constitucion.md` | Se aprueba el proyecto: 800.000.000 COP por el Comité de Inversiones; inicio 2026-01-06, cierre 2027-04-11. Patrocinador Ricardo Salas, gerente Rubén Cárdenas. Alcance escrito como "Componente 1/2/3". |
| 2025-12-27 | `10-plan/2025-12-27-cronograma-v1.xlsx` | Línea base: 4 hitos (ing. básica 2026-05-01, ing. de detalle 2026-08-24, licencias 2026-12-17, montaje 2027-04-11). Ver nota sobre la columna "estado". |
| 2026-10-05 | `30-reuniones/2026-10-05-comite-semanal.md` | Comité con Rubén Cárdenas y Ricardo Salas. Temas: "Avance" y "Compromisos". Un compromiso: Paula Céspedes, "Entregar el punto 8", para 2026-11-09. No consta decisión sobre fechas, costo ni alcance. |
| 2026-10-09 | `10-plan/2026-10-09-cronograma-v2.xlsx` | Cambia una sola fecha: "Montaje e instalación" pasa de 2027-04-11 a 2027-07-24 (+104 días). La fecha de línea base sigue en 2027-04-11. |
| 2026-10-09 | `20-seguimiento/2026-10-09-informe-avance.md` | Estado declarado: Rojo, 36%. Proyección al cierre 883.635.954 COP contra 800.000.000 aprobados. Menciona lluvias que detuvieron el montaje diez días y una actualización del presupuesto con compras. |
| 2026-10-12 | `20-seguimiento/2026-10-12-solicitud-cambio-cc-01.md` | Pide ampliación de alcance: +104 días "sobre la línea base vigente" y +208.000.000 COP. Autorización: "Pendiente de presentación al comité". |

**Nota sobre el cronograma v1:** el archivo está fechado 2025-12-27, pero marca como "cerrado" dos hitos que vencían el 2026-05-01 y el 2026-08-24. O el archivo se editó después de su fecha de nombre, o el estado de esas filas se escribió sin que el hecho hubiera ocurrido. Con los documentos no se puede distinguir cuál.

### Replanificaciones
| Nº | Fecha | Fecha de cierre nueva | Motivo declarado | Documento que la aprobó |
|---|---|---|---|---|
| 1 | 2026-10-09 (cronograma v2) | 2027-07-24 (montaje e instalación; antes 2027-04-11) | **Sin motivo documentado.** El informe del mismo día cita lluvias por diez días y una actualización de presupuesto; ninguno explica 104 días y el informe no los vincula con el cambio de fecha. | **Ninguno.** El comité del 2026-10-05 no la registra; CC-01 (2026-10-12) está pendiente de autorización. El script la marca como `rebaseline_unauthorized`: 104 días movidos, 0 autorizados. |

Un punto que los documentos no resuelven: CC-01 pide +104 días "sobre la línea base vigente", y la v2 ya movió exactamente 104 días. No se sabe si CC-01 formaliza ese mismo movimiento o pide 104 días adicionales sobre el nuevo cierre. Tampoco se sabe si los 208.000.000 COP están dentro de la proyección de 883.635.954 (la proyección no parece incluirlos, pero el informe no lo dice).

### Gobierno
| Fecha | Qué cambió | Documento |
|---|---|---|
| — | Sin cambios de patrocinador, gerente ni comité en los documentos. Ricardo Salas y Rubén Cárdenas figuran en el acta (2025-12-27) y en el comité (2026-10-05). | Acta; comité |

Faltan en la ficha `identity.authority` e `identity.phase`. Con solo cuatro documentos de texto y nueve meses de silencio, no se puede afirmar que no hubo cambios, solo que no hay rastro de ellos.

### Compromisos que se repitieron
| Doliente | Qué | Veces | Fechas prometidas |
|---|---|---|---|
| — | Ninguno se repite: hay un único comité. | — | — |

Un compromiso vigente, no vencido: Paula Céspedes, "Entregar el punto 8", para 2026-11-09. Ningún documento define qué es "el punto 8", y ella no figura entre los asistentes del comité.

### Desde cuándo lo declarado no se sostiene
- **Fecha:** el primer hito marcado como cumplido sin evidencia venció el **2026-05-01** ("Ingeniería básica aprobada"; 169 días al 2026-10-17). El segundo, "Ingeniería de detalle aprobada", venció el **2026-08-24** (54 días). Ninguno tiene acta de aprobación ni otro documento que lo respalde en la carpeta.
- **Qué se siguió reportando:** en el informe del 2026-10-09 el avance es 36%. Los hitos cumplidos (2 de 4) sustentan entre 50% y 75% según el plan, así que hay una diferencia de 14.0 puntos, en la dirección contraria a la esperada: el avance declarado es menor que lo que el plan implicaría. Es decir, el informe no infla el avance; lo que no se sostiene es que los dos hitos de ingeniería estén cerrados.
- **Lo que el informe sí dice y lo que no:** declara Rojo, que es coherente con los 104 días de atraso y la proyección sobre el presupuesto (10.5% por encima de lo aprobado). Pero no da cuenta de cinco señales que el script detecta: atraso de tiempo, desviación de costo, avance contra plan, hitos sin evidencia y replanificación sin autorizar.
- **Qué no se puede decir:** el "deslizamiento" que pide este análisis necesita una serie de estados declarados. Hay una sola declaración (2026-10-09) y ningún documento entre enero y septiembre de 2026, así que no se puede fechar cuándo empezó a no sostenerse más allá del 2026-05-01, y no se puede decir si antes del informe de octubre se reportó algo distinto.

### Lecciones ancladas a un hecho
1. **Un cambio de fecha sin acto de aprobación.** Hecho: el cronograma v2 del 2026-10-09 mueve el montaje 104 días y CC-01 del 2026-10-12 sigue "pendiente de presentación al comité". Efecto: el plan vigente ya tiene un cierre que nadie con autoridad ha aprobado, y la línea base original quedó como única referencia para medir el atraso (22.6%).
2. **Hitos cerrados sin soporte.** Hecho: dos hitos de ingeniería (vencimientos 2026-05-01 y 2026-08-24) figuran como cerrados y la carpeta no contiene ningún documento de aprobación. Efecto: no se puede verificar el 36% declarado, ni 2 de 4 hitos cumplidos.
3. **Nueve meses sin documentos.** Hecho: ningún documento fechado entre 2025-12-27 y 2026-10-05. Efecto: el período donde ocurrieron las ingenierías, y donde se originó el atraso, no se puede reconstruir desde la carpeta.

### Lo que esta historia no dice
No dice por qué se movió la fecha ni quién lo decidió. Que la v2 precediera a la solicitud de cambio puede ser un orden de trámite o puede ser otra cosa: los documentos no lo indican, y esa conversación es de personas, con los datos de arriba.

**Pie de rigor:** 6 documentos leídos completos; cifras copiadas de `portafolio.py compute` (2026-10-17). Sin atribución de intención. Lo que no está en los documentos se declaró como no sabido.

**Siguiente paso posible:** llevar esta historia al comité del 2026-10-21 para que decida sobre CC-01, o al cierre del proyecto cuando corresponda.
