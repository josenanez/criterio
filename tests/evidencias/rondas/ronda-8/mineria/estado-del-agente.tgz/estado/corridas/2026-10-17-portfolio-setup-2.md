# Corrida del 2026-10-17 · portfolio-setup

3 proyectos · 72 documentos, 46 releídos y 26 sin cambio · 25 hallazgos

> El tiempo no se midió: faltó `corrida-inicio` al arrancar. Un tiempo escrito a mano es un recuerdo, no una medición.

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 6 |
| `commitment_overdue` | 6 |
| `declared_vs_evidence` | 3 |
| `variance_time` | 2 |
| `commitment_undated` | 2 |
| `commitment_rescheduled` | 2 |
| `rebaseline_unauthorized` | 2 |
| `vendor_accepted_without_evidence` | 1 |
| `progress_vs_plan` | 1 |

0 preguntas (sesión sin interfaz, respuestas sugeridas); primer resultado en una sola sesión; 3 proyectos (PRY-204, PRY-201, PRY-206) con 25 señales, los tres en verde contradicho por la evidencia. Segundo registro: corrige 14 a 15 señales en PRY-201 en la salida

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## Listo — Portafolio de proyectos mineros

**Miré:** 72 documentos en 13 carpetas de proyecto (PRY-199 a PRY-211) · formatos: md 31, docx 14, pdf 11, xlsx 8, csv 6, json 1, txt 1 · más reciente: 2026-10-17
**Eres:** PMO del portafolio (propuesto por haber varios proyectos)
**Te aviso:** dos días antes del comité; propuse comité semanal con el próximo el 2026-10-21, porque los documentos traen actas de «comité-semanal». Fecha y cadencia son supuestos míos: corrígelos si no son así.
**En:** presentación
**Dónde guardo lo que voy encontrando:** `estado/` (fichas) y `reportes/` (informes), junto a la carpeta de documentos
**Términos:** aceptados por José Francisco Ñáñez para la versión 0.3.13 (términos 1.1), 2026-10-17 · comprobante en `.criterio/terminos/aceptacion-criterio-portfolio-0.3.13-2026-10-17.md` y `.pdf` · SHA-256 6d4b67767ea3a1ea…

Preguntas hechas: 0. Sesión sin interfaz; tomé la respuesta sugerida en cada punto.

### Probé con tres proyectos

Los tres con la documentación más reciente: PRY-204, PRY-201 y PRY-206. Sus fichas quedaron en `estado/records/`, selladas. Lo de abajo sale del cálculo (`compute`), con 25 señales en total. Los tres declaran verde y en los tres hay señales que ese verde no explica.

| Proyecto | Documentos | Qué supe | Qué no está |
|---|---|---|---|
| PRY-204 Monitoreo de taludes | 5 | Gerente Beatriz Cuéllar, patrocinador Jorge Medina, Comité de Seguridad. Presupuesto 800.000.000 COP, ejecutado 361.778.067 (45,2%). Declara verde y 45% al 2026-10-17. Cierre del acta 2026-03-31; cronograma v2 2026-05-10. | Autoridad del gerente, fase, actas de recibo de los tres hitos, proveedor y contrato. |
| PRY-201 Ampliación de la relavera | 17 | Gerente Mauricio Pérez, patrocinador María Restrepo, Comité de Operaciones. Presupuesto 4.200.000.000 COP, ejecutado 1.393.552.576 (33,2%). Declara verde y 29% al 2026-10-09. Cierre del acta 2027-02-03; cronograma v2 2027-05-10. 26 compromisos tomados de 6 comités y de las notas del 2026-10-17. Trae `ficha-pm.json` del gerente, que dejé aparte en `pm_record`. | Autoridad, fase, producto, nombre y contrato del proveedor, lo facturado, acta de recibo de la ingeniería básica. |
| PRY-206 Red privada LTE en mina | 4 | Gerente Sandra Gil, patrocinadora Beatriz Cuéllar, Comité Ambiental. Presupuesto 6.800.000.000 COP, ejecutado 3.563.413.906 (52,4%), proyección 4,2% sobre lo aprobado. Declara verde y 68% al 2026-10-16. Cierre 2027-01-24. | Autoridad, fase, producto, actas de recibo de las dos ingenierías, proveedor. |

### Hallazgos (todos levantados por `compute`)

**PRY-204 · 7 señales**
- `declared_vs_evidence`: declara verde, pero lo contradicen `milestone_met_without_evidence`, `progress_vs_plan`, `rebaseline_unauthorized` y `variance_time`.
- `progress_vs_plan`: declara 45% con los tres hitos del cronograma cerrados, que el plan sostiene como 100%. Diferencia: 55 puntos.
- `milestone_met_without_evidence`: los tres hitos (ingeniería básica, ingeniería de detalle, licencia y permisos) figuran cerrados en `2026-10-17-cronograma-v2.csv` sin ningún acta que lo pruebe.
- `variance_time` y `rebaseline_unauthorized`: el cierre corrió 40 días contra el acta (18,7%). La solicitud CC-01 (+40 días, +80.000.000 COP) sigue «pendiente de presentación al comité», así que el movimiento no tiene autorización.

**PRY-201 · 15 señales**
- `declared_vs_evidence`: declara verde con cinco señales que lo contradicen.
- `variance_time` y `rebaseline_unauthorized`: +96 días contra el acta (29,6%) y 0 autorizados. CC-01 (+96 días, +192.000.000 COP) está pendiente.
- `milestone_met_without_evidence`: ingeniería básica, cerrada desde 2026-07-02 y sin acta, hace 107 días.
- `commitment_overdue`: 6 vencidos sin evidencia. El más viejo es «Actualizar la matriz 6» de Mauricio Pérez, 32 días vencido, en el comité del 2026-09-12.
- `commitment_rescheduled`: «Enviar el documento 1» (Paula Céspedes) se reprogramó 6 veces, de 2026-09-14 a 2026-11-26. «Cerrar la prueba 2» (María Restrepo) se reprogramó 5 veces, de 2026-09-12 a 2026-11-28.
- `commitment_undated`: «Revisar el anexo 11» (María Restrepo) y «Mandar el ajuste del presupuesto» (Laura Vélez). Sobre el anexo 11, el comité del 2026-10-03 registra que ella dice haberlo entregado y que no se presentó acta.
- `vendor_accepted_without_evidence`: los equipos en el campamento figuran entregados, sin acta de aceptación y sin proveedor nombrado.
- Del 2026-10-17: una revisión con el proveedor para el 2026-10-27 (Óscar Ramírez) y un riesgo dicho en la reunión que nadie registró (el proveedor podría no llegar con el equipo completo a la siguiente fase). Está en la ficha como riesgo con su cita a las notas.

**PRY-206 · 3 señales**
- `milestone_met_without_evidence`: ingeniería básica (202 días) e ingeniería de detalle (51 días), cerradas sin acta.
- `declared_vs_evidence`: declara verde y la única señal que lo contradice es la anterior.
- Sin desviación de plazo contra el acta: la proyección de costo está 4,2% sobre lo aprobado, por debajo del umbral de 10%.

Los tres tienen 0 documentos de evidencia con marca: lo que hay son declaraciones y documentos de gobierno. Ninguno tiene definida la autoridad del gerente.

### El portafolio completo
10 proyectos más (PRY-199, 200, 202, 203, 205, 207, 208, 209, 210, 211) · 46 documentos · un solo lote, uno tras otro. Estimo unos 30 a 40 minutos con `workers: 1`. Es una estimación por lo que tardaron estos tres, no una medición.

### Lo que le falta a tu carpeta
- **Actas de recibo:** en PRY-204 y PRY-206 no hay ninguna, y es lo que deja los hitos cerrados sin prueba. Solo PRY-201 tiene cuatro, y son de compromisos, no de hitos.
- **Autoridad del gerente:** no aparece en ninguna de las tres actas. Sin ella no se puede decir si un cambio excede lo que el gerente decide solo.
- **Alcance:** las actas lo describen como «Componente 1, 2 y 3», sin más detalle. Cualquier cambio de alcance se queda sin contra qué medirlo.
- **Producto:** PRY-201 y PRY-206 dicen «No aplica». Solo PRY-204 sirve a un producto («alerta de taludes»).
- **Reuniones:** PRY-204 no tiene carpeta de reuniones. Las notas del 2026-10-17 de PRY-201 están sueltas en la raíz del proyecto, no en `30-reuniones`.
- **Proyectos con solo acta e informe, sin cronograma ni reuniones:** PRY-205, PRY-208 y PRY-209. Ahí el análisis de plazos será corto.
- **Ninguno es bloqueante.**
