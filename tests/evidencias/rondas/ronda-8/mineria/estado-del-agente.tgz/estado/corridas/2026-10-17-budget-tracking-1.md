# Corrida del 2026-10-17 · budget-tracking

13 proyectos · 33 s · 52 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 15 |
| `declared_vs_evidence` | 7 |
| `commitment_overdue` | 6 |
| `variance_time` | 4 |
| `progress_vs_plan` | 4 |
| `variance_cost` | 3 |
| `rebaseline_unauthorized` | 3 |
| `commitment_undated` | 2 |
| `commitment_rescheduled` | 2 |
| `vendor_deliverable_late` | 2 |
| `vendor_invoiced_without_delivery` | 2 |
| `vendor_accepted_without_evidence` | 1 |
| `silent` | 1 |

Informe de presupuesto de PRY-200: proyección 10.5 % sobre el aprobado, comprometido 78.0 % (sin alerta), ejecución 20.5 % frente a avance declarado 36 %. Dijo que no sabe: si la proyección incluye CC-01, quién es la autoridad, el motivo de la replanificación y el desglose por proveedor.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

Presupuesto de PRY-200 (Mantenimiento predictivo de camiones), calculado el 2026-10-17 con `portafolio.py compute`. Sale de la ficha `estado/records/PRY-200.json`, que se construyó con 6 documentos de la carpeta del proyecto; el más reciente es la solicitud de cambio CC-01, del 2026-10-12. Términos vigentes: aceptados por José Francisco Ñáñez (versión 0.3.13, 2026-10-17).

## Presupuesto — PRY-200 al 2026-10-17
**Moneda:** COP (única; no hay contratos en otra moneda ni conversión)

| | Monto (COP) | % del aprobado | Fuente | Fecha |
|---|---|---|---|---|
| Aprobado | 800.000.000 | 100 % | 00-gobierno/2025-12-27-acta-constitucion.md | 2025-12-27 |
| Comprometido | 624.011.195 | 78.0 % | 20-seguimiento/2026-10-09-informe-avance.md | 2026-10-09 |
| Ejecutado | 163.775.869 | 20.5 % | 20-seguimiento/2026-10-09-informe-avance.md | 2026-10-09 |
| Proyección al cierre | 883.635.954 | excede el aprobado en 10.5 % | 20-seguimiento/2026-10-09-informe-avance.md | 2026-10-09 |

**Disponible real** (aprobado menos comprometido): 175.988.805 COP

Las tres cifras que no son el aprobado salen de un informe de avance, o sea de una declaración. Ninguna tiene respaldo en un documento de evidencia (contrato, factura, extracto).

### Contra la línea base
| | Original | Vigente | Desviación |
|---|---|---|---|
| Presupuesto aprobado | 800.000.000 | 800.000.000 | sin cambio aprobado |
| Fecha de fin | 2027-04-11 | 2027-07-24 | 104 días (22.6 %) |

Replanificaciones de presupuesto aprobadas: 0. Hay una solicitud pendiente, CC-01 (2026-10-12): ampliación de alcance, 208.000.000 COP adicionales y +104 días. No tiene decisión ni decisor (`decision: pending`).

Aparte del presupuesto: el cronograma v2 (2026-10-09) movió el fin 104 días sin que ningún cambio aprobado lo autorice (`rebaseline_unauthorized`, 104 días movidos, 0 autorizados). El motivo de esa replanificación figura como `not_found`.

### Ejecución frente a avance
Ejecutado 20.5 % · Hitos cumplidos 2 de 4 · Avance declarado 36 %; el plan sustenta entre 50 y 75 %, o sea 14.0 puntos de atraso.
Lectura: la ejecución no va por encima del avance, que es la señal de sobrecosto. Va por debajo del avance declarado y del que sustenta el plan, y eso puede ser trabajo hecho y no facturado, o trabajo no hecho. Los datos no permiten distinguirlos. Los dos hitos que figuran cumplidos (Ingeniería básica, vencida el 2026-05-01 hace 169 días; Ingeniería de detalle, vencida el 2026-08-24 hace 54 días) no tienen evidencia de aceptación, así que ese «2 de 4» tampoco está sustentado.

### Alertas
- **Proyección por encima del aprobado:** 883.635.954 COP frente a 800.000.000, un 10.5 % sobre el aprobado (umbral 10 %). Supera el umbral por poco.
- **Proyección anterior a CC-01:** la proyección es del 2026-10-09 y CC-01 es del 2026-10-12. CC-01 pide 208.000.000 COP adicionales y está pendiente. No puedo decir si la proyección ya lo incluye; el informe no lo dice. Si es una cifra anterior a CC-01, queda vieja frente al último movimiento de presupuesto.
- **Comprometido:** 78.0 %, por debajo del umbral de 90 %. Sin alerta. El disponible real es 175.988.805 COP.
- **Ejecución desalineada del avance:** ver la sección anterior. Avance declarado 36 % contra 50–75 % que sustenta el plan.
- El estado declarado es rojo, pero el informe no explica 5 de las señales abiertas: variación de tiempo, variación de costo, avance contra plan, hitos cumplidos sin evidencia y replanificación no autorizada.

### Sin dato
- Autoridad que aprueba el presupuesto (`identity.authority`: `not_found`); sin ella no se sabe quién decide CC-01.
- Fase del proyecto (`identity.phase`: `not_found`).
- Motivo de la replanificación v2 del cronograma.
- Fecha de corte exacta del comprometido y del ejecutado: se conoce la del documento (2026-10-09), no la del cierre contable.
- Desglose por proveedor: la ficha no registra ningún proveedor ni contrato.
- Línea base de presupuesto separada de la del cronograma: no existe ninguna aprobada distinta de los 800.000.000 del acta.

Siguiente paso posible: evaluar CC-01 con `/criterio-portfolio:change-control` (costo, tiempo y alcance, y qué línea base queda si se aprueba). La proyección ya excede el aprobado, pero CC-01 ya está presentada, así que no hay una solicitud nueva que preparar.
