# Corrida del 2026-10-17 · project-charter

13 proyectos · 27 s · 52 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 15 |
| `declared_vs_evidence` | 7 |
| `commitment_overdue` | 6 |
| `variance_time` | 4 |
| `progress_vs_plan` | 4 |
| `variance_cost` | 3 |
| `rebaseline_unauthorized` | 3 |
| `commitment_undated` | 2 |
| `commitment_rescheduled` | 2 |
| `vendor_deliverable_late` | 2 |
| `vendor_invoiced_without_delivery` | 2 |
| `vendor_accepted_without_evidence` | 1 |
| `silent` | 1 |

Revisión del acta de PRY-208 (2025-09-27). Faltan autoridad del gerente, objetivo medible, supuestos, hitos y cadencia; exclusiones y alcance vacíos. Señalé cierre vencido (2026-08-31) con estado verde al 2026-10-12 y avance 90% frente a 46,5% ejecutado. No sé si hay autoridad definida fuera de la carpeta ni si el cierre se movió en otro documento.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

Acta previa: sí, existe — `PRY-208-trazabilidad-del-mineral/00-gobierno/2025-09-27-acta-constitucion.md`, del 2025-09-27 (aprobada por el Comité de Seguridad). Modo: revisar. Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17).

## Acta — PRY-208 · Trazabilidad del mineral
**Estado:** existe, del 2025-09-27

### Qué falta
| Campo | Estado | Consecuencia |
|---|---|---|
| Autoridad del gerente (monto y cambios de alcance sin comité) | **No está** en el acta ni en otro documento de la carpeta | Cualquier cambio de monto o alcance, por pequeño que sea, no tiene un umbral que diga si lo decide Laura Vélez o el Comité de Seguridad. Todo sube al comité por defecto, o se decide sin autoridad escrita. Ya hay un caso: el informe del 2026-10-12 dice que se reprogramó la parada de planta y no hay registro de quién lo aprobó. |
| Objetivo de negocio | Presente pero no medible: "Entregar trazabilidad del mineral para Tecnología" | Es la solución, no el resultado de negocio. Nadie puede decir qué problema se resuelve ni cuánto mejora. El cierre no tiene contra qué compararse. |
| Alcance | "Componente 1, 2, 3" sin descripción | No se puede saber qué entra y qué no. Cualquier solicitud de cambio se puede argumentar a favor o en contra con igual fuerza. |
| Exclusiones | "Lo que otro proyecto cubre", sin nombrar el proyecto | Declarada en forma, vacía en contenido. No dice qué otro proyecto ni qué cubre; el riesgo de que un entregable lo construyan dos proyectos, o ninguno, queda abierto. |
| Patrocinador con nombre | Cumple: Sandra Gil | — |
| Criterio de éxito medible y quién lo mide | "Trazabilidad del mineral en producción y medido": sin métrica, sin umbral, sin responsable de la medición | "Medido" sin decir por quién ni contra qué valor. El 90 % de avance reportado no se puede contrastar con ningún criterio de aceptación. |
| Supuestos y restricciones | No hay sección | La ventana de parada de planta (definida por operaciones) y el acceso a la mina aparecen como riesgos en el informe de avance, pero nunca se declararon como supuesto o restricción en el acta. |
| Dependencias | "Ninguna declarada" | La parada de planta depende de operaciones, según el informe. El acta dice que no hay dependencias; las dos afirmaciones no se sostienen a la vez. |
| Hitos principales | No hay | No existe cronograma en la carpeta (la línea base v1 solo tiene fecha de cierre). No hay forma de medir desviación por hito. |
| Cadencia de reporte al comité | No está | No se sabe cada cuánto debe rendir cuentas el proyecto al Comité de Seguridad. |

### Contenido
**Objetivo de negocio:** pendiente de definir. El acta dice "Entregar trazabilidad del mineral para Tecnología" (acta, §Objetivo del negocio); no es medible.
**Alcance:** "Componente 1, Componente 2, Componente 3" (acta, §Alcance). Sin detalle: pendiente de definir.
**Exclusiones:** "Lo que otro proyecto cubre" (acta, §Fuera de alcance). No nombra el proyecto: pendiente de definir.
**Patrocinador:** Sandra Gil · **Gerente:** Laura Vélez (acta, encabezado)
**Autoridad del gerente:** pendiente de definir. No hay fuente.
**Comité al que reporta:** Comité de Seguridad (acta) · **Cadencia:** pendiente de definir.
**Supuestos:** pendiente de definir · **Restricciones:** pendiente de definir.
**Presupuesto aprobado:** 9.500.000.000 COP, por el Comité de Seguridad el 2025-09-27 (acta, §Presupuesto).
**Fechas comprometidas:** inicio 2025-10-07, cierre 2026-08-31 (acta, §Fechas comprometidas).
**Criterio de éxito:** "Trazabilidad del mineral en producción y medido" (acta). No es medible · **Lo mide:** pendiente de definir.
**Hitos principales:** pendiente de definir (no hay cronograma en la carpeta).

### Lo que la revisión del acta hizo ver en el informe de avance (2026-10-12)
- **Cierre comprometido vencido.** El acta fija el cierre el 2026-08-31; el informe del 2026-10-12 reporta 90 % y estado verde, 42 días después. No hay solicitud de cambio ni nueva línea base en la carpeta. Un proyecto vencido no debería figurar como verde sin una fecha vigente aprobada.
- **Avance frente a dinero.** Ejecutado 4.421.982.097 COP = 46,5 % del aprobado; comprometido 7.472.735.712 = 78,7 %. Un avance del 90 % no es consistente con 46,5 % ejecutado salvo que lo restante sea barato; el informe no lo explica. No lo juzgo: lo señalo.
- **Proyección al cierre** 9.004.783.007 COP (94,8 % del aprobado): dentro del presupuesto, pero sin una fecha de cierre vigente la proyección no tiene un horizonte.
- **Reprogramación sin rastro.** "Se reprogramó la parada de planta por la ventana de mantenimiento" no tiene documento de cambio, motivo ni aprobador.
- **Riesgos sin dueño.** Los dos riesgos abiertos del informe no tienen responsable.

### Lo que no sé
- Si hay una autoridad del gerente definida fuera de estos documentos (política de la organización, delegación del comité): no está en la carpeta.
- Si la fecha de cierre se movió en alguna reunión o correo: solo veo dos documentos.
- Qué es cada "Componente" ni qué proyecto cubre lo excluido.

### Después
- El acta quedó sin autoridad declarada: propongo llevar esa definición al Comité de Seguridad (próximo comité: 2026-10-21). Es una decisión del comité, no un trámite.
- De esta revisión salen supuestos (parada de planta definida por operaciones, acceso a la mina) y la dependencia con operaciones; propongo pasarlos al registro RAID con `/raid-log`.
- Propongo también abrir un control de cambios por el cierre vencido (`/change-control`).

Pie de rigor: borrador de trabajo basado solo en dos documentos (acta del 2025-09-27 e informe de avance del 2026-10-12). No sustituye la decisión del comité; la verificación contra las fuentes citadas es de quien lo lea.
