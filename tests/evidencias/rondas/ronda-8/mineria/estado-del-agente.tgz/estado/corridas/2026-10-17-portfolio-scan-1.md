# Corrida del 2026-10-17 · portfolio-scan

13 proyectos · 72 documentos, 0 releídos y 72 sin cambio · 186 s · 52 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 15 |
| `declared_vs_evidence` | 7 |
| `commitment_overdue` | 6 |
| `variance_time` | 4 |
| `progress_vs_plan` | 4 |
| `variance_cost` | 3 |
| `rebaseline_unauthorized` | 3 |
| `commitment_undated` | 2 |
| `commitment_rescheduled` | 2 |
| `vendor_deliverable_late` | 2 |
| `vendor_invoiced_without_delivery` | 2 |
| `vendor_accepted_without_evidence` | 1 |
| `silent` | 1 |

10 fichas nuevas (PRY-199, 200, 202, 203, 205, 207-211) leídas y selladas; PRY-201, 204 y 206 sin cambio. Nada movido: no existe entrada/. Nada ilegible. Mirar: PRY-200 línea base movida antes de autorizar el cambio; facturas sin acta en PRY-203 y PRY-211; PRY-205, 208 y 209 sin cronograma y con cierre vencido; 22 citas de PRY-201 en pm_record no resuelven.

Contra la corrida del 2026-10-17: +27 hallazgos.

## Lo que produjo

## Barrido — 2026-10-17

**Encontré:** una carpeta con 13 proyectos (PRY-199 a PRY-211) y 72 documentos: 31 .md, 14 .docx, 11 .pdf, 8 .xlsx, 6 .csv, 1 .json y 1 .txt. Los 72 se pudieron convertir a texto.

**Documentos:** 72 en la carpeta · 46 leídos · 26 sin cambio desde la corrida anterior · 0 ilegibles
**Proyectos:** 13 con ficha · 10 nuevos · 0 sin carpeta propia

**Plan de lectura:** 46 de 72, todos en un solo lote de 10 proyectos (`workers: 1`, sin subagentes). No quedó nada diferido. Los 26 documentos sin cambio son de PRY-201, PRY-204 y PRY-206, que ya tenían ficha sellada. No los releí.

**Términos:** ya estaban vigentes (v1.1, familia 0.3.13), aceptados por José Francisco Ñáñez el 2026-10-17. No hubo que registrar nada nuevo.

### Nuevos
| Proyecto | Documentos | Campos encontrados | Campos sin dato |
|---|---|---|---|
| PRY-199 Cambio de luminarias del campamento | 6 | identidad, plan con 5 hitos, dinero, 1 contrato (3 entregables), riesgos, 1 compromiso | autoridad, fase |
| PRY-200 Mantenimiento predictivo de camiones | 6 | identidad, 2 líneas base, 4 hitos, dinero, CC-01 pendiente, 1 compromiso | autoridad, fase, razón de la línea base v2 |
| PRY-202 Planta de tratamiento de agua | 5 | identidad, plan con 4 hitos, dinero, 1 compromiso | autoridad, fase, producto (el acta dice «No aplica») |
| PRY-203 Despacho automático de flota | 6 | identidad, plan con 5 hitos, dinero, 1 contrato (2 entregables) y 1 factura, 2 compromisos | autoridad, fase |
| PRY-205 Sistema de gestión de seguridad | 2 | identidad, dinero, riesgos e incidencias | autoridad, fase, producto, **cronograma e hitos (no hay cronograma)** |
| PRY-207 Gemelo digital de la planta | 4 | identidad, plan con 3 hitos, dinero, 1 compromiso | autoridad, fase |
| PRY-208 Trazabilidad del mineral | 2 | identidad, dinero, riesgos | autoridad, fase, **cronograma e hitos (no hay cronograma)** |
| PRY-209 Electrificación de equipos | 2 | identidad, dinero, riesgos e incidencias | autoridad, fase, producto, **cronograma e hitos (no hay cronograma)** |
| PRY-210 Programa de relacionamiento comunitario | 5 | identidad, 2 líneas base, 3 hitos, dinero, CC-01 autorizado | autoridad, fase, producto, razón de la línea base v2 en el cronograma |
| PRY-211 Control de polvo en vías | 8 | identidad, plan con 5 hitos (2 con acta), dinero, 1 contrato (3 entregables) y 1 factura, 1 compromiso | autoridad, fase, producto |

### Actualizados
| Proyecto | Qué cambió | Fuente |
|---|---|---|
| — | Ninguno. PRY-201, PRY-204 y PRY-206 no tenían cambios y no se tocaron. | — |

### No pude leer
| Archivo | Por qué |
|---|---|
| — | Ninguno. |

### Movidos desde entrada/
| Archivo | A qué proyecto | Por qué |
|---|---|---|
| — | No existe carpeta `entrada/` en la documentación. No moví nada. | — |

### Pendientes de clasificar
| Archivo | Por qué no pude decidir |
|---|---|
| — | Ninguno. |

### Lo que hay que mirar
Las señales las calculó `portafolio.py compute`. No las calculé yo. 11 de 13 proyectos tienen alguna, 52 en total, y 7 proyectos tienen el semáforo declarado contradicho por los documentos. En los 13 la autoridad del gerente no aparece en ningún documento. Entre los 10 proyectos que leí hoy destaco:

- **PRY-200 (rojo, 36%):** el cronograma v2 del 2026-10-09 mueve «Montaje e instalación» de 2027-04-11 a 2027-07-24 (+104 días). La solicitud CC-01 del 2026-10-12 pide esos mismos 104 días y está «pendiente de presentación al comité». La línea base se movió antes de que nadie la autorizara (`rebaseline_unauthorized`). Además, dos hitos están cerrados sin acta de recibo. La proyección al cierre es de 883.635.954 COP contra 800.000.000 aprobados.
- **PRY-210 (rojo, 32%):** la CC-01 (+58 días, +116.000.000 COP) dice «Autorizada por el comité», pero no nombra quién decidió ni cuándo. El cronograma v2 desplaza la licencia de 2026-12-25 a 2027-02-21 sin declarar el motivo. Lo ejecutado (1.348.761.719) supera lo comprometido (817.041.785) y la proyección es de 2.790.603.817 contra 2.400.000.000.
- **PRY-203 y PRY-211, facturas sin entrega:**
  - PRY-203: la factura FV-1235 (2026-10-01) por 35.834.032 COP se radicó contra el contrato CT-235. Ningún entregable figura aceptado y no hay acta de recibo. «Licenciamiento del software» vencía el 2026-09-10 y sigue pendiente.
  - PRY-211: la factura FV-1239 (2026-09-06) por 174.788.809 COP se radicó contra el contrato CT-239, un día antes de la fecha de «Licenciamiento del software» (2026-09-07). Ningún entregable tiene acta de recibo y el contrato exige acta para facturar.
- **PRY-202 (verde, 43%):** declara verde, pero lo ejecutado (9.688.237.294) supera lo comprometido (5.057.071.760). Tiene dos hitos cerrados sin acta, y el cierre del acta es el 2026-11-09.
- **PRY-205, PRY-208, PRY-209:** no tienen cronograma. Sus fechas de cierre según el acta ya pasaron: 2026-03-19, 2026-08-31 y 2026-08-29. Ningún documento las reprograma. PRY-208 y PRY-209 declaran verde (90% y 36%) y PRY-205 declara rojo. PRY-209 lleva 22 días sin documentos nuevos.
- **PRY-207 (verde, 56%):** el hito «Ingeniería básica aprobada» figura cerrado sin acta. El último informe es del 2026-09-24.
- **PRY-199:** sin señales. El hito cerrado tiene su acta (2026-10-09) y el contrato CT-199 está sin facturar.
- **Compromisos con dolientes que no estaban en la reunión:** 6 de los 7 compromisos nuevos de las minutas están asignados a personas que no figuran entre los asistentes. Son Carlos Peña (PRY-199 y PRY-203), Paula Céspedes (PRY-200), Laura Vélez (PRY-202) y Camilo Beltrán (PRY-203 y PRY-207). El séptimo, de Sandra Gil (PRY-211), sí es de una asistente. Quedan como `open`; ninguno está vencido hoy. El más próximo es el de Laura Vélez, para el 2026-10-18.
- **PRY-201, PRY-204 y PRY-206 (sin cambio):** el índice reporta 22 citas de PRY-201 que no resuelven. Están dentro de `pm_record`, la ficha que publicó el gerente, y apuntan a rutas relativas a la carpeta del proyecto y no a la raíz de documentación. No las toqué: esa ficha es del gerente.

### Después
Hay 13 proyectos con ficha, así que puedo armar el informe consolidado con `/criterio-portfolio:portfolio-report`. No lo generé en este barrido.

*criterio-portfolio 0.3.13 · fichas tocadas: PRY-199, 200, 202, 203, 205, 207, 208, 209, 210, 211 · campos en `not_found`: autoridad y fase en las 10; producto en 5 (PRY-202, 205, 209, 210, 211); cronograma e hitos en 3 (PRY-205, 208, 209) · Términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.13*
