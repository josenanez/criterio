# Comité de proyectos — 2026-10-21 (material preparado el 2026-10-17)
7 decisiones · 7 escalamientos sin decisión asociada · 11 de 13 proyectos con hallazgos

**Base:** fichas de `estado/records/` (13 proyectos, corte 2026-10-17) y la salida de `portafolio.py compute` del mismo día. Términos 1.1 vigentes, aceptados por José Francisco Ñáñez el 2026-10-17. Todas las cifras derivadas salen de `compute`; las sumas en COP de cada solicitud de cambio se copian de la solicitud, no se calculan.

## Decisiones del comité anterior
No hay registro de un comité anterior en las fichas ni en las corridas (`estado/` no contiene acta, decisión ni material de comité previo). No se puede cerrar el ciclo: se declara el vacío en vez de reconstruirlo. Hay una decisión que alguien atribuye al comité sin acta: PRY-210 CC-01 (punto 5).

## Decisiones de hoy

### [1] ¿Quién tiene facultad para aprobar cambios de alcance, tiempo y costo en el portafolio, y hasta qué monto?
**Proyecto:** los 13 (`no_authority` = 13) · **Quién decide:** patrocinador / quien presida el comité (no consta en los documentos) · **Si no se decide hoy:** los puntos 2 a 7 se quedan sin un decisor verificable y cada solicitud seguirá subiendo al comité.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Fijar un monto y un tope de días por gerente, y todo lo demás sube | Cambios menores se resuelven en el proyecto | Menos espera en cambios pequeños | Control por umbral; el monto lo fija el comité |
| B. Todo cambio sube al comité mientras no haya autoridad escrita | Sin cambio | Cada cambio espera a la sesión | Control total, carga alta en el comité |
**Recomendación:** B hasta que haya autoridad escrita en las actas y A después. Hoy ningún acta declara autoridad, así que no hay umbral que respaldar con un documento.

### [2] ¿Se aprueba PRY-200 CC-01: ampliación de alcance, +104 días y 208.000.000 COP?
**Proyecto:** PRY-200 · **Quién decide:** sin determinar (ver punto 1) · **Si no se decide hoy:** el proyecto sigue con la fecha movida sin autorización: `rebaseline_unauthorized` = 104 días movidos, 0 autorizados.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| Aprobar | Ampliación | Fin 2027-07-24; 104 días (22,6 %) sobre la original | Aprobado 800.000.000 COP + 208.000.000 COP según la solicitud. Proyección actual 883.635.954 COP (10,5 % sobre el aprobado); si ya incluye el cambio, no consta |
| Rechazar | Sin ampliación | La fecha vuelve a la línea base original; el avance ya está atrás (declarado 36 %, el plan sostiene 50 a 75 %) | Aprobado 800.000.000 COP; proyección 10,5 % arriba |
| Aprobar parcial | A definir con el gerente | A definir | A definir |
**Recomendación:** no aprobar hasta que el gerente aporte evidencia de dos hitos declarados cumplidos sin soporte (Ingeniería básica y de detalle) y diga si la proyección ya incluye el cambio. La fecha ya está movida sin autorización.

### [3] ¿Se aprueba PRY-201 CC-01: ampliación de alcance, +96 días y 192.000.000 COP?
**Proyecto:** PRY-201 · **Quién decide:** sin determinar · **Si no se decide hoy:** 96 días movidos sin autorización, el informe declara verde y 6 compromisos están vencidos.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| Aprobar | Ampliación | Fin 2027-05-10; 96 días (29,6 %) sobre la original | Aprobado 4.200.000.000 COP + 192.000.000 COP; comprometido 3.527.144.366 (84,0 %); proyección 4.269.105.906 (1,6 % arriba) |
| Rechazar | Sin ampliación | Vuelve a la fecha original | Margen disponible real 672.855.634 COP |
**Recomendación:** no aprobar hasta que el gerente cierre los compromisos vencidos y explique el verde declarado el 2026-10-09 frente a 5 señales abiertas.

### [4] ¿Se aprueba PRY-204 CC-01: ampliación de alcance, +40 días y 80.000.000 COP?
**Proyecto:** PRY-204 · **Quién decide:** sin determinar · **Si no se decide hoy:** 40 días movidos sin autorización; la fecha fin ya pasó (2026-05-10) con 45 % declarado.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| Aprobar | Ampliación | 40 días (18,7 %) sobre la original | Aprobado 800.000.000 COP + 80.000.000 COP; proyección 765.155.217 (4,4 % por debajo del aprobado) |
| Rechazar | Sin ampliación | Vuelve a la original, ya vencida | Sin costo adicional |
**Recomendación:** pedir antes la fecha fin vigente y la evidencia de los 3 hitos declarados cumplidos. Con 45 % declarado, el plan sostiene 100 %: el atraso real puede ser mayor que los 40 días solicitados.

### [5] PRY-210 CC-01 figura aprobado por «el comité» sin nombre ni fecha: ¿se ratifica, con qué autoridad y qué se hace con el sobrecosto?
**Proyecto:** PRY-210 · **Quién decide:** el comité, en acta · **Si no se decide hoy:** hay un cambio aprobado sin decisor ni fecha (+58 días, 116.000.000 COP) y un proyecto en rojo cuya proyección es 2.790.603.817 COP contra 2.400.000.000 aprobados (16,3 % arriba).
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| Ratificar en acta | Ampliación vigente | Fin 2027-02-21; 58 días (14,8 %) sobre la original | La proyección supera el aprobado 16,3 %; hay que decidir cómo se cubre |
| Revertir y reevaluar | Sin ampliación | La fecha vuelve a la original | Sin los 116.000.000 COP de la solicitud; la proyección queda por revisar |
**Recomendación:** ratificar en acta con nombre y fecha, y pedir plan de cobertura del sobrecosto. Avance declarado 32 % frente a 67 a 100 % que sostiene el plan.

### [6] PRY-205: ¿se autoriza presupuesto adicional y nueva línea base?
**Proyecto:** PRY-205 · **Quién decide:** sin determinar · **Si no se decide hoy:** la proyección es 901.106.299 COP contra 800.000.000 aprobados (12,6 % arriba). La fecha fin (2026-03-19) está vencida desde hace casi 7 meses, con 68 % declarado y estado rojo.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| Autorizar el adicional y fijar nueva línea base | No consta | Fecha nueva a proponer por el gerente; no está en los documentos | 101.106.299 COP sobre el aprobado (proyección menos aprobado) |
| No autorizar y recortar alcance | A recortar | No consta | Se queda en 800.000.000 COP |
| Pausar hasta tener plan | Congelado | Se detiene | Comprometido 595.392.641 (74,4 %), ejecutado 230.242.278 |
**Recomendación:** pausar la decisión de fondos hasta que el gerente presente una fecha nueva. No hay solicitud de cambio, así que el comité no tiene qué aprobar. Los datos de la ficha tienen 17 meses.

### [7] PRY-203 y PRY-211: ¿se retiene el pago al proveedor que facturó sin entregar?
**Proyecto:** PRY-203 (Montajes Industriales Ltda., CT-235) y PRY-211 (Servicios Ambientales del Norte, CT-239) · **Quién decide:** sin determinar · **Si no se decide hoy:** se siguen acumulando pagos sin aceptación.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| Retener hasta aceptación | Sin cambio | Puede frenar al proveedor | PRY-203: 35.834.032 COP facturados, 0 aceptado. PRY-211: 174.788.809 COP facturados, 0 aceptado |
| Aceptar y pagar con observación | Sin cambio | Sigue el ritmo | Se paga sin evidencia de entrega |
**Recomendación:** retener. En ambos casos el entregable «Licenciamiento del software» sigue pendiente, 37 días tarde en PRY-203 y 40 en PRY-211. Los informes declaran verde (PRY-203) y amarillo (PRY-211) sin explicar la factura.

## Escalamientos sin decisión asociada
| Proyecto | Qué | Desde cuándo | Qué se necesita |
|---|---|---|---|
| PRY-201 | 6 compromisos vencidos (de 2 a 32 días) y 2 sin fecha; dos reprogramados 6 y 5 veces | Primer vencimiento 2026-09-15 | Doliente de seguimiento en el comité |
| PRY-202 | Avance declarado 43 % frente a 75 a 100 % que sostiene el plan (brecha 32 puntos); fin 2026-11-09; 2 hitos sin evidencia | Informe 2026-10-12 | Revisión independiente del avance |
| PRY-209 | Silencio de 22 días, fin 2026-08-29 ya pasado, verde declarado | Desde 2026-09-25 | Respuesta del gerente |
| PRY-208 | Fecha fin 2026-08-31 pasada con 90 % declarado | Sin fecha de corte de la fuente | Fecha vigente |
| PRY-204 y PRY-205 | Fecha fin pasada (2026-05-10 y 2026-03-19) | Ver puntos 4 y 6 | Ver puntos 4 y 6 |
| PRY-200, 201, 202, 203, 204, 206, 207, 210 | Hitos «cumplido» sin evidencia (ver anexo) | De 23 a 343 días | Que el gerente adjunte el soporte |
| PRY-207 | 13 días sin actividad (umbral 15); último informe hace 23 días | 2026-09-24 | Vigilar; todavía no supera el umbral |

## Para conocimiento
- PRY-199: sin alertas. Verde, 20 %.
- PRY-208: sin alertas del script; ver la fecha fin pasada arriba.
- PRY-206: verde; 2 hitos sin evidencia; avance coherente con el plan.
- PRY-207: verde; 1 hito sin evidencia.
- Sin dependencias declaradas entre proyectos en las fichas (`dependencies` vacío en los 13).

## Anexo
**Estado por proyecto (declarado → lo que señala el script):**
| Proyecto | Declarado | Señales abiertas |
|---|---|---|
| PRY-199 | verde | 0 |
| PRY-200 | rojo | 6 |
| PRY-201 | verde (contradicho) | 15 |
| PRY-202 | verde (contradicho) | 4 |
| PRY-203 | verde (contradicho) | 5 |
| PRY-204 | verde (contradicho) | 7 |
| PRY-205 | rojo | 1 |
| PRY-206 | verde (contradicho) | 3 |
| PRY-207 | verde (contradicho) | 2 |
| PRY-208 | verde | 0 |
| PRY-209 | verde (contradicho) | 2 |
| PRY-210 | rojo | 5 |
| PRY-211 | amarillo | 2 |

Totales de `compute`: 52 alertas, 11 proyectos con alertas, 7 verdes contradichos, 0 con registro roto.

**Contradicciones abiertas:** PRY-201, 202, 203, 204, 206, 207 y 209 declaran verde con señales abiertas.

**Vacíos de información:**
- Autoridad del gerente: falta en los 13.
- Fase del proyecto: falta en los 13.
- Producto: falta en PRY-201, 202, 205, 206, 209, 210 y 211.
- PRY-201: el proveedor del entregable «Equipos en el campamento» no tiene nombre, contrato ni factura en los documentos; figura entregado sin evidencia de recibo.
- Campos con más de 12 meses: PRY-204 (14 meses), PRY-205 (17), PRY-206 (12), PRY-208 (13) y PRY-209 (17).
- Ningún dato de las fichas está marcado como evidencia (`evidence` = 0 en los 13): todo es declaración o sin marcar. Las «brechas» son contra lo declarado, no contra una verificación en campo.
- No hay acta de comité anterior, por lo que el cierre de ciclo no es posible.

**Próximo comité:** 2026-10-21 (según la configuración). Las comparaciones de fecha fin contra hoy son de este material, no de `compute`.
