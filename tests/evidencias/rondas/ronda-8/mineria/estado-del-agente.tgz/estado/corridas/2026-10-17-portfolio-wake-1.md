# Corrida del 2026-10-17 · portfolio-wake

13 proyectos · 33 s · 52 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 15 |
| `declared_vs_evidence` | 7 |
| `commitment_overdue` | 6 |
| `variance_time` | 4 |
| `progress_vs_plan` | 4 |
| `variance_cost` | 3 |
| `rebaseline_unauthorized` | 3 |
| `commitment_undated` | 2 |
| `commitment_rescheduled` | 2 |
| `vendor_deliverable_late` | 2 |
| `vendor_invoiced_without_delivery` | 2 |
| `vendor_accepted_without_evidence` | 1 |
| `silent` | 1 |

Barrido sin cambios (72 documentos); 23 citas pm_record de PRY-201 marcadas source_missing aunque los archivos existen (ruta sin prefijo de carpeta); 5 preguntas de confirmación sin respuesta; no revisé peticiones del servidor

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## 2026-10-17

**Revisé:** 72 documentos · 0 cambiaron · 0 proyectos recalculados

Términos vigentes (v0.3.13, aceptados por José Francisco Ñáñez el 2026-10-17). Tocaban el barrido diario y la confirmación periódica; el informe de comité llega el 2026-10-19 (comité del 2026-10-21).

### Lo que cruzó un umbral
Nada. El barrido corrió sin documentos nuevos, cambiados, renombrados ni borrados, y no recalculé ningún proyecto.

**Cita que no resuelve (hallazgo, no relectura):** el índice marca 23 campos de `pm_record` de PRY-201 como `source_missing`. Los archivos citados existen en la carpeta del proyecto (`00-gobierno/2026-03-06-acta-constitucion.docx`, `20-seguimiento/2026-10-09-informe-avance.md`, `10-plan/2026-10-09-cronograma-v2.xlsx`). La causa probable es la forma de la ruta: `pm_record` cita sin el prefijo de carpeta `PRY-201-ampliación-de-la-relavera/`, y el resto de las fichas lo lleva. No lo corregí, porque la ficha del gerente no la escribe el agente. Queda como pregunta abierta para quien publica la ficha.

### Peticiones atendidas
No revisé el servidor de peticiones: `requests` no estaba entre lo que tocaba hoy.

### Preguntas
Cinco campos de PRY-201, elegidos por importancia. No hay nadie que responda en esta sesión, así que quedan preguntadas el 2026-10-17, sin respuesta. No se repiten hasta la próxima confirmación.
1. **Fase** del proyecto: no encontrada en ningún documento.
2. **Producto** al que sirve: no encontrado.
3. **Autoridad** que aprueba cambios: no encontrada. Hay una solicitud de cambio, CC-01, del 2026-10-05.
4. **Estado declarado** (verde, 29 %): viene del informe de avance del 2026-10-09. ¿Sigue vigente?
5. **Fecha de fin** (2027-05-10, cronograma v2 del 2026-10-09): la línea base original decía 2027-02-03. ¿Está aprobada la v2?

**Vuelvo el 2026-10-18.**
