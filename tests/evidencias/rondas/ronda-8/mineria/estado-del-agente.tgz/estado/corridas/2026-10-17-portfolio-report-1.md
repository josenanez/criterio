# Corrida del 2026-10-17 · portfolio-report

13 proyectos · 72 documentos, 0 releídos y 72 sin cambio · 25 s · 52 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 15 |
| `declared_vs_evidence` | 7 |
| `commitment_overdue` | 6 |
| `variance_time` | 4 |
| `progress_vs_plan` | 4 |
| `variance_cost` | 3 |
| `rebaseline_unauthorized` | 3 |
| `commitment_undated` | 2 |
| `commitment_rescheduled` | 2 |
| `vendor_deliverable_late` | 2 |
| `vendor_invoiced_without_delivery` | 2 |
| `vendor_accepted_without_evidence` | 1 |
| `silent` | 1 |

El informe quedó en `/home/claude/banco/ronda-8/mineria/espacio/reportes/index.html`.

7 proyectos en verde contradichos por la evidencia; PRY-204, PRY-200 y PRY-203 concentran las alertas

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

# Portafolio — 2026-10-17

Fichas cargadas: 13 proyectos (`estado/records/`), con datos al 2026-10-17. Términos vigentes: versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17.

13 proyectos · 11 con hallazgos · 52 alertas · 7 en verde contradichos por la evidencia · 6 productos.

## Qué cambió desde la corrida anterior
Sin cambios desde la instantánea anterior (2026-10-17). La instantánea es de hoy, así que este informe no tiene delta que reportar.

## Informe generado (formato html)
Carpeta: `/home/claude/banco/ronda-8/mineria/espacio/reportes` (23 páginas).
- `index.html` — vista por campo, con la cadena de evidencia completa. Para quien va a actuar.
- `decisiones.html` — vista por decisión. Para el patrocinador: solo lo que excede la facultad de quien gerencia.
- Una página por proyecto (`PRY-199.html` … `PRY-211.html`), una por producto, más `productos.html` y `proyectos.html`.
- El PDF sale de imprimir el HTML.

## Señales por producto (de `compute`)
| Producto | Proyecto | Alertas | Señales |
|---|---|---|---|
| alerta de taludes | PRY-204 | 7 | declarado vs evidencia, hito cumplido sin evidencia, avance vs plan, replanificación sin autorizar, desviación en tiempo |
| monitoreo de flota | PRY-200 | 6 | hito cumplido sin evidencia, avance vs plan, replanificación sin autorizar, desviación en costo, desviación en tiempo |
| despacho de flota | PRY-203 | 5 | declarado vs evidencia, hito cumplido sin evidencia, entregable de proveedor atrasado, proveedor facturado sin entrega |
| gemelo digital | PRY-207 | 2 | declarado vs evidencia, hito cumplido sin evidencia |
| PRD-299 | PRY-199 | 0 | — |
| trazabilidad | PRY-208 | 0 | — |

## Otros hallazgos del cálculo
- Ningún proyecto tiene autoridad nombrada (13 de 13 sin autoridad).
- Proyectos sin producto asociado: PRY-201, PRY-202, PRY-205, PRY-206, PRY-209, PRY-210, PRY-211.
- PRY-211 (declarado en amarillo, 56 % al 2026-10-15) no explica dos señales: entregable de proveedor atrasado y proveedor facturado sin entrega.
- Sin proyectos sin línea base. Sin problemas de ficha.

## Necesito que confirmes
No toca confirmación periódica en esta corrida; en una sesión sin interfaz no hay a quién preguntar. Pendiente para la próxima.

---
Criterio portfolio 0.3.13 · fichas aplicadas: 13, con fecha 2026-10-17 · campos inciertos: ver las páginas por proyecto · términos: https://www.josenanez.com/es/agents/criterio-pmo/legal
