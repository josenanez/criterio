<!-- origen: PRY-211-control-de-polvo-en-vías/20-seguimiento/2026-10-15-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Control de polvo en vías
Código: PRY-211
Fecha de corte: 2026-10-15
Gerente: Sandra Gil

Estado declarado
Amarillo
Avance reportado: 56%

Lo que pasó en el periodo
- Se levantó un hallazgo en la auditoría de seguridad

Presupuesto
COP
Aprobado 2.400.000.000
Comprometido 1.587.148.159
Ejecutado 564.763.180
Proyección al cierre 2.482.187.110

Riesgos abiertos
- Concentración del conocimiento en una sola persona
