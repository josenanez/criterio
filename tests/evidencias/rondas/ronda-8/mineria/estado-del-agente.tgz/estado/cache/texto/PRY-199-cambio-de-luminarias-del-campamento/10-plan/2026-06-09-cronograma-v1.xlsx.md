<!-- origen: PRY-199-cambio-de-luminarias-del-campamento/10-plan/2026-06-09-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Ingeniería básica aprobada | 2026-10-06 | 2026-10-06 | cerrado
Ingeniería de detalle aprobada | 2027-01-23 | 2027-01-23 | en curso
Licencia y permisos obtenidos | 2027-05-12 | 2027-05-12 | en curso
Montaje e instalación | 2027-08-29 | 2027-08-29 | en curso
Pruebas en operación | 2027-12-16 | 2027-12-16 | en curso
