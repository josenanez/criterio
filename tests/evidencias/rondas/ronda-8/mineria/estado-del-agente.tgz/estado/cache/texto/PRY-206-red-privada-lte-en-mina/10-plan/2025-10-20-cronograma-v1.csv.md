<!-- origen: PRY-206-red-privada-lte-en-mina/10-plan/2025-10-20-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Ingeniería básica aprobada,2026-03-29,2026-03-29,cerrado
Ingeniería de detalle aprobada,2026-08-27,2026-08-27,cerrado
Licencia y permisos obtenidos,2027-01-24,2027-01-24,en curso
