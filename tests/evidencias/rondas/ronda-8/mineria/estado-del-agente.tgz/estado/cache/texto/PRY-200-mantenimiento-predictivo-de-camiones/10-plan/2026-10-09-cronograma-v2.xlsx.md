<!-- origen: PRY-200-mantenimiento-predictivo-de-camiones/10-plan/2026-10-09-cronograma-v2.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Ingeniería básica aprobada | 2026-05-01 | 2026-05-01 | cerrado
Ingeniería de detalle aprobada | 2026-08-24 | 2026-08-24 | cerrado
Licencia y permisos obtenidos | 2026-12-17 | 2026-12-17 | en curso
Montaje e instalación | 2027-04-11 | 2027-07-24 | en curso
