<!-- origen: PRY-211-control-de-polvo-en-vías/10-plan/2026-06-04-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Ingeniería básica aprobada | 2026-08-15 | 2026-08-15 | cerrado
Ingeniería de detalle aprobada | 2026-10-16 | 2026-10-16 | cerrado
Licencia y permisos obtenidos | 2026-12-18 | 2026-12-18 | en curso
Montaje e instalación | 2027-02-18 | 2027-02-18 | en curso
Pruebas en operación | 2027-04-21 | 2027-04-21 | en curso
