<!-- origen: PRY-211-control-de-polvo-en-vías/20-seguimiento/2026-10-04-acta-recibo-ingeniería-básica-aprobada.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de recibo · Ingeniería básica aprobada
Proyecto: PRY-211 · Control de polvo en vías
Fecha de recibo: 2026-10-04
Recibido por: Sandra Gil
Se recibe a satisfacción el entregable Ingeniería básica aprobada.
