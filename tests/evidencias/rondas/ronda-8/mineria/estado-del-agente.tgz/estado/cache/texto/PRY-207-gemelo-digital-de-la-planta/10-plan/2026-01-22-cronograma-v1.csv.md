<!-- origen: PRY-207-gemelo-digital-de-la-planta/10-plan/2026-01-22-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Ingeniería básica aprobada,2026-07-07,2026-07-07,cerrado
Ingeniería de detalle aprobada,2026-12-10,2026-12-10,en curso
Licencia y permisos obtenidos,2027-05-15,2027-05-15,en curso
