<!-- origen: PRY-201-ampliación-de-la-relavera/30-reuniones/2026-09-05-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Operaciones · Ampliación de la relavera

**Fecha:** 2026-09-05
**Asistentes:** Felipe Arango, María Restrepo, Mauricio Pérez, Paula Céspedes

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Paula Céspedes | Enviar el documento 1 | 2026-09-14 |
| María Restrepo | Cerrar la prueba 2 | 2026-09-12 |
| Felipe Arango | Revisar el anexo 3 | 2026-09-10 |
| Felipe Arango | Validar el ambiente 4 | 2026-10-02 |
