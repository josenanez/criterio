<!-- origen: PRY-210-programa-de-relacionamiento-comunitario/10-plan/2026-10-14-cronograma-v2.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Ingeniería básica aprobada | 2026-04-08 | 2026-04-08 | cerrado
Ingeniería de detalle aprobada | 2026-08-17 | 2026-08-17 | cerrado
Licencia y permisos obtenidos | 2026-12-25 | 2027-02-21 | en curso
