<!-- origen: PRY-211-control-de-polvo-en-vías/30-reuniones/2026-10-12-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Inversiones · Control de polvo en vías

**Fecha:** 2026-10-12
**Asistentes:** Sandra Gil, Jorge Medina

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Sandra Gil | Entregar el punto 33 | 2026-10-29 |
