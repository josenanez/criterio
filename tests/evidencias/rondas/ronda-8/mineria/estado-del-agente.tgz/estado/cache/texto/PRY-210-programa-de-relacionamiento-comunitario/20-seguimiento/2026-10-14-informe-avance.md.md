<!-- origen: PRY-210-programa-de-relacionamiento-comunitario/20-seguimiento/2026-10-14-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Programa de relacionamiento comunitario

**Código:** PRY-210
**Fecha de corte:** 2026-10-14
**Gerente:** Paula Céspedes

## Estado declarado

**Rojo**

Avance reportado: **32%**

## Lo que pasó en el periodo

- El proveedor entregó los equipos en el campamento, pendientes de aceptación

## Presupuesto

| | COP |
|---|---|
| Aprobado | 2.400.000.000 |
| Comprometido | 817.041.785 |
| Ejecutado | 1.348.761.719 |
| Proyección al cierre | 2.790.603.817 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
- Cambio en la licencia ambiental que puede mover el alcance
