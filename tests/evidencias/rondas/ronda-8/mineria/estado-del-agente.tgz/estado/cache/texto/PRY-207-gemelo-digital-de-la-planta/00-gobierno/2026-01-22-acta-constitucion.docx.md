<!-- origen: PRY-207-gemelo-digital-de-la-planta/00-gobierno/2026-01-22-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Gemelo digital de la planta

Código: PRY-207

Área dueña: Planta de procesamiento

Patrocinador: Natalia Ospina

Gerente de proyecto: Liliana Torres

Comité: Comité de Inversiones

Producto asociado: gemelo digital

Fecha de aprobación: 2026-01-22

Objetivo del negocio

Entregar gemelo digital de la planta para Planta de procesamiento.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

2.400.000.000 COP, aprobado por Comité de Inversiones el 2026-01-22.

Fechas comprometidas

Fecha

Inicio

2026-02-01

Cierre

2027-05-15

Criterio de éxito

Gemelo digital de la planta en producción y medido.

Dependencias declaradas

• Ninguna declarada
