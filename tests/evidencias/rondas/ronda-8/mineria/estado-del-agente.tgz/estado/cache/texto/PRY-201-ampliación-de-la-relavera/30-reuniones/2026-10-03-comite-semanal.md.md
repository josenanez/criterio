<!-- origen: PRY-201-ampliación-de-la-relavera/30-reuniones/2026-10-03-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Operaciones · Ampliación de la relavera

**Fecha:** 2026-10-03
**Asistentes:** Andrés Lozano, Felipe Arango, Gustavo Neira, Javier Hoyos, Laura Vélez, Liliana Torres, María Restrepo, Mauricio Pérez, Paula Céspedes, Sandra Gil, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Paula Céspedes | Enviar el documento 1 | 2026-11-01 |
| María Restrepo | Cerrar la prueba 2 | 2026-11-14 |
| Andrés Lozano | Aprobar el diseño 5 | 2026-10-15 |
| Mauricio Pérez | Actualizar la matriz 6 | 2026-09-15 |
| Óscar Ramírez | Entregar el punto 8 | 2026-10-02 |
| Liliana Torres | Enviar el documento 9 | 2026-10-28 |
| Felipe Arango | Cerrar la prueba 10 | 2026-10-06 |
| Felipe Arango | Validar el ambiente 12 | 2026-10-22 |
| Laura Vélez | Aprobar el diseño 13 | 2026-09-30 |
| Sandra Gil | Confirmar la fecha 15 | 2026-10-17 |
| Felipe Arango | Entregar el punto 16 | 2026-10-19 |
| Andrés Lozano | Enviar el documento 17 | 2026-10-17 |
| Javier Hoyos | Cerrar la prueba 18 | por definir |
| Óscar Ramírez | Revisar el anexo 19 | 2026-10-11 |
| Gustavo Neira | Validar el ambiente 20 | 2026-10-08 |

## Cerrados en esta reunión

- Revisar el anexo 3 (Felipe Arango): recibido, acta de recibo del 2026-10-03.
- Validar el ambiente 4 (Felipe Arango): recibido, acta de recibo del 2026-10-03.
- Confirmar la fecha 7 (Mauricio Pérez): recibido, acta de recibo del 2026-10-03.
- Actualizar la matriz 14 (Sandra Gil): recibido, acta de recibo del 2026-10-03.

## Lo que se dijo

- María Restrepo dice que ya entregó «revisar el anexo 11». No se presentó acta.
