<!-- origen: PRY-207-gemelo-digital-de-la-planta/30-reuniones/2026-10-04-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Inversiones · Gemelo digital de la planta

Fecha: 2026-10-04

Asistentes: Liliana Torres, Natalia Ospina

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Camilo Beltrán

Entregar el punto 13

2026-11-09
