<!-- origen: PRY-207-gemelo-digital-de-la-planta/20-seguimiento/2026-09-24-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Gemelo digital de la planta
Código: PRY-207
Fecha de corte: 2026-09-24
Gerente: Liliana Torres

Estado declarado
Verde
Avance reportado: 56%

Lo que pasó en el periodo
- El equipo perdió dos semanas por rotación de un ingeniero clave

Presupuesto
COP
Aprobado 2.400.000.000
Comprometido 714.615.611
Ejecutado 498.192.587
Proyección al cierre 2.273.268.229

Riesgos abiertos
- Concentración del conocimiento en una sola persona
- Ventana de parada de planta definida por operaciones
