<!-- origen: PRY-203-despacho-automático-de-flota/00-gobierno/2026-05-30-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Despacho automático de flota

**Código:** PRY-203
**Área dueña:** Planta de procesamiento
**Patrocinador:** Javier Hoyos
**Gerente de proyecto:** Jorge Medina
**Comité:** Comité de Tecnología
**Producto asociado:** despacho de flota
**Fecha de aprobación:** 2026-05-30

## Objetivo del negocio

Entregar despacho automático de flota para Planta de procesamiento.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**800.000.000 COP**, aprobado por Comité de Tecnología el 2026-05-30.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-06-09 |
| Cierre | 2027-02-17 |

## Criterio de éxito

Despacho automático de flota en producción y medido.

## Dependencias declaradas

- Ninguna declarada
