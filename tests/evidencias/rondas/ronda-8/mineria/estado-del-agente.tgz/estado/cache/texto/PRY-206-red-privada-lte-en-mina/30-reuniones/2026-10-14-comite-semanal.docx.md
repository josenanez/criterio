<!-- origen: PRY-206-red-privada-lte-en-mina/30-reuniones/2026-10-14-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité Ambiental · Red privada LTE en mina

Fecha: 2026-10-14

Asistentes: Sandra Gil, Beatriz Cuéllar

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Liliana Torres

Entregar el punto 2

2026-11-13
