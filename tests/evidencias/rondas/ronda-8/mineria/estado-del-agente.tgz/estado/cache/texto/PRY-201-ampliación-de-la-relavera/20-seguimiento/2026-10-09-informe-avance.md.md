<!-- origen: PRY-201-ampliación-de-la-relavera/20-seguimiento/2026-10-09-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Ampliación de la relavera

**Código:** PRY-201
**Fecha de corte:** 2026-10-09
**Gerente:** Mauricio Pérez

## Estado declarado

**Verde**

Avance reportado: **29%**

## Lo que pasó en el periodo

- Se levantó un hallazgo en la auditoría de seguridad
- El proveedor entregó los equipos en el campamento, pendientes de aceptación
- Se recibió el permiso ambiental pendiente desde el trimestre anterior

## Presupuesto

| | COP |
|---|---|
| Aprobado | 4.200.000.000 |
| Comprometido | 3.527.144.366 |
| Ejecutado | 1.393.552.576 |
| Proyección al cierre | 4.269.105.906 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
- El proveedor no ha confirmado la fecha de la última entrega
