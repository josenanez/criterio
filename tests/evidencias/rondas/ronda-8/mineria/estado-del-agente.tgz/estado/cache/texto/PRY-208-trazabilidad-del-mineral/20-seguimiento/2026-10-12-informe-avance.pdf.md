<!-- origen: PRY-208-trazabilidad-del-mineral/20-seguimiento/2026-10-12-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Trazabilidad del mineral
Código: PRY-208
Fecha de corte: 2026-10-12
Gerente: Laura Vélez

Estado declarado
Verde
Avance reportado: 90%

Lo que pasó en el periodo
- Se reprogramó la parada de planta por la ventana de mantenimiento

Presupuesto
COP
Aprobado 9.500.000.000
Comprometido 7.472.735.712
Ejecutado 4.421.982.097
Proyección al cierre 9.004.783.007

Riesgos abiertos
- Bloqueo de la vía de acceso a la mina
- Ventana de parada de planta definida por operaciones
