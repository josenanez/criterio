<!-- origen: PRY-203-despacho-automático-de-flota/10-plan/2026-05-30-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Ingeniería básica aprobada,2026-07-29,2026-07-29,cerrado
Ingeniería de detalle aprobada,2026-09-18,2026-09-18,cerrado
Licencia y permisos obtenidos,2026-11-08,2026-11-08,en curso
Montaje e instalación,2026-12-28,2026-12-28,en curso
Pruebas en operación,2027-02-17,2027-02-17,en curso
