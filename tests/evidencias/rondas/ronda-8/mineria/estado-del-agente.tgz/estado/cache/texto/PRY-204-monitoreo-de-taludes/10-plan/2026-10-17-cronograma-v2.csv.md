<!-- origen: PRY-204-monitoreo-de-taludes/10-plan/2026-10-17-cronograma-v2.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Ingeniería básica aprobada,2025-11-08,2025-11-08,cerrado
Ingeniería de detalle aprobada,2026-01-18,2026-01-18,cerrado
Licencia y permisos obtenidos,2026-03-31,2026-05-10,cerrado
