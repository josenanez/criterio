<!-- origen: PRY-201-ampliación-de-la-relavera/20-seguimiento/2026-10-05-solicitud-cambio-cc-01.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-01

**Proyecto:** PRY-201 · Ampliación de la relavera
**Fecha:** 2026-10-05
**Solicitante:** Mauricio Pérez

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +96 días sobre la línea base vigente |
| Costo | 192.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
