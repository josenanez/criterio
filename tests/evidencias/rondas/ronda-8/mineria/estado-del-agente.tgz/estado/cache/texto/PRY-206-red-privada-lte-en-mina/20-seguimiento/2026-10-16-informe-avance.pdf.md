<!-- origen: PRY-206-red-privada-lte-en-mina/20-seguimiento/2026-10-16-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Red privada LTE en mina
Código: PRY-206
Fecha de corte: 2026-10-16
Gerente: Sandra Gil

Estado declarado
Verde
Avance reportado: 68%

Lo que pasó en el periodo
- Se levantó un hallazgo en la auditoría de seguridad
- Se reprogramó la parada de planta por la ventana de mantenimiento

Presupuesto
COP
Aprobado 6.800.000.000
Comprometido 5.767.007.545
Ejecutado 3.563.413.906
Proyección al cierre 7.083.466.999

Riesgos abiertos
- Concentración del conocimiento en una sola persona
- Ventana de parada de planta definida por operaciones
