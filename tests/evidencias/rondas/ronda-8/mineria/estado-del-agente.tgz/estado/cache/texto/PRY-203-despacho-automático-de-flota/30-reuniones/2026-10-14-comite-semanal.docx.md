<!-- origen: PRY-203-despacho-automático-de-flota/30-reuniones/2026-10-14-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Tecnología · Despacho automático de flota

Fecha: 2026-10-14

Asistentes: Jorge Medina, Javier Hoyos

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Carlos Peña

Entregar el punto 7

2026-10-28

Camilo Beltrán

Entregar el punto 35

2026-11-03
