<!-- origen: PRY-201-ampliación-de-la-relavera/10-plan/2026-03-06-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Ingeniería básica aprobada | 2026-07-02 | 2026-07-02 | cerrado
Ingeniería de detalle aprobada | 2026-10-18 | 2026-10-18 | en curso
Licencia y permisos obtenidos | 2027-02-03 | 2027-02-03 | en curso
