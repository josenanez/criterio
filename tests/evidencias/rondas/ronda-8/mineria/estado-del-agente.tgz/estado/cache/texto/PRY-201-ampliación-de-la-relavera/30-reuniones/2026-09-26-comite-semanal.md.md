<!-- origen: PRY-201-ampliación-de-la-relavera/30-reuniones/2026-09-26-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Operaciones · Ampliación de la relavera

**Fecha:** 2026-09-26
**Asistentes:** Andrés Lozano, Felipe Arango, Laura Vélez, Liliana Torres, María Restrepo, Mauricio Pérez, Paula Céspedes, Sandra Gil, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Paula Céspedes | Enviar el documento 1 | 2026-10-21 |
| María Restrepo | Cerrar la prueba 2 | 2026-10-25 |
| Felipe Arango | Revisar el anexo 3 | 2026-09-10 |
| Felipe Arango | Validar el ambiente 4 | 2026-10-31 |
| Andrés Lozano | Aprobar el diseño 5 | 2026-10-01 |
| Mauricio Pérez | Actualizar la matriz 6 | 2026-09-15 |
| Mauricio Pérez | Confirmar la fecha 7 | 2026-10-09 |
| Óscar Ramírez | Entregar el punto 8 | 2026-10-02 |
| Liliana Torres | Enviar el documento 9 | 2026-10-28 |
| Felipe Arango | Cerrar la prueba 10 | 2026-10-06 |
| María Restrepo | Revisar el anexo 11 | por definir |
| Felipe Arango | Validar el ambiente 12 | 2026-10-12 |
| Laura Vélez | Aprobar el diseño 13 | 2026-09-30 |
| Sandra Gil | Actualizar la matriz 14 | 2026-10-02 |
| Sandra Gil | Confirmar la fecha 15 | 2026-10-07 |
| Felipe Arango | Entregar el punto 16 | 2026-10-12 |
