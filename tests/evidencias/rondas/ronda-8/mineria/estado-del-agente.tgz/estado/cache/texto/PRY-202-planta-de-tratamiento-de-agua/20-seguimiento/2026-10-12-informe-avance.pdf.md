<!-- origen: PRY-202-planta-de-tratamiento-de-agua/20-seguimiento/2026-10-12-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Planta de tratamiento de agua
Código: PRY-202
Fecha de corte: 2026-10-12
Gerente: Paula Céspedes

Estado declarado
Verde
Avance reportado: 43%

Lo que pasó en el periodo
- Se recibió el permiso ambiental pendiente desde el trimestre anterior
- Se reprogramó la parada de planta por la ventana de mantenimiento
- El equipo perdió dos semanas por rotación de un ingeniero clave

Presupuesto
COP
Aprobado 18.000.000.000
Comprometido 5.057.071.760
Ejecutado 9.688.237.294
Proyección al cierre 18.618.936.126

Riesgos abiertos
- Ventana de parada de planta definida por operaciones
