<!-- origen: PRY-211-control-de-polvo-en-vías/00-gobierno/2026-06-04-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Control de polvo en vías

Código: PRY-211

Área dueña: Finanzas

Patrocinador: Jorge Medina

Gerente de proyecto: Sandra Gil

Comité: Comité de Inversiones

Producto asociado: No aplica

Fecha de aprobación: 2026-06-04

Objetivo del negocio

Entregar control de polvo en vías para Finanzas.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

2.400.000.000 COP, aprobado por Comité de Inversiones el 2026-06-04.

Fechas comprometidas

Fecha

Inicio

2026-06-14

Cierre

2027-04-21

Criterio de éxito

Control de polvo en vías en producción y medido.

Dependencias declaradas

• Ninguna declarada
