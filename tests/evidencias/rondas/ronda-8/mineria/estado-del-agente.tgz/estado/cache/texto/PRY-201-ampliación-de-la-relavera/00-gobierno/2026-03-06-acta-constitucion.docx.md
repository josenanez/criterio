<!-- origen: PRY-201-ampliación-de-la-relavera/00-gobierno/2026-03-06-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Ampliación de la relavera

Código: PRY-201

Área dueña: Logística

Patrocinador: María Restrepo

Gerente de proyecto: Mauricio Pérez

Comité: Comité de Operaciones

Producto asociado: No aplica

Fecha de aprobación: 2026-03-06

Objetivo del negocio

Entregar ampliación de la relavera para Logística.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

4.200.000.000 COP, aprobado por Comité de Operaciones el 2026-03-06.

Fechas comprometidas

Fecha

Inicio

2026-03-16

Cierre

2027-02-03

Criterio de éxito

Ampliación de la relavera en producción y medido.

Dependencias declaradas

• Ninguna declarada
