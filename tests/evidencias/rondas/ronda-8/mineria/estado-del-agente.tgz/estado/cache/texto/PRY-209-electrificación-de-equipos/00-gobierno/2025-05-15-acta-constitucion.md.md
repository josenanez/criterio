<!-- origen: PRY-209-electrificación-de-equipos/00-gobierno/2025-05-15-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Electrificación de equipos

**Código:** PRY-209
**Área dueña:** Mina
**Patrocinador:** Felipe Arango
**Gerente de proyecto:** Rubén Cárdenas
**Comité:** Comité de Inversiones
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-05-15

## Objetivo del negocio

Entregar electrificación de equipos para Mina.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**6.800.000.000 COP**, aprobado por Comité de Inversiones el 2025-05-15.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-05-25 |
| Cierre | 2026-08-29 |

## Criterio de éxito

Electrificación de equipos en producción y medido.

## Dependencias declaradas

- Ninguna declarada
