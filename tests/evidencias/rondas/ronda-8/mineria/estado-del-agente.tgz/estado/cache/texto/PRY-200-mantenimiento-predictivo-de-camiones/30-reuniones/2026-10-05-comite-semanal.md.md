<!-- origen: PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-10-05-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Inversiones · Mantenimiento predictivo de camiones

**Fecha:** 2026-10-05
**Asistentes:** Rubén Cárdenas, Ricardo Salas

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Paula Céspedes | Entregar el punto 8 | 2026-11-09 |
