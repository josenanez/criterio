<!-- origen: PRY-202-planta-de-tratamiento-de-agua/30-reuniones/2026-10-14-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Operaciones · Planta de tratamiento de agua

Fecha: 2026-10-14

Asistentes: Paula Céspedes, Gustavo Neira

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Laura Vélez

Entregar el punto 40

2026-10-18
