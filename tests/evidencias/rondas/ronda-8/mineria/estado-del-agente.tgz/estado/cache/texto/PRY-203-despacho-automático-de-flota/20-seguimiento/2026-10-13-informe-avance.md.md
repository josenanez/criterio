<!-- origen: PRY-203-despacho-automático-de-flota/20-seguimiento/2026-10-13-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Despacho automático de flota

**Código:** PRY-203
**Fecha de corte:** 2026-10-13
**Gerente:** Jorge Medina

## Estado declarado

**Verde**

Avance reportado: **36%**

## Lo que pasó en el periodo

- Se recibió el permiso ambiental pendiente desde el trimestre anterior
- Se levantó un hallazgo en la auditoría de seguridad
- El proveedor entregó los equipos en el campamento, pendientes de aceptación

## Presupuesto

| | COP |
|---|---|
| Aprobado | 800.000.000 |
| Comprometido | 458.388.139 |
| Ejecutado | 180.007.183 |
| Proyección al cierre | 787.823.857 |

## Riesgos abiertos

- Ventana de parada de planta definida por operaciones
- Cambio en la licencia ambiental que puede mover el alcance
