<!-- origen: PRY-204-monitoreo-de-taludes/00-gobierno/2025-08-19-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Monitoreo de taludes

Código: PRY-204

Área dueña: Geología

Patrocinador: Jorge Medina

Gerente de proyecto: Beatriz Cuéllar

Comité: Comité de Seguridad

Producto asociado: alerta de taludes

Fecha de aprobación: 2025-08-19

Objetivo del negocio

Entregar monitoreo de taludes para Geología.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

800.000.000 COP, aprobado por Comité de Seguridad el 2025-08-19.

Fechas comprometidas

Fecha

Inicio

2025-08-29

Cierre

2026-03-31

Criterio de éxito

Monitoreo de taludes en producción y medido.

Dependencias declaradas

• Ninguna declarada
