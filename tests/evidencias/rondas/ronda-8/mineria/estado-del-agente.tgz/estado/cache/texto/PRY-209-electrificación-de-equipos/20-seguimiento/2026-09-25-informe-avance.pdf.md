<!-- origen: PRY-209-electrificación-de-equipos/20-seguimiento/2026-09-25-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Electrificación de equipos
Código: PRY-209
Fecha de corte: 2026-09-25
Gerente: Rubén Cárdenas

Estado declarado
Verde
Avance reportado: 36%

Lo que pasó en el periodo
- Se recibió el permiso ambiental pendiente desde el trimestre anterior
- Se actualizó el presupuesto de la obra con el área de compras
- El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite

Presupuesto
COP
Aprobado 6.800.000.000
Comprometido 3.691.737.469
Ejecutado 2.547.469.156
Proyección al cierre 6.850.769.572

Riesgos abiertos
- Concentración del conocimiento en una sola persona
- Bloqueo de la vía de acceso a la mina
