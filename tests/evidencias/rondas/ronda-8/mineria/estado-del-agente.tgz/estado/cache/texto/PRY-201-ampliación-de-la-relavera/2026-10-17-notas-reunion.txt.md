<!-- origen: PRY-201-ampliación-de-la-relavera/2026-10-17-notas-reunion.txt · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

notas reunión ampliación de la relavera — 2026-10-17
estuvieron: Andrés Lozano, Felipe Arango, Gustavo Neira, Javier Hoyos, Jorge Medina, Laura Vélez, Liliana Torres, María Restrepo, Mauricio Pérez, Paula Céspedes, Sandra Gil, Óscar Ramírez

- Paula Céspedes dice que lo de «enviar el documento 1» no alcanzó, se compromete para el 26/11/2026
- Laura Vélez queda de mandar el ajuste del presupuesto la otra semana
- Óscar Ramírez: revisión con el proveedor, queda para el 2026-10-27
- se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo
- próxima reunión en dos semanas
