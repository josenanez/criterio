<!-- origen: PRY-201-ampliación-de-la-relavera/00-gobierno/ficha-pm.json · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

{
 "schema_version": "0.2",
 "identity": {
 "code": {
 "value": "PRY-201",
 "source": "00-gobierno/2026-03-06-acta-constitucion.docx",
 "source_date": "2026-03-06",
 "state": "found"
 },
 "name": {
 "value": "Ampliación de la relavera",
 "source": "00-gobierno/2026-03-06-acta-constitucion.docx",
 "source_date": "2026-03-06",
 "state": "found"
 },
 "aliases": [],
 "business_area": {
 "value": "Logística",
 "source": "00-gobierno/2026-03-06-acta-constitucion.docx",
 "source_date": "2026-03-06",
 "state": "found"
 },
 "product": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "authority": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "sponsor": {
 "value": "María Restrepo",
 "source": "00-gobierno/2026-03-06-acta-constitucion.docx",
 "source_date": "2026-03-06",
 "state": "found"
 },
 "manager": {
 "value": "Mauricio Pérez",
 "source": "00-gobierno/2026-03-06-acta-constitucion.docx",
 "source_date": "2026-03-06",
 "state": "found"
 },
 "committee": {
 "value": "Comité de Operaciones",
 "source": "00-gobierno/2026-03-06-acta-constitucion.docx",
 "source_date": "2026-03-06",
 "state": "found"
 },
 "phase": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 }
 },
 "declared": {
 "status": {
 "value": "verde",
 "source": "20-seguimiento/2026-10-09-informe-avance.md",
 "source_date": "2026-10-09",
 "state": "found",
 "source_kind": "declaration"
 },
 "progress_pct": {
 "value": 29,
 "source": "20-seguimiento/2026-10-09-informe-avance.md",
 "source_date": "2026-10-09",
 "state": "found",
 "source_kind": "declaration"
 },
 "as_of": "2026-10-09",
 "source": "20-seguimiento/2026-10-09-informe-avance.md"
 },
 "plan": {
 "start_date": {
 "value": "2026-03-16",
 "source": "00-gobierno/2026-03-06-acta-constitucion.docx",
 "source_date": "2026-03-06",
 "state": "found"
 },
 "end_date": {
 "value": "2027-05-10",
 "source": "10-plan/2026-10-09-cronograma-v2.xlsx",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "baseline": [
 {
 "version": 1,
 "approved_on": "2026-03-06",
 "start_date": "2026-03-16",
 "end_date": "2027-02-03",
 "reason": "Línea base original del acta de constitución",
 "source": "00-gobierno/2026-03-06-acta-constitucion.docx"
 }
 ],
 "milestones": [
 {
 "name": {
 "value": "Ingeniería básica aprobada",
 "source": "10-plan/2026-10-09-cronograma-v2.xlsx",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "baseline_date": "2026-07-02",
 "current_date": "2026-07-02",
 "state": {
 "value": "met",
 "source": "10-plan/2026-10-09-cronograma-v2.xlsx",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "evidence": null,
 "source": "10-plan/2026-10-09-cronograma-v2.xlsx"
 },
 {
 "name": {
 "value": "Ingeniería de detalle aprobada",
 "source": "10-plan/2026-10-09-cronograma-v2.xlsx",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "baseline_date": "2026-10-18",
 "current_date": "2026-10-18",
 "state": {
 "value": "pending",
 "source": "10-plan/2026-10-09-cronograma-v2.xlsx",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "evidence": null,
 "source": "10-plan/2026-10-09-cronograma-v2.xlsx"
 },
 {
 "name": {
 "value": "Licencia y permisos obtenidos",
 "source": "10-plan/2026-10-09-cronograma-v2.xlsx",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "baseline_date": "2027-02-03",
 "current_date": "2027-05-10",
 "state": {
 "value": "pending",
 "source": "10-plan/2026-10-09-cronograma-v2.xlsx",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "evidence": null,
 "source": "10-plan/2026-10-09-cronograma-v2.xlsx"
 }
 ],
 "scope_summary": {
 "value": "Componentes 1, 2 y 3 (sin más detalle en el acta)",
 "source": "00-gobierno/2026-03-06-acta-constitucion.docx",
 "source_date": "2026-03-06",
 "state": "found"
 },
 "exclusions": {
 "value": "Lo que otro proyecto cubre",
 "source": "00-gobierno/2026-03-06-acta-constitucion.docx",
 "source_date": "2026-03-06",
 "state": "found"
 }
 },
 "money": {
 "currency": {
 "value": "COP",
 "source": "20-seguimiento/2026-10-09-informe-avance.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "approved": {
 "value": 4200000000,
 "source": "00-gobierno/2026-03-06-acta-constitucion.docx",
 "source_date": "2026-03-06",
 "state": "found"
 },
 "committed": {
 "value": 3527144366,
 "source": "20-seguimiento/2026-10-09-informe-avance.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "executed": {
 "value": 1393552576,
 "source": "20-seguimiento/2026-10-09-informe-avance.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "projection": {
 "value": 4269105906,
 "source": "20-seguimiento/2026-10-09-informe-avance.md",
 "source_date": "2026-10-09",
 "state": "found"
 }
 },
 "vendors": [
 {
 "name": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "contract_ref": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "deliverables": [
 {
 "name": "Equipos en el campamento",
 "due_date": null,
 "amount": null,
 "state": "delivered",
 "evidence": null
 }
 ],
 "invoiced": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "source": "20-seguimiento/2026-10-09-informe-avance.md"
 }
 ],
 "raid": {
 "risks": [
 {
 "what": "Concentración del conocimiento en una sola persona",
 "owner": null,
 "source": "20-seguimiento/2026-10-09-informe-avance.md"
 },
 {
 "what": "El proveedor no ha confirmado la fecha de la última entrega",
 "owner": null,
 "source": "20-seguimiento/2026-10-09-informe-avance.md"
 },
 {
 "what": "El proveedor podría no llegar con el equipo completo para la siguiente fase (dicho en la reunión; nadie lo registró)",
 "owner": null,
 "source": "2026-10-17-notas-reunion.txt"
 }
 ],
 "assumptions": [],
 "issues": [
 {
 "what": "Hallazgo levantado en la auditoría de seguridad",
 "since": "2026-10-09",
 "owner": null,
 "source": "20-seguimiento/2026-10-09-informe-avance.md"
 }
 ],
 "dependencies": []
 },
 "changes": [
 {
 "ref": "CC-01",
 "requested_on": "2026-10-05",
 "scope_impact": "Ampliación de alcance",
 "time_impact": "+96 días sobre la línea base vigente",
 "cost_impact": "192.000.000 COP adicionales",
 "decision": "pending",
 "decided_by": null,
 "source": "20-seguimiento/2026-10-05-solicitud-cambio-cc-01.md"
 }
 ],
 "commitments": [
 {
 "who": "Paula Céspedes",
 "what": "Enviar el documento 1",
 "due_date": "2026-11-26",
 "original_due_date": "2026-09-14",
 "stated_on": "2026-09-05",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-09-22",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md"
 },
 {
 "due_date": "2026-10-12",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md"
 },
 {
 "due_date": "2026-10-21",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md"
 },
 {
 "due_date": "2026-11-01",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 },
 {
 "due_date": "2026-11-12",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 },
 {
 "due_date": "2026-11-26",
 "stated_on": "2026-10-17",
 "source": "2026-10-17-notas-reunion.txt"
 }
 ]
 },
 {
 "who": "María Restrepo",
 "what": "Cerrar la prueba 2",
 "due_date": "2026-11-28",
 "original_due_date": "2026-09-12",
 "stated_on": "2026-09-05",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-09-25",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md"
 },
 {
 "due_date": "2026-10-10",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md"
 },
 {
 "due_date": "2026-10-25",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md"
 },
 {
 "due_date": "2026-11-14",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 },
 {
 "due_date": "2026-11-28",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Felipe Arango",
 "what": "Revisar el anexo 3",
 "due_date": "2026-09-10",
 "original_due_date": "2026-09-10",
 "stated_on": "2026-09-05",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-10-03-acta-recibo-3.md"
 },
 {
 "who": "Felipe Arango",
 "what": "Validar el ambiente 4",
 "due_date": "2026-10-31",
 "original_due_date": "2026-10-02",
 "stated_on": "2026-09-05",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "state": "met",
 "reschedules": [
 {
 "due_date": "2026-10-22",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md"
 },
 {
 "due_date": "2026-10-31",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md"
 }
 ],
 "evidence": "20-seguimiento/2026-10-03-acta-recibo-4.md"
 },
 {
 "who": "Andrés Lozano",
 "what": "Aprobar el diseño 5",
 "due_date": "2026-10-15",
 "original_due_date": "2026-09-22",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-01",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md"
 },
 {
 "due_date": "2026-10-15",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Mauricio Pérez",
 "what": "Actualizar la matriz 6",
 "due_date": "2026-09-15",
 "original_due_date": "2026-09-15",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Mauricio Pérez",
 "what": "Confirmar la fecha 7",
 "due_date": "2026-10-09",
 "original_due_date": "2026-10-09",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-10-03-acta-recibo-7.md"
 },
 {
 "who": "Óscar Ramírez",
 "what": "Entregar el punto 8",
 "due_date": "2026-10-02",
 "original_due_date": "2026-10-02",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Liliana Torres",
 "what": "Enviar el documento 9",
 "due_date": "2026-11-16",
 "original_due_date": "2026-10-11",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-28",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md"
 },
 {
 "due_date": "2026-11-16",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Felipe Arango",
 "what": "Cerrar la prueba 10",
 "due_date": "2026-10-17",
 "original_due_date": "2026-10-06",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-17",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "who": "María Restrepo",
 "what": "Revisar el anexo 11",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Felipe Arango",
 "what": "Validar el ambiente 12",
 "due_date": "2026-10-22",
 "original_due_date": "2026-10-12",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-22",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Laura Vélez",
 "what": "Aprobar el diseño 13",
 "due_date": "2026-10-21",
 "original_due_date": "2026-09-30",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-21",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Sandra Gil",
 "what": "Actualizar la matriz 14",
 "due_date": "2026-10-02",
 "original_due_date": "2026-10-02",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-10-03-acta-recibo-14.md"
 },
 {
 "who": "Sandra Gil",
 "what": "Confirmar la fecha 15",
 "due_date": "2026-10-17",
 "original_due_date": "2026-10-07",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-17",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Felipe Arango",
 "what": "Entregar el punto 16",
 "due_date": "2026-10-19",
 "original_due_date": "2026-10-12",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-19",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Andrés Lozano",
 "what": "Enviar el documento 17",
 "due_date": "2026-10-30",
 "original_due_date": "2026-10-17",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-30",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Javier Hoyos",
 "what": "Cerrar la prueba 18",
 "due_date": "2026-10-25",
 "original_due_date": "2026-10-25",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Óscar Ramírez",
 "what": "Revisar el anexo 19",
 "due_date": "2026-10-11",
 "original_due_date": "2026-10-11",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Gustavo Neira",
 "what": "Validar el ambiente 20",
 "due_date": "2026-10-08",
 "original_due_date": "2026-10-08",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Gustavo Neira",
 "what": "Aprobar el diseño 21",
 "due_date": "2026-10-19",
 "original_due_date": "2026-10-19",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Mauricio Pérez",
 "what": "Actualizar la matriz 22",
 "due_date": "2026-11-05",
 "original_due_date": "2026-11-05",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Andrés Lozano",
 "what": "Confirmar la fecha 23",
 "due_date": "2026-11-04",
 "original_due_date": "2026-11-04",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Jorge Medina",
 "what": "Entregar el punto 24",
 "due_date": "2026-10-13",
 "original_due_date": "2026-10-13",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Óscar Ramírez",
 "what": "Revisión con el proveedor",
 "due_date": "2026-10-27",
 "original_due_date": "2026-10-27",
 "stated_on": "2026-10-17",
 "source": "2026-10-17-notas-reunion.txt",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Laura Vélez",
 "what": "Mandar el ajuste del presupuesto",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-10-17",
 "source": "2026-10-17-notas-reunion.txt",
 "state": "open",
 "reschedules": []
 }
 ],
 "meta": {
 "record_updated": "2026-10-17",
 "documents_seen": [],
 "fields_not_found": [
 "identity.product",
 "identity.authority",
 "identity.phase",
 "vendors.name",
 "vendors.contract_ref",
 "vendors.invoiced"
 ],
 "open_conflicts": []
 }
}
