# Comité de Transformación Digital · Tienda en línea

**Fecha:** 2026-10-03
**Asistentes:** Andrés Lozano, Beatriz Cuéllar, Camilo Beltrán, Felipe Arango, Javier Hoyos, Jorge Medina, Liliana Torres, María Restrepo, Mauricio Pérez, Natalia Ospina, Rubén Cárdenas, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Beatriz Cuéllar | Enviar el documento 1 | 2026-11-25 |
| Óscar Ramírez | Cerrar la prueba 2 | 2026-11-09 |
| Camilo Beltrán | Revisar el anexo 3 | 2026-10-22 |
| Natalia Ospina | Aprobar el diseño 5 | 2026-09-30 |
| Jorge Medina | Actualizar la matriz 6 | 2026-10-23 |
| Javier Hoyos | Confirmar la fecha 7 | 2026-09-26 |
| Felipe Arango | Aprobar el diseño 13 | 2026-10-10 |
| Andrés Lozano | Actualizar la matriz 14 | 2026-10-08 |
| Mauricio Pérez | Confirmar la fecha 15 | 2026-10-18 |
| Mauricio Pérez | Entregar el punto 16 | 2026-10-08 |
| María Restrepo | Enviar el documento 17 | 2026-10-19 |
| María Restrepo | Cerrar la prueba 18 | 2026-10-23 |
| Liliana Torres | Revisar el anexo 19 | 2026-10-09 |
| Felipe Arango | Validar el ambiente 20 | 2026-10-12 |

## Lo que se dijo

- Ricardo Salas dice que ya entregó «enviar el documento 9». No se presentó acta.
- Beatriz Cuéllar dice que ya entregó «revisar el anexo 11». No se presentó acta.
