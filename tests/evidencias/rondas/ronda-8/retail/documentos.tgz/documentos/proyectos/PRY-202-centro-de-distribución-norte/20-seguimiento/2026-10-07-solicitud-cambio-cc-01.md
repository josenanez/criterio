# Solicitud de cambio CC-01

**Proyecto:** PRY-202 · Centro de distribución norte
**Fecha:** 2026-10-07
**Solicitante:** Elena Duarte

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +52 días sobre la línea base vigente |
| Costo | 104.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
