# Comité de Expansión · Pago con QR en caja

**Fecha:** 2026-10-11
**Asistentes:** Jorge Medina, Liliana Torres

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Beatriz Cuéllar | Entregar el punto 9 | 2026-10-19 |
| Paula Céspedes | Entregar el punto 19 | 2026-11-09 |
