# Solicitud de cambio CC-01

**Proyecto:** PRY-205 · Pago con QR en caja
**Fecha:** 2026-10-09
**Solicitante:** Jorge Medina

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +107 días sobre la línea base vigente |
| Costo | 214.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
