# Solicitud de cambio CC-01

**Proyecto:** PRY-201 · Programa de fidelización
**Fecha:** 2026-10-14
**Solicitante:** Rubén Cárdenas

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +33 días sobre la línea base vigente |
| Costo | 66.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
