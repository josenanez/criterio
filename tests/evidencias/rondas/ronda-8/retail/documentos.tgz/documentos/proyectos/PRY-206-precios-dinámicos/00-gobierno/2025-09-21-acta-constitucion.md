# Acta de constitución · Precios dinámicos

**Código:** PRY-206
**Área dueña:** Comercio electrónico
**Patrocinador:** Ricardo Salas
**Gerente de proyecto:** Rubén Cárdenas
**Comité:** Comité de Expansión
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-09-21

## Objetivo del negocio

Entregar precios dinámicos para Comercio electrónico.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**9.500.000.000 COP**, aprobado por Comité de Expansión el 2025-09-21.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-10-01 |
| Cierre | 2026-07-02 |

## Criterio de éxito

Precios dinámicos en producción y medido.

## Dependencias declaradas

- Ninguna declarada
