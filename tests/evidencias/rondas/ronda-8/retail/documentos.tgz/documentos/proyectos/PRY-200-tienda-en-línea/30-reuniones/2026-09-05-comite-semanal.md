# Comité de Transformación Digital · Tienda en línea

**Fecha:** 2026-09-05
**Asistentes:** Beatriz Cuéllar, Camilo Beltrán, María Restrepo, Rubén Cárdenas, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Beatriz Cuéllar | Enviar el documento 1 | 2026-09-28 |
| Óscar Ramírez | Cerrar la prueba 2 | 2026-09-25 |
| Camilo Beltrán | Revisar el anexo 3 | 2026-09-20 |
| María Restrepo | Validar el ambiente 4 | 2026-09-24 |
