# Comité de Transformación Digital · Tienda en línea

**Fecha:** 2026-10-10
**Asistentes:** Andrés Lozano, Beatriz Cuéllar, Camilo Beltrán, Felipe Arango, Javier Hoyos, Jorge Medina, Liliana Torres, María Restrepo, Mauricio Pérez, Ricardo Salas, Rubén Cárdenas, Sandra Gil, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Beatriz Cuéllar | Enviar el documento 1 | 2026-12-05 |
| Óscar Ramírez | Cerrar la prueba 2 | 2026-11-22 |
| Camilo Beltrán | Revisar el anexo 3 | 2026-11-07 |
| Jorge Medina | Actualizar la matriz 6 | 2026-11-10 |
| Javier Hoyos | Confirmar la fecha 7 | 2026-10-18 |
| Felipe Arango | Aprobar el diseño 13 | 2026-10-10 |
| Andrés Lozano | Actualizar la matriz 14 | 2026-10-28 |
| Mauricio Pérez | Confirmar la fecha 15 | 2026-10-25 |
| María Restrepo | Enviar el documento 17 | 2026-11-07 |
| María Restrepo | Cerrar la prueba 18 | 2026-10-23 |
| Liliana Torres | Revisar el anexo 19 | 2026-10-09 |
| Felipe Arango | Validar el ambiente 20 | 2026-10-12 |
| Camilo Beltrán | Aprobar el diseño 21 | 2026-10-18 |
| Sandra Gil | Actualizar la matriz 22 | 2026-10-14 |
| Mauricio Pérez | Confirmar la fecha 23 | 2026-10-13 |
| Ricardo Salas | Entregar el punto 24 | 2026-10-15 |

## Cerrados en esta reunión

- Entregar el punto 16 (Mauricio Pérez): recibido, acta de recibo del 2026-10-10.

## Lo que se dijo

- Natalia Ospina dice que ya entregó «aprobar el diseño 5». No se presentó acta.
