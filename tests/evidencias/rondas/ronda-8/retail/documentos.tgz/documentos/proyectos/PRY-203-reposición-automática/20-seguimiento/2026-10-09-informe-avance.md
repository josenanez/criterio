# Informe de avance · Reposición automática

**Código:** PRY-203
**Fecha de corte:** 2026-10-09
**Gerente:** Mauricio Pérez

## Estado declarado

**Verde**

Avance reportado: **28%**

## Lo que pasó en el periodo

- Se levantó un hallazgo de seguridad en los medios de pago

## Presupuesto

| | COP |
|---|---|
| Aprobado | 3.300.000.000 |
| Comprometido | 1.237.905.774 |
| Ejecutado | 1.231.240.132 |
| Proyección al cierre | 3.302.588.164 |

## Riesgos abiertos

- Congelamiento de cambios en temporada alta
- El proveedor no ha confirmado la fecha de la última entrega
