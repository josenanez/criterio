# Acta de constitución · Reposición automática

**Código:** PRY-203
**Área dueña:** Tecnología
**Patrocinador:** Gustavo Neira
**Gerente de proyecto:** Mauricio Pérez
**Comité:** Comité de Cadena de Abastecimiento
**Producto asociado:** No aplica
**Fecha de aprobación:** 2026-03-28

## Objetivo del negocio

Entregar reposición automática para Tecnología.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**3.300.000.000 COP**, aprobado por Comité de Cadena de Abastecimiento el 2026-03-28.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-04-07 |
| Cierre | 2026-12-05 |

## Criterio de éxito

Reposición automática en producción y medido.

## Dependencias declaradas

- Ninguna declarada
