# Acta de constitución · Marca propia de alimentos

**Código:** PRY-207
**Área dueña:** Logística
**Patrocinador:** Javier Hoyos
**Gerente de proyecto:** Ricardo Salas
**Comité:** Comité de Cadena de Abastecimiento
**Producto asociado:** marca propia
**Fecha de aprobación:** 2026-04-29

## Objetivo del negocio

Entregar marca propia de alimentos para Logística.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**3.300.000.000 COP**, aprobado por Comité de Cadena de Abastecimiento el 2026-04-29.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-05-09 |
| Cierre | 2027-05-18 |

## Criterio de éxito

Marca propia de alimentos en producción y medido.

## Dependencias declaradas

- Ninguna declarada
