# Informe de avance · Pronóstico de demanda

**Código:** PRY-211
**Fecha de corte:** 2026-09-30
**Gerente:** Beatriz Cuéllar

## Estado declarado

**Verde**

Avance reportado: **43%**

## Lo que pasó en el periodo

- La validación con dos tiendas se extendió una semana por el conteo de inventario
- Se levantó un hallazgo de seguridad en los medios de pago

## Presupuesto

| | COP |
|---|---|
| Aprobado | 3.300.000.000 |
| Comprometido | 1.100.978.231 |
| Ejecutado | 1.403.708.177 |
| Proyección al cierre | 3.055.066.406 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
