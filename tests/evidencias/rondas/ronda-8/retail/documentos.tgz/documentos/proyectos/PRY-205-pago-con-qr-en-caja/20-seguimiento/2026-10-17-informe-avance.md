# Informe de avance · Pago con QR en caja

**Código:** PRY-205
**Fecha de corte:** 2026-10-17
**Gerente:** Jorge Medina

## Estado declarado

**Amarillo**

Avance reportado: **30%**

## Lo que pasó en el periodo

- Se recibió el concepto de Jurídica sobre los términos de uso
- El equipo perdió dos semanas por rotación de un desarrollador clave

## Presupuesto

| | COP |
|---|---|
| Aprobado | 1.200.000.000 |
| Comprometido | 832.019.377 |
| Ejecutado | 530.498.809 |
| Proyección al cierre | 1.466.019.411 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
