# Caso de negocio · Pago con QR

**Código:** PRD-303
**Fecha:** 2026-05-17
**Preparado por:** Felipe Arango

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 205.546 | Caso de negocio, 2026-05-17 |

## Retorno esperado

Retorno esperado en 24 meses.
