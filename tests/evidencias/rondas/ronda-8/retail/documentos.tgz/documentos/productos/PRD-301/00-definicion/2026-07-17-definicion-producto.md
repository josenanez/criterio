# Definición de producto · Puntos de fidelización

**Código:** PRD-301
**Gerente de producto:** Natalia Ospina
**Segmento:** Pequeños negocios
**Fecha de la definición:** 2026-07-17

## El problema

El segmento Pequeños negocios no tiene puntos de fidelización.

## La propuesta

- Propuesta principal

## Supuestos

- **El proveedor cumple el tiempo pactado** · declarado el 2026-09-09 · verificado con la medición del piloto del 2026-09-23 (anexo «Verificación del supuesto» del 2026-09-23)

## Proyectos que lo construyen

- Ninguno declarado
