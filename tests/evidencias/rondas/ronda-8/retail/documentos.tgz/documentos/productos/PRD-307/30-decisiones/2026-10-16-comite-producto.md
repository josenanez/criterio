# Comité de producto · Compra y recoge

**Fecha:** 2026-10-16
**Asistentes:** Diana Molina

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4700 | Requerimiento REQ-4700 | María Restrepo | se verifica en producción | — | aceptado | 2026-04-01 | — |
| REQ-4701 | Requerimiento REQ-4701 | Ricardo Salas | se verifica en producción | Cliente entrevistado | aceptado | 2026-09-02 | — |
| REQ-4702 | Requerimiento REQ-4702 | Camilo Beltrán | se verifica en producción | Cliente entrevistado | propuesto | 2026-03-18 | — |
| REQ-4703 | Requerimiento REQ-4703 | sin asignar | se verifica en producción | — | aceptado | 2026-04-10 | — |
| REQ-4704 | Requerimiento REQ-4704 | Gustavo Neira | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-12 | — |
| REQ-4705 | Requerimiento REQ-4705 | Paula Céspedes | se verifica en producción | — | aceptado | 2026-08-10 | — |
| REQ-4706 | Requerimiento REQ-4706 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-22 | — |
| REQ-4707 | Requerimiento REQ-4707 | Ricardo Salas | se verifica en producción | Cliente entrevistado | propuesto | 2026-08-18 | — |
| REQ-4708 | Requerimiento REQ-4708 | Jorge Medina | se verifica en producción | — | aceptado | 2026-09-02 | — |
| REQ-4709 | Requerimiento REQ-4709 | sin asignar | se verifica en producción | — | aceptado | 2026-07-26 | — |
| REQ-4710 | Requerimiento REQ-4710 | Liliana Torres | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-11 | — |
| REQ-4711 | Requerimiento REQ-4711 | Rubén Cárdenas | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-02 | — |
| REQ-4712 | Requerimiento REQ-4712 | Elena Duarte | se verifica en producción | — | propuesto | 2026-06-11 | — |
| REQ-4713 | Requerimiento REQ-4713 | Diana Molina | se verifica en producción | Cliente entrevistado | propuesto | 2026-04-21 | — |
| REQ-2028 | Requerimiento REQ-2028 | Camilo Beltrán | se verifica en producción | Cliente entrevistado | aceptado | 2026-10-06 | — |
| REQ-2036 | Requerimiento REQ-2036 | Laura Vélez | se verifica en producción | Cliente entrevistado | aceptado | 2026-10-15 | — |

## Decisiones

- Se mantiene el plan
