# Caso de negocio · App de clientes

**Código:** PRD-306
**Fecha:** 2026-02-27
**Preparado por:** Natalia Ospina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 105.881 | Caso de negocio, 2026-02-27 |

## Retorno esperado

Retorno esperado en 24 meses.
