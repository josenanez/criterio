# Definición de producto · Marketplace

**Código:** PRD-308
**Gerente de producto:** Natalia Ospina
**Segmento:** Jóvenes
**Fecha de la definición:** 2026-07-20

## El problema

El segmento Jóvenes no tiene marketplace.

## La propuesta

- Propuesta principal

## Supuestos

- **La demanda se sostiene sin descuento** · declarado el 2026-06-09 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
