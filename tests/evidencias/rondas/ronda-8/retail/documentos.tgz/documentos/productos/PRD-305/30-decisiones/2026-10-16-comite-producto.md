# Comité de producto · Entrega rápida

**Fecha:** 2026-10-16
**Asistentes:** Laura Vélez

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4500 | Requerimiento REQ-4500 | Liliana Torres | se verifica en producción | — | propuesto | 2026-07-31 | — |
| REQ-4501 | Requerimiento REQ-4501 | Camilo Beltrán | — | Cliente entrevistado | aceptado | 2026-06-05 | — |
| REQ-4502 | Requerimiento REQ-4502 | Liliana Torres | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-20 | — |
| REQ-4503 | Requerimiento REQ-4503 | Rubén Cárdenas | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-13 | — |
| REQ-4504 | Requerimiento REQ-4504 | Paula Céspedes | se verifica en producción | Cliente entrevistado | propuesto | 2026-06-12 | — |
| REQ-4505 | Requerimiento REQ-4505 | María Restrepo | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-08 | — |
| REQ-4506 | Requerimiento REQ-4506 | Natalia Ospina | se verifica en producción | — | propuesto | 2026-08-20 | — |
| REQ-4507 | Requerimiento REQ-4507 | Felipe Arango | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-25 | — |
| REQ-4508 | Requerimiento REQ-4508 | Carlos Peña | — | — | propuesto | 2026-06-25 | — |
| REQ-4509 | Requerimiento REQ-4509 | Mauricio Pérez | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-16 | — |
| REQ-4510 | Requerimiento REQ-4510 | Mauricio Pérez | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-03 | — |
| REQ-4511 | Requerimiento REQ-4511 | Óscar Ramírez | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-19 | — |
| REQ-4512 | Requerimiento REQ-4512 | Mauricio Pérez | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-10 | — |
| REQ-4513 | Requerimiento REQ-4513 | Mauricio Pérez | — | Cliente entrevistado | propuesto | 2026-03-30 | — |

## Decisiones

- Se mantiene el plan
