# Definición de producto · App de clientes

**Código:** PRD-306
**Gerente de producto:** Natalia Ospina
**Segmento:** Hogares
**Fecha de la definición:** 2026-02-27

## El problema

El segmento Hogares no tiene app de clientes.

## La propuesta

- Propuesta principal

## Supuestos

- **La demanda se sostiene sin descuento** · declarado el 2026-03-19 · verificado con la entrevista con doce clientes del segmento del 2026-04-08 (anexo «Verificación del supuesto» del 2026-04-08)

## Proyectos que lo construyen

- Ninguno declarado
