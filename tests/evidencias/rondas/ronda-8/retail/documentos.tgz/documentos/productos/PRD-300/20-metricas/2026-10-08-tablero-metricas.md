# Tablero de métricas · Venta en línea

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-08

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 182.059 | 2026-10-08 |
