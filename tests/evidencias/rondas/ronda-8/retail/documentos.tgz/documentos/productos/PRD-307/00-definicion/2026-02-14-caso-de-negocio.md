# Caso de negocio · Compra y recoge

**Código:** PRD-307
**Fecha:** 2026-02-14
**Preparado por:** Diana Molina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 287.888 | Caso de negocio, 2026-02-14 |

## Retorno esperado

Retorno esperado en 24 meses.
