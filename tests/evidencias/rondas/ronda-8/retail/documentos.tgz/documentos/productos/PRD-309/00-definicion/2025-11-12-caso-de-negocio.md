# Caso de negocio · Tarjeta de la tienda

**Código:** PRD-309
**Fecha:** 2025-11-12
**Preparado por:** Elena Duarte

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 106.991 | Caso de negocio, 2025-11-12 |

## Retorno esperado

Retorno esperado en 24 meses.
