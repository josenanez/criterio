# Definición de producto · Compra y recoge

**Código:** PRD-307
**Gerente de producto:** Diana Molina
**Segmento:** Clientes frecuentes
**Fecha de la definición:** 2026-02-14

## El problema

El segmento Clientes frecuentes no tiene compra y recoge.

## La propuesta

- Propuesta principal

## Supuestos

- **La demanda se sostiene sin descuento** · declarado el 2026-06-08 · verificado con la entrevista con doce clientes del segmento del 2026-09-07 (anexo «Verificación del supuesto» del 2026-09-07)

## Proyectos que lo construyen

- Ninguno declarado
