# Comité de producto · Tarjeta de la tienda

**Fecha:** 2026-10-16
**Asistentes:** Elena Duarte

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4900 | Requerimiento REQ-4900 | Diana Molina | — | Cliente entrevistado | propuesto | 2026-07-04 | — |
| REQ-4901 | Requerimiento REQ-4901 | Beatriz Cuéllar | — | Cliente entrevistado | aceptado | 2026-05-17 | — |
| REQ-4902 | Requerimiento REQ-4902 | Ricardo Salas | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-06 | — |
| REQ-4903 | Requerimiento REQ-4903 | Beatriz Cuéllar | se verifica en producción | — | aceptado | 2026-06-14 | — |
| REQ-4904 | Requerimiento REQ-4904 | Beatriz Cuéllar | se verifica en producción | — | propuesto | 2026-08-01 | — |
| REQ-4905 | Requerimiento REQ-4905 | Óscar Ramírez | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-01 | — |
| REQ-4906 | Requerimiento REQ-4906 | Mauricio Pérez | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-18 | — |
| REQ-4907 | Requerimiento REQ-4907 | Laura Vélez | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-21 | — |
| REQ-4908 | Requerimiento REQ-4908 | Sandra Gil | se verifica en producción | — | propuesto | 2026-08-08 | — |
| REQ-4909 | Requerimiento REQ-4909 | sin asignar | se verifica en producción | Cliente entrevistado | propuesto | 2026-05-18 | — |
| REQ-4910 | Requerimiento REQ-4910 | Óscar Ramírez | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-24 | — |
| REQ-4911 | Requerimiento REQ-4911 | Carlos Peña | — | — | aceptado | 2026-07-29 | — |
| REQ-4912 | Requerimiento REQ-4912 | Gustavo Neira | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-30 | — |
| REQ-4913 | Requerimiento REQ-4913 | sin asignar | — | Cliente entrevistado | aceptado | 2026-04-21 | — |
| REQ-2028 | Requerimiento REQ-2028 | Laura Vélez | — | Cliente entrevistado | aceptado | 2026-09-22 | — |

## Decisiones

- Se mantiene el plan
