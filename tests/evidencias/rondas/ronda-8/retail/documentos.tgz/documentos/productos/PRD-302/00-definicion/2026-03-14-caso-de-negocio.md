# Caso de negocio · Autopago en tienda

**Código:** PRD-302
**Fecha:** 2026-03-14
**Preparado por:** Jorge Medina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 199.140 | Caso de negocio, 2026-03-14 |

## Retorno esperado

Retorno esperado en 24 meses.
