# Entrevistas · App de clientes

**Ronda:** Ronda · 2026-05-17
**Realizadas por:** Natalia Ospina

### Cliente entrevistado · 2026-05-17

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
