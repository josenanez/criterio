# Caso de negocio · Venta en línea

**Código:** PRD-300
**Fecha:** 2026-03-18
**Preparado por:** Mauricio Pérez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 298.990 | Caso de negocio, 2026-03-18 |

## Retorno esperado

Retorno esperado en 24 meses.
