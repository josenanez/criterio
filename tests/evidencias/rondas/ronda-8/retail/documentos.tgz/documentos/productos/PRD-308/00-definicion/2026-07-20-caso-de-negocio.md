# Caso de negocio · Marketplace

**Código:** PRD-308
**Fecha:** 2026-07-20
**Preparado por:** Natalia Ospina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 110.759 | Caso de negocio, 2026-07-20 |

## Retorno esperado

Retorno esperado en 24 meses.
