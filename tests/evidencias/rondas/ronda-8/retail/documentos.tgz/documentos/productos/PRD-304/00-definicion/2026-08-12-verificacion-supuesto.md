# Verificación del supuesto · Marca propia

**Fecha:** 2026-08-12

**Supuesto:** La regulación de datos lo permite

**Con qué se verificó:** el concepto jurídico de cumplimiento del 2026-08-12

**Resultado:** se confirmó.
