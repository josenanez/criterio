# Caso de negocio · Marca propia

**Código:** PRD-304
**Fecha:** 2026-01-15
**Preparado por:** Liliana Torres

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 281.612 | Caso de negocio, 2026-01-15 |

## Retorno esperado

Retorno esperado en 24 meses.
