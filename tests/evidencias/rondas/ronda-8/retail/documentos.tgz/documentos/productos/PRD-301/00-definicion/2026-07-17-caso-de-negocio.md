# Caso de negocio · Puntos de fidelización

**Código:** PRD-301
**Fecha:** 2026-07-17
**Preparado por:** Natalia Ospina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 106.202 | Caso de negocio, 2026-07-17 |

## Retorno esperado

Retorno esperado en 24 meses.
