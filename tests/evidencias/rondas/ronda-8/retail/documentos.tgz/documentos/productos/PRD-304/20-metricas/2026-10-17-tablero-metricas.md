# Tablero de métricas · Marca propia

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-17

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 288.805 | 2026-10-17 |
