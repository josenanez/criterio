# Comité de producto · Venta en línea

**Fecha:** 2026-10-08
**Asistentes:** Mauricio Pérez

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4000 | Requerimiento REQ-4000 | Liliana Torres | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-12 | — |
| REQ-4001 | Requerimiento REQ-4001 | Laura Vélez | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-13 | — |
| REQ-4002 | Requerimiento REQ-4002 | Diana Molina | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-17 | — |
| REQ-4003 | Requerimiento REQ-4003 | Elena Duarte | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-20 | — |
| REQ-4004 | Requerimiento REQ-4004 | Andrés Lozano | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-25 | — |
| REQ-4005 | Requerimiento REQ-4005 | Camilo Beltrán | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-25 | — |
| REQ-4006 | Requerimiento REQ-4006 | Sandra Gil | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-28 | — |
| REQ-4007 | Requerimiento REQ-4007 | Gustavo Neira | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-18 | — |
| REQ-4008 | Requerimiento REQ-4008 | María Restrepo | se verifica en producción | Cliente entrevistado | propuesto | 2026-09-02 | — |
| REQ-4009 | Requerimiento REQ-4009 | Natalia Ospina | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-18 | — |
| REQ-4010 | Requerimiento REQ-4010 | Ricardo Salas | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-07 | — |
| REQ-4011 | Requerimiento REQ-4011 | Carlos Peña | se verifica en producción | Cliente entrevistado | propuesto | 2026-09-01 | — |
| REQ-4012 | Requerimiento REQ-4012 | Natalia Ospina | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-23 | — |
| REQ-4013 | Requerimiento REQ-4013 | Camilo Beltrán | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-30 | — |

## Decisiones

- Se mantiene el plan
