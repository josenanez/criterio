# Corrida del 2026-10-17 · product-spec

PRD-309 · 15 requerimientos · 43 s · 34 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 11 |
| `requirement_untraced` | 11 |
| `requirement_without_acceptance` | 4 |
| `requirement_undecided` | 4 |
| `requirement_accepted_without_evidence` | 2 |
| `requirement_without_owner` | 2 |

Borrador de especificación: 11 aceptados listados por identificador, 0 con contenido (el acta no dice qué se necesita). Criterio 'se verifica en producción' en 7 no es verificable, 4 sin criterio. Dije que no sé: necesidad, país, propuesta, quién decidió, plan, serie de volumen. No propuse criterios ni rellené vacíos.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

> **Borrador de trabajo, no especificación.** Lo cierra el gerente de producto (Elena Duarte); el Comité de producto lo aprueba. Este agente no firma ni aprueba. Términos vigentes (v1.1) aceptados por José Francisco Ñáñez el 2026-10-17; el comprobante ya existe y no se registró de nuevo.

# Especificación — Tarjeta de la tienda (PRD-309) · borrador del 2026-10-17

**Resultado en una línea:** de los 11 requerimientos aceptados, ninguno dice qué se necesita (el acta del comité solo trae el identificador). No hay texto del que salga una sección de comportamiento, y escribirla sería inventar. Lo que sigue es el esqueleto trazable y, sobre todo, los vacíos con dueño.

## Alcance

### Entra
Los requerimientos en `aceptado` (no hay ninguno en `en_construccion`). Entran **por identificador, sin contenido**:

REQ-2028, REQ-4901, REQ-4902, REQ-4903, REQ-4905, REQ-4906, REQ-4907, REQ-4910, REQ-4911, REQ-4912, REQ-4913.

Fuente única de los 11: `30-decisiones/2026-10-16-comite-producto.md`. Todos con título «Requerimiento REQ-xxxx», necesidad `not_found`, prioridad `not_found`, sin proyecto que los ejecute.

### No entra
- **Los 4 propuestos** (REQ-4900, 4904, 4908, 4909): nadie los ha decidido; especificarlos es escribir el documento dos veces.
- **Diseño y arquitectura**, **estimación** (esfuerzo, costo, fecha) y **aprobación**: no son de este comando.
- **Qué es la tarjeta** (qué ofrece, si es crédito o medio de pago, qué cobra, quién la emite): la definición solo dice «Propuesta principal», sin contenido. No lo escribo; tampoco puedo decir que queda fuera, porque nadie lo ha decidido. Va a Vacíos.
- **«El plan»** que el comité mantuvo el 2026-10-16: no hay plan en la carpeta.

## Criterios de aceptación
Prueba aplicada: dos personas distintas, mirando lo construido, llegan a la misma respuesta. **Ninguno la pasa.**

| Criterio | Requerimiento | Cómo se verifica | ¿Se puede medir hoy? |
|---|---|---|---|
| «se verifica en producción» | REQ-4902, 4903, 4905, 4906, 4907, 4910, 4912 (7) | No dice qué se observa, con qué umbral ni quién lo observa. Es un lugar, no un criterio. | No: no hay umbral, y la carpeta no tiene `20-metricas/`, así que nadie mide nada hoy. |
| *(ninguno)* | REQ-2028, 4901, 4911, 4913 (4) | — | — Sin criterio. |

No propongo criterios: sin saber qué hace cada requerimiento, cualquier cifra que escribiera sería mía, no del negocio.

## Supuestos sobre los que está escrita

| Supuesto | Verificado | Quién lo verificaría |
|---|---|---|
| «La regulación de datos lo permite» (declarado 2026-03-28) | Sí, según una nota del 2026-08-21 (`00-definicion/2026-08-21-verificacion-supuesto.md`). El concepto jurídico en que se apoya **no está en la carpeta**, y el supuesto no dice país ni dato. | Jurídico/cumplimiento de la organización; Elena Duarte lo incorpora a la carpeta. |
| Los clientes frecuentes son quienes quieren la tarjeta | No. La única entrevista (2025-10-11) no menciona el segmento. | Elena Duarte (descubrimiento). |
| La necesidad que citan 9 de los 11 aceptados es la de ese requerimiento | No. La entrevista «Lo necesito y hoy no lo tengo» no nombra ningún REQ ni dice qué se pidió; el acta atribuye el pedido a «Cliente entrevistado». Evidencia de 12 meses (en el umbral). | Doliente de cada requerimiento. |
| El volumen mensual de 106.991 (caso de negocio, 2025-11-12) | No: sin serie medida, y no se sabe qué cuenta (transacciones, tarjetas, clientes). | Elena Duarte con quien mida volumen. |

## Vacíos

| Qué falta decidir | Consecuencia de no decidirlo | Quién lo cierra |
|---|---|---|
| **Qué se necesita en cada uno de los 11** (necesidad en una frase) | No se puede escribir ninguna sección de comportamiento ni casos borde: la especificación está vacía de contenido. | El doliente de cada REQ (ver abajo) |
| **Criterio de aceptación** de REQ-2028, 4901, 4911, 4913 | No hay forma de saber cuándo están hechos. | Doliente: Laura Vélez (2028), Beatriz Cuéllar (4901), Carlos Peña (4911); REQ-4913 **sin doliente** |
| **Criterio medible** para los 7 con «se verifica en producción» | Se darán por buenos o malos según quién mire. | Doliente: Ricardo Salas (4902), Beatriz Cuéllar (4903), Óscar Ramírez (4905, 4910), Mauricio Pérez (4906), Laura Vélez (4907), Gustavo Neira (4912) |
| **Doliente de REQ-4913** | Aceptado y sin nadie que responda por él. | Elena Duarte nombra a la persona. |
| **Quién pidió REQ-4903 y REQ-4911** | Se van a construir y no tienen una sola cita de quien los pidió. | Beatriz Cuéllar (4903), Carlos Peña (4911) |
| **Quién decidió, y cuándo, los 11 aceptados** | Las fechas de decisión (2026-04-01 a 2026-09-22) son anteriores al acta del 2026-10-16, que no dice quién decidió. No hay documento de la decisión. | Comité de producto; Elena Duarte aporta el acta de cada fecha |
| **Criterio de éxito del producto** | Sin él la definición no se puede cerrar y no corresponde acta de constitución. | Elena Duarte / Comité de producto |
| **Contenido de la propuesta y país** | De ellos depende qué obligaciones normativas aplican (ver abajo) y el alcance de todo lo demás. | Elena Duarte |
| **Proyecto que construye cada requerimiento** (0 de 11 con proyecto; el más antiguo, REQ-4913, lleva 169 días sin proyecto) | Lo que se específique no tiene quién lo construya. Si algún otro equipo debe hacer algo, no hay nada acordado con ese equipo, porque no se sabe qué equipo. | Comité de producto, vía `/product-trace` |
| **Comportamiento en casos borde** | No definido para ninguno de los 11: no hay comportamiento base del cual derivarlos. | Doliente de cada REQ |
| **«Se mantiene el plan»** (acta, única decisión) | No hay plan en la carpeta; la decisión no tiene a qué referirse. | Elena Duarte |

**Obligaciones normativas sin resolver** (primer barrido, sin opinar sobre cumplimiento; país **no declarado**; no tengo la norma a la vista en ningún caso): autorización y finalidad en el tratamiento de datos personales de clientes frecuentes; consumidor financiero y medios de pago (si «tarjeta de la tienda» implica crédito o pago); protección al consumidor; retención y trazabilidad de transacciones; consentimiento y prueba al aceptar los términos de la tarjeta. Dueño: revisión jurídica de la organización; Elena Duarte le entrega país y propuesta. Es una lista de lo que podría tocar, no de lo que toca.

**Inconsistencia para su autor:** la definición está fechada 2025-11-12 pero contiene un supuesto «declarado el 2026-03-28» y una verificación del 2026-08-21. O se editó sin cambiar la fecha, o las fechas están mal.

## Requerimientos aceptados que esta especificación no cubre

| REQ | Título | Por qué no |
|---|---|---|
| REQ-2028 | Requerimiento REQ-2028 | Sin necesidad dicha, sin criterio, sin quién decidió. Sin evidencia propia (la entrevista no lo nombra). |
| REQ-4901 | Requerimiento REQ-4901 | Sin necesidad dicha ni criterio. |
| REQ-4902 | Requerimiento REQ-4902 | Sin necesidad dicha; criterio no verificable. |
| REQ-4903 | Requerimiento REQ-4903 | Sin necesidad dicha; criterio no verificable; **sin evidencia ni quien lo pidiera**. |
| REQ-4905 | Requerimiento REQ-4905 | Sin necesidad dicha; criterio no verificable. |
| REQ-4906 | Requerimiento REQ-4906 | Sin necesidad dicha; criterio no verificable. |
| REQ-4907 | Requerimiento REQ-4907 | Sin necesidad dicha; criterio no verificable. |
| REQ-4910 | Requerimiento REQ-4910 | Sin necesidad dicha; criterio no verificable. |
| REQ-4911 | Requerimiento REQ-4911 | Sin necesidad dicha ni criterio; **sin evidencia ni quien lo pidiera**. |
| REQ-4912 | Requerimiento REQ-4912 | Sin necesidad dicha; criterio no verificable. |
| REQ-4913 | Requerimiento REQ-4913 | Sin necesidad dicha, sin criterio, **sin doliente**. |

Cubiertos con contenido: **0 de 11**. Listados en el alcance por identificador: 11 de 11.

## Después
No ofrezco `/product-charter`: hay vacíos sin cerrar y el producto no tiene criterio de éxito. El paso útil ahora es que cada doliente escriba en una frase qué necesita su requerimiento; con eso este comando puede volver a correr y producir secciones reales.

---
**Pie:** sale del registro `estado-producto/PRD-309/requirements/` (15 requerimientos; 11 aceptados, 4 propuestos) construido el 2026-10-17 sobre el acta del 2026-10-16 · cubre 11 requerimientos por identificador, 0 con contenido · términos: https://www.josenanez.com/es/agents/criterio-pmo/legal
