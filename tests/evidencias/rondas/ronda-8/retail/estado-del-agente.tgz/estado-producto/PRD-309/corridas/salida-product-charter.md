> Términos vigentes (v1.1) aceptados por José Francisco Ñáñez el 2026-10-17; el comprobante ya existía y no se registró de nuevo.
> Verificación del paso 1: REQ-4901 está **aceptado**, pero le faltan criterios de aceptación, autoridad declarada del gerente del proyecto y quién lo aceptó. Respuesta tomada (sesión sin interfaz): seguir y marcarlos como vacíos del acta, sin rellenarlos.

# Acta de constitución — Tarjeta de la tienda · REQ-4901 · borrador del 2026-10-17
**Producto:** PRD-309 Tarjeta de la tienda · **Requerimientos:** REQ-4901

## Qué problema resuelve
«El segmento Clientes frecuentes no tiene tarjeta de la tienda.» (`00-definicion/2025-11-12-definicion-producto.docx`, 2025-11-12.)
**Lo que REQ-4901 pide dentro de ese problema no está dicho:** el acta del comité solo trae el identificador (`30-decisiones/2026-10-16-comite-producto.md`). Título «Requerimiento REQ-4901», necesidad `not_found`.

## Criterio de éxito
**Sin criterio.** REQ-4901 no tiene criterio de aceptación (columna «—» en el acta del 2026-10-16) y la definición del producto tampoco declara criterio de éxito. Sin él, el cierre del proyecto no se puede juzgar meses después. No propongo uno: sería mío, no del negocio.

## Alcance
### Entra
| REQ | Título | Evidencia que lo sostiene |
|---|---|---|
| REQ-4901 | Requerimiento REQ-4901 (sin descripción) | Entrevista del 2025-10-11: «Lo necesito y hoy no lo tengo.» **No nombra REQ-4901 ni dice qué se pidió**; es la más cercana. El acta atribuye el pedido a «Cliente entrevistado». Evidencia de 12 meses (en el umbral de envejecimiento). |

### No entra
| REQ | Título | Por qué no |
|---|---|---|
| REQ-4900, 4904, 4908, 4909 | (sin descripción) | Siguen en `propuesto`: nadie los ha decidido (acta 2026-10-16). |
| REQ-2028, 4902, 4903, 4905, 4906, 4907, 4910, 4911, 4912, 4913 | (sin descripción) | Aceptados, pero esta acta es solo para REQ-4901; ninguno fue pedido para este proyecto. Decide el gerente de producto si se suman. |
| Qué es la tarjeta (crédito, medio de pago, emisor, cobros) | — | La definición solo dice «Propuesta principal», sin contenido. No está decidido que quede fuera; es un vacío. |

## Gobierno
- **Patrocinador:** no está dicho en ningún documento.
- **Gerente propuesto:** no está dicho. Elena Duarte es gerente del **producto** (definición, 2025-11-12); no consta que sea gerente del proyecto, y asignar a una persona no es de este comando.
- **Comité:** Comité de producto (acta 2026-10-16; solo asistió Elena Duarte).
- **Autoridad del gerente del proyecto:** **no declarada.** Lo único declarado es que la autoridad del producto es el Comité de producto. Qué puede decidir el gerente por sí solo (alcance, gasto, fechas) no está dicho.
- **Doliente del requerimiento:** Beatriz Cuéllar (acta 2026-10-16).
- **Aceptación:** estado `aceptado` desde 2026-05-17 según el acta, que no dice quién lo aceptó. Esa fecha es anterior al acta y no hay documento de la decisión. La única decisión del acta es «Se mantiene el plan», y no hay plan en la carpeta.

## Supuestos que se llevan al proyecto
| Supuesto | Verificado | Se convierte en riesgo de |
|---|---|---|
| «La regulación de datos lo permite» (declarado 2026-03-28) | Sí, según nota del 2026-08-21 (`00-definicion/2026-08-21-verificacion-supuesto.md`); el concepto jurídico en que se apoya **no está en la carpeta**, y el supuesto no dice país ni dato | Sin doliente: lo propone Elena Duarte con Jurídico/cumplimiento. Queda como supuesto verificado sin soporte a la vista. |
| Los clientes frecuentes son quienes quieren la tarjeta | No: la única entrevista no menciona el segmento | Sin doliente: Elena Duarte (descubrimiento). |
| La entrevista del 2025-10-11 es el pedido de REQ-4901 | No: no nombra ningún REQ | Doliente propuesto: Beatriz Cuéllar. |
| Volumen mensual de 106.991 (caso de negocio, 2025-11-12) | No: sin serie medida, no se sabe qué cuenta | Sin doliente: Elena Duarte. |

Cada uno entra al registro RAID del proyecto como riesgo con doliente, una vez el gerente lo asuma.

## Restricciones normativas sin resolver
Primer barrido, sin opinar sobre cumplimiento. País **no declarado**; no tengo la norma a la vista en ningún caso.
| Qué toca | Obligación | Norma | Estado |
|---|---|---|---|
| Datos de clientes frecuentes | Autorización y finalidad del tratamiento de datos personales | No identificada (país no declarado) | Sin resolver; solo una nota de verificación sin el concepto jurídico |
| Si la tarjeta implica crédito o pago | Consumidor financiero y medios de pago | No identificada | Sin resolver |
| Venta al consumidor | Protección al consumidor | No identificada | Sin resolver |
| Transacciones | Retención y trazabilidad | No identificada | Sin resolver |
| Términos de la tarjeta | Consentimiento y prueba de aceptación | No identificada | Sin resolver |

Es una lista de lo que podría tocar, no de lo que toca.

## Vacíos de este acta
| Qué falta | Consecuencia de firmar sin eso | Quién lo cierra |
|---|---|---|
| Qué se necesita en REQ-4901 (necesidad en una frase) | El proyecto arranca sin saber qué construye | Beatriz Cuéllar |
| Criterio de aceptación de REQ-4901 y criterio de éxito del producto | El cierre no se puede juzgar | Beatriz Cuéllar / Elena Duarte / Comité de producto |
| Autoridad del gerente del proyecto | Escala todo o no escala nada | Comité de producto |
| Patrocinador y gerente del proyecto | Nadie recibe la ficha | Comité de producto |
| Quién aceptó REQ-4901 y con qué documento | La decisión no se puede rastrear | Comité de producto; Elena Duarte aporta el acta del 2026-05-17 |
| Evidencia de demanda que nombre el requerimiento | La demanda sigue sin sustento directo | Beatriz Cuéllar |
| Contenido de la propuesta y país | No se sabe qué normas aplican | Elena Duarte |
| Presupuesto e hitos | No hay presupuesto aprobado ni hitos declarados; no se inventan | Patrocinador |
| Inconsistencia de fechas: la definición es del 2025-11-12 pero cita un supuesto «declarado el 2026-03-28» y una verificación del 2026-08-21 | No se sabe qué versión de la definición se firma | Elena Duarte |

---
**Esto es un borrador.** Lo firma el Comité de producto, que es la autoridad declarada del producto. La ficha del proyecto **no se creó**: se crea después de la firma, con `portafolio.py init`, llenando identidad, `identity.product = PRD-309`, criterio de éxito, autoridad e hitos que el acta declare. El estado declarado (`declared`) queda vacío por diseño: lo declara el gerente.

**Sigue:** el gerente del proyecto —que la organización debe nombrar— instala `criterio-project` y corre `/pm-setup`; cuando publique su ficha con `/pm-publish`, `/product-trace` podrá confirmar la traza REQ-4901 → proyecto, y Alba sabrá si su producto se está construyendo sin preguntarle a nadie.
