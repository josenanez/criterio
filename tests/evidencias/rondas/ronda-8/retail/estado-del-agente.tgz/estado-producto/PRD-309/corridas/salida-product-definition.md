## Definición — Tarjeta de la tienda (PRD-309) · contrastada al 2026-10-17
**Documento:** `00-definicion/2025-11-12-definicion-producto.docx` (con el caso de negocio y la verificación del supuesto del 2026-08-21) · **del** 2025-11-12 · 7 afirmaciones

Términos vigentes (v1.1) aceptados por José Francisco Ñáñez el 2026-10-17; el comprobante ya existe, no se registró de nuevo. Criterio produce un borrador de trabajo: la verificación y la revisión jurídica son de la organización.

### Lo que la evidencia contradice
Nada. Ninguna fuente dice lo contrario de lo que afirma la definición. Eso no significa que esté sostenida: ver las secciones de abajo.

### El negocio y los datos
| Métrica | Declarado | Medido | Diferencia | Las dos fuentes y fechas |
|---|---|---|---|---|
| volumen_mensual | 106.991 | sin serie | no calculable | caso de negocio 2025-11-12 / sin fuente medida |

Ninguna pasa el umbral (20 %) porque no hay nada con qué comparar.

### Afirmaciones numéricas que nadie mide
| Afirma | De qué documento | No hay serie |
|---|---|---|
| volumen_mensual = 106.991 | `2025-11-12-caso-de-negocio.md` | La carpeta del producto no tiene `20-metricas/`. Nadie mide lo que el caso de negocio afirmó, a 11 meses de escrito. |
| Retorno esperado «en 24 meses» | `2025-11-12-caso-de-negocio.md` | Ni cifra ni base ni serie: no es contrastable. |

### No está dicho en ninguna parte
- **Criterio de éxito.** Ningún documento lo declara (`success` queda en `not_found`).
- **La propuesta.** La definición solo dice «Propuesta principal», sin contenido: qué es la tarjeta, qué ofrece, qué cobra, quién la emite.
- **El país.** No se declara, y de él depende la parte normativa.
- **Qué es «el plan» que el comité mantuvo el 2026-10-16.** No hay plan en la carpeta; la decisión «Se mantiene el plan» no tiene a qué referirse.
- **Quién decide.** La autoridad figura como «Comité de producto», pero el acta del 2026-10-16 solo registra a la gerente del producto como asistente. No hay otra persona nombrada que decida.
- **De dónde sale el 106.991 ni qué cuenta** (transacciones, tarjetas, clientes).
- **Que los clientes frecuentes sean quienes la quieren.** La definición lo da por hecho; la única entrevista no menciona el segmento.
- **Proyectos que construyen el producto:** «Ninguno declarado».

### Sostenida por un supuesto
| Supuesto | Días sin verificar | Qué haría falta para verificarlo |
|---|---|---|
| La regulación de datos lo permite | 0 pendientes: declarado el 2026-03-28, verificado el 2026-08-21 (146 días después; hoy van 203 desde que se declaró) | El concepto jurídico del 2026-08-21 **no está en la carpeta**: solo existe la nota que dice «se confirmó». Hace falta incorporarlo para poder citarlo, y que diga país y alcance. Además el supuesto no se puede desmentir como está escrito («la regulación de datos», sin país ni dato nombrado). |

Una inconsistencia de fechas para que la revise su autor: la definición está fechada el 2025-11-12 y contiene un supuesto «declarado el 2026-03-28» y una verificación del 2026-08-21. O el documento se editó después sin cambiar la fecha, o las fechas están mal.

### Sostenida por evidencia
| Afirmación | Sostenida por | De cuándo | Qué tan fuerte |
|---|---|---|---|
| El segmento Clientes frecuentes no tiene tarjeta de la tienda | Entrevista «Lo necesito y hoy no lo tengo» (cliente entrevistado), `10-descubrimiento/2025-10-11-entrevistas.docx` | 2025-10-11 | Débil: una sola voz, dicha («lo necesito»), sin pago ni compromiso, y no dice que pertenezca al segmento. |

Los 9 requerimientos con evidencia se apoyan en esa misma cita. Hay 2 aceptados sin ninguna evidencia (REQ-4903, REQ-4911).

### Evidencia que ya envejeció
| Afirmación | Lo más nuevo que la sostiene | Hace |
|---|---|---|
| Problema / necesidad del segmento (y los 11 requerimientos con evidencia, `evidence_stale`) | Entrevista del 2025-10-11 | 12 meses (umbral: 12) |

### Lo normativo que toca
Esto va a revisión jurídica, no la reemplaza. No dice si el producto cumple. País: **no declarado**.

| Qué toca | País | Obligación | Norma | Estado |
|---|---|---|---|---|
| Datos personales de clientes frecuentes (el propio supuesto lo reconoce) | no declarado | Autorización previa y finalidad; encargados del tratamiento | — | no tengo la norma a la vista |
| Una «tarjeta de la tienda» puede implicar crédito o medio de pago | no declarado | Consumidor financiero: información previa, reclamos, cobros; medios de pago | — | no tengo la norma a la vista |
| Protección al consumidor | no declarado | Información y condiciones al comprador | — | no tengo la norma a la vista |
| Retención y trazabilidad de transacciones | no declarado | Plazos de conservación | — | no tengo la norma a la vista |
| Consentimiento al aceptar términos de la tarjeta | no declarado | Firma y prueba del consentimiento | — | no tengo la norma a la vista |
| Verificación jurídica del supuesto de datos | no declarado | Concepto del 2026-08-21 | no está en la carpeta | sin resolver |

La definición no detalla qué dato recoge ni qué cobra, así que el barrido es una lista de lo que la propuesta podría tocar, no de lo que toca.

### Lo que falta para cerrar la definición
- **Criterio de éxito:** no declarado. Sin él la definición **no se puede cerrar**.
- **Problema:** declarado (2025-11-12).
- **Para quién:** declarado (Clientes frecuentes).
- **Quién decide:** el Comité de producto, sin decisor nombrado distinto de la gerente.
- Además: el contenido de la propuesta, el país, y una serie que mida el volumen mensual.

### Después
No hay supuestos sin verificar para convertir en riesgo. La definición no está cerrada, así que no corresponde `/product-charter`.
