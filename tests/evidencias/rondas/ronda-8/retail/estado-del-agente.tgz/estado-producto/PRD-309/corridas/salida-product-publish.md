**No publiqué la ficha.** La configuración de PRD-309 (`.criterio/producto/PRD-309/config.json`) no define ninguna carpeta de productos publicados, y en el espacio tampoco existe una carpeta `productos/publicados/`. Sin un sitio común acordado no hay dónde escribir `PRD-309.json`, y no lo invento: acordar ese sitio es una conversación de la organización, no un comando. En esta sesión nadie podía responder, así que no creé ninguna carpeta. Términos vigentes: v1.1, aceptados por José Francisco Ñáñez el 2026-10-17 (ya registrados, no se repitió el registro).

**Lo que publicaría, con corte al 2026-10-17:**

- **Producto:** PRD-309 · Tarjeta de la tienda · gerente Elena Duarte
- **Requerimientos:** 15 (11 aceptados, 4 propuestos), cada uno con id, título y estado
- **Proyectos:** 0. Ningún requerimiento tiene proyecto que lo ejecute (`traced` 0 de 15)
- **Métricas afirmadas:** 1
  - `volumen_mensual`: 106991.0, según `documentos/productos/PRD-309/00-definicion/2025-11-12-caso-de-negocio.md` (fecha de la fuente: 2025-11-12). No hay serie medida con la que contrastarla.
- **Segmento declarado:** Clientes frecuentes

**Qué significa para el cruce:** con 0 proyectos, `/product-overlap` no podría detectar el caso del mismo proyecto construyendo para dos dueños. Sí podría detectar la métrica compartida y el segmento.

**Pendiente para publicar:** acordar la carpeta común de fichas publicadas, ponerla en la configuración y volver a correr este comando.
