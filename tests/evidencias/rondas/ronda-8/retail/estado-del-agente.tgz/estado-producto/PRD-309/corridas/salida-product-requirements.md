## Registro — Tarjeta de la tienda (PRD-309) · al 2026-10-17
15 requerimientos · 11 decididos · 81.8% con evidencia · 0% con proyecto que lo ejecuta

### Se va a construir y nadie lo pidió
| REQ | Título | Estado | Doliente |
|---|---|---|---|
| REQ-4903 | Requerimiento REQ-4903 (el acta solo trae el identificador) | aceptado el 2026-06-14 | Beatriz Cuéllar |
| REQ-4911 | Requerimiento REQ-4911 (ídem) | aceptado el 2026-07-29 | Carlos Peña |

Ninguno trae una sola cita de quien lo pidió.

### Decidido y nadie lo está construyendo
Los 11 aceptados tienen proyecto = ninguno (0% con proyecto que los ejecute): REQ-2028 (2026-09-22), REQ-4901 (2026-05-17), REQ-4902 (2026-08-06), REQ-4903 (2026-06-14), REQ-4905 (2026-04-01), REQ-4906 (2026-08-18), REQ-4907 (2026-05-21), REQ-4910 (2026-07-24), REQ-4911 (2026-07-29), REQ-4912 (2026-04-30), REQ-4913 (2026-04-21).
El más antiguo lleva 169 días (REQ-4913, 2026-04-21) sin proyecto.

### Sin doliente, o con un área en vez de una persona
| REQ | Título | Dice |
|---|---|---|
| REQ-4909 | Requerimiento REQ-4909 | propuesto, sin doliente |
| REQ-4913 | Requerimiento REQ-4913 | aceptado, sin doliente |

Quien lo cierra: Elena Duarte (gerente del producto) nombra al doliente.

### Sin criterio de aceptación
| REQ | Título | Estado |
|---|---|---|
| REQ-2028 | Requerimiento REQ-2028 | aceptado |
| REQ-4901 | Requerimiento REQ-4901 | aceptado |
| REQ-4911 | Requerimiento REQ-4911 | aceptado |
| REQ-4913 | Requerimiento REQ-4913 | aceptado |

Solo los decididos. Quien lo cierra: el doliente de cada uno (REQ-4913 no tiene; primero hay que nombrarlo). Los propuestos no se cuentan.
Nota: el criterio que sí existe en los demás es «se verifica en producción» (visto en REQ-4903), que no es medible.

### Decidido sin documento que lo respalde
Los 11 aceptados citan el acta del comité del 2026-10-16, pero ninguno dice **quién decidió**, y las fechas de decisión (de 2026-04-01 a 2026-09-22) son anteriores al acta. No hay documento de la fecha en que se dice que se decidió.
| REQ | Quién decidió | Cuándo |
|---|---|---|
| los 11 aceptados | no consta | las fechas listadas arriba |

### Lleva meses y nadie lo decide
Umbral: 60 días.
| REQ | Título | Propuesto hace | Quién tiene la facultad |
|---|---|---|---|
| REQ-4909 | Requerimiento REQ-4909 | 152 días (2026-05-18) | Comité de producto |
| REQ-4900 | Requerimiento REQ-4900 | 105 días (2026-07-04) | Comité de producto |
| REQ-4904 | Requerimiento REQ-4904 | 77 días (2026-08-01) | Comité de producto |
| REQ-4908 | Requerimiento REQ-4908 | 70 días (2026-08-08) | Comité de producto |

La facultad es del Comité de producto (config); Elena Duarte lo lleva al comité. Se propone decidirlos, no cerrarlos por viejos. Si se descartan, que quede el documento.

### Evidencia vieja
| REQ | Lo más nuevo que lo sostiene | Hace |
|---|---|---|
| REQ-2028, 4900, 4901, 4902, 4905, 4906, 4907, 4909, 4910, 4912, 4913 (11) | Entrevista del 2025-10-11: «Lo necesito y hoy no lo tengo.» | 12 meses |

Es la misma entrevista para los 11, y no nombra ningún REQ ni dice qué se pidió: es la más cercana, no una prueba. Con evidencia de ese tipo, el 81.8% pesa menos de lo que parece.

## Por estado
| propuesto | aceptado | en construcción | entregado | descartado |
|---|---|---|---|---|
| 4 | 11 | 0 | 0 | 0 |

Sin descartados: no hay registro de nada que se haya decidido no hacer.

Siguiente paso: `/product-trace` para los 11 decididos sin proyecto.
