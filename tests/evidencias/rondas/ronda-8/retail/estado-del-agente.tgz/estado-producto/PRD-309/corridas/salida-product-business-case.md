# Caso de negocio — Tarjeta de la tienda (PRD-309) · borrador del 2026-10-17
**Desde:** la definición del 2025-11-12 y el caso de negocio del 2025-11-12 · **Cifras con fuente:** 1 de 1 (la única cifra es declarada; no hay ninguna medida)

Términos vigentes (v1.1) aceptados por José Francisco Ñáñez el 2026-10-17; el comprobante ya existía, no se registró de nuevo. Esto es un borrador de trabajo: las cifras son del negocio, y decidir es de quien tiene la autoridad (Comité de producto).

**Lo primero: con lo que hay en la carpeta esto todavía no es un caso de negocio, es una propuesta.** No hay ningún costo con fuente, no hay criterio de éxito, y la única cifra no tiene serie que la mida.

## Qué problema resuelve, y para quién
- **Problema:** «El segmento Clientes frecuentes no tiene tarjeta de la tienda.» — `00-definicion/2025-11-12-definicion-producto.docx`, 2025-11-12.
- **Para quién:** Clientes frecuentes — misma fuente y fecha.
- **Evidencia de demanda:** una sola entrevista, 2025-10-11, de «Cliente entrevistado»: «Lo necesito y hoy no lo tengo.» (`10-descubrimiento/2025-10-11-entrevistas.docx`). Es una voz, dicha, sin pago ni compromiso, y no dice que pertenezca al segmento. Tiene 12 meses, en el umbral de evidencia vieja.
- **La propuesta** en la definición dice solo «Propuesta principal», sin contenido: qué es la tarjeta, qué ofrece, qué cobra y quién la emite no está escrito en ninguna parte.

## Qué se construye
Entran al caso los 11 requerimientos decididos (aceptados) del acta `30-decisiones/2026-10-16-comite-producto.md`; los 4 propuestos (REQ-4900, 4904, 4908, 4909) quedan fuera hasta que el comité los decida.

| Requerimiento | Estado | Evidencia de demanda |
|---|---|---|
| REQ-4901 | aceptado (2026-05-17) | «Cliente entrevistado», entrevista 2025-10-11 (no nombra el REQ) |
| REQ-4902 | aceptado (2026-08-06) | ídem |
| REQ-4903 | aceptado (2026-06-14) | **ninguna: nadie consta como solicitante** |
| REQ-4905 | aceptado (2026-04-01) | «Cliente entrevistado», entrevista 2025-10-11 |
| REQ-4906 | aceptado (2026-08-18) | ídem |
| REQ-4907 | aceptado (2026-05-21) | ídem |
| REQ-4910 | aceptado (2026-07-24) | ídem |
| REQ-4911 | aceptado (2026-07-29) | **ninguna: nadie consta como solicitante** |
| REQ-4912 | aceptado (2026-04-30) | «Cliente entrevistado», entrevista 2025-10-11 |
| REQ-4913 | aceptado (2026-04-21) | ídem; además sin doliente |
| REQ-2028 | aceptado (2026-09-22) | ídem |

Lo que el acta no dice de ellos: el acta trae solo el identificador, no qué se necesita; ninguno tiene proyecto que lo ejecute (0 de 11); 4 no tienen criterio de aceptación (REQ-2028, 4901, 4911, 4913) y el resto dice «se verifica en producción», que no es medible; y no consta quién decidió ninguno. Sin saber qué es cada requerimiento no se puede costear ninguno.

## Las cifras
| Cifra | Valor | Clase | De dónde sale | De cuándo |
|---|---|---|---|---|
| volumen_mensual | 106.991 | **Declarada** | `00-definicion/2025-11-12-caso-de-negocio.md`, tabla «Cifras que sostienen el caso», elaborada por Elena Duarte | 2025-11-12 |
| Retorno esperado | «en 24 meses» | **Sin cifra** | mismo caso de negocio: solo un plazo, sin monto, base ni serie | 2025-11-12 |

No hay ninguna cifra **medida**. Tampoco se dice qué cuenta el 106.991 (transacciones, tarjetas o clientes), ni de dónde sale: eso queda en vacíos. El 24 meses no se trata como cifra porque no hay valor al que ponerle fuente.

### Donde la cifra declarada y la medida no coinciden
| Métrica | Declarada | Medida | Las dos fuentes y fechas |
|---|---|---|---|
| volumen_mensual | 106.991 | sin serie | caso de negocio 2025-11-12 / sin fuente medida (la carpeta no tiene `20-metricas/`) |

No es calculable la diferencia ni el umbral (20 %): no hay con qué comparar. Nadie mide lo que el caso afirmó, a 11 meses de escrito.

## Los costos
| Concepto | Valor | De dónde sale |
|---|---|---|
| Costo de construir | **vacío** | ningún documento: sin contratos, cotizaciones ni costo declarado del equipo |
| Costo de operar / emitir | **vacío** | ningún documento |
| Costo del equipo | **vacío** | ningún documento |

**El costo de construir es el primer vacío.** Sin él no hay caso de negocio que evaluar. No se calculan rentabilidad, retorno ni periodo de recuperación: con una cifra declarada sin base y ningún costo, cualquier número sería una opinión con dos decimales.

## Supuestos sobre los que se sostiene
| Supuesto | Qué pasa si resulta falso | Quién lo verificaría |
|---|---|---|
| La regulación de datos lo permite (declarado 2026-03-28; verificado 2026-08-21 según `00-definicion/2026-08-21-verificacion-supuesto.md`) | Los datos personales de clientes frecuentes no se podrían tratar como la tarjeta necesita; el producto no sale como está pensado | Jurídico: el concepto del 2026-08-21 **no está en la carpeta**, solo la nota que dice «se confirmó». No dice país ni alcance. |
| Que los Clientes frecuentes son quienes quieren la tarjeta (implícito, nadie lo ha afirmado con evidencia) | La demanda de la que cuelga el 106.991 no existe en ese segmento | Quien hizo la entrevista (Elena Duarte) o una nueva ronda con el segmento nombrado |
| Que el 106.991 mensual es alcanzable (implícito: no hay base declarada) | Todo el retorno esperado queda sin sustento | El negocio: quien produjo la cifra |

Los dos últimos son **supuestos de clase «supuesta»**: nadie los ha declarado, están implícitos en el razonamiento. Van al seguimiento de supuestos.

Una inconsistencia de fechas para que la revise su autor: la definición está fechada el 2025-11-12 y contiene un supuesto «declarado el 2026-03-28» y una verificación del 2026-08-21.

## Vacíos
| Qué falta | Por qué importa | Quién lo produce |
|---|---|---|
| Costo de construir (y operar) | Sin él no hay caso, hay una propuesta | Elena Duarte con quien cotice / el equipo; ningún documento lo trae |
| Criterio de éxito | Es lo que hace verificable el caso meses después; `success` queda en `not_found` | Elena Duarte; lo aprueba el Comité de producto |
| Origen y significado del 106.991 | No se sabe si cuenta transacciones, tarjetas o clientes | El autor del caso de negocio |
| Serie que mida el volumen mensual | La cifra declarada no se puede contrastar | El sistema donde viva el producto; hoy no hay `20-metricas/` |
| Monto y base del retorno esperado | «24 meses» no es contrastable | El negocio |
| Qué pasa si no se hace | El caso no dice el costo de no actuar | El negocio |
| Alternativas consideradas | No hay ninguna escrita | El negocio |
| Contenido de la propuesta (qué es, qué cobra, quién emite) | Sin ella no se puede costear ni revisar lo normativo | Elena Duarte |
| País | De él depende la parte normativa (datos personales, consumidor financiero, medios de pago); el barrido normativo quedó «sin norma a la vista» | Elena Duarte; revisión jurídica |
| Concepto jurídico del 2026-08-21 | El supuesto verificado no se puede citar sin el documento | Jurídico |
| Qué es «el plan» que el comité mantuvo el 2026-10-16 | La decisión «Se mantiene el plan» no tiene a qué referirse | Comité de producto |
| Quién decidió los 11 requerimientos aceptados | No consta; los 2 sin solicitante (REQ-4903, REQ-4911) se van a construir sin que nadie los pidiera | Comité de producto |
| Proyectos que lo construyen | «Ninguno declarado»; 0 de 11 con proyecto | Gerente del producto |

## Cómo se sabrá si funcionó
**No está declarado.** Ningún documento fija criterio de éxito, métrica ni fecha de corte. Lo único cercano es el volumen_mensual declarado de 106.991 y un retorno «en 24 meses» (contados desde una fecha de inicio que tampoco está). Sin esto el producto no se puede cerrar meses después. Quien lo define: Elena Duarte, con aprobación del Comité de producto.

## Si hay otros productos publicados
No hay ninguno publicado a la vista (la carpeta de fichas `estado/records` está vacía), así que no se pudo cruzar si otro producto afirma las mismas transacciones. Se cruza cuando haya otros publicados (`/product-overlap`).

## Después
Pasar los dos supuestos implícitos y el supuesto de datos (sin su concepto jurídico) al seguimiento con assumption-tracking. `/product-charter` no corresponde todavía: sin costo ni criterio de éxito el caso no está listo para aprobarse.
