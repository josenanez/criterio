## Trazabilidad — Tarjeta de la tienda (PRD-309) · al 2026-10-17
11 decididos · 0 con proyecto · 0 confirmados contra la ficha · 0 entregados

### Decidido y nadie lo está construyendo
Los 11 requerimientos aceptados carecen de proyecto en el registro. Ordenados por antigüedad de la decisión:

| REQ | Título | Decidido el | Por quién |
|---|---|---|---|
| REQ-4913 | Requerimiento REQ-4913 (sin doliente) | 2026-04-21 | no consta |
| REQ-4912 | Requerimiento REQ-4912 | 2026-04-30 | no consta |
| REQ-4905 | Requerimiento REQ-4905 | 2026-04-01 | no consta |
| REQ-4901 | Requerimiento REQ-4901 | 2026-05-17 | no consta |
| REQ-4907 | Requerimiento REQ-4907 | 2026-05-21 | no consta |
| REQ-4903 | Requerimiento REQ-4903 | 2026-06-14 | no consta |
| REQ-4910 | Requerimiento REQ-4910 | 2026-07-24 | no consta |
| REQ-4911 | Requerimiento REQ-4911 | 2026-07-29 | no consta |
| REQ-4902 | Requerimiento REQ-4902 | 2026-08-06 | no consta |
| REQ-4906 | Requerimiento REQ-4906 | 2026-08-18 | no consta |
| REQ-2028 | Requerimiento REQ-2028 | 2026-09-22 | no consta |

Las actas (documentos/productos/PRD-309/30-decisiones/, p. ej. 2026-10-16-comite-producto.md) traen solo el identificador: no dicen qué se necesita ni quién decidió. La cadena se rompe en ese eslabón y en el siguiente (proyecto).

### La traza no se confirma
Ningún requerimiento declara proyecto, así que no hay traza que confirmar ni desacuerdo que reportar.

### Lo que un proyecto construye y el registro no tiene
Ninguna de las 13 fichas (PRY-199 a PRY-211) declara PRD-309 como producto que ejecuta. Hay dos hallazgos del otro lado:
- 6 fichas dejan vacío el campo de producto (campo vacío en la ficha, hallazgo de ese lado). Una de ellas podría ser quien construye esto.
- 7 fichas declaran otro producto (PRD-299 y producto por nombre: venta en línea, autopago en tienda, entrega rápida, marca propia, pago con QR, puntos de fidelización).

No hay, por tanto, un proyecto que se haya declarado constructor de PRD-309 sin que el registro lo nombre.

### La cadena completa
| REQ | Estado | Decisión | Proyecto | Confirmado | Entregables |
|---|---|---|---|---|---|
| 11 aceptados (lista arriba) | aceptado | acta sin quién | — | no | — |
| REQ-4900, 4904, 4908, 4909 | propuesto | sin decidir (70 a 152 días) | — | no | — |

### Sin fichas a la vista
Están las 13 fichas, pero ninguna nombra PRD-309. No se pudo confirmar nada porque no hay a qué confirmar; no porque falten fichas.

Conviene `/criterio-product:product-charter` para el requerimiento que esté listo para ser proyecto. Los 6 gerentes con producto vacío en la ficha merecen una conversación, no un comando.
