## Tarjeta de la tienda (PRD-309) · 2026-10-17

**Qué tocaba:** `review` (nunca se había corrido). `crossed` no aplica: no existe un corte anterior contra el cual medir qué cruzó un umbral, así que esta corrida **fija el primer corte** y no reporta "nuevos" hallazgos. Responsable: Elena Duarte · Autoridad: Comité de producto.

**Documentos:** 5, ninguno nuevo ni cambiado desde el sellado; no hubo nada que releer. Aviso: el índice marca 8 campos con `source_missing` (identidad, definición, supuesto), todos apuntando a archivos que sí están en la carpeta. Parece un problema de resolución de rutas, no de documentos borrados; no lo he verificado.

### Estado del registro
15 requerimientos: 11 aceptados, 4 propuestos. Con evidencia: 9 de 11 decididos (81,8 %). **Trazados a un proyecto: 0 de 11 (0 %).**

### Para el comité (lo que necesita decisión)
| Qué | REQ | Cuánto lleva | Qué se necesita | Quién |
|---|---|---|---|---|
| Sin decidir, sin doliente | REQ-4909 | 152 días (desde 2026-05-18) | Nombrar doliente y decidir; además su evidencia ya tiene 12 meses | Comité de producto |
| Sin decidir | REQ-4900 | 105 días | Decidir o descartar; evidencia de 12 meses | Dueño: Diana Molina |
| Sin decidir | REQ-4904 | 77 días | Decidir; no tiene evidencia de demanda | Dueño: Beatriz Cuéllar |
| Sin decidir | REQ-4908 | 70 días | Decidir; no tiene evidencia de demanda | Dueño: Sandra Gil |
| Aceptado sin evidencia de demanda | REQ-4903, REQ-4911 | decididos 2026-06-14 y 2026-07-29 | Quién lo pidió; REQ-4911 además sin criterio de aceptación | Beatriz Cuéllar, Carlos Peña |
| Aceptado sin doliente ni criterio de aceptación | REQ-4913 | decidido 2026-04-21 | Nombrar doliente y criterio | Comité de producto |

Los cuatro propuestos superan el umbral de 60 días. Lo que cada uno necesita, antes que el diagnóstico, es saber quién tiene la facultad de decidirlo.

### Las trazas
Ninguna ficha de las 13 de `estado/records` nombra PRD-309 ni ninguno de sus requerimientos. Los 11 aceptados no tienen proyecto que los construya: no hay trazas que confirmar, y por eso tampoco hay ninguna que se haya roto. Si alguno de esos proyectos sí construye este producto, su ficha no lo dice.

### Del descubrimiento
Sin documentos nuevos. La evidencia de demanda de 9 requerimientos es una sola entrevista del 2025-10-11 («Lo necesito y hoy no lo tengo.»), que cumple 12 meses: `evidence_stale` en 11 requerimientos. Con eso la definición queda sin sustento de demanda reciente.

### Lo que el registro no sabe
- **Criterio de éxito de la definición: no está dicho** en ningún documento.
- La cifra de volumen mensual del caso de negocio (106.991, del 2025-11-12) no tiene medición contra la cual contrastarla.
- Sin criterio de aceptación: REQ-2028, 4901, 4911, 4913.

### Resto (anexo)
Señales totales: 11 `evidence_stale`, 11 `requirement_untraced`, 4 `requirement_undecided`, 4 `requirement_without_acceptance`, 2 `requirement_accepted_without_evidence`, 2 `requirement_without_owner`.

**Vuelvo el 2026-11-16.**
