## Descubrimiento — Tarjeta de la tienda (PRD-309) · 0 piezas nuevas al 2026-10-17

0 piezas leídas, ningún tema que el registro no tenga ya.

**Por qué:** el plan de lectura encontró 5 documentos y los 5 sin cambios desde la corrida anterior (`to_read: 0`; modo «nada que leer: ningún documento nuevo ni cambiado; solo recalcular»). No se releyó nada, y no se selló nada porque no se leyó nada.

**Lo que sí quedó recalculado** (`compute`, 15 requerimientos: 11 aceptados, 4 propuestos): 9 con evidencia, ninguno trazado a un proyecto. Las señales del registro se ven con `/product-requirements`; este comando no las repite.

**Una observación sobre el índice, sin interpretarla:** el índice reporta 8 campos de la ficha del producto cuya fuente citada no resuelve (`source_missing`, p. ej. `identity.code`, `definition.problem`, `definition.claims[0].declared`). No hay renombrados ni borrados detectados. Queda para quien mantenga la ficha; no la corregí.

**Dicho y nunca convertido en nada / Dicho una sola vez / Afirmaciones numéricas / Fuentes públicas / Evidencia que contradice el registro:** sin material nuevo, ninguna de estas secciones se produce en esta corrida.
