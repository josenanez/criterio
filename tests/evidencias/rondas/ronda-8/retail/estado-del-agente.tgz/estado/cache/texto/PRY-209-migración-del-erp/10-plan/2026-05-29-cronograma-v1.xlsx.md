<!-- origen: PRY-209-migración-del-erp/10-plan/2026-05-29-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la experiencia aprobado | 2026-07-25 | 2026-07-25 | cerrado
Ambiente de pruebas certificado | 2026-09-11 | 2026-09-11 | cerrado
Integración con el ERP | 2026-10-29 | 2026-10-29 | en curso
Piloto en tiendas | 2026-12-16 | 2026-12-16 | en curso
Despliegue en la cadena | 2027-02-02 | 2027-02-02 | en curso
