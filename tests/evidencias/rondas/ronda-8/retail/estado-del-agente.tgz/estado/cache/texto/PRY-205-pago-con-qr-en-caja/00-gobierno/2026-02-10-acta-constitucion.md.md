<!-- origen: PRY-205-pago-con-qr-en-caja/00-gobierno/2026-02-10-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Pago con QR en caja

**Código:** PRY-205
**Área dueña:** Mercadeo
**Patrocinador:** Liliana Torres
**Gerente de proyecto:** Jorge Medina
**Comité:** Comité de Expansión
**Producto asociado:** pago con QR
**Fecha de aprobación:** 2026-02-10

## Objetivo del negocio

Entregar pago con qr en caja para Mercadeo.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**1.200.000.000 COP**, aprobado por Comité de Expansión el 2026-02-10.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-02-20 |
| Cierre | 2026-09-15 |

## Criterio de éxito

Pago con QR en caja en producción y medido.

## Dependencias declaradas

- Ninguna declarada
