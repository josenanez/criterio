<!-- origen: PRY-201-programa-de-fidelización/00-gobierno/2025-09-25-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Programa de fidelización

Código: PRY-201

Área dueña: Finanzas

Patrocinador: Camilo Beltrán

Gerente de proyecto: Rubén Cárdenas

Comité: Comité Comercial

Producto asociado: puntos de fidelización

Fecha de aprobación: 2025-09-25

Objetivo del negocio

Entregar programa de fidelización para Finanzas.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

1.200.000.000 COP, aprobado por Comité Comercial el 2025-09-25.

Fechas comprometidas

Fecha

Inicio

2025-10-05

Cierre

2027-03-25

Criterio de éxito

Programa de fidelización en producción y medido.

Dependencias declaradas

• Ninguna declarada
