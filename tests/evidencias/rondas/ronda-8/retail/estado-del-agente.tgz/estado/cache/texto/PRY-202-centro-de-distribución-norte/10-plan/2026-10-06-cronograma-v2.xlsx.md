<!-- origen: PRY-202-centro-de-distribución-norte/10-plan/2026-10-06-cronograma-v2.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la experiencia aprobado | 2026-08-22 | 2026-08-22 | cerrado
Ambiente de pruebas certificado | 2026-11-01 | 2026-11-01 | en curso
Integración con el ERP | 2027-01-11 | 2027-01-11 | en curso
Piloto en tiendas | 2027-03-23 | 2027-05-14 | en curso
