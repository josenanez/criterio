<!-- origen: PRY-200-tienda-en-línea/20-seguimiento/2026-10-17-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Tienda en línea

**Código:** PRY-200
**Fecha de corte:** 2026-10-17
**Gerente:** Rubén Cárdenas

## Estado declarado

**Rojo**

Avance reportado: **69%**

## Lo que pasó en el periodo

- La prueba de carga de temporada no alcanzó el umbral pactado y se repite
- Se ajustó el plan de pruebas con el área de seguridad
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales

## Presupuesto

| | COP |
|---|---|
| Aprobado | 9.500.000.000 |
| Comprometido | 5.420.644.515 |
| Ejecutado | 5.110.694.551 |
| Proyección al cierre | 8.761.040.718 |

## Riesgos abiertos

- Cambio en la regulación de datos personales que puede mover el alcance
- El proveedor no ha confirmado la fecha de la última entrega
