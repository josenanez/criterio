<!-- origen: PRY-207-marca-propia-de-alimentos/10-plan/2026-10-14-cronograma-v2.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la experiencia aprobado | 2026-08-10 | 2026-08-10 | cerrado
Ambiente de pruebas certificado | 2026-11-12 | 2026-11-12 | en curso
Integración con el ERP | 2027-02-13 | 2027-02-13 | en curso
Piloto en tiendas | 2027-05-18 | 2027-06-18 | en curso
