<!-- origen: PRY-202-centro-de-distribución-norte/20-seguimiento/2026-10-06-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Centro de distribución norte
Código: PRY-202
Fecha de corte: 2026-10-06
Gerente: Elena Duarte

Estado declarado
Verde
Avance reportado: 28%

Lo que pasó en el periodo
- Se levantó un hallazgo de seguridad en los medios de pago
- La prueba de carga de temporada no alcanzó el umbral pactado y se repite
- Se ajustó el plan de pruebas con el área de seguridad

Presupuesto
COP
Aprobado 3.300.000.000
Comprometido 1.339.014.694
Ejecutado 1.653.468.061
Proyección al cierre 4.019.406.308

Riesgos abiertos
- Concentración del conocimiento en una sola persona
