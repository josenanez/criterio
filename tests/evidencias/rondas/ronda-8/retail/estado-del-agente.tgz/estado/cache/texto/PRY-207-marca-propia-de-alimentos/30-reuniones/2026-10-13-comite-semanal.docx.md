<!-- origen: PRY-207-marca-propia-de-alimentos/30-reuniones/2026-10-13-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Cadena de Abastecimiento · Marca propia de alimentos

Fecha: 2026-10-13

Asistentes: Ricardo Salas, Javier Hoyos

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Diana Molina

Entregar el punto 35

2026-10-10
