<!-- origen: PRY-200-tienda-en-línea/00-gobierno/2025-09-02-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Tienda en línea

**Código:** PRY-200
**Área dueña:** Tiendas
**Patrocinador:** Jorge Medina
**Gerente de proyecto:** Rubén Cárdenas
**Comité:** Comité de Transformación Digital
**Producto asociado:** venta en línea
**Fecha de aprobación:** 2025-09-02

## Objetivo del negocio

Entregar tienda en línea para Tiendas.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**9.500.000.000 COP**, aprobado por Comité de Transformación Digital el 2025-09-02.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-09-12 |
| Cierre | 2026-09-07 |

## Criterio de éxito

Tienda en línea en producción y medido.

## Dependencias declaradas

- Ninguna declarada
