<!-- origen: PRY-204-cajas-de-autopago/20-seguimiento/2026-10-04-solicitud-cambio-cc-01.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-01

**Proyecto:** PRY-204 · Cajas de autopago
**Fecha:** 2026-10-04
**Solicitante:** Liliana Torres

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +35 días sobre la línea base vigente |
| Costo | 70.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
