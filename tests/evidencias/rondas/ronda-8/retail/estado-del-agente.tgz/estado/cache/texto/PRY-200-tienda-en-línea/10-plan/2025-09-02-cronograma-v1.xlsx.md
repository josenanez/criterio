<!-- origen: PRY-200-tienda-en-línea/10-plan/2025-09-02-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la experiencia aprobado | 2025-11-23 | 2025-11-23 | cerrado
Ambiente de pruebas certificado | 2026-02-03 | 2026-02-03 | cerrado
Integración con el ERP | 2026-04-16 | 2026-04-16 | cerrado
Piloto en tiendas | 2026-06-27 | 2026-06-27 | cerrado
Despliegue en la cadena | 2026-09-07 | 2026-09-07 | cerrado
