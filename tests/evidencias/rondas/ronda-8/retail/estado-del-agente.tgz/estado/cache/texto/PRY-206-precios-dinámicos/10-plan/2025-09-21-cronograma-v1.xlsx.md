<!-- origen: PRY-206-precios-dinámicos/10-plan/2025-09-21-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la experiencia aprobado | 2025-12-08 | 2025-12-08 | cerrado
Ambiente de pruebas certificado | 2026-02-15 | 2026-02-15 | cerrado
Integración con el ERP | 2026-04-25 | 2026-04-25 | cerrado
Piloto en tiendas | 2026-07-02 | 2026-07-02 | cerrado
