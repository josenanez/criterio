<!-- origen: PRY-211-pronóstico-de-demanda/20-seguimiento/2026-10-04-solicitud-cambio-cc-01.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-01

**Proyecto:** PRY-211 · Pronóstico de demanda
**Fecha:** 2026-10-04
**Solicitante:** Beatriz Cuéllar

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +75 días sobre la línea base vigente |
| Costo | 150.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
