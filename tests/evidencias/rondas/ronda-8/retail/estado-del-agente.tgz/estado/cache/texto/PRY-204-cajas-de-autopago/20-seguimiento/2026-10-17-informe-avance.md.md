<!-- origen: PRY-204-cajas-de-autopago/20-seguimiento/2026-10-17-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Cajas de autopago

**Código:** PRY-204
**Fecha de corte:** 2026-10-17
**Gerente:** Liliana Torres

## Estado declarado

**Amarillo**

Avance reportado: **41%**

## Lo que pasó en el periodo

- Se reprogramó el despliegue por el congelamiento de temporada de fin de año
- El equipo perdió dos semanas por rotación de un desarrollador clave
- Se levantó un hallazgo de seguridad en los medios de pago

## Presupuesto

| | COP |
|---|---|
| Aprobado | 18.000.000.000 |
| Comprometido | 9.257.178.372 |
| Ejecutado | 5.257.416.864 |
| Proyección al cierre | 17.571.935.946 |

## Riesgos abiertos

- Cambio en la regulación de datos personales que puede mover el alcance
