<!-- origen: PRY-208-domicilios-en-dos-horas/10-plan/2025-12-19-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la experiencia aprobado | 2026-04-12 | 2026-04-12 | cerrado
Ambiente de pruebas certificado | 2026-07-26 | 2026-07-26 | cerrado
Integración con el ERP | 2026-11-08 | 2026-11-08 | en curso
Piloto en tiendas | 2027-02-21 | 2027-02-21 | en curso
Despliegue en la cadena | 2027-06-06 | 2027-06-06 | en curso
