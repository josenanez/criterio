<!-- origen: PRY-211-pronóstico-de-demanda/00-gobierno/2025-10-17-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Pronóstico de demanda

Código: PRY-211

Área dueña: Comercio electrónico

Patrocinador: Jorge Medina

Gerente de proyecto: Beatriz Cuéllar

Comité: Comité de Expansión

Producto asociado: No aplica

Fecha de aprobación: 2025-10-17

Objetivo del negocio

Entregar pronóstico de demanda para Comercio electrónico.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

3.300.000.000 COP, aprobado por Comité de Expansión el 2025-10-17.

Fechas comprometidas

Fecha

Inicio

2025-10-27

Cierre

2026-12-26

Criterio de éxito

Pronóstico de demanda en producción y medido.

Dependencias declaradas

• Ninguna declarada
