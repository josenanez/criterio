<!-- origen: PRY-210-etiquetas-electrónicas-de-precio/10-plan/2026-01-01-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la experiencia aprobado | 2026-03-28 | 2026-03-28 | cerrado
Ambiente de pruebas certificado | 2026-06-12 | 2026-06-12 | cerrado
Integración con el ERP | 2026-08-27 | 2026-08-27 | cerrado
Piloto en tiendas | 2026-11-11 | 2026-11-11 | en curso
Despliegue en la cadena | 2027-01-26 | 2027-01-26 | en curso
