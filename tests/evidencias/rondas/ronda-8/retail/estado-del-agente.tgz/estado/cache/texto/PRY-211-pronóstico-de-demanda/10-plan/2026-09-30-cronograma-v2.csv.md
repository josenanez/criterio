<!-- origen: PRY-211-pronóstico-de-demanda/10-plan/2026-09-30-cronograma-v2.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño de la experiencia aprobado,2026-01-20,2026-01-20,cerrado
Ambiente de pruebas certificado,2026-04-15,2026-04-15,cerrado
Integración con el ERP,2026-07-09,2026-07-09,cerrado
Piloto en tiendas,2026-10-02,2026-10-02,cerrado
Despliegue en la cadena,2026-12-26,2027-03-11,en curso
