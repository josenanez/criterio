<!-- origen: PRY-207-marca-propia-de-alimentos/20-seguimiento/2026-10-14-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Marca propia de alimentos

**Código:** PRY-207
**Fecha de corte:** 2026-10-14
**Gerente:** Ricardo Salas

## Estado declarado

**Rojo**

Avance reportado: **52%**

## Lo que pasó en el periodo

- Se ajustó el plan de pruebas con el área de seguridad

## Presupuesto

| | COP |
|---|---|
| Aprobado | 3.300.000.000 |
| Comprometido | 1.216.048.356 |
| Ejecutado | 903.523.999 |
| Proyección al cierre | 3.447.858.089 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
- Disponibilidad de los jefes de tienda para el piloto
