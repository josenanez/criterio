<!-- origen: PRY-206-precios-dinámicos/20-seguimiento/2026-10-15-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Precios dinámicos
Código: PRY-206
Fecha de corte: 2026-10-15
Gerente: Rubén Cárdenas

Estado declarado
Rojo
Avance reportado: 51%

Lo que pasó en el periodo
- La prueba de carga de temporada no alcanzó el umbral pactado y se repite
- El equipo perdió dos semanas por rotación de un desarrollador clave
- Se recibió el concepto de Jurídica sobre los términos de uso

Presupuesto
COP
Aprobado 9.500.000.000
Comprometido 6.871.346.757
Ejecutado 5.793.603.417
Proyección al cierre 9.510.217.057

Riesgos abiertos
- Concentración del conocimiento en una sola persona
- El proveedor no ha confirmado la fecha de la última entrega
