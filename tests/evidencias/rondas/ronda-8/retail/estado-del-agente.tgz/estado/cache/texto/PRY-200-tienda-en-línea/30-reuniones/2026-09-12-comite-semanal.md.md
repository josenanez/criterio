<!-- origen: PRY-200-tienda-en-línea/30-reuniones/2026-09-12-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Transformación Digital · Tienda en línea

**Fecha:** 2026-09-12
**Asistentes:** Beatriz Cuéllar, Camilo Beltrán, Gustavo Neira, Javier Hoyos, Jorge Medina, María Restrepo, Natalia Ospina, Rubén Cárdenas, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Beatriz Cuéllar | Enviar el documento 1 | 2026-10-17 |
| Óscar Ramírez | Cerrar la prueba 2 | 2026-10-12 |
| Camilo Beltrán | Revisar el anexo 3 | 2026-10-02 |
| María Restrepo | Validar el ambiente 4 | 2026-09-24 |
| Natalia Ospina | Aprobar el diseño 5 | 2026-09-16 |
| Jorge Medina | Actualizar la matriz 6 | 2026-10-07 |
| Javier Hoyos | Confirmar la fecha 7 | 2026-09-26 |
| Gustavo Neira | Entregar el punto 8 | 2026-09-23 |
