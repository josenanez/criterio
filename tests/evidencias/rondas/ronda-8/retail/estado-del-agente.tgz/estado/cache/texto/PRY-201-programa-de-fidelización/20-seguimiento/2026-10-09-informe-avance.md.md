<!-- origen: PRY-201-programa-de-fidelización/20-seguimiento/2026-10-09-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Programa de fidelización

**Código:** PRY-201
**Fecha de corte:** 2026-10-09
**Gerente:** Rubén Cárdenas

## Estado declarado

**Verde**

Avance reportado: **36%**

## Lo que pasó en el periodo

- Se acordó con arquitectura cómo se revisan los requisitos no funcionales
- La prueba de carga de temporada no alcanzó el umbral pactado y se repite

## Presupuesto

| | COP |
|---|---|
| Aprobado | 1.200.000.000 |
| Comprometido | 788.922.498 |
| Ejecutado | 716.395.662 |
| Proyección al cierre | 1.176.832.977 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
- El proveedor no ha confirmado la fecha de la última entrega
