<!-- origen: PRY-210-etiquetas-electrónicas-de-precio/20-seguimiento/2026-04-22-acta-recibo-ct-267-licenciamiento-de-la-plataforma.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de recibo · Licenciamiento de la plataforma
Proyecto: PRY-210 · Etiquetas electrónicas de precio
Fecha de recibo: 2026-04-22
Recibido por: Sandra Gil
Se recibe a satisfacción el entregable Licenciamiento de la plataforma.
Contrato CT-267 · Retail Andino Consultores S.A.S..
