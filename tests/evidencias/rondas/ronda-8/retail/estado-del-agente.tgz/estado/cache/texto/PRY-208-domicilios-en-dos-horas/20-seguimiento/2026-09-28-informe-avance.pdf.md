<!-- origen: PRY-208-domicilios-en-dos-horas/20-seguimiento/2026-09-28-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Domicilios en dos horas
Código: PRY-208
Fecha de corte: 2026-09-28
Gerente: Jorge Medina

Estado declarado
Verde
Avance reportado: 61%

Lo que pasó en el periodo
- El equipo perdió dos semanas por rotación de un desarrollador clave

Presupuesto
COP
Aprobado 2.400.000.000
Comprometido 1.751.477.026
Ejecutado 1.119.282.950
Proyección al cierre 3.054.296.028

Riesgos abiertos
- Congelamiento de cambios en temporada alta
