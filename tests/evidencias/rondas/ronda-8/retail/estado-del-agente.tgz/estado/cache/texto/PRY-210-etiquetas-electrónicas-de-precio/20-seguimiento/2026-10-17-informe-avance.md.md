<!-- origen: PRY-210-etiquetas-electrónicas-de-precio/20-seguimiento/2026-10-17-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Etiquetas electrónicas de precio

**Código:** PRY-210
**Fecha de corte:** 2026-10-17
**Gerente:** Sandra Gil

## Estado declarado

**Verde**

Avance reportado: **64%**

## Lo que pasó en el periodo

- La prueba de carga de temporada no alcanzó el umbral pactado y se repite
- Se recibió el concepto de Jurídica sobre los términos de uso

## Presupuesto

| | COP |
|---|---|
| Aprobado | 4.200.000.000 |
| Comprometido | 3.021.600.310 |
| Ejecutado | 2.232.011.975 |
| Proyección al cierre | 4.302.027.894 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
- Cambio en la regulación de datos personales que puede mover el alcance
