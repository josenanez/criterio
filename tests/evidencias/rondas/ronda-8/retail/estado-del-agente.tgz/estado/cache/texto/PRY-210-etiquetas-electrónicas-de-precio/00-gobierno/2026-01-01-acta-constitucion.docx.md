<!-- origen: PRY-210-etiquetas-electrónicas-de-precio/00-gobierno/2026-01-01-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Etiquetas electrónicas de precio

Código: PRY-210

Área dueña: Comercio electrónico

Patrocinador: Laura Vélez

Gerente de proyecto: Sandra Gil

Comité: Comité de Expansión

Producto asociado: No aplica

Fecha de aprobación: 2026-01-01

Objetivo del negocio

Entregar etiquetas electrónicas de precio para Comercio electrónico.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

4.200.000.000 COP, aprobado por Comité de Expansión el 2026-01-01.

Fechas comprometidas

Fecha

Inicio

2026-01-11

Cierre

2027-01-26

Criterio de éxito

Etiquetas electrónicas de precio en producción y medido.

Dependencias declaradas

• Ninguna declarada
