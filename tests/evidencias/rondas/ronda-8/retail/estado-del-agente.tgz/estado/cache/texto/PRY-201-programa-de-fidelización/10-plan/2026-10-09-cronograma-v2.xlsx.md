<!-- origen: PRY-201-programa-de-fidelización/10-plan/2026-10-09-cronograma-v2.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la experiencia aprobado | 2026-01-20 | 2026-01-20 | cerrado
Ambiente de pruebas certificado | 2026-05-07 | 2026-05-07 | cerrado
Integración con el ERP | 2026-08-22 | 2026-08-22 | cerrado
Piloto en tiendas | 2026-12-08 | 2026-12-08 | en curso
Despliegue en la cadena | 2027-03-25 | 2027-04-27 | en curso
