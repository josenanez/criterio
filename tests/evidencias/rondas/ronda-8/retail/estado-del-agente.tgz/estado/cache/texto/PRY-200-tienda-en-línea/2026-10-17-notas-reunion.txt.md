<!-- origen: PRY-200-tienda-en-línea/2026-10-17-notas-reunion.txt · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

notas reunión tienda en línea — 2026-10-17
estuvieron: Andrés Lozano, Beatriz Cuéllar, Camilo Beltrán, Felipe Arango, Javier Hoyos, Jorge Medina, Laura Vélez, Liliana Torres, María Restrepo, Mauricio Pérez, Ricardo Salas, Rubén Cárdenas, Sandra Gil, Óscar Ramírez

- Beatriz Cuéllar dice que lo de «enviar el documento 1» no alcanzó, se compromete para el 19/12/2026
- Laura Vélez queda de mandar el ajuste del presupuesto la otra semana
- Óscar Ramírez: revisión con el proveedor, queda para el 2026-10-27
- se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo
- próxima reunión en dos semanas
