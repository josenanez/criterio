<!-- origen: PRY-208-domicilios-en-dos-horas/30-reuniones/2026-10-11-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Cadena de Abastecimiento · Domicilios en dos horas

**Fecha:** 2026-10-11
**Asistentes:** Jorge Medina, Gustavo Neira

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Camilo Beltrán | Entregar el punto 22 | 2026-10-23 |
| Felipe Arango | Entregar el punto 3 | 2026-11-02 |
