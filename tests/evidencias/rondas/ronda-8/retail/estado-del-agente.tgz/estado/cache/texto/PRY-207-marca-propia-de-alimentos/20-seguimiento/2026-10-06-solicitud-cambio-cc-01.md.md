<!-- origen: PRY-207-marca-propia-de-alimentos/20-seguimiento/2026-10-06-solicitud-cambio-cc-01.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-01

**Proyecto:** PRY-207 · Marca propia de alimentos
**Fecha:** 2026-10-06
**Solicitante:** Ricardo Salas

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +31 días sobre la línea base vigente |
| Costo | 62.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
