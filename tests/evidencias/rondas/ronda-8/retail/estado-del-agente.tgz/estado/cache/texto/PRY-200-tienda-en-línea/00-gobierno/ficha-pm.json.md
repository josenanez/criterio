<!-- origen: PRY-200-tienda-en-línea/00-gobierno/ficha-pm.json · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

{
 "schema_version": "0.2",
 "identity": {
 "code": {
 "value": "PRY-200",
 "source": "00-gobierno/2025-09-02-acta-constitucion.md",
 "source_date": "2025-09-02",
 "state": "found"
 },
 "name": {
 "value": "Tienda en línea",
 "source": "00-gobierno/2025-09-02-acta-constitucion.md",
 "source_date": "2025-09-02",
 "state": "found"
 },
 "aliases": [],
 "business_area": {
 "value": "Tiendas",
 "source": "00-gobierno/2025-09-02-acta-constitucion.md",
 "source_date": "2025-09-02",
 "state": "found"
 },
 "product": {
 "value": "venta en línea",
 "source": "00-gobierno/2025-09-02-acta-constitucion.md",
 "source_date": "2025-09-02",
 "state": "found"
 },
 "authority": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "sponsor": {
 "value": "Jorge Medina",
 "source": "00-gobierno/2025-09-02-acta-constitucion.md",
 "source_date": "2025-09-02",
 "state": "found"
 },
 "manager": {
 "value": "Rubén Cárdenas",
 "source": "00-gobierno/2025-09-02-acta-constitucion.md",
 "source_date": "2025-09-02",
 "state": "found"
 },
 "committee": {
 "value": "Comité de Transformación Digital",
 "source": "00-gobierno/2025-09-02-acta-constitucion.md",
 "source_date": "2025-09-02",
 "state": "found"
 },
 "phase": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 }
 },
 "declared": {
 "status": {
 "value": "rojo",
 "source": "20-seguimiento/2026-10-17-informe-avance.md",
 "source_date": "2026-10-17",
 "state": "found",
 "source_kind": "declaration"
 },
 "progress_pct": {
 "value": 69,
 "source": "20-seguimiento/2026-10-17-informe-avance.md",
 "source_date": "2026-10-17",
 "state": "found",
 "source_kind": "declaration"
 },
 "as_of": "2026-10-17",
 "source": "20-seguimiento/2026-10-17-informe-avance.md"
 },
 "plan": {
 "start_date": {
 "value": "2025-09-12",
 "source": "00-gobierno/2025-09-02-acta-constitucion.md",
 "source_date": "2025-09-02",
 "state": "found"
 },
 "end_date": {
 "value": "2026-09-07",
 "source": "10-plan/2025-09-02-cronograma-v1.xlsx",
 "source_date": "2025-09-02",
 "state": "found"
 },
 "baseline": [
 {
 "version": 1,
 "approved_on": "2025-09-02",
 "start_date": "2025-09-12",
 "end_date": "2026-09-07",
 "reason": "Aprobación inicial del Comité de Transformación Digital",
 "source": "00-gobierno/2025-09-02-acta-constitucion.md"
 }
 ],
 "milestones": [
 {
 "name": {
 "value": "Diseño de la experiencia aprobado",
 "source": "10-plan/2025-09-02-cronograma-v1.xlsx",
 "source_date": "2025-09-02",
 "state": "found"
 },
 "baseline_date": "2025-11-23",
 "current_date": "2025-11-23",
 "state": {
 "value": "met",
 "source": "10-plan/2025-09-02-cronograma-v1.xlsx",
 "source_date": "2025-09-02",
 "state": "found"
 },
 "evidence": "",
 "source": "10-plan/2025-09-02-cronograma-v1.xlsx"
 },
 {
 "name": {
 "value": "Ambiente de pruebas certificado",
 "source": "10-plan/2025-09-02-cronograma-v1.xlsx",
 "source_date": "2025-09-02",
 "state": "found"
 },
 "baseline_date": "2026-02-03",
 "current_date": "2026-02-03",
 "state": {
 "value": "met",
 "source": "10-plan/2025-09-02-cronograma-v1.xlsx",
 "source_date": "2025-09-02",
 "state": "found"
 },
 "evidence": "",
 "source": "10-plan/2025-09-02-cronograma-v1.xlsx"
 },
 {
 "name": {
 "value": "Integración con el ERP",
 "source": "10-plan/2025-09-02-cronograma-v1.xlsx",
 "source_date": "2025-09-02",
 "state": "found"
 },
 "baseline_date": "2026-04-16",
 "current_date": "2026-04-16",
 "state": {
 "value": "met",
 "source": "10-plan/2025-09-02-cronograma-v1.xlsx",
 "source_date": "2025-09-02",
 "state": "found"
 },
 "evidence": "",
 "source": "10-plan/2025-09-02-cronograma-v1.xlsx"
 },
 {
 "name": {
 "value": "Piloto en tiendas",
 "source": "10-plan/2025-09-02-cronograma-v1.xlsx",
 "source_date": "2025-09-02",
 "state": "found"
 },
 "baseline_date": "2026-06-27",
 "current_date": "2026-06-27",
 "state": {
 "value": "met",
 "source": "10-plan/2025-09-02-cronograma-v1.xlsx",
 "source_date": "2025-09-02",
 "state": "found"
 },
 "evidence": "",
 "source": "10-plan/2025-09-02-cronograma-v1.xlsx"
 },
 {
 "name": {
 "value": "Despliegue en la cadena",
 "source": "10-plan/2025-09-02-cronograma-v1.xlsx",
 "source_date": "2025-09-02",
 "state": "found"
 },
 "baseline_date": "2026-09-07",
 "current_date": "2026-09-07",
 "state": {
 "value": "met",
 "source": "10-plan/2025-09-02-cronograma-v1.xlsx",
 "source_date": "2025-09-02",
 "state": "found"
 },
 "evidence": "",
 "source": "10-plan/2025-09-02-cronograma-v1.xlsx"
 }
 ],
 "scope_summary": {
 "value": "Componente 1, Componente 2, Componente 3",
 "source": "00-gobierno/2025-09-02-acta-constitucion.md",
 "source_date": "2025-09-02",
 "state": "found"
 },
 "exclusions": {
 "value": "Lo que otro proyecto cubre",
 "source": "00-gobierno/2025-09-02-acta-constitucion.md",
 "source_date": "2025-09-02",
 "state": "found"
 }
 },
 "money": {
 "currency": {
 "value": "COP",
 "source": "00-gobierno/2025-09-02-acta-constitucion.md",
 "source_date": "2025-09-02",
 "state": "found"
 },
 "approved": {
 "value": 9500000000,
 "source": "00-gobierno/2025-09-02-acta-constitucion.md",
 "source_date": "2025-09-02",
 "state": "found"
 },
 "committed": {
 "value": 5420644515,
 "source": "20-seguimiento/2026-10-17-informe-avance.md",
 "source_date": "2026-10-17",
 "state": "found"
 },
 "executed": {
 "value": 5110694551,
 "source": "20-seguimiento/2026-10-17-informe-avance.md",
 "source_date": "2026-10-17",
 "state": "found"
 },
 "projection": {
 "value": 8761040718,
 "source": "20-seguimiento/2026-10-17-informe-avance.md",
 "source_date": "2026-10-17",
 "state": "found"
 }
 },
 "vendors": [],
 "raid": {
 "risks": [
 {
 "what": {
 "value": "Cambio en la regulación de datos personales que puede mover el alcance",
 "source": "20-seguimiento/2026-10-17-informe-avance.md",
 "source_date": "2026-10-17",
 "state": "found"
 },
 "owner": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 }
 },
 {
 "what": {
 "value": "El proveedor no ha confirmado la fecha de la última entrega",
 "source": "20-seguimiento/2026-10-17-informe-avance.md",
 "source_date": "2026-10-17",
 "state": "found"
 },
 "owner": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 }
 },
 {
 "what": {
 "value": "El proveedor podría no llegar con el equipo completo para la siguiente fase",
 "source": "2026-10-17-notas-reunion.txt",
 "source_date": "2026-10-17",
 "state": "found"
 },
 "owner": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "registered": false,
 "note": "comentado en la reunión; las notas dicen que nadie lo anotó como riesgo"
 }
 ],
 "assumptions": [],
 "issues": [
 {
 "what": {
 "value": "La prueba de carga de temporada no alcanzó el umbral pactado y se repite",
 "source": "20-seguimiento/2026-10-17-informe-avance.md",
 "source_date": "2026-10-17",
 "state": "found"
 },
 "since": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "owner": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 }
 }
 ],
 "dependencies": []
 },
 "changes": [],
 "commitments": [
 {
 "who": {
 "value": "Beatriz Cuéllar"
 },
 "what": {
 "value": "Enviar el documento 1",
 "source": "30-reuniones/2026-09-05-comite-semanal.md"
 },
 "due_date": {
 "value": "2026-12-19"
 },
 "original_due_date": {
 "value": "2026-09-28"
 },
 "stated_on": "2026-09-05",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-17",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md"
 },
 {
 "due_date": "2026-11-04",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md"
 },
 {
 "due_date": "2026-11-11",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md"
 },
 {
 "due_date": "2026-11-25",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 },
 {
 "due_date": "2026-12-05",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 },
 {
 "due_date": "2026-12-19",
 "stated_on": "2026-10-17",
 "source": "2026-10-17-notas-reunion.txt"
 }
 ]
 },
 {
 "who": {
 "value": "Óscar Ramírez"
 },
 "what": {
 "value": "Cerrar la prueba 2",
 "source": "30-reuniones/2026-09-05-comite-semanal.md"
 },
 "due_date": {
 "value": "2026-11-22"
 },
 "original_due_date": {
 "value": "2026-09-25"
 },
 "stated_on": "2026-09-05",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-12",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md"
 },
 {
 "due_date": "2026-10-21",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md"
 },
 {
 "due_date": "2026-11-01",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md"
 },
 {
 "due_date": "2026-11-09",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 },
 {
 "due_date": "2026-11-22",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Camilo Beltrán"
 },
 "what": {
 "value": "Revisar el anexo 3",
 "source": "30-reuniones/2026-09-05-comite-semanal.md"
 },
 "due_date": {
 "value": "2026-11-07"
 },
 "original_due_date": {
 "value": "2026-09-20"
 },
 "stated_on": "2026-09-05",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-02",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md"
 },
 {
 "due_date": "2026-10-22",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 },
 {
 "due_date": "2026-11-07",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "María Restrepo"
 },
 "what": {
 "value": "Validar el ambiente 4",
 "source": "30-reuniones/2026-09-05-comite-semanal.md"
 },
 "due_date": {
 "value": "2026-10-10"
 },
 "original_due_date": {
 "value": "2026-09-24"
 },
 "stated_on": "2026-09-05",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "state": {
 "value": "overdue"
 },
 "reschedules": [
 {
 "due_date": "2026-10-10",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md"
 }
 ],
 "claimed_delivered": {
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "note": "dijo que ya lo entregó; no se presentó acta; salió de la tabla desde el 2026-09-26"
 }
 },
 {
 "who": {
 "value": "Natalia Ospina"
 },
 "what": {
 "value": "Aprobar el diseño 5",
 "source": "30-reuniones/2026-09-12-comite-semanal.md"
 },
 "due_date": {
 "value": "2026-09-30"
 },
 "original_due_date": {
 "value": "2026-09-16"
 },
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "state": {
 "value": "overdue"
 },
 "reschedules": [
 {
 "due_date": "2026-09-30",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md"
 }
 ],
 "claimed_delivered": {
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "note": "dijo que ya lo entregó; no se presentó acta; salió de la tabla el 2026-10-10"
 }
 },
 {
 "who": {
 "value": "Jorge Medina"
 },
 "what": {
 "value": "Actualizar la matriz 6",
 "source": "30-reuniones/2026-09-12-comite-semanal.md"
 },
 "due_date": {
 "value": "2026-11-10"
 },
 "original_due_date": {
 "value": "2026-10-07"
 },
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-23",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 },
 {
 "due_date": "2026-11-10",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Javier Hoyos"
 },
 "what": {
 "value": "Confirmar la fecha 7",
 "source": "30-reuniones/2026-09-12-comite-semanal.md"
 },
 "due_date": {
 "value": "2026-10-18"
 },
 "original_due_date": {
 "value": "2026-09-26"
 },
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-18",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Gustavo Neira"
 },
 "what": {
 "value": "Entregar el punto 8",
 "source": "30-reuniones/2026-09-12-comite-semanal.md"
 },
 "due_date": {
 "value": "2026-10-11"
 },
 "original_due_date": {
 "value": "2026-09-23"
 },
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "state": {
 "value": "met"
 },
 "reschedules": [
 {
 "due_date": "2026-10-11",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md"
 }
 ],
 "evidence": "20-seguimiento/2026-09-26-acta-recibo-8.md",
 "closed_on": "2026-09-26"
 },
 {
 "who": {
 "value": "Ricardo Salas"
 },
 "what": {
 "value": "Enviar el documento 9",
 "source": "30-reuniones/2026-09-19-comite-semanal.md"
 },
 "due_date": {
 "value": "2026-10-05"
 },
 "original_due_date": {
 "value": "2026-09-27"
 },
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "state": {
 "value": "overdue"
 },
 "reschedules": [
 {
 "due_date": "2026-10-05",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md"
 }
 ],
 "claimed_delivered": {
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "note": "dijo que ya lo entregó; no se presentó acta; salió de la tabla el 2026-10-03"
 }
 },
 {
 "who": {
 "value": "Camilo Beltrán"
 },
 "what": {
 "value": "Cerrar la prueba 10",
 "source": "30-reuniones/2026-09-19-comite-semanal.md"
 },
 "due_date": {
 "value": "no_declarada"
 },
 "original_due_date": {
 "value": "no_declarada"
 },
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "state": {
 "value": "open"
 },
 "reschedules": [],
 "stated_as": "por definir",
 "claimed_delivered": {
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "note": "dijo que ya lo entregó; no se presentó acta; salió de la tabla el 2026-09-26"
 }
 },
 {
 "who": {
 "value": "Beatriz Cuéllar"
 },
 "what": {
 "value": "Revisar el anexo 11",
 "source": "30-reuniones/2026-09-19-comite-semanal.md"
 },
 "due_date": {
 "value": "no_declarada"
 },
 "original_due_date": {
 "value": "no_declarada"
 },
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "state": {
 "value": "open"
 },
 "reschedules": [],
 "stated_as": "por definir",
 "claimed_delivered": {
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "note": "dijo que ya lo entregó; no se presentó acta; salió de la tabla el 2026-10-03"
 }
 },
 {
 "who": {
 "value": "Ricardo Salas"
 },
 "what": {
 "value": "Validar el ambiente 12",
 "source": "30-reuniones/2026-09-19-comite-semanal.md"
 },
 "due_date": {
 "value": "2026-09-28"
 },
 "original_due_date": {
 "value": "2026-09-28"
 },
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "state": {
 "value": "met"
 },
 "reschedules": [],
 "evidence": "20-seguimiento/2026-09-26-acta-recibo-12.md",
 "closed_on": "2026-09-26"
 },
 {
 "who": {
 "value": "Felipe Arango"
 },
 "what": {
 "value": "Aprobar el diseño 13",
 "source": "30-reuniones/2026-09-26-comite-semanal.md"
 },
 "due_date": {
 "value": "2026-10-10"
 },
 "original_due_date": {
 "value": "2026-10-10"
 },
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "state": {
 "value": "overdue"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Andrés Lozano"
 },
 "what": {
 "value": "Actualizar la matriz 14",
 "source": "30-reuniones/2026-09-26-comite-semanal.md"
 },
 "due_date": {
 "value": "2026-10-28"
 },
 "original_due_date": {
 "value": "2026-10-08"
 },
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-28",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Mauricio Pérez"
 },
 "what": {
 "value": "Confirmar la fecha 15",
 "source": "30-reuniones/2026-09-26-comite-semanal.md"
 },
 "due_date": {
 "value": "2026-10-25"
 },
 "original_due_date": {
 "value": "2026-10-18"
 },
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-25",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Mauricio Pérez"
 },
 "what": {
 "value": "Entregar el punto 16",
 "source": "30-reuniones/2026-09-26-comite-semanal.md"
 },
 "due_date": {
 "value": "2026-10-08"
 },
 "original_due_date": {
 "value": "2026-10-08"
 },
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "state": {
 "value": "met"
 },
 "reschedules": [],
 "evidence": "20-seguimiento/2026-10-10-acta-recibo-16.md",
 "closed_on": "2026-10-10"
 },
 {
 "who": {
 "value": "María Restrepo"
 },
 "what": {
 "value": "Enviar el documento 17",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 },
 "due_date": {
 "value": "2026-11-07"
 },
 "original_due_date": {
 "value": "2026-10-19"
 },
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-11-07",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "María Restrepo"
 },
 "what": {
 "value": "Cerrar la prueba 18",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 },
 "due_date": {
 "value": "2026-10-23"
 },
 "original_due_date": {
 "value": "2026-10-23"
 },
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Liliana Torres"
 },
 "what": {
 "value": "Revisar el anexo 19",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 },
 "due_date": {
 "value": "2026-10-09"
 },
 "original_due_date": {
 "value": "2026-10-09"
 },
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "state": {
 "value": "overdue"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Felipe Arango"
 },
 "what": {
 "value": "Validar el ambiente 20",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 },
 "due_date": {
 "value": "2026-10-12"
 },
 "original_due_date": {
 "value": "2026-10-12"
 },
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "state": {
 "value": "overdue"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Camilo Beltrán"
 },
 "what": {
 "value": "Aprobar el diseño 21",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 },
 "due_date": {
 "value": "2026-10-18"
 },
 "original_due_date": {
 "value": "2026-10-18"
 },
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Sandra Gil"
 },
 "what": {
 "value": "Actualizar la matriz 22",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 },
 "due_date": {
 "value": "2026-10-14"
 },
 "original_due_date": {
 "value": "2026-10-14"
 },
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "state": {
 "value": "overdue"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Mauricio Pérez"
 },
 "what": {
 "value": "Confirmar la fecha 23",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 },
 "due_date": {
 "value": "2026-10-13"
 },
 "original_due_date": {
 "value": "2026-10-13"
 },
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "state": {
 "value": "overdue"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Ricardo Salas"
 },
 "what": {
 "value": "Entregar el punto 24",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 },
 "due_date": {
 "value": "2026-10-15"
 },
 "original_due_date": {
 "value": "2026-10-15"
 },
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "state": {
 "value": "overdue"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Laura Vélez"
 },
 "what": {
 "value": "Mandar el ajuste del presupuesto",
 "source": "2026-10-17-notas-reunion.txt"
 },
 "due_date": {
 "value": "no_declarada"
 },
 "original_due_date": {
 "value": "no_declarada"
 },
 "stated_on": "2026-10-17",
 "source": "2026-10-17-notas-reunion.txt",
 "state": {
 "value": "open"
 },
 "reschedules": [],
 "stated_as": "la otra semana"
 },
 {
 "who": {
 "value": "Óscar Ramírez"
 },
 "what": {
 "value": "Revisión con el proveedor",
 "source": "2026-10-17-notas-reunion.txt"
 },
 "due_date": {
 "value": "2026-10-27"
 },
 "original_due_date": {
 "value": "2026-10-27"
 },
 "stated_on": "2026-10-17",
 "source": "2026-10-17-notas-reunion.txt",
 "state": {
 "value": "open"
 },
 "reschedules": [],
 "note": "La nota no dice si es la 'prueba 2' (ya en la tabla) o un compromiso nuevo; se registra aparte y no se enlaza."
 }
 ],
 "meta": {
 "record_updated": "2026-10-17",
 "fields_not_found": [
 "identity.authority",
 "identity.phase",
 "vendors",
 "changes"
 ],
 "open_conflicts": [],
 "notes": [
 "El cronograma es la v1 y lleva fecha 2025-09-02 en el nombre, pero declara cerrados hitos de 2026: la fecha del archivo no sostiene esas declaraciones.",
 "Ficha sin sellar: se leyeron las seis minutas, las tres actas de recibo, el informe, las notas de hoy, el acta y el cronograma."
 ]
 }
}
