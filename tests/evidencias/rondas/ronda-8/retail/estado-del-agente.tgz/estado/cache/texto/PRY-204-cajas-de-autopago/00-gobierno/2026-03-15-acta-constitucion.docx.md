<!-- origen: PRY-204-cajas-de-autopago/00-gobierno/2026-03-15-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Cajas de autopago

Código: PRY-204

Área dueña: Comercial

Patrocinador: Natalia Ospina

Gerente de proyecto: Liliana Torres

Comité: Comité Comercial

Producto asociado: autopago en tienda

Fecha de aprobación: 2026-03-15

Objetivo del negocio

Entregar cajas de autopago para Comercial.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

18.000.000.000 COP, aprobado por Comité Comercial el 2026-03-15.

Fechas comprometidas

Fecha

Inicio

2026-03-25

Cierre

2026-10-04

Criterio de éxito

Cajas de autopago en producción y medido.

Dependencias declaradas

• Ninguna declarada
