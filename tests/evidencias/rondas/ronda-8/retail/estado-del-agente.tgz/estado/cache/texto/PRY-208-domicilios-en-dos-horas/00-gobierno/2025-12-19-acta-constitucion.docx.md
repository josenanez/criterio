<!-- origen: PRY-208-domicilios-en-dos-horas/00-gobierno/2025-12-19-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Domicilios en dos horas

Código: PRY-208

Área dueña: Tecnología

Patrocinador: Gustavo Neira

Gerente de proyecto: Jorge Medina

Comité: Comité de Cadena de Abastecimiento

Producto asociado: entrega rápida

Fecha de aprobación: 2025-12-19

Objetivo del negocio

Entregar domicilios en dos horas para Tecnología.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

2.400.000.000 COP, aprobado por Comité de Cadena de Abastecimiento el 2025-12-19.

Fechas comprometidas

Fecha

Inicio

2025-12-29

Cierre

2027-06-06

Criterio de éxito

Domicilios en dos horas en producción y medido.

Dependencias declaradas

• Ninguna declarada
