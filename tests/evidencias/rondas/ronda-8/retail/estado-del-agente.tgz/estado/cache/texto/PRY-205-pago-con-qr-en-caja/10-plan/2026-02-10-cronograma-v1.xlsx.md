<!-- origen: PRY-205-pago-con-qr-en-caja/10-plan/2026-02-10-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la experiencia aprobado | 2026-04-30 | 2026-04-30 | cerrado
Ambiente de pruebas certificado | 2026-07-08 | 2026-07-08 | cerrado
Integración con el ERP | 2026-09-15 | 2026-09-15 | cerrado
