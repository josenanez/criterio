<!-- origen: PRY-209-migración-del-erp/00-gobierno/2026-05-29-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Migración del ERP

Código: PRY-209

Área dueña: Finanzas

Patrocinador: Mauricio Pérez

Gerente de proyecto: Andrés Lozano

Comité: Comité de Cadena de Abastecimiento

Producto asociado: No aplica

Fecha de aprobación: 2026-05-29

Objetivo del negocio

Entregar migración del erp para Finanzas.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

2.400.000.000 COP, aprobado por Comité de Cadena de Abastecimiento el 2026-05-29.

Fechas comprometidas

Fecha

Inicio

2026-06-08

Cierre

2027-02-02

Criterio de éxito

Migración del ERP en producción y medido.

Dependencias declaradas

• Ninguna declarada
