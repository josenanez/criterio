<!-- origen: PRY-209-migración-del-erp/20-seguimiento/2026-10-14-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Migración del ERP

**Código:** PRY-209
**Fecha de corte:** 2026-10-14
**Gerente:** Andrés Lozano

## Estado declarado

**Verde**

Avance reportado: **31%**

## Lo que pasó en el periodo

- Se levantó un hallazgo de seguridad en los medios de pago
- Se recibió el concepto de Jurídica sobre los términos de uso
- Se reprogramó el despliegue por el congelamiento de temporada de fin de año

## Presupuesto

| | COP |
|---|---|
| Aprobado | 2.400.000.000 |
| Comprometido | 2.283.756.927 |
| Ejecutado | 1.079.166.603 |
| Proyección al cierre | 2.287.155.869 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
