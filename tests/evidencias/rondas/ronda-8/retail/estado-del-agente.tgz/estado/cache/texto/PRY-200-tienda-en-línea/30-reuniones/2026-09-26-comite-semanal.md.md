<!-- origen: PRY-200-tienda-en-línea/30-reuniones/2026-09-26-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Transformación Digital · Tienda en línea

**Fecha:** 2026-09-26
**Asistentes:** Andrés Lozano, Beatriz Cuéllar, Camilo Beltrán, Felipe Arango, Javier Hoyos, Jorge Medina, Mauricio Pérez, Natalia Ospina, Ricardo Salas, Rubén Cárdenas, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Beatriz Cuéllar | Enviar el documento 1 | 2026-11-11 |
| Óscar Ramírez | Cerrar la prueba 2 | 2026-11-01 |
| Camilo Beltrán | Revisar el anexo 3 | 2026-10-02 |
| Natalia Ospina | Aprobar el diseño 5 | 2026-09-30 |
| Jorge Medina | Actualizar la matriz 6 | 2026-10-07 |
| Javier Hoyos | Confirmar la fecha 7 | 2026-09-26 |
| Ricardo Salas | Enviar el documento 9 | 2026-10-05 |
| Beatriz Cuéllar | Revisar el anexo 11 | por definir |
| Felipe Arango | Aprobar el diseño 13 | 2026-10-10 |
| Andrés Lozano | Actualizar la matriz 14 | 2026-10-08 |
| Mauricio Pérez | Confirmar la fecha 15 | 2026-10-18 |
| Mauricio Pérez | Entregar el punto 16 | 2026-10-08 |

## Cerrados en esta reunión

- Entregar el punto 8 (Gustavo Neira): recibido, acta de recibo del 2026-09-26.
- Validar el ambiente 12 (Ricardo Salas): recibido, acta de recibo del 2026-09-26.

## Lo que se dijo

- María Restrepo dice que ya entregó «validar el ambiente 4». No se presentó acta.
- Camilo Beltrán dice que ya entregó «cerrar la prueba 10». No se presentó acta.
