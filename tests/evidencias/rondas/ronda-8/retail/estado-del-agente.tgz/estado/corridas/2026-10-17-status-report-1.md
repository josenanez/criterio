# Corrida del 2026-10-17 · status-report

13 proyectos · 32 s · 73 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 21 |
| `commitment_overdue` | 11 |
| `declared_vs_evidence` | 7 |
| `progress_vs_plan` | 6 |
| `vendor_deliverable_late` | 5 |
| `change_without_baseline` | 4 |
| `variance_time` | 4 |
| `commitment_undated` | 3 |
| `commitment_rescheduled` | 3 |
| `variance_cost` | 3 |
| `rebaseline_unauthorized` | 2 |
| `vendor_invoiced_over_accepted` | 2 |
| `budget_committed` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

Informe de estado de PRY-211: verde declarado contradicho por 6 señales; dijo que no sabe la línea base de costo, el motivo de la v2, quién aprobó CC-01 ni las actas de 3 hitos y 3 entregables.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

# PRY-211 Pronóstico de demanda — estado al 2026-10-17

*Sale de la ficha `estado/records/PRY-211.json`, actualizada el 2026-10-17, y de las cifras de `portafolio.py compute` (as_of 2026-10-17). Términos vigentes: v1.1, aceptados por José Francisco Ñáñez el 2026-10-17.*

**Declara el gerente (Beatriz Cuéllar):** verde · 43% · al 2026-09-30 (17 días de antigüedad; no está vencida: el umbral es 30)
**Sustento documental:** contradicho. Es la alerta `declared_vs_evidence`: el gerente reporta verde y hay evidencia que ese verde no cubre.
**Lo que el semáforo no explica** (`declared.unaccounted_signals`):
- `variance_time`: cierre 75 días (17.6%) después de la línea base original.
- `progress_vs_plan`: declara 43% y el plan sostiene entre 80% y 100% (4 de 5 hitos cumplidos), una brecha de 37.0 puntos. El avance declarado queda por debajo de lo que dicen los hitos.
- `milestone_met_without_evidence`: 3 hitos declarados cumplidos sin acta de recibo.
- `commitment_overdue`: 1 compromiso vencido.
- `vendor_deliverable_late`: 2 entregables del proveedor vencidos y pendientes.
- `vendor_invoiced_over_accepted`: facturado por encima de lo aceptado.

**Último documento:** 2026-10-09 (8 días) · **Última reunión:** 2026-10-09, comité semanal (8 días). No está en silencio (umbral 15 días).

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2026-12-26 | 2027-03-11 | +75 días (17.6%) contra la original; 0 contra la vigente |
| Presupuesto | No consta una línea base de costo original separada | 3.300.000.000 COP aprobado | No calculable (ver «Sin dato») |

Replanificaciones: 1. El cronograma v2 es del 2026-09-30 y su motivo no consta (`plan.baseline[v2].reason` = not_found).

Presupuesto (COP, informe del 2026-09-30): aprobado 3.300.000.000 · comprometido 1.100.978.231 (33.4%) · ejecutado 1.403.708.177 (42.5%) · proyección 3.055.066.406 (7.4% por debajo del aprobado) · disponible real 2.199.021.769.
Nota: el ejecutado es mayor que el comprometido; el script no lo marca como alerta, pero conviene que Finanzas lo explique.

### Hitos
| Hito | Base | Vigente | Estado | Evidencia |
|---|---|---|---|---|
| Diseño de la experiencia aprobado | 2026-01-20 | 2026-01-20 | declarado cumplido | **Sin evidencia** (270 días desde el vencimiento) |
| Ambiente de pruebas certificado | 2026-04-15 | 2026-04-15 | cumplido | Acta de recibo del 2026-10-09 |
| Integración con el ERP | 2026-07-09 | 2026-07-09 | declarado cumplido | **Sin evidencia** (100 días) |
| Piloto en tiendas | 2026-10-02 | 2026-10-02 | declarado cumplido | **Sin evidencia** (15 días) |
| Despliegue en la cadena | 2026-12-26 | 2027-03-11 | pendiente | — |

### Dónde no coincide
- **Verde frente a seis señales abiertas.** El informe del 2026-09-30 declara verde; la evidencia (script, as_of 2026-10-17) trae las seis señales de arriba, ninguna explicada por el semáforo.
- **Avance 43% frente a 4 de 5 hitos «cumplidos».** Las dos cifras no pueden ser ciertas a la vez. O el avance está subdeclarado o los hitos están marcados como cumplidos sin estarlo. Tres de ellos no tienen acta.
- **Piloto en tiendas «cumplido» frente a un incidente abierto.** El mismo informe dice que la validación con dos tiendas se extendió una semana por el conteo de inventario.
- **CC-01 aprobado, pero la línea base vigente es anterior.** La solicitud es del 2026-10-04 (+75 días, +150.000.000 COP, ampliación de alcance). El cronograma v2 que ya incluye esos 75 días es del 2026-09-30. Se aprobó «el comité», sin nombre ni fecha de sesión. El script marca `change_without_baseline`. No hay línea base nueva que corresponda al cambio, y no consta quién autorizó el desplazamiento de fechas.
- **Los 150.000.000 COP adicionales de CC-01 no aparecen en el presupuesto aprobado** de 3.300.000.000 que cita el informe. No consta si ya están incluidos.
- **Contrato CT-520 (Retail Andino Consultores S.A.S.).** Facturado 345.838.436 COP (factura del 2026-08-29) frente a 246.790.805 COP aceptados: 99.047.631 COP facturados sin aceptación. Solo 1 de 4 entregables tiene acta de recibo (Configuración del catálogo).

### Abierto
**Riesgos e incidencias sin movimiento:**
- Riesgo: «El proveedor no ha confirmado la fecha de la última entrega». No consta probabilidad, impacto, responsable, fecha ni último movimiento. Este riesgo ya se materializó en parte: hay 2 entregables vencidos.
- Incidencia: «La validación con dos tiendas se extendió una semana por el conteo de inventario». Abierta desde el 2026-09-30, 17 días, sin responsable.
- Incidencia: **«Hallazgo de seguridad en los medios de pago».** Abierta desde el 2026-09-30, 17 días, sin responsable ni movimiento. Es la que más preocupa: debería ir al comité.

**Compromisos vencidos:** Sandra Gil, «Entregar el punto 11», vencido el 2026-09-29 (18 días). Quedó anotado en el comité del 2026-10-09, es decir, ya estaba vencido cuando se anotó. Sin reprogramaciones registradas.

**Entregables del proveedor vencidos:** Licenciamiento de la plataforma (vencía el 2026-01-28; 262 días, pendiente) y Bolsa de horas de desarrollo (2026-05-02; 168 días, pendiente). Soporte del primer trimestre vence el 2026-11-05.

**Dependencias sin confirmar:** ninguna declarada (el acta dice «Ninguna declarada»). El riesgo del proveedor sí describe una dependencia externa que nadie registró como tal.

### Sin dato
- Línea base de costo original, para calcular la desviación del presupuesto.
- Motivo de la replanificación v2.
- Quién aprobó CC-01 y en qué sesión.
- Actas de recibo de 3 hitos declarados cumplidos (diseño, integración con el ERP, piloto).
- Actas de recibo de 3 entregables de CT-520.
- Producto asociado, autoridad y fase (el acta dice «No aplica» para el producto).
- Responsable de las dos incidencias y del riesgo.
- Campos antiguos: 9 campos de identidad y plan vienen del acta del 2025-10-17 y llevan 12 meses; hay que confirmarlos.
- Las 18 lecturas de la ficha vienen sin marcar como evidencia o declaración (0 evidencia, 2 declaración, 16 sin marcar); la clasificación depende de la lectura del agente.

### Después
Hay desviación de tiempo por encima del umbral (17.6% frente a 10%) y una incidencia de seguridad que probablemente excede la autoridad de la gerente. Puedo preparar el punto de comité (`/steering-pack`) y, como el atraso viene de un cambio sin línea base formalizada, la solicitud de cambio (`/change-control`). Comité semanal siguiente: 2026-10-22.

---
*Criterio Portfolio v0.3.13 · ficha PRY-211 actualizada el 2026-10-17 · declaración del gerente del 2026-09-30 · campos inciertos: ver «Sin dato» · Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.13*
