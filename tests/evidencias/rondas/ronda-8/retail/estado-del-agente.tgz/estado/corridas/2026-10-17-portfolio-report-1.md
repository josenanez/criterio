# Corrida del 2026-10-17 · portfolio-report

13 proyectos · 89 documentos, 0 releídos y 89 sin cambio · 28 s · 73 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 21 |
| `commitment_overdue` | 11 |
| `declared_vs_evidence` | 7 |
| `progress_vs_plan` | 6 |
| `vendor_deliverable_late` | 5 |
| `change_without_baseline` | 4 |
| `variance_time` | 4 |
| `commitment_undated` | 3 |
| `commitment_rescheduled` | 3 |
| `variance_cost` | 3 |
| `rebaseline_unauthorized` | 2 |
| `vendor_invoiced_over_accepted` | 2 |
| `budget_committed` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

El informe quedó en `/home/claude/banco/ronda-8/retail/espacio/reportes/index.html`.

Primera corrida con instantánea de hoy: sin delta. 7 verdes contradichos y 13 proyectos sin autoridad identificada.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

# Portafolio — 2026-10-17

Cargué las 13 fichas de `estado/records/` (PRY-199 a PRY-211), todas del barrido del 2026-10-17: ninguna supera la semana. 13 proyectos · 12 con hallazgos · 73 señales · 7 productos.

Términos vigentes (versión 1.1, familia 0.3.13), aceptados por José Francisco Ñáñez el 2026-10-17.

## Qué cambió desde la instantánea anterior
La única instantánea es la de hoy (2026-10-17), así que el diff da 0 cambios. Es el punto de partida del portafolio: no hay delta que reportar.

## Lo que el cálculo marca (todo sale de `portafolio.py compute`; nada a mano)
- **Verdes contradichos por la evidencia: 7 de 13.** Ejemplo: PRY-202 se declara en verde (2026-10-06) con 52 días de atraso (18,4 %) y 21,8 % de sobrecosto proyectado (4.019 M contra 3.300 M aprobados).
- **Desviación en tiempo sobre el umbral del 10 %:** PRY-205 (107 días, 51,7 %), PRY-210 (76 días, 20 %), PRY-211 (75 días, 17,6 %), PRY-202 (52 días, 18,4 %).
- **Desviación en costo sobre el umbral del 10 %:** PRY-208 (27,3 %), PRY-202 (21,8 %), PRY-205.
- **Hitos declarados cumplidos sin evidencia:** señal presente en PRY-200, 201, 203, 205, 206, 208, 210 y 211. Ejemplo: «Diseño de la experiencia aprobado» en PRY-200, 328 días después de su fecha, sin documento que lo respalde.
- **Avance declarado por debajo de lo que sustenta el plan:** PRY-205 (declara 30 %, el plan sustenta 100 %), PRY-206 (51 % contra 100 %), PRY-211 (43 % contra 80–100 %), PRY-203 (28 % contra 60–80 %), PRY-201 (36 % contra 60–80 %), PRY-200 (69 % contra 100 %).
- **Cambios o replanificaciones sin autorización:** PRY-207 movió 31 días sin cambio aprobado; PRY-205 también. PRY-201, PRY-202 y PRY-204 tienen solicitudes de cambio sin línea base nueva.
- **Compromisos vencidos:** PRY-207, Diana Molina, «Entregar el punto 35», venció el 2026-10-10 (7 días). PRY-200 acumula compromisos vencidos, reprogramados y sin fecha.
- **Presupuesto y proveedor:** PRY-209 tiene 95,2 % comprometido (queda disponible real de 116 M). Un entregable de Sistemas Comerciales del Norte lleva 44 días tarde y hay facturación sin entrega.
- **Proyectos en silencio (umbral 15 días):** ninguno. El más callado es PRY-202 con 10 días.
- **Productos con más señales:** venta en línea (21), pago con QR (6), entrega rápida (4), puntos de fidelización (4).

## Vacíos de información
- Ningún proyecto tiene la autoridad que aprueba cambios identificada (13 de 13 sin autoridad), así que los cambios no se pueden contrastar contra quien debía autorizarlos.
- 6 proyectos no están asociados a un producto: PRY-202, 203, 206, 209, 210 y 211.
- Fichas con problemas de estructura: 0. Proyectos sin línea base: 0.

## Dónde quedó el informe
Carpeta `reportes/` (la que sirve Rostrum), 24 páginas:
- `index.html`: vista por campo, con la cadena de evidencia completa. Para quien va a actuar.
- `decisiones.html`: vista por decisión, solo lo que excede la facultad del gerente, con pregunta cerrada y consecuencia de no decidir. Para el patrocinador y el comité.
- Una página por proyecto (`PRY-199.html` … `PRY-211.html`), una por producto, más `productos.html` y `proyectos.html`.

Para PDF se imprime el HTML desde el navegador; está preparado para eso.

## Necesito que confirmes
La confirmación periódica es mensual y no hay registro de una anterior. Sin nadie que responda en esta sesión, la dejo pendiente; no inventé las cinco preguntas.

---
Criterio Portfolio 0.3.13 · fichas del 2026-10-17 · campos inciertos: ver las señales `declared_vs_evidence` y la ausencia de autoridad en las 13 fichas · términos: https://www.josenanez.com/es/agents/criterio-pmo/legal
