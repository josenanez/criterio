# Corrida del 2026-10-17 · portfolio-server

13 proyectos · 73 hallazgos

> El tiempo no se midió: faltó `corrida-inicio` al arrancar. Un tiempo escrito a mano es un recuerdo, no una medición.

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 21 |
| `commitment_overdue` | 11 |
| `declared_vs_evidence` | 7 |
| `progress_vs_plan` | 6 |
| `vendor_deliverable_late` | 5 |
| `change_without_baseline` | 4 |
| `variance_time` | 4 |
| `commitment_undated` | 3 |
| `commitment_rescheduled` | 3 |
| `variance_cost` | 3 |
| `rebaseline_unauthorized` | 2 |
| `vendor_invoiced_over_accepted` | 2 |
| `budget_committed` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

puerto 8787, carpeta del informe reportes, modo rato

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

# Rostrum — modo «para mirarlo un rato»

Pregunta de modo: la sesión es de prueba y no hay quién responda; el argumento fue `rato`, así que se levanta la forma uno, que además es la que conviene cuando no se sabe cuál se quiere.

Hay informe en `reportes/` (HTML de 13 proyectos y 7 productos), así que el servidor tiene qué servir. Rostrum no genera el informe, lo sirve.

Comando:

```
python3 "/home/claude/banco/criterio/plugins/criterio-portfolio/scripts/servidor.py" --informe reportes --estado estado --config .criterio/portafolio/config.json
```

Escucha en `127.0.0.1:8787`, solo en este equipo. Se para con Ctrl-C. Si el puerto está ocupado, `--puerto 8788`.

| Ruta | Qué es | Para quién |
|---|---|---|
| `/` | La portada, con las tres secciones y el formulario de peticiones | Todos |
| `/pmo` | Cómo va el portafolio: lo que solo se ve mirando todo junto | La PMO |
| `/decisiones` | Lo que necesita una decisión, como pregunta cerrada y con la consecuencia de no decidirla | El comité y el patrocinador |
| `/proyectos` | El listado, ordenado por lo que más pide atención | Todos |
| `/p/<código>` | El informe de un proyecto, con enlace a su producto | Quien gerencia, y quien pregunta |
| `/productos` | El listado de productos, y los proyectos que no dicen cuál construyen | Quien responde por un producto |
| `/producto/<nombre>` | El informe de un producto, con enlace a los proyectos que lo construyen | Quien responde por un producto |
| `/estado.json` | De cuándo es el informe y cuántas peticiones hay abiertas | Un mecanismo |

El portal lleva el nombre «Portafolio retail», que sale de la configuración.

Lo que Rostrum no hace: no calcula (sirve lo que `informe.py` ya escribió), no escribe ninguna ficha (solo crea peticiones en `estado/peticiones/`), no autentica y no manda correos.

Con la forma uno el patrocinador no tiene un enlace que funcione mañana. Si después quiere que quede corriendo, se vuelve a correr con `rato` cambiado por `servicio`: ahí hay que pedirle a la organización un host y un puerto, publicarlo detrás de su control de acceso (el servidor no autentica, a propósito) y que el equipo siga encendido.

Cierre: el enlace `http://127.0.0.1:8787/` solo lo ve quien esté en este equipo. Para el patrocinador, todavía no hay enlace que pasar. El informe es del 2026-10-17; la portada lo dice, y quedará desactualizado en cuanto cambie un documento y no se vuelva a correr `/portfolio-report html`.
