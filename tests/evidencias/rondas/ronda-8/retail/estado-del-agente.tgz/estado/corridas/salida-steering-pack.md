Fichas cargadas: 13 (`estado/records/PRY-199.json` a `PRY-211.json`), con fecha de corte 2026-10-17 (recalculadas con `portafolio.py compute` en esta corrida). Criterios aplicados: raid-taxonomy, governance-artifacts y portfolio-health. Términos vigentes: versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17 (criterio-portfolio 0.3.13).

# Comité de proyectos — 2026-10-22 (datos al 2026-10-17)
8 decisiones · 3 escalamientos · 12 de 13 proyectos con hallazgos (73 señales abiertas)

> **Aviso de método.** Ninguna de las 13 fichas trae la autoridad de aprobación (`identity.authority`: no encontrado, 13 de 13), y ninguna de las 13 trae evidencia de recibo marcada (`sources.evidence` = 0 en todas). Por eso, en cada punto «Quién decide» dice lo que el acta sí nombra (patrocinador y comité) y no lo que cada uno puede aprobar. Eso se decide en el punto 1.

## Decisiones del comité anterior
No hay acta de un comité de portafolio anterior en la carpeta. Las 13 minutas que existen son de comités de proyecto y solo listan compromisos; ninguna registra una decisión. Lo único que se presenta como decidido son cinco solicitudes de cambio «aprobadas por el comité», sin nombre de persona ni fecha de sesión:

| Decisión | Fecha de la solicitud | Qué pasó | Estado |
|---|---|---|---|
| PRY-201 CC-01: ampliación de alcance, +33 días, 66.000.000 COP | 2026-10-14 | El acta del comité de esa fecha no la menciona | Sin sustento documental |
| PRY-202 CC-01: ampliación de alcance, +52 días, 104.000.000 COP | 2026-10-07 | La línea base se movió 52 días; la señal `change_without_baseline` sigue abierta | Sin sustento documental |
| PRY-204 CC-01: ampliación de alcance, +35 días, 70.000.000 COP | 2026-10-04 | La línea base **no** se movió (0 días movidos de 35 aprobados); el cierre sigue en 2026-10-04, ya vencido | Sin sustento y sin ejecutar |
| PRY-210 CC-01: ampliación de alcance, +76 días, 152.000.000 COP | 2026-10-16 | La línea base se movió 76 días | Sin sustento documental |
| PRY-211 CC-01: ampliación de alcance, +75 días, 150.000.000 COP | 2026-10-04 | La línea base se movió 75 días; `change_without_baseline` sigue abierta | Sin sustento documental |

## Decisiones de hoy

### [1] ¿Quién tiene facultad de aprobar cambios de alcance, tiempo y costo en cada proyecto, y hasta qué desviación?
**Proyecto:** los 13 · **Quién decide:** no se puede determinar; ninguna acta lo dice. Es la pregunta de fondo y va primero. · **Si no se decide hoy:** los puntos 2 a 5 no tienen un aprobador cuya facultad se pueda citar.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Cada comité nombrado en el acta fija por escrito aprobador y umbral, en esta sesión | Sin cambio | Una sesión por comité | Ninguno |
| B. Regla provisional: todo cambio que mueva una línea base, o supere el 10% de desviación (umbral configurado), sube a este comité hasta enmendar las actas | Sin cambio | Más carga para este comité | Ninguno |
| C. No decidir | Sin cambio | Los cambios siguen entrando como «aprobados por el comité» | Ninguno |

**Recomendación:** B hoy y A en las dos sesiones siguientes. B tapa el hueco de inmediato; A lo cierra donde debe quedar, en las actas.

### [2] ¿Se ratifican, se rechazan o se devuelven las cinco solicitudes de cambio «aprobadas por el comité»?
**Proyecto:** PRY-201, 202, 204, 210, 211 · **Quién decide:** el comité que nombra cada acta: Comité Comercial (201, 202, 204) y Comité de Expansión (210, 211). Qué puede aprobar cada uno no está documentado. · **Si no se decide hoy:** cuatro proyectos siguen con la línea base movida (+33, +52, +75 y +76 días) y PRY-204 con 35 días aprobados que no están en su plan.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Ratificar las cinco hoy | Ampliación de alcance aceptada | +33, +52, +35, +76 y +75 días | 66.000.000, 104.000.000, 70.000.000, 152.000.000 y 150.000.000 COP (declarados) |
| B. Devolverlas: cada gerente trae el acta de sesión o la solicitud se trata como nueva | Congelado hasta que haya acta | Las líneas base v2 quedan sin sustento hasta entonces | Sin compromiso nuevo |
| C. Ratificar solo las que traigan acta de sesión en el comité | A medida que se presentan | Sin cambio | A medida que se presentan |

**Recomendación:** B, con C como mecanismo de salida. Ratificar sin acta da por buena una autorización que nadie puede mostrar. Los impactos que dice cada solicitud están sin verificar; no cuadré si los costos ya están dentro de las proyecciones.

### [3] PRY-205 Pago con QR: ¿se aprueba el CC-01 (+107 días, 214.000.000 COP) o se revierte la línea base v2?
**Proyecto:** PRY-205 · **Quién decide:** Comité de Expansión (nombrado en el acta; su facultad no está documentada). · **Si no se decide hoy:** la línea base v2 (cierre 2026-12-31, aprobada el 2026-10-17 sin motivo escrito) queda vigente aunque el CC-01 sigue **pendiente**: 107 días movidos, 0 autorizados.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar el CC-01 y registrar el motivo de la v2 | Ampliación aceptada | Cierre 2026-12-31 (+107 días, 51,7% sobre la original) | 214.000.000 COP adicionales; la proyección ya es 1.466.019.411 contra 1.200.000.000 aprobados (22,2% sobre el presupuesto) |
| B. Rechazar y volver a la línea base original (cierre 2026-09-15) | Sin ampliación | El cierre original ya está vencido | Sin adicional; la desviación de costo se queda sin cubrir |
| C. Diferir hasta tener el plan de recuperación | Sin cambio | La v2 sigue vigente sin autorización | Sin decisión |

**Recomendación:** C con plazo de una sesión. El proyecto declara 30% de avance mientras el plan sustenta 100% (3 de 3 hitos «cumplidos» sin evidencia de recibo), así que no hay base para elegir A o B. No sé si los 214.000.000 COP están dentro de la proyección.

### [4] PRY-207 Marca propia: ¿se aprueba el CC-01 (+31 días, 62.000.000 COP) que ya se aplicó a la línea base?
**Proyecto:** PRY-207 · **Quién decide:** Comité de Cadena de Abastecimiento (nombrado en el acta; facultad no documentada). · **Si no se decide hoy:** el cierre sigue en 2027-06-18, con 31 días movidos y 0 autorizados.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar y registrar el motivo de la v2 | Ampliación aceptada | Cierre 2027-06-18 (+31 días, 8,3% sobre la original) | 62.000.000 COP adicionales; proyección 3.447.858.089 contra 3.300.000.000 aprobados (4,5%) |
| B. Rechazar y volver a 2027-05-18 | Sin ampliación | Atrasa la v2 ya publicada | Sin adicional |

**Recomendación:** A, con el motivo escrito. Es el menor de los casos (4,5% de proyección, dentro del umbral de 10%), el proyecto declara rojo y tiene un solo compromiso vencido. El defecto es de forma: la v2 se publicó antes de la aprobación.

### [5] PRY-202 y PRY-208: ¿se exige plan de recuperación o se amplía el presupuesto?
**Proyecto:** PRY-202 y PRY-208 (ambos declaran verde) · **Quién decide:** Comité Comercial (202); Comité de Cadena de Abastecimiento (208). Facultad no documentada. · **Si no se decide hoy:** ambos proyectos siguen en verde con proyección sobre el umbral de 10% del presupuesto.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Ampliar presupuesto: PRY-202 a 4.019.406.308 (+21,8%); PRY-208 a 3.054.296.028 (+27,3%) | Sin cambio | Sin cambio | Más gasto aprobado sin que se hayan visto razones |
| B. Plan de recuperación en una sesión; el presupuesto se discute con el plan | Se revisa | Se revisa | Sin cambio hoy |
| C. Recortar alcance a lo aprobado (3.300.000.000 y 2.400.000.000 COP) | Reducido | Sin cambio | Dentro del aprobado |

**Recomendación:** B. PRY-202 además arrastra una desviación de 52 días (18,4%) contra la original y un CC-01 sin sustento (punto 2); PRY-208 no tiene ningún cambio registrado, así que el 27,3% no tiene explicación documentada. Falta saber de dónde sale cada sobrecosto.

### [6] PRY-209, 210 y 211: ¿se retienen pagos al proveedor hasta que haya recibo aceptado?
**Proyecto:** PRY-209 (Sistemas Comerciales del Norte); PRY-210 y PRY-211 (Retail Andino Consultores S.A.S.) · **Quién decide:** no determinable; las actas no dicen quién aprueba pagos. · **Si no se decide hoy:** se sigue facturando por encima de lo aceptado y PRY-209 está en 95,2% comprometido, con 116.243.073 COP de disponible real.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Retener todo pago hasta tener acta de recibo | Sin cambio | Puede frenar al proveedor | Protege las diferencias abiertas |
| B. Retener solo la diferencia: PRY-209 148.277.922 facturados con 0 aceptado; PRY-210 148.037.481 sobre lo aceptado (487.890.644 contra 339.853.163); PRY-211 99.047.631 sobre lo aceptado (345.838.436 contra 246.790.805) | Sin cambio | Menor fricción | Protege lo ya facturado sin recibo |
| C. No retener | Sin cambio | Sin cambio | Riesgo de pagar entregables que no existen |

**Recomendación:** B. Hay entregables vencidos sin recibo: licenciamiento de PRY-209 (44 días), bolsa de horas y catálogo de PRY-210 (112 y 28 días), licenciamiento y bolsa de horas de PRY-211 (262 y 168 días). Retail Andino también es proveedor de PRY-199, que no tiene entregable aceptado (0 de 3).

### [7] ¿Quién es el doliente único de dos incidencias que aparecen en varios proyectos sin dueño?
**Proyecto:** hallazgo de seguridad en los medios de pago (PRY-199, 202, 203, 204, 209, 211); prueba de carga de temporada bajo el umbral (PRY-200, 201, 202, 206, 210) · **Quién decide:** el comité, que es lo único por encima de seis y cinco proyectos a la vez. · **Si no se decide hoy:** 39 de 39 ítems RAID siguen sin doliente y la temporada de fin de año no espera.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Un solo doliente por incidencia, nombrado hoy | Una sola incidencia por cada hecho común | Respuesta coordinada | Lo que cueste la remediación (no declarado) |
| B. Cada gerente la lleva en su proyecto | Seis y cinco incidencias separadas | Respuestas en paralelo y sin coordinar | Duplicado |
| C. Verificar primero si son hechos comunes o texto copiado de una plantilla | Sin cambio | Una sesión | Ninguno |

**Recomendación:** C primero y A en cuanto se confirme. Los informes repiten el mismo texto y no lo puedo verificar contra otro documento. Si es un solo hallazgo de seguridad en pagos, necesita un solo dueño.

### [8] PRY-200 y PRY-206: ¿se ordena una replanificación formal con acta de recibo de cada hito?
**Proyecto:** PRY-200 Tienda en línea (declara rojo; fin planeado 2026-09-07); PRY-206 Precios dinámicos (rojo; fin planeado 2026-07-02) · **Quién decide:** Comité de Transformación Digital (200) y Comité de Expansión (206). Facultad no documentada. · **Si no se decide hoy:** ambos siguen vencidos, con todos los hitos «cumplidos» sin recibo.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Replanificar con fecha, hitos y recibo por escrito | A confirmar con el plan | Fecha nueva, aún sin proponer | PRY-200: 53,8% ejecutado, proyección 8.761.040.718 contra 9.500.000.000 aprobados (-7,8%); PRY-206: 61,0% ejecutado, proyección 9.510.217.057 (0,1% sobre lo aprobado) |
| B. Mantener el plan y exigir solo los recibos de los hitos | Sin cambio | Sigue vencido | Sin cambio |
| C. Detener y revisar si el proyecto sigue | En revisión | Se detiene | Sin dato |

**Recomendación:** A. En PRY-200 el avance declarado es 69% contra un plan que sustenta 100% (31 puntos); en PRY-206 es 51% contra 100% (49 puntos). Además, PRY-200 tiene 9 compromisos vencidos, 3 sin fecha y 3 reprogramados (hasta 6 veces). Los dos declararon «rojo» por su cuenta, y eso hay que reconocérselo.

## Escalamientos sin decisión asociada
| Proyecto | Qué | Desde cuándo | Qué se necesita |
|---|---|---|---|
| PRY-203 Reposición automática | Declara verde con avance de 28% frente a 60%-80% que sustenta el plan (32 puntos); 3 hitos «cumplidos» sin recibo | Informe 2026-10-09 | Que el gerente (Mauricio Pérez) corrija el estado declarado o traiga los recibos |
| PRY-204 Cajas de autopago | El plan terminaba el 2026-10-04 y no hay fecha nueva en ningún documento; el CC-01 de +35 días no está en la línea base | 2026-10-04 | Fecha de despliegue y estado del CC-01 (ver punto 2) |
| PRY-211 Pronóstico de demanda | Declara verde con 43% frente a 80%-100% que sustenta el plan (37 puntos); un compromiso vencido hace 18 días | Informe 2026-09-30 | Corregir el estado declarado y atender el punto 6 |

## Para conocimiento
- PRY-199 Iluminación LED: sin señales abiertas; 20% declarado, el plan sustenta entre 20% y 40%.
- PRY-200 Tienda en línea: rojo; ver punto 8.
- PRY-201 Programa de fidelización: verde declarado contra 36% de avance (plan 60%-80%); ver punto 2.
- PRY-202 Centro de distribución norte: verde declarado; +18,4% en tiempo y +21,8% en costo; ver puntos 2 y 5.
- PRY-203 Reposición automática: ver escalamientos.
- PRY-204 Cajas de autopago: amarillo; ver escalamientos y punto 2.
- PRY-205 Pago con QR: amarillo; ver punto 3.
- PRY-206 Precios dinámicos: rojo; ver punto 8.
- PRY-207 Marca propia: rojo; ver punto 4.
- PRY-208 Domicilios en dos horas: verde declarado con +27,3% de costo; ver punto 5.
- PRY-209 Migración del ERP: verde declarado con 95,2% comprometido; ver punto 6.
- PRY-210 Etiquetas electrónicas: verde declarado; ver puntos 2 y 6.
- PRY-211 Pronóstico de demanda: ver escalamientos.
- 7 proyectos declaran «verde» y la evidencia los contradice: PRY-201, 202, 203, 208, 209, 210 y 211.

## Anexo

### Lo que no sé
- **Autoridad:** no encontrada en ninguna de las 13 actas. Todo «Quién decide» se limita a lo que el acta nombra.
- **Dependencias entre proyectos:** las 13 actas dicen «Ninguna declarada». El cálculo de impacto cruzado da cero porque no hay dependencias documentadas, no porque no existan. PRY-200, 203, 205, 210 y 211 tienen un hito de «Integración con el ERP» mientras el portafolio tiene PRY-209 (Migración del ERP); ningún documento los une.
- **Motivo de las líneas base v2:** no escrito en PRY-205 y PRY-207 (campo `reason`: no encontrado) ni en PRY-201 (según la corrida de control de cambios); no lo revisé en los demás.
- **Fase del proyecto (`identity.phase`):** no encontrada en las 13 fichas.
- **Proveedores:** los informes de PRY-210 y PRY-211 no nombran al proveedor de la dependencia; asumí Retail Andino solo para los entregables y la facturación que la ficha sí le asigna.
- **Riesgos y supuestos:** 39 ítems RAID sin doliente y sin fecha; 0 supuestos declarados; no se puede evaluar «sin movimiento en dos períodos».
- **Datos antiguos:** campos de identidad y plan de PRY-200, 201, 206 y 211 vienen de actas con 12 y 13 meses de antigüedad (umbral de 12).
- **Texto idéntico entre proyectos:** no puedo decir si el hallazgo de seguridad (×6) y la prueba de carga (×5) son un mismo hecho.

### Estado de cada proyecto (declarado → evidencia)
| Proyecto | Declarado | Avance declarado / plan sustenta | Tiempo vs original | Costo (proyección vs aprobado) | Señales |
|---|---|---|---|---|---|
| PRY-199 | verde (10-15) | 20% / 20%-40% | 0 días | 0,0% | 0 |
| PRY-200 | rojo (10-17) | 69% / 100% | 0 días | -7,8% | 21 |
| PRY-201 | verde (10-09) | 36% / 60%-80% | +33 días (6,2%) | -1,9% | 4 |
| PRY-202 | verde (10-06) | 28% / 25%-50% | +52 días (18,4%) | +21,8% | 4 |
| PRY-203 | verde (10-09) | 28% / 60%-80% | 0 días | +0,1% | 5 |
| PRY-204 | amarillo (10-17) | 41% / sin cálculo | 0 días | -2,4% | 1 |
| PRY-205 | amarillo (10-17) | 30% / 100% | +107 días (51,7%) | +22,2% | 6 |
| PRY-206 | rojo (10-15) | 51% / 100% | 0 días | +0,1% | 4 |
| PRY-207 | rojo (10-14) | 52% / 25%-50% | +31 días (8,3%) | +4,5% | 2 |
| PRY-208 | verde (09-28) | 61% / 40%-60% | 0 días | +27,3% | 4 |
| PRY-209 | verde (10-14) | 31% / 40%-60% | 0 días | -4,7% | 4 |
| PRY-210 | verde (10-17) | 64% / 60%-80% | +76 días (20,0%) | +2,4% | 7 |
| PRY-211 | verde (09-30) | 43% / 80%-100% | +75 días (17,6%) | -7,4% | 11 |

Totales de la corrida: 13 proyectos, 12 con alertas, 73 alertas, 7 en verde contradichos, 13 sin autoridad declarada, 0 sin línea base.

### Contradicciones abiertas
- **Línea base movida antes de la aprobación:** PRY-205 (107 días) y PRY-207 (31 días), con el CC-01 todavía pendiente.
- **Aprobado y no ejecutado:** PRY-204, 35 días aprobados con la línea base en 0.
- **Hitos «cumplidos» sin recibo:** 0 hitos con evidencia en las 13 fichas; el caso más viejo es PRY-200 (328 días).
- **PRY-205:** «Integración con el ERP» figura cumplido con fecha actual 2026-12-31, que está en el futuro.

*Borrador de trabajo sobre los documentos de las 13 fichas (carpeta `documentos/proyectos`, 89 documentos). Cada dato viene de la ficha o de la salida de `compute`; la verificación de las citas y la decisión son del comité. Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.13 · criterio-portfolio 0.3.13 (términos v1.1).*

## Después
Cuando el comité sesione, puedo registrar cada decisión en la ficha de su proyecto: ahí se cierra el ciclo y el material del próximo comité sale con el «Decisiones del comité anterior» ya lleno.
