*Sale de: ficha PRY-209, `00-gobierno/2026-06-04-contrato-ct-865.docx`, `20-seguimiento/2026-09-11-factura-ct-865.pdf`, las dos actas de recibo y el informe de avance del 2026-10-14, y de la salida de `portafolio.py compute` al 2026-10-17. Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17).*

## Proveedores — PRY-209 Migración del ERP al 2026-10-17

### Sistemas Comerciales del Norte — contrato CT-865
**Vigencia:** sin dato (el contrato solo trae fecha de firma, 2026-06-04) · **Preaviso de no renovación:** sin dato · **Vence el:** sin dato

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento de la plataforma | 2026-09-03 · 148.277.922 COP | `unknown`: el contrato lo marca «pendiente»; vencido hace 44 días | Ninguna | Ver abajo |
| Bolsa de horas de desarrollo | 2026-11-30 · 148.277.922 COP | `unknown`: el contrato dice «en curso»; aún no vence | Ninguna | Ver abajo |

Total facturado al proveedor: 148.277.922 COP (factura FV-1865, 2026-09-11). Entregables aceptados: 0 de 2.

### Dónde no cuadra
| Qué | Dice el contrato | Dice la evidencia | Fuentes |
|---|---|---|---|
| Factura FV-1865 por 148.277.922 COP | «Cada entregable se factura contra acta de recibo firmada por el gerente del proyecto» | No existe ningún acta de recibo de un entregable de CT-865. Las dos actas de la carpeta (2026-10-06 y 2026-10-14) son de hitos del proyecto, no del proveedor. La factura es posterior en 5 días a la fecha comprometida del licenciamiento y anterior a las dos actas | contrato CT-865; factura FV-1865; actas de recibo |
| Qué entregable cubre la factura | Dos entregables de igual monto (148.277.922 COP cada uno) | La factura dice «Entregables del contrato CT-865», sin precisar cuál. Su valor coincide con el de cualquiera de los dos | contrato; factura |

El script levanta `vendor_invoiced_without_delivery`: hay factura y ningún entregable aceptado.

### Sin evidencia de recibo
| Entregable | Marcado como | Desde |
|---|---|---|
| Licenciamiento de la plataforma | «pendiente» (contrato) | Vencido desde 2026-09-03 (44 días) |
| Bolsa de horas de desarrollo | «en curso» (contrato) | Vence 2026-11-30; sin acta que sustente avance |

Ninguno está declarado entregado o aceptado, así que `accepted_without_evidence` es vacío.

### Compromisos del proveedor vencidos
Ninguno registrado: la ficha no tiene compromisos porque la carpeta no contiene actas de comité ni minutas. Eso es ausencia de documentos, no de compromisos.

### Contexto que la PMO debe ver
- El informe de avance del 2026-10-14 declara **verde**. El script lo contrasta con tres señales sin explicar: presupuesto comprometido al 95,2 % (disponible real 116.243.073 COP), el licenciamiento vencido y la factura sin entrega.
- Avance declarado 31 %; el plan sustenta entre 40 % y 60 % (2 de 5 hitos cumplidos). No es un hallazgo del proveedor, pero queda anotado.

### Sin dato
- Vigencia, terminación, renovación automática y preaviso de CT-865: el contrato no los trae. No se puede decir si hay un preaviso por vencer.
- Si la factura FV-1865 se pagó o está solo radicada: dice «Radicada en cuentas por pagar», sin fecha de pago.
- Qué entregable pretende cubrir la factura.
- Cualquier correo o minuta que acepte el licenciamiento fuera de la carpeta.

## Después
Hay una factura de 148.277.922 COP sin acta de recibo que la sustente. Recomiendo llevarla al comité del 2026-10-22 y, antes, pedir a Andrés Lozano (gerente) el acta del licenciamiento o confirmar que no existe, y pedir a cuentas por pagar que retengan el pago si está pendiente. La decisión es de la PMO y del comité.

*Rigor: cifras copiadas de `compute`; estados `unknown` por falta de evidencia, no por conclusión de incumplimiento. Lo que no está en los documentos no se afirma. La verificación contra las fuentes citadas es de quien lee.*
