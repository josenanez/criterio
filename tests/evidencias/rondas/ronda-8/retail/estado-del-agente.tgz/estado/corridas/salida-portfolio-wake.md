## 2026-10-17

**Revisé:** 89 documentos · 0 cambiaron · 0 proyectos recalculados

Términos: ya vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17); no hubo que volver a pedirlos.

### Lo que cruzó un umbral
Nada por cambio de documentos. Un hallazgo de citas: **PRY-200 (Tienda en línea)** tiene 63 citas en su ficha que el índice no resuelve (identidad, plan, dinero, RAID, compromisos). Los documentos citados **sí existen** en la carpeta del proyecto; el problema es que la ficha de PRY-200 los cita sin el prefijo de la carpeta del proyecto (`00-gobierno/…` en vez de `PRY-200-tienda-en-línea/00-gobierno/…`), a diferencia de las demás fichas. No lo corregí: reescribir la ficha es trabajo de `/portfolio-scan`, y ningún documento cambió. Queda abierto para el próximo scan de PRY-200.

### Peticiones atendidas
Ninguna: no había peticiones en el servidor.

### Preguntas
Nadie responde en esta sesión de prueba, así que quedan **preguntadas el 2026-10-17, sin respuesta** (la respuesta sugerida es «sin cambios», y no la tomo como confirmación). Cinco campos de PRY-200, todos con fuente del 2025-09-02 (más de 12 meses, umbral `stale_field_months`):

1. Presupuesto aprobado: COP 9.500.000.000 — acta de constitución, 2025-09-02.
2. Fecha de fin del plan — cronograma v1, 2025-09-02.
3. Patrocinador — acta de constitución, 2025-09-02.
4. Gerente del proyecto — acta de constitución, 2025-09-02.
5. Comité al que reporta — acta de constitución, 2025-09-02.

**Vuelvo el 2026-10-18.** El informe de comité del 2026-10-22 toca el 2026-10-20.
