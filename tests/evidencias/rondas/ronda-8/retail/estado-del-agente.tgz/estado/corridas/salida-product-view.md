**Vista por producto: pago con QR.** Sale de las fichas en `estado/records`, recalculadas con `portafolio.py compute` al 2026-10-17. Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17).

## Productos al 2026-10-17

| Producto | Proyectos | Con alertas | Fecha más tardía | Aprobado | Comprometido |
|---|---|---|---|---|---|
| pago con QR | 1 (PRY-205) | 6 alertas | 2026-12-31 (PRY-205) | COP 1.200.000.000 | COP 832.019.377 |

**pago con QR tiene un solo proyecto (PRY-205 Pago con QR en caja).** La vista por producto no aporta más que la ficha del proyecto, así que no armo sección de producto. Estas son las señales de PRY-205, copiadas del cálculo:

- **Atraso de fechas:** 107 días contra la línea base original (51,7 %). Contra la vigente es 0 días.
- **Cambio de línea base sin autorización:** se movió 107 días y se autorizaron 0. Hay 1 cambio visto.
- **Avance contra plan:** el gerente declara 30,0 %. Los 3 hitos del plan están declarados cumplidos, y eso sustenta 100 %. La brecha es de 70,0 puntos.
- **Hitos cumplidos sin evidencia:** "Diseño de la experiencia aprobado" (vencía 2026-04-30, hace 170 días) y "Ambiente de pruebas certificado" (vencía 2026-07-08, hace 101 días).
- **Costo:** la proyección es COP 1.466.019.411 contra COP 1.200.000.000 aprobados, es decir 22,2 % por encima.
- **Dinero:** ejecutado COP 530.498.809 (44,2 %), comprometido COP 832.019.377 (69,3 %), disponible real COP 367.980.623. Las cuatro cifras están presentes.
- **Lo declarado:** el estado declarado es amarillo, con fecha 2026-10-17. Las cinco señales anteriores no están reconocidas en ese informe.
- **Dependencias:** ninguna declarada, ni de PRY-205 hacia otro proyecto ni de otros hacia PRY-205. No hay dependencias internas que llevar al comité de producto.
- **Fecha comprometida del producto:** 2026-12-31, que sale de PRY-205.
- **Campos sin dato en la ficha:** `identity.authority` y `identity.phase`.

### Proyectos sin producto declarado (6 de 13)

| Proyecto | Área dueña |
|---|---|
| PRY-202 Centro de distribución norte | Tiendas |
| PRY-203 Reposición automática | Tecnología |
| PRY-206 Precios dinámicos | Comercio electrónico |
| PRY-209 Migración del ERP | Finanzas |
| PRY-210 Etiquetas electrónicas de precio | Comercio electrónico |
| PRY-211 Pronóstico de demanda | Comercio electrónico |

Consecuencia: nadie puede responder por el conjunto al que sirven. Es un hallazgo de gobierno. Si alguno sirve en realidad a "pago con QR", esta vista está incompleta, y no lo puedo saber desde las fichas.

*Pie de rigor:* las cifras vienen de `portafolio.py compute`. Los hitos "cumplidos sin evidencia" son hitos declarados cumplidos sin documento que lo sustente. La verificación contra los documentos citados es de quien lee este informe.
