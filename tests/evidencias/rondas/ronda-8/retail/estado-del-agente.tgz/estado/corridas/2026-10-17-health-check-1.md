# Corrida del 2026-10-17 · health-check

13 proyectos · 63 s · 73 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 21 |
| `commitment_overdue` | 11 |
| `declared_vs_evidence` | 7 |
| `progress_vs_plan` | 6 |
| `vendor_deliverable_late` | 5 |
| `change_without_baseline` | 4 |
| `variance_time` | 4 |
| `commitment_undated` | 3 |
| `commitment_rescheduled` | 3 |
| `variance_cost` | 3 |
| `rebaseline_unauthorized` | 2 |
| `vendor_invoiced_over_accepted` | 2 |
| `budget_committed` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

Diagnóstico de PRY-200 desde 14 documentos: 8 sostenidas, 11 sin sustento, 2 contradichas. Dijo que no puede afirmar si el despliegue ocurrió (sin acta de producción), ni la autoridad del gerente, ni el gasto real (sin soporte contable), ni el contrato del proveedor.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## Diagnóstico · PRY-200 Tienda en línea · 2026-10-17

**Leí:** 14 documentos · del 2025-09-02 al 2026-10-17 · formatos: .md (11), .txt (1), .xlsx (1), .json (1)
**No pude leer:** nada quedó ilegible. `00-gobierno/ficha-pm.json` es la ficha del propio gerente: leí solo su encabezado y no me apoyo en ella. Antes de leer los documentos abrí la ficha previa de la PMO (`estado/records/PRY-200.json`). Cada afirmación de abajo la volví a comprobar contra los documentos.

Términos: vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17). No hubo que registrarlos de nuevo.

### Dictamen
**Sostenido:** 8 afirmaciones · **Sin sustento:** 11 · **Contradicho:** 2

De esta carpeta se puede afirmar quién patrocina, quién gerencia, qué comité aprobó y con cuánto presupuesto. También se puede afirmar que tres compromisos se cerraron con acta de recibo. No se puede afirmar que el proyecto esté donde dice el cronograma. Ese cronograma marca los cinco hitos como cerrados, incluido el despliegue en la cadena del 2026-09-07, y el informe del 2026-10-17 declara el proyecto en **rojo**, con **69%** de avance y una prueba de carga que no alcanzó el umbral. Ninguno de los cinco cierres tiene un documento de evidencia. Tampoco hay quien tenga autoridad declarada para aprobar desviaciones. Las cifras de dinero salen solo del informe del gerente, sin ningún soporte contable en la carpeta.

### Gobierno
| | Qué dice el documento | Fuente |
|---|---|---|
| Patrocinador | Jorge Medina | 00-gobierno/2025-09-02-acta-constitucion.md |
| Gerente | Rubén Cárdenas | 00-gobierno/2025-09-02-acta-constitucion.md |
| Autoridad declarada | **No está.** El acta no dice qué puede aprobar el gerente en fechas, costo o alcance | acta de constitución (ausencia) |
| Comité | Comité de Transformación Digital; aprobó el presupuesto el 2025-09-02. Se reúne cada semana según las minutas (6 minutas, del 2026-09-05 al 2026-10-10) | acta; 30-reuniones/ |

Sin autoridad declarada no hay desviación aprobada. Las fechas movidas son fechas que alguien escribió. En la carpeta no hay ninguna solicitud de cambio.

### Contra el plan
- **Línea base original (v1):** inicio 2025-09-12, cierre 2026-09-07, aprobada el 2025-09-02 (acta y cronograma coinciden).
- **Línea base vigente:** es la misma. No hay replanificaciones ni control de cambios (0 cambios, 0 replanificaciones).
- **Desviación en tiempo:** el cálculo da 0 días, y no se puede tomar como cierto. Sale del cronograma v1, que marca todo como cerrado. Hoy son 40 días desde el cierre comprometido (2026-09-07), y el informe del 2026-10-17 declara el proyecto en rojo, así que ese 0 contradice el informe.
- **Avance:** el cronograma sostiene 100% (5 de 5 hitos cerrados) y el gerente declara 69%. Son 31.0 puntos de diferencia.
- El cronograma se llama `2025-09-02-cronograma-v1.xlsx` pero declara cerrados hitos de 2026. Un archivo fechado en 2025 no puede dar fe de esos cierres.

### Hitos vencidos sin evidencia
| Hito | Fecha | Días desde la fecha | Qué documento se esperaría |
|---|---|---|---|
| Diseño de la experiencia aprobado | 2025-11-23 | 328 | Acta de aprobación del diseño |
| Ambiente de pruebas certificado | 2026-02-03 | 256 | Certificado o acta de pruebas |
| Integración con el ERP | 2026-04-16 | 184 | Acta de recibo o informe de pruebas de integración |
| Piloto en tiendas | 2026-06-27 | 112 | Informe de cierre del piloto |
| Despliegue en la cadena | 2026-09-07 | 40 | Acta de puesta en producción (criterio de éxito: «en producción y medido») |

Los cinco figuran como «cerrado» sin ningún documento que lo respalde. La carpeta solo tiene tres actas de recibo (puntos 8, 12 y 16), y son de compromisos de las reuniones, no de estos hitos.

### Dinero
| Aprobado | Comprometido | Ejecutado | Proyección | Disponible real |
|---|---|---|---|---|
| 9.500.000.000 COP | 5.420.644.515 COP | 5.110.694.551 COP | 8.761.040.718 COP | 4.079.355.485 COP |

- Ejecutado: 53.8% de lo aprobado. Comprometido: 57.1%. La proyección queda 7.8% por debajo de lo aprobado (−7.8).
- Aprobado coincide entre el acta y el informe. Comprometido, ejecutado y proyección solo salen del informe, sin libro, contrato ni facturas que los soporten.
- Línea base de costo: solo hay una (la del acta). No hay presupuesto vigente distinto del original.
- Laura Vélez se comprometió el 2026-10-17 a mandar «el ajuste del presupuesto la otra semana». Eso sugiere que las cifras van a cambiar, y nadie dijo de cuánto.

### Lo que se dijo y nadie registró
- **Riesgo, dicho en la reunión del 2026-10-17:** el proveedor podría no llegar con el equipo completo para la siguiente fase. Las notas dicen que nadie lo anotó como riesgo.
- **Dependencia sin registrar:** el informe habla de «la última entrega» del proveedor sin fecha confirmada, pero el acta dice «Ninguna declarada» y no hay contrato de proveedor en la carpeta.
- **Riesgos del informe sin dueño ni fecha:** el cambio en la regulación de datos personales y la fecha sin confirmar del proveedor.
- **Incidencia sin dueño:** la prueba de carga de temporada no alcanzó el umbral y se repite, sin responsable ni fecha.
- **Compromisos vencidos (9),** en días desde su fecha:

| Responsable | Compromiso | Vencía | Días |
|---|---|---|---|
| Natalia Ospina | Aprobar el diseño 5 | 2026-09-30 | 17 |
| Ricardo Salas | Enviar el documento 9 | 2026-10-05 | 12 |
| Liliana Torres | Revisar el anexo 19 | 2026-10-09 | 8 |
| María Restrepo | Validar el ambiente 4 | 2026-10-10 | 7 |
| Felipe Arango | Aprobar el diseño 13 | 2026-10-10 | 7 |
| Felipe Arango | Validar el ambiente 20 | 2026-10-12 | 5 |
| Mauricio Pérez | Confirmar la fecha 23 | 2026-10-13 | 4 |
| Sandra Gil | Actualizar la matriz 22 | 2026-10-14 | 3 |
| Ricardo Salas | Entregar el punto 24 | 2026-10-15 | 2 |

- **Compromisos sin fecha (3):** Camilo Beltrán «Cerrar la prueba 10» y Beatriz Cuéllar «Revisar el anexo 11» (ambos «por definir» desde el 2026-09-19), y Laura Vélez, ajuste del presupuesto («la otra semana»).
- **Reprogramados reunión tras reunión:**
  - Beatriz Cuéllar, «Enviar el documento 1»: 6 veces. Era para el 2026-09-28 y quedó para el 2026-12-19.
  - Óscar Ramírez, «Cerrar la prueba 2»: 5 veces. Era para el 2026-09-25 y quedó para el 2026-11-22.
  - Camilo Beltrán, «Revisar el anexo 3»: 3 veces. Era para el 2026-09-20 y quedó para el 2026-11-07.
- **«Revisión con el proveedor» (Óscar Ramírez, 2026-10-27):** las notas no dicen si es la «prueba 2» (ya en la tabla) o un compromiso nuevo. No lo enlazo.
- **Silencio:** el proyecto no está en silencio (0 días). El silencio es de evidencia. Después del 2026-10-10 no hay un solo documento de recibo, y los hitos no tienen ninguno.

### Contradicho
| Afirmación | Documento A | Documento B |
|---|---|---|
| «Despliegue en la cadena» cerrado, fecha 2026-09-07 | Cronograma v1 (estado «cerrado») | Informe de avance 2026-10-17: estado rojo y una prueba de carga que se repite |
| Plan al 100% (5 de 5 hitos cerrados) | Cronograma v1 | Informe de avance 2026-10-17: avance 69% |

### Sin sustento
- Cuatro cierres de hitos (diseño, ambiente de pruebas, integración con el ERP, piloto): ningún documento los respalda y nada los contradice directamente.
- Cinco «ya lo entregué» dichos en comité sin acta de recibo, todos ya salidos de la tabla de compromisos:
  - María Restrepo, ambiente 4 (dicho el 2026-09-26).
  - Camilo Beltrán, prueba 10 (2026-09-26).
  - Ricardo Salas, documento 9 (2026-10-03).
  - Beatriz Cuéllar, anexo 11 (2026-10-03).
  - Natalia Ospina, diseño 5 (2026-10-10).
- El avance de 69%: no hay una medición ni una base de cálculo.
- Comprometido, ejecutado y proyección: solo salen del informe.

(Estas son 11 afirmaciones: 4 + 5 + 1 + 1.)

**Sostenido (8):** patrocinador, gerente y comité; presupuesto aprobado de 9.500.000.000 COP (acta e informe coinciden); cierre comprometido 2026-09-07 (acta y cronograma coinciden); y los tres compromisos cerrados con acta de recibo (punto 8, ambiente 12 y punto 16).

### Lo que esta carpeta no permite saber
- **Si el proyecto está desplegado o no:** falta el acta de puesta en producción. Sin ella no se puede decir si el atraso es cero o si el proyecto ya pasó su fecha de cierre.
- **Quién puede aprobar un cambio de fechas o de presupuesto:** falta la autoridad declarada. Sin ella, la desviación no tiene a quién llevársela.
- **Cuánto se ha gastado de verdad:** faltan contratos, facturas o el libro. Sin ellos, el dinero queda como lo declara el gerente.
- **Qué entrega el proveedor y cuándo:** no hay contrato ni entregables. No se puede cruzar lo entregado con lo facturado.
- **Si la nueva fecha de cierre existe:** no hay línea base vigente ni solicitud de cambio.
- **Qué pasa con los compromisos que dicen estar entregados:** no hay actas.
- **En qué fase está el proyecto:** el campo no aparece en ningún documento.

### Pie de rigor
Todas las cifras derivadas (días, porcentajes, puntos de diferencia, disponible real) se copiaron de la salida de `portafolio.py compute`, con sus dígitos. Este diagnóstico describe lo que muestran los documentos; no recomienda detener, continuar ni reestructurar, que le toca a quien tiene la facultad. La verificación de cada cita es de quien lo lee.

### Siguiente paso posible
El dictamen es que **esta carpeta no permite diagnosticar el estado real del proyecto**. Puedo preparar el punto de comité con la lista de lo que falta. También puedo llevar al gerente las dos contradicciones como preguntas, una por una.
