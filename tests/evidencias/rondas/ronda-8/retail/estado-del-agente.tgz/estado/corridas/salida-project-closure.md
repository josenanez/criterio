## Cierre — PRY-200 Tienda en línea — 2026-10-17

**Sale de:** la ficha `estado/records/PRY-200.json` (sellada a 2026-10-17), la salida de `portafolio.py compute` a 2026-10-17, y estos documentos: acta de constitución (2025-09-02), cronograma v1, informe de avance (2026-10-17), notas de reunión (2026-10-17), seis minutas de comité (2026-09-05 a 2026-10-10) y tres actas de recibo (2026-09-26, 2026-09-26, 2026-10-10). No usé como fuente `00-gobierno/ficha-pm.json`: es el registro del propio gerente, es declaración y no evidencia.

**Términos:** vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17). No hizo falta registrarlos de nuevo.

### Lo primero: el proyecto no ha declarado que terminó
El informe de avance del 2026-10-17 dice **estado Rojo, avance 69 %**, que la prueba de carga de temporada no alcanzó el umbral pactado y se repite, y que el proveedor no ha confirmado la fecha de la última entrega. Nadie ha declarado fin. Lo que sigue es el cierre **por decisión** que se pide, no por cumplimiento, y con la evidencia disponible no se puede sustentar un cierre por cumplimiento. Recomendación: no cerrar y no mover la carpeta a `archivo/` mientras tanto.

### Contra lo comprometido
**Criterio de éxito:** «Tienda en línea en producción y medido» (`00-gobierno/2025-09-02-acta-constitucion.md`). No trae umbral de medición ni dueño de la medición.
**Se cumplió:** **no se puede determinar con evidencia, y lo declarado apunta a que no.** Ningún documento muestra la tienda en producción ni una medición. El informe del 2026-10-17 declara 69 % y una prueba de carga fallida.

| Entregable comprometido | Estado | Evidencia |
|---|---|---|
| Alcance del acta: «Componente 1; Componente 2; Componente 3» | No verificable: los componentes no se nombran | Acta de constitución; ningún acta de recibo los cita |
| Hito «Diseño de la experiencia aprobado» (línea base 2025-11-23) | Cerrado según el cronograma | **Ninguna.** Sin acta de recibo; 328 días desde su fecha |
| Hito «Ambiente de pruebas certificado» (2026-02-03) | Cerrado según el cronograma | **Ninguna.** 256 días |
| Hito «Integración con el ERP» (2026-04-16) | Cerrado según el cronograma | **Ninguna.** 184 días |
| Hito «Piloto en tiendas» (2026-06-27) | Cerrado según el cronograma | **Ninguna.** 112 días |
| Hito «Despliegue en la cadena» (2026-09-07) | Cerrado según el cronograma | **Ninguna.** 40 días. Contradice el informe del 2026-10-17 (69 %, prueba de carga fallida) |

Los cinco hitos aparecen cerrados, y por eso el script calcula que el plan respalda 100 % frente al 69 % declarado: una brecha de 31 puntos (`progress_vs_plan`). Ninguno tiene evidencia. El cronograma lleva fecha 2025-09-02 en el nombre y declara cerrados hitos de 2026, así que su fecha no respalda esas declaraciones. Las tres actas de recibo que existen (`acta-recibo-8`, `acta-recibo-12`, `acta-recibo-16`) cierran compromisos de reunión, no hitos del plan.

### Fuera de alcance final
| Qué quedó fuera | Decidido por | Cuándo |
|---|---|---|
| Solo la exclusión genérica del acta: «Lo que otro proyecto cubre» | Acta de constitución | 2025-09-02 |

No hay solicitudes de cambio (`changes.total` = 0), así que no se registró ninguna decisión de recortar alcance. No puedo decir si se recortó algo: el alcance original no se nombra. Si hay recortes, no tienen decisión registrada, y eso es un hallazgo del cierre. El informe sí advierte que un cambio en la regulación de datos personales «puede mover el alcance».

### Números finales
| | Original | Vigente | Final | Desviación vs original |
|---|---|---|---|---|
| Fecha de cierre | 2026-09-07 | 2026-09-07 (nunca se replanificó) | **No existe: el proyecto sigue abierto** | La fecha original pasó hace 40 días y no hay entrega. El script calcula 0 días de desviación (0 replanificaciones), porque nadie movió la fecha; no es que se haya cumplido |
| Presupuesto (COP) | 9.500.000.000 aprobado | 9.500.000.000 (sin cambios aprobados) | Ejecutado a la fecha: 5.110.694.551 (53,8 %); comprometido: 5.420.644.515 (57,1 %); proyección al cierre: 8.761.040.718 | Proyección −7,8 % frente al aprobado; disponible real 4.079.355.485. Son cifras parciales, no finales |

Replanificaciones: **0**.
La proyección de 8.761.040.718 la declara el gerente en el informe y nada la respalda. Además, el gasto ejecutado (53,8 %) está lejos del avance declarado (69 %).

### RAID al cierre
**Materializados:** una incidencia: la prueba de carga de temporada no alcanzó el umbral pactado y se repite (informe, 2026-10-17). No hay fecha de inicio ni responsable.
**No materializados:** no se puede determinar. Los tres riesgos del registro siguen abiertos y ninguno tiene probabilidad, impacto, responsable ni fecha:
- cambio en la regulación de datos personales;
- el proveedor no ha confirmado la fecha de la última entrega;
- el proveedor podría no llegar con el equipo completo para la siguiente fase. Se dijo en la reunión del 2026-10-17 y nadie lo anotó como riesgo.

**Abiertos, con doliente:** ningún elemento del RAID tiene doliente, así que no está cerrado. Sí tienen doliente nombrado los **23 compromisos de reunión abiertos de 26**. De esos, 9 están vencidos, 3 no tienen fecha y 3 se han reprogramado varias veces. Los dolientes de los vencidos:
- María Restrepo, «Validar el ambiente 4», 7 días;
- Natalia Ospina, «Aprobar el diseño 5», 17 días;
- Ricardo Salas, «Enviar el documento 9», 12 días, y «Entregar el punto 24», 2 días;
- Felipe Arango, «Aprobar el diseño 13», 7 días, y «Validar el ambiente 20», 5 días;
- Liliana Torres, «Revisar el anexo 19», 8 días;
- Sandra Gil, «Actualizar la matriz 22», 3 días;
- Mauricio Pérez, «Confirmar la fecha 23», 4 días.

Además, el compromiso «Mandar el ajuste del presupuesto» (Laura Vélez) no tiene fecha, y la «revisión con el proveedor» (Óscar Ramírez, 2026-10-27) puede ser la misma «prueba 2» o un compromiso nuevo; las notas no lo dicen. **No hay contrato de proveedor en la documentación** (`vendors` vacío), aunque dos riesgos dependen de un proveedor.

### Lecciones
Solo entran las que se anclan a un hecho documentado.

| Qué pasó | Cuándo | Efecto | Qué haríamos distinto |
|---|---|---|---|
| «Enviar el documento 1» (Beatriz Cuéllar) se reprogramó 6 veces: de 2026-09-28 a 2026-12-19 | 2026-09-05 a 2026-10-17 | El compromiso se movió en cada comité sin que nadie lo escalara | Escalar un compromiso a la tercera reprogramación. Hoy hay 3 reprogramados varias veces (6, 5 y 3 veces: Cuéllar, Ramírez y Beltrán) |
| «Cerrar la prueba 2» (Óscar Ramírez) se reprogramó 5 veces: de 2026-09-25 a 2026-11-22 | 2026-09-05 a 2026-10-10 | Es una prueba, y el informe del 2026-10-17 reporta una prueba de carga fallida que se repite. Las minutas no dicen que sean la misma | Exigir fecha y criterio de cierre de cada prueba, y registrar los fallos como incidencia con responsable |
| Cinco compromisos (ambiente 4, prueba 10, documento 9, anexo 11, diseño 5) salieron de la tabla con «ya lo entregué» y sin acta de recibo | 2026-09-26 a 2026-10-10 | Quedaron cerrados sin evidencia, mientras los que sí tenían acta (puntos 8, 16 y ambiente 12) se cerraron con ella | Cerrar un compromiso solo con acta de recibo |
| Los 5 hitos figuran cerrados sin una sola acta de recibo, y el avance declarado (69 %) contradice el plan (100 %) | Cronograma v1, 2025-09-02; informe 2026-10-17 | Nadie puede decir qué estaba terminado. El hito «Despliegue en la cadena» (2026-09-07) figura cerrado y el proyecto sigue en rojo | Un hito cerrado exige acta de recibo; un cronograma que cambia de estado necesita versión nueva y fecha |
| El acta fijó alcance como «Componente 1/2/3», el criterio de éxito sin medida y «Ninguna declarada» en dependencias | 2025-09-02 | Hoy el cierre no tiene contra qué compararse, y el proveedor aparece como riesgo sin ser una dependencia declarada | Acta con entregables nombrados, criterio medible y dependencias antes de aprobar los 9.500.000.000 COP |
| Un riesgo se dijo en reunión y nadie lo registró (proveedor sin equipo completo) | 2026-10-17 | Sin responsable ni plan | Registrar los riesgos dichos en reunión el mismo día |

### Sin dato
- Si la tienda está en producción y si hay medición: ningún documento lo dice.
- El alcance real contratado (los componentes no se nombran) y cualquier recorte, con su decisión.
- Fecha final de cierre y gasto final: el proyecto sigue abierto.
- Responsable y fecha de inicio de la incidencia de carga, y probabilidad, impacto y responsable de los tres riesgos.
- Quién es el proveedor y cuál es el contrato: no hay documento.
- Autoridad y fase del proyecto: no están en la documentación.
- Qué documentos respaldan el cierre de los 5 hitos: ninguno está en la carpeta.
- Ningún dato de la ficha tiene fuente de evidencia (0 de 180 con marca de evidencia; 4 declaraciones); el resto no está marcado.

### Después
No muevo la carpeta a `archivo/` ni congelo la ficha: el proyecto no ha declarado fin y el script no ve un cierre real. Cuando el gerente (Rubén Cárdenas) y el patrocinador (Jorge Medina) declaren el cierre, o el comité lo decida de forma explícita, se repite este comando y ahí sí se archiva.

*Pie de rigor: las cifras salen de `compute` con todos sus dígitos; las citas apuntan a los documentos originales; lo declarado por el gerente se marca como declaración; lo que no se pudo determinar está en «Sin dato».*
