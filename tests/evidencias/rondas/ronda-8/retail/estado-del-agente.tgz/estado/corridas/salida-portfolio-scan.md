## Barrido — 2026-10-17

**Términos:** vigentes (v0.3.13), aceptados por José Francisco Ñáñez el 2026-10-17; no se registraron de nuevo. Comprobante: `.criterio/terminos/aceptacion-criterio-portfolio-0.3.13-2026-10-17.md` (y PDF).
**Encontré:** una carpeta de 13 proyectos (PRY-199 a PRY-211) con 89 documentos: 46 `.md`, 13 `.docx`, 13 `.xlsx`, 10 `.pdf`, 5 `.csv`, 1 `.txt`, 1 `.json`. No existe `entrada/`, así que no hubo nada que mover.

**Documentos:** 89 en la carpeta · 66 leídos (de 89) · 23 sin cambio desde la corrida anterior · 0 ilegibles
**Proyectos:** 13 con ficha · 10 nuevos (PRY-199, 201, 202, 203, 206, 207, 208, 209, 210, 211) · 0 sin carpeta propia · 3 sin cambio (PRY-200, 204, 205: no se abrieron)

Todo se leyó en un solo lote, uno tras otro en esta conversación (`workers: 1`), sin subagentes. Cada ficha se escribió y se selló al terminar su proyecto. Nada quedó diferido.

### Nuevos
| Proyecto | Documentos | Campos encontrados | Campos sin dato |
|---|---|---|---|
| PRY-199 Iluminación LED en bodegas | 6 | identidad, plan, 5 hitos, 1 contrato (3 entregables), 2 riesgos, 1 incidencia, 1 compromiso, estado y dinero | autoridad, fase, dependencias («Ninguna declarada»), facturación |
| PRY-201 Programa de fidelización | 8 | identidad, plan v1 y v2, 5 hitos, CC-01, 2 riesgos, 1 incidencia, 1 compromiso, estado y dinero | autoridad, fase, proveedor, dependencias, motivo del cronograma v2 |
| PRY-202 Centro de distribución norte | 7 | identidad, plan v1 y v2, 4 hitos, CC-01, 1 riesgo, 2 incidencias, 1 compromiso, estado y dinero | autoridad, fase, producto («No aplica»), proveedor, dependencias, motivo del cronograma v2 |
| PRY-203 Reposición automática | 3 | identidad, plan, 5 hitos, 2 riesgos, 1 incidencia, estado y dinero | autoridad, fase, producto, proveedor, dependencias, compromisos, 3 actas de hito |
| PRY-206 Precios dinámicos | 4 | identidad, plan, 4 hitos, 2 riesgos, 2 incidencias, estado y dinero | autoridad, fase, producto, proveedor, dependencias, compromisos, 3 actas de hito |
| PRY-207 Marca propia de alimentos | 7 | identidad, plan v1 y v2, 4 hitos, CC-01 (pendiente), 2 riesgos, 1 compromiso, estado y dinero | autoridad, fase, proveedor, dependencias, motivo del cronograma v2 |
| PRY-208 Domicilios en dos horas | 4 | identidad, plan, 5 hitos, 1 riesgo, 1 incidencia, 2 compromisos, estado y dinero | autoridad, fase, proveedor, dependencias, 2 actas de hito |
| PRY-209 Migración del ERP | 7 | identidad, plan, 5 hitos, contrato CT-865 y su factura, 1 riesgo, 2 incidencias, estado y dinero | autoridad, fase, producto, dependencias, compromisos, actas de los 2 entregables del contrato, fecha nueva del despliegue |
| PRY-210 Etiquetas electrónicas de precio | 10 | identidad, plan v1 y v2, 5 hitos, contrato CT-267, factura, CC-01, 2 riesgos, 1 incidencia, 1 compromiso, estado y dinero | autoridad, fase, producto, dependencias, 2 actas de hito, 3 actas de entregable, motivo del cronograma v2 |
| PRY-211 Pronóstico de demanda | 10 | identidad, plan v1 y v2, 5 hitos, contrato CT-520, factura, CC-01, 1 riesgo, 2 incidencias, 1 compromiso, estado y dinero | autoridad, fase, producto, dependencias, 3 actas de hito, 3 actas de entregable, motivo del cronograma v2 |

### Actualizados
Ninguno. No había fichas previas para estos 10 proyectos. Las de PRY-200, 204 y 205 no cambiaron y se conservaron tal cual.

### Lo que hay que mirar ya
No espero al informe consolidado: son hechos que ya se ven en los documentos. Las cifras y los umbrales los calcula el script en el informe.

**Hitos declarados cerrados sin acta de recibo** (la declaración se registró tal cual; falta la prueba):
- PRY-203: 3 de 3 cerrados (diseño, ambiente de pruebas, integración con el ERP).
- PRY-206: 3 de 4 (solo la integración con el ERP tiene acta).
- PRY-211: 3 de 4 (solo el ambiente de pruebas tiene acta).
- PRY-208: 2 de 2.
- PRY-210: 2 de 3 (sin acta el diseño y la integración con el ERP).
- PRY-201: 1 de 3 (sin acta el diseño).

**Facturas contra entregables sin recibo o por encima de lo recibido:**
- PRY-209: la factura FV-1865 (2026-09-11) cobra 148.277.922 COP. Ningún entregable del contrato CT-865 tiene acta de recibo; las actas existentes son de hitos del proyecto. El licenciamiento vencía el 2026-09-03 y sigue `pendiente`.
- PRY-210: la factura FV-1267 (2026-09-01) cobra 487.890.644 COP. Solo el licenciamiento está recibido, y vale 339.853.163 COP.
- PRY-211: la factura FV-1520 (2026-08-29) cobra 345.838.436 COP. Solo la configuración del catálogo está recibida, y vale 246.790.805 COP.

**Estado verde con cifras que no cuadran:**
- PRY-202: declara verde con 28%, pero proyecta 4.019.406.308 COP contra 3.300.000.000 aprobados. Además el ejecutado (1.653.468.061) supera lo comprometido (1.339.014.694).
- PRY-208: declara verde con 61%, pero proyecta 3.054.296.028 COP contra 2.400.000.000 aprobados.
- PRY-211: el ejecutado (1.403.708.177) supera lo comprometido (1.100.978.231).
- PRY-209: tiene comprometido 2.283.756.927 de 2.400.000.000 aprobados, y dice que reprogramó el despliegue sin dar fecha nueva en ningún documento.

**Cambios y cronogramas que no van en el mismo orden:**
- PRY-207: la CC-01 sigue «pendiente de presentación al comité», pero el cronograma v2 del 2026-10-14 ya mueve el piloto +31 días, que es lo mismo que pide la CC-01. El comité del 2026-10-13 no la trató.
- PRY-211: el cronograma v2 es del 2026-09-30 y la CC-01 (+75 días, igual al corrimiento) es del 2026-10-04, o sea posterior.
- PRY-201, 202, 210 y 211: la CC-01 dice «autorizada por el comité», sin nombre ni fecha de sesión. Las minutas de comité de PRY-201, 202 y 210 no la mencionan.

**Compromisos con fecha ya vencida y dicha después de vencer:**
- PRY-207: Diana Molina, «Entregar el punto 35», para el 2026-10-10, dicho en el comité del 2026-10-13.
- PRY-211: Sandra Gil, «Entregar el punto 11», para el 2026-09-29, dicho en el comité del 2026-10-09.
Los dos quedaron como `overdue`. La fecha es anterior a la reunión que los registra, y eso conviene confirmarlo con quien levantó la minuta.

**Estado rojo declarado:** PRY-206 (51%; su cierre comprometido era el 2026-07-02 y no hay cronograma nuevo) y PRY-207 (52%).

**Texto repetido:** «Se levantó un hallazgo de seguridad en los medios de pago» aparece en los informes de PRY-199 (iluminación LED), 202, 203, 209 y 211. Parece plantilla y no un hallazgo propio del proyecto. Lo registré como incidencia de cada uno; confírmelo con los gerentes.

### No pude leer
| Archivo | Por qué |
|---|---|
| — | Los 89 se leyeron o se convirtieron a texto sin error. |

### Movidos desde entrada/
| Archivo | A qué proyecto | Por qué |
|---|---|---|
| — | No existe la carpeta `entrada/`. |

### Pendientes de clasificar
| Archivo | Por qué no pude decidir |
|---|---|
| — | Ninguno. |

### Aviso sobre PRY-200 (no se tocó)
El índice marca 51 campos de la ficha de PRY-200 cuya cita no resuelve (`00-gobierno/2025-09-02-acta-constitucion.md`, `10-plan/...`, `30-reuniones/...`, `2026-10-17-notas-reunion.txt`). Las rutas están escritas sin el prefijo de carpeta del proyecto, o sea relativas al proyecto y no a la raíz de documentación. No releí PRY-200 porque sus documentos no cambiaron. Hay que corregir la ficha o decidir si se relee.

## Después
Hay más de un proyecto, así que puedo preparar el informe consolidado con `/criterio-portfolio:portfolio-report`. Hay contradicciones, compromisos vencidos y facturas sin recibo, y están arriba, no esperan al informe. El comité semanal es el 2026-10-22.

---
criterio-portfolio 0.3.13 · fichas tocadas: 10 (PRY-199, 201, 202, 203, 206, 207, 208, 209, 210, 211) · campos en `not_found`: autoridad y fase en las 10; producto en 6 («No aplica»); proveedor en 6 (los que no tienen contrato); dependencias en las 10 («Ninguna declarada»); y las actas de hito y de entregable que se listan arriba · Términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.13
