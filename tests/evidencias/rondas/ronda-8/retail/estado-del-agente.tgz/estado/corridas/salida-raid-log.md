## RAID — portafolio retail (13 proyectos, PRY-199 a PRY-211) al 2026-10-17

**De qué documentos sale:** las fichas en `estado/records/` (PRY-199 a PRY-211), las actas de constitución (sección «Dependencias declaradas»), los informes de avance, las 13 minutas de comité y las notas de reunión del 2026-10-17 de PRY-200 (89 documentos en la carpeta). Términos vigentes: aceptados por José Francisco Ñáñez, 2026-10-17 (v0.3.13).

**Qué no hay:** no existe un registro RAID formal en ningún proyecto. Lo «registrado» es lo que los informes de avance mencionan como riesgo o incidencia, y ninguno trae probabilidad, impacto, doliente, fecha ni fecha de último movimiento. Tampoco hay supuestos declarados.

14 riesgos · 0 supuestos · 18 incidencias · 7 dependencias
39 sin doliente · 39 sin fecha de vencimiento o de movimiento · 1 no registrado formalmente

### Necesitan decisión ahora
| Id | Tipo | Qué | Doliente | Desde | Por qué sube |
|---|---|---|---|---|---|
| PRY-199, 202, 203, 204, 209, 211 · I | Incidencia | «Hallazgo de seguridad en los medios de pago» (mismo texto en seis proyectos) | no registrado | 2026-09-30 a 2026-10-17 (según proyecto) | Sin doliente en ninguno de los seis. Afecta pagos y está repetido: nadie dijo si es un solo hallazgo común o seis. Decidir quién lo lleva y si se trata como una sola incidencia |
| PRY-200, 201, 202, 206, 210 · I | Incidencia | «La prueba de carga de temporada no alcanzó el umbral pactado y se repite» (cinco proyectos) | no registrado | 2026-10-06 a 2026-10-17 | Sin doliente. La temporada de fin de año ya está cerca y PRY-204 y PRY-209 hablan de congelamiento y despliegue reprogramado |
| PRY-204 · I | Incidencia | «Despliegue reprogramado por el congelamiento de temporada»; ningún documento da la fecha nueva | no registrado | sin fecha | El plan de la ficha termina el 2026-10-04, ya vencido, y declara amarillo. Tiene además 3 incidencias abiertas sin doliente |
| PRY-209 · I | Incidencia | Mismo despliegue reprogramado, sin fecha nueva | no registrado | sin fecha | Declara verde y no hay fecha de despliegue en ningún documento |
| PRY-200 · D/R | Dependencia y riesgo | El proveedor no confirmó la fecha de la última entrega; y en la reunión del 2026-10-17 se dijo que podría no llegar con el equipo completo a la siguiente fase | no registrado | 2026-10-17 | Declara rojo, el plan terminaba el 2026-09-07 y el proveedor es la dependencia crítica de lo que falta |
| PRY-206 · I/D | Incidencias y dependencia | Prueba de carga fallida, rotación de un desarrollador clave, y proveedor sin fecha de entrega | no registrado | 2026-10-15 | Declara rojo y el plan terminaba el 2026-07-02 |

### Detectados en reuniones, no registrados
| Qué | Tipo | Dicho en | Fecha |
|---|---|---|---|
| El proveedor podría no llegar con el equipo completo para la siguiente fase («nadie lo anotó como riesgo») | Riesgo (con rasgo de dependencia: depende de un tercero) | PRY-200, `2026-10-17-notas-reunion.txt` | 2026-10-17 |

Revisé las otras 13 minutas de comité (PRY-199, 200 ×6, 201, 202, 205, 207, 208, 210, 211). Su sección «Lo que se dijo» solo trae afirmaciones de «ya entregué» sin acta, que son asunto de compromisos y no de RAID. No encontré otros riesgos dichos al pasar, y no inventé ninguno.

### Sin doliente o sin fecha
No lleva doliente ninguno de los 39 ítems. Se reporta como hallazgo; no se rellenó.

| Id | Tipo | Qué | Qué falta |
|---|---|---|---|
| Los 14 riesgos | Riesgo | ver registro completo | doliente, probabilidad, impacto, fecha, último movimiento |
| Las 7 dependencias | Dependencia | ver registro completo | doliente, fecha comprometida por el proveedor, a quién se le pidió |
| Las 18 incidencias | Incidencia | ver registro completo | doliente en las 18; fecha de inicio en 6 (PRY-204 ×2, PRY-205, PRY-206 rotación, PRY-208, PRY-209 despliegue) |

**Sin movimiento en dos períodos y mitigaciones vencidas:** no se pueden evaluar. Ningún ítem trae fecha de último movimiento ni mitigación, y no hay un registro previo contra el cual comparar. Lo dejo dicho como lo que no sé, no como «sin novedad».

### Dependencias en riesgo
Ninguna acta de constitución declara dependencias («Ninguna declarada» en los 13 proyectos) y ningún documento cita el código de otro proyecto. **Por eso no puedo cruzar fechas entre proyectos: no hay dependencia entre proyectos documentada.** Las 7 que siguen son dependencias de un proveedor, reclasificadas desde riesgo (ver abajo).

| Id | Depende de | Confirmada | Qué pasó |
|---|---|---|---|
| PRY-200 · D1 | Proveedor (el informe no lo nombra) | No | «No ha confirmado la fecha de la última entrega» — informe 2026-10-17 |
| PRY-201 · D1 | Proveedor (no nombrado) | No | Igual — informe 2026-10-09 |
| PRY-203 · D1 | Proveedor (no nombrado) | No | Igual — informe 2026-10-09 |
| PRY-206 · D1 | Proveedor (no nombrado) | No | Igual — informe 2026-10-15; proyecto en rojo |
| PRY-207 · D1 | Proveedor (no nombrado) | No | Igual — informe 2026-10-14; proyecto en rojo |
| PRY-210 · D1 | Proveedor (no nombrado) | No | Igual — informe 2026-10-17 |
| PRY-211 · D1 | Proveedor (no nombrado) | No | Igual — informe 2026-09-30 |

**Reclasificadas y por qué:** «El proveedor no ha confirmado la fecha de la última entrega» estaba como riesgo en los siete informes. Depende de alguien fuera del proyecto, así que es dependencia. En PRY-210 y PRY-211 la ficha lista a Retail Andino Consultores S.A.S. como proveedor, pero el informe no dice que sea ese, así que no lo asigné.
«Disponibilidad de los jefes de tienda para el piloto» (PRY-199, PRY-207) sigue como riesgo; también podría ser dependencia o supuesto, pero los informes no dicen de quién ni qué se asumió.

### Registro completo
Referencias provisionales de esta corrida (R riesgo, D dependencia, I incidencia); ningún documento trae identificadores. Prob., Impacto, Doliente, Fecha y Último movimiento: **no registrado** en todos los ítems, salvo el desde de las incidencias.

| Id | Tipo | Qué | Fuente (informe de avance) | Desde |
|---|---|---|---|---|
| PRY-199 · R1 | Riesgo | Concentración del conocimiento en una sola persona | 2026-10-15 | — |
| PRY-199 · R2 | Riesgo | Disponibilidad de los jefes de tienda para el piloto | 2026-10-15 | — |
| PRY-199 · I1 | Incidencia | Hallazgo de seguridad en los medios de pago | 2026-10-15 | 2026-10-15 |
| PRY-200 · R1 | Riesgo | Cambio en la regulación de datos personales que puede mover el alcance | 2026-10-17 | — |
| PRY-200 · R2 | Riesgo (no registrado) | El proveedor podría no llegar con el equipo completo para la siguiente fase | notas de reunión 2026-10-17 | — |
| PRY-200 · D1 | Dependencia | Proveedor sin fecha confirmada de la última entrega | 2026-10-17 | — |
| PRY-200 · I1 | Incidencia | Prueba de carga de temporada bajo el umbral, se repite | 2026-10-17 | 2026-10-17 |
| PRY-201 · R1 | Riesgo | Concentración del conocimiento en una sola persona | 2026-10-09 | — |
| PRY-201 · D1 | Dependencia | Proveedor sin fecha confirmada de la última entrega | 2026-10-09 | — |
| PRY-201 · I1 | Incidencia | Prueba de carga de temporada bajo el umbral, se repite | 2026-10-09 | 2026-10-09 |
| PRY-202 · R1 | Riesgo | Concentración del conocimiento en una sola persona | 2026-10-06 | — |
| PRY-202 · I1 | Incidencia | Hallazgo de seguridad en los medios de pago | 2026-10-06 | 2026-10-06 |
| PRY-202 · I2 | Incidencia | Prueba de carga de temporada bajo el umbral, se repite | 2026-10-06 | 2026-10-06 |
| PRY-203 · R1 | Riesgo | Congelamiento de cambios en temporada alta | 2026-10-09 | — |
| PRY-203 · D1 | Dependencia | Proveedor sin fecha confirmada de la última entrega | 2026-10-09 | — |
| PRY-203 · I1 | Incidencia | Hallazgo de seguridad en los medios de pago | 2026-10-09 | 2026-10-09 |
| PRY-204 · R1 | Riesgo | Cambio en la regulación de datos personales que puede mover el alcance | 2026-10-17 | — |
| PRY-204 · I1 | Incidencia | Hallazgo de seguridad en los medios de pago | 2026-10-17 | 2026-10-17 |
| PRY-204 · I2 | Incidencia | El equipo perdió dos semanas por rotación de un desarrollador clave | 2026-10-17 | no registrado |
| PRY-204 · I3 | Incidencia | Despliegue reprogramado por congelamiento; sin fecha nueva | 2026-10-17 | no registrado |
| PRY-205 · R1 | Riesgo | Concentración del conocimiento en una sola persona | 2026-10-17 | — |
| PRY-205 · I1 | Incidencia | El equipo perdió dos semanas por rotación de un desarrollador clave | 2026-10-17 | no registrado |
| PRY-206 · R1 | Riesgo | Concentración del conocimiento en una sola persona | 2026-10-15 | — |
| PRY-206 · D1 | Dependencia | Proveedor sin fecha confirmada de la última entrega | 2026-10-15 | — |
| PRY-206 · I1 | Incidencia | Prueba de carga de temporada bajo el umbral, se repite | 2026-10-15 | 2026-10-15 |
| PRY-206 · I2 | Incidencia | El equipo perdió dos semanas por rotación de un desarrollador clave | 2026-10-15 | no registrado |
| PRY-207 · R1 | Riesgo | Disponibilidad de los jefes de tienda para el piloto | 2026-10-14 | — |
| PRY-207 · D1 | Dependencia | Proveedor sin fecha confirmada de la última entrega | 2026-10-14 | — |
| PRY-208 · R1 | Riesgo | Congelamiento de cambios en temporada alta | 2026-09-28 | — |
| PRY-208 · I1 | Incidencia | El equipo perdió dos semanas por rotación de un desarrollador clave | 2026-09-28 | no registrado |
| PRY-209 · R1 | Riesgo | Concentración del conocimiento en una sola persona | 2026-10-14 | — |
| PRY-209 · I1 | Incidencia | Hallazgo de seguridad en los medios de pago | 2026-10-14 | 2026-10-14 |
| PRY-209 · I2 | Incidencia | Despliegue reprogramado por congelamiento; sin fecha nueva | 2026-10-14 | no registrado |
| PRY-210 · R1 | Riesgo | Cambio en la regulación de datos personales que puede mover el alcance | 2026-10-17 | — |
| PRY-210 · D1 | Dependencia | Proveedor sin fecha confirmada de la última entrega | 2026-10-17 | — |
| PRY-210 · I1 | Incidencia | Prueba de carga de temporada bajo el umbral, se repite | 2026-10-17 | 2026-10-17 |
| PRY-211 · D1 | Dependencia | Proveedor sin fecha confirmada de la última entrega | 2026-09-30 | — |
| PRY-211 · I1 | Incidencia | La validación con dos tiendas se extendió una semana por el conteo de inventario | 2026-09-30 | 2026-09-30 |
| PRY-211 · I2 | Incidencia | Hallazgo de seguridad en los medios de pago | 2026-09-30 | 2026-09-30 |

PRY-199 y PRY-205 aparecen sin dependencias ni incidencias adicionales en sus informes; PRY-207 no registra ninguna incidencia.

### Lo que no sé
- Si los textos idénticos entre proyectos (seguridad en pagos ×6, prueba de carga ×5, rotación ×4) son un mismo hecho o texto copiado de una plantilla. Lo dicen los informes; no lo pude verificar contra otro documento.
- Quién es cada proveedor en las dependencias, y quién es el doliente natural de cualquier ítem.
- Si hay riesgos hablados en reuniones sin acta o grabadas que no están en la carpeta. Solo leí lo que está en la carpeta.

### Después
- **Subir a comité (22 de octubre):** los cuatro grupos de la tabla «Necesitan decisión ahora». Es una oferta; no los subí.
- **Doliente:** propongo que el gerente de cada proyecto asuma, como punto de partida, los ítems de su proyecto, y que la PMO nombre un solo doliente para el hallazgo de seguridad en pagos si resulta ser común. Es una propuesta; no asigné nada.

*Pie de rigor: borrador de trabajo sobre los documentos listados arriba. Cada dato cita su informe; la verificación y la decisión son suyas.*
