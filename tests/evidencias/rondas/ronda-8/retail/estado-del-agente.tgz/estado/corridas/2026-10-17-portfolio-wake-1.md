# Corrida del 2026-10-17 · portfolio-wake

13 proyectos · 36 s · 73 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 21 |
| `commitment_overdue` | 11 |
| `declared_vs_evidence` | 7 |
| `progress_vs_plan` | 6 |
| `vendor_deliverable_late` | 5 |
| `change_without_baseline` | 4 |
| `variance_time` | 4 |
| `commitment_undated` | 3 |
| `commitment_rescheduled` | 3 |
| `variance_cost` | 3 |
| `rebaseline_unauthorized` | 2 |
| `vendor_invoiced_over_accepted` | 2 |
| `budget_committed` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

Barrido: 89 documentos sin cambios. 63 citas de PRY-200 sin resolver por falta del prefijo de carpeta (los documentos existen); no reescribí la ficha. Confirmación: 5 campos de PRY-200 preguntados, sin respuesta (sesión sin interfaz). No sé si esos campos siguen vigentes.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## 2026-10-17

**Revisé:** 89 documentos · 0 cambiaron · 0 proyectos recalculados

Términos: ya vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17); no hubo que volver a pedirlos.

### Lo que cruzó un umbral
Nada por cambio de documentos. Un hallazgo de citas: **PRY-200 (Tienda en línea)** tiene 63 citas en su ficha que el índice no resuelve (identidad, plan, dinero, RAID, compromisos). Los documentos citados **sí existen** en la carpeta del proyecto; el problema es que la ficha de PRY-200 los cita sin el prefijo de la carpeta del proyecto (`00-gobierno/…` en vez de `PRY-200-tienda-en-línea/00-gobierno/…`), a diferencia de las demás fichas. No lo corregí: reescribir la ficha es trabajo de `/portfolio-scan`, y ningún documento cambió. Queda abierto para el próximo scan de PRY-200.

### Peticiones atendidas
Ninguna: no había peticiones en el servidor.

### Preguntas
Nadie responde en esta sesión de prueba, así que quedan **preguntadas el 2026-10-17, sin respuesta** (la respuesta sugerida es «sin cambios», y no la tomo como confirmación). Cinco campos de PRY-200, todos con fuente del 2025-09-02 (más de 12 meses, umbral `stale_field_months`):

1. Presupuesto aprobado: COP 9.500.000.000 — acta de constitución, 2025-09-02.
2. Fecha de fin del plan — cronograma v1, 2025-09-02.
3. Patrocinador — acta de constitución, 2025-09-02.
4. Gerente del proyecto — acta de constitución, 2025-09-02.
5. Comité al que reporta — acta de constitución, 2025-09-02.

**Vuelvo el 2026-10-18.** El informe de comité del 2026-10-22 toca el 2026-10-20.
