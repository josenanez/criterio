# Corrida del 2026-10-17 · change-control

13 proyectos · 44 s · 73 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 21 |
| `commitment_overdue` | 11 |
| `declared_vs_evidence` | 7 |
| `progress_vs_plan` | 6 |
| `vendor_deliverable_late` | 5 |
| `change_without_baseline` | 4 |
| `variance_time` | 4 |
| `commitment_undated` | 3 |
| `commitment_rescheduled` | 3 |
| `variance_cost` | 3 |
| `rebaseline_unauthorized` | 2 |
| `vendor_invoiced_over_accepted` | 2 |
| `budget_committed` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

Solicitud de +30 días en la salida a producción de PRY-201, tomada como el hito Despliegue en la cadena. Impacto en el portafolio: 0 alcanzados porque no hay dependencias declaradas. Dijo que no sabe: motivo y solicitante, impacto en alcance y costo, autoridad (el acta no la declara), quién autorizó CC-01 y cuántos días se mueve cada afectado (sin holgura por actividad).

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

Ficha de la que sale: `estado/records/PRY-201.json` (actualizada 2026-10-17). Términos vigentes: versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17.

## Solicitud de cambio — PRY-201 Programa de fidelización — 2026-10-17

**Qué se pide:** mover 30 días la salida a producción. Se toma como «Despliegue en la cadena» (2027-04-27), el último hito del cronograma v2, que es el que corresponde al criterio de éxito del acta («Programa de fidelización en producción y medido»). Si se refería a otro hito, el cálculo cambia.
**Quién lo pide:** no está dicho en la solicitud. **Por qué:** no está dicho. No lo invento: sin motivo no se puede registrar la línea base nueva.

### Impacto
| Dimensión | Hoy | Con el cambio | Diferencia |
|---|---|---|---|
| Alcance | 3 componentes sin nombre en el acta (cronograma v2) | No declarado | Sin impacto declarado |
| Tiempo | Despliegue 2027-04-27 (línea base v2) | 2027-05-27 | +30 días contra la vigente; **+63 contra la original (2027-03-25)** |
| Costo | Aprobado 1.200.000.000 COP; proyección 1.176.832.977; disponible real 411.077.502 | No declarado | Sin impacto declarado |

Alcance y costo llegan sin impacto declarado. Mover 30 días sin tocar ninguno de los dos significa que alguien lo absorbe en horas no pagadas o en calidad, y la solicitud no dice quién. Un equipo que corre 30 días más cuesta algo; ese monto lo tiene que dar el gerente, y no lo calculo porque la ficha no trae costo por periodo.

El piloto en tiendas (2026-12-08) queda dentro del tramo que se mueve, pero la solicitud no dice si también se corre. No lo supongo.

### Efecto en el portafolio
| Proyecto afectado | Cómo | Gerente |
|---|---|---|
| Ninguno alcanzado | `impact` recorrió las dependencias declaradas: 0 directos, 0 indirectos, 0 que no puedan sostener su fecha, 0 sin confirmar | Rubén Cárdenas (gerente de PRY-201) |

Este cero es «no hay dependencias declaradas», no «no hay dependencias». El acta dice «Ninguna declarada», y el proyecto tiene un hito «Integración con el ERP» mientras el portafolio tiene PRY-209 (Migración del ERP). Eso es una pregunta para el gerente, no un hallazgo: no hay documento que diga que se relacionan. Tampoco sé cuántos días se movería cada afectado, porque eso necesita holgura por actividad y la ficha no la tiene.

### Quién decide
**Autoridad requerida:** no se puede determinar. El acta no declara autoridad (`identity.authority`: no encontrado). Nombra al patrocinador (Camilo Beltrán) y al Comité Comercial, pero no dice qué puede aprobar cada uno ni hasta qué desviación.
**Según:** acta de constitución 2025-09-25, que no tiene cláusula de autoridad. Ese es el hallazgo de fondo.
**Va a comité:** sí, al Comité Comercial. Es la instancia que aprobó el presupuesto y, sin autoridad declarada, no hay base documental para decidir por debajo de ella. Próximo comité: 2026-10-22.

### Lo que el control de cambios de este proyecto ya muestra
- **CC-01 (2026-10-14), ampliación de alcance:** +33 días y +66.000.000 COP, autorizada por «el comité», sin nombre de persona ni fecha de sesión. El acta del comité del 2026-10-14 no la menciona (asistentes: Rubén Cárdenas, Camilo Beltrán; temas: avance y compromisos). Ningún documento sustenta la autorización.
- **Línea base v2 (2026-10-09), cierre 2027-04-27:** sin motivo escrito, y aprobada cinco días *antes* de que se pidiera CC-01. Los 33 días cuadran con CC-01 (`unauthorized_days` = 0), pero la señal `change_without_baseline` sigue abierta: CC-01 no dejó su propia línea base.
- **Estado declarado «verde»** (informe 2026-10-09) contra la evidencia: el avance declarado es 36% y el plan sustenta entre 60% y 80% (24 puntos por debajo); el hito «Diseño de la experiencia aprobado» figura como cumplido sin evidencia de recibo; hay una incidencia abierta (la prueba de carga de temporada no alcanzó el umbral y se repite) y un riesgo (el proveedor no ha confirmado la fecha de la última entrega) sin dueño ni fecha. No hay contrato de proveedor en la carpeta.

### Si no se aprueba
El proyecto sigue con cierre 2027-04-27 (+33 días contra la original). La prueba de carga que se repite y el proveedor sin fecha confirmada son los dos motivos documentados por los que esa fecha puede estar en riesgo. Ninguno está medido contra el cronograma, así que no afirmo que la fecha no se sostenga.

### Si se aprueba
Línea base 3 — cierre 2027-05-27 · presupuesto: no declarado (vigente 1.200.000.000 COP; la ficha no dice si los 66.000.000 de CC-01 ya están incluidos) · motivo: no declarado.
Desviación acumulada contra la línea base original: **+63 días** (6,1% más sobre 2027-03-25 → 2027-05-27) · costo: +66.000.000 COP de CC-01 más lo que esta solicitud no cuantificó.
Las replanificaciones pasarían de 1 a 2, y toda desviación se reportaría contra las dos referencias.

### Qué falta para llevarlo a comité
1. Motivo y solicitante de los 30 días.
2. Confirmar qué hito es «salida a producción» y si el piloto se mueve.
3. Impacto en alcance y costo, o la declaración expresa de quién absorbe cada uno.
4. Nombre y fecha de la sesión que autorizó CC-01, y la autoridad del Comité Comercial por escrito.
5. Revisar el declarado «verde» antes de que el comité lo use como punto de partida.

Esto es un borrador de trabajo: la decisión y la verificación de las citas son de quien lo lleva al comité.
