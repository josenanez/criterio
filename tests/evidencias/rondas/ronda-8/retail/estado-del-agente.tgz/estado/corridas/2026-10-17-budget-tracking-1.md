# Corrida del 2026-10-17 · budget-tracking

13 proyectos · 25 s · 73 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 21 |
| `commitment_overdue` | 11 |
| `declared_vs_evidence` | 7 |
| `progress_vs_plan` | 6 |
| `vendor_deliverable_late` | 5 |
| `change_without_baseline` | 4 |
| `variance_time` | 4 |
| `commitment_undated` | 3 |
| `commitment_rescheduled` | 3 |
| `variance_cost` | 3 |
| `rebaseline_unauthorized` | 2 |
| `vendor_invoiced_over_accepted` | 2 |
| `budget_committed` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

Presupuesto PRY-209: comprometido 95,2% sobre umbral 90%, facturado sin entrega en CT-865, declarado verde sin dar cuenta de ello. No hay línea base de costo separada ni evidencia independiente de las cifras.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

Fuentes: ficha PRY-209 (estado/records/PRY-209.json) y `portafolio.py compute` al 2026-10-17. Documento de cifras: PRY-209-migración-del-erp/20-seguimiento/2026-10-14-informe-avance.md (del 2026-10-14, una declaración del gerente, no evidencia independiente).

## Presupuesto — PRY-209 Migración del ERP al 2026-10-17
**Moneda:** COP (única; no hay contratos en otra moneda ni conversión)

| | Monto (COP) | % del aprobado | Fuente | Fecha |
|---|---|---|---|---|
| Aprobado | 2.400.000.000 | 100% | informe-avance.md | 2026-10-14 |
| Comprometido | 2.283.756.927 | 95,2% | informe-avance.md | 2026-10-14 |
| Ejecutado | 1.079.166.603 | 45,0% | informe-avance.md | 2026-10-14 |
| Proyección al cierre | 2.287.155.869 | 4,7% por debajo del aprobado (según compute) | informe-avance.md | 2026-10-14 |

**Disponible real** (aprobado menos comprometido): COP 116.243.073

### Contra la línea base
Solo existe una versión de línea base (v1, 2026-05-29, acta de constitución; fin 2027-02-02). No hay línea base de presupuesto separada ni solicitudes de cambio registradas, así que original y vigente coinciden en lo que consta: aprobado 2.400.000.000, desviación 0 por cambios.
Replanificaciones de presupuesto: 0 (cambios registrados: 0). Atraso de cronograma contra original y contra vigente: 0 días.

### Ejecución frente a avance
Ejecutado 45,0% · Hitos cumplidos 2 de 5 · Avance declarado 31,0%; el plan sustenta entre 40% y 60%. Se ha ejecutado más dinero que el avance declarado, y el sustento de hitos (2 de 5) apenas llega al rango bajo del plan. El comprometido (95,2%) es la cifra que manda: el 4,8% restante deja poca holgura para 3 de 5 hitos pendientes.

### Alertas
- **Comprometido 95,2%**, por encima del umbral de 90%. Disponible real COP 116.243.073. Con 45,0% ejecutado, el presupuesto está casi agotado aunque falte causar más de la mitad.
- **Proveedor Sistemas Comerciales del Norte (CT-865):** facturado COP 148.277.922 (factura del 2026-09-11) sin ningún entregable aceptado (0 de 2). "Licenciamiento de la plataforma" venció el 2026-09-03 (44 días, estado pendiente, sin evidencia de recibo).
- **Declarado vs evidencia:** el informe del 2026-10-14 declara verde y no da cuenta de las tres señales anteriores (comprometido, entregable tardío, facturado sin entrega).
- La proyección (2.287.155.869) no excede el aprobado, pero es una declaración del gerente con fecha 2026-10-14; no es posterior a un movimiento de presupuesto más reciente que ella (la última factura es del 2026-09-11) y no hay evidencia independiente que la sustente.

### Sin dato
- Presupuesto original vs vigente como cifras distintas: no hay documento de línea base de costo ni de cambios.
- Autoridad, producto y fase del proyecto: no declarados en la ficha.
- Aceptación de entregables del proveedor: ninguna evidencia en los documentos.
- Tasa de cambio: no aplica (solo COP).

### Siguiente paso
El comprometido está sobre el tope: puedo preparar el detalle por proveedor (CT-865 y los demás compromisos). La proyección no excede el aprobado, así que no hace falta solicitud de cambio por ahora.

---
Rigor: cifras copiadas de `compute` y de la ficha; las tres cifras de dinero y la proyección vienen de un solo documento declarativo; nada se verificó contra contabilidad ni contra contratos. No sé qué se habló fuera de los documentos.
