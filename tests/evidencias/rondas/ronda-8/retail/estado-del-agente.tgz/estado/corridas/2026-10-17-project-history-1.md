# Corrida del 2026-10-17 · project-history

13 proyectos · 43 s · 73 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 21 |
| `commitment_overdue` | 11 |
| `declared_vs_evidence` | 7 |
| `progress_vs_plan` | 6 |
| `vendor_deliverable_late` | 5 |
| `change_without_baseline` | 4 |
| `variance_time` | 4 |
| `commitment_undated` | 3 |
| `commitment_rescheduled` | 3 |
| `variance_cost` | 3 |
| `rebaseline_unauthorized` | 2 |
| `vendor_invoiced_over_accepted` | 2 |
| `budget_committed` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

Historia de PRY-201 sobre 9 documentos: 1 replanificación, 33 días (6,2 %) vs original, 0 cambios de gobierno. No pude fechar el punto de separación (una sola declaración) ni confirmar la autorización de CC-01 (no consta en el acta de comité); 12 meses sin documentos.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

Términos: ya estaban vigentes para esta versión (0.3.13, aceptados por José Francisco Ñáñez el 2026-10-17); no se pidió un registro nuevo.

## Historia · PRY-201 Programa de fidelización · 2025-09-25 a 2026-10-14

**Leí:** 9 documentos entre 2025-09-25 y 2026-10-14 (acta de constitución, cronogramas v1 y v2, informe de avance, dos actas de recibo, solicitud de cambio CC-01, acta de comité). Ninguno está marcado como evidencia independiente: el script cuenta 0 de evidencia, 2 de declaración y 16 sin marcar.
**Trimestres sin un solo documento:** 2025-T4, 2026-T1, 2026-T2 y 2026-T3. Los 9 documentos están en 2025-T3 (1) y 2026-T4 (8). Hay 12 meses sin ningún documento.

### En una línea
Un proyecto constituido el 2025-09-25 con cierre el 2027-03-25 que no deja un solo documento hasta octubre de 2026. En la primera semana de octubre de 2026 aparecen de golpe, el mismo mes, dos actas de recibo de hitos con fechas de línea base de mayo y agosto, un informe en verde, un cronograma v2 que mueve el cierre al 2027-04-27 y una solicitud de cambio de +33 días que dice estar autorizada por el comité.

### Las cuatro cifras
| Replanificaciones | Atraso acumulado vs. original | Meses declarando sin sustento | Cambios de gobierno |
|---|---|---|---|
| 1 | 33 días (6,2 %) | No calculable: solo hay una declaración (2026-10-09), no una serie | 0 documentados |

### Línea de tiempo
| Fecha | Documento | Qué cambió |
|---|---|---|
| 2025-09-25 | Acta de constitución | Presupuesto de 1.200.000.000 COP aprobado por el Comité Comercial; inicio 2025-10-05, cierre 2027-03-25. Patrocinador Camilo Beltrán, gerente Rubén Cárdenas. Dependencias: "Ninguna declarada". |
| 2025-09-25 | Cronograma v1 | Línea base de 5 hitos. El archivo es de esa fecha, pero su contenido ya marca como "cerrado" tres hitos con fechas de 2026; ese contenido es posterior al archivo. |
| 2026-10-08 | Acta de recibo · Integración con el ERP | Recibida por el gerente. Línea base del hito: 2026-08-22. |
| 2026-10-09 | Informe de avance | Estado declarado verde, 36 %. Dice que la prueba de carga de temporada no alcanzó el umbral y se repite. |
| 2026-10-09 | Cronograma v2 | "Despliegue en la cadena" pasa del 2027-03-25 al 2027-04-27. |
| 2026-10-11 | Acta de recibo · Ambiente de pruebas certificado | Recibida por el gerente. Línea base del hito: 2026-05-07. |
| 2026-10-14 | Solicitud de cambio CC-01 | Ampliación de alcance, +33 días y 66.000.000 COP. "Autorizada por el comité". |
| 2026-10-14 | Acta de comité semanal | Asistentes: Rubén Cárdenas y Camilo Beltrán. Un compromiso: Paula Céspedes, "Entregar el punto 29", para 2026-11-14. |

**Distancia entre lo ocurrido y lo escrito.** El cronograma v2 (2026-10-09) lleva la fecha que luego aprueba la CC-01 (2026-10-14): la replanificación quedó escrita cinco días antes que su autorización. Las actas de recibo son de octubre de 2026 para hitos de línea base de mayo y agosto.

### Replanificaciones
| Nº | Fecha | Fecha de cierre nueva | Motivo declarado | Documento que la aprobó |
|---|---|---|---|---|
| 1 | 2026-10-09 (cronograma v2) | 2027-04-27 | "Ampliación de alcance" (CC-01, de otro documento y 5 días posterior) | CC-01, 2026-10-14: "Autorizada por el comité". El acta del comité del 2026-10-14 no menciona CC-01. |

La línea base original sigue en 2027-03-25. El script marca `change_without_baseline`: CC-01 aprobada (+33 días) sin una línea base nueva registrada. Atraso contra la vigente: 0 días; contra la original: 33 días (6,2 %), por debajo del umbral de 10 %.

### Gobierno
| Fecha | Qué cambió | Documento |
|---|---|---|
| — | Ningún cambio de patrocinador, gerente o comité documentado. Patrocinador, gerente y comité vienen del acta de 2025-09-25 y no tienen respaldo posterior de más de 13 meses; el campo "autoridad" y la fase no figuran. | — |

### Compromisos que se repitieron
| Doliente | Qué | Veces | Fechas prometidas |
|---|---|---|---|
| Paula Céspedes | Entregar el punto 29 | 1 | 2026-11-14 |

Ninguno se repitió. No hay minutas anteriores contra las cuales comparar, así que la ausencia de repetición no prueba que no ocurriera. Vencidos: 0.

### Desde cuándo lo declarado no se sostiene
No se puede fechar con una serie, porque en la carpeta hay una sola declaración de estado (verde, 36 %, corte 2026-10-09). Lo que sí se puede decir de esa:
- Primer hito sin evidencia: **Diseño de la experiencia aprobado**, fecha 2026-01-20, marcado cumplido; no hay acta de recibo ni documento que lo sustente (270 días desde su fecha, según el script).
- Avance declarado 36 % frente a 60-80 % que sostiene el plan (3 de 5 hitos cumplidos): 24 puntos de diferencia, **declarado por debajo** del plan, no por encima. El script lo marca como `progress_vs_plan`; la dirección contradice la lectura habitual de "avance inflado" y no la interpreto.
- Los otros dos hitos cerrados (ERP y ambiente de pruebas) sí tienen acta, pero fechada en octubre de 2026.
- El informe dice verde y a la vez que la prueba de carga no alcanzó el umbral, y lista como riesgo que el proveedor no confirmó la fecha de la última entrega.
- Dinero: ejecutado 716.395.662 COP (59,7 %), comprometido 788.922.498 (65,7 %), proyección 1.176.832.977 (-1,9 % frente al aprobado). La CC-01 pide 66.000.000 COP adicionales y la proyección del informe no los incluye de forma visible; no puedo afirmar que los incluya o no.

### Lecciones ancladas a un hecho
1. **Una replanificación quedó escrita antes de su autorización.** Hecho: cronograma v2 del 2026-10-09 con cierre 2027-04-27; CC-01 del 2026-10-14. Efecto: +33 días en la vigente sin línea base nueva registrada.
2. **Una autorización "del comité" sin rastro en el acta del comité.** Hecho: CC-01 dice "Autorizada por el comité" el 2026-10-14; el acta de ese día no la menciona. Efecto: la aprobación no se puede verificar con los documentos.
3. **Hitos cerrados con acta meses después de su fecha.** Hecho: actas del 2026-10-08 y 2026-10-11 para hitos de línea base 2026-08-22 y 2026-05-07. Efecto: durante ese lapso no había documento que respaldara el cierre.
4. **Un hito cumplido sin ningún soporte.** Hecho: Diseño de la experiencia aprobado, 2026-01-20. Efecto: 1 de los 3 hitos que sostienen el avance no se puede comprobar.

### Lo que no sé
- Qué pasó entre 2025-10 y 2026-09: no hay documentos de ese período.
- Si el comité autorizó CC-01 y dónde quedó registrado.
- Cuántos meses se declaró verde: solo hay un informe.
- Si Paula Céspedes pertenece a otro proyecto o a este; no aparece en otro documento.

Esta historia no atribuye intención. Los hallazgos son brechas entre fechas y documentos; qué las explica es una conversación para tener con el gerente y el patrocinador, con estos datos delante. Puedo llevarla al cierre del proyecto o al comité del 2026-10-22 si hay una decisión que salga de ella (por ejemplo, registrar la línea base nueva de CC-01).

**Pie de rigor:** borrador de trabajo basado en 9 documentos; cada cifra derivada sale de `portafolio.py compute` (2026-10-17). Verifique contra los documentos originales antes de usarlo.
