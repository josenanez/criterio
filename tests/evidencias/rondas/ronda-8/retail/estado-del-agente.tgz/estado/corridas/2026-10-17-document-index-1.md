# Corrida del 2026-10-17 · document-index

13 proyectos · 23 s · 73 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 21 |
| `commitment_overdue` | 11 |
| `declared_vs_evidence` | 7 |
| `progress_vs_plan` | 6 |
| `vendor_deliverable_late` | 5 |
| `change_without_baseline` | 4 |
| `variance_time` | 4 |
| `commitment_undated` | 3 |
| `commitment_rescheduled` | 3 |
| `variance_cost` | 3 |
| `rebaseline_unauthorized` | 2 |
| `vendor_invoiced_over_accepted` | 2 |
| `budget_committed` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

89 documentos sin cambios, 0 por releer. 60 campos de PRY-200 marcados como cita rota aunque los archivos existen; causa no determinada, no se corrigió nada.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## Carpeta al 2026-10-17

**Documentos:** 89 · **Sin cambio:** 89 · **Hay que releer:** 0

### Cambió el contenido
Ninguno.

### Solo se reguardó
Ninguno.

### Renombrado o movido
Ninguno.

### Ya no está
Ninguno.

### Citas que dejaron de resolver
El índice marca 60 campos de **PRY-200** (tienda en línea) como `source_missing`: identidad, estado declarado y avance, plan e hitos, dinero, riesgos, incidencia y 26 compromisos. Los documentos citados son:

- `00-gobierno/2025-09-02-acta-constitucion.md`
- `10-plan/2025-09-02-cronograma-v1.xlsx`
- `20-seguimiento/2026-10-17-informe-avance.md`
- `30-reuniones/2026-09-05-comite-semanal.md` y los comités del 09-12, 09-19, 09-26, 10-03 y 10-10
- `2026-10-17-notas-reunion.txt`

No hay ninguna otra cita rota en el portafolio.

**Lo que no sé:** estos archivos existen en `documentos/proyectos/PRY-200-tienda-en-línea/`. La ficha los cita con la ruta completa, con el prefijo de la carpeta del proyecto, y los bytes de la ruta coinciden con los del disco. El índice dice "falta" y yo no pude confirmar la causa. Puede ser un fallo del índice con esta ficha o una diferencia que no vi. No lo traté como documento borrado y no corregí ninguna cita.

### Formatos que no se pudieron leer
Ninguno. Este comando no lee documentos: los cuenta y los compara.

### Siguiente paso
- No hay nada que releer, así que no hace falta un barrido de `/portfolio-scan` (`projects_to_recompute` está vacío).
- Antes de confiar en la ficha de PRY-200, conviene revisar por qué sus citas no resuelven.
