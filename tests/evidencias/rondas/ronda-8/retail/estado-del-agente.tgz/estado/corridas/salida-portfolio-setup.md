## Listo — Portafolio retail

**Miré:** 89 documentos en 13 proyectos (PRY-199 a PRY-211) · formatos: .md 46, .docx 13, .xlsx 13, .pdf 10, .csv 5, .json 1, .txt 1 · más reciente: 2026-10-17
**Eres:** PMO del portafolio (hay varios proyectos)
**Te aviso:** dos días antes del comité del 2026-10-22 (el informe aterriza el 2026-10-20). Las carpetas llaman "comité semanal" a sus reuniones, así que tomé cadencia semanal; la fecha del 22 es mi suposición, nadie la dijo.
**En:** presentación (valor sugerido)
**Términos:** aceptados para la versión 0.3.13 (términos 1.1) por José Francisco Ñáñez el 2026-10-17 · comprobante en `.criterio/terminos/aceptacion-criterio-portfolio-0.3.13-2026-10-17.md` y `.pdf` · SHA-256 6d4b67767ea3a1ea…
**Dónde queda:** configuración en `.criterio/portafolio/config.json`; lo que voy encontrando en `estado/`; informes en `reportes/`.

Preguntas hechas: 0 (sesión sin interfaz; tomé la respuesta sugerida en cada una).

### Probé con tres proyectos

Los de documentación más reciente (cuatro empatan el 2026-10-17; tomé PRY-200, PRY-204 y PRY-205).

| Proyecto | Documentos | Qué supe | Qué no está |
|---|---|---|---|
| PRY-200 Tienda en línea | 14 (acta, ficha-pm.json, cronograma v1, 3 actas de recibo, informe, 6 comités, notas del 10-17) | Gerente Rubén Cárdenas, patrocinador Jorge Medina (acta 2025-09-02). Declara **rojo, 69%** (informe 2026-10-17). Presupuesto 9.500 M COP, comprometido 5.420 M, ejecutado 5.111 M, proyección 8.761 M. Cierre comprometido 2026-09-07. 26 compromisos extraídos de los comités y las notas. | Autoridad del gerente y fase. Ningún hito tiene acta de recibo. Un riesgo (el proveedor sin equipo completo) solo está en las notas y nadie lo registró. |
| PRY-204 Cajas de autopago | 3 (acta .docx, solicitud de cambio, informe) | Gerente Liliana Torres, patrocinadora Natalia Ospina. Declara **amarillo, 41%**. Presupuesto 18.000 M, proyección 17.572 M. Cierre comprometido 2026-10-04. CC-01: +35 días, +70 M, "autorizada por el comité". | No hay cronograma ni hitos, ni actas de comité, ni autoridad del gerente. El informe dice que el despliegue se reprogramó, pero ningún documento da la fecha nueva. |
| PRY-205 Pago con QR en caja | 6 (acta, cronogramas v1 y v2, solicitud de cambio, informe, comité) | Gerente Jorge Medina, patrocinadora Liliana Torres. Declara **amarillo, 30%**. Presupuesto 1.200 M, proyección 1.466 M. Cierre original 2026-09-15; el cronograma v2 (2026-10-17) lo pone en 2026-12-31. CC-01: +107 días, +214 M, "pendiente de presentación al comité". | Autoridad del gerente y fase. Ningún hito tiene acta de recibo. |

### Lo que levantó el cálculo (28 señales; esto es todo lo que levantó)

**PRY-200 — 21 señales**
- `milestone_met_without_evidence` ×5: los cinco hitos del cronograma están "cerrado" y no hay un solo acta de recibo de ninguno (el más reciente, Despliegue en la cadena, vencía 2026-09-07, hace 40 días). Fuente: `PRY-200-tienda-en-línea/10-plan/2025-09-02-cronograma-v1.xlsx`.
- `progress_vs_plan`: declara 69% mientras el cronograma tiene 5 de 5 hitos cerrados (plan sostiene 100%, brecha de 31 puntos). Dos documentos que no pueden ser ciertos a la vez.
- `commitment_overdue` ×9: por ejemplo "Aprobar el diseño 5" (Natalia Ospina, venció 2026-09-30, hace 17 días: dijo que ya lo entregó y no presentó acta) y "Enviar el documento 9" (Ricardo Salas, 12 días).
- `commitment_rescheduled` ×3: "Enviar el documento 1" (Beatriz Cuéllar) se ha reprogramado 6 veces, del 2026-09-28 al 2026-12-19; "Cerrar la prueba 2" (Óscar Ramírez) 5 veces; "Revisar el anexo 3" (Camilo Beltrán) 3.
- `commitment_undated` ×3: "Cerrar la prueba 10", "Revisar el anexo 11" y "Mandar el ajuste del presupuesto" (Laura Vélez, "la otra semana").
- Cierre comprometido (2026-09-07) ya vencido sin cambio de línea base registrado, con proyección 8.761 M dentro del aprobado. Esto no levantó alerta de costo.

**PRY-204 — 1 señal**
- `change_without_baseline`: CC-01 (+35 días) figura autorizada y la línea base no se movió. No hay ningún documento con la fecha nueva.

**PRY-205 — 6 señales**
- `rebaseline_unauthorized`: el cronograma v2 mueve el cierre 107 días y la única solicitud de cambio (CC-01, +107 días) está pendiente de comité: 0 días autorizados.
- `variance_time`: 107 días contra la original (51,7 %).
- `variance_cost`: la proyección de 1.466 M supera el aprobado en 22,2 %.
- `progress_vs_plan`: declara 30% con 3 de 3 hitos cerrados (brecha de 70 puntos).
- `milestone_met_without_evidence` ×2: Diseño de la experiencia aprobado (vencía 2026-04-30) y Ambiente de pruebas certificado (2026-07-08) están "cerrado" sin acta. Integración con el ERP, vencida en la línea base, no aparece porque su fecha vigente (2026-12-31) aún no llega.

**Sobre el conjunto:** los tres proyectos tienen la autoridad del gerente sin documentar. Los campos de identidad de PRY-200 llevan 13 meses desde su fuente (el acta de 2025-09-02) sin confirmación posterior. No hubo contradicciones entre la ficha de PRY-200 publicada por su gerente (`ficha-pm.json`) y mi lectura.

### El portafolio completo
10 proyectos más (PRY-199, 201, 202, 203, 206 a 211) y 66 documentos, en dos lotes uno tras otro. Con lo que vi, calculo unos 30 a 40 minutos de lectura. Es estimación mía, no una medida.

### Lo que le falta a tu carpeta
- Ninguna acta de constitución trae la autoridad del gerente: hasta qué monto o cambio de alcance decide sin subir a comité. Sin eso no puedo decir si un cambio la excede.
- Las actas describen el alcance como "Componente 1, 2, 3" y "Lo que otro proyecto cubre". Sin alcance real, no hay contra qué medir un cambio de alcance.
- PRY-204 no tiene cronograma ni actas de comité. PRY-203, PRY-206 y PRY-209 tampoco tienen carpeta de reuniones.
- Los hitos se marcan cerrados sin acta de recibo en los tres proyectos. Con actas por hito, esa señal desaparece o se convierte en un hecho comprobado.
- Las notas de reunión de PRY-200 (2026-10-17) están sueltas en la raíz del proyecto y no en `30-reuniones/`. Las leí, pero conviene archivarlas donde van.
- Los cambios aprobados no dejan línea base nueva (PRY-204), y un cronograma v2 se publicó antes de que el comité aprobara el cambio (PRY-205).
- En `estado/` apareció una carpeta `PRY-200-tienda-en-línea/` que no creé yo y que no usé. Vale la pena revisar quién la dejó.

Ninguno de estos puntos es bloqueante. Puedo correr el portafolio completo cuando quieras. Si tienes un equipo de gerentes de proyecto, puedo publicar el estándar en una carpeta compartida para que usen los mismos criterios.
