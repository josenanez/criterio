Acta previa: sí, existe, del 2026-03-15 (`00-gobierno/2026-03-15-acta-constitucion.docx`). No hay una corrida anterior de /project-charter sobre PRY-204. Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17); no hizo falta registrarlos de nuevo.

## Acta — PRY-204 · Cajas de autopago
**Estado:** existe, del 2026-03-15 (aprobada por Comité Comercial)

### Qué falta
| Campo | Estado | Consecuencia |
|---|---|---|
| Autoridad del gerente | **Ausente.** El acta no dice hasta qué monto ni qué cambio de alcance puede decidir Liliana Torres sin comité. | Todo cambio sube al comité por defecto. Ya pasó: CC-01 (ampliación de alcance, +35 días, +70.000.000 COP) quedó "autorizada por el comité", sin nombre, sin fecha de sesión y sin saber si ese monto (0,39 % de 18.000 M) necesitaba comité. Sin umbral escrito, nadie puede decir si el trámite era obligatorio o costumbre. |
| Objetivo de negocio | **Es una descripción de la solución:** "Entregar cajas de autopago para Comercial". No dice qué resultado de negocio se busca. | No hay contra qué juzgar si el proyecto vale lo que cuesta ni si la ampliación CC-01 sirve al objetivo. "Entregado" cumple el objetivo aunque nadie las use. |
| Alcance | **Vacío en la práctica:** "Componente 1; Componente 2; Componente 3". | No se puede verificar qué amplió CC-01, porque no se sabe qué había. El cambio de alcance no tiene contra qué compararse. |
| Exclusiones | **Declarada pero inútil:** "Lo que otro proyecto cubre", sin nombrar el proyecto. | No se puede detectar traslape ni hueco con otros proyectos de Comercial. Quien reclame algo como "fuera de alcance" no tiene a qué citar. |
| Patrocinador / gerente | Presentes con nombre de persona: Natalia Ospina / Liliana Torres. | Sin hallazgo. |
| Supuestos y restricciones | **Ausentes.** Solo "Dependencias declaradas: ninguna declarada". | El informe de avance sí menciona un riesgo (cambio en la regulación de datos personales que puede mover el alcance) y un hallazgo de seguridad en medios de pago. Ninguno está en el acta, y que el acta declare cero dependencias con un componente de pagos es poco creíble. |
| Criterio de éxito | **No es medible:** "Cajas de autopago en producción y medido". No dice qué se mide, con qué meta ni quién lo mide. | El proyecto puede declararse exitoso con cualquier cifra. Hoy no se puede saber si va bien ni mal contra el éxito, solo contra el calendario. |
| Quién mide el éxito | **Ausente.** | Nadie es responsable de decir si se cumplió. |
| Hitos principales | **Ausentes.** Solo inicio (2026-03-25) y cierre (2026-10-04). | Sin hitos intermedios, el atraso solo se ve cuando vence el cierre, que es lo que pasó (ver abajo). |
| Cadencia del comité | **Ausente.** Se nombra al Comité Comercial, sin periodicidad ni actas de sesión en la carpeta. | No hay compromisos de comité contra los cuales medir, y la autorización de CC-01 no se puede rastrear a una sesión. |

### Contenido
**Objetivo de negocio:** pendiente de definir. El acta dice "Entregar cajas de autopago para Comercial", que describe la solución, no un resultado medible. *(Fuente: acta, 2026-03-15.)*
**Alcance:** "Componente 1; Componente 2; Componente 3" *(acta)*. Nada más: los componentes no están descritos.
**Exclusiones:** "Lo que otro proyecto cubre" *(acta)*. No se nombra el proyecto.
**Patrocinador:** Natalia Ospina · **Gerente:** Liliana Torres *(acta)*.
**Autoridad del gerente:** **pendiente de definir.** Ningún documento declara monto ni tipo de cambio. No la completo con un valor razonable.
**Comité al que reporta:** Comité Comercial *(acta)* · **Cadencia:** pendiente de definir.
**Supuestos:** pendiente de definir (el acta no trae). · **Restricciones:** pendiente de definir.
**Criterio de éxito:** "Cajas de autopago en producción y medido" *(acta)*, sin métrica ni meta · **Lo mide:** pendiente de definir.
**Hitos principales:** pendiente de definir. Solo existen inicio 2026-03-25 y cierre 2026-10-04 *(acta)*.
**Presupuesto aprobado:** 18.000.000.000 COP, aprobado por Comité Comercial el 2026-03-15 *(acta)*.

### Lo que la revisión del acta deja ver en el resto de la carpeta
- **El cierre comprometido ya pasó.** El acta fija el cierre en 2026-10-04; hoy es 2026-10-17, el informe declara 41 % de avance y estado amarillo. El mismo día 2026-10-04 se pidió CC-01 (+35 días "sobre la línea base vigente"). Ningún documento registra una línea base nueva con fecha de cierre; si la vigente fuera la original, +35 días daría 2026-11-08, pero eso lo deduzco yo, no lo dice ningún documento. Además el informe dice que el despliegue se reprogramó y que ningún documento da la fecha nueva.
- **La proyección no dice si incluye CC-01.** El informe proyecta 17.571.935.946 COP contra 18.000.000.000 aprobados, sin incluir explícitamente los 70.000.000 de CC-01. No puedo afirmar si los incluye.
- **CC-01 y el acta se contradicen en el vacío:** el acta no da al gerente autoridad alguna y CC-01 fue solicitada por la gerente y autorizada por "el comité" sin más datos. Es la ausencia de autoridad hecha trámite.

### Qué no sé
- No sé si el docx original trae algo que el convertidor no extrajo (tablas, comentarios, control de cambios); leí el texto convertido en caché.
- No sé qué comité autorizó CC-01 ni cuándo. No hay actas de comité en la carpeta.
- No sé si hay una línea base posterior a la original; no aparece en ningún documento.

## Después
- **Autoridad sin declarar:** ofrezco llevar esa definición al Comité Comercial como una decisión (monto y tipo de cambio que Liliana Torres puede resolver sin comité), con el caso de CC-01 como ejemplo. Es una decisión, no un trámite. El comité de portafolio está agendado para 2026-10-22 si quieres incluirlo.
- **RAID:** de la revisión salen supuestos que el acta no registra (la regulación de datos personales no mueve el alcance; no hay dependencias con pagos y seguridad). Ofrezco pasarlos al registro con `/raid-log`.

---
**Pie de rigor:** borrador de trabajo, no decisión ni asesoría. Leí 3 documentos de PRY-204 (acta en su texto convertido, solicitud CC-01 e informe de avance 2026-10-17) y la ficha del proyecto. Todo campo sin fuente quedó marcado como pendiente de definir. La verificación contra los originales es de quien firma el acta.
