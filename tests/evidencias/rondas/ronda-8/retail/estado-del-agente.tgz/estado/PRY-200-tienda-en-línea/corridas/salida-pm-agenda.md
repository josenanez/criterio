Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17 para criterio-project 0.3.13); no hubo que pedir ni registrar nada de nuevo.

## Reunión de seguimiento — Tienda en línea (PRY-200) · 2026-10-31
17 puntos · 45 minutos · 13 personas requeridas

Supuestos que hay que decir: la fecha es la próxima del comité según la configuración (sábado 2026-10-31; las notas de hoy dicen «en dos semanas», que coincide). Nadie dio duración, así que usé 45 minutos. La agenda se arma con lo que consta al 2026-10-17; lo que venza entre hoy y el 10-31 se revisa en la sala con la evidencia que llegue.

### Lo que no se destraba solo

> **[1] Que Beatriz diga qué bloquea «Enviar el documento 1» y quién lo puede quitar** · 10 min · **Beatriz Cuéllar** (y Rubén Cárdenas)
> Prometido para el 2026-12-19, y antes para el 12-05, y antes para el 11-25, 11-11, 11-04, 10-17 y la primera vez el 09-28. Seis reprogramaciones.
> Hoy dijo que «no alcanzó», sin decir qué. Seis veces no es seguimiento, es un bloqueo sin nombrar.
> Fuente: notas 2026-10-17; comité 2026-10-10
> **Si no se resuelve hoy:** la fecha vigente ya está a más de dos meses de la primera promesa y nada garantiza que el 12-19 sea distinta de las seis anteriores.

> **[2] Que Óscar aclare si «revisión con el proveedor» (10-27) es «Cerrar la prueba 2» y qué resultado trajo** · 8 min · **Óscar Ramírez**
> «Cerrar la prueba 2»: prometido para el 2026-09-25, y antes para el 10-12, 10-21, 11-01, 11-09, hoy vigente 11-22. Cinco reprogramaciones. La revisión del 10-27 ya habrá pasado: se pregunta qué salió. Si es el mismo compromiso, sería la sexta y la fecha pasaría de 11-22 a 10-27.
> Fuente: notas 2026-10-17; comité 2026-10-10
> **Si no se resuelve hoy:** quedan dos registros para un mismo trabajo, y el informe sigue con una prueba de carga de temporada que no alcanzó el umbral (informe 2026-10-17) sin dueño.

> **[3] Que Camilo confirme si el 11-07 para «Revisar el anexo 3» se sostiene** · 4 min · **Camilo Beltrán**
> Prometido para el 2026-09-20, y antes para el 10-02, 10-22, hoy vigente 11-07. Tres reprogramaciones.
> Fuente: comité 2026-10-10
> **Si no se resuelve hoy:** el 11-07 cae antes de la reunión siguiente; si falla será la cuarta.

### Vencido sin evidencia
Más viejo primero. Fechas de «desde» tomadas al 10-17; el 10-31 llevan dos semanas más.

| Quién | Qué | Desde | Qué se necesita hoy | Min |
|---|---|---|---|---|
| Natalia Ospina | Aprobar el diseño 5 | 2026-09-30 | Dijo el 10-10 que ya lo entregó; sin acta. Hoy no vino. Solo se trata si asiste; si no, se le pide el documento por fuera | 2 |
| Ricardo Salas | Enviar el documento 9 | 2026-10-05 | Dijo el 10-03 que ya lo entregó; sin acta. Quién lo recibió y el documento | 2 |
| Liliana Torres | Revisar el anexo 19 | 2026-10-09 | Estado y fecha nueva | 1 |
| María Restrepo | Validar el ambiente 4 | 2026-10-10 | Dijo el 09-26 que ya lo entregó; sin acta. El documento | 2 |
| Felipe Arango | Aprobar el diseño 13 | 2026-10-10 | Estado y fecha nueva | 1 |
| Felipe Arango | Validar el ambiente 20 | 2026-10-12 | Estado y fecha nueva | 1 |
| Mauricio Pérez | Confirmar la fecha 23 | 2026-10-13 | Estado y fecha nueva | 1 |
| Sandra Gil | Actualizar la matriz 22 | 2026-10-14 | Estado y fecha nueva | 1 |
| Ricardo Salas | Entregar el punto 24 | 2026-10-15 | Estado y fecha nueva | 1 |

Sin fecha hace 28 días y con «ya lo entregué» sin acta (1 min cada uno): **Camilo Beltrán** · Cerrar la prueba 10 (dicho el 09-26) y **Beatriz Cuéllar** · Revisar el anexo 11 (dicho el 10-03). Lo que tiene que quedar: una fecha o el documento. Fuente: comités 2026-09-19, 09-26 y 10-03.

Fuente de la tabla: comités 2026-09-26, 10-03 y 10-10; salida de `/pm-commitments` 2026-10-17.

### Se decide hoy o se atrasa

| Qué | Quién decide | Si no se decide | Min |
|---|---|---|---|
| Registrar «el proveedor podría no llegar con el equipo completo para la siguiente fase» como riesgo, con doliente. Se comentó el 10-17 y nadie lo anotó; es distinto del riesgo ya registrado («no ha confirmado la fecha de la última entrega»), que tampoco tiene doliente | Rubén Cárdenas | Sigue sin dueño; la revisión del 10-27 con el proveedor es el sitio para preguntarlo | 3 |
| Si el comité es semanal (configuración y seis minutas) o quincenal (lo que se dijo el 10-17); de eso depende cuándo se entrega el informe | Rubén Cárdenas, con Jorge Medina | Las fechas del informe quedan mal servidas | 2 |
| Que «Mandar el ajuste del presupuesto» (Laura Vélez, «la otra semana») tenga fecha. Es una referencia relativa, no una fecha | Laura Vélez | Sigue sin poder vencer | 1 |

Fuente: notas 2026-10-17; `config.json`; informe 2026-10-17.

### Vence antes de la próxima
Para después del 10-31 y antes del 11-14 (preventivo, 3 min en total):

| Quién | Qué | Para cuándo |
|---|---|---|
| Camilo Beltrán | Revisar el anexo 3 (ver punto 3) | 2026-11-07 |
| María Restrepo | Enviar el documento 17 | 2026-11-07 |
| Jorge Medina | Actualizar la matriz 6 | 2026-11-10 |

Con fecha entre hoy y el 10-31, que el 10-31 ya estarán vencidos o cumplidos: Camilo Beltrán · Aprobar el diseño 21 (10-18), Javier Hoyos · Confirmar la fecha 7 (10-18; ya reprogramada una vez), María Restrepo · Cerrar la prueba 18 (10-23), Mauricio Pérez · Confirmar la fecha 15 (10-25), Andrés Lozano · Actualizar la matriz 14 (10-28). Si no traen evidencia, pasan a la tabla de vencidos sin evidencia en la sala; no tienen minutos reservados.

### No es de esta reunión

| Qué | Por qué | Dónde va |
|---|---|---|
| Riesgo de cambio en la regulación de datos personales que puede mover el alcance | Sin doliente y excede la autoridad del gerente | Comité; `/criterio-project:pm-escalate` |
| 5 de 5 hitos del cronograma cerrados sin ningún acta de recibo, con el proyecto declarado en rojo y 69 % | Es un asunto de evidencia del plan, no de lo que alguien de la sala pueda mover | Material del comité |
| Quién tiene la autoridad del proyecto (`identity.authority` sin nombrar) | Hay que completarlo antes de poder formular a quién se le pide una decisión | Rubén Cárdenas, en la ficha |
| Fecha nueva de «Cerrar la prueba 2» y de «Enviar el documento 1», si la causa resulta ser del proveedor o de otra área | Solo se resuelve con quien no está en la sala | Comité, con `/criterio-project:pm-escalate` |

### Anexo — sin cambios desde el [no hay agenda previa]
Esta es la primera agenda de este proyecto: no hay una anterior contra la cual decir qué quedó igual, así que no hay anexo. El resto de los compromisos abiertos con fecha vigente no vencida figura en la ficha y no se repasa.

---

Lo que no sé: quién va a estar realmente (asumí la lista de asistentes del 10-10 y 10-17, más Natalia Ospina, que faltó hoy); la duración real de la reunión; y qué hubo entre hoy y el 10-31, por eso conviene volver a correr `/criterio-project:pm-agenda` el día anterior.

## Después
Cuando la reunión termine, `/criterio-project:pm-minutes` sobre la transcripción o las notas. Para los puntos 1, 2 y 3 y el riesgo de datos personales, `/criterio-project:pm-escalate`. Esta agenda no convoca a nadie: citar a la reunión es tuyo.
