# Tienda en línea (PRY-200) — semana del 2026-10-10 al 2026-10-17

*Sesión sin interfaz: nadie respondió la pregunta de la declaración. No se propuso ningún estado. La línea que sigue es la declaración que el gerente ya dejó escrita en su informe de avance; el agente no la eligió ni la tocó.*

**Declara el gerente (Rubén Cárdenas):** Rojo · 69 % · al 2026-10-17 (`20-seguimiento/2026-10-17-informe-avance.md`, antigüedad 0 días)
**Sustento documental:** no contradicho. Nada en los documentos sostiene un verde, pero ninguna fuente de la ficha está marcada como evidencia (0 de 162 datos; 2 declaraciones, 160 sin marcar).
**Lo que el semáforo no explica:** el rojo declarado no cubre cuatro señales: compromisos vencidos (9), compromisos reprogramados (3, hasta 6 veces), hitos «cumplidos» sin evidencia (5 de 5) y el avance de 69 % frente a un plan que sostiene 100 %.

## Qué cambió esta semana
No se puede comparar: esta es la primera instantánea de este estado (`snapshots/2026-10-17.json`), y el diff no tiene corrida anterior contra la cual calcular. Cambios detectados: 0. Eso no significa que nada cambió; significa que no hay punto de partida.

Lo nuevo que sí aparece en los documentos de hoy: la prueba de carga de temporada no alcanzó el umbral y se repite; se ajustó el plan de pruebas con seguridad; se acordó con arquitectura la revisión de requisitos no funcionales (informe de avance). Se comentó en la reunión un riesgo nuevo, el proveedor podría no llegar con el equipo completo, que nadie registró (`2026-10-17-notas-reunion.txt`).

## Lo que sigue igual y sigue mal
| Qué | Desde | Días así |
|---|---|---|
| Hito «Despliegue en la cadena» marcado cumplido, sin evidencia | 2026-09-07 | 40 |
| Hito «Piloto en tiendas» cumplido, sin evidencia | 2026-06-27 | 112 |
| Hito «Integración con el ERP» cumplido, sin evidencia | 2026-04-16 | 184 |
| Hito «Ambiente de pruebas certificado» cumplido, sin evidencia | 2026-02-03 | 256 |
| Hito «Diseño de la experiencia aprobado» cumplido, sin evidencia | 2025-11-23 | 328 |
| Fecha de cierre vigente vencida con avance declarado de 69 % | 2026-09-07 | 40 |

## Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2026-09-07 | 2026-09-07 | 0 días calculados contra ambas |
| Presupuesto aprobado | 9.500.000.000 COP | 9.500.000.000 COP | proyección 8.761.040.718 (−7,8 %) |

Replanificaciones: 0. Cambios de control de cambios: 0.

Cuidado con ese 0: la línea base nunca se movió y la fecha de cierre pasó hace 40 días con el proyecto al 69 %. El cálculo da cero porque no hay una fecha nueva contra la cual medir, no porque no haya atraso. Es el caso que la doble medición existe para mostrar: nadie replanificó, y el plan sigue diciendo «terminado».

El plan marca los cinco hitos como cumplidos (el plan sostiene 100 %), contra el 69 % declarado: 31 puntos de diferencia. Todos los estados «cumplido» salen del cronograma v1 del 2025-09-02, es decir, de un documento de hace 13 meses.

### Hitos de las próximas cuatro semanas
Ninguno: los cinco hitos del plan vencieron entre 2025-11-23 y 2026-09-07. No hay hito futuro en el plan.

## Las cifras
| Aprobado | Comprometido | Ejecutado | Proyectado | Disponible real |
|---|---|---|---|---|
| 9.500.000.000 | 5.420.644.515 (57,1 %) | 5.110.694.551 (53,8 %) | 8.761.040.718 | 4.079.355.485 |

Disponible real = aprobado − comprometido. Aprobado − ejecutado daría 4.389.305.449; la diferencia es 309.949.964 comprometidos que aún no se ejecutaron.
Cifras de COP, tomadas del informe de avance del gerente.

## Abierto
**Reprogramados:**
- Beatriz Cuéllar, «Enviar el documento 1»: 6 veces; original 2026-09-28, hoy 2026-12-19.
- Óscar Ramírez, «Cerrar la prueba 2»: 5 veces; original 2026-09-25, hoy 2026-11-22.
- Camilo Beltrán, «Revisar el anexo 3»: 3 veces; original 2026-09-20, hoy 2026-11-07.

**Vencidos sin evidencia:**
- Natalia Ospina, «Aprobar el diseño 5», vence 2026-09-30, 17 días (comité 09-12).
- Ricardo Salas, «Enviar el documento 9», vence 2026-10-05, 12 días (comité 09-19).
- Liliana Torres, «Revisar el anexo 19», vence 2026-10-09, 8 días (comité 10-03).
- María Restrepo, «Validar el ambiente 4», vence 2026-10-10, 7 días (comité 09-05).
- Felipe Arango, «Aprobar el diseño 13», vence 2026-10-10, 7 días (comité 09-26).
- Felipe Arango, «Validar el ambiente 20», vence 2026-10-12, 5 días (comité 10-03).
- Mauricio Pérez, «Confirmar la fecha 23», vence 2026-10-13, 4 días (comité 10-10).
- Sandra Gil, «Actualizar la matriz 22», vence 2026-10-14, 3 días (comité 10-10).
- Ricardo Salas, «Entregar el punto 24», vence 2026-10-15, 2 días (comité 10-10).

**Sin fecha:** Camilo Beltrán «Cerrar la prueba 10» y Beatriz Cuéllar «Revisar el anexo 11» (comité 09-19); Laura Vélez «Mandar el ajuste del presupuesto» (notas 10-17).

**RAID sin movimiento:** tres riesgos y una incidencia, ninguno con responsable. La ficha no trae fecha de apertura de la incidencia (prueba de carga), así que los días sin movimiento no se pueden contar.
**Proveedor:** la ficha no registra entregables de proveedor (lista vacía), aunque el informe dice que el proveedor no ha confirmado la fecha de su última entrega y hay actas de recibo (8, 12 y 16) en seguimiento. No se puede decir si hay entregables vencidos, aceptados sin documento o facturados sin entrega.

## Lo que necesito de alguien
- **Beatriz Cuéllar, Óscar Ramírez, Camilo Beltrán:** fecha real y razón de cada reprogramación. Con tres o más reprogramaciones, el punto de comité está justificado.
- **Natalia Ospina, Ricardo Salas, Liliana Torres, María Restrepo, Felipe Arango, Mauricio Pérez, Sandra Gil:** evidencia o nueva fecha de lo vencido.
- **Rubén Cárdenas:** responsable de cada riesgo y de la incidencia de la prueba de carga; registrar el riesgo del equipo del proveedor; decir si el cronograma se replanifica, porque la fecha de cierre ya pasó. **Replanificar con el patrocinador excede la autoridad del gerente: es material de comité** (próximo: 2026-10-31).
- **Laura Vélez:** fecha para el ajuste del presupuesto.
- **Quien corresponda:** la autoridad del proyecto no consta en la ficha.

## Lo que no se sabe
**Sin dato:** autoridad (`identity.authority`), fase (`identity.phase`), responsable de los tres riesgos, y fecha de apertura y responsable de la incidencia. Evidencia de recibo de los cinco hitos. 23 campos tienen más de 12 meses (todos del acta y el cronograma de 2025-09-02).
**Silencio:** último documento hace 0 días (informe de avance y notas del 2026-10-17) · última reunión hace 0 días (notas del 2026-10-17; último comité semanal: 2026-10-10, hace 7 días).

---
*Ficha: `estado/PRY-200-tienda-en-línea/records/PRY-200.json`, con corte al 2026-10-17. 7 campos sin dato (`not_found`) y 23 vencidos por antigüedad. Términos v1.1 aceptados por José Francisco Ñáñez el 2026-10-17: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.13*
