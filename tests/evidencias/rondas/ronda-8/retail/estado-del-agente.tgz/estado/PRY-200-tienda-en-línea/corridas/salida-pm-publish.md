Publiqué la ficha en `documentos/proyectos/PRY-200-tienda-en-línea/00-gobierno/ficha-pm.json`, con corte al 2026-10-17.

**Lleva:** 32 campos con dato · 7 sin decir en ninguna parte · declara **rojo** al 2026-10-17 (69 % de avance declarado)

**Lo más viejo que va ahí:** identidad, plan (fechas e hitos), alcance y monto aprobado, del 2025-09-02 (acta de constitución y cronograma v1) — 13 meses, pasa de un año.

**Antes de publicar:**
- Términos vigentes (versión 1.1, aceptada por José Francisco Ñáñez el 2026-10-17); no hubo que registrarlos de nuevo.
- Recalculé la ficha hoy. No hay cronograma más nuevo que la v1, así que `plan.end_date` (2026-09-07) coincide con la línea base v1; no hay diferencia que explicar.
- La carpeta de gobierno ya existía; no creé nada.

**Qué va a ver la PMO (las 21 alertas del cálculo):**
- Avance declarado 69 % contra 5 de 5 hitos marcados cumplidos: 31 puntos de diferencia.
- Los 5 hitos aparecen como cumplidos sin evidencia (el cronograma es la v1, con fecha de 2025, y declara cerrados hitos de 2026).
- 9 compromisos vencidos, 3 sin fecha y 3 reprogramados varias veces (hasta 6).
- Tu informe de hoy no da cuenta de esas cuatro señales: compromisos vencidos, reprogramados, hitos sin evidencia y avance contra plan.

**Sin decir en ninguna parte:** autoridad, fase, responsable de los 3 riesgos, y fecha y responsable de la incidencia abierta. Proveedores y cambios van vacíos.

La declaración de estado sigue siendo tuya y la ficha la marca como declarada. No avisé a nadie: Vera la lee en su próximo barrido.
