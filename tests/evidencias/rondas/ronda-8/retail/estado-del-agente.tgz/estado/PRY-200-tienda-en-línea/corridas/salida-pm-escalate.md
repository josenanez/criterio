Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17 para criterio-project 0.3.13); no hubo que pedir ni registrar nada de nuevo.

Sesión sin interfaz: no se indicó tema, así que escalé lo que ya estaba marcado como escalable en la agenda y el informe del 2026-10-17. Nadie respondió preguntas; donde faltaba un dato lo digo y no lo invento.

# Para decisión — Tienda en línea (PRY-200) · 2026-10-17

## Primer punto: la autoridad del gerente no consta en el acta

**Hallazgo:** el acta de constitución (2025-09-02) nombra patrocinador (Jorge Medina), gerente (Rubén Cárdenas) y comité (Comité de Transformación Digital), pero **no declara qué puede decidir el gerente** (`identity.authority` sin dato). Sin eso no se puede decir, con respaldo, qué excede su autoridad y qué no. Mientras no conste, el resto de este paquete se apoya en una suposición declarada: que cambiar la línea base aprobada por el Comité lo decide el Comité.

### ¿Se declara por escrito la autoridad del gerente del proyecto (alcance, fechas, presupuesto y proveedor que puede decidir sin subir), sí o no?

**Quién decide:** el patrocinador, Jorge Medina, o el Comité de Transformación Digital que aprobó el acta (el acta no dice cuál de los dos) · **Si no se decide hoy:** el 2026-10-31 (próximo comité) cualquier otro punto de este paquete sigue sin poder dirigirse a quien tenga la facultad, y se corre el riesgo de que se decida algo que no valga.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Se agrega la autoridad al acta (adenda) | Sin cambio | Una sesión de comité | Sin costo declarado en los documentos |
| B. No se declara | Sin cambio | Sin cambio | Sin costo declarado; cada escalamiento futuro se discute primero por quién decide |

**Recomiendo:** A — es lo que evita que los puntos siguientes se devuelvan con «eso no me corresponde».

## Segundo punto: la fecha de cierre pasó y la línea base sigue diciendo «terminado»

### ¿Se aprueba una línea base nueva (con nueva fecha de cierre y proyección de costo) para el proyecto, o se mantiene la v1 y se sigue reportando el atraso contra ella?

**Quién decide:** según la suposición de arriba, el Comité de Transformación Digital con el patrocinador (el Comité aprobó la línea base v1 y el presupuesto el 2025-09-02) · **Si no se decide hoy:** la línea base v1 sigue con cierre al 2026-09-07; hoy lleva 40 días vencida con el avance declarado en 69 % y el 2026-10-31 serán 54. Fecha límite externa (oferta, contrato, ventana de temporada) que obligue a decidir antes: **no consta en ningún documento**; no la invento.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Línea base v2 con nueva fecha de cierre; la v1 queda intacta como historial | No consta si cambia | Nueva fecha **no existe en los documentos**; la debe proponer el gerente (tras la revisión con el proveedor del 2026-10-27) | Proyección actual al cierre 8.761.040.718 COP sobre 9.500.000.000 aprobados; no hay proyección recalculada para una fecha nueva |
| B. Mantener la v1 y reportar el atraso | Sin cambio | Atraso contra v1 crece cada semana (40 días hoy) | El mismo; sin control de cambios, el informe seguirá en rojo sin fecha contra la cual medir |

**Recomiendo:** A, pero el comité no puede decidirla el 10-31 sin que el gerente traiga la fecha propuesta y la proyección recalculada. Esa fecha y ese costo son lo que falta para que la pregunta esté completa; no los puedo calcular desde la ficha. La razón: hoy el desvío calculado da 0 días solo porque nadie replanificó, y eso esconde el atraso.

**Estado del cálculo de efecto (`impact`, con 40 días, que es el atraso ya acumulado y no una fecha propuesta):** devuelve 0 proyectos alcanzados y 0 hitos por los que pasa el cambio. Lectura honesta: la ficha no declara dependencias (acta: «Ninguna declarada») y en el estado hay un solo proyecto, así que **no es evidencia de que ningún otro proyecto se vea afectado**. Tampoco dice cuántos días se mueve cada proyecto alcanzado: eso necesita holgura por actividad, que la ficha no tiene.

### A quién alcanza
| Proyecto | Gerente | ¿Sostiene su fecha? | Dependencia confirmada |
|---|---|---|---|
| Ninguno en la ficha ni en el estado | — | — | — (sin dependencias declaradas; no se confirmó con nadie) |

### Mis hitos por los que pasa
| Hito | Fecha vigente | En cuántos días |
|---|---|---|
| Ninguno: los cinco hitos del plan vencieron entre 2025-11-23 y 2026-09-07 y los cinco figuran «cumplidos» en el cronograma v1 sin acta de recibo | — | — |

## Lo que no armé como paquete, y por qué

- **Riesgo de cambio en la regulación de datos personales que puede mover el alcance.** Excede la autoridad según la agenda, pero no tiene doliente ni se puede formular como pregunta cerrada: faltan opciones y su costo. Primero hay que nombrar al responsable.
- **«Enviar el documento 1» (Beatriz Cuéllar, 6 reprogramaciones), «Cerrar la prueba 2» (Óscar Ramírez, 5) y «Revisar el anexo 3» (Camilo Beltrán, 3).** Superan el umbral de reprogramaciones, pero no se sabe la causa. Si es una llamada, se resuelve sin comité; si es del proveedor o de otra área, escala. Esa llamada es de Rubén Cárdenas y debe hacerse antes del 10-31.
- **Riesgo del proveedor que podría no llegar con el equipo completo, y riesgo de la fecha de última entrega sin confirmar.** Primero se registran con doliente (decide Rubén Cárdenas); la revisión del 2026-10-27 con el proveedor es el sitio para preguntarlo.
- **Los cinco hitos cerrados sin acta de recibo.** Es un asunto de evidencia, no una decisión; va como material del comité.

## De dónde sale esto
- Sin autoridad declarada, patrocinador, gerente, comité, presupuesto aprobado, fechas v1 y «dependencias: ninguna declarada»: `documentos/proyectos/PRY-200-tienda-en-línea/00-gobierno/2025-09-02-acta-constitucion.md`.
- Avance 69 %, estado rojo, comprometido, ejecutado y proyección 8.761.040.718 COP: `20-seguimiento/2026-10-17-informe-avance.md`.
- Hitos cumplidos sin acta: `10-plan/2025-09-02-cronograma-v1.xlsx`; ficha `estado/PRY-200-tienda-en-línea/records/PRY-200.json`.
- Revisión con el proveedor el 2026-10-27, riesgo del equipo del proveedor: `2026-10-17-notas-reunion.txt`.
- Reprogramaciones: ficha, `commitments`, con minutas `30-reuniones/2026-09-05` a `2026-10-10`.
- Próximo comité 2026-10-31: `config.json`; las notas de hoy dicen «en dos semanas» (coincide).

## Lo que no sé
La autoridad del gerente; la nueva fecha de cierre y su costo; si hay una fecha límite externa; la causa de las reprogramaciones; si otros proyectos dependen de este.

## Lo que este comando no hizo
No escaló nada: llevar el paquete al comité es de Rubén Cárdenas. No estimó días por proyecto alcanzado. No escribió a nadie.
