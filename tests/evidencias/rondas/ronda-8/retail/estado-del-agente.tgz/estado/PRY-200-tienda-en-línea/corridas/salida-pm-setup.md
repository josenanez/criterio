## Listo — PRY-200 · Tienda en línea

Soy Samuel. Proceso lo que pasa en tu proyecto y llevo la cuenta de lo que se prometió en cada reunión.

**Lo que miré:** 13 documentos · 7 de reunión (6 minutas del comité semanal y las notas de hoy) · la última, las notas del 2026-10-17. Formatos: 11 .md, 1 .txt, 1 .xlsx; todos legibles. Leí las 6 minutas de la más vieja a la más nueva, las 3 actas de recibo, el informe de avance, el acta de constitución y el cronograma.
**Preguntas:** en esta sesión nadie podía responder; tomé la respuesta sugerida en cada una.
- Quién eres: Rubén Cárdenas, gerente de PRY-200 (acta de constitución).
- Reunión: sábado, semanal (las seis minutas caen en sábado). Las notas de hoy dicen «próxima reunión en dos semanas», así que anoté el 2026-10-31.
- Estado: `estado/PRY-200-tienda-en-línea`, junto a `documentos/`, fuera de la carpeta de documentación y de `.criterio/`.
- Términos: los mostré tal cual; la instrucción de la prueba trae el sí de José Francisco Ñáñez, versión 1.1, fecha 2026-10-17.

**Términos:** aceptados para la versión 0.3.13 (términos 1.1) · comprobante en `.criterio/terminos/aceptacion-criterio-project-0.3.13-2026-10-17.md` y `.pdf` · SHA-256 b8d0cca7fea66fcb… (md) y 28e9cfed31cb47fb… (pdf)

### Lo que está abierto, y cuántas veces se ha movido
26 compromisos en total: 3 cumplidos con acta, 9 vencidos sin evidencia, 3 sin fecha y 11 abiertos con fecha.

**Movidos tres veces o más (el hallazgo):**

| Quién | Qué | Primera promesa | Vigente | Veces movido |
|---|---|---|---|---|
| Beatriz Cuéllar | Enviar el documento 1 | 2026-09-28 (comité 09-05) | 2026-12-19 (notas 10-17) | 6 |
| Óscar Ramírez | Cerrar la prueba 2 | 2026-09-25 (comité 09-05) | 2026-11-22 (comité 10-10) | 5 |
| Camilo Beltrán | Revisar el anexo 3 | 2026-09-20 (comité 09-05) | 2026-11-07 (comité 10-10) | 3 |

Fechas sucesivas de Beatriz: 10-17, 11-04, 11-11, 11-25, 12-05, 12-19. Las de Óscar: 10-12, 10-21, 11-01, 11-09, 11-22. Las de Camilo: 10-02, 10-22, 11-07. Hoy las notas dicen que el «documento 1» «no alcanzó» y queda para el 19/12/2026. Se ha vuelto a prometer en cada reunión desde el 09-12, siempre con fecha más lejana. Eso apunta a un bloqueo que nadie ha nombrado.

**Vencidos sin evidencia** (la fecha vigente pasó y no hay acta de recibo):

| Quién | Qué | Venció | Días | Cita |
|---|---|---|---|---|
| Natalia Ospina | Aprobar el diseño 5 | 2026-09-30 | 17 | comité 09-12 · «ya entregó», sin acta (10-10) |
| Ricardo Salas | Enviar el documento 9 | 2026-10-05 | 12 | comité 09-19 · «ya entregó», sin acta (10-03) |
| María Restrepo | Validar el ambiente 4 | 2026-10-10 | 7 | comité 09-05 · «ya entregó», sin acta (09-26) |
| Felipe Arango | Aprobar el diseño 13 | 2026-10-10 | 7 | comité 09-26 |
| Liliana Torres | Revisar el anexo 19 | 2026-10-09 | 8 | comité 10-03 |
| Felipe Arango | Validar el ambiente 20 | 2026-10-12 | 5 | comité 10-03 |
| Mauricio Pérez | Confirmar la fecha 23 | 2026-10-13 | 4 | comité 10-10 |
| Sandra Gil | Actualizar la matriz 22 | 2026-10-14 | 3 | comité 10-10 |
| Ricardo Salas | Entregar el punto 24 | 2026-10-15 | 2 | comité 10-10 |

Tres de ellos (diseño 5, documento 9, ambiente 4) salieron de la tabla porque la persona dijo que ya lo había entregado. En esas reuniones nadie presentó acta. Decirlo en la reunión no lo cierra; lo cierra un acta.

**Cumplidos con acta:** Entregar el punto 8 (Gustavo Neira, acta 2026-09-26), Validar el ambiente 12 (Ricardo Salas, acta 2026-09-26), Entregar el punto 16 (Mauricio Pérez, acta 2026-10-10).

**Otros 8 abiertos con fecha:** Actualizar la matriz 6 (Jorge Medina, movido 2 veces, vigente 11-10), Confirmar la fecha 7 (Javier Hoyos, vigente 10-18, mañana), Aprobar el diseño 21 (Camilo Beltrán, 10-18), Confirmar la fecha 15 (Mauricio Pérez, 10-25), Actualizar la matriz 14 (Andrés Lozano, 10-28), Enviar el documento 17 (María Restrepo, 11-07), Cerrar la prueba 18 (María Restrepo, 10-23) y Revisión con el proveedor (Óscar Ramírez, 10-27).

**Otras señales de `compute`:**
- El informe declara **rojo, 69 %**; el cronograma tiene los 5 hitos como cerrados, lo que sostiene 100 %: una brecha de 31 puntos entre los dos documentos.
- Los 5 hitos están declarados cerrados **sin ningún acta que lo pruebe**. El último, «Despliegue en la cadena», era del 2026-09-07, hace 40 días; el cierre del proyecto es esa misma fecha.
- Presupuesto (informe del 10-17): comprometido 57,1 %, ejecutado 53,8 %, proyección 7,8 % por debajo de lo aprobado. No hay señal de costo.

### Sin fecha
Nadie los fechó, así que no pueden estar vencidos, y por eso son los que se pierden en los informes:
- Camilo Beltrán · Cerrar la prueba 10 — «por definir» (comité 09-19); el 09-26 dijo que ya lo entregó, sin acta.
- Beatriz Cuéllar · Revisar el anexo 11 — «por definir» (comité 09-19 y 09-26); el 10-03 dijo que ya lo entregó, sin acta.
- Laura Vélez · Mandar el ajuste del presupuesto — «la otra semana» (notas 10-17). No la convertí en fecha.

### Qué le falta a tu carpeta
- **Actas de recibo de los hitos.** El cronograma declara cinco hitos cerrados y no hay ni una; un hito cerrado se ve igual que uno sin probar.
- **Cronograma vigente.** Solo hay la v1, y su fecha de archivo (2025-09-02) no cuadra con que declare cerrados hitos de 2026. Por eso la fecha de cierre sigue siendo la original.
- **Las minutas son tablas.** No dicen por qué se mueve cada fecha ni quién bloquea. Y la reunión de hoy solo tiene notas sueltas, no minuta.
- **Riesgo sin registrar.** Las notas de hoy dicen que el proveedor podría no llegar con el equipo completo y que nadie lo anotó. Lo dejé en la ficha, pero sin dueño. Falta además el contrato del proveedor, que no está en la carpeta.
- **No encontré** facultad del gerente (hasta qué monto puede decidir), fase y dueño de los riesgos.
- Duda abierta: «Revisión con el proveedor» (Óscar Ramírez, 10-27) puede ser la «prueba 2» o un compromiso nuevo; las notas no lo dicen. Lo registré aparte.

La ficha queda sin sellar (`estado/PRY-200-tienda-en-línea/records/PRY-200.json`). Leí todas las minutas, son menos de veinte, así que no queda nada por leer.

**Cuándo vuelvo:** el sábado 2026-10-31, la próxima reunión según las notas de hoy.
