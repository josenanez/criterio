# Plan — Tienda en línea (PRY-200) · borrador del 2026-10-17
**Desde:** acta de constitución del 2025-09-02 (`00-gobierno/2025-09-02-acta-constitucion.md`) · **Criterio de éxito:** «Tienda en línea en producción y medido» (acta, sección *Criterio de éxito*)

Términos vigentes (v1.1), aceptados por José Francisco Ñáñez el 2026-10-17; no hubo que registrarlos de nuevo.

> **Contexto que cambia la lectura de este borrador.** El cierre comprometido en el acta es **2026-09-07** y ya pasó. El informe del 2026-10-17 declara **rojo, 69 %**, y el cronograma v1 marca los cinco hitos como «cerrado», incluido «Despliegue en la cadena» (2026-09-07), sin evidencia de recibo en la carpeta. No hay solicitudes de cambio ni una línea base distinta de la v1. Este borrador es, en la práctica, una **replanificación**: no sustituye la línea base y cualquier fecha nueva pasa por control de cambios.

## Lo que le falta al acta
| Qué | Consecuencia de planificar sin eso |
|---|---|
| **Alcance sin contenido:** «Componente 1, Componente 2, Componente 3» | No se puede descomponer por entregable: no se sabe qué es cada componente. Los tres nodos de la WBS quedan «sin definir» y cualquier avance contra ellos (el 69 %) no tiene sobre qué medirse. |
| **Fuera de alcance genérico:** «Lo que otro proyecto cubre» | No dice qué proyecto ni qué. Con el riesgo de regulación de datos personales abierto, no hay frontera para decidir si un cambio es alcance o es de otro. |
| **Criterio de éxito sin umbral:** «en producción y medido» | No dice qué se mide, con qué meta ni cuándo. «Medido» no se puede aceptar ni rechazar. (El informe habla de un «umbral pactado» de carga que el acta no recoge.) |
| **Sin autoridad declarada** (nadie dice qué decide el gerente y qué sube) | No se sabe qué puedes decidir al replanificar y qué hay que llevar al Comité de Transformación Digital. Lo marco y no lo relleno. |
| **Dependencias: «Ninguna declarada»** | Hay un proveedor con una entrega sin fecha confirmada (informe) y un cambio regulatorio posible; el acta no los contempla. La ficha tampoco tiene proveedores registrados. |
| **Sin quién acepta cada entregable** | El acta nombra patrocinador (Jorge Medina) pero no dice quién recibe y acepta cada cosa. |

Patrocinador sí está declarado (Jorge Medina): hay a quién llevar las excepciones.

## WBS
| # | Entregable | Quién lo acepta | De dónde sale | Duración |
|---|---|---|---|---|
| 1 | Componente 1 (contenido no definido) | sin definir | del acta (nombre) · contenido **sin definir** | — |
| 2 | Componente 2 (contenido no definido) | sin definir | del acta (nombre) · contenido **sin definir** | — |
| 3 | Componente 3 (contenido no definido) | sin definir | del acta (nombre) · contenido **sin definir** | — |
| 4 | Tienda en línea en producción | sin definir (¿patrocinador?) | del acta (criterio de éxito) | — |
| 5 | Medición de la tienda en producción: qué se mide y con qué meta | sin definir | del acta («medido») · meta y métricas **sin definir** | — |
| 6 | Diseño de la experiencia aprobado | sin definir | supuesto: hito del cronograma v1, asumo que equivale a un entregable | — |
| 7 | Ambiente de pruebas certificado | sin definir | supuesto: hito del cronograma v1 | — |
| 8 | Integración con el ERP | sin definir | supuesto: hito del cronograma v1 | — |
| 9 | Prueba de carga de temporada superada contra el umbral pactado | sin definir | supuesto: sale del informe del 2026-10-17 (la prueba «se repite»); el umbral no está en el acta | — |
| 10 | Piloto en tiendas | sin definir | supuesto: hito del cronograma v1 | — |
| 11 | Despliegue en la cadena | sin definir | supuesto: hito del cronograma v1 | — |
| 12 | Última entrega del proveedor | sin definir | supuesto: el informe la menciona sin fecha; no hay contrato en la carpeta | — |

Los nodos 6–12 no están en el acta: son hitos o menciones de otros documentos que asumo como entregables. Si el negocio no los reconoce así, se caen.

## Orden
Sin fechas. Lo que necesita qué, tomando el orden del cronograma v1 como supuesto:
- 6 (diseño) → 7 (ambiente de pruebas) → 8 (integración ERP) → 10 (piloto) → 11 (despliegue) → 4 (producción) → 5 (medición).
- 9 (prueba de carga) necesita 7 y 8 y es previa a 11, si el umbral es condición de salida; **no está dicho en ningún documento**.
- 12 (entrega del proveedor): no se sabe de qué nodo depende ni cuál depende de ella. Queda suelta hasta que alguien lo diga.
- 1, 2 y 3 no se pueden ordenar: no se sabe qué son.

## Supuestos sobre los que está construido
| Supuesto | Qué pasa si resulta falso |
|---|---|
| Los hitos del cronograma v1 son entregables aceptables | La WBS pierde los nodos 6–11 y queda con tres componentes sin contenido. |
| El orden del cronograma v1 sigue siendo el orden real de dependencia | El orden de arriba no sirve y hay que rehacerlo con el equipo. |
| El umbral de la prueba de carga es condición previa al despliegue | La prueba puede correr en paralelo o después, y cambia la ruta crítica. |
| La entrega del proveedor es un solo entregable | Si son varias, el nodo 12 se descompone y puede tocar más nodos. |
| Medir significa medir en producción, después de desplegar | Si la medición es parte del piloto, el nodo 5 se adelanta. |

Pasan a riesgos del proyecto (con doliente) en cuanto el plan se apruebe.

## Sin definir
| Qué | Quién lo define |
|---|---|
| Qué son los Componentes 1, 2 y 3 | Patrocinador (Jorge Medina) con el gerente; el acta no lo dice |
| Qué queda fuera de alcance y qué proyecto lo cubre | Patrocinador / Comité de Transformación Digital |
| Qué se mide, con qué meta y cuándo, para dar por cumplido «medido» | Patrocinador |
| Quién acepta cada entregable | Patrocinador |
| Qué decide el gerente y qué sube al comité (autoridad) | Comité de Transformación Digital |
| Umbral de la prueba de carga y dónde está pactado | Sin dueño visible en los documentos |
| Qué proveedor, qué contrato y qué falta entregar | Sin dueño visible: no hay proveedor en la ficha ni contrato en la carpeta |
| Fase actual del proyecto | Sin dueño visible |

## Proyectos análogos
Ninguno a la vista. La configuración de PRY-200 apunta solo a la carpeta del proyecto y a su estado; no hay carpeta de fichas de la PMO que consultar. Es la respuesta correcta y evita una falsa precisión: no hay referencia de duración.

## Preguntas para el equipo
Una por duración vacía:
1. ¿Qué son los Componentes 1, 2 y 3, y cuánto toma cada uno? (nodos 1–3)
2. ¿Cuánto toma poner la tienda en producción una vez desplegada? (nodo 4)
3. ¿Qué se mide, con qué meta y cuánto tiempo hay que medir antes de dar por cumplido el criterio? (nodo 5)
4. ¿El diseño sigue aprobado o se reabrió con los requisitos no funcionales? ¿Cuánto toma lo que falte? (nodo 6)
5. ¿Qué falta para dar por certificado el ambiente de pruebas? (nodo 7)
6. ¿Qué falta de la integración con el ERP, si algo? (nodo 8)
7. ¿Cuánto toma repetir la prueba de carga, y cuánto corregir lo que no alcanzó el umbral? (nodo 9)
8. ¿El piloto en tiendas se cerró con acta de recibo? ¿Dónde está? (nodo 10)
9. ¿El despliegue en la cadena ocurrió? Si ocurrió, ¿por qué el informe dice 69 %? (nodo 11)
10. ¿Qué falta por entregar del proveedor y cuánto toma? (nodo 12)

## Para comprometer una fecha falta
- **Disponibilidad real del equipo** para lo que resta. No está en ningún documento.
- **La fecha del proveedor** para su última entrega, y si llega con el equipo completo para la siguiente fase (comentado en la reunión de hoy, sin registrar como riesgo).
- **La ventana de producción** y la de temporada, que condiciona cuándo se puede desplegar y probar la carga.
- **Una línea base vigente aprobada.** Hoy solo existe la v1 del 2025-09-02, ya vencida; una fecha nueva requiere control de cambios, y esa decisión es del patrocinador y el comité, no de este borrador.

## Qué sigue
Este comando no crea línea base ni compromete fechas ni asigna personas. Cuando el plan se apruebe: registrarlo como siguiente versión de la línea base (sin borrar la v1) y pasar los supuestos al RAID con doliente. Hoy el RAID ya tiene riesgos sin doliente: regulación de datos personales, fecha del proveedor y equipo del proveedor para la siguiente fase (este último, comentado hoy y sin registrar).
