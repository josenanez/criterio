Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17 para criterio-project 0.3.13); no hubo que pedir ni registrar nada de nuevo.

# Acta — Tienda en línea (PRY-200) · 2026-10-17
**Asistieron:** Andrés Lozano, Beatriz Cuéllar, Camilo Beltrán, Felipe Arango, Javier Hoyos, Jorge Medina, Laura Vélez, Liliana Torres, María Restrepo, Mauricio Pérez, Ricardo Salas, Rubén Cárdenas, Sandra Gil, Óscar Ramírez (14) · **Fuente:** `2026-10-17-notas-reunion.txt` · **Ausentes con tema en agenda:** no hay agenda en las notas, así que no se puede decir. Natalia Ospina estuvo el 10-03 y hoy no aparece; tiene «Aprobar el diseño 5» vencido y hoy nadie lo mencionó.

## Compromisos
| Quién | Qué | Para cuándo | |
|---|---|---|---|
| Beatriz Cuéllar | Enviar el documento 1 | 2026-12-19 | **Reprogramado por 6.ª vez.** Primera promesa 2026-09-28; fechas sucesivas: 10-17, 11-04, 11-11, 11-25, 12-05, 12-19. Cita: «lo de "enviar el documento 1" no alcanzó, se compromete para el 19/12/2026». |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-27 | Nuevo. Ver «Sin resolver»: no queda claro si es un compromiso aparte o un movimiento de otro. |

### Sin fecha
| Quién | Qué |
|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto («la otra semana»). Es una referencia relativa, no una fecha; no la convertí en una. Cuenta aparte y no puede vencer. |

(Siguen sin fecha de reuniones anteriores: Camilo Beltrán · Cerrar la prueba 10 y Beatriz Cuéllar · Revisar el anexo 11. Hoy no se tocaron.)

## Decisiones
Ninguna. Las notas no registran ninguna decisión.

## Quedó sin decidir
Ninguno de los puntos que las notas dejan abiertos tiene a alguien que lo estuviera decidiendo; no se anota ninguno para no inventarlo.

## Intenciones sin doliente
Ninguna.

## Dicho al pasar y no registrado
| Qué | Quién lo dijo | Categoría | Ya estaba en el RAID |
|---|---|---|---|
| «El proveedor podría no llegar con el equipo completo para la siguiente fase»; las notas añaden que «nadie lo anotó como riesgo» | No consta; las notas dicen «se comentó» | Riesgo (capacidad del proveedor) | **No.** El informe del 10-17 registra un riesgo cercano pero distinto: «el proveedor no ha confirmado la fecha de la última entrega». Aquel habla de la fecha; este, del equipo. Sin doliente. |

## Cerrado en esta reunión
Nada. (Sección omitida: no se citó ningún documento de recibo.)

## Lo que esta reunión contradice
| Campo | Dijo la reunión | Dice el expediente | Fuente y fecha de cada uno |
|---|---|---|---|
| Cadencia del comité | «próxima reunión en dos semanas» (≈ 2026-10-31) | La configuración de Samuel dice semanal, y las seis minutas anteriores son semanales | Notas 2026-10-17 · `config.json` |

El acta de constitución nombra al Comité de Transformación Digital y al patrocinador (Jorge Medina), pero no fija cadencia, así que esto no contradice ningún campo de la ficha. Lo dejo escrito porque, si la cadencia pasó de semanal a quincenal, también cambian las fechas a las que se sirve el informe. Sobre el patrocinador, la fecha de cierre y el comité las notas no dicen nada.

## Sin resolver de la transcripción
- «Óscar Ramírez: revisión con el proveedor, queda para el 2026-10-27»: «queda para» suena a algo que ya existía y se movió, pero no hay en la tabla una «revisión con el proveedor». Lo más cercano es «Cerrar la prueba 2» (Óscar, vigente 11-22), y nada dice que sea lo mismo. Lo registré aparte; si es ese compromiso, sería su 6.ª reprogramación y la fecha vigente pasaría de 11-22 a 10-27 (adelantada).
- «Lo de "enviar el documento 1" no alcanzó»: no se dice qué no alcanzó (tiempo, recursos, insumos). El 10-10 la fecha vigente era 12-05, que no ha llegado.
- «Próxima reunión en dos semanas»: sin fecha; asumí 2026-10-31 por el día de reunión (sábado).
- Las notas son un resumen de cinco líneas y no registran avance de ningún otro compromiso. Los 9 vencidos sin evidencia de la ficha no se mencionan y no los doy por cerrados.

## Recálculo
`compute` sobre la ficha: sin `record_issues`. Compromisos: 26 en total (3 cumplidos con acta, 9 vencidos sin evidencia, 3 sin fecha, 11 abiertos con fecha), 3 movidos tres veces o más (Beatriz 6, Óscar 5, Camilo 3). Sigue declarado rojo, 69 %, contra 5 de 5 hitos cerrados en el cronograma sin ningún acta de recibo.

## Después
`/criterio-project:pm-commitments` para ver el seguimiento completo con lo que entró hoy. `/criterio-project:pm-publish` solo si cambia algún campo de la ficha; hoy el acta no contradice a ninguno. El acta sale aquí y no la escribí en tu carpeta de reuniones: la guardas tú.
