# Corrida del 2026-10-17 · pm-commitments

1 proyectos · 29 s · 21 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_overdue` | 9 |
| `milestone_met_without_evidence` | 5 |
| `commitment_undated` | 3 |
| `commitment_rescheduled` | 3 |
| `progress_vs_plan` | 1 |

Reprogramados: Beatriz Cuéllar (6), Óscar Ramírez (5), Camilo Beltrán (3); 9 vencidos sin evidencia, 3 sin fecha

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17 para criterio-project 0.3.13); no hubo que pedir ni registrar nada de nuevo.

## Compromisos — Tienda en línea (PRY-200) · al 2026-10-17

23 compromisos abiertos de 26 en la ficha (3 cerrados con acta). De los abiertos: 3 reprogramados tres veces o más, 9 vencidos sin evidencia, 3 sin fecha. Todas las cifras salen de `compute` (sin `record_issues`).

### Se viene reprogramando

> **Beatriz Cuéllar** · Enviar el documento 1
> Prometido para el 2026-09-28, y antes para el 10-17, 11-04, 11-11, 11-25, 12-05, y hoy 12-19. **Seis reprogramaciones.** Cada comité la movió; la fecha vigente está a más de dos meses de la primera promesa.
> **Seis veces no es un problema de seguimiento: es un bloqueo que nadie ha nombrado.** Hoy dijo que «no alcanzó», sin decir qué.

> **Óscar Ramírez** · Cerrar la prueba 2
> Prometido para el 2026-09-25, y antes para el 10-12, 10-21, 11-01, 11-09, y vigente 11-22. **Cinco reprogramaciones.**
> Sin resolver: hoy se anotó «revisión con el proveedor, queda para el 10-27». Si es este mismo compromiso, sería la 6.ª reprogramación y la fecha vigente pasaría de 11-22 a 10-27. La nota no lo dice, así que está registrado aparte y no enlazado.

> **Camilo Beltrán** · Revisar el anexo 3
> Prometido para el 2026-09-20, y antes para el 10-02, 10-22, y vigente 11-07. **Tres reprogramaciones.**

### Vencidos sin evidencia
| Quién | Qué | Prometido para | Hace |
|---|---|---|---|
| Natalia Ospina | Aprobar el diseño 5 | 2026-09-30 | 17 días |
| Ricardo Salas | Enviar el documento 9 | 2026-10-05 | 12 días |
| Liliana Torres | Revisar el anexo 19 | 2026-10-09 | 8 días |
| María Restrepo | Validar el ambiente 4 | 2026-10-10 | 7 días |
| Felipe Arango | Aprobar el diseño 13 | 2026-10-10 | 7 días |
| Felipe Arango | Validar el ambiente 20 | 2026-10-12 | 5 días |
| Mauricio Pérez | Confirmar la fecha 23 | 2026-10-13 | 4 días |
| Sandra Gil | Actualizar la matriz 22 | 2026-10-14 | 3 días |
| Ricardo Salas | Entregar el punto 24 | 2026-10-15 | 2 días |

Tres de estos dicen que ya entregaron, y no hay nada en el expediente que lo respalde: **Natalia Ospina** (diseño 5, lo dijo el 10-10), **Ricardo Salas** (documento 9, el 10-03) y **María Restrepo** (ambiente 4, el 09-26). En las tres la tabla del comité los sacó tras esa afirmación, sin acta de recibo. Siguen abiertos hasta que haya un documento.

Natalia Ospina no apareció en la reunión de hoy y nadie mencionó su compromiso.

### Vencen esta semana
| Quién | Qué | Para cuándo |
|---|---|---|
| Camilo Beltrán | Aprobar el diseño 21 | 2026-10-18 |
| Javier Hoyos | Confirmar la fecha 7 (ya reprogramado una vez; era 09-26) | 2026-10-18 |
| María Restrepo | Cerrar la prueba 18 | 2026-10-23 |

### Sin fecha
| Quién | Qué | Dicho el |
|---|---|---|
| Camilo Beltrán | Cerrar la prueba 10 («por definir»; el 09-26 dijo que ya lo entregó, sin acta) | 2026-09-19 |
| Beatriz Cuéllar | Revisar el anexo 11 («por definir»; el 10-03 dijo que ya lo entregó, sin acta) | 2026-09-19 |
| Laura Vélez | Mandar el ajuste del presupuesto («la otra semana», referencia relativa, no se convirtió en fecha) | 2026-10-17 |

No pueden estar vencidos, por eso se cuentan aparte. Los dos primeros llevan 28 días sin fecha.

### Cerrados desde la última revisión
No hay una revisión anterior de este comando; estos son los cerrados con documento que tiene la ficha:
| Quién | Qué | Documento |
|---|---|---|
| Gustavo Neira | Entregar el punto 8 | `20-seguimiento/2026-09-26-acta-recibo-8.md` |
| Ricardo Salas | Validar el ambiente 12 | `20-seguimiento/2026-09-26-acta-recibo-12.md` |
| Mauricio Pérez | Entregar el punto 16 | `20-seguimiento/2026-10-10-acta-recibo-16.md` |

### Contexto
El informe de avance declara el proyecto en rojo y 69 %. En la ficha, los 5 hitos del cronograma figuran cumplidos sin ningún acta de recibo, y ninguna de las señales de compromisos aparece explicada en el informe.

## Después
- **Beatriz Cuéllar (6), Óscar Ramírez (5) y Camilo Beltrán (3)** superan el umbral de tres: puedo formularlos como decisión para el comité (qué se pide, qué pasa si no se decide, quién tiene la facultad) con `/criterio-project:pm-escalate`. La autoridad del proyecto no está nombrada en la ficha (`identity.authority`), así que quién decide hay que completarlo.
- `/criterio-project:pm-publish` solo si quieres que la PMO vea los cambios de la ficha; esta corrida no la modificó.
