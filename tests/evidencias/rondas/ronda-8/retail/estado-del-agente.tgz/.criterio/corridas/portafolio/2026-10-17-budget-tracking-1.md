# Corrida · 2026-10-17-budget-tracking-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:budget-tracking PRY-209

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-209

**Inicio:** 2026-10-17T17:54:39 · **Fin:** 2026-10-17T17:55:19 · **Duración:** 39 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `budget-tracking` | 13 | — | 25 | 73 | Presupuesto PRY-209: comprometido 95,2% sobre umbral 90%, facturado sin entrega en CT-865, declarado verde sin dar cuenta de ello. No hay línea base de costo separada ni evidencia independiente de las cifras. |

Por señal (`budget-tracking`): `milestone_met_without_evidence` 21, `commitment_overdue` 11, `declared_vs_evidence` 7, `progress_vs_plan` 6, `vendor_deliverable_late` 5, `change_without_baseline` 4, `variance_time` 4, `commitment_undated` 3, `commitment_rescheduled` 3, `variance_cost` 3, `rebaseline_unauthorized` 2, `vendor_invoiced_over_accepted` 2, `budget_committed` 1, `vendor_invoiced_without_delivery` 1

## Lo que el agente mostró

Terminé la corrida de presupuesto de PRY-209 (Migración del ERP). El presupuesto está casi comprometido por completo, y el informe del 14 de octubre lo declara en verde sin mencionarlo.

Las cifras salen de `compute` y de la ficha. En ambos casos la fuente es `20-seguimiento/2026-10-14-informe-avance.md`, que es una declaración del gerente y no evidencia independiente. Todo está en COP, sin conversiones.

| | Monto (COP) | % del aprobado |
|---|---|---|
| Aprobado | 2.400.000.000 | 100% |
| Comprometido | 2.283.756.927 | 95,2% |
| Ejecutado | 1.079.166.603 | 45,0% |
| Proyección al cierre | 2.287.155.869 | 4,7% por debajo del aprobado |

- **Disponible real:** COP 116.243.073. El comprometido supera el umbral de 90%.
- **Avance:** ejecutado 45,0%, avance declarado 31,0% y 2 de 5 hitos cumplidos. El plan sustenta entre 40% y 60%.
- **Proveedor Sistemas Comerciales del Norte (CT-865):** tiene facturados COP 148.277.922 sin ningún entregable aceptado. El "Licenciamiento de la plataforma" venció el 3 de septiembre y lleva 44 días tarde, sin evidencia de recibo.
- **Línea base:** solo existe la versión original del 29 de mayo de 2026, sin cambios registrados. No hay una línea base de costo separada, así que no puedo mostrar presupuesto original contra vigente.
- **Sin dato:** autoridad, producto y fase del proyecto, y la aceptación de entregables del proveedor.

No hace falta solicitud de cambio, porque la proyección no excede el aprobado. Puedo preparar el detalle por proveedor, porque el comprometido está sobre el tope.

Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 17 de octubre), así que no registré nada nuevo.

El informe completo quedó en `estado/corridas/salida-budget-tracking.md`, y la corrida quedó registrada con el id `2026-10-17-budget-tracking-1`. El registro de la corrida cuenta los 13 proyectos del portafolio y 73 señales abiertas en total, aunque el informe es solo de PRY-209.
