# Corrida · 2026-10-17-portfolio-report-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-report html

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T18:05:44 · **Fin:** 2026-10-17T18:06:32 · **Duración:** 47 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-report` | 13 | 89 | 28 | 73 | Primera corrida con instantánea de hoy: sin delta. 7 verdes contradichos y 13 proyectos sin autoridad identificada. |

Por señal (`portfolio-report`): `milestone_met_without_evidence` 21, `commitment_overdue` 11, `declared_vs_evidence` 7, `progress_vs_plan` 6, `vendor_deliverable_late` 5, `change_without_baseline` 4, `variance_time` 4, `commitment_undated` 3, `commitment_rescheduled` 3, `variance_cost` 3, `rebaseline_unauthorized` 2, `vendor_invoiced_over_accepted` 2, `budget_committed` 1, `vendor_invoiced_without_delivery` 1

## Lo que el agente mostró

El informe HTML está generado y la corrida quedó registrada como `2026-10-17-portfolio-report-1`. Tardó 28 segundos y leyó 89 documentos, todos sin cambios.

**Términos:** ya estaban vigentes (versión 1.1, familia 0.3.13) y constan a nombre de José Francisco Ñáñez, 2026-10-17. Por eso no registré una aceptación nueva.

**Fichas:** cargué las 13 de `estado/records/` (PRY-199 a PRY-211), todas del barrido de hoy, así que ninguna está vieja.

**Qué cambió:** nada. La única instantánea es la de hoy, así que el diff da 0 cambios y esta corrida es el punto de partida.

**Hallazgos (73 señales, 12 de 13 proyectos):**
- **Verdes contradichos:** 7 proyectos se declaran en verde y la evidencia no lo sostiene. Por ejemplo, PRY-202 lleva 52 días de atraso y 21,8 % de sobrecosto proyectado.
- **Atrasos mayores al 10 %:** PRY-205 (107 días, 51,7 %), PRY-210 (76 días), PRY-211 (75 días) y PRY-202 (52 días).
- **Hitos cumplidos sin evidencia:** 21 señales de este tipo.
- **Compromisos vencidos:** 11, nueve de ellos en PRY-200.
- **Proveedor y presupuesto:** PRY-209 tiene 95,2 % del presupuesto comprometido y facturación sin entrega.
- **Vacíos:** ninguno de los 13 proyectos tiene identificada la autoridad que aprueba cambios. Seis proyectos no están asociados a ningún producto: PRY-202, 203, 206, 209, 210 y 211.
- **Sin hallazgos:** PRY-199 no tiene señales. No hay proyectos en silencio.

**Dónde quedó el informe:** en `/home/claude/banco/ronda-8/retail/espacio/reportes/`, 24 páginas.
- `index.html` es la vista por campo, con la cadena de evidencia completa. Va para quien va a actuar.
- `decisiones.html` es la vista por decisión, con pregunta cerrada y consecuencia de no decidir. Va para el patrocinador y el comité del 2026-10-22.
- El resto son una página por proyecto, una por producto, `productos.html` y `proyectos.html`.
- Para el PDF se imprime el HTML desde el navegador.

**Pendiente:** la confirmación mensual de cinco campos queda sin hacer, porque nadie responde en esta sesión y no inventé las preguntas.

La configuración pide `pptx`, pero usé `html` porque lo indicó el argumento del comando.

La salida de la corrida está en `/home/claude/banco/ronda-8/retail/espacio/estado/corridas/salida-portfolio-report.md`.
