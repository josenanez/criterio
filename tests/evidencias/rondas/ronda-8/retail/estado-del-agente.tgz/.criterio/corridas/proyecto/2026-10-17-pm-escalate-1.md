# Corrida · 2026-10-17-pm-escalate-1

**Agente:** Samuel (proyecto) · **Comando:** `/criterio-project:pm-escalate (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T17:41:13 · **Fin:** 2026-10-17T17:42:16 · **Duración:** 63 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `pm-escalate` | 1 | — | 47 | 21 | Dos paquetes: autoridad del gerente no consta en el acta, y línea base v1 vencida hace 40 días con 69 %. No dije la nueva fecha ni su costo (no constan), ni la fecha límite externa, ni si otros proyectos dependen (impact con 40 días dio 0, sin dependencias declaradas). No empaqueté riesgo de datos personales ni reprogramaciones por falta de causa. |

Por señal (`pm-escalate`): `commitment_overdue` 9, `milestone_met_without_evidence` 5, `commitment_undated` 3, `commitment_rescheduled` 3, `progress_vs_plan` 1

## Lo que el agente mostró

Armé dos paquetes de decisión para PRY-200, pero el segundo queda incompleto porque faltan la nueva fecha de cierre y su costo.

Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17), así que no hubo que registrar nada. Nadie indicó un tema, así que escalé lo que ya estaba marcado como escalable en la agenda y el informe de hoy.

1. **Autoridad del gerente.** El acta no dice qué puede decidir Rubén Cárdenas. La pregunta cerrada es si se declara por escrito. Decide Jorge Medina o el Comité de Transformación Digital; el acta no dice cuál de los dos. Recomiendo agregarla al acta mediante una adenda.
2. **Línea base vencida.** El cierre pactado era el 2026-09-07 y el avance declarado es 69 %. Hoy lleva 40 días vencida y el 2026-10-31, día del comité, serán 54. La pregunta es si se aprueba una línea base v2 o se mantiene la v1 y se sigue reportando el atraso. Recomiendo la v2. Para que el comité pueda decidirla, Rubén debe traer la fecha propuesta y la proyección de costo recalculada.

Lo que no sé y no inventé:
- **Fecha límite externa.** Ningún documento dice si hay una oferta, contrato o ventana de temporada que obligue a decidir antes del 10-31.
- **Otros proyectos.** El cálculo de efecto con esos 40 días dio 0 proyectos y 0 hitos alcanzados, pero no es evidencia de que nadie dependa de este. El acta dice «ninguna dependencia declarada» y el estado solo tiene este proyecto. Tampoco calcula cuántos días se mueve cada proyecto alcanzado, porque la ficha no tiene holgura por actividad.

Dejé fuera el riesgo de datos personales y las reprogramaciones de Beatriz Cuéllar (6), Óscar Ramírez (5) y Camilo Beltrán (3). En ambos casos falta la causa o un doliente. Si la causa es una llamada pendiente, la resuelve Rubén antes del comité. Los riesgos del proveedor primero hay que registrarlos con responsable.

La corrida quedó registrada como `2026-10-17-pm-escalate-1`, en 47 segundos.

Archivo en `/home/claude/banco/ronda-8/retail/espacio/estado/PRY-200-tienda-en-línea/corridas/`:
- `salida-pm-escalate.md`
