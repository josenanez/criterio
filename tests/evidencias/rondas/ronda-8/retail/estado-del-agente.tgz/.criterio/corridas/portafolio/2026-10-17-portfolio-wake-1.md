# Corrida · 2026-10-17-portfolio-wake-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-wake (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T18:06:36 · **Fin:** 2026-10-17T18:07:26 · **Duración:** 50 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-wake` | 13 | — | 36 | 73 | Barrido: 89 documentos sin cambios. 63 citas de PRY-200 sin resolver por falta del prefijo de carpeta (los documentos existen); no reescribí la ficha. Confirmación: 5 campos de PRY-200 preguntados, sin respuesta (sesión sin interfaz). No sé si esos campos siguen vigentes. |

Por señal (`portfolio-wake`): `milestone_met_without_evidence` 21, `commitment_overdue` 11, `declared_vs_evidence` 7, `progress_vs_plan` 6, `vendor_deliverable_late` 5, `change_without_baseline` 4, `variance_time` 4, `commitment_undated` 3, `commitment_rescheduled` 3, `variance_cost` 3, `rebaseline_unauthorized` 2, `vendor_invoiced_over_accepted` 2, `budget_committed` 1, `vendor_invoiced_without_delivery` 1

## Lo que el agente mostró

Hoy tocaron el barrido y la confirmación, y ya quedaron registrados.

**Revisé:** 89 documentos. Ninguno cambió, así que no recalculé ningún proyecto. Los términos ya estaban vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17), por eso no pedí aceptarlos de nuevo.

**Citas rotas en PRY-200 (Tienda en línea):** la ficha de este proyecto tiene 63 citas que el índice no resuelve. Los documentos sí existen. Lo que pasa es que la ficha los cita sin el prefijo de la carpeta del proyecto (`00-gobierno/…` en vez de `PRY-200-tienda-en-línea/00-gobierno/…`), a diferencia de las demás fichas. No reescribí la ficha, porque eso le toca a `/portfolio-scan` y ningún documento cambió. Queda pendiente para el próximo scan de PRY-200.

**Peticiones:** no había ninguna en el servidor.

**Confirmación:** nadie responde en esta sesión, así que quedó como preguntada el 2026-10-17, sin respuesta. Son cinco campos de PRY-200, todos con fuente del 2025-09-02, más viejos que el umbral de 12 meses:
1. Presupuesto aprobado (COP 9.500.000.000).
2. Fecha de fin del plan.
3. Patrocinador.
4. Gerente del proyecto.
5. Comité al que reporta.

La salida completa está en `estado/corridas/salida-portfolio-wake.md`. La corrida dejó `2026-10-17-portfolio-wake-1`: 36 segundos, 13 proyectos y 73 hallazgos abiertos.

**Vuelvo el 2026-10-18.** El informe de comité del 22 de octubre toca el 2026-10-20.
