# Corrida · 2026-10-17-document-index-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:document-index (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T17:51:35 · **Fin:** 2026-10-17T17:52:11 · **Duración:** 37 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `document-index` | 13 | — | 23 | 73 | 89 documentos sin cambios, 0 por releer. 60 campos de PRY-200 marcados como cita rota aunque los archivos existen; causa no determinada, no se corrigió nada. |

Por señal (`document-index`): `milestone_met_without_evidence` 21, `commitment_overdue` 11, `declared_vs_evidence` 7, `progress_vs_plan` 6, `vendor_deliverable_late` 5, `change_without_baseline` 4, `variance_time` 4, `commitment_undated` 3, `commitment_rescheduled` 3, `variance_cost` 3, `rebaseline_unauthorized` 2, `vendor_invoiced_over_accepted` 2, `budget_committed` 1, `vendor_invoiced_without_delivery` 1

## Lo que el agente mostró

## Carpeta al 2026-10-17

**Documentos:** 89 · **Sin cambio:** 89 · **Hay que releer:** 0

Los términos de la versión 0.3.13 ya estaban vigentes y aceptados a nombre de José Francisco Ñáñez el 2026-10-17, así que no los registré de nuevo.

- **Contenido cambiado, solo reguardados, renombrados, borrados:** ninguno.
- **Citas rotas:** el índice marca 60 campos de PRY-200 (tienda en línea) como `source_missing`. Cubren identidad, estado declarado, plan e hitos, dinero, riesgos, incidencia y 26 compromisos. Son los mismos que ya están en la salida guardada.
- **Lo que no sé:** los archivos citados existen en la carpeta de PRY-200. La ficha los cita con la ruta completa y los bytes de la ruta coinciden con los del disco. No determiné por qué el índice dice que faltan. No los traté como borrados y no corregí ninguna cita. Antes de confiar en la ficha de PRY-200 conviene revisar esa causa.
- **Siguiente paso:** no hace falta un barrido de `/portfolio-scan`, porque `projects_to_recompute` está vacío.
- **Formatos ilegibles:** ninguno. Este comando no lee documentos: los cuenta y los compara.

La corrida quedó registrada y tardó 23 segundos. El registro también contiene 73 hallazgos de otras señales, por ejemplo compromisos vencidos e hitos cumplidos sin evidencia. Vienen de las fichas ya existentes. Este comando no los recalculó y no los incluí en el informe.

Archivos en `/home/claude/banco/ronda-8/retail/espacio/estado/corridas/`:
- `salida-document-index.md`
- `2026-10-17-document-index-1.md`
