# Corrida · 2026-10-17-product-wake-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-wake (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T18:09:34 · **Fin:** 2026-10-17T18:10:20 · **Duración:** 46 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-wake` | 15 | — | 32 | 34 | Primera revisión y primer corte: sin corte anterior no hay crossed. 4 propuestos sin decidir (70-152 días), 0 de 11 aceptados trazados, ninguna ficha nombra PRD-309. No sabe: criterio de éxito, medición del volumen mensual; source_missing en 8 campos del índice sin verificar. |

Por señal (`product-wake`): `evidence_stale` 11, `requirement_untraced` 11, `requirement_without_acceptance` 4, `requirement_undecided` 4, `requirement_accepted_without_evidence` 2, `requirement_without_owner` 2

## Lo que el agente mostró

## Tarjeta de la tienda (PRD-309) · 2026-10-17

Hice la revisión del registro. Nunca se había corrido, así que esta corrida fija el primer corte. Sin un corte anterior no puedo decir qué cruzó un umbral desde entonces.

**Estado del registro:** hay 15 requerimientos, 11 aceptados y 4 propuestos. Ninguno de los 11 aceptados tiene un proyecto que lo construya. Ninguna de las 13 fichas de proyecto nombra PRD-309 ni sus requerimientos, así que no había trazas que confirmar.

**Lo que necesita decisión del comité:**
- **Sin decidir:** los 4 propuestos superan el umbral de 60 días.
  - REQ-4909 lleva 152 días sin decidirse y no tiene doliente.
  - REQ-4900 lleva 105 días (Diana Molina).
  - REQ-4904 lleva 77 días (Beatriz Cuéllar).
  - REQ-4908 lleva 70 días (Sandra Gil).
- **Aceptados sin evidencia de demanda:** REQ-4903 y REQ-4911. REQ-4911 tampoco tiene criterio de aceptación.
- **Aceptado sin doliente ni criterio de aceptación:** REQ-4913.

**Evidencia de demanda envejecida:** la única evidencia de demanda es una entrevista del 2025-10-11 y ya cumple 12 meses. Esto afecta a 11 requerimientos.

**Lo que no sé:**
- El criterio de éxito de la definición no está escrito en ningún documento.
- La cifra de volumen mensual del caso de negocio (106.991) no tiene una medición con qué contrastarla.
- El índice de documentos marca 8 campos como `source_missing`, aunque los archivos están en la carpeta. Parece un problema de rutas, pero no lo verifiqué.

**Términos:** ya estaban vigentes, aceptados por José Francisco Ñáñez el 2026-10-17, así que no registré una aceptación nueva.

La corrida quedó registrada (`2026-10-17-product-wake-1`), con el resultado completo en `salida-product-wake.md` y el corte en `snapshots/2026-10-17.json`.

**Vuelvo el 2026-11-16.**
