# Corrida · 2026-10-17-product-requirements-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-requirements (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T17:27:28 · **Fin:** 2026-10-17T17:28:08 · **Duración:** 40 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-requirements` | 15 | — | 24 | 34 | REQ-4903 y REQ-4911 aceptados sin evidencia; 11 aceptados sin proyecto; 4 propuestos sin decidir (70 a 152 días); evidencia única de 2025-10-11 que no nombra ningún REQ |

Por señal (`product-requirements`): `evidence_stale` 11, `requirement_untraced` 11, `requirement_without_acceptance` 4, `requirement_undecided` 4, `requirement_accepted_without_evidence` 2, `requirement_without_owner` 2

## Lo que el agente mostró

## Registro — Tarjeta de la tienda (PRD-309) · al 2026-10-17

El registro tiene 15 requerimientos: 11 aceptados y 4 propuestos. De los 11 decididos, el 81.8% tiene evidencia y ninguno tiene un proyecto que lo ejecute. Los términos ya estaban vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17), así que no los volví a registrar.

**Se va a construir y nadie lo pidió**
- REQ-4903, aceptado el 2026-06-14 (doliente: Beatriz Cuéllar).
- REQ-4911, aceptado el 2026-07-29 (doliente: Carlos Peña).
- Ninguno trae una sola cita de quien lo pidió.

**Decidido y nadie lo construye**
- Los 11 aceptados están sin proyecto.
- El más antiguo es REQ-4913, aceptado el 2026-04-21, hace 169 días.

**Sin doliente**
- REQ-4909 (propuesto) y REQ-4913 (aceptado). Elena Duarte, gerente del producto, tendría que nombrar a la persona.

**Sin criterio de aceptación** (solo cuento los decididos)
- REQ-2028, REQ-4901, REQ-4911 y REQ-4913.

**Decidido sin documento que lo respalde**
- Los 11 aceptados citan el acta del comité del 2026-10-16, pero ninguno dice quién decidió.
- Sus fechas de decisión van del 2026-04-01 al 2026-09-22, anteriores al acta.

**Lleva meses y nadie lo decide** (umbral: 60 días; la facultad es del Comité de producto)
- REQ-4909: 152 días.
- REQ-4900: 105 días.
- REQ-4904: 77 días.
- REQ-4908: 70 días.

**Evidencia vieja**
- 11 requerimientos se apoyan en la misma entrevista del 2025-10-11, de hace 12 meses.
- Esa entrevista no nombra ningún requerimiento. Es la evidencia más cercana, no una prueba, así que el 81.8% pesa menos de lo que parece.

**Por estado:** 4 propuestos, 11 aceptados, y ninguno en construcción, entregado o descartado.

La salida quedó guardada en `estado-producto/PRD-309/corridas/salida-product-requirements.md`. La corrida quedó registrada como `2026-10-17-product-requirements-1`: 34 hallazgos en 24 segundos.

Siguiente paso sugerido: `/product-trace` para los 11 decididos sin proyecto.
