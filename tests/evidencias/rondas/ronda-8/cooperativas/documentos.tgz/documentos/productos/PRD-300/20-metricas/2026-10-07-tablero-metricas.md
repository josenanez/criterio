# Tablero de métricas · Crédito de libranza

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-07

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 75.313 | 2026-10-07 |
