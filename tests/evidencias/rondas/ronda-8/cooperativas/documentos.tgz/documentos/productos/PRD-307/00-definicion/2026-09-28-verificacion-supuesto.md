# Verificación del supuesto · Auxilios de solidaridad

**Fecha:** 2026-09-28

**Supuesto:** Los asociados usan el canal digital

**Con qué se verificó:** el concepto jurídico de cumplimiento del 2026-09-28

**Resultado:** se confirmó.
