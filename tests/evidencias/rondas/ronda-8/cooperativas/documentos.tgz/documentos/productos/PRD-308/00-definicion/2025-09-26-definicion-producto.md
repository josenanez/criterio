# Definición de producto · Remesas familiares

**Código:** PRD-308
**Gerente de producto:** Natalia Ospina
**Segmento:** Asociados urbanos
**Fecha de la definición:** 2025-09-26

## El problema

El segmento Asociados urbanos no tiene remesas familiares.

## La propuesta

- Propuesta principal

## Supuestos

- **El proveedor cumple el tiempo pactado** · declarado el 2026-09-10 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
