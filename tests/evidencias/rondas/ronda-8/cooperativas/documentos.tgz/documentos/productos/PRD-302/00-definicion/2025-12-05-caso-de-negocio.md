# Caso de negocio · Aportes sociales

**Código:** PRD-302
**Fecha:** 2025-12-05
**Preparado por:** María Restrepo

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 207.060 | Caso de negocio, 2025-12-05 |

## Retorno esperado

Retorno esperado en 24 meses.
