# Caso de negocio · Auxilios de solidaridad

**Código:** PRD-307
**Fecha:** 2026-04-18
**Preparado por:** Diana Molina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 177.205 | Caso de negocio, 2026-04-18 |

## Retorno esperado

Retorno esperado en 24 meses.
