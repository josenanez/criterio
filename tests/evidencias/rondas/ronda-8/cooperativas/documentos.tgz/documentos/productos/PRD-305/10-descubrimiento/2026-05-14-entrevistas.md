# Entrevistas · Microcrédito

**Ronda:** Ronda · 2026-05-14
**Realizadas por:** Diana Molina

### Cliente entrevistado · 2026-05-14

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
