# Definición de producto · Aportes sociales

**Código:** PRD-302
**Gerente de producto:** María Restrepo
**Segmento:** Asociados urbanos
**Fecha de la definición:** 2025-12-05

## El problema

El segmento Asociados urbanos no tiene aportes sociales.

## La propuesta

- Propuesta principal

## Supuestos

- **Los asociados usan el canal digital** · declarado el 2026-06-26 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
