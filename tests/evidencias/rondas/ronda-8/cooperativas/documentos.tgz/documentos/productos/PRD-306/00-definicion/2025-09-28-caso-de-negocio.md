# Caso de negocio · Recaudos

**Código:** PRD-306
**Fecha:** 2025-09-28
**Preparado por:** Gustavo Neira

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 196.775 | Caso de negocio, 2025-09-28 |

## Retorno esperado

Retorno esperado en 24 meses.
