# Verificación del supuesto · Microseguros

**Fecha:** 2026-05-28

**Supuesto:** Los asociados usan el canal digital

**Con qué se verificó:** la entrevista con doce clientes del segmento del 2026-05-28

**Resultado:** se confirmó.
