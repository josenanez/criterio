# Caso de negocio · Microcrédito

**Código:** PRD-305
**Fecha:** 2025-11-10
**Preparado por:** Diana Molina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 119.236 | Caso de negocio, 2025-11-10 |

## Retorno esperado

Retorno esperado en 24 meses.
