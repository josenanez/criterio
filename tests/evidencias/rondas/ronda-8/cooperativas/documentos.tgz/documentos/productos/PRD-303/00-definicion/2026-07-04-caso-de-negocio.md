# Caso de negocio · Tarjeta débito

**Código:** PRD-303
**Fecha:** 2026-07-04
**Preparado por:** Beatriz Cuéllar

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 226.477 | Caso de negocio, 2026-07-04 |

## Retorno esperado

Retorno esperado en 24 meses.
