# Tablero de métricas · Auxilios de solidaridad

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-10

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 176.292 | 2026-10-10 |
