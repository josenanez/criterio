# Definición de producto · Pagos QR

**Código:** PRD-304
**Gerente de producto:** Felipe Arango
**Segmento:** Jóvenes
**Fecha de la definición:** 2025-11-15

## El problema

El segmento Jóvenes no tiene pagos qr.

## La propuesta

- Propuesta principal

## Supuestos

- **El proveedor cumple el tiempo pactado** · declarado el 2026-03-30 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
