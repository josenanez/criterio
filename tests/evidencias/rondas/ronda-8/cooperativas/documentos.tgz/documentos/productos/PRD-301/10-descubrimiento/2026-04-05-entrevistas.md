# Entrevistas · Ahorro a la vista

**Ronda:** Ronda · 2026-04-05
**Realizadas por:** Diana Molina

### Cliente entrevistado · 2026-04-05

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
