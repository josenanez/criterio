# Caso de negocio · Remesas familiares

**Código:** PRD-308
**Fecha:** 2025-09-26
**Preparado por:** Natalia Ospina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 174.609 | Caso de negocio, 2025-09-26 |

## Retorno esperado

Retorno esperado en 24 meses.
