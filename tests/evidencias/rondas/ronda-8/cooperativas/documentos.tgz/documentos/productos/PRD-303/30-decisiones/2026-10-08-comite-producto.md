# Comité de producto · Tarjeta débito

**Fecha:** 2026-10-08
**Asistentes:** Beatriz Cuéllar

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4300 | Requerimiento REQ-4300 | Óscar Ramírez | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-13 | — |
| REQ-4301 | Requerimiento REQ-4301 | Liliana Torres | se verifica en producción | — | aceptado | 2026-05-11 | — |
| REQ-4302 | Requerimiento REQ-4302 | Gustavo Neira | se verifica en producción | — | aceptado | 2026-05-18 | — |
| REQ-4303 | Requerimiento REQ-4303 | Liliana Torres | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-24 | — |
| REQ-4304 | Requerimiento REQ-4304 | Ricardo Salas | — | Cliente entrevistado | aceptado | 2026-08-31 | — |
| REQ-4305 | Requerimiento REQ-4305 | Javier Hoyos | — | — | aceptado | 2026-04-03 | — |
| REQ-4306 | Requerimiento REQ-4306 | Javier Hoyos | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-24 | — |
| REQ-4307 | Requerimiento REQ-4307 | Gustavo Neira | se verifica en producción | — | propuesto | 2026-05-09 | — |
| REQ-4308 | Requerimiento REQ-4308 | María Restrepo | se verifica en producción | — | propuesto | 2026-06-05 | — |
| REQ-4309 | Requerimiento REQ-4309 | Mauricio Pérez | se verifica en producción | — | aceptado | 2026-04-24 | — |
| REQ-4310 | Requerimiento REQ-4310 | Beatriz Cuéllar | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-15 | — |
| REQ-4311 | Requerimiento REQ-4311 | Mauricio Pérez | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-11 | — |

## Decisiones

- Se mantiene el plan
