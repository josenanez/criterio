# Definición de producto · Microseguros

**Código:** PRD-309
**Gerente de producto:** Mauricio Pérez
**Segmento:** Asociados urbanos
**Fecha de la definición:** 2026-04-01

## El problema

El segmento Asociados urbanos no tiene microseguros.

## La propuesta

- Propuesta principal

## Supuestos

- **Los asociados usan el canal digital** · declarado el 2026-03-23 · verificado con la entrevista con doce clientes del segmento del 2026-05-28 (anexo «Verificación del supuesto» del 2026-05-28)

## Proyectos que lo construyen

- Ninguno declarado
