# Entrevistas · Aportes sociales

**Ronda:** Ronda · 2026-05-26
**Realizadas por:** María Restrepo

### Cliente entrevistado · 2026-05-26

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
