# Comité de producto · Microseguros

**Fecha:** 2026-10-12
**Asistentes:** Mauricio Pérez

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4900 | Requerimiento REQ-4900 | Ricardo Salas | se verifica en producción | — | propuesto | 2026-08-04 | — |
| REQ-4901 | Requerimiento REQ-4901 | Beatriz Cuéllar | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-15 | — |
| REQ-4902 | Requerimiento REQ-4902 | Sandra Gil | — | Cliente entrevistado | aceptado | 2026-03-19 | — |
| REQ-4903 | Requerimiento REQ-4903 | Mauricio Pérez | — | Cliente entrevistado | aceptado | 2026-06-13 | — |
| REQ-4904 | Requerimiento REQ-4904 | Beatriz Cuéllar | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-10 | — |
| REQ-4905 | Requerimiento REQ-4905 | Mauricio Pérez | se verifica en producción | — | aceptado | 2026-04-30 | — |
| REQ-4906 | Requerimiento REQ-4906 | Rubén Cárdenas | se verifica en producción | — | aceptado | 2026-03-31 | — |
| REQ-4907 | Requerimiento REQ-4907 | Natalia Ospina | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-20 | — |
| REQ-4908 | Requerimiento REQ-4908 | Gustavo Neira | se verifica en producción | — | aceptado | 2026-06-13 | — |
| REQ-4909 | Requerimiento REQ-4909 | Andrés Lozano | — | Cliente entrevistado | aceptado | 2026-08-12 | — |
| REQ-4910 | Requerimiento REQ-4910 | Natalia Ospina | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-14 | — |
| REQ-4911 | Requerimiento REQ-4911 | María Restrepo | se verifica en producción | — | aceptado | 2026-08-18 | — |
| REQ-4912 | Requerimiento REQ-4912 | Paula Céspedes | — | — | aceptado | 2026-04-12 | — |
| REQ-4913 | Requerimiento REQ-4913 | Natalia Ospina | se verifica en producción | — | aceptado | 2026-09-02 | — |
| REQ-2035 | Requerimiento REQ-2035 | Diana Molina | se verifica en producción | Cliente entrevistado | aceptado | 2026-10-12 | — |

## Decisiones

- Se mantiene el plan
