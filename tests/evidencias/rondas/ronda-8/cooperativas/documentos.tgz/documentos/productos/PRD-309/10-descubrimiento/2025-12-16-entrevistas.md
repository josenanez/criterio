# Entrevistas · Microseguros

**Ronda:** Ronda · 2025-12-16
**Realizadas por:** Mauricio Pérez

### Cliente entrevistado · 2025-12-16

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
