# Caso de negocio · Microseguros

**Código:** PRD-309
**Fecha:** 2026-04-01
**Preparado por:** Mauricio Pérez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 299.344 | Caso de negocio, 2026-04-01 |

## Retorno esperado

Retorno esperado en 24 meses.
