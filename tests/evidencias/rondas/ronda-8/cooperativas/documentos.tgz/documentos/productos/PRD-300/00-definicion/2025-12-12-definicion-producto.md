# Definición de producto · Crédito de libranza

**Código:** PRD-300
**Gerente de producto:** Javier Hoyos
**Segmento:** Asociados rurales
**Fecha de la definición:** 2025-12-12

## El problema

El segmento Asociados rurales no tiene crédito de libranza.

## La propuesta

- Propuesta principal

## Supuestos

- **El proveedor cumple el tiempo pactado** · declarado el 2026-04-10 · verificado con la medición del piloto del 2026-06-25 (anexo «Verificación del supuesto» del 2026-06-25)

## Proyectos que lo construyen

- Ninguno declarado
