# Comité de producto · Crédito de libranza

**Fecha:** 2026-10-12
**Asistentes:** Javier Hoyos

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4000 | Requerimiento REQ-4000 | Mauricio Pérez | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-13 | — |
| REQ-4001 | Requerimiento REQ-4001 | Diana Molina | se verifica en producción | — | propuesto | 2026-08-25 | — |
| REQ-4002 | Requerimiento REQ-4002 | Mauricio Pérez | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-21 | — |
| REQ-4003 | Requerimiento REQ-4003 | María Restrepo | se verifica en producción | — | aceptado | 2026-08-10 | — |
| REQ-4004 | Requerimiento REQ-4004 | Javier Hoyos | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-13 | — |
| REQ-4005 | Requerimiento REQ-4005 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-29 | — |
| REQ-4006 | Requerimiento REQ-4006 | Óscar Ramírez | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-21 | — |
| REQ-4007 | Requerimiento REQ-4007 | Sandra Gil | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-09 | — |
| REQ-4008 | Requerimiento REQ-4008 | Carlos Peña | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-11 | — |
| REQ-4009 | Requerimiento REQ-4009 | Beatriz Cuéllar | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-03 | — |
| REQ-4010 | Requerimiento REQ-4010 | Gustavo Neira | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-13 | — |
| REQ-4011 | Requerimiento REQ-4011 | María Restrepo | — | Cliente entrevistado | aceptado | 2026-03-27 | — |
| REQ-4012 | Requerimiento REQ-4012 | Diana Molina | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-26 | — |
| REQ-4013 | Requerimiento REQ-4013 | Camilo Beltrán | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-02 | — |
| REQ-4014 | Requerimiento REQ-4014 | Andrés Lozano | se verifica en producción | Cliente entrevistado | propuesto | 2026-06-06 | — |
| REQ-4015 | Requerimiento REQ-4015 | Elena Duarte | se verifica en producción | — | aceptado | 2026-06-29 | — |

## Decisiones

- Se mantiene el plan
