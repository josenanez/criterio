# Definición de producto · Microcrédito

**Código:** PRD-305
**Gerente de producto:** Diana Molina
**Segmento:** Microempresarios
**Fecha de la definición:** 2025-11-10

## El problema

El segmento Microempresarios no tiene microcrédito.

## La propuesta

- Propuesta principal

## Supuestos

- **El proveedor cumple el tiempo pactado** · declarado el 2026-08-02 · verificado con la entrevista con doce clientes del segmento del 2026-08-30 (anexo «Verificación del supuesto» del 2026-08-30)

## Proyectos que lo construyen

- Ninguno declarado
