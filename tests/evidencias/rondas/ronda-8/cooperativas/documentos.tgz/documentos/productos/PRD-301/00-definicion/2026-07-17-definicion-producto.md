# Definición de producto · Ahorro a la vista

**Código:** PRD-301
**Gerente de producto:** Diana Molina
**Segmento:** Jóvenes
**Fecha de la definición:** 2026-07-17

## El problema

El segmento Jóvenes no tiene ahorro a la vista.

## La propuesta

- Propuesta principal

## Supuestos

- **El core soporta el volumen** · declarado el 2026-06-02 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
