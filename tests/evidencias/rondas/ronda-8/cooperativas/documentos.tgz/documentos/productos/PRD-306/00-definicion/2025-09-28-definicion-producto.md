# Definición de producto · Recaudos

**Código:** PRD-306
**Gerente de producto:** Gustavo Neira
**Segmento:** Asociados urbanos
**Fecha de la definición:** 2025-09-28

## El problema

El segmento Asociados urbanos no tiene recaudos.

## La propuesta

- Propuesta principal

## Supuestos

- **El reglamento vigente lo permite** · declarado el 2026-05-16 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
