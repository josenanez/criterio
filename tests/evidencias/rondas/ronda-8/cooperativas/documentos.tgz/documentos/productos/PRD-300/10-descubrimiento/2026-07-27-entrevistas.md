# Entrevistas · Crédito de libranza

**Ronda:** Ronda · 2026-07-27
**Realizadas por:** Javier Hoyos

### Cliente entrevistado · 2026-07-27

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
