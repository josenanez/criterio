# Comité de producto · Pagos QR

**Fecha:** 2026-10-07
**Asistentes:** Felipe Arango

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4400 | Requerimiento REQ-4400 | Gustavo Neira | — | Cliente entrevistado | aceptado | 2026-05-26 | — |
| REQ-4401 | Requerimiento REQ-4401 | Laura Vélez | — | Cliente entrevistado | aceptado | 2026-03-26 | — |
| REQ-4402 | Requerimiento REQ-4402 | Natalia Ospina | — | Cliente entrevistado | aceptado | 2026-03-24 | — |
| REQ-4403 | Requerimiento REQ-4403 | Sandra Gil | — | Cliente entrevistado | aceptado | 2026-07-10 | — |
| REQ-4404 | Requerimiento REQ-4404 | Andrés Lozano | se verifica en producción | Cliente entrevistado | propuesto | 2026-09-01 | — |
| REQ-4405 | Requerimiento REQ-4405 | Sandra Gil | — | Cliente entrevistado | aceptado | 2026-05-27 | — |
| REQ-4406 | Requerimiento REQ-4406 | Felipe Arango | — | Cliente entrevistado | aceptado | 2026-04-28 | — |
| REQ-4407 | Requerimiento REQ-4407 | sin asignar | se verifica en producción | Cliente entrevistado | propuesto | 2026-05-16 | — |
| REQ-4408 | Requerimiento REQ-4408 | Ricardo Salas | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-15 | — |
| REQ-4409 | Requerimiento REQ-4409 | Óscar Ramírez | se verifica en producción | — | aceptado | 2026-07-06 | — |
| REQ-4410 | Requerimiento REQ-4410 | Paula Céspedes | se verifica en producción | — | aceptado | 2026-07-11 | — |
| REQ-4411 | Requerimiento REQ-4411 | Liliana Torres | se verifica en producción | Cliente entrevistado | propuesto | 2026-06-23 | — |
| REQ-4412 | Requerimiento REQ-4412 | Beatriz Cuéllar | se verifica en producción | Cliente entrevistado | propuesto | 2026-05-28 | — |
| REQ-4413 | Requerimiento REQ-4413 | Felipe Arango | se verifica en producción | — | propuesto | 2026-07-30 | — |

## Decisiones

- Se mantiene el plan
