# Consejo de Administración · Crédito de libranza digital

**Fecha:** 2026-09-26
**Asistentes:** Carlos Peña, Elena Duarte, Felipe Arango, Gustavo Neira, Jorge Medina, María Restrepo, Paula Céspedes, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Felipe Arango | Enviar el documento 1 | 2026-10-24 |
| Óscar Ramírez | Cerrar la prueba 2 | 2026-11-10 |
| Elena Duarte | Revisar el anexo 3 | 2026-10-22 |
| Carlos Peña | Actualizar la matriz 6 | 2026-10-20 |
| Óscar Ramírez | Confirmar la fecha 7 | 2026-10-05 |
| Felipe Arango | Cerrar la prueba 10 | 2026-10-04 |
| María Restrepo | Revisar el anexo 11 | 2026-10-20 |
| Paula Céspedes | Aprobar el diseño 13 | por definir |
| Gustavo Neira | Actualizar la matriz 14 | 2026-10-14 |
| Gustavo Neira | Confirmar la fecha 15 | 2026-10-10 |
| Elena Duarte | Entregar el punto 16 | 2026-10-09 |

## Cerrados en esta reunión

- Entregar el punto 8 (Laura Vélez): recibido, acta de recibo del 2026-09-26.

## Lo que se dijo

- Sandra Gil dice que ya entregó «aprobar el diseño 5». No se presentó acta.
- Elena Duarte dice que ya entregó «enviar el documento 9». No se presentó acta.
- Gustavo Neira dice que ya entregó «validar el ambiente 12». No se presentó acta.
