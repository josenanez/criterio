# Comité de Crédito · Corresponsales rurales

**Fecha:** 2026-10-06
**Asistentes:** Óscar Ramírez, Diana Molina

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Sandra Gil | Entregar el punto 40 | por definir |
