# Informe de avance · Prevención de lavado de activos

**Código:** PRY-205
**Fecha de corte:** 2026-10-14
**Gerente:** Camilo Beltrán

## Estado declarado

**Verde**

Avance reportado: **48%**

## Lo que pasó en el periodo

- Se reprogramó la salida por el cierre contable de fin de mes

## Presupuesto

| | COP |
|---|---|
| Aprobado | 4.200.000.000 |
| Comprometido | 1.378.457.363 |
| Ejecutado | 1.937.776.494 |
| Proyección al cierre | 5.188.200.936 |

## Riesgos abiertos

- Aprobación del reglamento por el Consejo de Administración
