# Informe de avance · Aportes sociales en línea

**Código:** PRY-203
**Fecha de corte:** 2026-10-14
**Gerente:** Gustavo Neira

## Estado declarado

**Verde**

Avance reportado: **35%**

## Lo que pasó en el periodo

- La prueba de carga no alcanzó el umbral pactado y se repite
- Se levantó un hallazgo de seguridad en la revisión de arquitectura

## Presupuesto

| | COP |
|---|---|
| Aprobado | 18.000.000.000 |
| Comprometido | 12.718.235.403 |
| Ejecutado | 8.771.337.338 |
| Proyección al cierre | 16.832.732.205 |

## Riesgos abiertos

- Cambio normativo del supervisor que puede mover el alcance
- Concentración del conocimiento en una sola persona
