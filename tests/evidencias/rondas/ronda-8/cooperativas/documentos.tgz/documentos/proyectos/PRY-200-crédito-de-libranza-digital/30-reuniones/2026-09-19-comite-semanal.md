# Consejo de Administración · Crédito de libranza digital

**Fecha:** 2026-09-19
**Asistentes:** Carlos Peña, Elena Duarte, Felipe Arango, Gustavo Neira, Jorge Medina, Laura Vélez, María Restrepo, Sandra Gil, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Felipe Arango | Enviar el documento 1 | 2026-10-11 |
| Óscar Ramírez | Cerrar la prueba 2 | 2026-10-21 |
| Elena Duarte | Revisar el anexo 3 | 2026-10-22 |
| Sandra Gil | Aprobar el diseño 5 | por definir |
| Carlos Peña | Actualizar la matriz 6 | 2026-10-20 |
| Óscar Ramírez | Confirmar la fecha 7 | 2026-10-05 |
| Laura Vélez | Entregar el punto 8 | 2026-10-12 |
| Elena Duarte | Enviar el documento 9 | 2026-09-25 |
| Felipe Arango | Cerrar la prueba 10 | 2026-10-04 |
| María Restrepo | Revisar el anexo 11 | 2026-10-10 |
| Gustavo Neira | Validar el ambiente 12 | por definir |
