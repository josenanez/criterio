# Solicitud de cambio CC-01

**Proyecto:** PRY-208 · Motor de crédito
**Fecha:** 2026-10-14
**Solicitante:** Laura Vélez

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +117 días sobre la línea base vigente |
| Costo | 234.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
