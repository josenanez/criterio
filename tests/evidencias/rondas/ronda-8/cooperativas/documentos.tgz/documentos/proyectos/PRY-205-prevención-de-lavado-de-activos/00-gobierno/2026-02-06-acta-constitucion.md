# Acta de constitución · Prevención de lavado de activos

**Código:** PRY-205
**Área dueña:** Tesorería
**Patrocinador:** María Restrepo
**Gerente de proyecto:** Camilo Beltrán
**Comité:** Consejo de Administración
**Producto asociado:** No aplica
**Fecha de aprobación:** 2026-02-06

## Objetivo del negocio

Entregar prevención de lavado de activos para Tesorería.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**4.200.000.000 COP**, aprobado por Consejo de Administración el 2026-02-06.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-02-16 |
| Cierre | 2026-09-21 |

## Criterio de éxito

Prevención de lavado de activos en producción y medido.

## Dependencias declaradas

- Ninguna declarada
