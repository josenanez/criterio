# Consejo de Administración · Pagos con QR

**Fecha:** 2026-10-16
**Asistentes:** Felipe Arango, Beatriz Cuéllar

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Jorge Medina | Entregar el punto 14 | 2026-10-10 |
