# Consejo de Administración · Core cooperativo

**Fecha:** 2026-10-17
**Asistentes:** Natalia Ospina, Andrés Lozano

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Natalia Ospina | Entregar el punto 25 | 2026-09-23 |
| Camilo Beltrán | Entregar el punto 16 | 2026-10-15 |
