# Solicitud de cambio CC-01

**Proyecto:** PRY-203 · Aportes sociales en línea
**Fecha:** 2026-10-14
**Solicitante:** Gustavo Neira

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +112 días sobre la línea base vigente |
| Costo | 224.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
