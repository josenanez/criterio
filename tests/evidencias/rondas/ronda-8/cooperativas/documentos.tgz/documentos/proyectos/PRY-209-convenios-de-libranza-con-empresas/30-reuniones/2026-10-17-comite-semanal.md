# Comité de Crédito · Convenios de libranza con empresas

**Fecha:** 2026-10-17
**Asistentes:** Felipe Arango, Mauricio Pérez

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Javier Hoyos | Entregar el punto 35 | 2026-10-10 |
