# Informe de avance · Crédito de libranza digital

**Código:** PRY-200
**Fecha de corte:** 2026-10-07
**Gerente:** Jorge Medina

## Estado declarado

**Verde**

Avance reportado: **48%**

## Lo que pasó en el periodo

- La prueba de carga no alcanzó el umbral pactado y se repite
- El equipo perdió dos semanas por rotación de un desarrollador clave
- Se reprogramó la salida por el cierre contable de fin de mes

## Presupuesto

| | COP |
|---|---|
| Aprobado | 4.200.000.000 |
| Comprometido | 3.390.376.801 |
| Ejecutado | 1.405.474.333 |
| Proyección al cierre | 4.010.066.854 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
