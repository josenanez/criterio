# Comité de Riesgos · Cobranza digital

**Fecha:** 2026-10-15
**Asistentes:** Camilo Beltrán, Liliana Torres

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Rubén Cárdenas | Entregar el punto 2 | 2026-09-28 |
