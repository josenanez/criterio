# Acta de constitución · Core cooperativo

**Código:** PRY-202
**Área dueña:** Canales digitales
**Patrocinador:** Andrés Lozano
**Gerente de proyecto:** Natalia Ospina
**Comité:** Consejo de Administración
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-08-20

## Objetivo del negocio

Entregar core cooperativo para Canales digitales.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**3.300.000.000 COP**, aprobado por Consejo de Administración el 2025-08-20.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-08-30 |
| Cierre | 2026-05-16 |

## Criterio de éxito

Core cooperativo en producción y medido.

## Dependencias declaradas

- Ninguna declarada
