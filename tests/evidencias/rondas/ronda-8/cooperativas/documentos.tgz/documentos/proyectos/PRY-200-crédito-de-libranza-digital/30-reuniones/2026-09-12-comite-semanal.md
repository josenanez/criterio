# Consejo de Administración · Crédito de libranza digital

**Fecha:** 2026-09-12
**Asistentes:** Carlos Peña, Elena Duarte, Felipe Arango, Jorge Medina, Laura Vélez, Sandra Gil, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Felipe Arango | Enviar el documento 1 | 2026-09-22 |
| Óscar Ramírez | Cerrar la prueba 2 | 2026-10-03 |
| Elena Duarte | Revisar el anexo 3 | 2026-10-05 |
| Sandra Gil | Aprobar el diseño 5 | por definir |
| Carlos Peña | Actualizar la matriz 6 | 2026-10-08 |
| Óscar Ramírez | Confirmar la fecha 7 | 2026-10-05 |
| Laura Vélez | Entregar el punto 8 | 2026-09-30 |

## Cerrados en esta reunión

- Validar el ambiente 4 (María Restrepo): recibido, acta de recibo del 2026-09-12.
