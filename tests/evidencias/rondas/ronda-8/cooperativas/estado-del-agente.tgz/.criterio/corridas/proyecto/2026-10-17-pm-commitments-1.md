# Corrida · 2026-10-17-pm-commitments-1

**Agente:** Samuel (proyecto) · **Comando:** `/criterio-project:pm-commitments (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T16:52:26 · **Fin:** 2026-10-17T16:53:12 · **Duración:** 45 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `pm-commitments` | 1 | — | 29 | 20 | Reprogramado 3+ veces: Felipe Arango (6), Óscar Ramírez (5), Elena Duarte (4); 5 vencidos sin evidencia; 3 sin fecha |

Por señal (`pm-commitments`): `commitment_overdue` 5, `milestone_met_without_evidence` 4, `commitment_undated` 3, `commitment_rescheduled` 3, `vendor_deliverable_late` 3, `progress_vs_plan` 1, `declared_vs_evidence` 1

## Lo que el agente mostró

## Compromisos — Crédito de libranza digital (PRY-200) · al 2026-10-17

La ficha tiene 26 compromisos. Hay 18 abiertos, 5 vencidos sin evidencia y 3 cerrados con documento. De los 18 abiertos, 3 no tienen fecha. Las cifras salen de `compute`, que no trajo `record_issues`. Los términos ya estaban vigentes y aceptados por José Francisco Ñáñez el 2026-10-17, así que no hubo que registrar nada.

### Se viene reprogramando
- **Felipe Arango, enviar el documento 1:** 6 reprogramaciones. Prometió el 09-12 y hoy está para el 11-24. Es un bloqueo que nadie ha nombrado.
- **Óscar Ramírez, cerrar la prueba 2:** 5 reprogramaciones. Prometió el 09-26 y hoy está para el 12-01.
- **Elena Duarte, revisar el anexo 3:** 4 reprogramaciones. Prometió el 09-28 y hoy está para el 11-17.
- **Cerca del umbral de 3:** con 2 reprogramaciones cada uno están Carlos Peña (matriz 6), Óscar Ramírez (fecha 7), María Restrepo (anexo 11) y Gustavo Neira (fecha 15). Todavía no son hallazgo.

### Vencidos sin evidencia
| Quién | Qué | Hace |
|---|---|---|
| Elena Duarte | Enviar el documento 9 | 22 días |
| Felipe Arango | Cerrar la prueba 10 | 13 días |
| Rubén Cárdenas | Cerrar la prueba 18 | 6 días |
| Gustavo Neira | Actualizar la matriz 14 | 3 días |
| Óscar Ramírez | Confirmar la fecha 23 | 2 días |

Elena Duarte, Felipe Arango y Rubén Cárdenas dijeron en comité que ya habían entregado, pero no hay acta que lo respalde. Siguen abiertos.

### Vencen esta semana
Solo Diana Molina, revisar el anexo 19, para el 10-20.

### Sin fecha
- Sandra Gil, aprobar el diseño 5.
- Gustavo Neira, validar el ambiente 12.
- Laura Vélez, mandar el ajuste del presupuesto, que dijo «la otra semana».

Sandra Gil y Gustavo Neira dijeron el 09-26 que ya habían entregado, sin acta. Estos tres no pueden figurar como vencidos, por eso se cuentan aparte.

### Cerrados con documento
- María Restrepo, ambiente 4, cerrado con `acta-recibo-4`.
- Laura Vélez, punto 8, cerrado con `acta-recibo-8`.
- Paula Céspedes, diseño 13, cerrado con `acta-recibo-13`.

### Después
- Ofrezco formular el compromiso de Felipe Arango (documento 1) como decisión para el comité. Excede la autoridad del gerente.
- La ficha dice «verde» (informe del 10-07) y estos compromisos la contradicen. `/pm-publish` deja que la PMO lo vea.

La salida completa quedó en `estado/PRY-200-crédito-de-libranza-digital/corridas/salida-pm-commitments.md`. La corrida quedó registrada como `2026-10-17-pm-commitments-1`: 20 hallazgos en 29 segundos.
