# Corrida · 2026-10-17-product-requirements-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-requirements (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T16:44:10 · **Fin:** 2026-10-17T16:44:46 · **Duración:** 36 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-requirements` | 17 | — | 21 | 43 | 5 aceptados sin evidencia, 7 sin criterio de aceptación, 16 sin proyecto, 11 con evidencia vieja, 2 sin doliente, 1 propuesto sin decidir hace 124 días |

Por señal (`product-requirements`): `requirement_untraced` 16, `evidence_stale` 11, `requirement_without_acceptance` 7, `requirement_accepted_without_evidence` 5, `requirement_without_owner` 2, `requirement_undecided` 1, `assumption_unverified` 1

## Lo que el agente mostró

## Registro — Recaudos (PRD-306) · al 2026-10-17
17 requerimientos · 16 decididos · 68,8 % con evidencia · 0 % con proyecto que lo ejecute.

Los términos v1.1 ya estaban vigentes y aceptados por José Francisco Ñáñez el 2026-10-17, así que no los registré de nuevo.

**Se va a construir y nadie lo pidió (5).** Están aceptados y no tienen ninguna cita de quien los pidió.
- REQ-2030 (Beatriz Cuéllar)
- REQ-4600 (Gustavo Neira)
- REQ-4605 (Carlos Peña)
- REQ-4607 (Beatriz Cuéllar)
- REQ-4613 (Elena Duarte)

**Decidido y nadie lo construye (16 de 16).** Ningún aceptado tiene proyecto. Ofrezco `/product-trace` para recorrer esa cadena.

**Sin doliente (2).**
- REQ-4611 (aceptado)
- REQ-4614 (propuesto)

Los cierra Gustavo Neira nombrando a una persona.

**Sin criterio de aceptación (7).** Solo cuento los decididos: REQ-2030, 4606, 4607, 4608, 4609, 4610 y 4612. Cada doliente cierra el suyo.

**Decidido sin documento que respalde la decisión.** No lo pude comprobar, porque el cálculo no produce esa señal. No afirmo ninguno y queda para revisar a mano contra las actas.

**Lleva meses y nadie lo decide (1).** REQ-4614 está propuesto hace 124 días, y el umbral es 60. Quien tiene la facultad de decidirlo es el Comité de producto. Propongo llevarlo al próximo comité mensual para aceptarlo o descartarlo.

**Evidencia vieja (11).** Todos los requerimientos con evidencia se apoyan en la misma entrevista del 2025-09-27, que ya está en el umbral de 12 meses. Esa entrevista no nombra ninguno de ellos, así que además de vieja es evidencia débil.

**De la definición del producto.**
- El supuesto «El reglamento vigente lo permite» lleva 154 días sin verificar (umbral 30).
- El volumen mensual declarado es 196.775 y el medido es 175.099. La brecha es del 11 %, bajo el umbral del 20 %.
- El retorno a 24 meses no tiene cifra.
- El criterio de éxito de la definición no está dicho.

**Por estado.** 1 propuesto y 16 aceptados. No hay requerimientos en construcción, entregados ni descartados.

La corrida quedó registrada como `2026-10-17-product-requirements-1`, con 43 hallazgos y 21 segundos. El texto completo está en `estado-producto/PRD-306/corridas/salida-product-requirements.md`.
