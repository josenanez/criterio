# Corrida · 2026-10-17-document-index-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:document-index (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T17:05:19 · **Fin:** 2026-10-17T17:05:49 · **Duración:** 30 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `document-index` | 13 | — | 15 | 69 | 76 documentos sin cambio, 0 por releer. 37 citas de PRY-200 marcadas source_missing aunque los archivos existen; probable fallo de resolución de rutas relativas, sin confirmar. No se corrigió ninguna ficha. |

Por señal (`document-index`): `milestone_met_without_evidence` 25, `commitment_overdue` 10, `progress_vs_plan` 7, `vendor_deliverable_late` 5, `commitment_undated` 4, `declared_vs_evidence` 4, `milestone_overdue` 4, `commitment_rescheduled` 3, `change_without_baseline` 2, `silent` 1, `variance_cost` 1, `budget_committed` 1, `variance_time` 1, `vendor_invoiced_without_delivery` 1

## Lo que el agente mostró

## Carpeta al 2026-10-17

**Documentos:** 76 · **Sin cambio:** 76 · **Hay que releer:** 0

No hay documentos nuevos, cambiados, reguardados, renombrados ni borrados. El único hallazgo son 37 citas de PRY-200 que el índice marca como "ya no resuelven".

Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17), así que no los registré otra vez.

### Citas que dejaron de resolver
Las 37 son de PRY-200. Los archivos citados sí existen en `PRY-200-crédito-de-libranza-digital/`, así que no se borraron ni se movieron. Mi lectura es que el índice no resuelve las rutas citadas sin el prefijo de la carpeta del proyecto. No lo confirmé en el código del índice.

| Campo | Documento citado |
|---|---|
| identity: code, name, business_area, product, sponsor, manager, committee (7) | 00-gobierno/2025-12-18-acta-constitucion.md |
| declared: status, progress_pct, as_of (3) | 20-seguimiento/2026-10-07-informe-avance.md |
| plan.start_date; money.currency, money.approved (3) | 00-gobierno/2025-12-18-acta-constitucion.md |
| plan.end_date y los 5 hitos (name, baseline_date, current_date, state) (21) | 10-plan/2025-12-18-cronograma-v1.xlsx |
| plan.milestones[2].evidence (1) | 20-seguimiento/2026-10-07-acta-recibo-integración-con-el-core-cooperativo.md |
| money.committed, executed, projection (3) | 20-seguimiento/2026-10-07-informe-avance.md |

### Formatos que no se pudieron leer
El índice no reportó ninguno.

### Qué sigue
No hace falta `/portfolio-scan`, porque `projects_to_recompute` está vacío. Antes de tocar la ficha de PRY-200, hay que confirmar si el problema es de resolución de rutas. No corregí ninguna cita.

Un detalle sin resolver: en la carpeta de PRY-200 está `2026-10-17-notas-reunion.txt`, pero el índice no lo reporta como nuevo. No averigüé si ya estaba indexado o si el índice no lee `.txt`.

La corrida quedó registrada como `2026-10-17-document-index-1`. Tardó 15 segundos y la salida completa está en `estado/corridas/salida-document-index.md`. El número de documentos de la corrida quedó sin medir.
