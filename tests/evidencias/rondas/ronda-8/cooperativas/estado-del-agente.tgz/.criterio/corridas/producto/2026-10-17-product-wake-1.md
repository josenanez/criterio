# Corrida · 2026-10-17-product-wake-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-wake (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T17:22:58 · **Fin:** 2026-10-17T17:23:41 · **Duración:** 43 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-wake` | 17 | — | 28 | 43 | Primera revisión, línea base sin corte previo: 7 señales tipos, 16 REQ sin proyecto, REQ-4614 sin decidir 124 días, supuesto del reglamento 154 días. No leí el acta docx del 2026-10-15; trazas no confirmables porque ninguna ficha nombra el producto. |

Por señal (`product-wake`): `requirement_untraced` 16, `evidence_stale` 11, `requirement_without_acceptance` 7, `requirement_accepted_without_evidence` 5, `requirement_without_owner` 2, `requirement_undecided` 1, `assumption_unverified` 1

## Lo que el agente mostró

## Recaudos (PRD-306) · 2026-10-17

Esta fue la primera revisión del registro, así que no había un corte anterior con qué comparar. Lo que sigue es la línea base, no novedad. Los términos ya estaban vigentes a nombre de José Francisco Ñáñez, así que no hubo que aceptarlos de nuevo.

**Decisiones pendientes**
- **REQ-4614:** lleva 124 días propuesto, y el umbral es 60. No tiene doliente, y falta saber quién tiene la facultad de decidirlo. Se puede llevar al Comité de producto.
- **Supuesto «El reglamento vigente lo permite»:** lleva 154 días sin verificar, y el umbral es 30. Hay que contrastarlo con quien interprete el reglamento. Ya pasó el punto en que conviene tratarlo como riesgo registrado.

**Aceptados que nadie está construyendo**
- 16 de los 17 requerimientos están aceptados y ninguno tiene proyecto.
- Siete no tienen criterio de aceptación, cinco no tienen evidencia de demanda y dos no tienen doliente (REQ-4611 y REQ-4614).
- 11 requerimientos descansan en la entrevista del 2025-09-27, que ya cumplió 12 meses y no nombra ninguno de ellos.

**Negocio contra datos**
- El volumen mensual declarado en el caso de negocio es 196.775 y el medido es 175.099, una brecha de 11 %. Está por debajo del umbral de 20 %, así que no es hallazgo.
- El retorno a 24 meses no tiene cifra, y el criterio de éxito de la definición no está dicho.

**Trazas:** ninguna ficha de `estado/records` nombra PRD-306 ni sus requerimientos, así que no hay trazas que confirmar. Eso no prueba que nadie trabaje en esto, solo que ninguna ficha lo dice.

**Lo que no hice:** no abrí el acta `2026-10-15-comite-producto.docx`. Queda pendiente de lectura.

Dejé registrados la revisión, el corte (`snapshots/2026-10-17.json`) y la corrida `2026-10-17-product-wake-1`, que tardó 28 segundos. La salida completa está en `estado-producto/PRD-306/corridas/salida-product-wake.md`.

**Vuelvo el 2026-11-16.**
