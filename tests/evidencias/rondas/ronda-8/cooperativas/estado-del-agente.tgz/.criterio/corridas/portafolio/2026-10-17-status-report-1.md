# Corrida · 2026-10-17-status-report-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:status-report PRY-204

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-204

**Inicio:** 2026-10-17T17:05:54 · **Fin:** 2026-10-17T17:06:34 · **Duración:** 40 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `status-report` | 13 | — | 26 | 69 | Status report de PRY-204: amarillo 62% declarado el 2026-09-25; hito Diseño funcional sin evidencia (54 días), silencio de 22 días, incidencia de prueba de carga sin seguimiento. Sin dato: autoridad, fase, última reunión, dueños de riesgos. |

Por señal (`status-report`): `milestone_met_without_evidence` 25, `commitment_overdue` 10, `progress_vs_plan` 7, `vendor_deliverable_late` 5, `commitment_undated` 4, `declared_vs_evidence` 4, `milestone_overdue` 4, `commitment_rescheduled` 3, `change_without_baseline` 2, `silent` 1, `variance_cost` 1, `budget_committed` 1, `variance_time` 1, `vendor_invoiced_without_delivery` 1

## Lo que el agente mostró

**PRY-204 no tiene un estado que los documentos confirmen.** El gerente declara amarillo y 62% de avance, pero la declaración tiene 22 días y no hay ningún documento posterior que la respalde.

- **Hito sin evidencia:** «Diseño funcional aprobado» está dado por cumplido, con fecha 2026-08-24. No hay ningún documento que lo sustente, y van 54 días.
- **Silencio:** el último documento es el informe de avance del 2026-09-25. Lleva 22 días sin documentos y el umbral es 15. No hay ninguna reunión registrada.
- **Incidencia abierta:** el informe dice que la prueba de carga no alcanzó el umbral y se repite. No hay nada posterior que diga cómo terminó.
- **Plazo y costo:** no hay desviación. El cierre sigue en 2027-06-17, con 0 replanificaciones. La proyección de COP 1.180.865.844 queda un 1,6% por debajo de los COP 1.200.000.000 aprobados. Ejecutado: 27,4%.
- **Riesgos sin dueño:** los dos riesgos y la incidencia no tienen dueño. Faltan también la autoridad del proyecto y la fase, así que no puedo decir si algún riesgo excede la autoridad del gerente.

La corrida quedó registrada como `2026-10-17-status-report-1`. Marcó 26 segundos y no pudo medir los documentos leídos.

Si quieres, preparo el punto para el comité del 2026-10-24.

Archivos en `estado/corridas/`:
- salida-status-report.md
- 2026-10-17-status-report.md
