# Corrida · 2026-10-17-project-charter-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-charter PRY-201 revisar

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-201

**Inicio:** 2026-10-17T17:15:16 · **Fin:** 2026-10-17T17:16:00 · **Duración:** 44 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-charter` | 13 | — | 27 | 69 | Revisión del acta PRY-201 (2026-04-16): faltan autoridad del gerente, supuestos/restricciones, objetivo medible, métrica del criterio de éxito y quién la mide; patrocinador = gerente; dependencias 'ninguna' contradicen cronograma e informe. No sé qué se habló fuera de los tres documentos. |

Por señal (`project-charter`): `milestone_met_without_evidence` 25, `commitment_overdue` 10, `progress_vs_plan` 7, `vendor_deliverable_late` 5, `commitment_undated` 4, `declared_vs_evidence` 4, `milestone_overdue` 4, `commitment_rescheduled` 3, `change_without_baseline` 2, `silent` 1, `variance_cost` 1, `budget_committed` 1, `variance_time` 1, `vendor_invoiced_without_delivery` 1

## Lo que el agente mostró

Hay acta previa de PRY-201, del 2026-04-16, y la revisé contra ella, el cronograma v1 y el informe de avance del 2026-10-15. Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17), así que no hubo que registrar nada.

**Lo que falta en el acta y lo que cuesta:**
- **Autoridad del gerente:** ausente. La proyección al cierre es de 4.306.338.785 COP, 106.338.785 COP (2,5 %) sobre los 4.200.000.000 aprobados. Sin un umbral escrito, nadie puede decir si eso lo resuelve Paula Céspedes o lo debe decidir el Comité de Educación, y por defecto todo sube a comité.
- **Objetivo de negocio:** el acta solo describe la solución ("Entregar apertura de ahorro en línea") y no da ningún resultado medible. Así no se puede juzgar si el proyecto vale lo que cuesta.
- **Criterio de éxito:** dice "en producción y medido", pero no qué se mide, con qué meta ni quién lo mide. El cierre sería una opinión.
- **Alcance y exclusiones:** son genéricos. El alcance dice "Componente 1, 2 y 3" y las exclusiones "Lo que otro proyecto cubre". Sin alcance base no se puede decidir si el hallazgo de seguridad y el ajuste al plan de pruebas son cambios.
- **Patrocinador:** es la misma persona que la gerente, así que no hay a quién escalar ni quién arbitre.
- **Supuestos y restricciones:** ausentes.
- **Dependencias:** el acta dice "Ninguna declarada", pero el cronograma tiene un hito de integración con el core cooperativo y el informe tiene un riesgo abierto con el proveedor, que no ha confirmado la fecha de su última entrega.
- **Cadencia:** el comité está nombrado, pero la cadencia no.
- **Hitos:** el último hito (Piloto con asociados, 2027-09-15) coincide con el cierre. Ningún hito sustenta el "medido" del criterio de éxito.

Dejé pendientes de definir los campos que no estaban en los documentos, sin rellenarlos. No sé nada de lo hablado fuera de estos tres documentos, y no hay minutas ni solicitudes de cambio en la carpeta.

**Para ti:**
- **Autoridad:** ofrezco llevar su definición al Comité de Educación como decisión (monto y tipo de cambio que la gerente decide sin comité). No lo he ejecutado.
- **Supuestos:** también ofrezco pasar al registro RAID los que salieron de la revisión (entrega del proveedor, ambiente de pruebas, core). Tampoco lo he ejecutado.
- **Coherencia:** el área dueña es Cartera y cobranza y el producto es ahorro a la vista, y el acta no explica esa relación ni por qué lo aprueba el Comité de Educación. Lo dejé como pregunta para la gerente, no como hallazgo.

La corrida quedó registrada como `2026-10-17-project-charter-1`. Su salida íntegra está en `/home/claude/banco/ronda-8/cooperativas/espacio/estado/corridas/salida-project-charter.md`.
