# Corrida · 2026-10-17-pm-escalate-1

**Agente:** Samuel (proyecto) · **Comando:** `/criterio-project:pm-escalate (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T16:57:13 · **Fin:** 2026-10-17T16:58:05 · **Duración:** 52 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `pm-escalate` | 1 | — | 36 | 20 | Escaló un solo punto: autoridad del gerente no declarada en el acta. No calculó impacto (sin días de cambio ni fecha nueva de salida). No dijo cuánto cuesta cada opción ni si hay proyectos alcanzados. |

Por señal (`pm-escalate`): `commitment_overdue` 5, `milestone_met_without_evidence` 4, `commitment_undated` 3, `commitment_rescheduled` 3, `vendor_deliverable_late` 3, `progress_vs_plan` 1, `declared_vs_evidence` 1

## Lo que el agente mostró

## Para decisión — PRY-200 · Crédito de libranza digital · 2026-10-17

Los términos ya estaban vigentes (versión 1.1, aceptada por José Francisco Ñáñez el 2026-10-17), así que no los registré otra vez.

Solo escala un punto, y es la pregunta que dejo para el Consejo de Administración: **¿declara el Consejo, por escrito, qué puede decidir Jorge Medina en fechas, presupuesto y proveedor, y qué debe llevarle?**

El acta de constitución nombra patrocinador, gerente, comité y presupuesto, pero no declara la autoridad del gerente. Sin ese límite no se puede decir si lo demás excede su facultad.

- **Quién decide:** el Consejo de Administración, que es el comité y aprobó el presupuesto. El acta no dice quién más puede fijar esa autoridad.
- **Si no se decide hoy:** ningún documento trae una fecha límite, y no la inventé. El cierre comprometido (2026-10-01) ya venció, y la próxima reunión es en dos semanas.
- **Recomiendo:** que el Consejo declare la autoridad en el acta o en un anexo (opción A). Con la opción B, dejarla como está, cada decisión subiría caso por caso, con el riesgo de que la devuelvan o la decidan sin tener la facultad.

Esto no armé como escalamiento:
- **Cierre vencido y salida a producción:** el informe del 2026-10-07 dice «se reprogramó la salida», pero no hay fecha nueva ni línea base 2. Es control de cambios, no escalamiento.
- **Proveedor Soluciones Solidarias (CT-410):** tiene tres entregables vencidos sin acta de recibo. La revisión con el proveedor es el 2026-10-27, a cargo de Óscar Ramírez. Quedó sin registrar como riesgo que el proveedor podría no llegar con el equipo completo.
- **Compromisos reprogramados tres o más veces:** son los de Felipe Arango (5 veces), Óscar Ramírez (4) y Elena Duarte (3). Sus dolientes están dentro del proyecto, así que primero va la llamada.
- **Estado verde con 48% de avance y cierre vencido:** es una contradicción para el informe, no una decisión.

No calculé a quién alcanza ni qué hitos mueve. El comando necesita un número de días de cambio y no hay ninguno, porque no existe una fecha nueva de salida. El acta tampoco declara dependencias con otros proyectos, pero eso no prueba que no las haya.

Tampoco sé cuánto cuesta cada opción, ni qué se habló fuera de estos documentos.

La corrida quedó registrada como `2026-10-17-pm-escalate-1` (36 segundos, 1 proyecto, 20 señales abiertas).

Archivos en `estado/PRY-200-crédito-de-libranza-digital/corridas/`:
- salida-pm-escalate.md
