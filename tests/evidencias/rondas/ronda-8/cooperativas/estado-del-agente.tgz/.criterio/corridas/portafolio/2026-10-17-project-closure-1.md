# Corrida · 2026-10-17-project-closure-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-closure PRY-200

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-200

**Inicio:** 2026-10-17T17:16:05 · **Fin:** 2026-10-17T17:17:15 · **Duración:** 70 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-closure` | 13 | — | 53 | 69 | Cierre de PRY-200 no determinable: criterio de éxito 'en producción y medido' sin evidencia de producción ni de medición; 4 de 5 hitos cumplidos sin evidencia; 0 de 3 entregables del proveedor con acta; informe dice salida reprogramada sin línea base nueva. No se sabe: producción, medición, alcance entregado, facturado, autoridad. |

Por señal (`project-closure`): `milestone_met_without_evidence` 25, `commitment_overdue` 10, `progress_vs_plan` 7, `vendor_deliverable_late` 5, `commitment_undated` 4, `declared_vs_evidence` 4, `milestone_overdue` 4, `commitment_rescheduled` 3, `change_without_baseline` 2, `silent` 1, `variance_cost` 1, `budget_committed` 1, `variance_time` 1, `vendor_invoiced_without_delivery` 1

## Lo que el agente mostró

**PRY-200 (Crédito de libranza digital) no se puede cerrar contra su criterio de éxito con los documentos que hay.** Si se cerrara hoy, sería por decisión y no por cumplimiento.

Salí de la ficha de PRY-200, la salida de `compute` del 2026-10-17 y los documentos del proyecto: acta de constitución, contrato CT-410, cronograma v1, informe de avance del 2026-10-07, acta de recibo de la integración con el core y las notas de la reunión del 2026-10-17. Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17), así que no los registré de nuevo.

- **Criterio de éxito:** el acta pide «Crédito de libranza digital en producción y medido». Ningún documento prueba la salida a producción, y el informe del 2026-10-07 dice que la salida se reprogramó. Tampoco hay medición, ni el acta define qué se mide.
- **Hitos:** el cronograma marca 5 de 5 como cumplidos, pero solo la integración con el core tiene evidencia (acta firmada el 2026-10-07). El informe declara 48 % de avance y estado verde. `compute` marca esa brecha de 52 puntos.
- **Proveedor:** ninguno de los 3 entregables de CT-410 tiene acta de recibo (217, 141 y 65 días de atraso), y no consta lo facturado.
- **Números:**
  - Presupuesto aprobado: 4.200.000.000 COP.
  - Ejecutado: 1.405.474.333 COP (33,5 %).
  - Comprometido: 3.390.376.801 COP (80,7 %).
  - Proyección declarada: 4.010.066.854 COP (−4,5 % contra el aprobado).
  - Fecha: `compute` da 0 días de desviación contra la línea base original, pero no es confiable. La reprogramación de la salida no dejó línea base nueva.
  - Replanificaciones registradas: 0.
- **RAID:** 2 riesgos y 3 incidencias abiertos, ninguno con responsable. De 26 compromisos de reunión, 23 siguen sin cumplirse: 5 vencidos, 3 sin fecha y 3 reprogramados 4, 5 y 6 veces.
- **Lecciones:** puse 6, cada una anclada a un hecho y a una fecha.
- **Sin dato:** producción, medición, alcance entregado, lo facturado, quién aprueba (`authority`) y la fase del proyecto.

No tuve a quién preguntarle sobre archivar, así que tomé la respuesta sugerida: no mover la carpeta a `archivo/` ni congelar la ficha. Cerrarlo ocultaría las señales abiertas.

Las cifras salen de `compute`, salvo dos cálculos míos: 117 días entre la fecha del hito del core y su acta, y 73 días de desplazamiento del «documento 1».

La corrida quedó registrada como `2026-10-17-project-closure-1`. El texto completo está en `estado/PRY-200-crédito-de-libranza-digital/corridas/salida-project-closure.md`.
