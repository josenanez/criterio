# Corrida · 2026-10-17-product-spec-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-spec (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T16:46:32 · **Fin:** 2026-10-17T16:47:25 · **Duración:** 53 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-spec` | 17 | — | 39 | 43 | Borrador sin comportamiento: 0 de 16 aceptados cubiertos por falta de necesidad registrada; 9 criterios 'se verifica en producción' no verificables, 7 sin criterio; barrido normativo sin país ni norma a la vista; dependencias de otros equipos no registradas, no inventadas. |

Por señal (`product-spec`): `requirement_untraced` 16, `evidence_stale` 11, `requirement_without_acceptance` 7, `requirement_accepted_without_evidence` 5, `requirement_without_owner` 2, `requirement_undecided` 1, `assumption_unverified` 1

## Lo que el agente mostró

Terminé el borrador de especificación de Recaudos (PRD-306), pero sin comportamiento: ninguno de los 16 requerimientos aceptados quedó cubierto. Ninguno dice qué problema resuelve (los títulos son solo «Requerimiento REQ-xxxx»), y no quise inventarlo.

- **Criterios de aceptación:** 9 requerimientos dicen solo «se verifica en producción», que no se puede verificar sin discutir. Los otros 7 no tienen criterio. No propuse cifras propias.
- **Supuestos:** «El reglamento vigente lo permite» lleva 154 días sin verificar. El volumen mensual declarado (196.775) frente al medido (175.099) tiene una brecha del 11%, bajo el umbral del 20%.
- **Vacíos:**
  - El problema de cada requerimiento.
  - Los casos borde.
  - Los dueños de REQ-4611 y REQ-4614.
  - Los dueños de cada criterio faltante.
  - El proyecto que construiría los 16 (hoy ninguno).
  - Las dependencias con otros equipos: ningún documento las registra, así que no las inventé.
- **Obligaciones normativas:** ningún documento dice el país, así que todas quedaron como «no tengo la norma a la vista» o «sin resolver». No cité ninguna norma.
- **Fuera de la especificación:** REQ-4614, porque está propuesto y no aceptado.
- **Corrida:** los términos ya estaban vigentes a nombre de José Francisco Ñáñez (2026-10-17), así que no los registré de nuevo. La corrida quedó registrada con `product-spec` (39 s, 17 requerimientos, 43 hallazgos).
- **Siguiente paso:** no ofrezco `/product-charter`, porque los vacíos siguen abiertos. Antes conviene volver a `/product-requirements` cuando los dueños hayan escrito el problema de cada requerimiento.

El borrador completo está en `estado-producto/PRD-306/corridas/salida-product-spec.md`. Lo tiene que cerrar Gustavo Neira.
