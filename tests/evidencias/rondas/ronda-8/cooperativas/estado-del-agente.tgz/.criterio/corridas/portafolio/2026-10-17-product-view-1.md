# Corrida · 2026-10-17-product-view-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:product-view recaudos

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T17:18:47 · **Fin:** 2026-10-17T17:19:24 · **Duración:** 37 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-view` | 13 | — | 21 | 69 | Producto recaudos tiene un solo proyecto (PRY-211); sin sección de producto. Declarado rojo, 7 alertas. Dije que no sé el producto de 5 proyectos sin producto declarado ni su área dueña. |

Por señal (`product-view`): `milestone_met_without_evidence` 25, `commitment_overdue` 10, `progress_vs_plan` 7, `vendor_deliverable_late` 5, `commitment_undated` 4, `declared_vs_evidence` 4, `milestone_overdue` 4, `commitment_rescheduled` 3, `change_without_baseline` 2, `silent` 1, `variance_cost` 1, `budget_committed` 1, `variance_time` 1, `vendor_invoiced_without_delivery` 1

## Lo que el agente mostró

**Fichas:** salen de `estado/`, calculadas el 2026-10-17. Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17), así que no hubo que registrarlos de nuevo.

**«recaudos» tiene un solo proyecto, PRY-211 Cobranza digital.** La vista por producto no aporta nada con un único proyecto, así que no armé sección de producto. Esto es lo que dice la ficha:

| Producto | Proyectos | Con alertas | Fecha más tardía | Aprobado | Comprometido |
|---|---|---|---|---|---|
| recaudos | 1 (PRY-211) | 7 alertas | 2026-10-14 (Salida a producción) | COP 3.300.000.000 | COP 1.118.869.755 |

- **Estado declarado:** el gerente declara rojo, con 77 % de avance (informe del 2026-10-15).
- **Hito vencido:** «Salida a producción» venció hace 3 días.
- **Hitos sin evidencia:** «Ambiente de pruebas certificado» e «Integración con el core cooperativo» figuran como cumplidos sin evidencia.
- **Compromiso vencido:** «Entregar el punto 2», de Rubén Cárdenas, venció hace 19 días.
- **Proveedor:** Datos para Cooperativas S.A.S. (CT-650) tiene 2 entregables vencidos, uno hace 160 días y otro hace 69. Ha facturado COP 376.332.909 con 0 entregables aceptados.
- **Dinero:** las cuatro cifras están completas. Ejecutado COP 855.582.138 (25,9 %). La proyección es 4,5 % por debajo de lo aprobado.
- **Dependencias internas:** no aplican. La ficha no declara dependencias de PRY-211.

**Proyectos sin producto declarado.** Cinco de los 13 no declaran producto: PRY-202, 205, 208, 209 y 210. No puedo saber si alguno sirve a «recaudos», así que el dueño de ese producto podría estar viendo el conjunto incompleto. Esto es un hallazgo de gobierno. La tabla con el área dueña no se pudo completar porque el cálculo no trae ese dato.

**Lo que no sé.** Falta el producto y el área dueña de esos cinco proyectos. Tampoco hay evidencia de los hitos marcados como cumplidos, ni autoridad ni fase declaradas en PRY-211.

La corrida quedó registrada como `2026-10-17-product-view-1` (21 segundos, 13 proyectos, 69 hallazgos). La salida completa está en `estado/corridas/salida-product-view.md`. Es un borrador de trabajo, no una decisión. La verificación contra los documentos citados es de quien lo use.
