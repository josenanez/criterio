# Corrida · 2026-10-17-product-trace-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-trace (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T17:22:03 · **Fin:** 2026-10-17T17:22:41 · **Duración:** 39 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-trace` | 17 | — | 24 | 43 | 16 requerimientos decididos y ninguno con proyecto; PRY-211 dice ejecutar «recaudos» y ningún REQ lo nombra |

Por señal (`product-trace`): `requirement_untraced` 16, `evidence_stale` 11, `requirement_without_acceptance` 7, `requirement_accepted_without_evidence` 5, `requirement_without_owner` 2, `requirement_undecided` 1, `assumption_unverified` 1

## Lo que el agente mostró

## Trazabilidad — Recaudos (PRD-306) · al 2026-10-17

El comité decidió 16 requerimientos y ninguno tiene proyecto asignado en el registro.

**Términos:** ya estaban vigentes, aceptados por José Francisco Ñáñez el 2026-10-17. No hubo que registrar nada.

**Decidido y nadie lo está construyendo:**
- Los 16 requerimientos aceptados tienen «Proyecto que lo ejecuta: —».
- Por eso no hay trazas que confirmar y tampoco entregables.
- El más antiguo es REQ-4603, decidido el 2026-03-17 (214 días). El más reciente es REQ-2030, del 2026-09-23.
- El acta no dice quién decidió. En la tabla puse al doliente del registro, y REQ-4611 no tiene ninguno.
- REQ-4614 está «propuesto» y no cuenta como decidido.

**Lo que un proyecto construye y el registro no tiene:**
- La ficha de PRY-211 (Cobranza digital) dice que ejecuta el producto «recaudos», según su acta del 2026-01-30. Ningún requerimiento de PRD-306 la nombra.
- La ficha dice «recaudos» por nombre, no por el código PRD-306. Hay que confirmar con su gerente que es el mismo producto.
- Ninguna de las otras 12 fichas nombra PRD-306 ni «Recaudos».

**Señales de la corrida (43 hallazgos):** 16 requerimientos sin traza, 11 con evidencia vencida, 7 sin criterio de aceptación, 5 aceptados sin evidencia, 2 sin doliente, 1 sin decidir (REQ-4614, 124 días) y 1 supuesto sin verificar.

**Qué sigue:** `/criterio-product:product-charter` para el requerimiento que ya esté listo para ser proyecto. Sobre PRY-211, la salida es una conversación con su gerente de proyecto.

La salida completa quedó en `estado-producto/PRD-306/corridas/salida-product-trace.md`. La corrida quedó registrada como `2026-10-17-product-trace-1` (24 segundos).
