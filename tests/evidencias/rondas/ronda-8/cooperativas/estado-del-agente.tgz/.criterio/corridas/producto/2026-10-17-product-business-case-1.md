# Corrida · 2026-10-17-product-business-case-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-business-case (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T16:45:42 · **Fin:** 2026-10-17T16:46:27 · **Duración:** 45 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-business-case` | 17 | — | 30 | 43 | Caso de negocio armado: 1 cifra declarada (196.775) frente a 1 medida (175.099, brecha 11%, bajo el umbral). Sin costos, sin cifra de retorno, sin criterio de éxito y sin proyecto que construya. Sin fichas de otros productos publicadas: cruce no hecho. |

Por señal (`product-business-case`): `requirement_untraced` 16, `evidence_stale` 11, `requirement_without_acceptance` 7, `requirement_accepted_without_evidence` 5, `requirement_without_owner` 2, `requirement_undecided` 1, `assumption_unverified` 1

## Lo que el agente mostró

Armé el caso de negocio de Recaudos (PRD-306) y registré la corrida. Es una estructura con cada cifra citada a su fuente. No contiene proyecciones ni recomendación, y a este caso le faltan costos, retorno y criterio de éxito.

Los términos v1.1 ya estaban vigentes y aceptados por José Francisco Ñáñez el 2026-10-17, así que no los registré de nuevo.

- **Cifras:** el caso tiene una sola cifra con fuente: 196.775 de volumen mensual, declarada por Gustavo Neira el 2025-09-28. El tablero mide 175.099 con corte al 2026-10-15, una brecha del 11%, bajo el umbral del 20%. La serie medida tiene un solo punto, así que no hay tendencia. El «retorno esperado en 24 meses» no trae cifra.
- **Costos:** no aparecen en ningún documento, ni de construir, ni de equipo, ni contratos. Es el primer vacío: sin ellos esto es una propuesta, no un caso evaluable.
- **Requerimientos:** hay 16 aceptados y ninguno tiene proyecto que lo construya. Cinco aceptados no tienen quién los pidió, y 11 se apoyan en la misma entrevista del 2025-09-27, que no nombra ninguno de ellos.
- **Supuesto sin verificar:** «El reglamento vigente lo permite» lleva 154 días sin verificar (umbral 30) y no tiene responsable.
- **Cómo se sabrá si funcionó:** no está declarado. Sin eso, el 175.099 medido contra el 196.775 declarado no se puede leer como cumplido ni como incumplido.
- **Cruce con otros productos:** no lo hice, porque no hay fichas de otros productos publicadas.

La corrida registró 43 hallazgos sobre 17 requerimientos y tardó 30 segundos. El sistema de registro no pudo comprobar la señal de «decidido sin documento que lo respalde»; hay que verificarla a mano contra el acta del comité.

Archivos en `/home/claude/banco/ronda-8/cooperativas/espacio/estado-producto/PRD-306/corridas/`:
- `salida-product-business-case.md`
- `2026-10-17-product-business-case-1.md`
