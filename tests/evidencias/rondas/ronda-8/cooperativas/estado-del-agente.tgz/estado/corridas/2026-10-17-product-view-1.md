# Corrida del 2026-10-17 · product-view

13 proyectos · 21 s · 69 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 25 |
| `commitment_overdue` | 10 |
| `progress_vs_plan` | 7 |
| `vendor_deliverable_late` | 5 |
| `commitment_undated` | 4 |
| `declared_vs_evidence` | 4 |
| `milestone_overdue` | 4 |
| `commitment_rescheduled` | 3 |
| `change_without_baseline` | 2 |
| `silent` | 1 |
| `variance_cost` | 1 |
| `budget_committed` | 1 |
| `variance_time` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

Producto recaudos tiene un solo proyecto (PRY-211); sin sección de producto. Declarado rojo, 7 alertas. Dije que no sé el producto de 5 proyectos sin producto declarado ni su área dueña.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

Vista por producto, "recaudos". Sale del cálculo de `portafolio.py compute` sobre el estado de las fichas, al 2026-10-17.

**«recaudos» tiene un solo proyecto, PRY-211 Cobranza digital.** La vista por producto no aporta nada aquí, así que no armo una sección; abajo va lo que dice la ficha del proyecto.

| Producto | Proyectos | Con alertas | Fecha más tardía | Aprobado | Comprometido |
|---|---|---|---|---|---|
| recaudos | 1 (PRY-211) | 7 alertas | 2026-10-14 (Salida a producción, vencida hace 3 días) | COP 3.300.000.000 | COP 1.118.869.755 |

Las cuatro cifras de dinero vienen completas en el único proyecto. Ejecutado: COP 855.582.138 (25,9 %). Proyección: COP 3.150.132.734 (-4,5 % sobre lo aprobado).

**Lo que hay que ver en PRY-211.** El gerente declara **rojo** (informe del 2026-10-15) con un avance de 77 %. Las siete alertas son:
- Hito «Salida a producción» vencido hace 3 días (plazo 2026-10-14).
- Hitos declarados cumplidos sin evidencia: «Ambiente de pruebas certificado» (2026-05-18) e «Integración con el core cooperativo» (2026-07-07).
- Compromiso vencido: Rubén Cárdenas, «Entregar el punto 2», plazo 2026-09-28, 19 días.
- Proveedor Datos para Cooperativas S.A.S. (CT-650): dos entregables pendientes y vencidos, «Licenciamiento del módulo» (160 días) y «Bolsa de horas de desarrollo» (69 días).
- Ese mismo proveedor ha facturado COP 376.332.909 con 0 entregables aceptados de 2.

**Dependencias internas:** no aplica, el producto tiene un solo proyecto. La ficha no declara dependencias de PRY-211 con otros proyectos.

**Fecha comprometida del producto:** 2026-10-14, de PRY-211. Con corte 2026-10-17 no hay replanificación (0) ni desvío contra la línea base (0 días).

### Proyectos sin producto declarado
Esto es un hallazgo de gobierno y afecta a esta vista. Cinco de los 13 proyectos no declaran producto, y no puedo decir si alguno sirve a «recaudos»:

| Proyecto | Área dueña |
|---|---|
| PRY-202 Core cooperativo | no consta en el cálculo |
| PRY-205 Prevención de lavado de activos | no consta en el cálculo |
| PRY-208 Motor de crédito | no consta en el cálculo |
| PRY-209 Convenios de libranza con empresas | no consta en el cálculo |
| PRY-210 Corresponsales rurales | no consta en el cálculo |

Consecuencia: nadie puede responder por el conjunto al que sirven, y el dueño de «recaudos» no puede saber si le falta algún proyecto en la vista. Para completar la columna de área dueña hay que abrir la ficha de cada uno; el cálculo no la trae.

**Qué no sé:** el dato de producto de esos cinco proyectos, el área dueña, y el sustento de los hitos marcados cumplidos (la ficha no trae evidencia de ninguno). Tampoco hay autoridad de aprobación declarada en PRY-211 (`identity.authority`) ni fase.

*Pie de rigor: borrador de trabajo, no decisión. Todas las cifras vienen de la salida de `compute` del 2026-10-17 sobre las fichas del estado; la verificación contra los documentos citados es de la persona que lo usa.*
