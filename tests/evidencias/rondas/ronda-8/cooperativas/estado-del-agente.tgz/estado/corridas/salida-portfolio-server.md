# Rostrum — modo «para mirarlo un rato»

**Términos:** vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17, plugin 0.3.13). No hizo falta pedirlos de nuevo.

**Modo elegido:** «para mirarlo un rato» (argumento `rato`). Se levanta, se mira y se apaga. No hay enlace que funcione mañana.

**Informe:** existe en `reportes/` (index, proyectos, decisiones, productos y fichas por proyecto). Rostrum lo sirve, no lo genera.

## Comando

```
python3 "/home/claude/banco/criterio/plugins/criterio-portfolio/scripts/servidor.py" --informe reportes --estado estado --config .criterio/portafolio/config.json
```

Escucha en `127.0.0.1:8787`, solo en este equipo. Se para con Ctrl-C. Si el puerto está ocupado: `--puerto 8788`.

## Qué hay y para quién

| Ruta | Qué es | Para quién |
|---|---|---|
| `/` | Portada con las tres secciones y el formulario de peticiones | Todos |
| `/pmo` | Cómo va el portafolio: verdes que la evidencia no sostiene, silencios, patrocinadores repetidos | La PMO |
| `/decisiones` | Lo que necesita decisión, como pregunta cerrada y con la consecuencia de no decidir | Comité y patrocinador |
| `/proyectos` | Listado ordenado por lo que más pide atención | Todos |
| `/p/<código>` | Informe de un proyecto, con enlace a su producto | Quien gerencia |
| `/productos` | Listado de productos y proyectos sin producto declarado | Quien responde por un producto |
| `/producto/<nombre>` | Informe de un producto, con enlace a los proyectos que lo construyen | Quien responde por un producto |
| `/estado.json` | Fecha del informe y peticiones abiertas | Un mecanismo |

El portal lleva el nombre «Cooperativa» en todas las páginas.

## Lo que Rostrum no hace

- No calcula: sirve lo que `informe.py` ya escribió; dos personas ven lo mismo.
- No escribe fichas: el único archivo que crea es la petición, en `estado/peticiones/`.
- No autentica. En este modo solo escucha en el propio equipo.
- No manda nada: ni correo ni notificaciones.

## La cola de peticiones

El formulario de la portada no contesta en el momento: deja la petición en `estado/peticiones/` hasta que el agente despierte. `portafolio.py due` las cuenta y una abierta rompe el silencio de `/portfolio-wake`.

## Cierre

Este enlace, `http://127.0.0.1:8787/`, solo sirve a quien esté en este equipo. Para el patrocinador no hay enlace todavía: eso exige el modo «que quede corriendo» y una conversación con seguridad (host, puerto y control de acceso), que conviene tener ya con esto funcionando delante.

El informe es de la fecha que dice la portada; si se regenera con `/portfolio-report html`, hay que recargar la página.
