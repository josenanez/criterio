Acta previa: sí, del 2026-04-16 (`PRY-201-apertura-de-ahorro-en-línea/00-gobierno/2026-04-16-acta-constitucion.docx`). Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17).

## Acta — PRY-201 · Apertura de ahorro en línea
**Estado:** existe, del 2026-04-16

### Qué falta
| Campo | Estado | Consecuencia |
|---|---|---|
| Autoridad del gerente | **Ausente.** El acta no dice hasta qué monto ni qué cambio de alcance o fechas decide Paula Céspedes sin comité. | La proyección al cierre (4.306.338.785 COP) ya supera lo aprobado (4.200.000.000) en 106.338.785 COP (+2,5 %). Sin umbral escrito, nadie puede decir si eso lo resuelve la gerente o lo debe decidir el Comité de Educación; por defecto todo sube a comité. |
| Objetivo de negocio | **Es la descripción de la solución:** "Entregar apertura de ahorro en línea para Cartera y cobranza". Sin resultado de negocio ni cifra. | No hay contra qué juzgar si el proyecto vale lo que cuesta ni cuándo dejó de valer la pena. |
| Criterio de éxito | "En producción y medido": no dice qué se mide, con qué meta, ni quién mide. | Nadie puede declarar el proyecto exitoso o fallido. El cierre será una opinión. |
| Alcance | "Componente 1, 2, 3", sin nombre ni contenido. | Cualquier solicitud de cambio es indiscutible: no hay alcance base contra el cual compararla. El hallazgo de seguridad y el ajuste al plan de pruebas (informe 2026-10-15) no se pueden clasificar como dentro o fuera. |
| Exclusiones | "Lo que otro proyecto cubre": texto genérico, sin proyecto nombrado. | No se sabe qué no se hace ni quién lo hace; es riesgo de traslape o de hueco entre proyectos. |
| Patrocinador | Hay nombre, pero es la misma persona que la gerente (Paula Céspedes). | No hay patrocinador independiente a quien escalar ni que arbitre contra la gerente. Con la autoridad ausente, la escalada no tiene destinatario claro. |
| Supuestos y restricciones | **Ausentes.** | Lo que el proyecto da por cierto (entregas del proveedor, certificación del ambiente de pruebas, acceso al core) no está escrito y no se puede revisar cuando falle. |
| Dependencias | "Ninguna declarada", pero el cronograma tiene un hito de integración con el core cooperativo (2027-05-11) y el informe nombra un proveedor con una entrega sin fecha. | Una dependencia real quedó sin dueño ni fecha; el riesgo del proveedor está en el informe y no en el acta. |
| Comité y cadencia | Comité nombrado (Comité de Educación); cadencia no declarada. | No hay ritmo de reporte ni de decisión comprometido. |
| Hitos principales | Presentes en el cronograma v1, no en el acta. El último hito (Piloto con asociados, 2027-09-15) coincide con el cierre; nada después. | El criterio de éxito ("en producción y medido") queda sin hito que lo sustente: el cierre planeado es el piloto, no la medición. |
| Fecha de inicio | Acta aprobada el 2026-04-16; inicio 2026-04-26. Consistente. | — |

### Contenido
**Objetivo de negocio:** pendiente de definir (el acta solo describe la solución).
**Alcance:** pendiente de definir (acta: "Componente 1, 2 y 3", sin detalle).
**Exclusiones:** pendiente de definir (acta: "Lo que otro proyecto cubre").
**Patrocinador:** Paula Céspedes · **Gerente:** Paula Céspedes (acta, 2026-04-16)
**Autoridad del gerente:** **pendiente de definir** (no está en ningún documento).
**Comité al que reporta:** Comité de Educación (acta) · **Cadencia:** pendiente de definir.
**Supuestos:** pendiente de definir · **Restricciones:** pendiente de definir.
**Criterio de éxito:** "Apertura de ahorro en línea en producción y medido" (acta); sin métrica ni meta · **Lo mide:** pendiente de definir.
**Presupuesto aprobado:** 4.200.000.000 COP, por el Comité de Educación el 2026-04-16 (acta).
**Fechas:** inicio 2026-04-26, cierre 2027-09-15 (acta).
**Hitos principales** (cronograma v1, 2026-04-16): Diseño funcional aprobado 2026-08-30 (cerrado) · Ambiente de pruebas certificado 2027-01-04 · Integración con el core cooperativo 2027-05-11 · Piloto con asociados 2027-09-15.

### Observaciones de coherencia (para confirmar, no conclusiones)
- El área dueña es Cartera y cobranza y el producto es ahorro a la vista; el acta no explica la relación. Un proyecto de ahorro lo aprueba el Comité de Educación: el acta no dice por qué ese comité. Pregunta para la gerente, no hallazgo.
- Presupuesto del informe 2026-10-15: comprometido 2.835.540.251 (67,5 %), ejecutado 2.435.174.020 (58,0 %), avance reportado 47 %, estado declarado amarillo. La proyección ya excede lo aprobado; sin autoridad declarada, no hay regla para saber quién decide.

### Fuentes
Acta de constitución 2026-04-16 · cronograma v1 2026-04-16 · informe de avance 2026-10-15 · ficha `estado/records/PRY-201.json` (campos no encontrados: autoridad, fase).

## Lo que no sé
No sé qué se habló fuera de estos tres documentos. No hay minutas del comité ni solicitudes de cambio en la carpeta; si la autoridad o los supuestos existen, están sin escribir o en otro lugar. No sé quién mide el criterio de éxito.

## Después
El acta quedó sin autoridad declarada. Te ofrezco llevar esa definición al Comité de Educación como decisión (monto y tipo de cambio que la gerente decide sin comité); no es un trámite, es lo que hoy obliga a subirlo todo. Los supuestos que salieron (entrega del proveedor, certificación del ambiente de pruebas, disponibilidad del core) se pueden pasar al registro RAID. Ambos ofrecimientos quedan pendientes de tu respuesta; no los ejecuté.

---
*Pie de rigor: borrador de trabajo, no decisión ni asesoría. Cada dato sale del documento citado; la verificación es de quien lo usa.*
