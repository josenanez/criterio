# Corrida del 2026-10-17 · portfolio-server

13 proyectos · 69 hallazgos

> El tiempo no se midió: faltó `corrida-inicio` al arrancar. Un tiempo escrito a mano es un recuerdo, no una medición.

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 25 |
| `commitment_overdue` | 10 |
| `progress_vs_plan` | 7 |
| `vendor_deliverable_late` | 5 |
| `commitment_undated` | 4 |
| `declared_vs_evidence` | 4 |
| `milestone_overdue` | 4 |
| `commitment_rescheduled` | 3 |
| `change_without_baseline` | 2 |
| `silent` | 1 |
| `variance_cost` | 1 |
| `budget_committed` | 1 |
| `variance_time` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

puerto 8787, carpeta del informe reportes, modo rato

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

# Rostrum — modo «para mirarlo un rato»

**Términos:** vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17, plugin 0.3.13). No hizo falta pedirlos de nuevo.

**Modo elegido:** «para mirarlo un rato» (argumento `rato`). Se levanta, se mira y se apaga. No hay enlace que funcione mañana.

**Informe:** existe en `reportes/` (index, proyectos, decisiones, productos y fichas por proyecto). Rostrum lo sirve, no lo genera.

## Comando

```
python3 "/home/claude/banco/criterio/plugins/criterio-portfolio/scripts/servidor.py" --informe reportes --estado estado --config .criterio/portafolio/config.json
```

Escucha en `127.0.0.1:8787`, solo en este equipo. Se para con Ctrl-C. Si el puerto está ocupado: `--puerto 8788`.

## Qué hay y para quién

| Ruta | Qué es | Para quién |
|---|---|---|
| `/` | Portada con las tres secciones y el formulario de peticiones | Todos |
| `/pmo` | Cómo va el portafolio: verdes que la evidencia no sostiene, silencios, patrocinadores repetidos | La PMO |
| `/decisiones` | Lo que necesita decisión, como pregunta cerrada y con la consecuencia de no decidir | Comité y patrocinador |
| `/proyectos` | Listado ordenado por lo que más pide atención | Todos |
| `/p/<código>` | Informe de un proyecto, con enlace a su producto | Quien gerencia |
| `/productos` | Listado de productos y proyectos sin producto declarado | Quien responde por un producto |
| `/producto/<nombre>` | Informe de un producto, con enlace a los proyectos que lo construyen | Quien responde por un producto |
| `/estado.json` | Fecha del informe y peticiones abiertas | Un mecanismo |

El portal lleva el nombre «Cooperativa» en todas las páginas.

## Lo que Rostrum no hace

- No calcula: sirve lo que `informe.py` ya escribió; dos personas ven lo mismo.
- No escribe fichas: el único archivo que crea es la petición, en `estado/peticiones/`.
- No autentica. En este modo solo escucha en el propio equipo.
- No manda nada: ni correo ni notificaciones.

## La cola de peticiones

El formulario de la portada no contesta en el momento: deja la petición en `estado/peticiones/` hasta que el agente despierte. `portafolio.py due` las cuenta y una abierta rompe el silencio de `/portfolio-wake`.

## Cierre

Este enlace, `http://127.0.0.1:8787/`, solo sirve a quien esté en este equipo. Para el patrocinador no hay enlace todavía: eso exige el modo «que quede corriendo» y una conversación con seguridad (host, puerto y control de acceso), que conviene tener ya con esto funcionando delante.

El informe es de la fecha que dice la portada; si se regenera con `/portfolio-report html`, hay que recargar la página.
