**Sale de:** las 13 fichas de `estado/records` (PRY-199 a PRY-211) y, para lo no registrado, las reuniones y notas de `documentos/proyectos` (PRY-200, 202, 206, 209, 210, 211, 199) y las actas de constitución (sección «Dependencias declaradas»). No hay ficha de PRY-199…211 con ids de RAID propios: los ids de abajo (`PRY-nnn/R1`, `/D1`, `/I1`) son etiquetas de esta salida, no del registro.

## RAID — portafolio al 2026-10-17
12 riesgos · 0 supuestos · 18 incidencias · 8 dependencias
12 de 12 riesgos sin doliente y sin fecha · 18 de 18 incidencias sin doliente · 8 de 8 dependencias sin confirmar · 1 no registrado formalmente

Escala de probabilidad e impacto: ninguna definida por la organización ni valorada en las fichas; se deja en blanco, no se inventa (la de referencia sería alta/media/baja).
Sin movimiento: **no se puede medir.** Ningún ítem trae fecha de último movimiento, así que no afirmo que alguno lleve dos períodos quieto; es en sí un hallazgo.
Supuestos: ninguno registrado ni dicho en un documento. Que no haya no significa que no existan (personas clave, ambientes, aprobaciones); nadie los levantó.

**Reclasificados (8):** en las fichas figuraban como riesgos y por la prueba rápida son dependencias, porque dependen de alguien fuera del proyecto.
- «Dependencia del proveedor del core cooperativo» (PRY-199, 206, 209): ya dice que es una dependencia.
- «El proveedor no ha confirmado la fecha de la última entrega» (PRY-201, 207, 208, 209, 211): depende de un tercero y no está confirmada.

**Por revisar (no reclasifiqué):** «Se ajustó el plan de pruebas con el área de seguridad» (PRY-201, 206, 207, 210) está registrada como incidencia, pero describe una acción ya hecha, no un problema abierto. Que la PMO decida si es una incidencia o debe cerrarse.

### Necesitan decisión ahora
| Id | Tipo | Qué | Doliente | Desde | Por qué sube |
|---|---|---|---|---|---|
| PRY-199/D1, PRY-206/D1, PRY-209/D1 | Dependencia | Depende del «proveedor del core cooperativo» | sin doliente | 2026-10-15 / 10-10 / 10-06 | Afecta a tres proyectos. Ninguna acta declara dependencias («Ninguna declarada»), y ninguna cita un código de proyecto. PRY-202 *Core cooperativo* es el candidato obvio, pero **ningún documento lo dice**; confirmarlo es de la PMO. Si lo fuera: su fecha de cierre de línea base era 2026-05-16 (vencida), declara verde con 65 % y tiene dos compromisos vencidos en el comité del 2026-10-17 (puntos 25 y 16). |
| PRY-200/R2 | Riesgo (no registrado) | El proveedor podría no llegar con el equipo completo para la siguiente fase | sin doliente | 2026-10-17 | Posible efecto en otro proyecto: Soluciones Solidarias S.A.S. es proveedor de CT-410 (PRY-200) y de CT-199 (PRY-199, primer entregable 2026-11-16). Las notas **no nombran** al proveedor; es una inferencia a confirmar. |
| PRY-199/I1, PRY-201/I2, PRY-203/I2 | Incidencia | «Hallazgo de seguridad en la revisión de arquitectura» | sin doliente | 2026-10-15 / 10-15 / 10-14 | Misma frase en tres proyectos, sin doliente en ninguno. No sé si es un solo hallazgo transversal; confirmarlo. |
| PRY-199/I2, PRY-200/I1, PRY-203/I1, PRY-204/I1 | Incidencia | «La prueba de carga no alcanzó el umbral pactado y se repite» | sin doliente | 2026-09-25 a 10-15 | Cuatro proyectos con la misma incidencia y ninguno con doliente. |

### Detectados en reuniones, no registrados
| Qué | Tipo | Dicho en | Fecha |
|---|---|---|---|
| El proveedor podría no llegar con el equipo completo para la siguiente fase («nadie lo anotó como riesgo») | Riesgo | PRY-200, `2026-10-17-notas-reunion.txt` | 2026-10-17 |

Es el único. El resto de reuniones leídas (PRY-199, 202, 206, 209, 210, 211 y los comités semanales de PRY-200) solo traen tablas de compromisos, sin riesgos dichos al pasar. No inventé ninguno.
Estas dos observaciones de las notas no son RAID, pero conviene saberlas: Felipe Arango reprogramó otra vez «enviar el documento 1» (24/11/2026, antes 2026-09-12) y Óscar Ramírez fijó la revisión con el proveedor para el 2026-10-27.

### Sin doliente o sin fecha
| Id | Tipo | Qué | Qué falta |
|---|---|---|---|
| PRY-200/R1, 202/R2, 203/R2, 204/R1 | Riesgo | Concentración del conocimiento en una sola persona | Doliente, fecha, probabilidad, impacto |
| PRY-202/R1, 205/R1, 208/R1 | Riesgo | Aprobación del reglamento por el Consejo de Administración | Ídem. Es además una aprobación que nadie ha verificado si es trámite: candidata a supuesto |
| PRY-203/R1, 204/R2, 210/R1, 211/R1 | Riesgo | Cambio normativo del supervisor que puede mover el alcance | Ídem |
| PRY-200/R2 | Riesgo (no registrado) | Equipo incompleto del proveedor | Ídem |
| Las 18 incidencias | Incidencia | Ver registro completo | Doliente. Solo hay fecha de origen (la del informe que la menciona), no fecha de resolución |
| Las 8 dependencias | Dependencia | Ver registro completo | Doliente, código del proyecto o tercero, fecha y confirmación de la contraparte |

No propongo dolientes aquí; eso se hace cuando la PMO lo pida.

### Dependencias en riesgo
| Id | Depende de | Confirmada | Qué pasó |
|---|---|---|---|
| PRY-199/D1, 206/D1, 209/D1 | «Proveedor del core cooperativo» (¿PRY-202?) | No | Declarada solo en el informe de avance; ningún documento de PRY-202 la reconoce. Si es PRY-202, su cierre de línea base (2026-05-16) ya pasó. |
| PRY-201/D1, 207/D1, 208/D1, 209/D2, 211/D1 | Proveedor de la última entrega (PRY-211: Datos para Cooperativas S.A.S., CT-650; PRY-208: CT-349; PRY-209: CT-951; PRY-201 y PRY-207: sin contrato en la carpeta) | No: el informe dice que el proveedor no ha confirmado la fecha | Declarada, no acordada. Sin código de proyecto porque depende de un tercero, no de otro proyecto. |

Cruce de movimiento de fechas entre proyectos: no se puede hacer. Ninguna dependencia cita un código de proyecto, así que no tengo con qué cruzar.

### Registro completo
| Id | Tipo | Qué | Prob. | Impacto | Doliente | Fecha | Último movimiento |
|---|---|---|---|---|---|---|---|
| PRY-200/R1 | Riesgo | Concentración del conocimiento en una sola persona | — | — | — | — | — |
| PRY-200/R2 | Riesgo (no registrado) | Proveedor sin equipo completo en la siguiente fase | — | — | — | — | dicho 2026-10-17 |
| PRY-202/R1 | Riesgo | Aprobación del reglamento por el Consejo de Administración | — | — | — | — | — |
| PRY-202/R2 | Riesgo | Concentración del conocimiento en una sola persona | — | — | — | — | — |
| PRY-203/R1 | Riesgo | Cambio normativo del supervisor que puede mover el alcance | — | — | — | — | — |
| PRY-203/R2 | Riesgo | Concentración del conocimiento en una sola persona | — | — | — | — | — |
| PRY-204/R1 | Riesgo | Concentración del conocimiento en una sola persona | — | — | — | — | — |
| PRY-204/R2 | Riesgo | Cambio normativo del supervisor que puede mover el alcance | — | — | — | — | — |
| PRY-205/R1 | Riesgo | Aprobación del reglamento por el Consejo de Administración | — | — | — | — | — |
| PRY-208/R1 | Riesgo | Aprobación del reglamento por el Consejo de Administración | — | — | — | — | — |
| PRY-210/R1 | Riesgo | Cambio normativo del supervisor que puede mover el alcance | — | — | — | — | — |
| PRY-211/R1 | Riesgo | Cambio normativo del supervisor que puede mover el alcance | — | — | — | — | — |
| PRY-199/D1 | Dependencia | Proveedor del core cooperativo | — | — | — | — | informe 2026-10-15 |
| PRY-206/D1 | Dependencia | Proveedor del core cooperativo | — | — | — | — | informe 2026-10-10 |
| PRY-209/D1 | Dependencia | Proveedor del core cooperativo | — | — | — | — | informe 2026-10-06 |
| PRY-201/D1 | Dependencia | Proveedor sin fecha confirmada de la última entrega | — | — | — | — | informe 2026-10-15 |
| PRY-207/D1 | Dependencia | Ídem | — | — | — | — | informe 2026-10-06 |
| PRY-208/D1 | Dependencia | Ídem | — | — | — | — | informe 2026-10-08 |
| PRY-209/D2 | Dependencia | Ídem | — | — | — | — | informe 2026-10-06 |
| PRY-211/D1 | Dependencia | Ídem | — | — | — | — | informe 2026-10-15 |
| PRY-199/I1 | Incidencia | Hallazgo de seguridad en la revisión de arquitectura | | | — | desde 2026-10-15 | — |
| PRY-199/I2 | Incidencia | Prueba de carga bajo el umbral, se repite | | | — | desde 2026-10-15 | — |
| PRY-200/I1 | Incidencia | Prueba de carga bajo el umbral, se repite | | | — | desde 2026-10-07 | — |
| PRY-200/I2 | Incidencia | Dos semanas perdidas por rotación de un desarrollador clave | | | — | desde 2026-10-07 | — |
| PRY-200/I3 | Incidencia | Salida reprogramada por el cierre contable de fin de mes | | | — | desde 2026-10-07 | — |
| PRY-201/I1 | Incidencia (revisar) | Ajuste del plan de pruebas con seguridad | | | — | desde 2026-10-15 | — |
| PRY-201/I2 | Incidencia | Hallazgo de seguridad en la revisión de arquitectura | | | — | desde 2026-10-15 | — |
| PRY-203/I1 | Incidencia | Prueba de carga bajo el umbral, se repite | | | — | desde 2026-10-14 | — |
| PRY-203/I2 | Incidencia | Hallazgo de seguridad en la revisión de arquitectura | | | — | desde 2026-10-14 | — |
| PRY-204/I1 | Incidencia | Prueba de carga bajo el umbral, se repite | | | — | desde 2026-09-25 | — |
| PRY-205/I1 | Incidencia | Salida reprogramada por el cierre contable de fin de mes | | | — | desde 2026-10-14 | — |
| PRY-206/I1 | Incidencia | Dos semanas perdidas por rotación de un desarrollador clave | | | — | desde 2026-10-10 | — |
| PRY-206/I2 | Incidencia (revisar) | Ajuste del plan de pruebas con seguridad | | | — | desde 2026-10-10 | — |
| PRY-207/I1 | Incidencia | El Consejo pidió ajustar el reglamento antes del piloto | | | — | desde 2026-10-06 | — |
| PRY-207/I2 | Incidencia (revisar) | Ajuste del plan de pruebas con seguridad | | | — | desde 2026-10-06 | — |
| PRY-207/I3 | Incidencia | Dos semanas perdidas por rotación de un desarrollador clave | | | — | desde 2026-10-06 | — |
| PRY-208/I1 | Incidencia | Dos semanas perdidas por rotación de un desarrollador clave | | | — | desde 2026-10-08 | — |
| PRY-210/I1 | Incidencia (revisar) | Ajuste del plan de pruebas con seguridad | | | — | desde 2026-10-09 | — |

«—» = el documento no lo dice; no se rellenó.

## Lo que no sé
- Quién es el doliente de cualquier ítem, y cuándo se movió por última vez: ninguna ficha lo trae.
- Si «proveedor del core» es PRY-202, y si el proveedor de las notas de PRY-200 es Soluciones Solidarias.
- Sin ficha de RAID previa que compare, no puedo decir qué ítems se cerraron ni cuáles son nuevos desde la última corrida.
- PRY-200 tiene su propia ficha del gerente (`ficha-pm.json`); la usé solo como contexto, no como corrección del registro.

## Después
Los ítems que cumplen el criterio de escalamiento (afectan a otro proyecto) son las tres dependencias del core, el riesgo de equipo del proveedor de PRY-200 y las incidencias de seguridad y carga repetidas. Puedo preparar la decisión formulada para cada una para el comité del 2026-10-24, y proponer dolientes (proponer, no asignar). No lo he hecho: espero tu indicación.
