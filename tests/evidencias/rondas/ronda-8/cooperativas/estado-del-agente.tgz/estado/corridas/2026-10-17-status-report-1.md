# Corrida del 2026-10-17 · status-report

13 proyectos · 26 s · 69 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 25 |
| `commitment_overdue` | 10 |
| `progress_vs_plan` | 7 |
| `vendor_deliverable_late` | 5 |
| `commitment_undated` | 4 |
| `declared_vs_evidence` | 4 |
| `milestone_overdue` | 4 |
| `commitment_rescheduled` | 3 |
| `change_without_baseline` | 2 |
| `silent` | 1 |
| `variance_cost` | 1 |
| `budget_committed` | 1 |
| `variance_time` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

Status report de PRY-204: amarillo 62% declarado el 2026-09-25; hito Diseño funcional sin evidencia (54 días), silencio de 22 días, incidencia de prueba de carga sin seguimiento. Sin dato: autoridad, fase, última reunión, dueños de riesgos.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

Informe sobre la ficha `estado/records/PRY-204.json`, actualizada el 2026-10-17. Cifras recalculadas con `portafolio.py compute` al 2026-10-17.

## PRY-204 Tarjeta débito para asociados — estado al 2026-10-17

**Declara el gerente (Javier Hoyos):** amarillo · 62% · al 2026-09-25 (hace 22 días)
**Sustento documental:** sin sustento (parcial). El único documento posterior al plan es el propio informe de avance. Ninguna fuente está marcada como evidencia: 0 de evidencia, 0 de declaración y 14 sin marcar.
**Lo que el semáforo no explica:** `milestone_met_without_evidence` (Diseño funcional aprobado) y `silent` (22 días sin documentos)
**Último documento:** 2026-09-25 (informe de avance) · **Última reunión:** sin dato; no hay actas ni transcripciones en la carpeta

El 62% queda dentro de lo que el plan sostiene según los hitos (entre 33% y 67%, con 1 de 3 hitos cumplidos). Esa cifra sale del cálculo del script; la ficha no trae más detalle.

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2027-06-17 | 2027-06-17 | 0 días (0 replanificaciones) |
| Presupuesto aprobado | COP 1.200.000.000 | COP 1.200.000.000 | Proyección COP 1.180.865.844 (-1,6%) |

Ejecutado: COP 329.106.175 (27,4%). Comprometido: COP 565.373.056 (47,1%). Disponible real: COP 634.626.944. Cifras y proyección declaradas en el informe del 2026-09-25.

Replanificaciones: 0. Solo existe la versión 1 de la línea base, aprobada el 2026-03-19 por el Comité de Riesgos.

### Hitos
| Hito | Base | Vigente | Estado | Evidencia |
|---|---|---|---|---|
| Diseño funcional aprobado | 2026-08-24 | 2026-08-24 | Cumplido (declarado) | **Ninguna.** Sin evidencia hace 54 días |
| Ambiente de pruebas certificado | 2027-01-20 | 2027-01-20 | Pendiente | n/a |
| Integración con el core cooperativo | 2027-06-17 | 2027-06-17 | Pendiente | n/a |

### Dónde no coincide
- **Hito cumplido sin evidencia.** El cronograma v1 (2026-03-19) fija el hito el 2026-08-24, y la ficha lo da por cumplido sin ningún documento que lo sustente. Son 54 días desde la fecha.
- **Verde o amarillo frente al silencio.** El gerente declara amarillo el 2026-09-25 y no hay un solo documento posterior. Lleva 22 días en silencio; el umbral configurado es 15.
- **Incidencia abierta.** El informe del 2026-09-25 dice que la prueba de carga no alcanzó el umbral pactado y se repite. No hay ningún documento posterior que diga si se repitió ni con qué resultado.

### Abierto
**Riesgos e incidencias sin movimiento:**
- Incidencia: la prueba de carga no alcanzó el umbral y se repite (desde 2026-09-25, 22 días; sin dueño).
- Riesgo: concentración del conocimiento en una sola persona (sin dueño, probabilidad, impacto ni fecha de último movimiento).
- Riesgo: cambio normativo del supervisor que puede mover el alcance (sin dueño, probabilidad, impacto ni fecha de último movimiento).

**Compromisos vencidos:** ninguno registrado. No hay compromisos en la ficha porque no hay actas de reunión; eso no equivale a que no existan.
**Dependencias sin confirmar:** ninguna registrada. El hito «Integración con el core cooperativo» sugiere relación con PRY-202 (Core cooperativo), pero ningún documento la declara como dependencia.

### Sin dato
- Autoridad del proyecto (`identity.authority`): sin dato. Sin ella no se puede decir si los riesgos exceden la autoridad del gerente.
- Fase (`identity.phase`): sin dato.
- Dueño, probabilidad e impacto de los dos riesgos; dueño de la incidencia.
- Última reunión, compromisos, cambios y proveedores: no hay documentos que los cubran.
- Motivo por el que se declara cumplido el diseño funcional.

### Después
No hay desviación de plazo ni de costo por encima del umbral (10%). Lo que sí merece atención es el hito sin evidencia, el silencio y la incidencia de la prueba de carga. Puedo preparar el punto de comité para el 2026-10-24 si lo quieres.

---
Criterio Portfolio 0.3.13 · Ficha de PRY-204 actualizada el 2026-10-17 (declaración del 2026-09-25) · Campos inciertos: `identity.authority`, `identity.phase` · Términos aceptados el 2026-10-17 por José Francisco Ñáñez: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.13
