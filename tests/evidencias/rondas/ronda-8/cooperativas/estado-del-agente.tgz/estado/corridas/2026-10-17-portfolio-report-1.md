# Corrida del 2026-10-17 · portfolio-report

13 proyectos · 76 documentos, 0 releídos y 76 sin cambio · 35 s · 69 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 25 |
| `commitment_overdue` | 10 |
| `progress_vs_plan` | 7 |
| `vendor_deliverable_late` | 5 |
| `commitment_undated` | 4 |
| `declared_vs_evidence` | 4 |
| `milestone_overdue` | 4 |
| `commitment_rescheduled` | 3 |
| `change_without_baseline` | 2 |
| `silent` | 1 |
| `variance_cost` | 1 |
| `budget_committed` | 1 |
| `variance_time` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

El informe quedó en `/home/claude/banco/ronda-8/cooperativas/espacio/reportes/index.html`.

Primer informe, sin delta. 4 verdes contradichos (PRY-200, 202, 205, 207); PRY-211 con factura sin entregable aceptado; confirmación mensual pendiente por sesión sin interfaz.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

# Portafolio — 2026-10-17

Fichas cargadas: 13 (PRY-199 a PRY-211), todas de la corrida del 2026-10-17; ninguna con más de una semana sin barrido. Términos vigentes (versión 0.3.13), aceptados por José Francisco Ñáñez el 2026-10-17.

13 proyectos · 12 con hallazgos · 69 señales · último barrido 2026-10-17

## Qué cambió desde la corrida anterior
Sin cambios desde la corrida anterior: la única instantánea (2026-10-17) es de hoy, así que este informe es el punto de partida y no hay delta.

## Contradicciones abiertas
Vacía: ningún proyecto tiene campos en conflicto entre dos fuentes.

## Hitos vencidos sin evidencia
| Proyecto | Hito | Fecha | Días |
|---|---|---|---|
| PRY-206 | Ambiente de pruebas certificado | 2026-10-06 | 11 |
| PRY-207 | Piloto con asociados | 2026-10-09 | 8 |
| PRY-208 | Piloto con asociados | 2026-10-06 | 11 |
| PRY-211 | Salida a producción | 2026-10-14 | 3 |

Además hay 28 hitos declarados "cumplido" sin evidencia en el documento (p. ej. PRY-202: 4 hitos, hasta 349 días; PRY-200: 4 hitos; PRY-210: 3; PRY-205: 3).

## Proyectos en silencio
| Proyecto | Días | Último documento |
|---|---|---|
| PRY-204 Tarjeta débito para asociados | 22 | 2026-09-25 (informe de avance) |

## Dependencias en riesgo
Vacía: ningún proyecto declara dependencias por código.

## Sin sustento (declarado verde contradicho por la evidencia)
| Proyecto | Declara | Qué lo respalda |
|---|---|---|
| PRY-200 Crédito de libranza digital | verde (48 %) | Contradice 5 señales: avance 48 % frente a 100 % que sostiene el plan, 4 hitos sin evidencia, 5 compromisos vencidos, 3 reprogramados varias veces, 3 entregables del proveedor atrasados |
| PRY-202 Core cooperativo | verde (65 %) | Plan sostiene 100 %; 4 hitos sin evidencia; 2 compromisos vencidos |
| PRY-205 Prevención de lavado de activos | verde (48 %) | Plan sostiene 100 %; 3 hitos sin evidencia; proyección de costo +23,5 % sobre lo aprobado |
| PRY-207 Microcrédito rural | verde (36 %) | Plan sostiene 75–100 %; piloto vencido 8 días; 2 hitos sin evidencia |

## Vacíos de información
- Los 13 proyectos no tienen autoridad ni fase identificadas.
- PRY-202, 205, 208, 209, 210 no tienen producto asociado.
- Campos con más de 12 meses de antigüedad: PRY-202, 203, 207, 210.
- Proveedor sin dato de facturación: PRY-199, PRY-200.

## Otras señales por proyecto
- **PRY-211 Cobranza digital** (declarado rojo): proveedor Datos para Cooperativas facturó COP 376.332.909 sin ningún entregable aceptado; 2 entregables atrasados (160 y 69 días).
- **PRY-208 Motor de crédito**: atraso de 117 días (29,6 %) contra la línea base original; CC-01 aprobado.
- **PRY-203 Aportes sociales**: CC-01 aprobó 112 días sin mover la línea base.
- **PRY-206 Pagos con QR**: 90 % del presupuesto comprometido; avance declarado 83 % frente a 25–50 % que sostiene el plan.
- **PRY-209**: avance 27 % frente a 40–60 % del plan; 1 compromiso vencido.
- **PRY-210**: avance 81 % frente a 100 % del plan; 1 compromiso sin fecha.

## Estado general
| Proyecto | Declarado | Sustento | Desviación vs original | vs vigente | Replanificaciones |
|---|---|---|---|---|---|
| PRY-199 | verde | sin señales | 0 | 0 | 0 |
| PRY-200 | verde | contradicho | 0 | 0 | 0 |
| PRY-201 | amarillo | 1 señal | 0 | 0 | 0 |
| PRY-202 | verde | contradicho | 0 | 0 | 0 |
| PRY-203 | verde | 1 señal | 0 | 0 | 0 |
| PRY-204 | amarillo | silencio 22 d | 0 | 0 | 0 |
| PRY-205 | verde | contradicho | 0 | 0 | 0 |
| PRY-206 | amarillo | 5 señales | 0 | 0 | 0 |
| PRY-207 | verde | contradicho | 0 | 0 | 0 |
| PRY-208 | amarillo | 5 señales | +117 d (29,6 %) | 0 | 1 |
| PRY-209 | amarillo | 4 señales | 0 | 0 | 0 |
| PRY-210 | amarillo | 5 señales | 0 | 0 | 0 |
| PRY-211 | rojo | 7 señales | 0 | 0 | 0 |

## Necesito que confirmes
Este mes toca la confirmación de cinco campos. En esta sesión no hay quien responda, así que no se formularon; quedan pendientes para la próxima corrida con interlocutor.

## Dónde quedó el informe
Carpeta `reportes/` (la que sirve Rostrum), 25 páginas:
- `reportes/index.html` — vista por campo con la cadena de evidencia completa. Para quien va a actuar.
- `reportes/decisiones.html` — vista por decisión. Para el patrocinador: solo lo que excede la facultad de quien gerencia, como pregunta cerrada y con la consecuencia de no decidir.
- Una página por proyecto (`PRY-199.html` … `PRY-211.html`), más páginas de productos.
- El PDF sale de imprimir el HTML.

Nota: la configuración tiene formato `pptx`; se usó `html` por el argumento de esta invocación.

---
Pie: Criterio Portfolio v0.3.13 · fichas aplicadas: 13, todas de 2026-10-17 · campos inciertos: autoridad y fase en los 13 proyectos, más los campos de más de 12 meses citados arriba · Términos: https://www.josenanez.com/es/agents/criterio-pmo/legal
