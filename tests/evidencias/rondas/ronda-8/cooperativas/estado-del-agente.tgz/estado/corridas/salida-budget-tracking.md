Documentos: ficha PRY-206 (acta de constitución 2026-04-15; informe de avance 2026-10-10), cifras de `portafolio.py compute` al 2026-10-17.

## Presupuesto — PRY-206 Pagos con QR al 2026-10-17
**Moneda:** COP (única; no hay contratos en otra moneda ni conversión)

| | Monto (COP) | % del aprobado | Fuente | Fecha |
|---|---|---|---|---|
| Aprobado | 3.300.000.000 | 100% | 00-gobierno/2026-04-15-acta-constitucion.md | 2026-04-15 |
| Comprometido | 2.970.911.597 | 90.0% | 20-seguimiento/2026-10-10-informe-avance.md | 2026-10-10 |
| Ejecutado | 1.806.185.462 | 54.7% | 20-seguimiento/2026-10-10-informe-avance.md | 2026-10-10 |
| Proyección al cierre | 3.444.173.074 | excede el aprobado en 4.4% | 20-seguimiento/2026-10-10-informe-avance.md | 2026-10-10 |

**Disponible real** (aprobado menos comprometido): COP 329.088.403

### Contra la línea base
No hay línea base de presupuesto distinta de la original: la única línea base (v1, 2026-04-15) fija el aprobado en COP 3.300.000.000 y no registra modificaciones de presupuesto. El aprobado vigente es el original.
Replanificaciones de presupuesto: 0 (cambios registrados: 0).

### Ejecución frente a avance
Ejecutado 54.7% · Hitos cumplidos 1 de 4 · El avance declarado (83%) no lo sustenta el plan: el cronograma respalda entre 25% y 50% (brecha de 33 puntos). El hito "Diseño funcional aprobado" figura cumplido sin evidencia, y "Ambiente de pruebas certificado" lleva 11 días vencido (era 2026-10-06). El ejecutado (54.7%) queda por encima de lo que el plan sustenta (25–50%) y muy por debajo del 83% declarado.

### Alertas
- **Comprometido en el umbral (90.0%, umbral 90%):** el presupuesto está prácticamente asignado; solo quedan COP 329.088.403 sin comprometer, aunque se haya ejecutado 54.7%. La holgura aparente (45.3% sin ejecutar) no es real.
- **Proyección por encima del aprobado en 4.4%.** Es una declaración del informe de avance del 2026-10-10, no un dato duro; no hay movimiento de presupuesto posterior que la contradiga ni la confirme.
- **Avance declarado sin sustento:** 83% declarado contra 25–50% que respalda el plan; 1 de 4 hitos, y ese sin evidencia.
- **Compromiso vencido:** Jorge Medina, "Entregar el punto 14", vencido desde 2026-10-10 (7 días), según el comité semanal del 2026-10-16.

### Sin dato
- Línea base de presupuesto vigente distinta de la original: no declarada (se asume que no hubo cambios porque no hay ninguno registrado).
- Autoridad y fase del proyecto: no declaradas en la ficha.
- Detalle por proveedor: la ficha no registra contratos de proveedor para PRY-206.

Siguiente paso posible: como la proyección excede el aprobado, puedo preparar la solicitud de cambio de presupuesto; el comprometido está en el tope, pero no hay proveedores registrados para detallar.

---
Rigor: cifras copiadas de la salida de `compute`; el porcentaje de la proyección sobre el aprobado se expresa como el exceso que el script calculó (4.4%). Las cuatro cifras provienen de declaraciones en documentos (acta e informe de avance), ninguna de un sistema contable; la verificación es de quien lee. Nada fuera de los documentos es conocido por este informe.
