# Corrida del 2026-10-17 · document-index

13 proyectos · 15 s · 69 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 25 |
| `commitment_overdue` | 10 |
| `progress_vs_plan` | 7 |
| `vendor_deliverable_late` | 5 |
| `commitment_undated` | 4 |
| `declared_vs_evidence` | 4 |
| `milestone_overdue` | 4 |
| `commitment_rescheduled` | 3 |
| `change_without_baseline` | 2 |
| `silent` | 1 |
| `variance_cost` | 1 |
| `budget_committed` | 1 |
| `variance_time` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

76 documentos sin cambio, 0 por releer. 37 citas de PRY-200 marcadas source_missing aunque los archivos existen; probable fallo de resolución de rutas relativas, sin confirmar. No se corrigió ninguna ficha.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## Carpeta al 2026-10-17

**Documentos:** 76 · **Sin cambio:** 76 · **Hay que releer:** 0

### Cambió el contenido
Ninguno.

### Solo se reguardó
Ninguno.

### Renombrado o movido
Ninguno.

### Ya no está
Ninguno.

### Citas que dejaron de resolver
El índice marca 37 citas de PRY-200 como "source_missing". Los archivos citados sí están en la carpeta del proyecto, así que no se borraron ni se movieron. Lo más probable es que el índice no resuelva las citas escritas relativas a la carpeta del proyecto (`PRY-200-crédito-de-libranza-digital/`). No lo confirmé en el código del índice.

| Proyecto | Campo | Documento citado |
|---|---|---|
| PRY-200 | identity (code, name, business_area, product, sponsor, manager, committee) — 7 campos | 00-gobierno/2025-12-18-acta-constitucion.md |
| PRY-200 | declared (status, progress_pct, as_of) — 3 campos | 20-seguimiento/2026-10-07-informe-avance.md |
| PRY-200 | plan.start_date | 00-gobierno/2025-12-18-acta-constitucion.md |
| PRY-200 | plan.end_date y plan.milestones[0..4] (name, baseline_date, current_date, state) — 21 campos | 10-plan/2025-12-18-cronograma-v1.xlsx |
| PRY-200 | plan.milestones[2].evidence | 20-seguimiento/2026-10-07-acta-recibo-integración-con-el-core-cooperativo.md |
| PRY-200 | money.currency, money.approved | 00-gobierno/2025-12-18-acta-constitucion.md |
| PRY-200 | money.committed, executed, projection | 20-seguimiento/2026-10-07-informe-avance.md |

### Formatos que no se pudieron leer
El índice no reportó ninguno. Este comando cuenta y compara; no lee contenido.

### Qué sigue
No hay nada que releer, por lo que `projects_to_recompute` está vacío y no hace falta `/portfolio-scan`. Queda abierto el asunto de las 37 citas de PRY-200: confirmar si es un fallo de resolución de rutas antes de tocar la ficha. No se corrigió ninguna cita.
