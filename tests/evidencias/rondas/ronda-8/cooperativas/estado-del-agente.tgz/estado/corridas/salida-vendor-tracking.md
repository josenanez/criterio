**Sale de:** `00-gobierno/2025-12-13-contrato-ct-410.md`, `00-gobierno/ficha-pm.json`, las cuatro actas de recibo de `20-seguimiento/`, `20-seguimiento/2026-10-07-informe-avance.md`, las seis minutas de `30-reuniones/` y `2026-10-17-notas-reunion.txt`, todos de PRY-200. Las cifras derivadas salen de `portafolio.py compute` (al 2026-10-17). Términos vigentes: aceptados por José Francisco Ñáñez, v1.1, 2026-10-17.

## Proveedores — PRY-200 Crédito de libranza digital al 2026-10-17

### Soluciones Solidarias S.A.S. — contrato CT-410
**Vigencia:** sin dato (el contrato solo trae fecha de firma, 2025-12-13) · **Preaviso de no renovación:** sin dato · **Vence el:** sin dato

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento del módulo (194.058.672 COP) | 2026-03-14 | `unknown` — el contrato dice «pendiente»; vencido hace 217 días | ninguna | sin dato |
| Bolsa de horas de desarrollo (194.058.672 COP) | 2026-05-29 | `unknown` — el contrato dice «en curso»; vencido hace 141 días | ninguna | sin dato |
| Parametrización de líneas de crédito (194.058.672 COP) | 2026-08-13 | `unknown` — el contrato dice «en curso»; vencido hace 65 días | ninguna | sin dato |

El script da: 3 entregables, 0 aceptados, 3 con fecha pasada y sin evidencia (`late`), 0 `accepted_without_evidence`, `invoiced` = null, 3 montos declarados, monto aceptado 0. No se levantó `vendor_invoiced_without_delivery`, porque no hay ninguna factura declarada.

### Dónde no cuadra
| Qué | Dice el contrato | Dice la evidencia | Fuentes |
|---|---|---|---|
| Estado de «Bolsa de horas» y «Parametrización» | «en curso» | La ficha los registra `pending` y ningún documento los respalda. Las fechas comprometidas ya pasaron. | contrato CT-410; `ficha-pm.json` |
| Actas de recibo del proyecto | La condición de pago exige acta de recibo firmada por el gerente por cada entregable del contrato | Hay cuatro actas firmadas por Jorge Medina y ninguna nombra un entregable de CT-410. Recibieron «Validar el ambiente 4» (2026-09-12), «Entregar el punto 8» (2026-09-26), «Integración con el core cooperativo» (2026-10-07) y «Aprobar el diseño 13» (2026-10-10). | `20-seguimiento/` (4 actas) |
| Hito «Salida a producción» | — | El informe del 2026-10-07 lo da por cumplido (5 de 5 hitos), pero declara 48 % de avance. Los cuatro hitos «cumplidos» sin evidencia suman 4 señales `milestone_met_without_evidence`. La brecha de avance es de 52,0 puntos. | `informe-avance.md`; compute |

La «Integración con el core cooperativo» tiene acta de recibo, pero no es un entregable de CT-410. No se puede atribuir a este proveedor ni a ninguna factura.

### Sin evidencia de recibo
| Entregable | Marcado como | Desde |
|---|---|---|
| Licenciamiento del módulo | pendiente (contrato) | 2026-03-14 |
| Bolsa de horas de desarrollo | en curso (contrato) | 2026-05-29 |
| Parametrización de líneas de crédito | en curso (contrato) | 2026-08-13 |

Ninguno está declarado entregado ni aceptado. Lo que hay es retraso sin recibo, no entrega sin evidencia.

### Compromisos del proveedor vencidos
| Qué | Prometido en | Para | Días |
|---|---|---|---|
| Ninguno registrado | — | — | — |

Ningún compromiso del proveedor figura con responsable y fecha en las minutas. En `2026-10-17-notas-reunion.txt`: Óscar Ramírez, «revisión con el proveedor», para 2026-10-27, aún no vence. Los compromisos vencidos del proyecto son de personas del equipo y no los de este proveedor: 5 vencidos, 3 sin fecha y 3 reprogramados (la lista completa está en `compute`).

### Sin dato
- **Vigencia, terminación, renovación automática y preaviso de CT-410:** el contrato en la carpeta no los trae. No se puede decir si el preaviso vence antes del cierre. El cierre planeado del proyecto es 2026-10-01, ya pasado.
- **Facturación:** ningún documento declara facturas ni pagos a este proveedor (`invoiced` = null). No se puede cruzar contra lo facturado.
- **Riesgo no registrado:** las notas de hoy dicen que el proveedor podría no llegar con el equipo completo a la siguiente fase; «nadie lo anotó como riesgo». Hay que llevarlo al RAID.
- **Fase 2 / continuidad:** nada indica qué es «la siguiente fase» ni si está cubierta por CT-410.

## Después
- Sin preaviso conocido no hay un vencimiento que avisar. Pide el contrato completo o sus anexos de vigencia.
- No hay entregables facturados sin evidencia, porque no hay facturas declaradas. Si Finanzas ya pagó algo contra CT-410, hay que confirmarlo: la condición de pago exige un acta que no existe.
- Ofrezco llevar a comité: (1) tres entregables vencidos sin recibo, el más antiguo con 217 días; (2) el informe en verde con 52,0 puntos de brecha de avance; (3) el riesgo del equipo del proveedor sin registrar.

---
**Pie de rigor:** borrador de trabajo, no asesoría ni decisión. Cada dato viene del documento citado; la verificación es de quien lo lea. No sé lo que se habló fuera de los documentos de la carpeta. Cifras derivadas copiadas de `portafolio.py compute`; lo que el script no calcula no se escribe.
