**Fichas cargadas:** las 13 de `estado/records` (PRY-199 a PRY-211), selladas el 2026-10-17, y la salida de `portafolio.py compute` al 2026-10-17. Criterios aplicados: raid-taxonomy y governance-artifacts. Para RAID, cambios y proveedores usé las salidas de esta misma fecha (`salida-raid-log`, `salida-change-control`, `salida-vendor-tracking`). Términos vigentes: v1.1, aceptados por José Francisco Ñáñez el 2026-10-17.

# Comité de proyectos — 2026-10-24
5 decisiones · 6 escalamientos sin decisión asociada · 12 de 13 proyectos con hallazgos (69 señales en total)

Cuatro proyectos declaran verde y el cálculo lo contradice: PRY-200, PRY-202, PRY-205 y PRY-207.

## Decisiones del comité anterior
| Decisión | Fecha | Qué pasó | Estado |
|---|---|---|---|
| Sin dato | — | Ninguna carpeta trae acta de un comité de dirección ni de decisiones tomadas. Los `comite-semanal` de PRY-200, 202, 206, 209, 210 y 211 son comités de proyecto y solo traen tablas de compromisos. | No se puede cerrar el ciclo anterior. Que no haya acta es en sí un hallazgo. |

## Decisiones de hoy

### [1] ¿Quién tiene la autoridad para aprobar cambios, presupuesto y fechas en cada proyecto?
**Proyecto:** los 13 · **Quién decide:** el comité mismo; es la pregunta previa a las demás · **Si no se decide hoy:** los puntos 2 a 5 no tienen a quién dirigirse. `identity.authority` está sin dato en 13 de 13 proyectos y ningún acta declara umbrales de autoridad.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. El comité declara la autoridad por proyecto y la deja en cada acta | Sin efecto | Sin efecto | Sin efecto |
| B. Todo cambio va al comité hasta que haya umbrales escritos | Sin efecto | Más espera en cada cambio | No declarado |

**Recomendación:** A, con B como regla transitoria. Hoy, de hecho, ya opera B por defecto: sin autoridad declarada nadie puede aprobar por debajo del comité.

### [2] PRY-211 Cobranza digital: ¿se detienen los pagos a Datos para Cooperativas S.A.S. (CT-650) hasta que haya acta de recibo?
**Proyecto:** PRY-211 · **Quién decide:** sin autoridad declarada; lo lleva el comité · **Si no se decide hoy:** se sigue pagando sin recibo. Hay 376.332.909 COP facturados, 0 entregables aceptados de 2, y los dos están vencidos (licenciamiento, 160 días; bolsa de horas, 69 días).

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Suspender pagos y exigir actas de recibo por entregable | Sin efecto | Puede frenar al proveedor; la salida a producción ya está vencida 3 días (2026-10-14) | Sin costo adicional declarado |
| B. Seguir pagando y pedir las actas después | Sin efecto | Sin efecto | Se agrava la exposición: 376.332.909 COP ya sin respaldo |
| C. Pedir primero a Finanzas el detalle de lo pagado, y decidir en una semana | Sin efecto | Una semana más | No declarado |

**Recomendación:** C, y A si Finanzas confirma que se pagó contra facturas sin acta. Hay que verificar el pago real: el dato de «facturado» sale de un documento, no de Finanzas.

### [3] PRY-208 Motor de crédito: ¿se regulariza CC-01 y se tramita el cambio de +30 días de la salida a producción?
**Proyecto:** PRY-208 · **Quién decide:** sin autoridad declarada; el comité de proyecto del acta es el Comité de Riesgos · **Si no se decide hoy:** la salida sigue en 2027-04-20, a 117 días (29,6 %) de la línea base original, con el piloto vencido hace 11 días.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Regularizar CC-01 (citar el acta del comité que la autorizó) y devolver el cambio de +30 días hasta que traiga solicitante, motivo y costo | CC-01 es una ampliación de alcance | Salida 2027-04-20 | Aprobado 18.000.000.000 COP; proyección 18.533.650.569 (+3,0 %); CC-01 pide 234.000.000 COP más |
| B. Aprobar ya el cambio de +30 días (salida 2027-05-20) | No declarado | +30 días contra la vigente; +147 contra la original | No declarado |

**Recomendación:** A. La solicitud de +30 días llegó sin firmante ni motivo, y no se puede evaluar. La línea base 3 no se registra sin aprobación de quien tenga autoridad. Además hay que confirmar con Talento Solidario Ltda. que CT-349 cubre hasta 2027-05-20: el contrato no trae vigencia.

### [4] PRY-203 Aportes sociales en línea: ¿el comité reconoce CC-01 y se registra la línea base?
**Proyecto:** PRY-203 · **Quién decide:** sin autoridad declarada · **Si no se decide hoy:** CC-01 sigue «aprobada» sin cita al acta y sin línea base: +112 días y 224.000.000 COP adicionales con 0 días movidos en la línea base. El presupuesto del proyecto es de 18.000.000.000 COP.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Confirmar con acta que el comité la aprobó y registrar la línea base nueva | Ampliación de alcance | +112 días | 224.000.000 COP adicionales |
| B. No reconocerla hasta que se presente el acta | Alcance anterior | Sin movimiento de la línea base | Sin costo adicional |

**Recomendación:** B hasta que aparezca el acta; después, A. La ficha dice «el comité» sin indicar cuál ni cuándo. El informe lo declara verde con 35 %.

### [5] PRY-205 Prevención de lavado de activos: ¿se reconoce el sobrecosto y se corrige el estado verde?
**Proyecto:** PRY-205 · **Quién decide:** sin autoridad declarada · **Si no se decide hoy:** el proyecto sigue en verde con una proyección de 5.188.200.936 COP contra 4.200.000.000 aprobados (+23,5 %), avance declarado de 48 % con 3 de 3 hitos cumplidos (brecha de 52,0 puntos) y fin planeado el 2026-09-21, ya pasado.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Pedir al gerente un cambio formal por el sobrecosto, con motivo, y reclasificar el estado | A definir por el gerente | No declarado | Proyección +23,5 % |
| B. Reducir alcance para quedar en 4.200.000.000 COP | Se reduce; no está dicho cuánto | No declarado | Dentro de lo aprobado |
| C. Dejarlo como está | Sin efecto | Sin efecto | Sobrecosto sin aprobar |

**Recomendación:** A. El exceso supera el umbral de 10 % y nadie lo ha pedido formalmente. B solo si el comité no está dispuesto a ampliar presupuesto. Los tres hitos «cumplidos» no traen evidencia de recibo: no sé si el avance real es el declarado.

## Escalamientos sin decisión asociada
| Proyecto | Qué | Desde cuándo | Qué se necesita |
|---|---|---|---|
| PRY-199, 206, 209 (y ¿PRY-202?) | Tres proyectos dependen del «proveedor del core cooperativo». Ningún documento dice que sea PRY-202. | Informes del 2026-10-06, 10-10 y 10-15 | Que la PMO confirme si es PRY-202 y nombre un doliente. Si lo es: PRY-202 declara verde con 65 % de avance, su fin planeado era 2026-05-16 y sus 4 hitos «cumplidos» no tienen evidencia. Tiene 2 compromisos vencidos. |
| PRY-200 | Crédito de libranza: verde declarado con 48 %, 4 hitos «cumplidos» sin evidencia, 5 compromisos vencidos, 3 sin fecha y 3 reprogramados. Felipe Arango lo reprogramó 6 veces («enviar el documento 1», original 2026-09-12). Los 3 entregables de CT-410 (Soluciones Solidarias) están vencidos, el más antiguo con 217 días, y ninguno trae acta. | Informe del 2026-10-07 | Desmentir o sustentar el verde. Pedir el contrato completo (vigencia y preaviso: sin dato). |
| PRY-200 / PRY-199 | Riesgo dicho en reunión el 2026-10-17 y nadie lo registró: el proveedor podría no llegar con el equipo completo. Las notas no nombran al proveedor; Soluciones Solidarias es proveedor de CT-410 y de CT-199 (primer entregable 2026-11-16). Es una inferencia. | 2026-10-17 | Confirmar proveedor, registrarlo y asignar doliente. |
| PRY-199, 201, 203, 204 | Incidencias repetidas sin doliente: hallazgo de seguridad en la revisión de arquitectura (PRY-199, 201, 203) y prueba de carga bajo el umbral (PRY-199, 200, 203, 204). No sé si cada una es un solo hallazgo transversal. | 2026-09-25 a 2026-10-15 | Confirmar si es un hallazgo y nombrar un doliente. |
| PRY-206 | Pagos con QR: 90,0 % comprometido, disponible real 329.088.403 COP; el hito «Ambiente de pruebas certificado» vencido hace 11 días; avance declarado 83 % contra 25–50 % que sostiene el plan. | Informe del 2026-10-10 | Que el gerente explique el avance y el presupuesto antes de comprometer más. |
| PRY-204 y PRY-207 | PRY-204 lleva 22 días sin informe (desde 2026-09-25). PRY-207 declara verde y su piloto con asociados está vencido hace 8 días; avance de 36 % contra 75–100 % que sostiene el plan. | 2026-09-25 y 2026-10-09 | Un informe de PRY-204. Una explicación del verde de PRY-207. |

## Para conocimiento
- PRY-199 Mobiliario: sin señales. Verde, 20 %, plan 20–40 %.
- PRY-201 Ahorro en línea: 1 hito «cumplido» sin evidencia (48 días). Amarillo, 47 %.
- PRY-209 Convenios de libranza: avance 27 % contra 40–60 %; 1 compromiso vencido (7 días); amarillo.
- PRY-210 Corresponsales rurales: avance 81 % con 4 de 4 hitos cumplidos y 3 sin evidencia; fin planeado 2026-07-16. Amarillo; 1 compromiso sin fecha.
- Datos con más de 12 meses: PRY-202, 203, 207 y 210 (la mayoría de sus campos de identidad y plan).
- Riesgos sin doliente ni fecha: 12 de 12; incidencias sin doliente: 18 de 18; dependencias sin confirmar: 8 de 8.

## Anexo
**Estado de cada proyecto (declarado → lo que muestra el cálculo)**
| Proyecto | Declarado | Avance declarado | Plan sostiene | Señales |
|---|---|---|---|---|
| PRY-199 | verde | 20 % | 20–40 % | 0 |
| PRY-200 | verde | 48 % | 100 % | 20 |
| PRY-201 | amarillo | 47 % | 25–50 % | 1 |
| PRY-202 | verde | 65 % | 100 % | 8 |
| PRY-203 | verde | 35 % | sin dato | 1 |
| PRY-204 | amarillo | 62 % | 33–67 % | 2 |
| PRY-205 | verde | 48 % | 100 % | 6 |
| PRY-206 | amarillo | 83 % | 25–50 % | 5 |
| PRY-207 | verde | 36 % | 75–100 % | 5 |
| PRY-208 | amarillo | 85 % | 60–80 % | 5 |
| PRY-209 | amarillo | 27 % | 40–60 % | 4 |
| PRY-210 | amarillo | 81 % | 100 % | 5 |
| PRY-211 | rojo | 77 % | 80–100 % | 7 |

**Contradicciones abiertas:** los cuatro verdes contradichos (PRY-200, 202, 205, 207).
**Vacíos de información:**
- Autoridad: sin dato en 13 de 13. Fase: sin dato en todos.
- No hay evidencia de recibo en ninguna ficha (`evidence` = 0 en las 13).
- Ninguna dependencia cita un código de proyecto, así que no se puede cruzar el movimiento de fechas entre proyectos.
- No hay acta del comité anterior.
- Facturación de proveedores sin dato en PRY-199 y PRY-200 (CT-199 y CT-410).
- No hay escala de probabilidad e impacto ni fecha de último movimiento en el RAID: no se puede afirmar qué lleva dos períodos sin moverse.

## Después
Cuando el comité sesione, puedo registrar las decisiones en las fichas. Ahí se cierra el ciclo y el material del próximo comité parte de lo decidido.

---
**Pie:** borrador de trabajo, no asesoría ni decisión; cada dato sale de la ficha o de la salida de `compute` del 2026-10-17, y la verificación es de quien lo lea. Versión de la familia 0.3.13; fichas aplicadas: las 13 de `estado/records`. Campos inciertos: autoridad de cambios en los 13 proyectos, si «proveedor del core» es PRY-202, si el proveedor de las notas de PRY-200 es Soluciones Solidarias, el origen de los pagos de CT-650, y el acta del comité que autorizó CC-01 en PRY-203 y PRY-208. Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.13
