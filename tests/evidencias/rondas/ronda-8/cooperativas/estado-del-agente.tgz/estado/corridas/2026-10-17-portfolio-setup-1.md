# Corrida del 2026-10-17 · portfolio-setup

3 proyectos · 76 documentos, 57 releídos y 19 sin cambio · 87 s · 19 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 8 |
| `commitment_overdue` | 4 |
| `progress_vs_plan` | 2 |
| `vendor_deliverable_late` | 2 |
| `declared_vs_evidence` | 1 |
| `milestone_overdue` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

0 preguntas (sesión sin interfaz, valores sugeridos); primer resultado en una sola conversación; 3 proyectos (PRY-202, 209, 211), 19 señales; PRY-202 declara verde y compute lo contradice; PRY-211 factura CT-650 sin actas de recibo

Primera corrida: no hay una anterior contra la cual comparar.

## Lo que produjo

Soy Vera, el agente PMO de Criterio. Proceso la documentación que ya tienes y digo qué no se sostiene.

## Listo — Cooperativa

**Miré:** 76 documentos en 13 proyectos · formatos: .md (36), .pdf (14), .docx (11), .xlsx (8), .csv (5), .json (1), .txt (1) · más reciente: 2026-10-17
**Eres:** PMO del portafolio (se ven varios proyectos)
**Te aviso:** dos días antes del comité semanal; el primero, el 2026-10-24 (supuesto: no se dijo fecha; los documentos muestran comités semanales)
**En:** presentación (valor sugerido)
**Términos:** aceptados por José Francisco Ñáñez para la versión 0.3.13 (términos 1.1), 2026-10-17 · comprobante en `.criterio/terminos/aceptacion-criterio-portfolio-0.3.13-2026-10-17.md` y `.pdf` · SHA-256 del Markdown 6d4b67767ea3a1ea…

Preguntas contestadas con el valor sugerido (sesión sin interfaz): ruta de documentos (argumento), rol, comité, formato, ubicación del estado (`estado/`) y de los informes (`reportes/`).

### Probé con tres proyectos

Tres proyectos con documentación del 2026-10-17 o 2026-10-15 (hay otros empatados con esa fecha, p. ej. PRY-200).

| Proyecto | Documentos | Qué supe | Qué no está |
|---|---|---|---|
| PRY-202 Core cooperativo | 4 | Patrocinador Andrés Lozano, gerente Natalia Ospina, comité Consejo de Administración; presupuesto 3.300 M COP; cierre pactado 2026-05-16; declara verde, 65 % (informe 2026-10-17) | Producto, autoridad del gerente, fase; ningún acta de recibo |
| PRY-209 Convenios de libranza | 7 | Patrocinador Mauricio Pérez, gerente Felipe Arango; presupuesto 800 M COP; cierre 2027-04-10; declara amarillo, 27 % (informe 2026-10-06); contrato CT-951 con 2 entregables, uno recibido con acta, facturado 32.792.867 COP | Producto, autoridad, fase; actas de los hitos cerrados |
| PRY-211 Cobranza digital | 8 | Patrocinador Liliana Torres, gerente Camilo Beltrán, producto «recaudos»; presupuesto 3.300 M COP; cierre pactado 2026-10-14; declara rojo, 77 % (2026-10-15); contrato CT-650, facturado 376.332.909 COP | Autoridad, fase; acta de recibo de los dos entregables del contrato |

### Qué levantó el cálculo (19 señales en los tres proyectos)

**PRY-202 — declara verde y la evidencia no lo sostiene** (`declared_vs_evidence`)
- `milestone_met_without_evidence`: los cuatro hitos del cronograma están «cerrado» y ninguno tiene acta de recibo (el más viejo, Diseño funcional, vencía el 2025-11-02).
- `progress_vs_plan`: declara 65 %; el cronograma da por cumplido el 100 % (4 de 4 hitos), 35 puntos de diferencia.
- `commitment_overdue`: «Entregar el punto 25» (Natalia Ospina, para el 2026-09-23, 24 días) y «Entregar el punto 16» (Camilo Beltrán, para el 2026-10-15, 2 días), ambos del comité del 2026-10-17.
- Datos con más de 12 meses de antigüedad (acta de 2025-08-20) sin confirmación posterior: patrocinador, comité, alcance y fechas.

**PRY-209 — amarillo**
- `milestone_met_without_evidence`: Diseño funcional (2026-04-30) y Ambiente de pruebas (2026-07-25) figuran cerrados sin acta.
- `progress_vs_plan`: declara 27 %; el cronograma sostiene entre 40 % y 60 % (13 puntos por debajo).
- `commitment_overdue`: «Entregar el punto 35» (Javier Hoyos, para el 2026-10-10, 7 días).

**PRY-211 — rojo, y el rojo es honesto; lo grave está en el proveedor**
- `vendor_invoiced_without_delivery`: Datos para Cooperativas S.A.S. facturó 376.332.909 COP el 2026-08-29 y ningún entregable del contrato CT-650 tiene acta de recibo (el contrato exige acta firmada para facturar).
- `vendor_deliverable_late`: Licenciamiento del módulo (vencía 2026-05-10, 160 días) y Bolsa de horas (2026-08-09, 69 días).
- `milestone_overdue`: Salida a producción, comprometida para el 2026-10-14, sin cumplir (3 días).
- `milestone_met_without_evidence`: Ambiente de pruebas (2026-05-18) e Integración con el core (2026-07-07) cerrados sin acta.
- `commitment_overdue`: «Entregar el punto 2» (Rubén Cárdenas, para el 2026-09-28, 19 días).

En los tres falta el campo «autoridad» (hasta qué monto decide el gerente sin subir a comité).

### El portafolio completo
10 proyectos más (PRY-199, 200, 201, 203 a 208 y 210) · 57 documentos pendientes de leer · aproximadamente 30 a 40 minutos, en dos lotes, uno tras otro, a la velocidad que tuvo esta lectura.

### Lo que le falta a tu carpeta
- Ninguno de los hitos cerrados tiene su acta de recibo en la carpeta: es la brecha más repetida.
- Las actas de constitución no declaran la autoridad del gerente ni la fase.
- En PRY-202 los datos de gobierno vienen solo del acta de 2025-08-20 (14 meses) y nada posterior los confirma.
- PRY-200 trae una `ficha-pm.json` publicada por su gerente: se leerá aparte y se contrastará contra la lectura de la PMO.
- Un archivo de notas suelto (`PRY-200/2026-10-17-notas-reunion.txt`) fuera de las carpetas numeradas.

Ninguno bloquea; el análisis funciona con lo que hay.

¿Corro el portafolio completo? Si tienes equipo, también puedo publicar el estándar en una carpeta compartida para que los gerentes usen los mismos criterios.
