# Corrida del 2026-10-17 · portfolio-scan

13 proyectos · 76 documentos, 0 releídos y 76 sin cambio · 217 s · 69 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 25 |
| `commitment_overdue` | 10 |
| `progress_vs_plan` | 7 |
| `vendor_deliverable_late` | 5 |
| `commitment_undated` | 4 |
| `declared_vs_evidence` | 4 |
| `milestone_overdue` | 4 |
| `commitment_rescheduled` | 3 |
| `change_without_baseline` | 2 |
| `silent` | 1 |
| `variance_cost` | 1 |
| `budget_committed` | 1 |
| `variance_time` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

10 fichas nuevas (PRY-199,200,201,203-208,210) leídas en un lote, 57 de 76 documentos; PRY-202, 209 y 211 sin cambio. Nada movido (no hay entrada/). Notas de reunión de PRY-200 leídas en la raíz de su carpeta. Mirar: hitos cerrados sin acta (200, 205, 207, 210), factura anterior al recibo en PRY-208, CC-01 sin línea base en PRY-203, 25 compromisos en PRY-200.

Contra la corrida del 2026-10-17: +50 hallazgos.

## Lo que produjo

## Barrido — 2026-10-17

Términos vigentes (v1.1, familia 0.3.13), aceptados por José Francisco Ñáñez el 2026-10-17: no hubo que pedirlos de nuevo.

**Documentos:** 76 en la carpeta · 57 leídos · 19 sin cambio desde la corrida anterior · 0 ilegibles
**Proyectos:** 13 con ficha · 10 nuevos en esta corrida (PRY-199, 200, 201, 203, 204, 205, 206, 207, 208, 210) · 3 ya existían y no se tocaron (PRY-202, 209, 211) · 0 sin carpeta propia

Formatos: 36 .md, 14 .pdf, 11 .docx, 8 .xlsx, 5 .csv, 1 .txt, 1 .json. Todo se pudo leer (Word, Excel y PDF por su texto, vía caché; las citas van al original). Plan: un solo lote de 10 proyectos, uno tras otro en esta conversación, sin subagentes; cada ficha se escribió y se selló al terminar su proyecto.

### Nuevos
| Proyecto | Documentos | Campos encontrados | Campos sin dato |
|---|---|---|---|
| PRY-199 Cambio de mobiliario de agencias | 6 | identidad, plan, presupuesto, contrato CT-199, riesgos, 1 compromiso | autoridad, fase, facturado CT-199 |
| PRY-200 Crédito de libranza digital | 16 | ídem + contrato CT-410, 25 compromisos de 7 minutas/notas, `pm_record` (ficha-pm.json) | autoridad, fase, facturado CT-410 |
| PRY-201 Apertura de ahorro en línea | 3 | identidad, plan, presupuesto, riesgos | autoridad, fase |
| PRY-203 Aportes sociales en línea | 3 | identidad, cierre del acta, presupuesto, CC-01, riesgos | autoridad, fase, cronograma (no existe) |
| PRY-204 Tarjeta débito para asociados | 3 | identidad, plan, presupuesto, riesgos | autoridad, fase |
| PRY-205 Prevención de lavado de activos | 3 | identidad, plan, presupuesto, riesgo | producto («No aplica»), autoridad, fase |
| PRY-206 Pagos con QR | 4 | identidad, plan, presupuesto, 1 compromiso | autoridad, fase |
| PRY-207 Microcrédito rural | 4 | identidad, plan, presupuesto, 1 acta de recibo | autoridad, fase |
| PRY-208 Motor de crédito | 10 | identidad, 2 líneas base, CT-349, factura, CC-01 | producto («No aplica»), autoridad, fase |
| PRY-210 Corresponsales rurales | 5 | identidad, plan, presupuesto, 1 acta de recibo, 1 compromiso | producto («No aplica»), autoridad, fase |

En los diez, «autoridad» y «fase» no aparecen en ningún documento: es un vacío de información, no un error.

### Actualizados
Ninguno: las fichas de PRY-202, 209 y 211 no tuvieron documentos nuevos ni cambiados y no se releyeron.

### Lo que hay que mirar (lo que declaran los documentos contra lo que prueban; el cálculo y las señales las emite el código en la instantánea)
- **PRY-200 (verde, 48 %).** El cronograma declara **los cinco hitos «cerrado»**, incluida la salida a producción del 2026-10-01, pero el mismo informe del 2026-10-07 dice que «se reprogramó la salida», que la prueba de carga se repite y que el avance es 48 %. Solo la integración con el core tiene acta de recibo, y es del 2026-10-07 (baseline 2026-06-12). Los otros cuatro hitos cerrados no tienen acta. El contrato CT-410 tiene sus tres entregables con fecha vencida (2026-03-14, 05-29 y 08-13) en estado pendiente/en curso y sin acta. Hay 25 compromisos; varios con 4 a 6 reprogramaciones (p. ej. «Enviar el documento 1», de Felipe Arango: del 2026-09-12 al 2026-11-24, reprogramado seis veces) y cinco que dijeron haber entregado sin presentar acta (diseño 5, documento 9, ambiente 12, prueba 10, prueba 18). Riesgo dicho en la reunión del 2026-10-17 y no registrado: el proveedor podría no llegar con el equipo completo. La ficha `ficha-pm.json` se guardó entera en `pm_record`, sin fusionarla.
- **PRY-205 (verde, 48 %).** Tres hitos «cerrado», ninguno con acta; el cierre del acta (2026-09-21) ya pasó. El informe muestra ejecutado (1.937.776.494) mayor que comprometido (1.378.457.363) y una proyección (5.188.200.936) sobre el aprobado (4.200.000.000).
- **PRY-203 (verde, 35 %).** No hay cronograma. El cierre del acta es 2026-03-16 y está vencido; la solicitud CC-01 (+112 días, +224.000.000 COP) dice «autorizada por el comité» sin decir cuál ni cuándo, y no hay línea base nueva que la recoja.
- **PRY-208 (amarillo, 85 %).** Cronograma v2 (2026-10-08) mueve la salida del 2026-12-24 al 2027-04-20 (+117 días), la misma cifra de la CC-01 del 2026-10-14; ningún documento las enlaza. La factura FV-1349 (2026-09-05) cobra 2.259.084.226 COP, los dos entregables de CT-349, pero el acta de la bolsa de horas es del 2026-09-30: **se facturó antes del recibo** de uno de los dos (1.129.542.113). El acta del ambiente de pruebas (2026-10-04) no prueba la integración con el core, que sigue «cerrada» sin acta. El piloto (2026-10-06) está vencido y «en curso».
- **PRY-207 (verde, 36 %).** Cierre del acta 2026-10-09, ya pasado; piloto del 2026-10-09 «en curso». El diseño funcional se declara cerrado con fecha 2026-01-08, pero su acta de recibo es del 2026-10-08. Ambiente e integración «cerrado» sin acta.
- **PRY-210 (amarillo, 81 %).** Cierre del acta 2026-07-16 y los cuatro hitos «cerrado»; el único acta (diseño funcional) es del 2026-10-05, un año después de la fecha de baseline (2025-10-29). Ejecutado 1.630.726.010 de 4.992.964.859 comprometido.
- **PRY-199, 201, 204, 206.** Diseño funcional «cerrado»; solo PRY-199 tiene acta (2026-10-09, baseline 2026-10-06). PRY-206 tiene el ambiente de pruebas (2026-10-06) «en curso» y vencido, con 83 % de avance declarado y un solo hito de cuatro cerrado. PRY-201: patrocinador y gerente son la misma persona (Paula Céspedes). PRY-199: el contrato CT-199 lista «Parametrización de líneas de crédito» para un proyecto de mobiliario.
- **Compromisos con doliente ajeno a la reunión.** PRY-206: Jorge Medina (gerente de PRY-200, no asistente) «Entregar el punto 14», para el 2026-10-10, vencido. PRY-210: Sandra Gil «Entregar el punto 40», sin fecha. PRY-199: Carlos Peña (no asistente) «Presentar el cierre de la fase», 2026-11-06.
- **Dependencias.** Ninguna acta declara dependencias; PRY-199 y PRY-206 listan como riesgo la «dependencia del proveedor del core cooperativo» (el core es PRY-202), sin que nadie la haya acordado como dependencia entre proyectos.

### No pude leer
| Archivo | Por qué |
|---|---|
| — | Ninguno: 76 de 76 se convirtieron. |

### Movidos desde entrada/
| Archivo | A qué proyecto | Por qué |
|---|---|---|
| — | — | No hay carpeta `entrada/`; no se movió nada. |

### Pendientes de clasificar
| Archivo | Por qué no pude decidir |
|---|---|
| `PRY-200-…/2026-10-17-notas-reunion.txt` | No está pendiente: nombra el proyecto y se leyó donde está, en la raíz de la carpeta de PRY-200 (fuera de `30-reuniones/`). Se deja en su sitio y se cita tal cual. |

### Pie
criterio-portfolio 0.3.13 · fichas tocadas: PRY-199, 200, 201, 203, 204, 205, 206, 207, 208, 210 (10) · campos en `not_found`: autoridad y fase en las 10; producto en PRY-205, 208 y 210; facturado en PRY-199 y 200; cronograma de PRY-203 · Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.13

**Después:** hay más de un proyecto, así que puedo preparar el informe consolidado (`/criterio-portfolio:portfolio-report`). Las contradicciones y los compromisos vencidos de arriba irán en él.
