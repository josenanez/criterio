# Corrida del 2026-10-17 · portfolio-wake

13 proyectos · 28 s · 69 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 25 |
| `commitment_overdue` | 10 |
| `progress_vs_plan` | 7 |
| `vendor_deliverable_late` | 5 |
| `commitment_undated` | 4 |
| `declared_vs_evidence` | 4 |
| `milestone_overdue` | 4 |
| `commitment_rescheduled` | 3 |
| `change_without_baseline` | 2 |
| `silent` | 1 |
| `variance_cost` | 1 |
| `budget_committed` | 1 |
| `variance_time` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

Barrido: 76 documentos sin cambios, nada recalculado. Confirmación: 5 preguntas formuladas, sin respuesta (prueba sin interfaz). Advertencia: 37 citas de PRY-200 sin resolver en el índice aunque los archivos existen; no investigado. No consulté peticiones.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## 2026-10-17

**Términos:** vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17 para esta prueba).
**Revisé:** 76 documentos · 0 cambiaron · 0 proyectos recalculados

### Lo que cruzó un umbral
Nada. El barrido corrió y no había noticia.

Una advertencia del índice, que no es un cambio: reporta 37 citas de PRY-200 como «source_missing» (acta de constitución, informe de avance del 2026-10-07, cronograma v1 y acta de recibo de integración con el core). Los cuatro archivos existen en la carpeta del proyecto, así que parece un fallo al resolver la ruta (la carpeta tiene tilde: «crédito»), no documentos borrados. No lo investigué más; queda para revisar a mano.

### Peticiones atendidas
No tocaba revisar peticiones (no es cadencia en `due`); no las consulté.

### Preguntas (confirmación periódica; nadie respondió en esta prueba, no se repiten)
Primera vez que corre (`last: null`). Cinco campos, por importancia:
1. PRY-211 (estado declarado «rojo», 77 %, al 2026-10-15, informe .pdf): ¿cuál es la causa y qué decisión espera de comité?
2. PRY-204 (amarillo, 62 %, al 2026-09-25): el dato más viejo del portafolio, 22 días sin informe; ¿sigue vigente?
3. PRY-208 (amarillo, 85 %, al 2026-10-08): ¿qué le falta para pasar a verde?
4. PRY-200 (verde, 48 %, al 2026-10-07): ¿se mantiene el verde frente a las actas de recibo del 09-12 al 10-10?
5. PRY-209 (amarillo, 27 %, al 2026-10-06): ¿cuándo habrá informe nuevo?

**Vuelvo el 2026-10-18.**
