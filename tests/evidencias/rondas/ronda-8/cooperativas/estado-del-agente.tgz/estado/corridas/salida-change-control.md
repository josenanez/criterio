**Sale de la ficha `estado/records/PRY-208.json` (sellada 2026-10-17, informe de avance al corte 2026-10-08). Términos vigentes: v1.1, aceptados por José Francisco Ñáñez el 2026-10-17.**

## Solicitud de cambio — PRY-208 Motor de crédito — 2026-10-17

**Qué se pide:** mover la salida a producción 30 días (2027-04-20 → 2027-05-20).
**Quién lo pide:** no consta en ningún documento; la solicitud llegó por la sesión sin firmante.
**Por qué:** no se dio motivo. Sin motivo no hay solicitud completa.

### Impacto
| Dimensión | Hoy | Con el cambio | Diferencia |
|---|---|---|---|
| Alcance | Componentes 1 a 3, sin detalle (acta 2025-11-14) | No declarado | No declarado |
| Tiempo | Salida a producción 2027-04-20 (cronograma v2) | 2027-05-20 | +30 días |
| Costo | Aprobado 18.000.000.000 COP; proyección 18.533.650.569 (+3,0 %) | No declarado | No declarado |

Alcance y costo no tienen impacto declarado. Un retraso de 30 días con el equipo ya cargado no es gratis: alguien lo absorbe en horas no pagadas o en calidad, o aparece como costo. Hay que decir quién. Y el costo ya viene presionado: la proyección supera lo aprobado y CC-01 pide 234.000.000 COP más que no están en el presupuesto aprobado.

### Efecto en el portafolio
| Proyecto afectado | Cómo | Gerente |
|---|---|---|
| Ninguno alcanzado | `impact`: 0 alcanzados, 0 que no puedan sostener su fecha, 0 dependencias sin confirmar | — |

**Esto no significa que nadie dependa de PRY-208.** El acta declara «Ninguna declarada» y la ficha no tiene dependencias, así que el cálculo no tiene grafo que recorrer. Es ausencia de declaración, no ausencia de efecto. El hito «Salida a producción» (2027-04-20, a 185 días) es el único que atraviesa el cambio.
No se sabe cuántos días se mueve cada hito intermedio: eso necesita holgura por actividad y la ficha no la tiene.
Sí hay un riesgo abierto sin dueño que toca esta fecha: «El proveedor no ha confirmado la fecha de la última entrega» (informe 2026-10-08). El contrato CT-349 no trae fecha de terminación ni vigencia, y los dos entregables listados ya están recibidos. Antes de aprobar hay que confirmar con Talento Solidario Ltda. que el contrato cubre hasta 2027-05-20.

### Quién decide
**Autoridad requerida:** no determinable. `identity.authority` = no encontrado; el acta no declara umbrales de autoridad para cambios.
**Según:** acta de constitución 2025-11-14, que solo nombra al Comité de Riesgos como comité del proyecto, sin límites de tiempo ni de monto.
**Va a comité:** sí, por defecto. Sin autoridad declarada no hay quien pueda aprobarlo por debajo del comité. Que falte esa autoridad es el hallazgo de fondo.

### Estado de los antecedentes (lo que hay que arreglar antes de apilar otro cambio)
- **CC-01** (2026-10-14, +117 días, +234.000.000 COP, ampliación de alcance) dice «Autorizada por el comité» sin decir cuál comité, en qué fecha ni con qué acta. Está registrada como aprobada, pero la ficha la marca `change_without_baseline`: el cronograma v2 (2026-10-08) movió la salida seis días **antes** de que se pidiera CC-01 (2026-10-14).
- La reconciliación cuadra en días (117 movidos, 117 autorizados, 0 sin autorización), pero lo que la autoriza es una solicitud que no cita acta de comité.
- Piloto con asociados: vencido hace 11 días (2026-10-06) y sigue «en curso».
- Dos hitos figuran como cumplidos sin evidencia de recibo: Diseño funcional aprobado y Integración con el core cooperativo.
- Avance declarado 85 % con 3 de 5 hitos cumplidos y el piloto vencido.

### Si no se aprueba
El proyecto sigue con salida el 2027-04-20, 117 días (29,6 %) sobre la línea base original, con el piloto ya vencido, un equipo que perdió dos semanas por rotación y un proveedor sin fecha confirmada. La fecha vigente es difícil de sostener según esa evidencia, pero eso es una lectura de los documentos y no un cálculo de holgura.

### Si se aprueba
**Línea base 3** — cierre 2027-05-20 · presupuesto: no se puede fijar; el último aprobado es 18.000.000.000 COP, sin los 234.000.000 de CC-01 y sin costo declarado para este cambio · motivo: no declarado, hay que obtenerlo.
Las líneas base 1 y 2 no se tocan. Las replanificaciones pasan de 1 a 2.
**Desviación acumulada contra la línea base original (2026-12-24):** tiempo +147 días (117 + 30), 37,2 % sobre una duración original de 395 días · costo: proyección actual +3,0 % sobre lo aprobado, sin cifra de este cambio.
Contra la línea base vigente (v2) serían +30 días. Esa lectura se ve mucho más sana que la de 147 días, y es la que conviene no usar sola.

### Qué falta para poder decidir
1. Quién lo pide y su motivo.
2. Impacto de alcance y de costo, o a quién se le carga.
3. Confirmación del proveedor sobre la fecha de entrega y la vigencia de CT-349.
4. El acta del comité que autorizó CC-01.
5. Declarar la autoridad de cambios del proyecto en el acta.
6. Dependencias reales de otros proyectos con la salida a producción.

**Siguiente paso:** llevarlo a comité, con CC-01 regularizada primero. No se registra línea base 3 mientras nadie con autoridad lo haya aprobado.

---
*Pie de rigor: esto es un borrador de trabajo a partir de los documentos de la carpeta, cada dato sale de la ficha con su cita. No sabe lo que se habló fuera de ellos. Verifique antes de usarlo. Aquí no se ha aprobado ni registrado nada.*
