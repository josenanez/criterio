# Corrida del 2026-10-17 · project-history

13 proyectos · 65 s · 69 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 25 |
| `commitment_overdue` | 10 |
| `progress_vs_plan` | 7 |
| `vendor_deliverable_late` | 5 |
| `commitment_undated` | 4 |
| `declared_vs_evidence` | 4 |
| `milestone_overdue` | 4 |
| `commitment_rescheduled` | 3 |
| `change_without_baseline` | 2 |
| `silent` | 1 |
| `variance_cost` | 1 |
| `budget_committed` | 1 |
| `variance_time` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

Historia de PRY-208 sobre 10 documentos (2025-11-14 a 2026-10-14): 1 replanificación (+117 días, 29.6%) sin motivo ni aprobación enlazada; 0 cambios de gobierno visibles; sin documentos en 2026-T1. Dijo que no sabe quién es el comité de CC-01, por qué se movió la salida, ni los meses declarando sin sustento (un solo estado declarado).

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## Historia · PRY-208 Motor de crédito · 2025-11-14 a 2026-10-14

**Leí:** 10 documentos entre 2025-11-14 y 2026-10-14 (los 10 de la carpeta del proyecto; cifras recalculadas con `compute` el 2026-10-17).
**Trimestres sin un solo documento:** 2026-T1 (enero a marzo de 2026). Justo ahí vencía el hito «Diseño funcional aprobado» (2026-02-11).

Términos: vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17); no hizo falta registrarlos de nuevo.

### En una línea
El proyecto nació el 2025-11-14 con cierre a 2026-12-24 y 18.000.000.000 COP. Entre el acta y el primer documento de seguimiento pasan más de cinco meses, y no hay ningún documento en el primer trimestre de 2026. El 2026-10-08 aparecen el informe de avance (amarillo, 85%) y un cronograma v2 que mueve la salida a producción al 2027-04-20 (+117 días). El 2026-10-14 llega una solicitud de cambio CC-01 que declara el mismo +117 días, ya «autorizada por el comité». Todo el movimiento queda escrito en una semana de octubre de 2026, cuando el piloto ya llevaba 11 días vencido.

### Las cuatro cifras
| Replanificaciones | Atraso acumulado vs. original | Meses declarando sin sustento | Cambios de gobierno |
|---|---|---|---|
| 1 | 117 días (29.6%), salida a producción 2026-12-24 → 2027-04-20 | No calculable: hay un solo estado declarado (2026-10-08). Los hitos «cumplidos» sin evidencia llevan 248 y 90 días vencidos | 0 en los documentos leídos |

### Línea de tiempo
| Fecha | Documento | Qué cambió |
|---|---|---|
| 2025-11-14 | `00-gobierno/2025-11-14-acta-constitucion.docx` | Acta: patrocinadora Liliana Torres, gerente Laura Vélez, Comité de Riesgos. 18.000.000.000 COP. Inicio 2025-11-24, cierre 2026-12-24. Producto asociado: «No aplica». |
| 2025-11-14 | `10-plan/2025-11-14-cronograma-v1.csv` | Línea base v1. Ya muestra tres hitos «cerrado» (fechas de 2026), lo que no puede ser cierto en esa fecha. |
| 2025-11-22 | `00-gobierno/2025-11-22-contrato-ct-349.md` | Contrato CT-349 con Talento Solidario: 2 entregables de 1.129.542.113 COP. La tabla dice «recibido» en ambos, aunque se firmó antes de que existiera el entregable. |
| 2026-04-29 | `20-seguimiento/2026-04-29-acta-recibo-ct-349-licenciamiento-del-módulo.md` | Recibo del licenciamiento (comprometido 2026-04-18). |
| 2026-09-05 | `20-seguimiento/2026-09-05-factura-ct-349.pdf` | Factura FV-1349 por 2.259.084.226 COP, «entregables del contrato CT-349», radicada en cuentas por pagar. |
| 2026-09-30 | `20-seguimiento/2026-09-30-acta-recibo-ct-349-bolsa-de-horas-de-desarrollo.md` | Recibo de la bolsa de horas (comprometida 2026-09-10). |
| 2026-10-04 | `20-seguimiento/2026-10-04-acta-recibo-ambiente-de-pruebas-certificado.pdf` | Recibo del ambiente de pruebas (hito con fecha 2026-05-01). |
| 2026-10-08 | `20-seguimiento/2026-10-08-informe-avance.pdf` | Declarado: amarillo, 85%. Reporta dos semanas perdidas por rotación de un desarrollador, 2 riesgos abiertos, proyección 18.533.650.569 COP. |
| 2026-10-08 | `10-plan/2026-10-08-cronograma-v2.xlsx` | Salida a producción pasa a 2027-04-20. El piloto sigue con fecha 2026-10-06 y estado «en curso». |
| 2026-10-14 | `20-seguimiento/2026-10-14-solicitud-cambio-cc-01.md` | CC-01: ampliación de alcance, +117 días «sobre la línea base vigente», +234.000.000 COP, «autorizada por el comité». |

### Replanificaciones
| Nº | Fecha | Fecha de cierre nueva | Motivo declarado | Documento que la aprobó |
|---|---|---|---|---|
| 1 | 2026-10-08 | 2027-04-20 (+117 días) | Sin motivo en el cronograma v2. El informe del mismo día atribuye dos semanas perdidas a la rotación de un desarrollador, pero esas dos semanas no explican 117 días. CC-01 (2026-10-14) declara el mismo +117 por ampliación de alcance. | Ninguno. CC-01 dice «el comité» sin nombrarlo ni fechar la decisión, y es posterior al cronograma. `compute` marca `change_without_baseline`. |

La línea base v1 no se perdió: el cierre original (2026-12-24) se conserva.

### Gobierno
| Fecha | Qué cambió | Documento |
|---|---|---|
| — | Ningún cambio de patrocinadora, gerente ni comité en los documentos leídos. Liliana Torres, Laura Vélez y el Comité de Riesgos figuran desde el acta. | — |

Esto solo cubre lo que hay en la carpeta: no hay correos ni minutas, y estos son los documentos donde aparecen los cambios de gobierno. El «comité» que autoriza CC-01 no es identificable.

### Compromisos que se repitieron
| Doliente | Qué | Veces | Fechas prometidas |
|---|---|---|---|
| — | No hay carpeta de reuniones ni minutas, así que no hay compromisos que seguir. | 0 | — |

### Desde cuándo lo declarado no se sostiene
- **Fecha:** 2026-02-11. Es el primer hito marcado «cumplido» sin evidencia («Diseño funcional aprobado»), y no hay ningún documento de enero a marzo de 2026. El segundo es «Integración con el core cooperativo» (2026-07-19). `compute` los marca `milestone_met_without_evidence` (248 y 90 días).
- **Lo que siguió reportándose:** estado amarillo y 85% de avance el 2026-10-08. El plan sustenta entre 60% y 80% (3 de 5 hitos; `gap_points` −5.0). El piloto (2026-10-06) está vencido 11 días y se reporta sin mover su fecha. El informe no menciona el atraso de 117 días.
- **No es un salto:** el ambiente de pruebas se recibió el 2026-10-04 contra una fecha de hito del 2026-05-01, y el cronograma lo tenía «cerrado» desde antes.
- No se puede decir «meses declarando sin sustento» porque no hay serie de estados declarados, solo el del 2026-10-08.

### Lecciones ancladas a un hecho
1. **El cronograma marcó como cerrado un hito cuya acta llegó meses después.** El ambiente de pruebas figuraba «cerrado» en el cronograma, fechado 2025-11-14. Su acta es del 2026-10-04.
2. **La factura se adelantó al recibo.** FV-1349 (2026-09-05) cobra los dos entregables de CT-349. El contrato dice que cada uno se factura contra acta firmada, y el acta de la bolsa de horas es del 2026-09-30. Hoy ambos están recibidos, pero a la fecha de radicación solo uno lo estaba. Efecto: 1.129.542.113 COP quedaron en cuentas por pagar sin acta.
3. **El cronograma se movió antes de que existiera la solicitud.** Cronograma v2 (2026-10-08) precede a CC-01 (2026-10-14), y CC-01 dice +117 «sobre la línea base vigente» cuando la vigente ya incluía ese movimiento. Efecto: no se puede saber si son un mismo cambio o dos; tampoco se puede decir si los 234.000.000 COP de CC-01 ya están en la proyección del informe (18.533.650.569 COP, 3.0% sobre lo aprobado), porque ningún documento lo dice.

### Lo que no sé
- Quién es «el comité» que autorizó CC-01, y cuándo.
- Por qué se movió la salida a producción.
- Qué pasó entre 2025-11-22 y 2026-04-29, y todo 2026-T1.
- Producto, autoridad y fase no figuran en ningún documento.

### Pie de rigor
- Cifras copiadas de `compute` (2026-10-17). Los días y porcentajes que no salen de ahí no se escribieron.
- Los 10 documentos fueron leídos; los PDF y los archivos de Office por su texto.
- La historia describe qué quedó escrito y cuándo. No dice quién lo sabía ni por qué se escribió tarde: esa conversación es de personas, con estos datos.
- Siguiente paso posible: llevar esto al comité (CC-01 necesita que alguien identifique quién la autorizó) o al cierre del proyecto.
