## Diagnóstico · PRY-200 Crédito de libranza digital · 2026-10-17

**Leí:** 16 documentos de la carpeta del proyecto · de 2025-12-13 a 2026-10-17 · formatos: 13 .md, 1 .txt, 1 .json, 1 .xlsx
**No pude leer:** nada de la carpeta del proyecto quedó sin leer. En las otras carpetas de proyecto busqué menciones de «PRY-200» y «libranza digital» solo en texto plano (.md, .txt, .json): no hay ninguna. Los .docx, .xlsx y .pdf de otros proyectos no se pueden buscar así y no los abrí; si alguna minuta ahí habla de PRY-200, no la vi.

Términos: vigentes (versión 1.1, aceptada por José Francisco Ñáñez el 2026-10-17); no hizo falta pedir una aceptación nueva.

Nota de método: `00-gobierno/ficha-pm.json` es la ficha que lleva el gerente; la leí como declaración suya, no como evidencia. Las cifras derivadas salen de `portafolio.py compute` (corte 2026-10-17); donde el script no da una cifra, no la escribo.

### Dictamen
**Sostenido:** 6 afirmaciones · **Sin sustento:** 14 · **Contradicho:** 4

El informe de avance del 2026-10-07 declara **verde** y **48 %**, y la carpeta no sostiene ninguna de las dos cosas. El informe se contradice con su propio texto (prueba de carga fallida, salida reprogramada), el cronograma marca los cinco hitos como cerrados (lo que daría 100 %, no 48 %) y de esos cinco solo uno tiene acta de recibo, firmada el 2026-10-07. La fecha de cierre comprometida, 2026-10-01, ya pasó hace 16 días sin evidencia de salida a producción y sin ningún cambio registrado que la mueva. Los tres entregables del contrato CT-410 están vencidos y ninguno tiene acta de recibo. Del dinero, solo el presupuesto aprobado tiene sustento; comprometido, ejecutado y proyección son cifras del informe sin documento detrás. Lo que sí se puede afirmar con documentos: quién patrocina y quién gerencia, el presupuesto aprobado, la integración con el core recibida el 2026-10-07 y tres compromisos de comité cerrados con acta. No hay autoridad del gerente declarada, así que ninguna fecha movida cuenta como desviación aprobada.

### Gobierno
| | Qué dice el documento | Fuente |
|---|---|---|
| Patrocinador | Carlos Peña | `00-gobierno/2025-12-18-acta-constitucion.md` |
| Gerente | Jorge Medina | `00-gobierno/2025-12-18-acta-constitucion.md` |
| Autoridad declarada | No está. El acta no dice qué puede decidir el gerente ni qué requiere aprobación del comité. | `00-gobierno/2025-12-18-acta-constitucion.md` |
| Comité | Consejo de Administración (las seis minutas semanales llevan ese nombre) | `00-gobierno/2025-12-18-acta-constitucion.md`; `30-reuniones/` |

Otros hallazgos de gobierno:
- El alcance del acta es «Componente 1, 2, 3» y el fuera de alcance es «Lo que otro proyecto cubre»: no se puede medir el cumplimiento de un alcance que no está escrito.
- Dependencias declaradas: «Ninguna». El hito «Integración con el core cooperativo» (`10-plan/2025-12-18-cronograma-v1.xlsx`) es una dependencia del proyecto y no está declarada.
- El contrato CT-410 se firmó el 2025-12-13, cinco días antes de que el acta y el presupuesto se aprobaran (2025-12-18) (`00-gobierno/2025-12-13-contrato-ct-410.md`).
- Las minutas del comité listan compromisos, pero ninguna registra una decisión del comité. Ningún documento aprueba un cambio.
- Criterio de éxito: «en producción y medido». Nada en la carpeta muestra producción ni medición.

### Contra el plan
- **Línea base original:** v1, aprobada el 2025-12-18, inicio 2025-12-28, cierre 2026-10-01 (`00-gobierno/2025-12-18-acta-constitucion.md`; `10-plan/2025-12-18-cronograma-v1.xlsx`).
- **Vigente:** igual a la original. No hay cronograma v2, solicitud de cambio ni acta de replanificación. El script da 0 replanificaciones y 0 días de atraso contra la línea base, pero ese 0 es la ausencia de registro, no la ausencia de atraso: el informe del 2026-10-07 dice «Se reprogramó la salida por el cierre contable de fin de mes» y no existe documento que lo apruebe.
- **Problema del propio cronograma:** el archivo se llama «cronograma-v1» y lleva fecha 2025-12-18, pero marca los cinco hitos como «cerrado», incluidos hitos de febrero a octubre de 2026. O se editó después sin versionarse, o la fecha del nombre no es la del contenido. Por eso no lo uso como prueba de que los hitos se cumplieron, solo como línea base de fechas.

### Hitos vencidos sin evidencia
| Hito | Fecha | Días | Qué documento se esperaría |
|---|---|---|---|
| Diseño funcional aprobado | 2026-02-21 | 238 | Acta de aprobación del diseño funcional |
| Ambiente de pruebas certificado | 2026-04-17 | 183 | Certificado o acta de recibo del ambiente |
| Piloto con asociados | 2026-08-06 | 72 | Informe o acta de cierre del piloto |
| Salida a producción | 2026-10-01 | 16 | Acta de puesta en producción; el informe dice que la prueba de carga se repite y la salida se reprogramó |

El quinto hito, **Integración con el core cooperativo**, sí tiene acta de recibo: `20-seguimiento/2026-10-07-acta-recibo-integración-con-el-core-cooperativo.md`, del 2026-10-07, contra una fecha de línea base de 2026-06-12. El acta no dice qué criterio se verificó. El script no calcula los días de ese atraso, así que no escribo la cifra.

### Dinero
| Aprobado | Comprometido | Ejecutado | Proyección | Disponible real |
|---|---|---|---|---|
| 4.200.000.000 COP (acta) | 3.390.376.801 COP (80,7 % del aprobado) | 1.405.474.333 COP (33,5 % del aprobado) | 4.010.066.854 COP (4,5 % por debajo del aprobado) | 809.623.199 COP |

- Solo el aprobado tiene sustento (`00-gobierno/2025-12-18-acta-constitucion.md`). Comprometido, ejecutado y proyección vienen únicamente del informe del 2026-10-07 (declaración del gerente); no hay ejecución presupuestal, factura ni orden de compra en la carpeta.
- Comprometido está en 80,7 %, por debajo del umbral de 90 % de la configuración.
- Contrato CT-410: tres entregables de 194.058.672 COP cada uno, todos vencidos y ninguno con acta de recibo. El contrato condiciona la factura a un acta firmada por el gerente (`00-gobierno/2025-12-13-contrato-ct-410.md`). Cuánto se facturó o pagó no consta en ningún documento.
- La nota del 2026-10-17 dice que Laura Vélez enviará «el ajuste del presupuesto la otra semana». No hay solicitud de cambio ni cifra: si el ajuste mueve el aprobado, hoy no tiene proceso.

### Lo que se dijo y nadie registró
- **Riesgo:** «el proveedor podría no llegar con el equipo completo para la siguiente fase»; la nota dice que nadie lo anotó como riesgo (`2026-10-17-notas-reunion.txt`). Sin responsable. El mismo proveedor tiene tres entregables vencidos.
- **Incidencias del informe sin registro ni responsable:** la prueba de carga no alcanzó el umbral y se repite; el equipo perdió dos semanas por la rotación de un desarrollador clave (`20-seguimiento/2026-10-07-informe-avance.md`). No hay registro RAID en la carpeta.
- **Riesgo abierto del informe sin responsable:** concentración del conocimiento en una sola persona.
- **Compromisos nuevos del 2026-10-17:** Óscar Ramírez, revisión con el proveedor, 2026-10-27; Laura Vélez, ajuste del presupuesto, «la otra semana» (sin fecha); Felipe Arango, «enviar el documento 1», 2026-11-24.
- **Compromisos reprogramados** (de `30-reuniones/` y las notas del 2026-10-17):
  - Felipe Arango, «Enviar el documento 1»: 6 veces; original 2026-09-12, hoy 2026-11-24.
  - Óscar Ramírez, «Cerrar la prueba 2»: 5 veces; original 2026-09-26, hoy 2026-12-01.
  - Elena Duarte, «Revisar el anexo 3»: 4 veces; original 2026-09-28, hoy 2026-11-17.
- **Compromisos vencidos sin evidencia (5):** Elena Duarte, «Enviar el documento 9» (22 días); Felipe Arango, «Cerrar la prueba 10» (13); Rubén Cárdenas, «Cerrar la prueba 18» (6); Gustavo Neira, «Actualizar la matriz 14» (3); Óscar Ramírez, «Confirmar la fecha 23» (2).
- **Compromisos sin fecha (3):** Sandra Gil, «Aprobar el diseño 5»; Gustavo Neira, «Validar el ambiente 12»; Laura Vélez, «Mandar el ajuste del presupuesto».
- **Dichos como entregados sin acta (5):** Sandra Gil (diseño 5), Elena Duarte (documento 9), Gustavo Neira (ambiente 12), Felipe Arango (prueba 10), Rubén Cárdenas (prueba 18). Después de decirlo salieron de las tablas de compromisos abiertos sin que se presentara acta.
- **Cadencia:** las notas del 2026-10-17 dicen «próxima reunión en dos semanas»; las seis minutas anteriores son semanales. Entre tanto vencen compromisos del 2026-10-20 al 2026-10-28.

### Contradicho
| Afirmación | Documento A | Documento B |
|---|---|---|
| Estado **verde** | `20-seguimiento/2026-10-07-informe-avance.md`, «Estado declarado: Verde» | El mismo informe: prueba de carga fallida, dos semanas perdidas, salida reprogramada; y `00-gobierno/2025-12-13-contrato-ct-410.md`: tres entregables vencidos sin acta |
| Avance **48 %** | `20-seguimiento/2026-10-07-informe-avance.md` | `10-plan/2025-12-18-cronograma-v1.xlsx`: 5 de 5 hitos «cerrado», que sostiene 100 % (el script marca una brecha de 52,0 puntos) |
| «Salida a producción» **cerrada** | `10-plan/2025-12-18-cronograma-v1.xlsx` (estado «cerrado», fecha 2026-10-01) | `20-seguimiento/2026-10-07-informe-avance.md`: «la prueba de carga … se repite»; «Se reprogramó la salida» |
| Plan vigente = línea base (cierre 2026-10-01, 0 cambios) | `10-plan/2025-12-18-cronograma-v1.xlsx`; `00-gobierno/2025-12-18-acta-constitucion.md` | `20-seguimiento/2026-10-07-informe-avance.md`: se reprogramó la salida |

### Sin sustento
Lo que nada contradice y nada respalda (14):
1. Comprometido 3.390.376.801 COP: solo el informe.
2. Ejecutado 1.405.474.333 COP: solo el informe.
3. Proyección al cierre 4.010.066.854 COP: solo el informe.
4. Hito «Diseño funcional aprobado» cumplido: sin acta.
5. Hito «Ambiente de pruebas certificado» cumplido: sin acta.
6. Hito «Piloto con asociados» cumplido: sin acta.
7. La prueba de carga no alcanzó el umbral: solo el informe; no hay resultado de la prueba ni el umbral pactado.
8. El equipo perdió dos semanas por rotación: solo el informe.
9. Riesgo de concentración del conocimiento: solo el informe, sin responsable.
10 a 14. Cinco compromisos dichos como entregados sin acta (los de la lista anterior).

Sostenido (6), para dejar el conteo completo: presupuesto aprobado (4.200.000.000 COP); fechas comprometidas de inicio y cierre (acta y cronograma coinciden); integración con el core recibida el 2026-10-07; «Validar el ambiente 4» (acta del 2026-09-12); «Entregar el punto 8» (acta del 2026-09-26); «Aprobar el diseño 13» (acta del 2026-10-10).

### Lo que esta carpeta no permite saber
- **Si el proyecto está en verde, amarillo o rojo.** Faltan actas de tres hitos y la de producción; sin ellas no hay con qué medir el avance real. Consecuencia: el comité no tiene base para aceptar el verde.
- **Qué puede decidir el gerente.** Sin autoridad declarada, cada fecha movida es una fecha que alguien escribió, no una desviación aprobada.
- **Qué incluye el alcance.** «Componente 1, 2, 3» no permite decir qué falta por entregar.
- **Cuánto se facturó o pagó al proveedor.** No hay facturas ni ejecución presupuestal. Consecuencia: no se puede saber si se pagó contra actas que no existen, ni cuánto de los 1.405.474.333 COP «ejecutados» corresponde al CT-410.
- **Cómo evolucionó el estado.** Hay un solo informe de avance (2026-10-07). Sin informes anteriores no se ve cuándo empezó la brecha.
- **Qué decidió el comité.** Las minutas solo listan compromisos.
- **Qué dependencias tiene el proyecto.** El acta declara ninguna; la integración con el core sugiere otra.

---
**Pie de rigor.** Base: 16 documentos de la carpeta de PRY-200, leídos el 2026-10-17; ficha del gerente tratada como declaración. Cifras derivadas: `portafolio.py compute`, corte 2026-10-17. No verifiqué nada fuera de los documentos: lo hablado fuera de ellos no consta. No recomiendo detener, continuar ni reestructurar; eso lo decide quien tiene la facultad. Cada dato lleva su fuente para que usted la verifique.
