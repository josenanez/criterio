<!-- origen: PRY-202-core-cooperativo/10-plan/2025-08-20-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2025-11-02,2025-11-02,cerrado
Ambiente de pruebas certificado,2026-01-06,2026-01-06,cerrado
Integración con el core cooperativo,2026-03-12,2026-03-12,cerrado
Piloto con asociados,2026-05-16,2026-05-16,cerrado
