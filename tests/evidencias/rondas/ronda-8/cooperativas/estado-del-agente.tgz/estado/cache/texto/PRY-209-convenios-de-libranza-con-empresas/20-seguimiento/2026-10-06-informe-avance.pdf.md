<!-- origen: PRY-209-convenios-de-libranza-con-empresas/20-seguimiento/2026-10-06-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Convenios de libranza con empresas
Código: PRY-209
Fecha de corte: 2026-10-06
Gerente: Felipe Arango

Estado declarado
Amarillo
Avance reportado: 27%

Lo que pasó en el periodo
- Se reprogramó la salida por el cierre contable de fin de mes

Presupuesto
COP
Aprobado 800.000.000
Comprometido 640.217.034
Ejecutado 350.822.333
Proyección al cierre 796.111.121

Riesgos abiertos
- Dependencia del proveedor del core cooperativo
- El proveedor no ha confirmado la fecha de la última entrega
