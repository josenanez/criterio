<!-- origen: PRY-209-convenios-de-libranza-con-empresas/10-plan/2026-01-24-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-04-30 | 2026-04-30 | cerrado
Ambiente de pruebas certificado | 2026-07-25 | 2026-07-25 | cerrado
Integración con el core cooperativo | 2026-10-20 | 2026-10-20 | en curso
Piloto con asociados | 2027-01-14 | 2027-01-14 | en curso
Salida a producción | 2027-04-10 | 2027-04-10 | en curso
