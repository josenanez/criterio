<!-- origen: PRY-208-motor-de-crédito/00-gobierno/2025-11-14-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Motor de crédito

Código: PRY-208

Área dueña: Ahorro y aportes

Patrocinador: Liliana Torres

Gerente de proyecto: Laura Vélez

Comité: Comité de Riesgos

Producto asociado: No aplica

Fecha de aprobación: 2025-11-14

Objetivo del negocio

Entregar motor de crédito para Ahorro y aportes.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

18.000.000.000 COP, aprobado por Comité de Riesgos el 2025-11-14.

Fechas comprometidas

Fecha

Inicio

2025-11-24

Cierre

2026-12-24

Criterio de éxito

Motor de crédito en producción y medido.

Dependencias declaradas

• Ninguna declarada
