<!-- origen: PRY-208-motor-de-crédito/10-plan/2025-11-14-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2026-02-11,2026-02-11,cerrado
Ambiente de pruebas certificado,2026-05-01,2026-05-01,cerrado
Integración con el core cooperativo,2026-07-19,2026-07-19,cerrado
Piloto con asociados,2026-10-06,2026-10-06,en curso
Salida a producción,2026-12-24,2026-12-24,en curso
