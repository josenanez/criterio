<!-- origen: PRY-209-convenios-de-libranza-con-empresas/00-gobierno/2026-01-24-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Convenios de libranza con empresas

Código: PRY-209

Área dueña: Ahorro y aportes

Patrocinador: Mauricio Pérez

Gerente de proyecto: Felipe Arango

Comité: Comité de Crédito

Producto asociado: No aplica

Fecha de aprobación: 2026-01-24

Objetivo del negocio

Entregar convenios de libranza con empresas para Ahorro y aportes.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

800.000.000 COP, aprobado por Comité de Crédito el 2026-01-24.

Fechas comprometidas

Fecha

Inicio

2026-02-03

Cierre

2027-04-10

Criterio de éxito

Convenios de libranza con empresas en producción y medido.

Dependencias declaradas

• Ninguna declarada
