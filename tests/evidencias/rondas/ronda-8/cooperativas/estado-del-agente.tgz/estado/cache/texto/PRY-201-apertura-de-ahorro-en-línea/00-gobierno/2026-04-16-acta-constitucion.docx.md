<!-- origen: PRY-201-apertura-de-ahorro-en-línea/00-gobierno/2026-04-16-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Apertura de ahorro en línea

Código: PRY-201

Área dueña: Cartera y cobranza

Patrocinador: Paula Céspedes

Gerente de proyecto: Paula Céspedes

Comité: Comité de Educación

Producto asociado: ahorro a la vista

Fecha de aprobación: 2026-04-16

Objetivo del negocio

Entregar apertura de ahorro en línea para Cartera y cobranza.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

4.200.000.000 COP, aprobado por Comité de Educación el 2026-04-16.

Fechas comprometidas

Fecha

Inicio

2026-04-26

Cierre

2027-09-15

Criterio de éxito

Apertura de ahorro en línea en producción y medido.

Dependencias declaradas

• Ninguna declarada
