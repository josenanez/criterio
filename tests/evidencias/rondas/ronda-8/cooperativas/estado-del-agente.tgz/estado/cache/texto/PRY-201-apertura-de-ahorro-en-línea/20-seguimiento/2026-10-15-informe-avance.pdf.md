<!-- origen: PRY-201-apertura-de-ahorro-en-línea/20-seguimiento/2026-10-15-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Apertura de ahorro en línea
Código: PRY-201
Fecha de corte: 2026-10-15
Gerente: Paula Céspedes

Estado declarado
Amarillo
Avance reportado: 47%

Lo que pasó en el periodo
- Se ajustó el plan de pruebas con el área de seguridad
- Se levantó un hallazgo de seguridad en la revisión de arquitectura

Presupuesto
COP
Aprobado 4.200.000.000
Comprometido 2.835.540.251
Ejecutado 2.435.174.020
Proyección al cierre 4.306.338.785

Riesgos abiertos
- El proveedor no ha confirmado la fecha de la última entrega
