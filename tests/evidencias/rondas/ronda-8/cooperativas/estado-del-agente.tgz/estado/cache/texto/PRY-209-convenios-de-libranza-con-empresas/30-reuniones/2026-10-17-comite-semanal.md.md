<!-- origen: PRY-209-convenios-de-libranza-con-empresas/30-reuniones/2026-10-17-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Crédito · Convenios de libranza con empresas

**Fecha:** 2026-10-17
**Asistentes:** Felipe Arango, Mauricio Pérez

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Javier Hoyos | Entregar el punto 35 | 2026-10-10 |
