<!-- origen: PRY-202-core-cooperativo/20-seguimiento/2026-10-17-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Core cooperativo

**Código:** PRY-202
**Fecha de corte:** 2026-10-17
**Gerente:** Natalia Ospina

## Estado declarado

**Verde**

Avance reportado: **65%**

## Lo que pasó en el periodo

- Se recibió el concepto pendiente del ente supervisor

## Presupuesto

| | COP |
|---|---|
| Aprobado | 3.300.000.000 |
| Comprometido | 1.650.470.755 |
| Ejecutado | 1.930.253.365 |
| Proyección al cierre | 3.433.155.097 |

## Riesgos abiertos

- Aprobación del reglamento por el Consejo de Administración
- Concentración del conocimiento en una sola persona
