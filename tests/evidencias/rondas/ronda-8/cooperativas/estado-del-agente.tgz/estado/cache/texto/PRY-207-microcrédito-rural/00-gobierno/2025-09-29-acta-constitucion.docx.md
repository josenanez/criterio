<!-- origen: PRY-207-microcrédito-rural/00-gobierno/2025-09-29-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Microcrédito rural

Código: PRY-207

Área dueña: Operaciones

Patrocinador: Laura Vélez

Gerente de proyecto: Liliana Torres

Comité: Comité de Crédito

Producto asociado: microcrédito

Fecha de aprobación: 2025-09-29

Objetivo del negocio

Entregar microcrédito rural para Operaciones.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

6.800.000.000 COP, aprobado por Comité de Crédito el 2025-09-29.

Fechas comprometidas

Fecha

Inicio

2025-10-09

Cierre

2026-10-09

Criterio de éxito

Microcrédito rural en producción y medido.

Dependencias declaradas

• Ninguna declarada
