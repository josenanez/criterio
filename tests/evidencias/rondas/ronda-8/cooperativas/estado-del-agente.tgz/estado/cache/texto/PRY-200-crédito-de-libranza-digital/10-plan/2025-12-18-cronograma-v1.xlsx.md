<!-- origen: PRY-200-crédito-de-libranza-digital/10-plan/2025-12-18-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-02-21 | 2026-02-21 | cerrado
Ambiente de pruebas certificado | 2026-04-17 | 2026-04-17 | cerrado
Integración con el core cooperativo | 2026-06-12 | 2026-06-12 | cerrado
Piloto con asociados | 2026-08-06 | 2026-08-06 | cerrado
Salida a producción | 2026-10-01 | 2026-10-01 | cerrado
