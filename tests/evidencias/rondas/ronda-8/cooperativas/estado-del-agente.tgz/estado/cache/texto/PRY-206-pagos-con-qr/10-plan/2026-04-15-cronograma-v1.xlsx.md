<!-- origen: PRY-206-pagos-con-qr/10-plan/2026-04-15-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-07-16 | 2026-07-16 | cerrado
Ambiente de pruebas certificado | 2026-10-06 | 2026-10-06 | en curso
Integración con el core cooperativo | 2026-12-27 | 2026-12-27 | en curso
Piloto con asociados | 2027-03-19 | 2027-03-19 | en curso
