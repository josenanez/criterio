<!-- origen: PRY-206-pagos-con-qr/30-reuniones/2026-10-16-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Consejo de Administración · Pagos con QR

**Fecha:** 2026-10-16
**Asistentes:** Felipe Arango, Beatriz Cuéllar

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Jorge Medina | Entregar el punto 14 | 2026-10-10 |
