<!-- origen: PRY-203-aportes-sociales-en-línea/00-gobierno/2025-08-03-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Aportes sociales en línea

Código: PRY-203

Área dueña: Cartera y cobranza

Patrocinador: María Restrepo

Gerente de proyecto: Gustavo Neira

Comité: Comité de Riesgos

Producto asociado: aportes sociales

Fecha de aprobación: 2025-08-03

Objetivo del negocio

Entregar aportes sociales en línea para Cartera y cobranza.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

18.000.000.000 COP, aprobado por Comité de Riesgos el 2025-08-03.

Fechas comprometidas

Fecha

Inicio

2025-08-13

Cierre

2026-03-16

Criterio de éxito

Aportes sociales en línea en producción y medido.

Dependencias declaradas

• Ninguna declarada
