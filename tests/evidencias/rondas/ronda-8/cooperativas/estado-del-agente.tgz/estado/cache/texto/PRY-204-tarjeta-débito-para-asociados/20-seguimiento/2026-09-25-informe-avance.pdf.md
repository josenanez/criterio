<!-- origen: PRY-204-tarjeta-débito-para-asociados/20-seguimiento/2026-09-25-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Tarjeta débito para asociados
Código: PRY-204
Fecha de corte: 2026-09-25
Gerente: Javier Hoyos

Estado declarado
Amarillo
Avance reportado: 62%

Lo que pasó en el periodo
- La prueba de carga no alcanzó el umbral pactado y se repite

Presupuesto
COP
Aprobado 1.200.000.000
Comprometido 565.373.056
Ejecutado 329.106.175
Proyección al cierre 1.180.865.844

Riesgos abiertos
- Concentración del conocimiento en una sola persona
- Cambio normativo del supervisor que puede mover el alcance
