<!-- origen: PRY-208-motor-de-crédito/20-seguimiento/2026-10-08-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Motor de crédito
Código: PRY-208
Fecha de corte: 2026-10-08
Gerente: Laura Vélez

Estado declarado
Amarillo
Avance reportado: 85%

Lo que pasó en el periodo
- El equipo perdió dos semanas por rotación de un desarrollador clave

Presupuesto
COP
Aprobado 18.000.000.000
Comprometido 15.434.381.391
Ejecutado 9.323.368.667
Proyección al cierre 18.533.650.569

Riesgos abiertos
- Aprobación del reglamento por el Consejo de Administración
- El proveedor no ha confirmado la fecha de la última entrega
