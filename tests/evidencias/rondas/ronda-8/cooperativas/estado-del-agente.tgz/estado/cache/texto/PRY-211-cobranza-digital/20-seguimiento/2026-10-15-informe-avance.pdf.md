<!-- origen: PRY-211-cobranza-digital/20-seguimiento/2026-10-15-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Cobranza digital
Código: PRY-211
Fecha de corte: 2026-10-15
Gerente: Camilo Beltrán

Estado declarado
Rojo
Avance reportado: 77%

Lo que pasó en el periodo
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales

Presupuesto
COP
Aprobado 3.300.000.000
Comprometido 1.118.869.755
Ejecutado 855.582.138
Proyección al cierre 3.150.132.734

Riesgos abiertos
- Cambio normativo del supervisor que puede mover el alcance
- El proveedor no ha confirmado la fecha de la última entrega
