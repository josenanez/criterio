<!-- origen: PRY-200-crédito-de-libranza-digital/00-gobierno/ficha-pm.json · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

{
 "schema_version": "0.2",
 "identity": {
 "code": {
 "value": "PRY-200",
 "source": "00-gobierno/2025-12-18-acta-constitucion.md",
 "source_date": "2025-12-18",
 "state": "found"
 },
 "name": {
 "value": "Crédito de libranza digital",
 "source": "00-gobierno/2025-12-18-acta-constitucion.md",
 "source_date": "2025-12-18",
 "state": "found"
 },
 "business_area": {
 "value": "Cartera y cobranza",
 "source": "00-gobierno/2025-12-18-acta-constitucion.md",
 "source_date": "2025-12-18",
 "state": "found"
 },
 "product": {
 "value": "crédito de libranza",
 "source": "00-gobierno/2025-12-18-acta-constitucion.md",
 "source_date": "2025-12-18",
 "state": "found"
 },
 "authority": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "sponsor": {
 "value": "Carlos Peña",
 "source": "00-gobierno/2025-12-18-acta-constitucion.md",
 "source_date": "2025-12-18",
 "state": "found"
 },
 "manager": {
 "value": "Jorge Medina",
 "source": "00-gobierno/2025-12-18-acta-constitucion.md",
 "source_date": "2025-12-18",
 "state": "found"
 },
 "committee": {
 "value": "Consejo de Administración",
 "source": "00-gobierno/2025-12-18-acta-constitucion.md",
 "source_date": "2025-12-18",
 "state": "found"
 },
 "phase": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 }
 },
 "declared": {
 "status": {
 "value": "verde",
 "source": "20-seguimiento/2026-10-07-informe-avance.md",
 "source_date": "2026-10-07",
 "state": "found",
 "source_kind": "declaration"
 },
 "progress_pct": {
 "value": 48,
 "source": "20-seguimiento/2026-10-07-informe-avance.md",
 "source_date": "2026-10-07",
 "state": "found",
 "source_kind": "declaration"
 },
 "as_of": {
 "value": "2026-10-07",
 "source": "20-seguimiento/2026-10-07-informe-avance.md",
 "source_date": "2026-10-07",
 "state": "found"
 },
 "source": "20-seguimiento/2026-10-07-informe-avance.md"
 },
 "plan": {
 "start_date": {
 "value": "2025-12-28",
 "source": "00-gobierno/2025-12-18-acta-constitucion.md",
 "source_date": "2025-12-18",
 "state": "found"
 },
 "end_date": {
 "value": "2026-10-01",
 "source": "10-plan/2025-12-18-cronograma-v1.xlsx",
 "source_date": "2025-12-18",
 "state": "found"
 },
 "baseline": [
 {
 "version": 1,
 "approved_on": "2025-12-18",
 "start_date": "2025-12-28",
 "end_date": "2026-10-01",
 "reason": "Aprobación del acta de constitución",
 "source": "00-gobierno/2025-12-18-acta-constitucion.md"
 }
 ],
 "milestones": [
 {
 "name": {
 "value": "Diseño funcional aprobado",
 "source": "10-plan/2025-12-18-cronograma-v1.xlsx",
 "source_date": "2025-12-18",
 "state": "found"
 },
 "baseline_date": {
 "value": "2026-02-21",
 "source": "10-plan/2025-12-18-cronograma-v1.xlsx",
 "source_date": "2025-12-18",
 "state": "found"
 },
 "current_date": {
 "value": "2026-02-21",
 "source": "10-plan/2025-12-18-cronograma-v1.xlsx",
 "source_date": "2025-12-18",
 "state": "found"
 },
 "state": {
 "value": "met",
 "source": "10-plan/2025-12-18-cronograma-v1.xlsx",
 "source_date": "2025-12-18",
 "state": "found"
 },
 "evidence": {
 "value": null,
 "state": "not_found"
 },
 "source": "10-plan/2025-12-18-cronograma-v1.xlsx"
 },
 {
 "name": {
 "value": "Ambiente de pruebas certificado",
 "source": "10-plan/2025-12-18-cronograma-v1.xlsx",
 "source_date": "2025-12-18",
 "state": "found"
 },
 "baseline_date": {
 "value": "2026-04-17",
 "source": "10-plan/2025-12-18-cronograma-v1.xlsx",
 "source_date": "2025-12-18",
 "state": "found"
 },
 "current_date": {
 "value": "2026-04-17",
 "source": "10-plan/2025-12-18-cronograma-v1.xlsx",
 "source_date": "2025-12-18",
 "state": "found"
 },
 "state": {
 "value": "met",
 "source": "10-plan/2025-12-18-cronograma-v1.xlsx",
 "source_date": "2025-12-18",
 "state": "found"
 },
 "evidence": {
 "value": null,
 "state": "not_found"
 },
 "source": "10-plan/2025-12-18-cronograma-v1.xlsx"
 },
 {
 "name": {
 "value": "Integración con el core cooperativo",
 "source": "10-plan/2025-12-18-cronograma-v1.xlsx",
 "source_date": "2025-12-18",
 "state": "found"
 },
 "baseline_date": {
 "value": "2026-06-12",
 "source": "10-plan/2025-12-18-cronograma-v1.xlsx",
 "source_date": "2025-12-18",
 "state": "found"
 },
 "current_date": {
 "value": "2026-06-12",
 "source": "10-plan/2025-12-18-cronograma-v1.xlsx",
 "source_date": "2025-12-18",
 "state": "found"
 },
 "state": {
 "value": "met",
 "source": "10-plan/2025-12-18-cronograma-v1.xlsx",
 "source_date": "2025-12-18",
 "state": "found"
 },
 "evidence": {
 "value": "20-seguimiento/2026-10-07-acta-recibo-integración-con-el-core-cooperativo.md",
 "source": "20-seguimiento/2026-10-07-acta-recibo-integración-con-el-core-cooperativo.md",
 "source_date": "2026-10-07",
 "state": "found"
 },
 "source": "10-plan/2025-12-18-cronograma-v1.xlsx"
 },
 {
 "name": {
 "value": "Piloto con asociados",
 "source": "10-plan/2025-12-18-cronograma-v1.xlsx",
 "source_date": "2025-12-18",
 "state": "found"
 },
 "baseline_date": {
 "value": "2026-08-06",
 "source": "10-plan/2025-12-18-cronograma-v1.xlsx",
 "source_date": "2025-12-18",
 "state": "found"
 },
 "current_date": {
 "value": "2026-08-06",
 "source": "10-plan/2025-12-18-cronograma-v1.xlsx",
 "source_date": "2025-12-18",
 "state": "found"
 },
 "state": {
 "value": "met",
 "source": "10-plan/2025-12-18-cronograma-v1.xlsx",
 "source_date": "2025-12-18",
 "state": "found"
 },
 "evidence": {
 "value": null,
 "state": "not_found"
 },
 "source": "10-plan/2025-12-18-cronograma-v1.xlsx"
 },
 {
 "name": {
 "value": "Salida a producción",
 "source": "10-plan/2025-12-18-cronograma-v1.xlsx",
 "source_date": "2025-12-18",
 "state": "found"
 },
 "baseline_date": {
 "value": "2026-10-01",
 "source": "10-plan/2025-12-18-cronograma-v1.xlsx",
 "source_date": "2025-12-18",
 "state": "found"
 },
 "current_date": {
 "value": "2026-10-01",
 "source": "10-plan/2025-12-18-cronograma-v1.xlsx",
 "source_date": "2025-12-18",
 "state": "found"
 },
 "state": {
 "value": "met",
 "source": "10-plan/2025-12-18-cronograma-v1.xlsx",
 "source_date": "2025-12-18",
 "state": "found"
 },
 "evidence": {
 "value": null,
 "state": "not_found"
 },
 "source": "10-plan/2025-12-18-cronograma-v1.xlsx"
 }
 ]
 },
 "money": {
 "currency": {
 "value": "COP",
 "source": "00-gobierno/2025-12-18-acta-constitucion.md",
 "source_date": "2025-12-18",
 "state": "found"
 },
 "approved": {
 "value": 4200000000,
 "source": "00-gobierno/2025-12-18-acta-constitucion.md",
 "source_date": "2025-12-18",
 "state": "found"
 },
 "committed": {
 "value": 3390376801,
 "source": "20-seguimiento/2026-10-07-informe-avance.md",
 "source_date": "2026-10-07",
 "state": "found",
 "source_kind": "declaration"
 },
 "executed": {
 "value": 1405474333,
 "source": "20-seguimiento/2026-10-07-informe-avance.md",
 "source_date": "2026-10-07",
 "state": "found",
 "source_kind": "declaration"
 },
 "projection": {
 "value": 4010066854,
 "source": "20-seguimiento/2026-10-07-informe-avance.md",
 "source_date": "2026-10-07",
 "state": "found",
 "source_kind": "declaration"
 }
 },
 "vendors": [
 {
 "name": "Soluciones Solidarias S.A.S.",
 "contract_ref": "CT-410",
 "source": "00-gobierno/2025-12-13-contrato-ct-410.md",
 "deliverables": [
 {
 "name": "Licenciamiento del módulo",
 "due_date": "2026-03-14",
 "amount": 194058672,
 "state": "pending",
 "evidence": null,
 "source": "00-gobierno/2025-12-13-contrato-ct-410.md"
 },
 {
 "name": "Bolsa de horas de desarrollo",
 "due_date": "2026-05-29",
 "amount": 194058672,
 "state": "pending",
 "evidence": null,
 "source": "00-gobierno/2025-12-13-contrato-ct-410.md"
 },
 {
 "name": "Parametrización de líneas de crédito",
 "due_date": "2026-08-13",
 "amount": 194058672,
 "state": "pending",
 "evidence": null,
 "source": "00-gobierno/2025-12-13-contrato-ct-410.md"
 }
 ]
 }
 ],
 "raid": {
 "risks": [
 {
 "what": "Concentración del conocimiento en una sola persona",
 "owner": "no_identificado",
 "source": "20-seguimiento/2026-10-07-informe-avance.md"
 },
 {
 "what": "El proveedor podría no llegar con el equipo completo para la siguiente fase (se comentó en la reunión; nadie lo registró como riesgo)",
 "owner": "no_identificado",
 "source": "2026-10-17-notas-reunion.txt"
 }
 ],
 "assumptions": [],
 "issues": [
 {
 "what": "La prueba de carga no alcanzó el umbral pactado y se repite",
 "owner": "no_identificado",
 "source": "20-seguimiento/2026-10-07-informe-avance.md"
 },
 {
 "what": "El equipo perdió dos semanas por rotación de un desarrollador clave",
 "owner": "no_identificado",
 "source": "20-seguimiento/2026-10-07-informe-avance.md"
 }
 ],
 "dependencies": []
 },
 "changes": [],
 "commitments": [
 {
 "who": "Felipe Arango",
 "what": "Enviar el documento 1",
 "due_date": "2026-11-24",
 "original_due_date": "2026-09-12",
 "stated_on": "2026-09-05",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-09-22",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md"
 },
 {
 "due_date": "2026-10-11",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md"
 },
 {
 "due_date": "2026-10-24",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md"
 },
 {
 "due_date": "2026-11-03",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 },
 {
 "due_date": "2026-11-10",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 },
 {
 "due_date": "2026-11-24",
 "stated_on": "2026-10-17",
 "source": "2026-10-17-notas-reunion.txt"
 }
 ]
 },
 {
 "who": "Óscar Ramírez",
 "what": "Cerrar la prueba 2",
 "due_date": "2026-12-01",
 "original_due_date": "2026-09-26",
 "stated_on": "2026-09-05",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-03",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md"
 },
 {
 "due_date": "2026-10-21",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md"
 },
 {
 "due_date": "2026-11-10",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md"
 },
 {
 "due_date": "2026-11-17",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 },
 {
 "due_date": "2026-12-01",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Elena Duarte",
 "what": "Revisar el anexo 3",
 "due_date": "2026-11-17",
 "original_due_date": "2026-09-28",
 "stated_on": "2026-09-05",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-05",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md"
 },
 {
 "due_date": "2026-10-22",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md"
 },
 {
 "due_date": "2026-10-29",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 },
 {
 "due_date": "2026-11-17",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "who": "María Restrepo",
 "what": "Validar el ambiente 4",
 "due_date": "2026-09-15",
 "original_due_date": "2026-09-15",
 "stated_on": "2026-09-05",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "state": "met",
 "evidence": "20-seguimiento/2026-09-12-acta-recibo-4.md"
 },
 {
 "who": "Sandra Gil",
 "what": "Aprobar el diseño 5",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "state": "open",
 "note": "El 2026-09-26 dijo que ya lo entregó; no se presentó acta (30-reuniones/2026-09-26-comite-semanal.md). Desde entonces no aparece en las tablas."
 },
 {
 "who": "Carlos Peña",
 "what": "Actualizar la matriz 6",
 "due_date": "2026-10-28",
 "original_due_date": "2026-10-08",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-20",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md"
 },
 {
 "due_date": "2026-10-28",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Óscar Ramírez",
 "what": "Confirmar la fecha 7",
 "due_date": "2026-11-01",
 "original_due_date": "2026-10-05",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-21",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 },
 {
 "due_date": "2026-11-01",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Laura Vélez",
 "what": "Entregar el punto 8",
 "due_date": "2026-10-12",
 "original_due_date": "2026-09-30",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "state": "met",
 "reschedules": [
 {
 "due_date": "2026-10-12",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md"
 }
 ],
 "evidence": "20-seguimiento/2026-09-26-acta-recibo-8.md"
 },
 {
 "who": "Elena Duarte",
 "what": "Enviar el documento 9",
 "due_date": "2026-09-25",
 "original_due_date": "2026-09-25",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "state": "overdue",
 "note": "El 2026-09-26 dijo que ya lo entregó; no se presentó acta (30-reuniones/2026-09-26-comite-semanal.md). Desde entonces no aparece en las tablas."
 },
 {
 "who": "Felipe Arango",
 "what": "Cerrar la prueba 10",
 "due_date": "2026-10-04",
 "original_due_date": "2026-10-04",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "state": "overdue",
 "note": "El 2026-10-10 dijo que ya lo entregó; no se presentó acta (30-reuniones/2026-10-10-comite-semanal.md). Desde entonces no aparece en las tablas."
 },
 {
 "who": "María Restrepo",
 "what": "Revisar el anexo 11",
 "due_date": "2026-11-04",
 "original_due_date": "2026-10-10",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-20",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md"
 },
 {
 "due_date": "2026-11-04",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Gustavo Neira",
 "what": "Validar el ambiente 12",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "state": "open",
 "note": "El 2026-09-26 dijo que ya lo entregó; no se presentó acta (30-reuniones/2026-09-26-comite-semanal.md). Desde entonces no aparece en las tablas."
 },
 {
 "who": "Paula Céspedes",
 "what": "Aprobar el diseño 13",
 "due_date": "2026-10-14",
 "original_due_date": "2026-10-14",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "state": "met",
 "evidence": "20-seguimiento/2026-10-10-acta-recibo-13.md"
 },
 {
 "who": "Gustavo Neira",
 "what": "Actualizar la matriz 14",
 "due_date": "2026-10-14",
 "original_due_date": "2026-10-14",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "state": "overdue"
 },
 {
 "who": "Gustavo Neira",
 "what": "Confirmar la fecha 15",
 "due_date": "2026-11-01",
 "original_due_date": "2026-10-10",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-22",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 },
 {
 "due_date": "2026-11-01",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Elena Duarte",
 "what": "Entregar el punto 16",
 "due_date": "2026-10-28",
 "original_due_date": "2026-10-09",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-28",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Mauricio Pérez",
 "what": "Enviar el documento 17",
 "due_date": "2026-11-12",
 "original_due_date": "2026-10-26",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-11-12",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Rubén Cárdenas",
 "what": "Cerrar la prueba 18",
 "due_date": "2026-10-11",
 "original_due_date": "2026-10-11",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "state": "overdue",
 "note": "El 2026-10-10 dijo que ya lo entregó; no se presentó acta (30-reuniones/2026-10-10-comite-semanal.md). Desde entonces no aparece en las tablas."
 },
 {
 "who": "Diana Molina",
 "what": "Revisar el anexo 19",
 "due_date": "2026-10-20",
 "original_due_date": "2026-10-20",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "state": "open"
 },
 {
 "who": "Jorge Medina",
 "what": "Validar el ambiente 20",
 "due_date": "2026-10-28",
 "original_due_date": "2026-10-28",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "state": "open"
 },
 {
 "who": "Felipe Arango",
 "what": "Aprobar el diseño 21",
 "due_date": "2026-10-28",
 "original_due_date": "2026-10-28",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "state": "open"
 },
 {
 "who": "Andrés Lozano",
 "what": "Actualizar la matriz 22",
 "due_date": "2026-10-29",
 "original_due_date": "2026-10-29",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "state": "open"
 },
 {
 "who": "Óscar Ramírez",
 "what": "Confirmar la fecha 23",
 "due_date": "2026-10-15",
 "original_due_date": "2026-10-15",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "state": "overdue"
 },
 {
 "who": "Liliana Torres",
 "what": "Entregar el punto 24",
 "due_date": "2026-11-03",
 "original_due_date": "2026-11-03",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "state": "open"
 },
 {
 "who": "Óscar Ramírez",
 "what": "Revisión con el proveedor",
 "due_date": "2026-10-27",
 "original_due_date": "2026-10-27",
 "stated_on": "2026-10-17",
 "source": "2026-10-17-notas-reunion.txt",
 "state": "open"
 },
 {
 "who": "Laura Vélez",
 "what": "Mandar el ajuste del presupuesto",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-10-17",
 "source": "2026-10-17-notas-reunion.txt",
 "state": "open",
 "due_text": "la otra semana"
 }
 ],
 "meta": {
 "record_updated": "2026-10-17",
 "documents_seen": [],
 "fields_not_found": [
 "identity.authority",
 "identity.phase",
 "vendors[0].invoiced"
 ],
 "open_conflicts": []
 }
}
