<!-- origen: PRY-211-cobranza-digital/00-gobierno/2026-01-30-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Cobranza digital

**Código:** PRY-211
**Área dueña:** Tecnología
**Patrocinador:** Liliana Torres
**Gerente de proyecto:** Camilo Beltrán
**Comité:** Comité de Riesgos
**Producto asociado:** recaudos
**Fecha de aprobación:** 2026-01-30

## Objetivo del negocio

Entregar cobranza digital para Tecnología.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**3.300.000.000 COP**, aprobado por Comité de Riesgos el 2026-01-30.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-02-09 |
| Cierre | 2026-10-14 |

## Criterio de éxito

Cobranza digital en producción y medido.

## Dependencias declaradas

- Ninguna declarada
