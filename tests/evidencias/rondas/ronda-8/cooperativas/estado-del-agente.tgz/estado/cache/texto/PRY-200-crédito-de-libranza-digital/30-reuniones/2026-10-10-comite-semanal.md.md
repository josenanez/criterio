<!-- origen: PRY-200-crédito-de-libranza-digital/30-reuniones/2026-10-10-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Consejo de Administración · Crédito de libranza digital

**Fecha:** 2026-10-10
**Asistentes:** Andrés Lozano, Carlos Peña, Diana Molina, Elena Duarte, Felipe Arango, Gustavo Neira, Jorge Medina, Liliana Torres, María Restrepo, Mauricio Pérez, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Felipe Arango | Enviar el documento 1 | 2026-11-10 |
| Óscar Ramírez | Cerrar la prueba 2 | 2026-12-01 |
| Elena Duarte | Revisar el anexo 3 | 2026-11-17 |
| Carlos Peña | Actualizar la matriz 6 | 2026-10-28 |
| Óscar Ramírez | Confirmar la fecha 7 | 2026-11-01 |
| María Restrepo | Revisar el anexo 11 | 2026-11-04 |
| Gustavo Neira | Actualizar la matriz 14 | 2026-10-14 |
| Gustavo Neira | Confirmar la fecha 15 | 2026-11-01 |
| Elena Duarte | Entregar el punto 16 | 2026-10-28 |
| Mauricio Pérez | Enviar el documento 17 | 2026-11-12 |
| Diana Molina | Revisar el anexo 19 | 2026-10-20 |
| Jorge Medina | Validar el ambiente 20 | 2026-10-28 |
| Felipe Arango | Aprobar el diseño 21 | 2026-10-28 |
| Andrés Lozano | Actualizar la matriz 22 | 2026-10-29 |
| Óscar Ramírez | Confirmar la fecha 23 | 2026-10-15 |
| Liliana Torres | Entregar el punto 24 | 2026-11-03 |

## Cerrados en esta reunión

- Aprobar el diseño 13 (Paula Céspedes): recibido, acta de recibo del 2026-10-10.

## Lo que se dijo

- Felipe Arango dice que ya entregó «cerrar la prueba 10». No se presentó acta.
- Rubén Cárdenas dice que ya entregó «cerrar la prueba 18». No se presentó acta.
