<!-- origen: PRY-211-cobranza-digital/30-reuniones/2026-10-15-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Riesgos · Cobranza digital

**Fecha:** 2026-10-15
**Asistentes:** Camilo Beltrán, Liliana Torres

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Rubén Cárdenas | Entregar el punto 2 | 2026-09-28 |
