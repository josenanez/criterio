<!-- origen: PRY-204-tarjeta-débito-para-asociados/10-plan/2026-03-19-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-08-24 | 2026-08-24 | cerrado
Ambiente de pruebas certificado | 2027-01-20 | 2027-01-20 | en curso
Integración con el core cooperativo | 2027-06-17 | 2027-06-17 | en curso
