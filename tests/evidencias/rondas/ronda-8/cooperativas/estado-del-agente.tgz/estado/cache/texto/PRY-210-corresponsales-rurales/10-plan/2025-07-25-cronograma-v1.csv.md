<!-- origen: PRY-210-corresponsales-rurales/10-plan/2025-07-25-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2025-10-29,2025-10-29,cerrado
Ambiente de pruebas certificado,2026-01-24,2026-01-24,cerrado
Integración con el core cooperativo,2026-04-21,2026-04-21,cerrado
Piloto con asociados,2026-07-16,2026-07-16,cerrado
