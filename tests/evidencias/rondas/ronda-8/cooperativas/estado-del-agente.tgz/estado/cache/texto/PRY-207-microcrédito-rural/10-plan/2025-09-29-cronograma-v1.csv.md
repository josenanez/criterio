<!-- origen: PRY-207-microcrédito-rural/10-plan/2025-09-29-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2026-01-08,2026-01-08,cerrado
Ambiente de pruebas certificado,2026-04-09,2026-04-09,cerrado
Integración con el core cooperativo,2026-07-10,2026-07-10,cerrado
Piloto con asociados,2026-10-09,2026-10-09,en curso
