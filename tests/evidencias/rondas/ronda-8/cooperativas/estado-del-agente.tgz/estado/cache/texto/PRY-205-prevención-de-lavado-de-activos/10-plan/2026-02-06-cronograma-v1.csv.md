<!-- origen: PRY-205-prevención-de-lavado-de-activos/10-plan/2026-02-06-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2026-04-29,2026-04-29,cerrado
Ambiente de pruebas certificado,2026-07-11,2026-07-11,cerrado
Integración con el core cooperativo,2026-09-21,2026-09-21,cerrado
