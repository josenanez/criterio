<!-- origen: PRY-211-cobranza-digital/10-plan/2026-01-30-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-03-30 | 2026-03-30 | cerrado
Ambiente de pruebas certificado | 2026-05-18 | 2026-05-18 | cerrado
Integración con el core cooperativo | 2026-07-07 | 2026-07-07 | cerrado
Piloto con asociados | 2026-08-25 | 2026-08-25 | cerrado
Salida a producción | 2026-10-14 | 2026-10-14 | en curso
