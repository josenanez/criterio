<!-- origen: PRY-202-core-cooperativo/30-reuniones/2026-10-17-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Consejo de Administración · Core cooperativo

**Fecha:** 2026-10-17
**Asistentes:** Natalia Ospina, Andrés Lozano

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Natalia Ospina | Entregar el punto 25 | 2026-09-23 |
| Camilo Beltrán | Entregar el punto 16 | 2026-10-15 |
