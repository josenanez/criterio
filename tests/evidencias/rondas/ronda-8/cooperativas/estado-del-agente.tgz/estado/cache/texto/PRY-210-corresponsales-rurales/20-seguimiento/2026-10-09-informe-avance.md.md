<!-- origen: PRY-210-corresponsales-rurales/20-seguimiento/2026-10-09-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Corresponsales rurales

**Código:** PRY-210
**Fecha de corte:** 2026-10-09
**Gerente:** Óscar Ramírez

## Estado declarado

**Amarillo**

Avance reportado: **81%**

## Lo que pasó en el periodo

- Se ajustó el plan de pruebas con el área de seguridad

## Presupuesto

| | COP |
|---|---|
| Aprobado | 9.500.000.000 |
| Comprometido | 4.992.964.859 |
| Ejecutado | 1.630.726.010 |
| Proyección al cierre | 9.123.347.396 |

## Riesgos abiertos

- Cambio normativo del supervisor que puede mover el alcance
