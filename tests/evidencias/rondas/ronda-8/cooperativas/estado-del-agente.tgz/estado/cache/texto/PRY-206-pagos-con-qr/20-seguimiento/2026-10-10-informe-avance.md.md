<!-- origen: PRY-206-pagos-con-qr/20-seguimiento/2026-10-10-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Pagos con QR

**Código:** PRY-206
**Fecha de corte:** 2026-10-10
**Gerente:** Felipe Arango

## Estado declarado

**Amarillo**

Avance reportado: **83%**

## Lo que pasó en el periodo

- Se acordó con arquitectura cómo se revisan los requisitos no funcionales
- Se ajustó el plan de pruebas con el área de seguridad
- El equipo perdió dos semanas por rotación de un desarrollador clave

## Presupuesto

| | COP |
|---|---|
| Aprobado | 3.300.000.000 |
| Comprometido | 2.970.911.597 |
| Ejecutado | 1.806.185.462 |
| Proyección al cierre | 3.444.173.074 |

## Riesgos abiertos

- Dependencia del proveedor del core cooperativo
