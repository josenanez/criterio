<!-- origen: PRY-201-apertura-de-ahorro-en-línea/10-plan/2026-04-16-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-08-30 | 2026-08-30 | cerrado
Ambiente de pruebas certificado | 2027-01-04 | 2027-01-04 | en curso
Integración con el core cooperativo | 2027-05-11 | 2027-05-11 | en curso
Piloto con asociados | 2027-09-15 | 2027-09-15 | en curso
