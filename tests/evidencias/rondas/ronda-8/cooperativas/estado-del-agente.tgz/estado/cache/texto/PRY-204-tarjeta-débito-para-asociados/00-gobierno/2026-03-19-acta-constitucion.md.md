<!-- origen: PRY-204-tarjeta-débito-para-asociados/00-gobierno/2026-03-19-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Tarjeta débito para asociados

**Código:** PRY-204
**Área dueña:** Crédito
**Patrocinador:** Sandra Gil
**Gerente de proyecto:** Javier Hoyos
**Comité:** Comité de Riesgos
**Producto asociado:** tarjeta débito
**Fecha de aprobación:** 2026-03-19

## Objetivo del negocio

Entregar tarjeta débito para asociados para Crédito.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**1.200.000.000 COP**, aprobado por Comité de Riesgos el 2026-03-19.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-03-29 |
| Cierre | 2027-06-17 |

## Criterio de éxito

Tarjeta débito para asociados en producción y medido.

## Dependencias declaradas

- Ninguna declarada
