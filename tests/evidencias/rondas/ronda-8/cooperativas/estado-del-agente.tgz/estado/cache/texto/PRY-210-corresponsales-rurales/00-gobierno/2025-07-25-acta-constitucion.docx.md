<!-- origen: PRY-210-corresponsales-rurales/00-gobierno/2025-07-25-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Corresponsales rurales

Código: PRY-210

Área dueña: Bienestar social

Patrocinador: Diana Molina

Gerente de proyecto: Óscar Ramírez

Comité: Comité de Crédito

Producto asociado: No aplica

Fecha de aprobación: 2025-07-25

Objetivo del negocio

Entregar corresponsales rurales para Bienestar social.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

9.500.000.000 COP, aprobado por Comité de Crédito el 2025-07-25.

Fechas comprometidas

Fecha

Inicio

2025-08-04

Cierre

2026-07-16

Criterio de éxito

Corresponsales rurales en producción y medido.

Dependencias declaradas

• Ninguna declarada
