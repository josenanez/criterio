<!-- origen: PRY-200-crédito-de-libranza-digital/2026-10-17-notas-reunion.txt · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

notas reunión crédito de libranza digital — 2026-10-17
estuvieron: Andrés Lozano, Carlos Peña, Diana Molina, Elena Duarte, Felipe Arango, Gustavo Neira, Jorge Medina, Laura Vélez, Liliana Torres, María Restrepo, Mauricio Pérez, Óscar Ramírez

- Felipe Arango dice que lo de «enviar el documento 1» no alcanzó, se compromete para el 24/11/2026
- Laura Vélez queda de mandar el ajuste del presupuesto la otra semana
- Óscar Ramírez: revisión con el proveedor, queda para el 2026-10-27
- se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo
- próxima reunión en dos semanas
