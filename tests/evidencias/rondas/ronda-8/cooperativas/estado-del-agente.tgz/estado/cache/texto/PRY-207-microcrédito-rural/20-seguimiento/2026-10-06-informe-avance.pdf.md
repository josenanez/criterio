<!-- origen: PRY-207-microcrédito-rural/20-seguimiento/2026-10-06-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Microcrédito rural
Código: PRY-207
Fecha de corte: 2026-10-06
Gerente: Liliana Torres

Estado declarado
Verde
Avance reportado: 36%

Lo que pasó en el periodo
- El Consejo de Administración pidió ajustar el reglamento antes del piloto
- Se ajustó el plan de pruebas con el área de seguridad
- El equipo perdió dos semanas por rotación de un desarrollador clave

Presupuesto
COP
Aprobado 6.800.000.000
Comprometido 4.130.690.153
Ejecutado 1.536.413.566
Proyección al cierre 6.731.398.575

Riesgos abiertos
- El proveedor no ha confirmado la fecha de la última entrega
