<!-- origen: PRY-200-crédito-de-libranza-digital/30-reuniones/2026-10-03-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Consejo de Administración · Crédito de libranza digital

**Fecha:** 2026-10-03
**Asistentes:** Carlos Peña, Diana Molina, Elena Duarte, Felipe Arango, Gustavo Neira, Jorge Medina, María Restrepo, Mauricio Pérez, Paula Céspedes, Rubén Cárdenas, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Felipe Arango | Enviar el documento 1 | 2026-11-03 |
| Óscar Ramírez | Cerrar la prueba 2 | 2026-11-17 |
| Elena Duarte | Revisar el anexo 3 | 2026-10-29 |
| Carlos Peña | Actualizar la matriz 6 | 2026-10-20 |
| Óscar Ramírez | Confirmar la fecha 7 | 2026-10-21 |
| Felipe Arango | Cerrar la prueba 10 | 2026-10-04 |
| María Restrepo | Revisar el anexo 11 | 2026-10-20 |
| Paula Céspedes | Aprobar el diseño 13 | 2026-10-14 |
| Gustavo Neira | Actualizar la matriz 14 | 2026-10-14 |
| Gustavo Neira | Confirmar la fecha 15 | 2026-10-22 |
| Elena Duarte | Entregar el punto 16 | 2026-10-09 |
| Mauricio Pérez | Enviar el documento 17 | 2026-10-26 |
| Rubén Cárdenas | Cerrar la prueba 18 | 2026-10-11 |
| Diana Molina | Revisar el anexo 19 | 2026-10-20 |
| Jorge Medina | Validar el ambiente 20 | 2026-10-28 |
