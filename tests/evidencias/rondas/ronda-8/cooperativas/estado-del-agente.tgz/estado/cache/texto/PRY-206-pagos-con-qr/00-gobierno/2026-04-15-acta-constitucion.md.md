<!-- origen: PRY-206-pagos-con-qr/00-gobierno/2026-04-15-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Pagos con QR

**Código:** PRY-206
**Área dueña:** Cartera y cobranza
**Patrocinador:** Beatriz Cuéllar
**Gerente de proyecto:** Felipe Arango
**Comité:** Consejo de Administración
**Producto asociado:** pagos QR
**Fecha de aprobación:** 2026-04-15

## Objetivo del negocio

Entregar pagos con qr para Cartera y cobranza.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**3.300.000.000 COP**, aprobado por Consejo de Administración el 2026-04-15.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-04-25 |
| Cierre | 2027-03-19 |

## Criterio de éxito

Pagos con QR en producción y medido.

## Dependencias declaradas

- Ninguna declarada
