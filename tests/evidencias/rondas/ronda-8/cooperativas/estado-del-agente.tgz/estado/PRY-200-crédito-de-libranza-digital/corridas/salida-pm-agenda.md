Términos vigentes (v0.3.13, aceptados por José Francisco Ñáñez el 2026-10-17); no hizo falta registrarlos de nuevo. No hubo a quién preguntar, así que tomé dos respuestas sugeridas: la fecha es **2026-10-24**, la siguiente fecha del comité semanal (sábado) que dice la configuración, y la duración, **45 minutos**, que no vino en la invocación. Es la primera corrida de `diff`, así que no hay foto anterior: "sin cambios" en el anexo se compara contra el comité del 2026-10-10 y las notas del 2026-10-17.

## Reunión de seguimiento — Crédito de libranza digital (PRY-200) · 2026-10-24
13 puntos · 42 minutos · 8 personas requeridas: Felipe Arango, Óscar Ramírez, Elena Duarte, Gustavo Neira, Laura Vélez, Diana Molina, Carlos Peña (patrocinador) y Jorge Medina.

### Lo que no se destraba solo

> **[1] Nombrar qué bloquea «Enviar el documento 1» y quién lo quita; o una fecha con un entregable parcial que se pueda verificar** · 8 min · **Felipe Arango, con Carlos Peña**
> Prometido para el 2026-11-24, y antes para el 11-10, el 11-03, el 10-24, el 10-11 y el 09-22. La primera promesa fue el 2026-09-12: la fecha nueva queda 73 días después.
> Fuente: comité del 2026-10-10 (11-10) y notas del 2026-10-17 (11-24).
> **Si no se resuelve hoy:** es la séptima fecha. Seis reprogramaciones en cinco semanas no son un problema de seguimiento sino un bloqueo que nadie ha nombrado. Si el bloqueo excede lo que se resuelve en la sala, sale como decisión de comité (`/pm-escalate`).

> **[2] Qué hace falta para que «Cerrar la prueba 2» tenga una fecha que se sostenga** · 6 min · **Óscar Ramírez**
> Prometido para el 2026-12-01, y antes para el 11-17, el 11-10, el 10-21 y el 10-03. La primera promesa fue el 2026-09-26.
> Fuente: comités del 2026-09-26 (11-10) y del 2026-10-10 (12-01).
> **Si no se resuelve hoy:** la fecha vigente se aleja más de lo que avanzan las semanas; cinco reprogramaciones.

> **[3] Qué se necesita para «Revisar el anexo 3»** · 4 min · **Elena Duarte**
> Prometido para el 2026-11-17, y antes para el 10-29, el 10-22 y el 10-05. La primera promesa fue el 2026-09-28.
> Fuente: comités del 2026-09-26 (10-22) y del 2026-10-10 (11-17).
> **Si no se resuelve hoy:** cuarta reprogramación pasada; la quinta pondría a Elena donde ya está Óscar.

### Vencido sin evidencia
Lo más viejo primero. Los tres primeros tienen un «ya lo entregué» dicho en comité y ningún acta de recibo. Lo que hace falta hoy es el acta o una fecha nueva, no repetir que ya lo entregaron.

| Quién | Qué | Desde | Qué se necesita hoy | Min |
|---|---|---|---|---|
| Elena Duarte | Enviar el documento 9 (comité 2026-09-19; «ya lo entregué» el 09-26) | 2026-09-25 · 22 días | El acta de recibo, o una fecha | 2 |
| Felipe Arango | Cerrar la prueba 10 (comité 2026-09-19; «ya lo entregué» el 10-10) | 2026-10-04 · 13 días | El acta de recibo, o una fecha | 2 |
| Gustavo Neira | Actualizar la matriz 14 (comité 2026-09-26) | 2026-10-14 · 3 días | Si se entregó, con qué documento; si no, una fecha | 2 |
| Óscar Ramírez | Confirmar la fecha 23 (comité 2026-10-10) | 2026-10-15 · 2 días | La fecha | 2 |

### Se decide hoy o se atrasa

| Qué | Quién decide | Si no se decide | Min |
|---|---|---|---|
| **Registrar como riesgo que el proveedor podría no llegar con el equipo completo para la siguiente fase** y ponerle dueño. Se comentó y nadie lo anotó (notas del 2026-10-17, línea 7). Las notas no dicen qué proveedor es; el único en la ficha es Soluciones Solidarias S.A.S. (CT-410), con los 3 entregables sin recibo (217, 141 y 65 días). Óscar tiene la revisión con el proveedor el 10-27: que la lleve con esto. | Carlos Peña (dueño) y Jorge Medina (registra) | Sigue como comentario sin dueño hasta la revisión del 10-27. | 4 |
| **«La siguiente fase»: ¿qué es?** El cronograma v1 cierra el proyecto el 2026-10-01 con «Salida a producción» en estado cumplido y sin acta de recibo; ninguna ficha nombra fases (notas, línea 7). Si hay una ampliación, entra por control de cambios; si no la hay, hay un hito dado por cumplido sin estarlo. | Carlos Peña | No se sabe cuál de las dos cosas es y la línea base sigue diciendo que el proyecto ya terminó. | 4 |
| **Una fecha para «Mandar el ajuste del presupuesto»**: «la otra semana» no es una fecha (notas del 2026-10-17). Y si es un cambio de presupuesto, quién lo aprueba. | Laura Vélez; Carlos Peña si es cambio | Entra al seguimiento sin fecha, que es como llegaron otros dos compromisos que llevan más de 28 días. | 3 |
| **Una fecha para «Validar el ambiente 12»**, abierto sin fecha desde el comité del 2026-09-19 (28 días); Gustavo dijo el 09-26 que ya lo había entregado, sin acta. | Gustavo Neira | Cumple 35 días sin fecha y sin acta. | 2 |
| **Cadencia**: las notas dicen «próxima reunión en dos semanas» (línea 8) y la configuración dice comité semanal. Dos semanas dejan la próxima en el 10-31, y antes vencen 7 compromisos que ningún comité revisaría. | Jorge Medina | Esos 7 vencen sin pasar por el comité. | 2 |

### Vence antes de la próxima
| Quién | Qué | Para cuándo |
|---|---|---|
| Diana Molina | Revisar el anexo 19 (comité 2026-10-10) | 2026-10-20 · 1 min: confirmar que va a llegar |

### No es de esta reunión

| Qué | Por qué | Dónde va |
|---|---|---|
| Rubén Cárdenas, «Cerrar la prueba 18» (vencido hace 6 días; dijo que ya lo entregó, sin acta) | No estuvo el 10-17 y no es seguro que venga. | Que Jorge Medina le pida el acta antes del 10-24; si no hay respuesta, `/pm-commitments`. |
| Sandra Gil, «Aprobar el diseño 5» (sin fecha, 35 días; dijo que ya lo entregó, sin acta) | Igual: ausente el 10-17. | Igual. |
| Los 3 entregables del proveedor sin recibo y el contrato CT-410 | Sacar al proveedor del incumplimiento excede la autoridad del gerente y lo único que se puede mover en la sala es el riesgo del punto de arriba. | La revisión del 10-27 de Óscar; si no sale acta de recibo, `/pm-escalate` hacia el comité. |
| Estado «verde» del informe del 2026-10-07 frente a 20 señales (4 hitos «cumplidos» sin evidencia, 52 puntos entre lo declarado y los hitos del plan) | Es del informe, no de la reunión: lo declara el gerente. | `/pm-report`, y `/pm-publish` si cambia. |

### Anexo — sin cambios desde el comité del 2026-10-10
No se repasa en la reunión. Ninguno vencido ni reprogramado tres veces; cuatro están a una reprogramación del umbral (marcados con *).
- Carlos Peña · matriz 6 · 10-28 *
- Óscar Ramírez · fecha 7 · 11-01 *
- María Restrepo · anexo 11 · 11-04 *
- Gustavo Neira · fecha 15 · 11-01 *
- Elena Duarte · punto 16 · 10-28
- Mauricio Pérez · documento 17 · 11-12
- Jorge Medina · ambiente 20 · 10-28
- Felipe Arango · diseño 21 · 10-28
- Andrés Lozano · matriz 22 · 10-29
- Liliana Torres · punto 24 · 11-03
- Óscar Ramírez · revisión con el proveedor · 10-27 (las notas no dicen si es una reunión o un entregable; entra en el punto del riesgo)

Nada quedó fuera por tiempo: 42 de 45 minutos.

Esta agenda no convoca a nadie. Cuando termine la reunión, `/pm-minutes` sobre las notas o la transcripción.
