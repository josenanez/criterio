# PRY-200 Crédito de libranza digital — semana del 2026-10-10 al 2026-10-17

## Señales abiertas (lo que se le muestra al gerente antes de preguntar)

El cálculo trae 20 alertas. El semáforo que consta en el último informe (verde) no explica ninguna de estas cinco señales: `commitment_overdue`, `commitment_rescheduled`, `milestone_met_without_evidence`, `progress_vs_plan`, `vendor_deliverable_late`.

**Pregunta al gerente (Jorge Medina):** ¿qué estado declara esta semana y con qué avance?
**Respuesta en esta sesión:** ninguna. La sesión no tiene interfaz y el comando prohíbe sugerir un estado, así que no se propone uno. La línea de declaración queda en blanco.

**Declara el gerente:** *(sin declaración en esta sesión)*
Último estado que consta en documento: verde · 48 % · al 2026-10-07 (`20-seguimiento/2026-10-07-informe-avance.md`, 10 días de antigüedad, no está vencida). Es la declaración anterior, no la de esta semana.
**Sustento documental:** contradicho. Ese verde no tiene sustento: el cálculo marca `declared_vs_evidence` con las cinco señales de arriba.
**Lo que el semáforo no explica:** compromisos vencidos, compromisos reprogramados, hitos «cumplidos» sin evidencia, avance contra plan y entregables de proveedor vencidos.

## Qué cambió esta semana

Sin cambios. El diff contra la corrida anterior da 0 cambios, y no hay un snapshot previo contra el cual comparar. Esta es la primera corrida de `pm-report`, así que «sin cambios» significa que no hay base para comparar. No significa que el proyecto esté quieto.

## Lo que sigue igual y sigue mal

| Qué | Desde | Días así |
|---|---|---|
| Hito «Diseño funcional aprobado» marcado cumplido sin evidencia | 2026-02-21 | 238 |
| Hito «Ambiente de pruebas certificado» marcado cumplido sin evidencia | 2026-04-17 | 183 |
| Hito «Piloto con asociados» marcado cumplido sin evidencia | 2026-08-06 | 72 |
| Hito «Salida a producción» marcado cumplido sin evidencia | 2026-10-01 | 16 |
| Proveedor: Licenciamiento del módulo, pendiente | 2026-03-14 | 217 |
| Proveedor: Bolsa de horas de desarrollo, pendiente | 2026-05-29 | 141 |
| Proveedor: Parametrización de líneas de crédito, pendiente | 2026-08-13 | 65 |

## Contra el plan

| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2026-10-01 | 2026-10-01 | 0 días (0 replanificaciones) |
| Presupuesto | COP 4.200.000.000 | COP 4.200.000.000 | proyección COP 4.010.066.854 (−4,5 %) |

Replanificaciones: 0. Solo existe la línea base v1, aprobada el 2025-12-18 con el acta de constitución.

**Lectura honesta de «0 días de desviación».** La fecha de cierre pasó hace 16 días (2026-10-01). El cronograma marca los cinco hitos como cumplidos, pero cuatro no tienen evidencia. El declarado de 48 % no coincide con el 100 % que sostiene el plan (brecha de 52 puntos, el proyecto va atrás). La línea base no se ha movido, así que la desviación no aparece en la fecha. Aparece en el avance.

### Hitos de las próximas cuatro semanas
Ninguno. Los cinco hitos del plan vencen en 2026-10-01 o antes. Tampoco hay hitos nuevos ni línea base posterior que cubra el trabajo restante.

| Hito | Base | Vigente | Evidencia |
|---|---|---|---|
| Diseño funcional aprobado | 2026-02-21 | 2026-02-21 | no encontrada |
| Ambiente de pruebas certificado | 2026-04-17 | 2026-04-17 | no encontrada |
| Integración con el core cooperativo | 2026-06-12 | 2026-06-12 | acta de recibo 2026-10-07 |
| Piloto con asociados | 2026-08-06 | 2026-08-06 | no encontrada |
| Salida a producción | 2026-10-01 | 2026-10-01 | no encontrada |

## Las cifras (COP)

| Aprobado | Comprometido | Ejecutado | Proyectado | Disponible real |
|---|---|---|---|---|
| 4.200.000.000 | 3.390.376.801 (80,7 %) | 1.405.474.333 (33,5 %) | 4.010.066.854 | **809.623.199** (aprobado − comprometido) |

Las tres cifras son declaradas en el informe del 2026-10-07. Ningún documento de evidencia las respalda (0 fuentes de evidencia, 5 declaraciones).

## Abierto

**Reprogramados:**
- Felipe Arango, «Enviar el documento 1»: 6 veces. Original 2026-09-12, hoy 2026-11-24.
- Óscar Ramírez, «Cerrar la prueba 2»: 5 veces. Original 2026-09-26, hoy 2026-12-01.
- Elena Duarte, «Revisar el anexo 3»: 4 veces. Original 2026-09-28, hoy 2026-11-17.

Los tres pasan el umbral de 3 reprogramaciones.

**Vencidos sin evidencia:**
- Elena Duarte, «Enviar el documento 9»: venció 2026-09-25, 22 días.
- Felipe Arango, «Cerrar la prueba 10»: venció 2026-10-04, 13 días.
- Rubén Cárdenas, «Cerrar la prueba 18»: venció 2026-10-11, 6 días.
- Gustavo Neira, «Actualizar la matriz 14»: venció 2026-10-14, 3 días.
- Óscar Ramírez, «Confirmar la fecha 23»: venció 2026-10-15, 2 días.

**Sin fecha:** Sandra Gil, «Aprobar el diseño 5». Gustavo Neira, «Validar el ambiente 12». Laura Vélez, «Mandar el ajuste del presupuesto» (de las notas de hoy).

**RAID sin movimiento:** dos riesgos sin dueño identificado: concentración del conocimiento en una sola persona, y que el proveedor no llegue con el equipo completo para la siguiente fase (dicho en reunión, nadie lo registró). Hay además una incidencia abierta: la prueba de carga no alcanzó el umbral pactado y se repite. La ficha no trae fechas de movimiento del RAID, así que no se calculan días.

**Proveedor (Soluciones Solidarias S.A.S., CT-410):** 3 entregables, 0 aceptados, 3 vencidos y pendientes (217, 141 y 65 días). Aceptados sin documento: ninguno. Facturado: sin dato.

## Lo que necesito de alguien

- **Jorge Medina:** declarar el estado y el avance de esta semana. Sin esa línea, el informe sale incompleto a propósito.
- **Jorge Medina:** explicar por qué cuatro hitos figuran como cumplidos sin evidencia, y por qué el avance declarado es 48 % si el plan sostiene 100 %.
- **Felipe Arango, Óscar Ramírez, Elena Duarte:** cada uno confirmar si su compromiso reprogramado tiene una fecha real o se está arrastrando.
- **Sandra Gil, Gustavo Neira, Laura Vélez:** ponerle fecha a su compromiso.
- **Autoridad sobre el contrato CT-410:** el proveedor lleva 0 de 3 entregables aceptados y el primero venció hace 217 días. Esto excede la autoridad del gerente y es material de comité, no de este informe. La ficha tampoco identifica una autoridad (`identity.authority` sin dato).

## Lo que no se sabe

**Sin dato:** `identity.authority`, `identity.phase`, y la evidencia de cuatro hitos (Diseño funcional aprobado, Ambiente de pruebas certificado, Piloto con asociados, Salida a producción). También falta el monto facturado al proveedor.
**Silencio:** el cálculo devuelve `days_silent` = sin dato, así que no se afirma un número. El último documento fechado en la carpeta es del 2026-10-10 (acta de recibo 13) y la última reunión con acta es del 2026-10-10, ambos hace 7 días. Hay además unas notas de reunión del 2026-10-17.

---
*Ficha: `estado/PRY-200-crédito-de-libranza-digital/records/PRY-200.json`, con corte al 2026-10-17. 6 campos sin dato, 20 alertas. Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17): https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.13*
