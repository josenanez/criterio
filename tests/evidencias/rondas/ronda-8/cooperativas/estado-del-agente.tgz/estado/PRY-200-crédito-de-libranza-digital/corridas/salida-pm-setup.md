Soy Samuel. Proceso lo que pasa en tu proyecto y llevo la cuenta de lo que se prometió en cada reunión.

Preguntas (sesión sin interfaz, tomé la propuesta de cada una):
1. Quién eres y qué proyecto es → Jorge Medina, gerente de PRY-200 · Crédito de libranza digital (acta de constitución).
2. Reunión de seguimiento → los sábados, cada semana (las seis minutas caen en sábado). Las notas de hoy dicen que la próxima es en dos semanas.
3. Dónde guardo lo que encuentro → `estado/PRY-200-crédito-de-libranza-digital`.
4. Términos → «Criterio produce borradores de trabajo, no decisiones ni asesoría. Procesa los documentos que usted le indique y dice lo que muestran; no sabe lo que se habló fuera de ellos. Puede equivocarse, y por eso cada dato viene con la cita del documento de donde salió: la verificación es suya. Sus documentos se procesan en la infraestructura de la plataforma de IA, no solo en su equipo. Cada versión se certifica antes de publicarse; garantía y responsabilidad: licencia Apache 2.0. Cada versión se acepta de nuevo y deja un comprobante en Markdown y PDF con su huella SHA-256. Términos completos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal». Aceptación dada en el argumento de la prueba por José Francisco Ñáñez, 2026-10-17.

## Listo — Crédito de libranza digital (PRY-200)

**Lo que miré:** 15 documentos · 7 de reunión (6 comités semanales del 2026-09-05 al 2026-10-10 y las notas del 2026-10-17, la más reciente) · 4 actas de recibo · sin formatos ilegibles. Leí todas las reuniones, de la más vieja a la más nueva.
**Términos:** aceptados para la versión 0.3.13 (términos 1.1) · comprobante en `.criterio/terminos/aceptacion-criterio-project-0.3.13-2026-10-17.md` y `.pdf` · SHA-256 b8d0cca7fea66fcb…

Son 26 compromisos en total: 3 cumplidos con acta, 23 sin cerrar.

### Lo que está abierto, y cuántas veces se ha movido
Los vencidos van primero. Todos están sin acta que los pruebe.

| Quién | Qué | Para cuándo | |
|---|---|---|---|
| Elena Duarte | Enviar el documento 9 | 2026-09-25 | Vencido hace 22 días. El 09-26 dijo que ya lo entregó; no hubo acta y no volvió a aparecer (`30-reuniones/2026-09-19-comite-semanal.md`) |
| Felipe Arango | Cerrar la prueba 10 | 2026-10-04 | Vencido hace 13 días. El 10-10 dijo que ya lo entregó; no hubo acta (`30-reuniones/2026-09-19-comite-semanal.md`) |
| Rubén Cárdenas | Cerrar la prueba 18 | 2026-10-11 | Vencido hace 6 días. El 10-10 dijo que ya lo entregó; no hubo acta (`30-reuniones/2026-10-03-comite-semanal.md`) |
| Gustavo Neira | Actualizar la matriz 14 | 2026-10-14 | Vencido hace 3 días (`30-reuniones/2026-09-26-comite-semanal.md`) |
| Óscar Ramírez | Confirmar la fecha 23 | 2026-10-15 | Vencido hace 2 días (`30-reuniones/2026-10-10-comite-semanal.md`) |
| Felipe Arango | Enviar el documento 1 | 2026-11-24 | Movido 6 veces. Prometido el 2026-09-12, luego 09-22, 10-11, 10-24, 11-03, 11-10 y 11-24 (`30-reuniones/2026-09-05-comite-semanal.md`; última fecha en `2026-10-17-notas-reunion.txt`) |
| Óscar Ramírez | Cerrar la prueba 2 | 2026-12-01 | Movido 5 veces. Prometido el 2026-09-26, luego 10-03, 10-21, 11-10, 11-17 y 12-01 (`30-reuniones/2026-09-05-comite-semanal.md`) |
| Elena Duarte | Revisar el anexo 3 | 2026-11-17 | Movido 4 veces. Prometido el 2026-09-28, luego 10-05, 10-22, 10-29 y 11-17 (`30-reuniones/2026-09-05-comite-semanal.md`) |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-27 | Nuevo hoy (`2026-10-17-notas-reunion.txt`) |

Los otros 11 compromisos con fecha están vigentes y no cruzan el umbral de reprogramaciones. Están en la ficha.

### Sin fecha
Nadie los fechó, así que no pueden estar vencidos y por eso se pierden en los informes.
- Sandra Gil · Aprobar el diseño 5. Sin fecha desde el 2026-09-12. El 09-26 dijo que ya lo entregó, sin acta, y desapareció de las tablas (`30-reuniones/2026-09-12-comite-semanal.md`).
- Gustavo Neira · Validar el ambiente 12. Sin fecha desde el 2026-09-19. El 09-26 dijo que ya lo entregó, sin acta, y desapareció de las tablas (`30-reuniones/2026-09-19-comite-semanal.md`).
- Laura Vélez · Mandar el ajuste del presupuesto. Dijo «la otra semana» el 2026-10-17; es una fecha que nadie dijo, así que no la calculé (`2026-10-17-notas-reunion.txt`).

### Otras señales que levantó el cálculo
- **El estado declarado es verde (48%, informe del 2026-10-07) y 5 tipos de señal lo contradicen.** El cronograma da 5 de 5 hitos cerrados, una distancia de 52 puntos contra el 48% declarado (`20-seguimiento/2026-10-07-informe-avance.md`).
- **4 de los 5 hitos están declarados cerrados sin acta** (la integración con el core sí la tiene, del 2026-10-07): diseño funcional (2026-02-21), ambiente de pruebas (2026-04-17), piloto (2026-08-06) y salida a producción (2026-10-01) (`10-plan/2025-12-18-cronograma-v1.xlsx`). El mismo informe dice «Se reprogramó la salida», y el cronograma la muestra cerrada el 2026-10-01.
- **3 entregables del proveedor Soluciones Solidarias (CT-410) siguen pendientes sin acta de recibo:** licenciamiento (217 días de atraso), bolsa de horas (141) y parametrización (65) (`00-gobierno/2025-12-13-contrato-ct-410.md`).
- **Presupuesto** (declarado en el informe): comprometido 80,7% y ejecutado 33,5% de 4.200.000.000 COP. La proyección al cierre es 4.010.066.854 COP, 4,5% por debajo de lo aprobado.
- **Riesgo que se dijo y nadie anotó:** el proveedor podría no llegar con el equipo completo para la siguiente fase (`2026-10-17-notas-reunion.txt`). Lo dejé en la ficha, sin dueño.

### Qué le falta a tu carpeta
- Actas de recibo para los 4 hitos cerrados sin prueba y para los 3 entregables del proveedor. Sin ellas lo cumplido se ve igual que lo incumplido.
- Actas de recibo de las pruebas 10 y 18, el documento 9, el diseño 5 y el ambiente 12, que cuatro personas dicen haber entregado.
- Un cronograma posterior a la v1 (es del 2025-12-18 y ya muestra todo cerrado). Sin él no se sabe la fecha vigente de salida, que tomé del último hito.
- El campo de la facultad del gerente (hasta qué monto y qué cambio de alcance decide sin comité) no está en el acta.
- Minutas anteriores al 2026-09-05. Hoy el historial arranca ahí, y un compromiso movido antes de esa fecha se vería como si empezara en septiembre.

**Cuándo vuelvo:** el sábado 2026-10-31, porque las notas de hoy dicen que la próxima reunión es en dos semanas (la cadencia normal es semanal, los sábados).
