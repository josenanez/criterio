Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17); no hizo falta volver a pedirlos.

Antes de escribir, recalculé la ficha (`compute`, corte 2026-10-17). La fecha de cierre sigue siendo 2026-10-01: no hay un cronograma más nuevo que `10-plan/2025-12-18-cronograma-v1.xlsx`, y coincide con la línea base (sin diferencia).

Publiqué la ficha en `/home/claude/banco/ronda-8/cooperativas/espacio/documentos/proyectos/PRY-200-crédito-de-libranza-digital/00-gobierno/ficha-pm.json`, con corte al 2026-10-17.

**Lleva:** 38 campos con dato · 6 sin decir en ninguna parte (autoridad, fase y la evidencia de 4 hitos) · declara **verde** al 2026-10-07

**Lo más viejo que va ahí:** la identidad, el plan y el presupuesto aprobado, del 2025-12-18 (acta de constitución y cronograma v1), unos 10 meses; no pasa de un año.

**Lo primero que va a mirar la PMO:** el verde está contradicho. El informe declara 48 % y verde, pero el cronograma marca los 5 hitos como cumplidos (4 sin evidencia), hay 5 compromisos vencidos, 3 reprogramados 4 veces o más, y 3 entregables del proveedor CT-410 pendientes y vencidos (0 aceptados). Son 20 alertas en total. La ficha marca el estado como declarado por el gerente, no como lectura de la PMO.

No toqué ningún otro archivo. No avisé a nadie: Vera la leerá en su próximo barrido.
