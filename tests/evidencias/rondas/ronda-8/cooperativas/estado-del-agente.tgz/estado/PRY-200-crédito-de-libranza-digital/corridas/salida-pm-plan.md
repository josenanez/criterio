# Plan — PRY-200 · Crédito de libranza digital · borrador del 2026-10-17
**Desde:** acta de constitución del 2025-12-18 (`00-gobierno/2025-12-18-acta-constitucion.md`) · **Criterio de éxito:** «Crédito de libranza digital en producción y medido» (acta, sección *Criterio de éxito*)

Términos de la versión 0.3.13 ya aceptados por José Francisco Ñáñez el 2026-10-17 (comprobante en `.criterio/terminos/`); no se registró uno nuevo.

## Antes de leer el borrador: este plan no es de un proyecto que arranca

Hay tres documentos que no caben en el mismo cuadro, y lo digo antes de descomponer nada:

- El acta compromete **cierre 2026-10-01**; hoy es 2026-10-17. Esa fecha ya pasó.
- El `cronograma-v1.xlsx` (10-plan, fechado 2025-12-18) marca los **5 hitos como «cerrado»**, incluida *Salida a producción*, con fecha vigente igual a la de línea base en los cinco.
- El contrato CT-410 tiene 3 entregables del proveedor, ninguno marcado como terminado: *Licenciamiento* «pendiente» (fecha comprometida 2026-03-14), *Bolsa de horas* y *Parametrización* «en curso» (2026-05-29 y 2026-08-13). Las notas de hoy hablan de «la siguiente fase» con el proveedor.

No resuelvo la contradicción ni elijo cuál de los documentos manda. Pero cambia el tipo de documento que estoy produciendo: si el proyecto ya está en ejecución y pasó su cierre, lo que se necesita es una **replanificación**, que pasa por control de cambios y no crea una línea base original; este borrador sirve como insumo de eso, no como la línea base. **Decide tú cuál es el caso.**

## Lo que le falta al acta

| Qué | Consecuencia de planificar sin eso |
|---|---|
| **Alcance: «Componente 1, Componente 2, Componente 3»** y fuera de alcance: «Lo que otro proyecto cubre» | Es texto de plantilla. No hay entregables que descomponer desde el acta; los tres componentes quedan **sin definir** y cualquier WBS que los nombre los estaría inventando. |
| **Criterio de éxito sin umbral**: «en producción y medido» | No dice qué se mide, con qué indicador ni cuánto. «Medido» no es aceptable ni rechazable, así que el último nodo de la WBS no se puede cerrar. |
| **Autoridad del gerente no declarada** (no hay sección; la ficha del proyecto la registra como no encontrada) | No sé qué puedes decidir tú al planificar y qué hay que subir. Por eso nada de este borrador compromete fecha, costo ni alcance. |
| **Dependencias: «Ninguna declarada»** | Existe el contrato CT-410 con Soluciones Solidarias S.A.S., que ya es una dependencia; además el hito *Integración con el core cooperativo* apunta a otro sistema. Las dependencias reales no están en el acta. |
| **Presupuesto 4.200.000.000 COP sin desglose** | El contrato CT-410 suma 582.176.016 COP (3 × 194.058.672), cerca del 14 % del total. El otro 86 % no tiene entregable ni proveedor identificado en ningún documento que yo vea. |
| **Patrocinador presente** (Carlos Peña) y comité (Consejo de Administración) | No falta. Hay a quién llevarle las excepciones. |

Se puede seguir marcándolo así. No relleno ninguno de estos huecos.

## WBS

Cada nodo terminal es algo que alguien recibe y acepta. La columna *De dónde sale* usa solo los tres estados; cuando el nodo está en otro documento que no es el acta, queda como **supuesto** y la cita dice cuál.

| # | Entregable | Quién lo acepta | De dónde sale | Duración |
|---|---|---|---|---|
| 1 | Diseño funcional aprobado | sin definir | supuesto — hito en `cronograma-v1.xlsx`, no en el acta | vacía |
| 2 | Ambiente de pruebas certificado | sin definir | supuesto — hito en `cronograma-v1.xlsx` | vacía |
| 3 | Licenciamiento del módulo (CT-410) | acta de recibo firmada por el gerente del proyecto (contrato); quién acepta por el negocio: sin definir | supuesto — está en el contrato CT-410, no en el acta | vacía · el contrato fija 2026-03-14 |
| 4 | Bolsa de horas de desarrollo (CT-410) | igual que el 3 | supuesto — contrato CT-410 | vacía · el contrato fija 2026-05-29 |
| 5 | Parametrización de líneas de crédito (CT-410) | igual que el 3 | supuesto — contrato CT-410 | vacía · el contrato fija 2026-08-13 |
| 6 | Integración con el core cooperativo | sin definir | supuesto — hito en `cronograma-v1.xlsx` | vacía |
| 7 | Piloto con asociados | sin definir | supuesto — hito en `cronograma-v1.xlsx` | vacía |
| 8 | Crédito de libranza digital en producción | sin definir | del acta — *Criterio de éxito* («en producción») | vacía |
| 9 | Medición del producto en producción | sin definir | del acta — *Criterio de éxito* («y medido»); qué se mide: sin definir | vacía |
| 10–12 | Componentes 1, 2 y 3 del alcance | sin definir | sin definir — el acta solo trae texto de plantilla | vacía |

Las fechas del contrato y del cronograma v1 son referencia citada, no fechas de este plan.

## Orden

Qué necesita qué. Sin fechas. Todo el orden es **supuesto** mío, porque el acta no declara dependencias:

- 1 → 2 → 6 → 7 → 8 → 9: el diseño antes del ambiente, el ambiente antes de la integración, la integración antes del piloto, el piloto antes de producción, producción antes de medir. Es el orden en que aparecen los hitos en `cronograma-v1.xlsx`, no una dependencia escrita.
- 3 (licenciamiento) antes de 5 (parametrización): no se parametriza un módulo sin licencia. Supuesto.
- 4 (bolsa de horas) sin predecesor claro: no sé de qué trabajos se descuentan las horas.
- 10–12: no se puede ordenar lo que no está definido.

## Supuestos sobre los que está construido

| Supuesto | Qué pasa si resulta falso |
|---|---|
| Los 5 hitos de `cronograma-v1.xlsx` son los entregables del proyecto | Faltan o sobran nodos; el alcance real puede ser distinto (ver componentes 1–3). |
| Los entregables de CT-410 son parte de este alcance y no de otro proyecto | Cambia qué se acepta y quién lo hace. |
| El orden de los hitos del cronograma v1 es dependencia técnica y no solo secuencia de calendario | Se puede paralelizar o, al revés, hay dependencias no vistas. |
| El presupuesto de 4.200.000.000 COP sigue vigente | En la reunión de hoy, Laura Vélez quedó de mandar «el ajuste del presupuesto la otra semana»; si cambia, cambia la línea de costo de todo el plan. |
| El proyecto sigue en ejecución y el cierre del 2026-10-01 no se cumplió | Si en realidad cerró, este borrador sobra y el paso es *project-closure*. |
| El proveedor sigue disponible para «la siguiente fase» | Las notas de hoy dicen que podría no llegar con el equipo completo; ningún documento registra ese riesgo. |

## Sin definir

| Qué | Quién lo define |
|---|---|
| Componentes 1, 2 y 3 del alcance | El patrocinador (Carlos Peña) o quien firmó el acta; el acta no lo dice |
| Qué es «medido»: indicador, umbral, fuente | Sin doliente en ningún documento |
| Quién acepta cada entregable por el negocio | Sin doliente en ningún documento |
| Autoridad del gerente del proyecto | El patrocinador / Consejo de Administración |
| Dependencias reales del proyecto | El gerente, con el patrocinador |
| A qué se destina el 86 % del presupuesto fuera de CT-410 | Sin doliente en ningún documento |
| Qué es «la siguiente fase» mencionada en las notas del 2026-10-17 | Sin doliente en ningún documento |
| Qué es el «documento 1» de Felipe Arango (compromiso para el 24/11/2026) | Felipe Arango |

## Proyectos análogos

**No hay ninguno a la vista.** La configuración de este proyecto no apunta a una carpeta de fichas de la PMO, así que no consulté ficha alguna y no traigo números de otros proyectos. La carpeta de documentos tiene otros proyectos (por nombre, PRY-209 *Convenios de libranza con empresas* parece cercano), pero son documentos sin ficha; no los leí para esto y no extraigo de ellos ninguna cifra. Si quieres referencia, el camino es correr el barrido del portafolio y volver a este comando.

## Preguntas para el equipo

Una por cada duración vacía:

1. Diseño funcional aprobado: ¿cuánto toma, y quién lo aprueba por el negocio?
2. Ambiente de pruebas certificado: ¿cuánto toma, y quién certifica?
3. Licenciamiento: el contrato dice 2026-03-14 y el estado es «pendiente». ¿Esa fecha sigue vigente? ¿Cuánto falta realmente?
4. Bolsa de horas: ¿cuántas horas se han consumido y cuántas quedan? ¿Cuánto toma lo que falta?
5. Parametrización de líneas: la fecha del contrato (2026-08-13) ya pasó con estado «en curso». ¿Cuánto toma lo que falta?
6. Integración con el core cooperativo: ¿cuánto toma, y quién del core participa?
7. Piloto con asociados: ¿cuánto dura, con cuántos asociados y quién acepta el resultado?
8. Salida a producción: ¿cuánto toma, y con qué criterio se decide que se sale?
9. Medición: ¿qué se mide, desde cuándo, durante cuánto tiempo?
10–12. Componentes 1, 2 y 3: ¿cuáles son? Sin eso no hay duración que preguntar.

## Para comprometer una fecha falta

Ninguna de estas tres está en un documento:

- La **disponibilidad real del equipo** del proyecto.
- La **fecha del proveedor**, hoy en duda por lo dicho en la reunión: la «revisión con el proveedor» de Óscar Ramírez es el 2026-10-27, y es el primer momento en que se podría saber.
- La **ventana de la sala de producción**.

Y antes de todas, la decisión previa: si esto es una replanificación (con control de cambios) o un plan nuevo.

## Después

Cuando alguien apruebe el plan, ofrezco registrarlo como línea base (original o vigente, según lo que decidas arriba) y pasar los supuestos al RAID con doliente. Hay un riesgo que ya se dijo en voz alta y que nadie registró: *el proveedor podría no llegar con el equipo completo para la siguiente fase* (reunión del 2026-10-17). No lo registro yo: es tu RAID.
