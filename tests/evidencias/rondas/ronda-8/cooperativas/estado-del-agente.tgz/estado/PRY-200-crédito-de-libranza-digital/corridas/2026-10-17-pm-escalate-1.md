# Corrida del 2026-10-17 · pm-escalate

1 proyectos · 36 s · 20 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_overdue` | 5 |
| `milestone_met_without_evidence` | 4 |
| `commitment_undated` | 3 |
| `commitment_rescheduled` | 3 |
| `vendor_deliverable_late` | 3 |
| `progress_vs_plan` | 1 |
| `declared_vs_evidence` | 1 |

Escaló un solo punto: autoridad del gerente no declarada en el acta. No calculó impacto (sin días de cambio ni fecha nueva de salida). No dijo cuánto cuesta cada opción ni si hay proyectos alcanzados.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## Para decisión — PRY-200 · Crédito de libranza digital · 2026-10-17

*Términos vigentes (versión 1.1), aceptados por José Francisco Ñáñez el 2026-10-17. Sin tema indicado: se revisó lo que cumple el criterio de escalamiento en la ficha.*

### ¿Declara hoy el Consejo de Administración, por escrito, qué puede decidir el gerente (Jorge Medina) en fechas, presupuesto y proveedor, y qué debe llevar al Consejo?

**Este es el primer punto que escala, y no hay otro todavía.** El acta de constitución (2025-12-18) nombra patrocinador, gerente, comité y presupuesto, pero **no declara la autoridad del gerente** (`identity.authority`: no encontrado). Sin ese límite no se puede decir si lo demás excede o no su facultad: es el motivo por el que no armo paquetes separados para el resto.

**Quién decide:** el Consejo de Administración (es el comité y quien aprobó el presupuesto según el acta; el patrocinador es Carlos Peña). El acta no dice quién *más* puede fijar esa autoridad; confirmarlo es parte de la respuesta. · **Si no se decide hoy:** no hay fecha límite en ningún documento; no la invento. Lo que sí está escrito: el cierre comprometido (2026-10-01) ya pasó sin línea base nueva, y la próxima reunión es en dos semanas (≈2026-10-31).

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. El Consejo declara la autoridad (límites de fecha, presupuesto y proveedor) en el acta o en un anexo | Sin cambio de alcance | Una sesión; la acta ya existe | No declarado en los documentos |
| B. Se deja como está y cada decisión sube caso por caso | Sin cambio | Cada punto depende de que el comité esté reunido | No declarado; riesgo: puntos devueltos por «eso lo decide usted» o decididos sin facultad |

**Recomiendo:** A — es la única que permite distinguir en adelante qué escala y qué no; con B el gerente subiría todo o nada.

### Lo que revisé y por ahora NO armo como escalamiento

| Asunto | Por qué no (todavía) | Qué hacer |
|---|---|---|
| Salida a producción / cierre 2026-10-01 vencido; el informe del 2026-10-07 dice «se reprogramó la salida» pero no hay fecha nueva ni línea base 2 | Es **control de cambios**, no escalamiento: falta la fecha nueva, y sin ella no hay días que calcular. La línea base v1 no se toca | Definir la fecha nueva y registrar el cambio aparte |
| Proveedor Soluciones Solidarias (CT-410): 3 entregables vencidos (2026-03-14, 05-29, 08-13), ninguno con acta de recibo; en la reunión de hoy se comentó que podría no llegar con el equipo completo, y nadie lo registró como riesgo | Excede la autoridad solo si el acta lo dijera; no lo dice. Hay revisión con el proveedor el 2026-10-27 (Óscar Ramírez) | Registrar el riesgo en el RAID; llevar a esa revisión el estado de los 3 entregables. Si de ahí sale una decisión de cambio de proveedor o de plazo, ese sí escala |
| Compromisos reprogramados 3 veces o más: «Enviar el documento 1» (Felipe Arango, 5 veces, hoy al 2026-11-24), «Cerrar la prueba 2» (Óscar Ramírez, 4 veces, al 2026-12-01), «Revisar el anexo 3» (Elena Duarte, 3 veces, al 2026-11-17) | Cumplen el umbral, pero los dolientes están dentro del proyecto y no se documenta que dependan de otra área | Llamarlos; si tras la llamada no se mueven, escalan |
| Salud declarada verde con avance 48% y cierre vencido | Es una contradicción para el informe, no una decisión | Resolver en `/pm-report` |

### A quién alcanza
**No calculado.** `impact` necesita un número de días de cambio y no hay ninguno en los documentos (la fecha nueva de salida no existe). No lo estimo. Además, el acta declara «Ninguna dependencia» con otros proyectos, así que no hay proyecto alcanzado documentado; eso tampoco prueba que no lo haya.

### Mis hitos por los que pasa
**No calculado**, por la misma razón. Hito afectado a la vista: «Salida a producción», fecha vigente 2026-10-01 (ya vencida), marcado `met` en el cronograma v1 **sin evidencia de recibo** (`evidence`: no encontrado).

### De dónde sale esto
- Autoridad no declarada; patrocinador, comité, presupuesto 4.200.000.000 COP, cierre 2026-10-01: `00-gobierno/2025-12-18-acta-constitucion.md`.
- Entregables y condición de pago (acta de recibo firmada por el gerente): `00-gobierno/2025-12-13-contrato-ct-410.md`. Sin acta de recibo en `20-seguimiento/` para ninguno de los tres.
- «Se reprogramó la salida», estado verde, 48%: `20-seguimiento/2026-10-07-informe-avance.md`.
- Comentario del proveedor, próxima reunión en dos semanas, revisión 2026-10-27: `2026-10-17-notas-reunion.txt`.
- Reprogramaciones: `estado/…/records/PRY-200.json`, campo `commitments`.

**Lo que no sé:** qué puede decidir el gerente; la fecha nueva de salida; cuánto cuesta cada opción; si hay otros proyectos alcanzados; qué se habló fuera de estos documentos.
