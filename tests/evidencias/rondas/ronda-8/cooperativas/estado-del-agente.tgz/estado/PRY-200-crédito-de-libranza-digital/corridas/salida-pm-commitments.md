## Compromisos — Crédito de libranza digital (PRY-200) · al 2026-10-17

26 compromisos en la ficha: 18 abiertos, 5 vencidos sin evidencia, 3 cerrados con documento. De los 18 abiertos, 3 no tienen fecha. Cifras de `portafolio.py compute`; sin `record_issues`.

### Se viene reprogramando

> **Felipe Arango** · Enviar el documento 1
> Prometido para el 2026-11-24 (dicho el 2026-10-17), y antes para el 11-10, el 11-03, el 10-24, el 10-11 y el 09-22. La primera promesa fue el 2026-09-12.
> **Seis reprogramaciones en cinco semanas: es un bloqueo que nadie ha nombrado, no un problema de seguimiento.**

> **Óscar Ramírez** · Cerrar la prueba 2
> Prometido para el 2026-12-01, y antes para el 11-17, el 11-10, el 10-21 y el 10-03. La primera promesa fue el 2026-09-26.
> **Cinco reprogramaciones. La fecha vigente se aleja más de lo que avanzan las semanas.**

> **Elena Duarte** · Revisar el anexo 3
> Prometido para el 2026-11-17, y antes para el 10-29, el 10-22 y el 10-05. La primera promesa fue el 2026-09-28.
> **Cuatro reprogramaciones.**

Cerca del umbral (2 reprogramaciones, el umbral es 3): Carlos Peña (matriz 6, hoy 10-28), Óscar Ramírez (fecha 7, hoy 11-01), María Restrepo (anexo 11, hoy 11-04) y Gustavo Neira (fecha 15, hoy 11-01). Aún no son hallazgo.

### Vencidos sin evidencia
| Quién | Qué | Prometido para | Hace |
|---|---|---|---|
| Elena Duarte | Enviar el documento 9 | 2026-09-25 | 22 días |
| Felipe Arango | Cerrar la prueba 10 | 2026-10-04 | 13 días |
| Rubén Cárdenas | Cerrar la prueba 18 | 2026-10-11 | 6 días |
| Gustavo Neira | Actualizar la matriz 14 | 2026-10-14 | 3 días |
| Óscar Ramírez | Confirmar la fecha 23 | 2026-10-15 | 2 días |

Tres de ellos tienen un «ya lo entregué» dicho en comité sin acta que lo respalde, y desde entonces no aparecen en las tablas: Elena Duarte (documento 9, dicho el 09-26), Felipe Arango (prueba 10, dicho el 10-10) y Rubén Cárdenas (prueba 18, dicho el 10-10). Siguen abiertos: no hay nada en el expediente que lo respalde.

### Vencen esta semana
| Quién | Qué | Para cuándo |
|---|---|---|
| Diana Molina | Revisar el anexo 19 | 2026-10-20 |

### Sin fecha
| Quién | Qué | Dicho el |
|---|---|---|
| Sandra Gil | Aprobar el diseño 5 | 2026-09-12 |
| Gustavo Neira | Validar el ambiente 12 | 2026-09-19 |
| Laura Vélez | Mandar el ajuste del presupuesto («la otra semana») | 2026-10-17 |

Sandra Gil y Gustavo Neira dijeron el 2026-09-26 que ya lo habían entregado; no se presentó acta. Llevan 35 y 28 días abiertos sin fecha y sin evidencia, y no pueden figurar como vencidos. Para Laura Vélez, «la otra semana» no es una fecha; se dejó como `no_declarada` con el texto original.

### Cerrados desde la última revisión
| Quién | Qué | Documento que lo cierra |
|---|---|---|
| María Restrepo | Validar el ambiente 4 | 20-seguimiento/2026-09-12-acta-recibo-4.md |
| Laura Vélez | Entregar el punto 8 (reprogramado una vez) | 20-seguimiento/2026-09-26-acta-recibo-8.md |
| Paula Céspedes | Aprobar el diseño 13 | 20-seguimiento/2026-10-10-acta-recibo-13.md |

### Después
- Tres compromisos pasaron el umbral de reprogramación. Se puede formular el de Felipe Arango (documento 1) como decisión para el comité: qué se pide, qué pasa si no se decide y quién tiene la facultad. Excede la autoridad del gerente.
- La ficha dice «verde» (informe del 2026-10-07) y estos compromisos la contradicen. `/pm-publish` deja que la PMO lo vea.
- Sin documento no se cierra nada: este comando no marcó cumplido ningún compromiso por palabra de nadie.
