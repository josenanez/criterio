# Acta — Crédito de libranza digital (PRY-200) · 2026-10-17

**Asistieron:** Andrés Lozano, Carlos Peña, Diana Molina, Elena Duarte, Felipe Arango, Gustavo Neira, Jorge Medina, Laura Vélez, Liliana Torres, María Restrepo, Mauricio Pérez, Óscar Ramírez · **Fuente:** `2026-10-17-notas-reunion.txt` (notas de 5 líneas, sin agenda) · **Ausentes con compromisos abiertos:** Rubén Cárdenas, Sandra Gil. Las notas no traen agenda, así que no puedo decir si tenían tema en ella.

Los nombres de las notas coinciden con los de la ficha; no hubo que normalizar ninguno.

## Compromisos
| Quién | Qué | Para cuándo | |
|---|---|---|---|
| Felipe Arango | Enviar el documento 1 («no alcanzó», se compromete de nuevo; línea 4) | 2026-11-24 | **Reprogramado por 6.ª vez.** Prometido por primera vez para 2026-09-12; fechas siguientes: 09-22, 10-11, 10-24, 11-03, 11-10, 11-24. La fecha nueva queda 73 días después de la original. |
| Óscar Ramírez | Revisión con el proveedor (línea 6) | 2026-10-27 | Nuevo. Las notas dicen «queda para el 2026-10-27»; no dicen si es una reunión o un entregable. Se registra como compromiso de Óscar, y eso es una lectura mía. |

### Sin fecha
| Quién | Qué |
|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto. Dijo «la otra semana» (línea 5): fecha relativa, sin día. Queda `no_declarada` con esa cita; no la convierto en 2026-10-19 ni en 2026-10-24. |

Ya había dos sin fecha de reuniones anteriores, con lo que son **3 compromisos sin fecha** en total: Sandra Gil (Aprobar el diseño 5) y Gustavo Neira (Validar el ambiente 12).

## Decisiones
Ninguna. Las notas no registran que alguien haya decidido algo.

## Quedó sin decidir
Ninguna cuestión se nombra como pendiente de decisión. Un punto relacionado: «ajuste del presupuesto» (Laura Vélez) sugiere que se va a pedir un cambio, pero las notas no dicen de cuánto ni quién lo aprobaría. No se registra como decisión ni como cambio.

## Intenciones sin doliente
Ninguna.

## Dicho al pasar y no registrado
| Qué | Quién lo dijo | Categoría | Ya estaba en el RAID |
|---|---|---|---|
| «El proveedor podría no llegar con el equipo completo para la siguiente fase»; las notas añaden que nadie lo anotó como riesgo (línea 7) | Sin atribuir: las notas dicen «se comentó» | Riesgo | No. El proyecto no tiene un RAID aparte. En la ficha solo está la concentración del conocimiento en una persona, del informe del 2026-10-07. Entra ahora con dueño `no_identificado`. |

El proveedor del contrato CT-410 es Soluciones Solidarias S.A.S., que tiene los 3 entregables pendientes y sin evidencia de recibo. Las notas no dicen que sea ese proveedor, pero es el único que hay en la ficha. Lo nombro como contexto y no lo afirmo.

## Cerrado en esta reunión
Nada. Se omite la sección: ninguna frase de las notas viene con un documento.

## Lo que esta reunión contradice
Nada comprobable. Patrocinador, gerente, comité y presupuesto no cambian en las notas. Hay una tensión sin resolver, que va abajo.

## Sin resolver de la transcripción
- «próxima reunión en dos semanas» (línea 8): la configuración del proyecto tiene comité **semanal**, los sábados. Dos semanas dejan la próxima en 2026-10-31. Antes de esa fecha vencen Diana Molina (anexo 19, 10-20), Carlos Peña (matriz 6, 10-28), Jorge Medina (ambiente 20, 10-28), Elena Duarte (punto 16, 10-28), Felipe Arango (diseño 21, 10-28), Andrés Lozano (matriz 22, 10-29) y la propia revisión con el proveedor del 10-27. Ninguno se revisaría en comité. No quedó claro si es un cambio de cadencia o un descuido.
- «la siguiente fase» (línea 7): el cronograma v1 cierra el proyecto el 2026-10-01 con «Salida a producción» en estado met, y ninguna ficha nombra fases. Las notas hablan de una fase que viene. No sé si hay una ampliación no documentada o si el hito se declaró cumplido sin estarlo. Está sin resolver.
- Las notas no dicen nada de los 5 compromisos ya vencidos (ver abajo).

## Lo que el acta no cubre, con la cuenta recalculada

`compute` sobre la ficha (sin `record_issues`):

- **Vencidos sin evidencia (5):** Elena Duarte, documento 9 (22 días); Felipe Arango, prueba 10 (13); Rubén Cárdenas, prueba 18 (6, ausente hoy); Gustavo Neira, matriz 14 (3); Óscar Ramírez, fecha 23 (2). Las notas no los mencionan. Elena, Felipe y Rubén dijeron antes que ya habían entregado, y no hay acta de recibo.
- **Reprogramados 3 veces o más (3):** Felipe Arango, documento 1 (6 veces); Óscar Ramírez, prueba 2 (5; ahora 2026-12-01); Elena Duarte, anexo 3 (4).
- **Sin fecha (3).**
- **Estado declarado:** el informe del 2026-10-07 dice verde y 48 %. El cálculo lo contradice con 20 señales: 4 hitos «cumplidos» sin evidencia, 52 puntos entre el avance declarado y los hitos del plan, y los 3 entregables del proveedor pendientes y sin recibo. Esta reunión no cambia ese cuadro.

## Después
Esta acta sale en la conversación y la guardas tú; no escribí nada en `30-reuniones/`. `/pm-commitments` muestra el seguimiento completo. `/pm-publish` no hace falta por esta reunión: ningún campo oficial cambió.
