Cierre de PRY-200 · Crédito de libranza digital. Sale de la ficha `estado/records/PRY-200.json`, de la salida de `compute` del 2026-10-17 y de estos documentos: acta de constitución (2025-12-18), contrato CT-410 (2025-12-13), cronograma v1 (2025-12-18), informe de avance (2026-10-07), acta de recibo de la integración con el core (2026-10-07) y las notas de la reunión del 2026-10-17. Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17).

## Cierre — PRY-200 Crédito de libranza digital — 2026-10-17

**Veredicto: el proyecto no se puede cerrar contra su criterio de éxito con la documentación disponible.** Si se cerrara hoy, sería por decisión y no por cumplimiento. Todo lo que el cierre necesita para afirmar que se cumplió está sin evidencia o en contradicción con otro documento.

### Contra lo comprometido
**Criterio de éxito:** «Crédito de libranza digital en producción y medido» (acta de constitución, 2025-12-18, sección Criterio de éxito).
**Se cumplió:** no se puede determinar.
- No hay ningún documento que pruebe la puesta en producción. El hito «Salida a producción» (2026-10-01) está marcado como cumplido en el cronograma v1, sin evidencia. El informe de avance del 2026-10-07 dice lo contrario: «Se reprogramó la salida por el cierre contable de fin de mes».
- No hay ninguna medición del crédito. Ningún documento define qué se mide ni con qué umbral, y el acta tampoco lo define. La mitad «medido» del criterio no se puede comprobar, ni siquiera en principio.
- El mismo informe dice que «La prueba de carga no alcanzó el umbral pactado y se repite».

| Entregable comprometido | Estado | Evidencia |
|---|---|---|
| Diseño funcional aprobado (2026-02-21) | Cumplido según cronograma | Ninguna (hace 238 días) |
| Ambiente de pruebas certificado (2026-04-17) | Cumplido según cronograma | Ninguna (hace 183 días) |
| Integración con el core cooperativo (2026-06-12) | Cumplido | Acta de recibo del 2026-10-07, firmada 117 días después de la fecha comprometida |
| Piloto con asociados (2026-08-06) | Cumplido según cronograma | Ninguna (hace 72 días) |
| Salida a producción (2026-10-01) | Cumplido según cronograma; el informe dice que se reprogramó | Ninguna, y contradicha por el informe del 2026-10-07 |

Los 117 días son mi cálculo, no una cifra de `compute`: del 2026-06-12 al 2026-10-07.

Solo 1 de los 5 hitos tiene evidencia. El informe declara 48 % de avance y el cronograma marca 5 de 5 hitos cumplidos. La brecha que da `compute` es de 52 puntos. Las dos cifras no pueden ser ciertas a la vez. El estado declarado es «verde», y `compute` lo marca como no respaldado por cinco señales: compromisos vencidos, compromisos reprogramados, hitos cumplidos sin evidencia, avance contra plan y entregables de proveedor atrasados.

### Fuera de alcance final
| Qué quedó fuera | Decidido por | Cuándo |
|---|---|---|
| Sin dato: el acta pactó «Componente 1, 2 y 3» sin describirlos, y no hay registro de qué se entregó de cada uno | — | — |
| «Lo que otro proyecto cubre» (exclusión original del acta, sin concretar) | Acta de constitución | 2025-12-18 |

No hay solicitudes de cambio registradas (0 cambios). Tampoco hay decisión que respalde ningún recorte. No puedo decir si se recortó alcance, porque los componentes nunca se describieron.

### Números finales
| | Original | Vigente | Final | Desviación vs original |
|---|---|---|---|---|
| Fecha de cierre | 2026-10-01 | 2026-10-01 | Sin dato: no hay salida a producción documentada | 0 días según `compute`. La cifra no es confiable: el informe dice que la salida se reprogramó y no existe línea base nueva |
| Presupuesto aprobado | 4.200.000.000 COP | 4.200.000.000 COP | — | — |
| Comprometido (corte 2026-10-07) | | | 3.390.376.801 COP (80,7 %) | — |
| Ejecutado (corte 2026-10-07) | | | 1.405.474.333 COP (33,5 %) | — |
| Proyección al cierre (declarada) | | | 4.010.066.854 COP | −4,5 % contra el aprobado |

Replanificaciones: 0 (una sola línea base, la v1 del 2025-12-18). El informe menciona una reprogramación de la salida que no quedó como línea base nueva. Es un hallazgo del cierre: la fecha se movió sin dejar registro.

Disponible real: 809.623.199 COP.

Las cifras de dinero son declaradas por el gerente en el informe del 2026-10-07, no están respaldadas por un ejecutado contable. La proyección de 4.010.066.854 con solo 33,5 % ejecutado exige que se gaste el 66,5 % restante, y el informe no lo explica. Además, el 2026-10-17 se acordó que Laura Vélez mandaría un «ajuste del presupuesto» (sin fecha; dijo «la otra semana»). Las cifras de presupuesto pueden estar desactualizadas.

### Proveedor Soluciones Solidarias S.A.S. (CT-410)
| Entregable | Fecha | Monto COP | Estado | Atraso al 2026-10-17 |
|---|---|---|---|---|
| Licenciamiento del módulo | 2026-03-14 | 194.058.672 | pendiente | 217 días |
| Bolsa de horas de desarrollo | 2026-05-29 | 194.058.672 | pendiente en la ficha («en curso» en el contrato) | 141 días |
| Parametrización de líneas de crédito | 2026-08-13 | 194.058.672 | pendiente en la ficha («en curso» en el contrato) | 65 días |

Ninguno tiene acta de recibo, y el contrato condiciona cada pago a un acta firmada. Lo facturado no aparece en ningún documento. No puedo decir si se pagó algo sin acta.

### RAID al cierre
**Materializados:**
- La prueba de carga no alcanzó el umbral y se repite (informe 2026-10-07). Es incidencia, sin responsable.
- Pérdida de dos semanas por la rotación de un desarrollador clave (informe 2026-10-07). Es incidencia, sin responsable. Materializa en parte el riesgo de concentración del conocimiento.
- Reprogramación de la salida por el cierre contable (informe 2026-10-07). Es incidencia, sin responsable.

**No materializados:** ninguno se puede afirmar. Ningún riesgo tiene probabilidad, impacto ni fecha de revisión.

**Abiertos, con doliente:** ninguno tiene doliente. No están cerrados.
- Riesgo: concentración del conocimiento en una sola persona. Sin responsable.
- Riesgo: el proveedor podría no llegar con el equipo completo para la siguiente fase. Salió en la reunión del 2026-10-17 y nadie lo anotó. Sin responsable.
- Las 3 incidencias de arriba. Sin responsable.
- Compromisos de reunión abiertos: 23 de 26 siguen sin cumplirse. 5 están vencidos (cifra de `compute`): Elena Duarte (documento 9, vencido hace 22 días), Felipe Arango (prueba 10, 13 días), Rubén Cárdenas (prueba 18, 6 días), Gustavo Neira (matriz 14, 3 días) y Óscar Ramírez (fecha 23, 2 días). 3 no tienen fecha: Sandra Gil (diseño 5), Gustavo Neira (ambiente 12) y Laura Vélez (ajuste del presupuesto). 5 compromisos (Sandra Gil, Elena Duarte, Felipe Arango, Gustavo Neira y Rubén Cárdenas) figuran como «ya lo entregó» en una reunión, sin acta de recibo, y después no vuelven a aparecer en las tablas.
- Compromisos reprogramados: Felipe Arango, «Enviar el documento 1», 6 veces (original 2026-09-12, hoy 2026-11-24). Óscar Ramírez, «Cerrar la prueba 2», 5 veces (original 2026-09-26, hoy 2026-12-01). Elena Duarte, «Revisar el anexo 3», 4 veces (original 2026-09-28, hoy 2026-11-17).

Tienen doliente con nombre, pero ninguno cierra el proyecto. Los dolientes de los compromisos son personas de reunión, no hay un responsable de cierre de la incidencia o del riesgo.

### Lecciones
Solo entran las que se pueden anclar a un hecho documentado.

| Qué pasó | Cuándo | Efecto | Qué haríamos distinto |
|---|---|---|---|
| El cronograma v1 marca 4 hitos (los que no tienen acta) como cumplidos sin acta de recibo ni otra evidencia. La integración con el core sí tiene acta, firmada el 2026-10-07 sobre un hito de 2026-06-12 | Hitos de 2026-02-21 a 2026-10-01; acta del core 2026-10-07 | El cronograma dice 5 de 5 y el informe dice 48 %. Cualquier cierre queda sin base | Exigir acta de recibo o evidencia en el momento de marcar un hito como cumplido |
| Ninguno de los 3 entregables del contrato CT-410 tiene acta de recibo, con atrasos de 217, 141 y 65 días | Fechas de 2026-03-14, 2026-05-29, 2026-08-13 | El pago está condicionado a esas actas, así que el estado de lo pagado no es verificable | Revisar mes a mes el recibo del proveedor contra el contrato |
| La salida a producción se reprogramó (informe del 2026-10-07) sin línea base nueva | Informe del 2026-10-07 | La fecha vigente sigue siendo 2026-10-01 y el atraso real no se calcula | Registrar toda reprogramación como línea base nueva, sin borrar la anterior |
| El compromiso «Enviar el documento 1» se reprogramó 6 veces en 6 reuniones seguidas, de 2026-09-12 a 2026-11-24 | Reuniones del 2026-09-12 al 2026-10-17 | 73 días de desplazamiento sobre la fecha original (mi cálculo). Nadie lo escaló | Escalar un compromiso a la tercera reprogramación |
| El criterio de éxito «en producción y medido» no define qué se mide ni con qué umbral | Acta del 2025-12-18 | No se puede decidir si el proyecto cumplió | Pactar en el acta una medida y un umbral |
| El acta lista «Componente 1, 2 y 3» sin describirlos | Acta del 2025-12-18 | No se puede decidir si se entregó el alcance | Describir cada componente en el acta |

No incluyo lecciones sobre la causa de los atrasos, porque ningún documento la explica. Tampoco sobre la rotación del desarrollador más allá de lo que el informe dice.

### Sin dato
- Si el crédito está en producción, y desde cuándo.
- Qué se mide del crédito y con qué resultado.
- Qué se entregó de cada componente del alcance.
- Quién tiene la autoridad de aprobación (`identity.authority`) y en qué fase está el proyecto (`identity.phase`): no aparecen.
- Lo facturado al proveedor.
- El presupuesto ejecutado con respaldo contable: solo hay lo declarado en el informe del 2026-10-07.
- Si el «ajuste del presupuesto» (Laura Vélez, 2026-10-17) cambia el aprobado, el comprometido o la proyección.
- Si hubo recortes de alcance y con acuerdo de quién.

### Después
Mi respuesta sugerida, por no haber interfaz: **no mover la carpeta a `archivo/` ni congelar la ficha.** El proyecto sigue en el barrido diario, porque cerrarlo hoy ocultaría 5 señales abiertas y 3 hitos sin evidencia. Para cerrarlo hace falta, como mínimo, evidencia de la puesta en producción, la medición del crédito, actas de recibo del proveedor y un responsable para cada riesgo e incidencia abiertos.

---
Pie de rigor: las cifras salen de `compute` del 2026-10-17, salvo los dos cálculos marcados como míos (117 y 73 días). Ningún dato de estado está respaldado por evidencia (`sources.evidence` = 0 en `compute`). El dinero y el avance son declaraciones del gerente. El resultado es un borrador de trabajo; la verificación es suya.
