# Corrida del 2026-10-17 · product-business-case

PRD-306 · 17 requerimientos · 30 s · 43 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 16 |
| `evidence_stale` | 11 |
| `requirement_without_acceptance` | 7 |
| `requirement_accepted_without_evidence` | 5 |
| `requirement_without_owner` | 2 |
| `requirement_undecided` | 1 |
| `assumption_unverified` | 1 |

Caso de negocio armado: 1 cifra declarada (196.775) frente a 1 medida (175.099, brecha 11%, bajo el umbral). Sin costos, sin cifra de retorno, sin criterio de éxito y sin proyecto que construya. Sin fichas de otros productos publicadas: cruce no hecho.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

# Caso de negocio — Recaudos (PRD-306) · borrador del 2026-10-17
**Desde:** definición de producto y caso de negocio, ambos del 2025-09-28 · **Cifras con fuente:** 1 de 1 (la única cifra del caso es el volumen mensual; el «retorno esperado» no trae cifra)

(Términos v1.1 ya vigentes y aceptados por José Francisco Ñáñez el 2026-10-17; no se registraron de nuevo.)

## Qué problema resuelve, y para quién
«El segmento Asociados urbanos no tiene recaudos.» (definición de producto, 2025-09-28). Segmento: Asociados urbanos. La única voz de demanda es una entrevista del 2025-09-27: «Lo necesito y hoy no lo tengo.» (Cliente entrevistado, sin nombre ni segmento). La propuesta de la definición es solo «Propuesta principal»: no dice qué se construye.

## Qué se construye
16 requerimientos aceptados de 17 registrados (1 propuesto, REQ-4614). Fuente: acta del Comité de producto, 2026-10-15, tabla «Requerimientos revisados». Ninguno tiene proyecto que lo ejecute (0 de 16).

| Requerimiento | Estado | Evidencia de demanda |
|---|---|---|
| REQ-4601, 4602, 4603, 4604, 4606, 4608, 4609, 4610, 4611, 4612, 4615 | aceptado | Entrevista 2025-09-27, «Cliente entrevistado» (no nombra el requerimiento; es la más cercana; 12 meses de antigüedad) |
| REQ-2030, 4600, 4605, 4607, 4613 | aceptado | **Ninguna.** Nadie lo pidió en ningún documento |
| REQ-4614 | propuesto (124 días sin decidir) | Ninguna |

Los requerimientos que entran al caso son los decididos; REQ-4614 queda fuera hasta que el comité lo decida. El acta solo dice «Se mantiene el plan».

## Las cifras
| Cifra | Valor | Clase | De dónde sale | De cuándo |
|---|---|---|---|---|
| Volumen mensual esperado | 196.775 | Declarada | Caso de negocio, Gustavo Neira | 2025-09-28 |
| Volumen mensual actual | 175.099 | Medida | Bodega de datos, tablero de producto (`20-metricas/2026-10-15-tablero-metricas.md`) | corte 2026-10-15 |
| Retorno esperado en 24 meses | sin cifra | — | El caso lo menciona sin valor | — |

Aviso: la serie medida tiene **un solo punto** (2026-10-15). No hay tendencia que mostrar, y no se sabe qué medía el tablero un año atrás.

### Donde la cifra declarada y la medida no coinciden
| Métrica | Declarada | Medida | Las dos fuentes y fechas |
|---|---|---|---|
| volumen_mensual | 196.775 | 175.099 | Caso de negocio 2025-09-28 vs. tablero de métricas, corte 2026-10-15. Brecha de 21.676 (11%), bajo el umbral de 20% de la configuración. La cifra declarada no dice si es meta o línea de partida: sin eso no se sabe si 175.099 es un avance o un incumplimiento. |

## Los costos
| Concepto | Valor | De dónde sale |
|---|---|---|
| Costo de construir | **Sin fuente** | Ningún documento. Es el primer vacío |
| Costo del equipo | **Sin fuente** | Ningún documento |
| Contratos o cotizaciones | **Sin fuente** | Ningún documento |

Sin el costo de construir esto es una propuesta, no un caso de negocio que se pueda evaluar.

## Supuestos sobre los que se sostiene
| Supuesto | Qué pasa si resulta falso | Quién lo verificaría |
|---|---|---|
| «El reglamento vigente lo permite» (declarado, sin verificar hace 154 días; umbral 30) | Los 16 requerimientos aceptados quedan sin base para construirse | Sin asignar; la definición no nombra a nadie. Propuesta: Gustavo Neira nombra una persona |
| El volumen de 196.775 es alcanzable | El retorno, que no tiene cifra, se cae | El negocio: debe decir si es meta o línea de partida |
| La entrevista de 2025-09-27 representa a Asociados urbanos | 11 requerimientos quedan sin demanda sostenida | Quien hizo la ronda (Gustavo Neira); hoy es una sola cita, sin nombre |

## Vacíos
| Qué falta | Por qué importa | Quién lo produce |
|---|---|---|
| Costo de construir y de operar | Sin él no hay caso que evaluar | Gustavo Neira / finanzas, sin asignar |
| Cifra del retorno esperado a 24 meses | «Retorno esperado» sin número no se puede aprobar ni verificar | El negocio |
| Qué significa 196.775 (meta, línea de partida o proyección) y con qué método | Decide si la brecha del 11% es un problema | Gustavo Neira |
| Alternativas consideradas y qué pasa si no se hace | El comité no puede comparar | Gustavo Neira |
| Criterio de éxito y fecha de corte | No está dicho en la definición; sin esto el producto no se puede cerrar meses después | Comité de producto |
| Proyecto que construye (0 de 16 trazados; la definición dice «Ninguno declarado») | Un caso sin proyecto no tiene quién gaste el costo | Comité de producto; ver `/product-trace` |
| Doliente de REQ-4611 y REQ-4614 | Nadie responde por ellos | Gustavo Neira |
| Evidencia de demanda de 5 requerimientos aceptados | Se construiría algo que nadie pidió | Los dolientes: Beatriz Cuéllar (2030, 4607), Gustavo Neira (4600), Carlos Peña (4605), Elena Duarte (4613) |
| Criterio de aceptación de 7 aceptados | No se podrá decir cuándo están entregados | Cada doliente |

## Cómo se sabrá si funcionó
**No está declarado.** Hay una métrica con serie (volumen_mensual) pero ningún documento dice qué valor, a qué fecha, cuenta como éxito. Hasta que el comité lo fije, el volumen medido (175.099) contra el declarado (196.775) no se puede leer como cumplido ni como incumplido.

## Si hay otros productos publicados
Ningún producto tiene ficha publicada a la vista (no existe `estado/records`), así que no se pudo hacer el cruce de `/product-overlap`. Existen carpetas de documentos de otros 11 productos (PRD-299 a PRD-309), pero no se leyeron: sin ficha publicada no hay con qué cruzar. Queda pendiente si alguno afirma el mismo volumen mensual.

## Lo que este documento no hace
No proyecta ingresos, retorno ni ahorro, no calcula recuperación y no recomienda aprobar ni rechazar. Decidir es del Comité de producto.

## Después
Los tres supuestos de arriba pueden pasar al seguimiento con **assumption-tracking**. Si el caso se aprueba, `/product-charter`. Antes, `/product-trace` para los 16 aceptados sin proyecto.
