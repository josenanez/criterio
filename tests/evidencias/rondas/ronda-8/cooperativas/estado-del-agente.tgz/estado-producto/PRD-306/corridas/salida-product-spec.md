> **Borrador de trabajo, no una decisión.** Lo escribe el agente; lo cierra Gustavo Neira (gerente de producto) con la autoridad del Comité de producto. Este agente no aprueba.

(Términos v1.1 ya vigentes y aceptados por José Francisco Ñáñez el 2026-10-17; no se registraron de nuevo.)

# Especificación — Recaudos (PRD-306) · borrador del 2026-10-17

**Resultado en una línea:** del registro no se puede escribir el comportamiento de ningún requerimiento, porque ninguno dice qué problema resuelve. Prefiero entregar la estructura con los huecos a la vista que rellenarlos con lo razonable.

## Qué problema resuelve
La definición dice: «El segmento Asociados urbanos no tiene recaudos.» (`documentos/productos/PRD-306/00-definicion/2025-09-28-definicion-producto.md`, «El problema», 2025-09-28). Es una frase, no un problema: no dice qué recaudo, de qué, por qué medio ni qué pasa hoy.
La propuesta es el marcador «Propuesta principal»: no dice qué se propone. El criterio de éxito de la definición no está dicho en ningún documento.

## Alcance
### Entra
Nada que pueda afirmar. Los 16 requerimientos `aceptado` del registro (ver abajo) son los candidatos, pero para ninguno el registro tiene el «problema»: los títulos son «Requerimiento REQ-xxxx» y el acta del comité (`30-decisiones/2026-10-15-comite-producto.docx`) solo los nombra. Un alcance escrito sobre eso sería inventado.

### No entra
- **REQ-4614** (propuesto, sin doliente, 124 días sin decidir): no entra por estado; solo se especifica lo `aceptado` o `en_construccion`.
- Cualquier cosa que no esté en el registro. No agrego funcionalidad por inferencia del nombre «Recaudos».
- No se especifica diseño técnico, estimación, costo ni fechas.

## Comportamiento
**Sin secciones.** Una sección de comportamiento debe citar el requerimiento que cubre y su necesidad; los 16 tienen `need: not_found`. Los casos borde (conexión caída, pago duplicado, cliente que se va antes de la confirmación) tampoco están definidos en ningún documento. Ver Vacíos.

## Criterios de aceptación
Los 9 que existen dicen todos lo mismo: «se verifica en producción» (acta del comité, 2026-10-15). **No pasan la prueba de las dos personas**: no dice qué se mira ni qué resultado cuenta como bueno. Los otros 7 no tienen criterio.

| Criterio | Requerimiento | Cómo se verifica | ¿Se puede medir hoy? |
|---|---|---|---|
| «se verifica en producción» | REQ-4600, 4601, 4602, 4603, 4604, 4605, 4611, 4613, 4615 | No está dicho: sin umbral, sin medición, sin quién verifica | No verificable todavía: es una fecha de verificación, no un criterio |
| (ninguno) | REQ-2030, 4606, 4607, 4608, 4609, 4610, 4612 | — | — |

No propongo criterios con cifras (p. ej. un percentil o un tiempo): sin el problema de cada requerimiento sería poner un número mío donde nadie decidió. Lo único medido hoy en el producto es `volumen_mensual` (175.099, tablero 2026-10-15); no hay ninguna medición de tiempos, errores o conciliación.

## Supuestos sobre los que está escrita
| Supuesto | Verificado | Quién lo verificaría |
|---|---|---|
| «El reglamento vigente lo permite» (declarado 2026-05-16) | No, hace 154 días (umbral 30) | Gustavo Neira, con revisión jurídica |
| Que el volumen mensual es 196.775 (caso de negocio, 2025-09-28) | Medido 175.099 (2026-10-15): brecha 11%, bajo el umbral de 20% | Gustavo Neira |
| Que la entrevista del 2025-09-27 sustenta 11 requerimientos | No: la entrevista no nombra ninguno; es la «más cercana» | Gustavo Neira |

## Vacíos
| Qué falta decidir | Consecuencia de no decidirlo | Quién lo cierra |
|---|---|---|
| El problema de cada uno de los 16 requerimientos (y de la definición) | No se puede escribir comportamiento; cualquiera que construya decide por su cuenta | Cada doliente (ver «Sin doliente» y la lista por persona) con Gustavo Neira |
| Criterio de aceptación de los 7 sin criterio: REQ-2030 y 4607 (Beatriz Cuéllar), 4606 (Óscar Ramírez), 4608 (Elena Duarte), 4609 (Ricardo Salas), 4610 (Mauricio Pérez), 4612 (Gustavo Neira) | No hay forma de decir que está terminado | Cada doliente |
| Criterio verificable en los 9 con «se verifica en producción»: REQ-4600 (Gustavo Neira), 4601 y 4615 (Diana Molina), 4602 (Rubén Cárdenas), 4603 (Liliana Torres), 4604 (Mauricio Pérez), 4605 (Carlos Peña), 4613 (Elena Duarte), 4611 (sin doliente) | La discusión de si quedó bien ocurre después de construir | Cada doliente |
| Doliente de REQ-4611 (aceptado) y REQ-4614 (propuesto) | Nadie responde por el requerimiento | Gustavo Neira |
| Casos borde: sin conexión, pago duplicado, abandono antes de la confirmación, medio de pago | Comportamiento sin definir; lo decide quien construye | Gustavo Neira con los dolientes |
| Qué hace el producto («Propuesta principal») y criterio de éxito de la definición | Sin éxito definido no hay cierre posible | Gustavo Neira, Comité de producto |
| Retorno a 24 meses: el caso de negocio no tiene cifra | El caso de negocio no se sostiene | Gustavo Neira |
| Quién decidió cada aceptación: el acta no lo dice y lista un único asistente (Gustavo Neira) | Autoridad de las decisiones no demostrable | Comité de producto |
| Proyecto que lo construye: 0 de 16 trazados; la definición dice «Ninguno declarado» | Decidido que nadie construye (ver `/product-trace`) | Gustavo Neira |
| Lo que otro equipo tiene que hacer | No hay dependencias registradas en ningún documento; no sé si existen. No las invento | Gustavo Neira |
| REQ-4614: 124 días propuesto (umbral 60) | Se queda sin decidir | Comité de producto, próximo comité mensual |

### Obligaciones normativas (barrido, sin dictamen de cumplimiento)
El producto mueve dinero de asociados de una cooperativa, pero **ningún documento dice el país**, y no hay norma a la vista. No cito ninguna.

| Qué toca la definición | País | Obligación | Norma citada | Estado |
|---|---|---|---|---|
| Recaudar dinero de asociados (sistemas/medios de pago) | no dicho | Quién puede recaudar, con qué autorización y reportes | — | no tengo la norma a la vista |
| Asociados como consumidores financieros | no dicho | Información previa, reclamos, cobros | — | no tengo la norma a la vista |
| Datos personales del asociado y de sus pagos | no dicho | Autorización y finalidad | — | no tengo la norma a la vista |
| Retención y trazabilidad de las transacciones | no dicho | Plazos y quién puede pedirlo | — | no tengo la norma a la vista |
| El «reglamento vigente» del supuesto | no dicho | Si lo permite | — | sin resolver (no hay documento que lo verifique) |

Cierra: Gustavo Neira, con la revisión jurídica de la organización. Esto es insumo, no sustituto.

## Requerimientos aceptados que esta especificación no cubre
Ninguna sección los cubre a ninguno: la causa es la misma para todos (sin necesidad registrada), más lo propio de cada uno.

| REQ | Título | Por qué no |
|---|---|---|
| REQ-2030 | Requerimiento REQ-2030 | Sin problema, sin criterio, sin evidencia de demanda |
| REQ-4600 | Requerimiento REQ-4600 | Sin problema; criterio no verificable; sin evidencia de demanda |
| REQ-4601 | Requerimiento REQ-4601 | Sin problema; criterio no verificable |
| REQ-4602 | Requerimiento REQ-4602 | Sin problema; criterio no verificable |
| REQ-4603 | Requerimiento REQ-4603 | Sin problema; criterio no verificable |
| REQ-4604 | Requerimiento REQ-4604 | Sin problema; criterio no verificable |
| REQ-4605 | Requerimiento REQ-4605 | Sin problema; criterio no verificable; sin evidencia de demanda |
| REQ-4606 | Requerimiento REQ-4606 | Sin problema; sin criterio |
| REQ-4607 | Requerimiento REQ-4607 | Sin problema; sin criterio; sin evidencia de demanda |
| REQ-4608 | Requerimiento REQ-4608 | Sin problema; sin criterio |
| REQ-4609 | Requerimiento REQ-4609 | Sin problema; sin criterio |
| REQ-4610 | Requerimiento REQ-4610 | Sin problema; sin criterio |
| REQ-4611 | Requerimiento REQ-4611 | Sin problema; sin doliente; criterio no verificable |
| REQ-4612 | Requerimiento REQ-4612 | Sin problema; sin criterio |
| REQ-4613 | Requerimiento REQ-4613 | Sin problema; criterio no verificable; sin evidencia de demanda |
| REQ-4615 | Requerimiento REQ-4615 | Sin problema; criterio no verificable |

---
**Pie.** Sale del registro `estado-producto/PRD-306/requirements/` (17 requerimientos), al 2026-10-17, con el acta del comité del 2026-10-15. Cubre 0 de los 16 aceptados; 1 propuesto (REQ-4614) queda fuera. Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal

**Después:** no ofrezco `/product-charter`: los vacíos no están cerrados y la definición no tiene criterio de éxito. Antes, `/product-requirements` cuando los dolientes hayan escrito el problema de cada uno.
