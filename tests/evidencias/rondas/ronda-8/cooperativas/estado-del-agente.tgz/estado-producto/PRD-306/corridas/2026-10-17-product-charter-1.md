# Corrida del 2026-10-17 · product-charter

PRD-306 · 17 requerimientos · 29 s · 43 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 16 |
| `evidence_stale` | 11 |
| `requirement_without_acceptance` | 7 |
| `requirement_accepted_without_evidence` | 5 |
| `requirement_without_owner` | 2 |
| `requirement_undecided` | 1 |
| `assumption_unverified` | 1 |

Borrador de acta para REQ-4600 con vacíos marcados (problema, criterio verificable, evidencia, autoridad, patrocinador, propuesta); sin firma, no se creó la ficha. No leí los demás REQ para el 'no entra'.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## Acta de constitución — Recaudos (borrador) · borrador del 2026-10-17
**Producto:** PRD-306 · Recaudos · **Requerimientos:** REQ-4600

Términos vigentes: v1.1, aceptados por José Francisco Ñáñez el 2026-10-17; no hizo falta registrarlos de nuevo.

### Antes de redactar: lo que falta para que haya con qué
Revisé REQ-4600 contra las cuatro condiciones. Sesión sin interfaz: tomé la respuesta sugerida, que es **seguir marcando cada falta como vacío del acta, sin rellenarla**.

| Condición | Estado |
|---|---|
| Aceptado, no propuesto | Cumple: «aceptado» (acta de comité 2026-10-15, fila REQ-4600). El acta **no dice quién decidió**. |
| Criterios de aceptación verificables | **No cumple.** El único es «se verifica en producción»: no dice qué se mide, ni con qué umbral, ni quién lo verifica. |
| Evidencia de demanda con cita | **No cumple.** `evidence` está vacío en REQ-4600 y el acta no dice el problema. La única evidencia del producto es una entrevista del 2025-09-27, de 385 días (más de 12 meses). |
| Autoridad declarada en la definición | **No cumple.** «Comité de producto» es la propuesta por defecto de la instalación; el acta del 2026-10-15 lista como único asistente a Gustavo Neira. |

### Qué problema resuelve
De la definición: «El segmento Asociados urbanos no tiene recaudos.» (`00-definicion/2025-09-28-definicion-producto.md`, El problema).
**Del requerimiento:** el problema no está dicho. REQ-4600 no tiene necesidad registrada (el acta solo lo nombra). No lo infiero de la definición.

### Criterio de éxito
- Del requerimiento: «se verifica en producción» (acta 2026-10-15, fila REQ-4600). **No es verificable tal cual**: sin métrica, umbral ni fecha, el cierre no se podría juzgar.
- De la definición: el criterio de éxito del producto **no existe en ningún documento**.

### Alcance
#### Entra
| REQ | Título | Evidencia que lo sostiene |
|---|---|---|
| REQ-4600 | «Requerimiento REQ-4600» (el acta no da otro título) | Ninguna sobre el requerimiento. Del producto: entrevista 2025-09-27, «Lo necesito y hoy no lo tengo.» — una voz, sin segmento nombrado, sin pago, envejecida |

#### No entra
| REQ | Título | Por qué no |
|---|---|---|
| REQ-2030, REQ-4601 a REQ-4615 | No los leí para esta acta | Esta acta cubre solo REQ-4600, el único pedido. Decir por qué no entra cada uno requiere su propio registro y la decisión de quien pidió el alcance; **no inventé una razón por cada uno**. |

### Gobierno
- **Patrocinador:** no consta en ningún documento.
- **Gerente propuesto:** Gustavo Neira, gerente del producto y dueño de REQ-4600 (definición y acta 2026-10-15). Es una propuesta: asignar al gerente del proyecto no es de este comando.
- **Comité:** «Comité de producto» — propuesta por defecto de la instalación, no declarada por ningún documento.
- **Autoridad del gerente:** no está dicha.
- **Quién decidió aceptar REQ-4600:** el acta no lo dice (fecha de la tabla: 2026-06-12).

### Supuestos que se llevan al proyecto
| Supuesto | Verificado | Se convierte en riesgo de |
|---|---|---|
| «El reglamento vigente lo permite» (declarado 2026-05-16) | No: 154 días sin verificar, umbral 30 | Riesgo del proyecto, **sin doliente asignado**. Hay que nombrar cuál es el reglamento y qué artículo lo permite; tal como está escrito es casi imposible de desmentir. |

Nota: el supuesto está fechado 2026-05-16 dentro de un documento fechado 2025-09-28; su autor debería aclarar cuál fecha es la correcta.

### Restricciones normativas sin resolver
| Qué toca | Obligación | Norma | Estado |
|---|---|---|---|
| Recaudo de fondos de asociados | No determinada | No identificada | No tengo la norma a la vista. No consta el país. No digo si aplica ni si cumple; va a revisión jurídica. |

### Cifras del caso de negocio que el proyecto hereda
- Volumen mensual: declarado 196.775 (caso de negocio, 2025-09-28) vs. medido 175.099 (tablero, corte 2026-10-15): −11,0 %, bajo el umbral del 20 %. La serie medida tiene un solo punto.
- Retorno esperado «en 24 meses»: sin cifra ni serie.

### Vacíos de este acta
| Qué falta | Consecuencia de firmar sin eso | Quién lo cierra |
|---|---|---|
| Problema del requerimiento | El proyecto arranca sin saber qué resuelve REQ-4600 | Gustavo Neira, dueño del requerimiento |
| Criterio de aceptación verificable | El cierre no se puede juzgar meses después | Gustavo Neira |
| Evidencia de demanda reciente y con segmento | Se construye sobre una sola voz de hace 385 días | Gustavo Neira |
| Qué se propone (la definición dice solo «Propuesta principal») | No hay alcance real que entregar | Gustavo Neira |
| Autoridad declarada | El gerente del proyecto no sabrá qué puede decidir: escalará todo o nada | Quien tenga la autoridad sobre el producto |
| Patrocinador | Nadie responde por el presupuesto ni por el cambio de alcance | Por definir |
| Quién decidió aceptar REQ-4600 | La decisión no es trazable | Autor del acta del 2026-10-15 |
| Presupuesto e hitos | No hay ninguno declarado en los documentos; no los inventé | Quien patrocine |
| Verificación del supuesto del reglamento y país | Riesgo legal abierto desde hace 154 días | Revisión jurídica, con doliente y fecha |

---
**Esto es un borrador.** Lo firma quien tenga la autoridad sobre el producto, hoy sin declarar. **No hay acta firmada, así que no creé la ficha del proyecto** (`portafolio.py init` no se corrió) y `declared` queda sin escribir.

### Después
Con tantos vacíos, lo que corresponde antes de firmar es cerrarlos, empezando por criterio de éxito, autoridad y problema de REQ-4600. Una vez firmada el acta, se crea la ficha, y el gerente del proyecto instala `criterio-project` y corre `/pm-setup`; cuando publique con `/pm-publish`, `/product-trace` podrá confirmar la traza y Alba sabrá si su producto se está construyendo sin tener que preguntar.
