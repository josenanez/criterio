# Corrida del 2026-10-17 · product-definition

PRD-306 · 17 requerimientos · 31 s · 43 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 16 |
| `evidence_stale` | 11 |
| `requirement_without_acceptance` | 7 |
| `requirement_accepted_without_evidence` | 5 |
| `requirement_without_owner` | 2 |
| `requirement_undecided` | 1 |
| `assumption_unverified` | 1 |

La evidencia no contradice la definición, pero la sostiene poco: una entrevista de hace 385 días, un supuesto sin verificar hace 154 y sin criterio de éxito

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## Definición — Recaudos (PRD-306) · contrastada al 2026-10-17
**Documento:** `00-definicion/2025-09-28-definicion-producto.md` y `00-definicion/2025-09-28-caso-de-negocio.md` · **del** 2025-09-28 · 6 afirmaciones (el problema, el segmento, la propuesta, la cifra de volumen, el retorno a 24 meses y el supuesto del reglamento)

Términos vigentes: v1.1, aceptados por José Francisco Ñáñez el 2026-10-17; no hizo falta registrarlos de nuevo.

### Lo que la evidencia contradice
Nada. Ninguna fuente dice lo contrario de lo que afirma la definición. La única diferencia numérica está en la sección siguiente y queda bajo el umbral.

### El negocio y los datos
Ninguna métrica pasa del umbral (20 %). Lo que hay es imprecisión, no contradicción:

| Métrica | Declarado | Medido | Diferencia | Las dos fuentes y fechas |
|---|---|---|---|---|
| volumen_mensual | 196.775 | 175.099 | −11,0 % (el medido está por debajo) | Caso de negocio, 2025-09-28 · Tablero de métricas (bodega de datos), corte 2026-10-15 |

Límite de la lectura: la serie medida tiene un solo punto (2026-10-15). No se puede decir si el volumen baja, sube o está estable; solo que hoy está 11 % por debajo de lo declarado.

### Afirmaciones numéricas que nadie mide
| Afirma | De qué documento | No hay serie |
|---|---|---|
| Retorno esperado en 24 meses | Caso de negocio, 2025-09-28 | El documento no trae cifra ni serie; no hay nada que medir ni contra qué contrastar |

### No está dicho en ninguna parte
- Qué se propone: la sección «La propuesta» dice solo «Propuesta principal», un marcador.
- El criterio de éxito: no existe en ningún documento.
- Cuánto es el retorno: el caso de negocio nombra el plazo (24 meses) pero no la cifra.
- Qué cuenta el «volumen_mensual» (recaudos, transacciones o monto) y cómo se calculó el 196.775: la fuente es el propio caso de negocio.
- Cuántos Asociados urbanos hay y cuántos de ellos no tienen recaudos: solo se afirma que «no tiene recaudos».
- Que quien se entrevistó es del segmento Asociados urbanos: la entrevista dice «Cliente entrevistado» y no nombra segmento.
- Cuánto pagaría alguien o si alguien ya pagó por esto: no hay ninguna evidencia de pago.
- Qué proyecto lo construye: «Ninguno declarado».
- Quién decide: ningún documento lo dice. «Comité de producto» es la propuesta por defecto de la instalación, y el acta del 2026-10-15 lista como único asistente a Gustavo Neira.
- Qué plan «se mantiene»: la única decisión del acta del 2026-10-15 es «Se mantiene el plan», y no hay un plan al que remita.

### Sostenida por un supuesto
| Supuesto | Días sin verificar | Qué haría falta para verificarlo |
|---|---|---|
| El reglamento vigente lo permite | 154 (declarado el 2026-05-16; umbral 30) | Nombrar cuál es el reglamento y qué artículo permite el recaudo, y llevar esa cita a revisión jurídica con un doliente y una fecha. Tal como está escrito («el reglamento vigente») es casi imposible de desmentir, y por eso nadie lo ha verificado. |

Nota: el supuesto está fechado 2026-05-16 dentro de un documento fechado 2025-09-28. O el documento se editó después, o una de las dos fechas está mal; conviene que su autor lo aclare.

### Sostenida por evidencia
| Afirmación | Sostenida por | De cuándo | Qué tan fuerte |
|---|---|---|---|
| El segmento no tiene recaudos | Entrevista, «Cliente entrevistado»: «Lo necesito y hoy no lo tengo.» | 2025-09-27 | Débil: una sola voz, dicha y no pagada, sin segmento nombrado |

### Evidencia que ya envejeció
| Afirmación | Lo más nuevo que la sostiene | Hace |
|---|---|---|
| El segmento no tiene recaudos | Entrevista del 2025-09-27 | 385 días (más de 12 meses, el umbral) |

Es la única evidencia de demanda de todo el producto: todo lo que la apoya cumplió ya el umbral de 12 meses.

### Lo normativo que toca
| Qué toca | País | Obligación | Norma | Estado |
|---|---|---|---|---|
| Recaudo de fondos de asociados; la propia definición supone un «reglamento vigente» | No consta en la configuración ni en los documentos | No determinada | No identificada | No tengo la norma a la vista |

No se dice si cumple ni si aplica. Falta el país y el reglamento que el supuesto da por conocido. Esto va a revisión jurídica, no la reemplaza.

### Lo que falta para cerrar la definición
- **Criterio de éxito: no declarado.** Sin él el producto no se puede cerrar, porque el cierre se juzga contra él.
- **Quién decide:** solo hay una propuesta por defecto, no una autoridad declarada.
- **Qué se propone:** el texto de la propuesta es un marcador.
- El problema («El segmento Asociados urbanos no tiene recaudos») y para quién (Asociados urbanos) sí están dichos, aunque con la evidencia envejecida de arriba.

### Después
El supuesto del reglamento lleva 154 días sin verificarse: se puede convertir en riesgo con doliente (raid-taxonomy). La definición no está cerrada (falta criterio de éxito y autoridad), así que no corresponde ofrecer `/product-charter` todavía.
