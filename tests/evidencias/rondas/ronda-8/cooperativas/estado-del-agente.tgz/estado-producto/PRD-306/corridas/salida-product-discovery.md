## Descubrimiento — Recaudos (PRD-306) · 1 pieza de descubrimiento al 2026-10-17

Se leyeron las 5 piezas de la carpeta (la entrevista, la definición, el caso de negocio, el tablero y el acta del comité). Solo una es material de descubrimiento: `10-descubrimiento/2025-09-27-entrevistas.md`, una entrevista de Gustavo Neira a un cliente.

### Temas
Ninguno. Con una sola voz y una sola frase no hay agrupación que hacer; lo único que hay está en «Dicho una sola vez».

### Dicho y nunca convertido en nada
Ninguno. El único tema, «Necesidad principal», ya está en el registro como evidencia de 11 de los 17 requerimientos.

### Dicho una sola vez
| Qué | Quién | Cuándo |
|---|---|---|
| *«Lo necesito y hoy no lo tengo.»* (tema rotulado «Necesidad principal») | Cliente entrevistado (sin nombre ni segmento) | 2025-09-27 |

No se promueve ni se descarta. La frase no dice qué necesita, y la entrevista no nombra ningún requerimiento.

### Afirmaciones numéricas de los entrevistados
Ninguna. La entrevista no trae cifras.

### De fuentes públicas
No entró ninguna.

### Evidencia nueva que contradice el registro
Ninguna.

### Lo que el registro ya hace con esta entrevista
- Esta misma frase figura como evidencia de 11 requerimientos (REQ-4601, 4602, 4603, 4604, 4606, 4608, 4609, 4610, 4611, 4612, 4615). Cada uno la marca como «la más cercana», porque la entrevista no nombra ninguno.
- Tiene 12 meses (2025-09-27), y por eso `compute` marca `evidence_stale` en esos 11.
- No creo ningún requerimiento y no cambio el registro.

*1 pieza de descubrimiento leída, ningún tema que el registro no tenga ya.*
