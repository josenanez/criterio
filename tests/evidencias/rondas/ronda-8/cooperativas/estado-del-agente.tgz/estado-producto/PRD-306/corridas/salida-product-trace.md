## Trazabilidad — Recaudos (PRD-306) · al 2026-10-17
16 decididos · 0 con proyecto · 0 confirmados contra la ficha · 0 entregados
(Un requerimiento más, REQ-4614, está «propuesto» y no cuenta como decidido.)

### Decidido y nadie lo está construyendo
Los 16 requerimientos aceptados tienen «Proyecto que lo ejecuta: —» en el registro (ejemplo: REQ-4600, `30-decisiones/2026-10-15-comite-producto.docx`, tabla «Requerimientos revisados») y la cobertura por proyecto es 0 %. Los más antiguos van primero:

| REQ | Decidido el | Días | Por quién (doliente) |
|---|---|---|---|
| REQ-4603 | 2026-03-17 | 214 | Liliana Torres |
| REQ-4607 | 2026-03-31 | 200 | Beatriz Cuéllar |
| REQ-4609 | 2026-04-06 | 194 | Ricardo Salas |
| REQ-4613 | 2026-05-21 | 149 | Elena Duarte |
| REQ-4608 | 2026-05-28 | 142 | Elena Duarte |
| REQ-4605 | 2026-06-09 | 130 | Carlos Peña |
| REQ-4606 | 2026-06-10 | 129 | Óscar Ramírez |
| REQ-4600 | 2026-06-12 | 127 | Gustavo Neira |
| REQ-4602 | 2026-06-15 | 124 | Rubén Cárdenas |
| REQ-4611 | 2026-06-25 | 114 | sin doliente |
| REQ-4612 | 2026-07-04 | 105 | Gustavo Neira |
| REQ-4615 | 2026-07-25 | 84 | Diana Molina |
| REQ-4610 | 2026-08-03 | 75 | Mauricio Pérez |
| REQ-4604 | 2026-08-06 | 72 | Mauricio Pérez |
| REQ-4601 | 2026-08-13 | 65 | Diana Molina |
| REQ-2030 | 2026-09-23 | 24 | Beatriz Cuéllar |

Nota: el acta no dice quién decidió; la columna «Por quién» es el doliente del registro, no quien decidió. «Decidido el» es la fecha de la tabla del acta.

### La traza no se confirma
Ninguna: no hay trazas que confirmar porque ningún requerimiento nombra un proyecto.

### Lo que un proyecto construye y el registro no tiene
| Proyecto | Su ficha dice que ejecuta este producto | Ningún REQ lo nombra |
|---|---|---|
| PRY-211 Cobranza digital | Producto: «recaudos» (acta de constitución 2026-01-30, `PRY-211-cobranza-digital/00-gobierno/2026-01-30-acta-constitucion.md`) | Cierto: ningún REQ de PRD-306 cita PRY-211 |

Cautela: la ficha dice «recaudos» por nombre, no por código PRD-306. Coincide con el nombre del producto, pero hay que confirmar que es el mismo. Ninguna otra de las 13 fichas nombra PRD-306 ni «Recaudos» (PRY-199, por ejemplo, dice PRD-299; PRY-201, «ahorro a la vista»).

### La cadena completa
REQ-xxxx → decisión del comité del 15-oct (u otra fecha de la tabla de arriba) → **sin proyecto** → sin entregables. La cadena se rompe en el eslabón «proyecto» en los 16 requerimientos.

### Sin fichas a la vista
Se revisaron 13 fichas (PRY-199 a PRY-211). No hay fichas faltantes que impidan confirmar, porque no hay ninguna traza declarada que confirmar.

### Otras señales del cálculo (contexto, no son de esta cadena)
`requirement_untraced` 16 · `evidence_stale` 11 · `requirement_without_acceptance` 7 · `requirement_accepted_without_evidence` 5 · `requirement_without_owner` 2 · `requirement_undecided` 1 (REQ-4614, 124 días) · `assumption_unverified` 1.

### Después
Ya hay requerimientos decididos sin proyecto: `/criterio-product:product-charter` para el que esté listo para serlo. Sobre PRY-211, la salida es una conversación con su gerente de proyecto, no un comando.
