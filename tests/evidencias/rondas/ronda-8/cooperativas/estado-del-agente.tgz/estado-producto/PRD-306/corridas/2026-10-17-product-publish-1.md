# Corrida del 2026-10-17 · product-publish

PRD-306 · 17 requerimientos · 15 s · 43 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 16 |
| `evidence_stale` | 11 |
| `requirement_without_acceptance` | 7 |
| `requirement_accepted_without_evidence` | 5 |
| `requirement_without_owner` | 2 |
| `requirement_undecided` | 1 |
| `assumption_unverified` | 1 |

No se publicó: no hay carpeta de productos publicados configurada ni existente

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

**No publiqué la ficha de PRD-306 (Recaudos), con corte al 2026-10-17.**

Motivo: no hay carpeta de productos publicados configurada (`config.json` no la tiene) y tampoco existe ninguna `publicados/` en el espacio. Sin un sitio común acordado esto no sirve, y acordarlo es una conversación de la organización, no un comando. No creé ninguna carpeta ni escribí ningún archivo de ficha.

**Lo que habría llevado (calculado, listo para publicar cuando haya sitio):**
- **Requerimientos:** 17 (16 aceptados, 1 propuesto) · **Proyectos:** 0 (ningún requerimiento tiene proyecto asignado) · **Métricas afirmadas:** 2
- **Segmento declarado:** Asociados urbanos
- **Métricas:**
  - `volumen_mensual`: 196775.0, de `documentos/productos/PRD-306/00-definicion/2025-09-28-caso-de-negocio.md` (Cifras que sostienen el caso), 2025-09-28
  - `retorno_24_meses`: sin cifra, del mismo documento («Retorno esperado en 24 meses.»)

**Para que lo sepas antes de publicar:** ningún requerimiento está trazado a un proyecto, así que la ficha no permitiría cruzar por proyecto compartido; solo por métrica y segmento.

**Siguiente paso:** acordar la carpeta común de publicados y configurarla; después se vuelve a correr el comando.
