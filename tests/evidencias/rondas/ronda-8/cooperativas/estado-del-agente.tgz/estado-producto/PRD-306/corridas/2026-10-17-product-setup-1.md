# Corrida del 2026-10-17 · product-setup

PRD-306 · 17 requerimientos · 43 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 16 |
| `evidence_stale` | 11 |
| `requirement_without_acceptance` | 7 |
| `requirement_accepted_without_evidence` | 5 |
| `requirement_without_owner` | 2 |
| `requirement_undecided` | 1 |
| `assumption_unverified` | 1 |

> El tiempo no se midió: faltó `corrida-inicio` al arrancar.

0 preguntas hechas (4 resueltas con la respuesta sugerida, sesión sin interfaz); minutos hasta el primer resultado no medidos (sin corrida-inicio, por instrucción del comando); 5 documentos, 17 requerimientos levantados, 0 de 16 aceptados con proyecto, 11 con evidencia vencida (misma entrevista), 5 sin evidencia; sellar no corrió: exige corrida-inicio y el comando lo prohíbe

Primera corrida: no hay una anterior contra la cual comparar.

## Lo que produjo

Soy Alba. Trabajo antes de que haya proyecto: miro qué sostiene tu definición y qué se sostiene solo.

Sesión sin interfaz: tomé la respuesta sugerida en cada pregunta.
- Producto: Recaudos (PRD-306), gerente Gustavo Neira, tomado del caso de negocio y la definición.
- Quién decide: propuse «Comité de producto». Ningún documento lo dice (ver abajo).
- Estado: `estado-producto/PRD-306`, hermana de `documentos/`, no la carpeta `estado/` del portafolio.
- Términos 1.1: mostrados tal cual y aceptados por José Francisco Ñáñez el 2026-10-17, según el argumento de la sesión.

## Listo — Recaudos (PRD-306)

**Lo que miré:** 5 documentos · 1 de descubrimiento (una ronda de entrevistas con una sola cita) · la definición del 2025-09-28 · lo más reciente es del 2026-10-15 · todos legibles (4 .md y 1 .docx).
**Términos:** aceptados para la versión 1.1 (familia 0.3.13) · comprobante en `.criterio/terminos/aceptacion-criterio-product-0.3.13-2026-10-17.md` y `.pdf` · SHA-256 d85e8bd2335ac89a… (el .md; el .pdf es ffdddcc09fd7c905…)

### Lo que tu definición afirma, y qué lo sostiene
| Afirmación | Sostenida por | De cuándo |
|---|---|---|
| «El segmento Asociados urbanos no tiene recaudos» | Débilmente: una entrevista a un «Cliente entrevistado» sin nombre: «Lo necesito y hoy no lo tengo». No dice recaudos ni dice que sea de ese segmento | 2025-09-27 (12 meses; pasó el umbral de 12) |
| `volumen_mensual` = 196.775 | Solo el caso de negocio, sin método ni fuente de datos. El tablero mide 175.099: brecha de 11.0%, bajo el umbral de 20%, así que no es contradicción. Es un solo punto, no una serie | Declarado 2025-09-28 · medido 2026-10-15 |
| Retorno esperado en 24 meses | Nada: la frase no trae cifra ni base | 2025-09-28 |

### Lo que no está dicho en ninguna parte
- **El criterio de éxito.** Ningún documento dice cuándo Recaudos habrá funcionado.
- **La propuesta.** La definición dice «Propuesta principal» y nada más: es un marcador.
- **Cuánto retorno, sobre qué base.** «Retorno esperado en 24 meses» no tiene cifra.
- **Quién decide qué se construye.** El acta del comité del 2026-10-15 solo lista como asistente a Gustavo Neira y no dice quién decidió cada aceptación. «Comité de producto» es mi propuesta, no un dato.
- **Qué proyecto construye esto.** La definición dice «Ninguno declarado» y el acta no trae proyecto en ninguna de las 17 filas. El acta dice «Se mantiene el plan», y no hay plan en la carpeta.
- **El problema de cada requerimiento.** El acta solo trae un número y un título genérico («Requerimiento REQ-46xx»). Ningún documento dice qué necesita cada uno.

### Supuestos sobre los que está escrita
- «El reglamento vigente lo permite»: declarado el 2026-05-16, sin verificar, **154 días**. Está fechado ocho meses después de la definición (2025-09-28), así que alguien la editó sin cambiar la fecha.
- No declara ningún otro. Todo lo demás se afirma sin decir que es un supuesto.

### Lo que dice el registro de requerimientos (17 levantados del acta del 2026-10-15)
- 16 aceptados y 1 propuesto (REQ-4614).
- **0 de 16 aceptados tienen proyecto que los ejecute (0.0%).** Se decidió construir 16 cosas y ninguna dice quién las construye.
- 11 de 16 aceptados tienen evidencia (68.8%), y es **la misma entrevista de 2025-09-27 en las 11**. No nombra ninguno de esos requerimientos. Las 11 están vencidas por antigüedad (12 meses).
- 5 aceptados sin ninguna evidencia: REQ-2030, REQ-4600, REQ-4605, REQ-4607 y REQ-4613.
- 7 aceptados sin criterio de aceptación: REQ-2030, REQ-4606, REQ-4607, REQ-4608, REQ-4609, REQ-4610 y REQ-4612. En los otros 9 el criterio es «se verifica en producción». Es el mismo texto en todos y no dice qué se mide, así que no sirve para decidir si quedó hecho.
- 2 sin doliente: REQ-4611 (aceptado, «sin asignar») y REQ-4614.
- REQ-4614 lleva 124 días propuesto sin que nadie lo decida.
- REQ-2030 (aceptado el 2026-09-23) es de otra serie de numeración y no tiene criterio, evidencia ni proyecto.

### Qué le falta a tu carpeta
- Las transcripciones de las entrevistas. Hoy hay una sola cita, de una persona sin nombre; así no se ve cuántos clientes lo piden ni cuáles.
- La serie de `volumen_mensual` con su fuente. Hay un solo punto, el del 2026-10-15; con una serie se vería si el caso de negocio se cumple.
- Las decisiones del comité con quién decidió y por qué. El acta registra aceptados sin decisor y no registra ningún descartado, así que un requerimiento descartado se ve igual que uno que nadie miró.
- El criterio de éxito y la propuesta, escritos.

### Lo que no pude hacer
- **No sellé la lectura.** `producto.py sellar` exige una corrida abierta con `corrida-inicio`, y este comando dice que aquí no va `corrida-inicio`. Respeté la prohibición. La próxima corrida releerá los 5 documentos (barato, pero no es el ahorro previsto). Hay que corregir una de las dos instrucciones.
- No miré `documentos/proyectos/` para buscar qué proyecto podría estar ejecutando Recaudos: eso es de `/product-trace`.

### Después
`/product-discovery` sobre las entrevistas: es donde los temas se vuelven requerimientos con la cita de quién lo pidió. Con una sola entrevista de hace 12 meses, lo más útil es conseguir entrevistas nuevas.
