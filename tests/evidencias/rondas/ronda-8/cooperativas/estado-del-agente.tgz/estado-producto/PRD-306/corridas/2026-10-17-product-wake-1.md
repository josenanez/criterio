# Corrida del 2026-10-17 · product-wake

PRD-306 · 17 requerimientos · 28 s · 43 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 16 |
| `evidence_stale` | 11 |
| `requirement_without_acceptance` | 7 |
| `requirement_accepted_without_evidence` | 5 |
| `requirement_without_owner` | 2 |
| `requirement_undecided` | 1 |
| `assumption_unverified` | 1 |

Primera revisión, línea base sin corte previo: 7 señales tipos, 16 REQ sin proyecto, REQ-4614 sin decidir 124 días, supuesto del reglamento 154 días. No leí el acta docx del 2026-10-15; trazas no confirmables porque ninguna ficha nombra el producto.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## Recaudos (PRD-306) · 2026-10-17

**Primera revisión del registro:** no hay corte anterior, así que lo que sigue es la línea base, no novedad. Hoy tocaba `review`; no tocaba `crossed` ni `report`. Términos vigentes (aceptados por José Francisco Ñáñez, 2026-10-17).

### Lo que necesita decisión
| Qué | REQ | Cuánto lleva | Qué se necesita | Quién |
|---|---|---|---|---|
| `requirement_undecided` | REQ-4614 | 124 días propuesto (desde 2026-06-15; umbral 60) | Quién tiene la facultad de decidirlo. No tiene doliente. | Comité de producto (autoridad); sin doliente |
| `assumption_unverified` | «El reglamento vigente lo permite» | 154 días (umbral 30) | Verificar contra el reglamento con quien lo interprete (jurídico/cumplimiento). Ya pasó el punto en que conviene tratarlo como riesgo registrado. | Sin dueño en el registro |

### Aceptados sin sustento
- 16 de 17 requerimientos están aceptados; **ninguno tiene proyecto** (trazados: 0 %). Nadie los está construyendo.
- Sin evidencia de demanda (5): REQ-2030, REQ-4600, REQ-4605, REQ-4607, REQ-4613.
- Sin criterio de aceptación (7): REQ-2030, 4606, 4607, 4608, 4609, 4610, 4612.
- Sin doliente (2): REQ-4611, REQ-4614.
- Evidencia vencida (11, 12 meses): REQ-4601 a 4604, 4606, 4608 a 4612, 4615. Todas descansan en la misma entrevista del 2025-09-27, que además no nombra ninguno de esos requerimientos («es la más cercana»). La afirmación de demanda de la definición queda sin sustento vigente.

### Negocio contra datos
- `volumen_mensual`: el caso de negocio declara 196.775; el tablero del 2026-10-15 mide 175.099 (brecha 11 %, bajo el umbral de 20 %: no es hallazgo, se anota).
- `retorno_24_meses`: sin cifra en el caso de negocio; no hay nada que contrastar.
- El criterio de éxito de la definición no está dicho en ninguna parte (`success` desconocido).

### Las trazas
Ninguna ficha de `estado/records` (13 leídas por búsqueda de texto) nombra PRD-306 ni ningún REQ. No hay traza declarada que confirmar ni que se haya roto. Eso no prueba que nadie trabaje en esto, solo que ninguna ficha lo dice.

### Del descubrimiento
Sin documentos nuevos desde las corridas de hoy. Pendiente de lectura en esta revisión: el acta `2026-10-15-comite-producto.docx` (formato docx, no la abrí en este barrido).

**Vuelvo el 2026-11-16.**
