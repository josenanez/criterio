# Corrida del 2026-10-17 · product-requirements

PRD-306 · 17 requerimientos · 21 s · 43 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 16 |
| `evidence_stale` | 11 |
| `requirement_without_acceptance` | 7 |
| `requirement_accepted_without_evidence` | 5 |
| `requirement_without_owner` | 2 |
| `requirement_undecided` | 1 |
| `assumption_unverified` | 1 |

5 aceptados sin evidencia, 7 sin criterio de aceptación, 16 sin proyecto, 11 con evidencia vieja, 2 sin doliente, 1 propuesto sin decidir hace 124 días

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## Registro — Recaudos (PRD-306) · al 2026-10-17
17 requerimientos · 16 decididos · 68.8% con evidencia · 0% con proyecto que lo ejecuta

(Términos v1.1 ya vigentes y aceptados por José Francisco Ñáñez el 2026-10-17; no se registraron de nuevo.)

### Se va a construir y nadie lo pidió
Aceptados sin una sola cita de quien lo pidió (5 de 16 decididos).
| REQ | Título | Estado | Doliente |
|---|---|---|---|
| REQ-2030 | Requerimiento REQ-2030 | aceptado (2026-09-23) | Beatriz Cuéllar |
| REQ-4600 | Requerimiento REQ-4600 | aceptado (2026-06-12) | Gustavo Neira |
| REQ-4605 | Requerimiento REQ-4605 | aceptado (2026-06-09) | Carlos Peña |
| REQ-4607 | Requerimiento REQ-4607 | aceptado (2026-03-31) | Beatriz Cuéllar |
| REQ-4613 | Requerimiento REQ-4613 | aceptado (2026-05-21) | Elena Duarte |

### Decidido y nadie lo está construyendo
Los 16 aceptados carecen de proyecto que los ejecute (trazados: 0 de 16).
| REQ | Título | Decidido el |
|---|---|---|
| REQ-2030 | Requerimiento REQ-2030 | 2026-09-23 |
| REQ-4600 | Requerimiento REQ-4600 | 2026-06-12 |
| REQ-4601 | Requerimiento REQ-4601 | 2026-08-13 |
| REQ-4602 | Requerimiento REQ-4602 | 2026-06-15 |
| REQ-4603 | Requerimiento REQ-4603 | 2026-03-17 |
| REQ-4604 | Requerimiento REQ-4604 | 2026-08-06 |
| REQ-4605 | Requerimiento REQ-4605 | 2026-06-09 |
| REQ-4606 | Requerimiento REQ-4606 | 2026-06-10 |
| REQ-4607 | Requerimiento REQ-4607 | 2026-03-31 |
| REQ-4608 | Requerimiento REQ-4608 | 2026-05-28 |
| REQ-4609 | Requerimiento REQ-4609 | 2026-04-06 |
| REQ-4610 | Requerimiento REQ-4610 | 2026-08-03 |
| REQ-4611 | Requerimiento REQ-4611 | 2026-06-25 |
| REQ-4612 | Requerimiento REQ-4612 | 2026-07-04 |
| REQ-4613 | Requerimiento REQ-4613 | 2026-05-21 |
| REQ-4615 | Requerimiento REQ-4615 | 2026-07-25 |

Cierra el vacío: el doliente de cada uno con el Comité de producto (autoridad: Comité de producto, gerente: Gustavo Neira). Ofrezco `/product-trace`.

### Sin doliente, o con un área en vez de una persona
| REQ | Título | Dice |
|---|---|---|
| REQ-4611 | Requerimiento REQ-4611 | aceptado, sin doliente. Lo cierra Gustavo Neira nombrando una persona. |
| REQ-4614 | Requerimiento REQ-4614 | propuesto, sin doliente. Lo cierra Gustavo Neira. |

### Sin criterio de aceptación
Solo decididos (7 de 16).
| REQ | Título | Estado |
|---|---|---|
| REQ-2030 | Requerimiento REQ-2030 | aceptado |
| REQ-4606 | Requerimiento REQ-4606 | aceptado |
| REQ-4607 | Requerimiento REQ-4607 | aceptado |
| REQ-4608 | Requerimiento REQ-4608 | aceptado |
| REQ-4609 | Requerimiento REQ-4609 | aceptado |
| REQ-4610 | Requerimiento REQ-4610 | aceptado |
| REQ-4612 | Requerimiento REQ-4612 | aceptado |

Cada doliente lo cierra: Beatriz Cuéllar (2030, 4607), Óscar Ramírez (4606), Elena Duarte (4608), Ricardo Salas (4609), Mauricio Pérez (4610), Gustavo Neira (4612).

### Decidido sin documento que lo respalde
No se pudo comprobar: el cálculo no produce esta señal, así que no afirmo ninguno. Queda por verificar a mano contra el acta del Comité de producto.

### Lleva meses y nadie lo decide
| REQ | Título | Propuesto hace | Quién tiene la facultad |
|---|---|---|---|
| REQ-4614 | Requerimiento REQ-4614 | 124 días (desde 2026-06-15; umbral 60) | Comité de producto |

Propuesta: llevarlo al próximo comité mensual para aceptarlo o descartarlo. No se cierra por viejo.

### Evidencia vieja
Los 11 con evidencia se apoyan en la misma entrevista del 2025-09-27 (12 meses, en el umbral). Esa entrevista no nombra ninguno de estos requerimientos; es la «más cercana»: «Lo necesito y hoy no lo tengo.» Es evidencia débil, además de vieja.
| REQ | Lo más nuevo que lo sostiene | Hace |
|---|---|---|
| REQ-4601, 4602, 4603, 4604, 4606, 4608, 4609, 4610, 4611, 4612, 4615 | Entrevista 2025-09-27 | 12 meses |

### Además, de la definición
- Supuesto sin verificar hace 154 días (umbral 30): «El reglamento vigente lo permite».
- Caso de negocio: volumen mensual declarado 196.775 vs. medido 175.099 (2026-10-15), brecha 11% (bajo el umbral de 20%). El retorno a 24 meses no tiene cifra. Criterio de éxito de la definición: no está dicho.

## Por estado
| propuesto | aceptado | en construcción | entregado | descartado |
|---|---|---|---|---|
| 1 | 16 | 0 | 0 | 0 |
