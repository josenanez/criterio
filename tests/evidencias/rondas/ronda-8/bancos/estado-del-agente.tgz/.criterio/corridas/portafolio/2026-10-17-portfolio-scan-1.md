# Corrida · 2026-10-17-portfolio-scan-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-scan (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T17:02:08 · **Fin:** 2026-10-17T17:05:29 · **Duración:** 201 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-scan` | 13 | 78 | 184 | 60 | 10 fichas nuevas (PRY-199, 200, 201, 204, 205, 206, 207, 209, 210, 211); 35 documentos de PRY-202, 203 y 208 sin cambio, no releidos. Nada movido: entrada/ no existe. Nada omitido ni ilegible. Mirar: hitos cerrados sin acta (200, 204, 205, 210, 211), verde contradicho (200, 209, 211), PRY-206 CC-01 aprobada sin línea base nueva, PRY-210 factura por 2 entregables con 1 acta, 18 citas de pm_record de PRY-202 sin prefijo de carpeta. |

Por señal (`portfolio-scan`): `milestone_met_without_evidence` 20, `commitment_overdue` 8, `progress_vs_plan` 7, `vendor_deliverable_late` 5, `declared_vs_evidence` 4, `commitment_undated` 3, `vendor_accepted_without_evidence` 3, `variance_cost` 3, `commitment_rescheduled` 2, `silent` 1, `variance_time` 1, `rebaseline_unauthorized` 1, `budget_committed` 1, `change_without_baseline` 1

## Lo que el agente mostró

Barrido terminado: escribí y sellé 10 fichas nuevas (PRY-199, 200, 201, 204, 205, 206, 207, 209, 210 y 211). Leí 43 de los 78 documentos. Los otros 35, de PRY-202, 203 y 208, no habían cambiado y no los abrí.

Los términos estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17), así que no hubo que volver a registrarlos. No quedó ningún archivo ilegible ni pendiente de clasificar. La carpeta `entrada/` no existe, así que no moví nada.

El script calculó 60 alertas en el portafolio. Lo más importante en los 10 proyectos leídos:
- **Hitos cerrados sin acta que lo pruebe:** PRY-200 (3), PRY-204 (2), PRY-205 (3), PRY-210 (4) y PRY-211 (2).
- **Verde contradicho por sus propios documentos:** PRY-200, PRY-209 y PRY-211.
- **PRY-210:** la factura FV-1100 cubre dos entregables y solo uno tiene acta. Otros dos entregables del contrato siguen sin recibirse.
- **PRY-206:** la solicitud de cambio CC-01 (+97 días) está aprobada, pero no hay línea base nueva que la refleje.
- **PRY-201:** hay un compromiso vencido, de Elena Duarte, que ya nació vencido.
- **Sin señal pese a estar vencidos:** PRY-199 no tiene alertas. PRY-207 y PRY-209 pasaron su fecha de cierre y no tienen cronograma, así que el cálculo no puede medirlas.
- **PRY-205:** el mismo nombre figura como patrocinador y como gerente.
- **Vacíos:** en las 13 fichas falta la autoridad del gerente, porque ninguna acta la dice.

Dos cosas para vigilar:
- **PRY-202:** el índice marca 18 citas de la ficha de su gerente (`pm_record`) como no resueltas. Las rutas no llevan el prefijo de la carpeta del proyecto, aunque los archivos existen. No toqué esa ficha.
- **Registro de la corrida:** `relectura` muestra 78 sin cambio y 0 releídos. Eso sale del orden en que se sella y no refleja las 43 lecturas reales. Los 43 sí quedaron registrados en el plan.

El resultado completo está en `estado/corridas/salida-portfolio-scan.md`. Si quieres el informe consolidado del portafolio, corre `/criterio-portfolio:portfolio-report`.
