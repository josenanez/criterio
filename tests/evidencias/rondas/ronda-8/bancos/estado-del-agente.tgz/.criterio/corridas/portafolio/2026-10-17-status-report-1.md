# Corrida · 2026-10-17-status-report-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:status-report PRY-200

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-200

**Inicio:** 2026-10-17T17:06:06 · **Fin:** 2026-10-17T17:06:46 · **Duración:** 40 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `status-report` | 13 | — | 24 | 60 | Estado de PRY-200: verde declarado sin sustento (3 hitos cumplidos sin evidencia, 46 puntos de brecha de avance, 23 días de silencio). Dijo no saber: autoridad, fase, última reunión, evidencia de hitos. |

Por señal (`status-report`): `milestone_met_without_evidence` 20, `commitment_overdue` 8, `progress_vs_plan` 7, `vendor_deliverable_late` 5, `declared_vs_evidence` 4, `commitment_undated` 3, `vendor_accepted_without_evidence` 3, `variance_cost` 3, `commitment_rescheduled` 2, `silent` 1, `variance_time` 1, `rebaseline_unauthorized` 1, `budget_committed` 1, `change_without_baseline` 1

## Lo que el agente mostró

Terminé el informe de estado de PRY-200 y dejé la corrida registrada.

*Informe construido desde la ficha PRY-200 (actualizada el 2026-10-17); cifras recalculadas por `compute` con fecha de corte 2026-10-17.*

## PRY-200 · Originación digital — estado al 2026-10-17

- **Declara el gerente (Jorge Medina):** verde, 29%, al 2026-09-24. Esa declaración tiene 23 días, así que aún no está vencida (el umbral es 30).
- **Sustento documental:** sin sustento. La ficha no tiene ninguna fuente independiente; solo el acta, el cronograma v1 y el propio informe de avance.
- **Lo que el semáforo no explica:** hitos cumplidos sin evidencia, avance contra plan y silencio.
- **Último documento:** 2026-09-24, hace 23 días de silencio (el umbral es 15).
- **Última reunión:** sin dato. La ficha no registra ninguna.

**Contra el plan**
- **Fecha de cierre:** 2027-01-21 en la línea base original y en la vigente. Desviación 0 y ninguna replanificación.
- **Presupuesto:** aprobado COP 6.800.000.000, proyección COP 6.809.407406 (+0,1%).
- **Ejecución:** comprometido 72,9%, ejecutado 51,8%, disponible real COP 1.845.004.746.

**Hitos**
- Diseño funcional aprobado (2026-01-02), Ambiente de pruebas certificado (2026-05-10) e Integración con el core (2026-09-15) figuran como cumplidos, sin ninguna evidencia.
- Piloto con usuarios internos (2027-01-21) está pendiente.

**Dónde no coincide**
- **Avance:** el gerente declara 29%, pero con 3 de 4 hitos cumplidos el plan sustenta entre 75% y 100%. La brecha es de 46,0 puntos. Los documentos no permiten saber cuál de las dos cifras está mal.
- **Verde frente a la evidencia:** se reporta verde con tres señales abiertas que ese verde no cubre.

**Abierto**
- **Riesgo:** concentración del conocimiento en una sola persona. No tiene responsable, probabilidad, impacto ni fecha.
- **Incidencia:** hallazgo de seguridad abierto desde 2026-09-24, sin responsable.
- **Compromisos vencidos:** ninguno registrado. Pero la ficha no tiene compromisos de ninguna reunión, así que es ausencia de dato, no cumplimiento.

**Sin dato**
- **Identidad:** autoridad del proyecto y fase.
- **Evidencia:** la de cumplimiento de los tres hitos.
- **Antigüedad:** los campos de identidad y plan vienen del acta y el cronograma del 2025-08-17, con 14 meses, por encima del umbral de 12.

**Siguiente paso:** ofrezco preparar el punto de comité del 2026-10-20 (`/steering-pack`). No hay desviación de fechas ni de costo sobre el umbral, así que no corresponde una solicitud de cambio.

---
criterio-portfolio 0.3.13 · ficha PRY-200 aplicada, actualizada el 2026-10-17 · campos inciertos: autoridad, fase, última reunión, evidencia de hitos · Términos (v1.1) y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.13

Los términos ya estaban vigentes a nombre de José Francisco Ñáñez (2026-10-17), así que no hubo que registrar una aceptación nueva. El informe completo está en `estado/corridas/salida-status-report.md` y la corrida quedó como `2026-10-17-status-report-1`.
