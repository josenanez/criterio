# Corrida · 2026-10-17-product-view-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:product-view nómina empresarial

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T17:19:38 · **Fin:** 2026-10-17T17:20:23 · **Duración:** 45 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-view` | 13 | — | 30 | 60 | Producto de un solo proyecto (PRY-209): sin sección aparte. Señales: variance_cost 10,0 % y verde declarado sin explicar el costo. Reporta 4 proyectos sin producto. No sabe si el sobrecosto tiene aprobación (falta authority). |

Por señal (`product-view`): `milestone_met_without_evidence` 20, `commitment_overdue` 8, `progress_vs_plan` 7, `vendor_deliverable_late` 5, `declared_vs_evidence` 4, `commitment_undated` 3, `vendor_accepted_without_evidence` 3, `variance_cost` 3, `commitment_rescheduled` 2, `silent` 1, `variance_time` 1, `rebaseline_unauthorized` 1, `budget_committed` 1, `change_without_baseline` 1

## Lo que el agente mostró

**Vista por producto: nómina empresarial, al 2026-10-17.** Los términos ya estaban vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17), así que no hubo que registrar nada. Las cifras salen de las fichas, recalculadas con `portafolio.py compute`.

Nómina empresarial tiene un solo proyecto, PRY-209 Nómina electrónica. Por eso no armé una sección de producto aparte. Esto es lo que hay que ver:

- **Costo:** la proyección es COP 2.640.413.839 contra COP 2.400.000.000 aprobados, 10,0 % por encima. Ese es justo el umbral configurado (10 %).
- **Verde sin explicación:** el informe de avance del 2026-10-17 declara verde y 50 % de avance. No explica el sobrecosto.
- **Dinero:**
  - Ejecutado: COP 1.193.333.539 (49,7 %).
  - Comprometido: 70,8 %.
  - Disponible real: COP 700.111.916.
  - La ficha trae las cuatro cifras, así que la suma del producto está completa.
- **Fecha:** el fin vigente es 2026-09-21, anterior a la fecha de corte. El cálculo no marca atraso ni hitos vencidos, y las fichas no traen cierre ni fecha nueva. No lo doy por cerrado.
- **Dependencias:** ninguna entre proyectos del mismo producto, porque solo hay uno.
- **Lo que no sé:** si el sobrecosto tiene aprobación, porque a la ficha le falta `identity.authority`. Tampoco tiene `identity.phase`.

**Cuatro proyectos no declaran producto**, y nadie responde por el conjunto al que sirven:

| Proyecto | Área dueña |
|---|---|
| PRY-202 Migración a la nube | Riesgo y Cumplimiento |
| PRY-205 Prevención de lavado de activos | Riesgo y Cumplimiento |
| PRY-208 Motor de decisión | Banca Hipotecaria |
| PRY-210 Portal de proveedores | Tesorería |

Además, PRY-199 declara el producto como «PRD-299», un código y no un nombre. Así no cruza con los demás productos.

No hay dependencias internas que llevar al comité de producto. Para el comité del 2026-10-20 propongo una sola decisión: PRY-209 está en verde declarado con 10,0 % de sobrecosto proyectado.

La corrida quedó registrada como `2026-10-17-product-view-1`, en 30 segundos y sobre los 13 proyectos del portafolio. El texto completo está en `estado/corridas/salida-product-view.md`. La verificación de las citas es suya.
