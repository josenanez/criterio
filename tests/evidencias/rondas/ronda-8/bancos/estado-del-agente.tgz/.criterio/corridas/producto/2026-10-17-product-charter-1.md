# Corrida · 2026-10-17-product-charter-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-charter REQ-4600

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** REQ-4600

**Inicio:** 2026-10-17T16:46:43 · **Fin:** 2026-10-17T16:47:32 · **Duración:** 49 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-charter` | 14 | — | 34 | 32 | Borrador de acta REQ-4600 sin firma; ficha no creada. Vacíos: autoridad, criterio de éxito medible, necesidad, quién aceptó, patrocinador, gerente, norma/país. |

Por señal (`product-charter`): `requirement_untraced` 11, `evidence_stale` 10, `requirement_without_acceptance` 3, `requirement_undecided` 3, `requirement_accepted_without_evidence` 2, `requirement_without_owner` 1, `assumption_unverified` 1, `claim_vs_metric` 1

## Lo que el agente mostró

Dejé el borrador del acta de constitución del REQ-4600 (Microseguros, PRD-306), con sus vacíos marcados, pero **no creé la ficha del proyecto**. No hay firma, y la ficha va solo después de ella.

Los términos ya estaban vigentes y aceptados por José Francisco Ñáñez el 2026-10-17, así que no los registré de nuevo. Los vacíos que se llevó el borrador, tomando la respuesta sugerida de seguir sin lo que falta y marcarlo:

- **Autoridad:** no está en la definición. «Comité de producto» es solo la propuesta por defecto de la configuración.
- **Criterio de éxito:** el único escrito es «se verifica en producción», sin métrica, umbral ni fecha. El del producto no está en ningún documento.
- **Necesidad:** el requerimiento no tiene necesidad escrita ni título descriptivo.
- **Quién lo aceptó:** el acta del comité (2026-10-05) lo lista como aceptado desde 2026-04-11, pero no dice quién.
- **Evidencia de demanda:** una sola entrevista de 2025-09-25, ya de 12 meses (umbral 12). No nombra el requerimiento ni dice que el cliente sea PyME.
- **Gobierno:** no hay patrocinador, gerente del proyecto ni presupuesto, y la norma y el país aplicables no constan.

**Supuesto de demanda:** el supuesto «la demanda declarada se sostiene sin campaña» (166 días sin verificar) pasa como riesgo del proyecto, sin doliente. El volumen declarado, 140.572, está 28,9 % por encima del medido, 99.900 (umbral 20 %).

**Alcance:** el acta cubre solo REQ-4600. Los otros 13 requerimientos quedan fuera porque no se pidieron aquí. La salida anota qué le falta a cada uno (sin criterio, sin doliente, sin quién lo pidió o solo propuesto).

**Siguiente paso:** cuando haya firma de quien tenga la autoridad, se crea la ficha con `portafolio.py init` y el estado declarado queda vacío. El gerente del proyecto, ya nombrado, instala `criterio-project` y corre `/pm-setup`.

Dejé la corrida registrada como `2026-10-17-product-charter-1`. Lo que te mostré está en `estado-producto/PRD-306/corridas/salida-product-charter.md`.
