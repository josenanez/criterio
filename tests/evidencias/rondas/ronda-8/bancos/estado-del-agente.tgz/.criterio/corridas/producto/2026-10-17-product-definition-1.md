# Corrida · 2026-10-17-product-definition-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-definition (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T16:43:58 · **Fin:** 2026-10-17T16:44:45 · **Duración:** 47 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-definition` | 14 | — | 30 | 32 | La evidencia sostiene débilmente el problema (una entrevista de hace 12 meses); el volumen declarado está 28,9 % sobre lo medido; falta criterio de éxito y quién decide |

Por señal (`product-definition`): `requirement_untraced` 11, `evidence_stale` 10, `requirement_without_acceptance` 3, `requirement_undecided` 3, `requirement_accepted_without_evidence` 2, `requirement_without_owner` 1, `assumption_unverified` 1, `claim_vs_metric` 1

## Lo que el agente mostró

## Definición de Microseguros (PRD-306), contrastada al 2026-10-17

Los términos ya estaban vigentes y registrados a nombre de José Francisco Ñáñez, así que no los volví a registrar.

**Lo que la evidencia contradice:** nada.

**El negocio y los datos:** el volumen mensual declarado es 140.572 (caso de negocio, 2026-07-22). El medido es 99.900 (tablero, corte 2026-10-07). El declarado está 28,9 % por encima, y el umbral es 20 %. La serie medida tiene un solo punto, y no consta si hubo campaña.

**Afirmaciones numéricas que nadie mide:** el «retorno esperado en 24 meses» no trae cifra ni base de cálculo, y no hay ninguna serie que lo mida.

**No está dicho en ninguna parte:**
- La propuesta de valor, que solo dice «Propuesta principal».
- Cuánto pagaría el cliente.
- El tamaño del segmento PyME.
- La unidad del «volumen_mensual».
- Qué proyecto lo construye.
- El criterio de éxito.
- Quién decide. El acta del 2026-10-05 lista solo a Mauricio Pérez y no lo dice. «Comité de producto» es la propuesta por defecto de la configuración.

**Sostenida por un supuesto:** «La demanda declarada se sostiene sin campaña» lleva 166 días sin verificar (umbral 30). Para verificarlo hace falta una serie mensual de volumen con las fechas de campaña al lado. Hoy hay un solo punto.

**Sostenida por evidencia:** una sola entrevista de un cliente (2025-09-25): «Lo necesito y hoy no lo tengo.» Es evidencia débil: alguien dijo que lo necesita, no pagó. La entrevista tampoco dice que sea PyME.

**Evidencia que ya envejeció:** esa entrevista tiene 12 meses, justo en el umbral. Es la única evidencia de demanda y alcanza a 10 de los 14 requerimientos.

**Lo normativo que toca:** estado «no tengo la norma a la vista». No consta el país en la configuración ni en los documentos, así que no nombré ninguna obligación. Esto no es una declaración de cumplimiento. Hace falta el país antes de nombrar normas.

**Lo que falta para cerrar la definición:** el criterio de éxito y quién decide. Sin el criterio de éxito no se puede cerrar, así que no corresponde ofrecer `/product-charter`. El supuesto de 166 días se puede convertir en riesgo con doliente.

Escribí la salida en `estado-producto/PRD-306/corridas/salida-product-definition.md`. Registré la corrida `2026-10-17-product-definition-1`: 32 hallazgos en 30 segundos.
