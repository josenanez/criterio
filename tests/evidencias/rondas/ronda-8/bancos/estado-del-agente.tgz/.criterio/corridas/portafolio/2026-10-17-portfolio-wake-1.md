# Corrida · 2026-10-17-portfolio-wake-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-wake (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T17:21:24 · **Fin:** 2026-10-17T17:22:02 · **Duración:** 38 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-wake` | 13 | — | 25 | 60 | Barrido: 78 documentos sin cambios, 18 citas de PRY-202 sin resolver en el indice (los archivos existen en la carpeta del proyecto). Confirmacion: 5 campos preguntados, sin respuesta (sesion sin interfaz). No toco informe ni peticiones. No se verifico la causa de las citas rotas. |

Por señal (`portfolio-wake`): `milestone_met_without_evidence` 20, `commitment_overdue` 8, `progress_vs_plan` 7, `vendor_deliverable_late` 5, `declared_vs_evidence` 4, `commitment_undated` 3, `vendor_accepted_without_evidence` 3, `variance_cost` 3, `commitment_rescheduled` 2, `silent` 1, `variance_time` 1, `rebaseline_unauthorized` 1, `budget_committed` 1, `change_without_baseline` 1

## Lo que el agente mostró

## 2026-10-17

**Revisé:** 78 documentos, ninguno cambió, 0 proyectos recalculados.

Los términos estaban vigentes (v1.1, aceptados el 2026-10-17 por José Francisco Ñáñez), así que no hizo falta registrarlos de nuevo. No corrí `/portfolio-scan` porque no había nada que releer.

**Citas rotas en PRY-202.** 18 citas no resuelven en el índice. Los archivos citados existen dentro de la carpeta del proyecto. Mi suposición es que la ruta de la ficha no lleva el prefijo de esa carpeta, pero no lo comprobé y no corregí nada. Las citas rotas cubren identidad, estado y avance declarados, plazos, dinero y facturación.

**Peticiones:** no había ninguna pendiente.

**Confirmación:** como nadie responde en esta sesión, tomé la respuesta sugerida (no registrar nada). Quedaron preguntados y sin respuesta cinco campos de PRY-202:
- estado declarado
- avance declarado
- fecha de fin del plan
- proyección de costo
- monto facturado del proveedor

**Registro de la corrida:** quedó `2026-10-17-portfolio-wake-1`, con la salida guardada en `estado/corridas/salida-portfolio-wake.md`. Hay una discrepancia que no investigué: la corrida registró 60 hallazgos por señales en 13 proyectos, pero este barrido no los generó. Parece que cuenta señales abiertas de corridas anteriores.

**Vuelvo el 2026-10-18.** Ese día toca el informe, porque el comité es el 2026-10-20.
