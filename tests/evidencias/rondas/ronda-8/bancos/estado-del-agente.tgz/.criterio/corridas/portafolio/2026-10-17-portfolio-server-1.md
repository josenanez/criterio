# Corrida · 2026-10-17-portfolio-server-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-server rato

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T17:22:07 · **Fin:** 2026-10-17T17:22:59 · **Duración:** 52 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-server` | 13 | — | — | 60 | puerto 8787, informe en estado/reportes, modo rato (solo 127.0.0.1) |

Por señal (`portfolio-server`): `milestone_met_without_evidence` 20, `commitment_overdue` 8, `progress_vs_plan` 7, `vendor_deliverable_late` 5, `declared_vs_evidence` 4, `commitment_undated` 3, `vendor_accepted_without_evidence` 3, `variance_cost` 3, `commitment_rescheduled` 2, `silent` 1, `variance_time` 1, `rebaseline_unauthorized` 1, `budget_committed` 1, `change_without_baseline` 1

## Lo que el agente mostró

Rostrum está corriendo en `http://127.0.0.1:8788/`, en modo «para mirarlo un rato». Solo es accesible desde esta máquina.

**Qué pasó:**
- **Puerto:** el 8787 ya lo ocupaba otro proceso. Sus datos no coinciden con este informe (otra lista de productos), así que no lo toqué y usé 8788.
- **Términos:** ya estaban vigentes (v0.3.13, aceptados por José Francisco Ñáñez el 2026-10-17). No hizo falta volver a registrarlos.
- **Modo:** nadie podía responder, así que tomé la respuesta sugerida, que es empezar por «para mirarlo un rato».
- **Informe servido:** `estado/reportes`, con 13 proyectos (PRY-199 a PRY-211) y 9 productos. Es del 2026-10-17 17:20.
- **Pruebas:** la portada y `/estado.json` responden con 200. Las demás rutas (`/pmo`, `/decisiones`, `/proyectos`, `/productos`, `/p/PRY-202`) responden con 302, es decir, redirigen a su página, y no seguí ninguna redirección.
- **Registro:** la corrida quedó como `2026-10-17-portfolio-server-1`, con la salida en `estado/corridas/salida-portfolio-server.md`. Esa salida ya dice 8788; la corrida se registró antes de que supiera que el 8787 estaba ocupado.

**Qué hay en el portal:**
- **Portada:** `/`, con el formulario de peticiones.
- **PMO:** `/pmo` es el estado del portafolio visto en conjunto.
- **Decisiones:** `/decisiones` es lo que el comité tiene que decidir.
- **Proyectos y productos:** `/proyectos` y `/productos` son los listados. `/p/<código>` y `/producto/<nombre>` enlazan entre sí en los dos sentidos.
- **Corridas y frescura:** `/corridas` muestra las 33 corridas registradas, y `/estado.json` dice de cuándo es el informe.

**Qué enlace pasarle a quién:** ninguno todavía. Este enlace solo funciona en esta máquina y mientras el proceso siga vivo, así que no sirve para el patrocinador. Para eso hace falta el modo «que quede corriendo». Habría que pedir a la organización un host y un puerto internos, y publicarlo detrás de su control de acceso, porque el servidor no autentica.

**Cuándo queda desactualizado:** en cuanto cambie una ficha o un documento. El próximo comité es el 2026-10-20, y conviene regenerar el informe con `/portfolio-report html` antes. La portada muestra la fecha del informe.

El servidor sigue en segundo plano; su log está en `/tmp/claude-0/-home-claude-banco-ronda-8-bancos-espacio/692b0e4d-0e89-5e8d-a391-2cabbf233557/scratchpad/rostrum.log`.
