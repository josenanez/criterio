# Corrida · 2026-10-17-project-charter-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-charter PRY-207 revisar

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-207

**Inicio:** 2026-10-17T17:16:10 · **Fin:** 2026-10-17T17:16:53 · **Duración:** 42 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-charter` | 13 | — | 29 | 60 | Revisión del acta de PRY-207 (2025-07-02): falta autoridad del gerente, cadencia, supuestos, hitos y quién mide el éxito; objetivo, alcance, exclusiones y criterio de éxito son genéricos. No sé si hay autoridad declarada fuera de los dos documentos leídos. |

Por señal (`project-charter`): `milestone_met_without_evidence` 20, `commitment_overdue` 8, `progress_vs_plan` 7, `vendor_deliverable_late` 5, `declared_vs_evidence` 4, `commitment_undated` 3, `vendor_accepted_without_evidence` 3, `variance_cost` 3, `commitment_rescheduled` 2, `silent` 1, `variance_time` 1, `rebaseline_unauthorized` 1, `budget_committed` 1, `change_without_baseline` 1

## Lo que el agente mostró

Acabo de registrar la corrida (`2026-10-17-project-charter-1`), que ya está guardada con su salida completa.

**Acta de PRY-207 (Onboarding PyME):** existe una del 2025-07-02, y es la única. Es casi una plantilla vacía.

- **Autoridad del gerente:** no está declarada. Por eso la reprogramación de salida y el hallazgo de seguridad abiertos no tienen un umbral que los resuelva, y todo sube al Comité de Riesgos.
- **Faltan del todo:** cadencia del comité, supuestos y restricciones, hitos, y quién mide el éxito.
- **Están pero son genéricos:**
  - El objetivo describe la solución, no un resultado.
  - El alcance dice "Componente 1, 2 y 3" sin nombrarlos.
  - La exclusión dice "lo que otro proyecto cubre" sin decir cuál.
  - El criterio de éxito ("en producción y medido") no se puede medir.
- **Patrocinador y gerente:** sí constan, Ricardo Salas y Beatriz Cuéllar.
- **Fuera del acta pero relevante:**
  - El cierre comprometido (2026-03-03) está vencido hace más de siete meses, y no hay línea base nueva.
  - El informe del 2026-10-07 muestra ejecutado por encima de comprometido (9.436.735.981 frente a 8.804.213.210 COP), sin explicación.

Lo que no sé es si la autoridad del gerente está declarada fuera de los dos documentos que leí (el acta y el informe). Los campos que no están quedaron marcados como pendientes de definir, no los completé.

Los términos ya estaban vigentes (v0.3.13, aceptados el 2026-10-17), así que no hubo que registrarlos de nuevo. Nadie respondió preguntas, pero tampoco hizo falta ninguna.

**Siguiente paso que ofrezco:** llevar la definición de autoridad, junto con una línea base nueva, al Comité de Riesgos, y pasar los supuestos que salieron de la revisión al registro RAID con `/raid-log`.

Los archivos están en `/home/claude/banco/ronda-8/bancos/espacio/estado/corridas/`:
- `salida-project-charter.md`
- `2026-10-17-project-charter-1.md`
