# Corrida · 2026-10-17-product-business-case-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-business-case (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T16:44:50 · **Fin:** 2026-10-17T16:45:34 · **Duración:** 44 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-business-case` | 14 | — | 29 | 32 | Caso de negocio armado: 1 cifra declarada (140.572) contra 1 medida (99.900), 28,9 % de distancia; costos, retorno, criterio de éxito, precio y tamaño del segmento quedan como vacíos; 11 aceptados en alcance, 2 sin quien los pidiera; sin otros productos publicados para cruzar. |

Por señal (`product-business-case`): `requirement_untraced` 11, `evidence_stale` 10, `requirement_without_acceptance` 3, `requirement_undecided` 3, `requirement_accepted_without_evidence` 2, `requirement_without_owner` 1, `assumption_unverified` 1, `claim_vs_metric` 1

## Lo que el agente mostró

Armé el caso de negocio de Microseguros (PRD-306) y dejé la corrida registrada. En el caso, la única cifra con fuente, el volumen mensual, no coincide con la medida. Los términos ya estaban vigentes a nombre de José Francisco Ñáñez (2026-10-17), así que no los registré de nuevo.

- **Volumen mensual:** el caso declara 140.572 (2026-07-22) y el tablero mide 99.900 (corte 2026-10-07). La declarada está 28,9 % por encima, con umbral de 20 %. La serie medida tiene un solo punto, así que es una diferencia entre dos fechas y no una tendencia. Esa diferencia quedó dentro del caso.
- **Costos:** ningún documento da el costo de construir, el del equipo ni contratos. Por eso lo que hay es una propuesta y no un caso evaluable.
- **Retorno:** «retorno esperado en 24 meses» es un plazo sin cifra ni base de cálculo. Lo traté como vacío, no como cifra.
- **Alcance:** entran los 11 requerimientos aceptados. Dos de ellos (REQ-4605 y REQ-4613) no tienen a nadie que los haya pedido, y ninguno de los 11 tiene proyecto que lo construya.
- **Supuesto:** «la demanda se sostiene sin campaña» lleva 166 días sin verificarse.
- **Otros vacíos:** el criterio de éxito, el precio, el tamaño del segmento PyME y la unidad del volumen no están en ningún documento. Tampoco consta quién decide ni qué norma aplica.
- **Cruce con otros productos:** no se pudo hacer. Las carpetas de `estado/` existen pero no tienen fichas dentro.

No calculé rentabilidad, no estimé cifras ni recomendé aprobar o rechazar. Dejé ofrecido pasar el supuesto al seguimiento. `/product-charter` no corresponde todavía, porque la definición no está cerrada.

La corrida es `2026-10-17-product-business-case-1` (29 segundos, 32 hallazgos).

Archivos en `estado-producto/PRD-306/corridas/`:
- `salida-product-business-case.md`
