<!-- origen: PRY-211-cobranza-digital/20-seguimiento/2026-09-27-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Cobranza digital
Código: PRY-211
Fecha de corte: 2026-09-27
Gerente: Mauricio Pérez

Estado declarado
Verde
Avance reportado: 80%

Lo que pasó en el periodo
- El equipo perdió dos semanas por rotación de un desarrollador clave

Presupuesto
COP
Aprobado 800.000.000
Comprometido 564.632.510
Ejecutado 338.564.647
Proyección al cierre 768.783.864

Riesgos abiertos
- Dependencia del calendario de liberaciones del core
