<!-- origen: PRY-202-migración-a-la-nube/10-plan/2025-11-03-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-02-24 | 2026-02-24 | cerrado
Ambiente de pruebas certificado | 2026-06-07 | 2026-06-07 | cerrado
Integración con el core | 2026-09-19 | 2026-09-19 | cerrado
Piloto con usuarios internos | 2026-12-31 | 2026-12-31 | en curso
Salida a producción | 2027-04-14 | 2027-04-14 | en curso
