<!-- origen: PRY-207-onboarding-pyme/00-gobierno/2025-07-02-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Onboarding PyME

Código: PRY-207

Área dueña: Banca PyME

Patrocinador: Ricardo Salas

Gerente de proyecto: Beatriz Cuéllar

Comité: Comité de Riesgos

Producto asociado: cuenta PyME

Fecha de aprobación: 2025-07-02

Objetivo del negocio

Entregar onboarding pyme para Banca PyME.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

18.000.000.000 COP, aprobado por Comité de Riesgos el 2025-07-02.

Fechas comprometidas

Fecha

Inicio

2025-07-12

Cierre

2026-03-03

Criterio de éxito

Onboarding PyME en producción y medido.

Dependencias declaradas

• Ninguna declarada
