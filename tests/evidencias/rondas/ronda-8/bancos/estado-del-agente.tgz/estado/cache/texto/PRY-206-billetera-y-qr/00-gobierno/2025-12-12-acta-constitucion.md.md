<!-- origen: PRY-206-billetera-y-qr/00-gobierno/2025-12-12-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Billetera y QR

**Código:** PRY-206
**Área dueña:** Medios de Pago
**Patrocinador:** Javier Hoyos
**Gerente de proyecto:** Rubén Cárdenas
**Comité:** Comité de Medios de Pago
**Producto asociado:** pagos QR
**Fecha de aprobación:** 2025-12-12

## Objetivo del negocio

Entregar billetera y qr para Medios de Pago.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**18.000.000.000 COP**, aprobado por Comité de Medios de Pago el 2025-12-12.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-12-22 |
| Cierre | 2027-01-15 |

## Criterio de éxito

Billetera y QR en producción y medido.

## Dependencias declaradas

- Ninguna declarada
