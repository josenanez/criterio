<!-- origen: PRY-205-prevención-de-lavado-de-activos/20-seguimiento/2026-10-04-acta-recibo-ambiente-de-pruebas-certificado.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de recibo · Ambiente de pruebas certificado
Proyecto: PRY-205 · Prevención de lavado de activos
Fecha de recibo: 2026-10-04
Recibido por: Óscar Ramírez
Se recibe a satisfacción el entregable Ambiente de pruebas certificado.
