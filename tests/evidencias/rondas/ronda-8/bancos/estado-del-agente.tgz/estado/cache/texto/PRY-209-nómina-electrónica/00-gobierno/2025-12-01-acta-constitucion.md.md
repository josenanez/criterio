<!-- origen: PRY-209-nómina-electrónica/00-gobierno/2025-12-01-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Nómina electrónica

**Código:** PRY-209
**Área dueña:** Tesorería
**Patrocinador:** Óscar Ramírez
**Gerente de proyecto:** Paula Céspedes
**Comité:** Comité de Medios de Pago
**Producto asociado:** nómina empresarial
**Fecha de aprobación:** 2025-12-01

## Objetivo del negocio

Entregar nómina electrónica para Tesorería.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**2.400.000.000 COP**, aprobado por Comité de Medios de Pago el 2025-12-01.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-12-11 |
| Cierre | 2026-09-21 |

## Criterio de éxito

Nómina electrónica en producción y medido.

## Dependencias declaradas

- Ninguna declarada
