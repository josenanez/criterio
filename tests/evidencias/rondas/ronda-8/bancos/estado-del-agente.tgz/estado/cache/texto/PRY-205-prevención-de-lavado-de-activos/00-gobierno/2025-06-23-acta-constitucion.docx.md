<!-- origen: PRY-205-prevención-de-lavado-de-activos/00-gobierno/2025-06-23-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Prevención de lavado de activos

Código: PRY-205

Área dueña: Riesgo y Cumplimiento

Patrocinador: Óscar Ramírez

Gerente de proyecto: Óscar Ramírez

Comité: Comité de Transformación Digital

Producto asociado: No aplica

Fecha de aprobación: 2025-06-23

Objetivo del negocio

Entregar prevención de lavado de activos para Riesgo y Cumplimiento.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

1.200.000.000 COP, aprobado por Comité de Transformación Digital el 2025-06-23.

Fechas comprometidas

Fecha

Inicio

2025-07-03

Cierre

2026-06-17

Criterio de éxito

Prevención de lavado de activos en producción y medido.

Dependencias declaradas

• Ninguna declarada
