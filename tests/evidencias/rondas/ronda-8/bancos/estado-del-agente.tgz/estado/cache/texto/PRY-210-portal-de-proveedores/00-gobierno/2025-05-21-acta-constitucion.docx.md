<!-- origen: PRY-210-portal-de-proveedores/00-gobierno/2025-05-21-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Portal de proveedores

Código: PRY-210

Área dueña: Tesorería

Patrocinador: Camilo Beltrán

Gerente de proyecto: Paula Céspedes

Comité: Comité de Riesgos

Producto asociado: No aplica

Fecha de aprobación: 2025-05-21

Objetivo del negocio

Entregar portal de proveedores para Tesorería.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

4.200.000.000 COP, aprobado por Comité de Riesgos el 2025-05-21.

Fechas comprometidas

Fecha

Inicio

2025-05-31

Cierre

2026-01-03

Criterio de éxito

Portal de proveedores en producción y medido.

Dependencias declaradas

• Ninguna declarada
