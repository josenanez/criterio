<!-- origen: PRY-208-motor-de-decisión/20-seguimiento/2026-10-17-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Motor de decisión

**Código:** PRY-208
**Fecha de corte:** 2026-10-17
**Gerente:** Gustavo Neira

## Estado declarado

**Rojo**

Avance reportado: **57%**

## Lo que pasó en el periodo

- Dos historias quedaron fuera del alcance del sprint por dependencia con el core
- Se levantó un hallazgo de seguridad en la revisión de arquitectura

## Presupuesto

| | COP |
|---|---|
| Aprobado | 4.200.000.000 |
| Comprometido | 2.627.159.697 |
| Ejecutado | 760.056.752 |
| Proyección al cierre | 5.331.567.805 |

## Riesgos abiertos

- Disponibilidad del equipo de seguridad para la revisión final
- Cambio regulatorio en discusión que puede mover el alcance
