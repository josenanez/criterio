<!-- origen: PRY-200-originación-digital/00-gobierno/2025-08-17-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Originación digital

Código: PRY-200

Área dueña: Banca Empresas

Patrocinador: Mauricio Pérez

Gerente de proyecto: Jorge Medina

Comité: Comité de Banca Empresas

Producto asociado: crédito de consumo

Fecha de aprobación: 2025-08-17

Objetivo del negocio

Entregar originación digital para Banca Empresas.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

6.800.000.000 COP, aprobado por Comité de Banca Empresas el 2025-08-17.

Fechas comprometidas

Fecha

Inicio

2025-08-27

Cierre

2027-01-21

Criterio de éxito

Originación digital en producción y medido.

Dependencias declaradas

• Ninguna declarada
