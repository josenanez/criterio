<!-- origen: PRY-210-portal-de-proveedores/10-plan/2025-05-21-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2025-07-13,2025-07-13,cerrado
Ambiente de pruebas certificado,2025-08-25,2025-08-25,cerrado
Integración con el core,2025-10-08,2025-10-08,cerrado
Piloto con usuarios internos,2025-11-20,2025-11-20,cerrado
Salida a producción,2026-01-03,2026-01-03,cerrado
