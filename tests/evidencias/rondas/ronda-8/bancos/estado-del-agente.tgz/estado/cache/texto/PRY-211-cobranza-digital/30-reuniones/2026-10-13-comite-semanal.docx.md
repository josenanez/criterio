<!-- origen: PRY-211-cobranza-digital/30-reuniones/2026-10-13-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Medios de Pago · Cobranza digital

Fecha: 2026-10-13

Asistentes: Mauricio Pérez, Laura Vélez

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Rubén Cárdenas

Entregar el punto 7

2026-10-18
