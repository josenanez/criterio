<!-- origen: PRY-202-migración-a-la-nube/30-reuniones/2026-09-12-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Banca Empresas · Migración a la nube

**Fecha:** 2026-09-12
**Asistentes:** Camilo Beltrán, Felipe Arango, Laura Vélez, María Restrepo, Natalia Ospina, Paula Céspedes, Ricardo Salas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Laura Vélez | Enviar el documento 1 | 2026-10-03 |
| María Restrepo | Cerrar la prueba 2 | 2026-10-02 |
| Paula Céspedes | Revisar el anexo 3 | 2026-09-20 |
| Paula Céspedes | Validar el ambiente 4 | 2026-10-14 |
| Felipe Arango | Aprobar el diseño 5 | 2026-09-15 |
| Natalia Ospina | Actualizar la matriz 6 | 2026-10-04 |
| Natalia Ospina | Confirmar la fecha 7 | 2026-10-08 |
| Ricardo Salas | Entregar el punto 8 | 2026-10-05 |
