<!-- origen: PRY-205-prevención-de-lavado-de-activos/20-seguimiento/2026-10-16-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Prevención de lavado de activos
Código: PRY-205
Fecha de corte: 2026-10-16
Gerente: Óscar Ramírez

Estado declarado
Rojo
Avance reportado: 51%

Lo que pasó en el periodo
- Se ajustó el plan de pruebas con el área de seguridad

Presupuesto
COP
Aprobado 1.200.000.000
Comprometido 890.894.455
Ejecutado 211.162.320
Proyección al cierre 1.199.500.067

Riesgos abiertos
- Cambio regulatorio en discusión que puede mover el alcance
