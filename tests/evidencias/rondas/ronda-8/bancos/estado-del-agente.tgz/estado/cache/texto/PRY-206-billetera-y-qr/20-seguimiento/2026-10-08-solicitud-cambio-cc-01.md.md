<!-- origen: PRY-206-billetera-y-qr/20-seguimiento/2026-10-08-solicitud-cambio-cc-01.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-01

**Proyecto:** PRY-206 · Billetera y QR
**Fecha:** 2026-10-08
**Solicitante:** Rubén Cárdenas

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +97 días sobre la línea base vigente |
| Costo | 194.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
