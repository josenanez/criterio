<!-- origen: PRY-202-migración-a-la-nube/30-reuniones/2026-09-05-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Banca Empresas · Migración a la nube

**Fecha:** 2026-09-05
**Asistentes:** Camilo Beltrán, Laura Vélez, María Restrepo, Paula Céspedes

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Laura Vélez | Enviar el documento 1 | 2026-09-24 |
| María Restrepo | Cerrar la prueba 2 | 2026-09-13 |
| Paula Céspedes | Revisar el anexo 3 | 2026-09-20 |
| Paula Céspedes | Validar el ambiente 4 | 2026-09-24 |
