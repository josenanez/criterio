<!-- origen: PRY-210-portal-de-proveedores/20-seguimiento/2025-11-01-acta-recibo-ct-100-parametrización-del-tarifario.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de recibo · Parametrización del tarifario

**Proyecto:** PRY-210 · Portal de proveedores
**Fecha de recibo:** 2025-11-01
**Recibido por:** Paula Céspedes

Se recibe a satisfacción el entregable **Parametrización del tarifario**.

Contrato CT-100 · Talento Digital S.A.S..
