<!-- origen: PRY-209-nómina-electrónica/20-seguimiento/2026-10-17-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Nómina electrónica

**Código:** PRY-209
**Fecha de corte:** 2026-10-17
**Gerente:** Paula Céspedes

## Estado declarado

**Verde**

Avance reportado: **50%**

## Lo que pasó en el periodo

- La prueba de carga no alcanzó el umbral pactado y se repite
- Se recibió la aprobación regulatoria pendiente desde el trimestre anterior

## Presupuesto

| | COP |
|---|---|
| Aprobado | 2.400.000.000 |
| Comprometido | 1.699.888.084 |
| Ejecutado | 1.193.333.539 |
| Proyección al cierre | 2.640.413.839 |

## Riesgos abiertos

- Dependencia del calendario de liberaciones del core
