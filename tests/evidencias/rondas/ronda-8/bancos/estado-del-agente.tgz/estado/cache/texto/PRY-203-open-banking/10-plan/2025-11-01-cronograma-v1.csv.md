<!-- origen: PRY-203-open-banking/10-plan/2025-11-01-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2026-02-07,2026-02-07,cerrado
Ambiente de pruebas certificado,2026-05-06,2026-05-06,cerrado
Integración con el core,2026-08-02,2026-08-02,cerrado
Piloto con usuarios internos,2026-10-29,2026-10-29,en curso
