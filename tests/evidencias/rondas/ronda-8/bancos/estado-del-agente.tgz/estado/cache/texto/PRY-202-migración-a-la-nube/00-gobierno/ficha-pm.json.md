<!-- origen: PRY-202-migración-a-la-nube/00-gobierno/ficha-pm.json · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

{
 "schema_version": "0.2",
 "identity": {
 "code": {
 "value": "PRY-202",
 "source": "00-gobierno/2025-11-03-acta-constitucion.docx",
 "source_date": "2025-11-03",
 "state": "found"
 },
 "name": {
 "value": "Migración a la nube",
 "source": "00-gobierno/2025-11-03-acta-constitucion.docx",
 "source_date": "2025-11-03",
 "state": "found"
 },
 "aliases": [],
 "business_area": {
 "value": "Riesgo y Cumplimiento",
 "source": "00-gobierno/2025-11-03-acta-constitucion.docx",
 "source_date": "2025-11-03",
 "state": "found"
 },
 "product": {
 "value": null,
 "source": "00-gobierno/2025-11-03-acta-constitucion.docx",
 "source_date": "2025-11-03",
 "state": "not_found",
 "note": "el acta dice «No aplica»"
 },
 "authority": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "sponsor": {
 "value": "María Restrepo",
 "source": "00-gobierno/2025-11-03-acta-constitucion.docx",
 "source_date": "2025-11-03",
 "state": "found"
 },
 "manager": {
 "value": "Camilo Beltrán",
 "source": "20-seguimiento/2026-10-17-informe-avance.md",
 "source_date": "2026-10-17",
 "state": "found"
 },
 "committee": {
 "value": "Comité de Banca Empresas",
 "source": "00-gobierno/2025-11-03-acta-constitucion.docx",
 "source_date": "2025-11-03",
 "state": "found"
 },
 "phase": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 }
 },
 "declared": {
 "status": {
 "value": "rojo",
 "source": "20-seguimiento/2026-10-17-informe-avance.md",
 "source_date": "2026-10-17",
 "state": "found",
 "source_kind": "declaration"
 },
 "progress_pct": {
 "value": 77,
 "source": "20-seguimiento/2026-10-17-informe-avance.md",
 "source_date": "2026-10-17",
 "state": "found",
 "source_kind": "declaration"
 },
 "as_of": "2026-10-17",
 "source": "20-seguimiento/2026-10-17-informe-avance.md"
 },
 "plan": {
 "start_date": {
 "value": "2025-11-13",
 "source": "00-gobierno/2025-11-03-acta-constitucion.docx",
 "source_date": "2025-11-03",
 "state": "found"
 },
 "end_date": {
 "value": "2027-06-29",
 "source": "10-plan/2026-10-17-cronograma-v2.csv",
 "source_date": "2026-10-17",
 "state": "found"
 },
 "baseline": [
 {
 "version": 1,
 "approved_on": "2025-11-03",
 "start_date": "2025-11-13",
 "end_date": "2027-04-14",
 "reason": "aprobación inicial del acta de constitución",
 "source": "00-gobierno/2025-11-03-acta-constitucion.docx"
 }
 ],
 "milestones": [
 {
 "name": "Diseño funcional aprobado",
 "baseline_date": "2026-02-24",
 "current_date": "2026-02-24",
 "state": "met",
 "evidence": null,
 "source": "10-plan/2026-10-17-cronograma-v2.csv"
 },
 {
 "name": "Ambiente de pruebas certificado",
 "baseline_date": "2026-06-07",
 "current_date": "2026-06-07",
 "state": "met",
 "evidence": "20-seguimiento/2026-10-04-acta-recibo-ambiente-de-pruebas-certificado.pdf",
 "source": "10-plan/2026-10-17-cronograma-v2.csv"
 },
 {
 "name": "Integración con el core",
 "baseline_date": "2026-09-19",
 "current_date": "2026-09-19",
 "state": "met",
 "evidence": null,
 "source": "10-plan/2026-10-17-cronograma-v2.csv"
 },
 {
 "name": "Piloto con usuarios internos",
 "baseline_date": "2026-12-31",
 "current_date": "2026-12-31",
 "state": "pending",
 "evidence": null,
 "source": "10-plan/2026-10-17-cronograma-v2.csv"
 },
 {
 "name": "Salida a producción",
 "baseline_date": "2027-04-14",
 "current_date": "2027-06-29",
 "state": "pending",
 "evidence": null,
 "source": "10-plan/2026-10-17-cronograma-v2.csv"
 }
 ],
 "scope_summary": {
 "value": "Componente 1, Componente 2 y Componente 3",
 "source": "00-gobierno/2025-11-03-acta-constitucion.docx",
 "source_date": "2025-11-03",
 "state": "found"
 },
 "exclusions": {
 "value": [
 "Lo que otro proyecto cubre"
 ],
 "source": "00-gobierno/2025-11-03-acta-constitucion.docx",
 "source_date": "2025-11-03",
 "state": "found"
 }
 },
 "money": {
 "currency": "COP",
 "approved": {
 "value": 6800000000,
 "source": "20-seguimiento/2026-10-17-informe-avance.md",
 "source_date": "2026-10-17",
 "state": "found"
 },
 "committed": {
 "value": 3838191725,
 "source": "20-seguimiento/2026-10-17-informe-avance.md",
 "source_date": "2026-10-17",
 "state": "found"
 },
 "executed": {
 "value": 3907353837,
 "source": "20-seguimiento/2026-10-17-informe-avance.md",
 "source_date": "2026-10-17",
 "state": "found"
 },
 "projection": {
 "value": 6544762976,
 "source": "20-seguimiento/2026-10-17-informe-avance.md",
 "source_date": "2026-10-17",
 "state": "found"
 }
 },
 "vendors": [
 {
 "name": "Datacore Colombia",
 "contract_ref": "CT-267",
 "source": "00-gobierno/2025-10-27-contrato-ct-267.docx",
 "deliverables": [
 {
 "name": "Licenciamiento del motor",
 "due_date": "2026-04-04",
 "amount": 428583833,
 "state": "pending",
 "evidence": null
 },
 {
 "name": "Bolsa de horas de desarrollo",
 "due_date": "2026-08-24",
 "amount": 428583833,
 "state": "accepted",
 "evidence": null
 },
 {
 "name": "Parametrización del tarifario",
 "due_date": "2027-01-13",
 "amount": 428583833,
 "state": "pending",
 "evidence": null
 }
 ],
 "invoiced": {
 "value": 428583833,
 "source": "20-seguimiento/2026-08-30-factura-ct-267.pdf",
 "source_date": "2026-08-30"
 }
 },
 {
 "name": "Datacore Colombia",
 "contract_ref": "CT-243",
 "source": "00-gobierno/2025-11-08-contrato-ct-243.md",
 "deliverables": [
 {
 "name": "Licenciamiento del motor",
 "due_date": "2026-05-21",
 "amount": 321737192,
 "state": "pending",
 "evidence": null
 },
 {
 "name": "Bolsa de horas de desarrollo",
 "due_date": "2026-11-27",
 "amount": 321737192,
 "state": "pending",
 "evidence": null
 }
 ],
 "invoiced": null
 }
 ],
 "raid": {
 "risks": [
 {
 "what": "El proveedor no ha confirmado la fecha de la última entrega",
 "probability": null,
 "impact": null,
 "owner": "no_identificado",
 "due_date": null,
 "last_moved": null,
 "source": "20-seguimiento/2026-10-17-informe-avance.md"
 },
 {
 "what": "El proveedor podría no llegar con el equipo completo para la siguiente fase (se comentó en la reunión; nadie lo anotó como riesgo)",
 "probability": null,
 "impact": null,
 "owner": "no_identificado",
 "due_date": null,
 "last_moved": null,
 "source": "2026-10-17-notas-reunion.txt"
 }
 ],
 "assumptions": [],
 "issues": [
 {
 "what": "El equipo perdió dos semanas por rotación de un desarrollador clave",
 "since": null,
 "owner": "no_identificado",
 "source": "20-seguimiento/2026-10-17-informe-avance.md"
 },
 {
 "what": "La prueba de carga no alcanzó el umbral pactado y se repite",
 "since": null,
 "owner": "no_identificado",
 "source": "20-seguimiento/2026-10-17-informe-avance.md"
 }
 ],
 "dependencies": []
 },
 "changes": [
 {
 "ref": "CC-01",
 "requested_on": "2026-10-08",
 "scope_impact": "Ampliación de alcance",
 "time_impact": "+76 días sobre la línea base vigente",
 "cost_impact": "152.000.000 COP",
 "decision": "pending",
 "decided_by": null,
 "source": "20-seguimiento/2026-10-08-solicitud-cambio-cc-01.md"
 }
 ],
 "commitments": [
 {
 "who": "Laura Vélez",
 "what": "Enviar el documento 1",
 "due_date": "2026-12-28",
 "original_due_date": "2026-09-24",
 "stated_on": "2026-09-05",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-03",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md"
 },
 {
 "due_date": "2026-10-15",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md"
 },
 {
 "due_date": "2026-11-04",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md"
 },
 {
 "due_date": "2026-11-24",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 },
 {
 "due_date": "2026-12-14",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 },
 {
 "due_date": "2026-12-28",
 "stated_on": "2026-10-17",
 "source": "2026-10-17-notas-reunion.txt"
 }
 ]
 },
 {
 "who": "María Restrepo",
 "what": "Cerrar la prueba 2",
 "due_date": "2026-12-15",
 "original_due_date": "2026-09-13",
 "stated_on": "2026-09-05",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-02",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md"
 },
 {
 "due_date": "2026-10-23",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md"
 },
 {
 "due_date": "2026-11-05",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md"
 },
 {
 "due_date": "2026-11-24",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 },
 {
 "due_date": "2026-12-15",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Paula Céspedes",
 "what": "Revisar el anexo 3",
 "due_date": "2026-09-20",
 "original_due_date": "2026-09-20",
 "stated_on": "2026-09-05",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-09-19-acta-recibo-3.md"
 },
 {
 "who": "Paula Céspedes",
 "what": "Validar el ambiente 4",
 "due_date": "2026-11-03",
 "original_due_date": "2026-09-24",
 "stated_on": "2026-09-05",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-14",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md"
 },
 {
 "due_date": "2026-11-03",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Felipe Arango",
 "what": "Aprobar el diseño 5",
 "due_date": "2026-10-20",
 "original_due_date": "2026-09-15",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-20",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Natalia Ospina",
 "what": "Actualizar la matriz 6",
 "due_date": "2026-10-04",
 "original_due_date": "2026-10-04",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "state": "overdue",
 "reschedules": []
 },
 {
 "who": "Natalia Ospina",
 "what": "Confirmar la fecha 7",
 "due_date": "2026-10-08",
 "original_due_date": "2026-10-08",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-09-19-acta-recibo-7.md"
 },
 {
 "who": "Ricardo Salas",
 "what": "Entregar el punto 8",
 "due_date": "2026-10-05",
 "original_due_date": "2026-10-05",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "state": "unknown",
 "reschedules": [],
 "note": "2026-09-19: dice que ya lo entregó, no se presentó acta; desde 2026-09-26 sale de la lista sin cierre"
 },
 {
 "who": "Natalia Ospina",
 "what": "Enviar el documento 9",
 "due_date": "2026-10-19",
 "original_due_date": "2026-10-06",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-19",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md"
 }
 ]
 },
 {
 "who": "María Restrepo",
 "what": "Cerrar la prueba 10",
 "due_date": "2026-10-26",
 "original_due_date": "2026-10-11",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-26",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Gustavo Neira",
 "what": "Revisar el anexo 11",
 "due_date": "2026-10-15",
 "original_due_date": "2026-10-02",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "state": "met",
 "reschedules": [
 {
 "due_date": "2026-10-15",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 }
 ],
 "evidence": "20-seguimiento/2026-10-10-acta-recibo-11.md"
 },
 {
 "who": "Sandra Gil",
 "what": "Validar el ambiente 12",
 "due_date": "2026-09-24",
 "original_due_date": "2026-09-24",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "state": "overdue",
 "reschedules": []
 },
 {
 "who": "Ricardo Salas",
 "what": "Aprobar el diseño 13",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "state": "unknown",
 "reschedules": [],
 "note": "2026-09-26: «por definir». 2026-10-03: dice que ya lo entregó, no se presentó acta; sale de la lista"
 },
 {
 "who": "Laura Vélez",
 "what": "Actualizar la matriz 14",
 "due_date": "2026-10-21",
 "original_due_date": "2026-10-21",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "María Restrepo",
 "what": "Confirmar la fecha 15",
 "due_date": "2026-10-18",
 "original_due_date": "2026-09-30",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-18",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Ricardo Salas",
 "what": "Entregar el punto 16",
 "due_date": "2026-10-13",
 "original_due_date": "2026-10-13",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "state": "overdue",
 "reschedules": []
 },
 {
 "who": "Diana Molina",
 "what": "Enviar el documento 17",
 "due_date": "2026-10-23",
 "original_due_date": "2026-10-23",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Gustavo Neira",
 "what": "Cerrar la prueba 18",
 "due_date": "2026-11-05",
 "original_due_date": "2026-10-21",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-11-05",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Mauricio Pérez",
 "what": "Revisar el anexo 19",
 "due_date": "2026-10-15",
 "original_due_date": "2026-10-15",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "state": "unknown",
 "reschedules": [],
 "note": "2026-10-10: dice que ya lo entregó, no se presentó acta; sale de la lista"
 },
 {
 "who": "Natalia Ospina",
 "what": "Validar el ambiente 20",
 "due_date": "2026-10-07",
 "original_due_date": "2026-10-07",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "state": "overdue",
 "reschedules": []
 },
 {
 "who": "Ricardo Salas",
 "what": "Aprobar el diseño 21",
 "due_date": "2026-10-23",
 "original_due_date": "2026-10-23",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Diana Molina",
 "what": "Actualizar la matriz 22",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Óscar Ramírez",
 "what": "Confirmar la fecha 23",
 "due_date": "2026-11-02",
 "original_due_date": "2026-11-02",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Ricardo Salas",
 "what": "Entregar el punto 24",
 "due_date": "2026-11-02",
 "original_due_date": "2026-11-02",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Laura Vélez",
 "what": "Mandar el ajuste del presupuesto",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-10-17",
 "source": "2026-10-17-notas-reunion.txt",
 "state": "open",
 "reschedules": [],
 "note": "«la otra semana»: no es una fecha"
 },
 {
 "who": "Óscar Ramírez",
 "what": "Revisión con el proveedor",
 "due_date": "2026-10-27",
 "original_due_date": "2026-10-27",
 "stated_on": "2026-10-17",
 "source": "2026-10-17-notas-reunion.txt",
 "state": "open",
 "reschedules": []
 }
 ],
 "meta": {
 "record_updated": "2026-10-17",
 "documents_seen": [],
 "fields_not_found": [
 "identity.product",
 "identity.authority",
 "identity.phase"
 ],
 "open_conflicts": []
 }
}
