<!-- origen: PRY-202-migración-a-la-nube/30-reuniones/2026-09-19-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Banca Empresas · Migración a la nube

**Fecha:** 2026-09-19
**Asistentes:** Camilo Beltrán, Felipe Arango, Gustavo Neira, Laura Vélez, María Restrepo, Natalia Ospina, Paula Céspedes, Sandra Gil

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Laura Vélez | Enviar el documento 1 | 2026-10-15 |
| María Restrepo | Cerrar la prueba 2 | 2026-10-23 |
| Paula Céspedes | Validar el ambiente 4 | 2026-10-14 |
| Felipe Arango | Aprobar el diseño 5 | 2026-09-15 |
| Natalia Ospina | Actualizar la matriz 6 | 2026-10-04 |
| Natalia Ospina | Enviar el documento 9 | 2026-10-06 |
| María Restrepo | Cerrar la prueba 10 | 2026-10-11 |
| Gustavo Neira | Revisar el anexo 11 | 2026-10-02 |
| Sandra Gil | Validar el ambiente 12 | 2026-09-24 |

## Cerrados en esta reunión

- Revisar el anexo 3 (Paula Céspedes): recibido, acta de recibo del 2026-09-19.
- Confirmar la fecha 7 (Natalia Ospina): recibido, acta de recibo del 2026-09-19.

## Lo que se dijo

- Ricardo Salas dice que ya entregó «entregar el punto 8». No se presentó acta.
