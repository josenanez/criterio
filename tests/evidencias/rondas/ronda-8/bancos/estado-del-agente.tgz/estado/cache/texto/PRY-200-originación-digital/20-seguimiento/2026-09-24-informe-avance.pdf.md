<!-- origen: PRY-200-originación-digital/20-seguimiento/2026-09-24-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Originación digital
Código: PRY-200
Fecha de corte: 2026-09-24
Gerente: Jorge Medina

Estado declarado
Verde
Avance reportado: 29%

Lo que pasó en el periodo
- Se levantó un hallazgo de seguridad en la revisión de arquitectura
- Se ajustó el plan de pruebas con el área de seguridad

Presupuesto
COP
Aprobado 6.800.000.000
Comprometido 4.954.995.254
Ejecutado 3.520.982.115
Proyección al cierre 6.809.407.406

Riesgos abiertos
- Concentración del conocimiento en una sola persona
