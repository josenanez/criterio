<!-- origen: PRY-205-prevención-de-lavado-de-activos/10-plan/2025-06-23-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2025-09-28 | 2025-09-28 | cerrado
Ambiente de pruebas certificado | 2025-12-24 | 2025-12-24 | cerrado
Integración con el core | 2026-03-22 | 2026-03-22 | cerrado
Piloto con usuarios internos | 2026-06-17 | 2026-06-17 | cerrado
