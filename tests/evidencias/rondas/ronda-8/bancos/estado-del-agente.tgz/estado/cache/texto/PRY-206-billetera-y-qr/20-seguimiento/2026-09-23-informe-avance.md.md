<!-- origen: PRY-206-billetera-y-qr/20-seguimiento/2026-09-23-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Billetera y QR

**Código:** PRY-206
**Fecha de corte:** 2026-09-23
**Gerente:** Rubén Cárdenas

## Estado declarado

**Verde**

Avance reportado: **36%**

## Lo que pasó en el periodo

- Se acordó con arquitectura cómo se revisan los requisitos no funcionales

## Presupuesto

| | COP |
|---|---|
| Aprobado | 18.000.000.000 |
| Comprometido | 9.237.228.817 |
| Ejecutado | 8.692.486.704 |
| Proyección al cierre | 17.313.900.425 |

## Riesgos abiertos

- Disponibilidad del equipo de seguridad para la revisión final
- Concentración del conocimiento en una sola persona
