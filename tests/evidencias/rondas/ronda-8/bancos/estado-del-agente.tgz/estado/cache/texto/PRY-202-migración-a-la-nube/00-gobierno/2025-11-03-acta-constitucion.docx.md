<!-- origen: PRY-202-migración-a-la-nube/00-gobierno/2025-11-03-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Migración a la nube

Código: PRY-202

Área dueña: Riesgo y Cumplimiento

Patrocinador: María Restrepo

Gerente de proyecto: Camilo Beltrán

Comité: Comité de Banca Empresas

Producto asociado: No aplica

Fecha de aprobación: 2025-11-03

Objetivo del negocio

Entregar migración a la nube para Riesgo y Cumplimiento.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

6.800.000.000 COP, aprobado por Comité de Banca Empresas el 2025-11-03.

Fechas comprometidas

Fecha

Inicio

2025-11-13

Cierre

2027-04-14

Criterio de éxito

Migración a la nube en producción y medido.

Dependencias declaradas

• Ninguna declarada
