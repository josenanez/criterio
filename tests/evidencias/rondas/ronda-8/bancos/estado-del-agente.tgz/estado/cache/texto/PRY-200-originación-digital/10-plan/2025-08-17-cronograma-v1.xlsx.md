<!-- origen: PRY-200-originación-digital/10-plan/2025-08-17-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-01-02 | 2026-01-02 | cerrado
Ambiente de pruebas certificado | 2026-05-10 | 2026-05-10 | cerrado
Integración con el core | 2026-09-15 | 2026-09-15 | cerrado
Piloto con usuarios internos | 2027-01-21 | 2027-01-21 | en curso
