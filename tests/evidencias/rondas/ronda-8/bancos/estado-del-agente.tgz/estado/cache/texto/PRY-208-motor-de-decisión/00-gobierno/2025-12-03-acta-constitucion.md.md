<!-- origen: PRY-208-motor-de-decisión/00-gobierno/2025-12-03-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Motor de decisión

**Código:** PRY-208
**Área dueña:** Banca Hipotecaria
**Patrocinador:** Natalia Ospina
**Gerente de proyecto:** Gustavo Neira
**Comité:** Comité de Arquitectura
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-12-03

## Objetivo del negocio

Entregar motor de decisión para Banca Hipotecaria.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**4.200.000.000 COP**, aprobado por Comité de Arquitectura el 2025-12-03.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-12-13 |
| Cierre | 2026-11-08 |

## Criterio de éxito

Motor de decisión en producción y medido.

## Dependencias declaradas

- Ninguna declarada
