<!-- origen: PRY-208-motor-de-decisión/10-plan/2025-12-03-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2026-02-17,2026-02-17,cerrado
Ambiente de pruebas certificado,2026-04-24,2026-04-24,cerrado
Integración con el core,2026-06-29,2026-06-29,cerrado
Piloto con usuarios internos,2026-09-03,2026-09-03,cerrado
Salida a producción,2026-11-08,2026-11-08,en curso
