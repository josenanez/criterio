<!-- origen: PRY-210-portal-de-proveedores/20-seguimiento/2026-10-17-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Portal de proveedores

**Código:** PRY-210
**Fecha de corte:** 2026-10-17
**Gerente:** Paula Céspedes

## Estado declarado

**Amarillo**

Avance reportado: **73%**

## Lo que pasó en el periodo

- Se ajustó el plan de pruebas con el área de seguridad
- El equipo perdió dos semanas por rotación de un desarrollador clave
- Se recibió la aprobación regulatoria pendiente desde el trimestre anterior

## Presupuesto

| | COP |
|---|---|
| Aprobado | 4.200.000.000 |
| Comprometido | 1.938.815.478 |
| Ejecutado | 2.270.104.627 |
| Proyección al cierre | 3.916.250.636 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
- Concentración del conocimiento en una sola persona
