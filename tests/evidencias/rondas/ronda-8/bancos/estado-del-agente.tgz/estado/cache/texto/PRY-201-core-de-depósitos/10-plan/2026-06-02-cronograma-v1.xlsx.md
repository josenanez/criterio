<!-- origen: PRY-201-core-de-depósitos/10-plan/2026-06-02-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-11-16 | 2026-11-16 | en curso
Ambiente de pruebas certificado | 2027-04-23 | 2027-04-23 | en curso
Integración con el core | 2027-09-28 | 2027-09-28 | en curso
