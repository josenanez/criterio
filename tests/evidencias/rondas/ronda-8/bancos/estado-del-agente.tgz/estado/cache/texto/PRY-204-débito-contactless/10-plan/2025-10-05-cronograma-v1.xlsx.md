<!-- origen: PRY-204-débito-contactless/10-plan/2025-10-05-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-01-30 | 2026-01-30 | cerrado
Ambiente de pruebas certificado | 2026-05-17 | 2026-05-17 | cerrado
Integración con el core | 2026-09-01 | 2026-09-01 | cerrado
Piloto con usuarios internos | 2026-12-17 | 2026-12-17 | en curso
