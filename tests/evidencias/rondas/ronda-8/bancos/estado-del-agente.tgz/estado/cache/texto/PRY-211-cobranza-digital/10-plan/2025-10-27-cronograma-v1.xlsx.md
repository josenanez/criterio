<!-- origen: PRY-211-cobranza-digital/10-plan/2025-10-27-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-03-22 | 2026-03-22 | cerrado
Ambiente de pruebas certificado | 2026-08-06 | 2026-08-06 | cerrado
Integración con el core | 2026-12-21 | 2026-12-21 | en curso
