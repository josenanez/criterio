<!-- origen: PRY-204-débito-contactless/00-gobierno/2025-10-05-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Débito contactless

Código: PRY-204

Área dueña: Banca Hipotecaria

Patrocinador: Rubén Cárdenas

Gerente de proyecto: Sandra Gil

Comité: Comité de Arquitectura

Producto asociado: tarjeta débito

Fecha de aprobación: 2025-10-05

Objetivo del negocio

Entregar débito contactless para Banca Hipotecaria.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

4.200.000.000 COP, aprobado por Comité de Arquitectura el 2025-10-05.

Fechas comprometidas

Fecha

Inicio

2025-10-15

Cierre

2026-12-17

Criterio de éxito

Débito contactless en producción y medido.

Dependencias declaradas

• Ninguna declarada
