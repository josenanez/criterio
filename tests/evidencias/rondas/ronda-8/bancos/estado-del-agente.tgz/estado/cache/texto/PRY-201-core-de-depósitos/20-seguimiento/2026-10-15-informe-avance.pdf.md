<!-- origen: PRY-201-core-de-depósitos/20-seguimiento/2026-10-15-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Core de depósitos
Código: PRY-201
Fecha de corte: 2026-10-15
Gerente: Laura Vélez

Estado declarado
Rojo
Avance reportado: 63%

Lo que pasó en el periodo
- Dos historias quedaron fuera del alcance del sprint por dependencia con el core
- Se ajustó el plan de pruebas con el área de seguridad
- Se levantó un hallazgo de seguridad en la revisión de arquitectura

Presupuesto
COP
Aprobado 4.200.000.000
Comprometido 2.421.427.933
Ejecutado 2.541.264.701
Proyección al cierre 4.266.620.617

Riesgos abiertos
- Disponibilidad del equipo de seguridad para la revisión final
