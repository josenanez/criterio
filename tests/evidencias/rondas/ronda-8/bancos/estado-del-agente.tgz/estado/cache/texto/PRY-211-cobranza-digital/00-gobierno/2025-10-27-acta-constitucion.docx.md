<!-- origen: PRY-211-cobranza-digital/00-gobierno/2025-10-27-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Cobranza digital

Código: PRY-211

Área dueña: Canales Digitales

Patrocinador: Laura Vélez

Gerente de proyecto: Mauricio Pérez

Comité: Comité de Medios de Pago

Producto asociado: recaudos

Fecha de aprobación: 2025-10-27

Objetivo del negocio

Entregar cobranza digital para Canales Digitales.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

800.000.000 COP, aprobado por Comité de Medios de Pago el 2025-10-27.

Fechas comprometidas

Fecha

Inicio

2025-11-06

Cierre

2026-12-21

Criterio de éxito

Cobranza digital en producción y medido.

Dependencias declaradas

• Ninguna declarada
