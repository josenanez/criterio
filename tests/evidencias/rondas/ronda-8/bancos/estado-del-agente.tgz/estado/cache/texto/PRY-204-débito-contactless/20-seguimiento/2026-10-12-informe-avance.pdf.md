<!-- origen: PRY-204-débito-contactless/20-seguimiento/2026-10-12-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Débito contactless
Código: PRY-204
Fecha de corte: 2026-10-12
Gerente: Sandra Gil

Estado declarado
Amarillo
Avance reportado: 58%

Lo que pasó en el periodo
- Se recibió la aprobación regulatoria pendiente desde el trimestre anterior
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales

Presupuesto
COP
Aprobado 4.200.000.000
Comprometido 2.022.765.950
Ejecutado 1.742.310.187
Proyección al cierre 4.158.574.285

Riesgos abiertos
- Concentración del conocimiento en una sola persona
- Dependencia del calendario de liberaciones del core
