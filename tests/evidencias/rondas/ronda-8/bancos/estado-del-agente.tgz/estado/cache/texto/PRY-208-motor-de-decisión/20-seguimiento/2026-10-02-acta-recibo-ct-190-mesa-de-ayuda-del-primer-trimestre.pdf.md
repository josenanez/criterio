<!-- origen: PRY-208-motor-de-decisión/20-seguimiento/2026-10-02-acta-recibo-ct-190-mesa-de-ayuda-del-primer-trimestre.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de recibo · Mesa de ayuda del primer trimestre
Proyecto: PRY-208 · Motor de decisión
Fecha de recibo: 2026-10-02
Recibido por: Gustavo Neira
Se recibe a satisfacción el entregable Mesa de ayuda del primer trimestre.
Contrato CT-190 · Redes del Norte Ltda..
