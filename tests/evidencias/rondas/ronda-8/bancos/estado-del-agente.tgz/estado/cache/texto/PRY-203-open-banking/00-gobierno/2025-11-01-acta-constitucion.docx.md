<!-- origen: PRY-203-open-banking/00-gobierno/2025-11-01-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Open Banking

Código: PRY-203

Área dueña: Medios de Pago

Patrocinador: Natalia Ospina

Gerente de proyecto: María Restrepo

Comité: Comité de Transformación Digital

Producto asociado: APIs de datos

Fecha de aprobación: 2025-11-01

Objetivo del negocio

Entregar open banking para Medios de Pago.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

6.800.000.000 COP, aprobado por Comité de Transformación Digital el 2025-11-01.

Fechas comprometidas

Fecha

Inicio

2025-11-11

Cierre

2026-10-29

Criterio de éxito

Open Banking en producción y medido.

Dependencias declaradas

• Ninguna declarada
