<!-- origen: PRY-208-motor-de-decisión/30-reuniones/2026-10-13-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Arquitectura · Motor de decisión

Fecha: 2026-10-13

Asistentes: Gustavo Neira, Natalia Ospina

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

María Restrepo

Entregar el punto 24

2026-10-23

María Restrepo

Entregar el punto 4

2026-10-25
