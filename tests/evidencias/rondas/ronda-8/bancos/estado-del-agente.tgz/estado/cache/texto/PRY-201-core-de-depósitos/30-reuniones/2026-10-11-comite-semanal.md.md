<!-- origen: PRY-201-core-de-depósitos/30-reuniones/2026-10-11-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Arquitectura · Core de depósitos

**Fecha:** 2026-10-11
**Asistentes:** Laura Vélez, Carlos Peña

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Camilo Beltrán | Entregar el punto 23 | 2026-11-06 |
| Elena Duarte | Entregar el punto 39 | 2026-09-28 |
