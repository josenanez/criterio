*Informe construido desde la ficha PRY-200 (actualizada el 2026-10-17); cifras recalculadas por `compute` con fecha de corte 2026-10-17.*

## PRY-200 · Originación digital — estado al 2026-10-17

**Declara el gerente (Jorge Medina):** verde · 29% · al 2026-09-24 (23 días; la declaración no está vencida: el umbral es 30)
**Sustento documental:** sin sustento. Las tres fuentes de la ficha son el acta, el cronograma v1 y el propio informe de avance; ninguna es evidencia independiente (evidencia: 0, declaración: 2, sin marcar: 15).
**Lo que el semáforo no explica:** `milestone_met_without_evidence`, `progress_vs_plan`, `silent`
**Último documento:** 2026-09-24 (23 días de silencio; umbral 15) · **Última reunión:** sin dato — la ficha no registra ninguna reunión ni acta de reunión.

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2027-01-21 | 2027-01-21 | 0 días (0 vs. original, 0 vs. vigente) |
| Presupuesto aprobado | COP 6.800.000.000 | COP 6.800.000.000 | Proyección COP 6.809.407.406 (+0,1% sobre lo aprobado) |

Presupuesto: comprometido COP 4.954.995.254 (72,9%), ejecutado COP 3.520.982.115 (51,8%), disponible real COP 1.845.004.746. La ficha no trae una línea base de costo separada de lo aprobado.

Replanificaciones: 0 — no hay fechas ni motivos que citar. La línea base v1 (2025-08-17) es la única.

### Hitos
| Hito | Base | Vigente | Estado | Evidencia |
|---|---|---|---|---|
| Diseño funcional aprobado | 2026-01-02 | 2026-01-02 | cumplido (declarado) | ninguna — 288 días |
| Ambiente de pruebas certificado | 2026-05-10 | 2026-05-10 | cumplido (declarado) | ninguna — 160 días |
| Integración con el core | 2026-09-15 | 2026-09-15 | cumplido (declarado) | ninguna — 32 días |
| Piloto con usuarios internos | 2027-01-21 | 2027-01-21 | pendiente | — |

### Dónde no coincide
- **Avance:** el gerente declara 29% (informe de avance, 2026-09-24). Con 3 de 4 hitos marcados como cumplidos, el plan sustenta entre 75% y 100%: una diferencia de 46,0 puntos. El número declarado está muy por debajo de lo que dicen los hitos; una de las dos cifras está mal y los documentos no permiten saber cuál.
- **Verde frente a la evidencia:** se declara verde (informe de avance, 2026-09-24) y hay tres señales abiertas que ese verde no explica (hitos cumplidos sin evidencia, avance contra plan, silencio). Es la alerta `declared_vs_evidence`.
- **Hitos:** los tres figuran como cumplidos en el cronograma v1 (2025-08-17), un documento anterior a las fechas de cumplimiento; no hay acta de aceptación, certificado ni otro soporte.

### Abierto
**Riesgos e incidencias sin movimiento:**
- Riesgo: concentración del conocimiento en una sola persona — sin responsable identificado, sin probabilidad, impacto ni fecha; sin movimiento registrado (fuente: informe de avance, 2026-09-24).
- Incidencia: hallazgo de seguridad levantado en la revisión de arquitectura — abierta desde 2026-09-24 (23 días), sin responsable identificado.

**Compromisos vencidos:** ninguno registrado — pero la ficha no tiene compromisos de ninguna reunión, así que es ausencia de dato, no cumplimiento.
**Dependencias sin confirmar:** ninguna registrada.
**Proveedores:** ninguno en la ficha.

### Sin dato
- Autoridad del proyecto (`identity.authority`) y fase (`identity.phase`).
- Reuniones y compromisos: ninguno en la ficha.
- Evidencia de cumplimiento de los tres hitos declarados como cumplidos.
- Campos de identidad y plan con 14 meses de antigüedad (acta y cronograma, 2025-08-17): código, nombre, área, producto, patrocinador, comité, inicio, fin, alcance y exclusiones. Superan el umbral de 12 meses.
- Nota de consistencia: el acta coloca el proyecto en Banca Empresas y el producto es «crédito de consumo»; no verifiqué si es coherente.

### Siguiente paso
El silencio, el hallazgo de seguridad sin dueño y la diferencia de 46 puntos en el avance justifican llevar el proyecto al comité del 2026-10-20 (`/steering-pack`). Solo ofrezco el punto de comité: no hay desviación de fechas ni de costo por encima del umbral, así que no corresponde una solicitud de cambio.

---
criterio-portfolio 0.3.13 · ficha PRY-200 aplicada, actualizada el 2026-10-17 · campos inciertos: autoridad, fase, última reunión, evidencia de hitos · Términos (v1.1) y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.13
