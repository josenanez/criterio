# Corrida del 2026-10-17 · portfolio-report

13 proyectos · 78 documentos, 0 releídos y 78 sin cambio · 32 s · 60 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 7 |
| `vendor_deliverable_late` | 5 |
| `declared_vs_evidence` | 4 |
| `commitment_undated` | 3 |
| `vendor_accepted_without_evidence` | 3 |
| `variance_cost` | 3 |
| `commitment_rescheduled` | 2 |
| `silent` | 1 |
| `variance_time` | 1 |
| `rebaseline_unauthorized` | 1 |
| `budget_committed` | 1 |
| `change_without_baseline` | 1 |

El informe quedó en `/home/claude/banco/ronda-8/bancos/espacio/reportes`.

4 verdes contradichos (PRY-200, 203, 209, 211); 20 hitos sin evidencia; autoridad vacía en los 13

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

# Portafolio — 2026-10-17
13 proyectos · 11 con hallazgos (60 señales) · 9 productos · último barrido 2026-10-17

**Fichas cargadas:** las 13 de `estado/records/` (PRY-199 a PRY-211), barrido del 2026-10-17; ninguna con más de una semana. (La carpeta `estado/fichas/` no existe; las fichas están en `estado/records/`.)
**Términos:** v1.1, aceptados por José Francisco Ñáñez el 2026-10-17 (vigentes, sin nuevo registro).

## Qué cambió desde la corrida anterior
Sin cambios desde la corrida anterior. La instantánea previa es del mismo día (2026-10-17): el diff da 0 cambios, así que esto es el punto de partida y no hay delta real.

## Contradicciones abiertas
Vacía: `compute` no reporta campos en conflicto entre dos fuentes (0 problemas de ficha).

## Hitos vencidos sin evidencia (declarados cumplidos, sin documento)
| Proyecto | Hito | Fecha | Días |
|---|---|---|---|
| PRY-210 Portal de proveedores | Diseño funcional aprobado | 2025-07-13 | 461 |
| PRY-210 | Ambiente de pruebas certificado | 2025-08-25 | 418 |
| PRY-210 | Integración con el core | 2025-10-08 | 374 |
| PRY-210 | Piloto con usuarios internos | 2025-11-20 | 331 |
| PRY-205 Prevención de lavado de activos | Diseño funcional aprobado | 2025-09-28 | 384 |
| PRY-205 | Integración con el core | 2026-03-22 | 209 |
| PRY-205 | Piloto con usuarios internos | 2026-06-17 | 122 |
| PRY-200 Originación digital | Diseño funcional aprobado | 2026-01-02 | 288 |
| PRY-200 | Ambiente de pruebas certificado | 2026-05-10 | 160 |
| PRY-200 | Integración con el core | 2026-09-15 | 32 |
| PRY-204 Débito contactless | Diseño funcional aprobado | 2026-01-30 | 260 |
| PRY-204 | Integración con el core | 2026-09-01 | 46 |
| PRY-202 Migración a la nube | Diseño funcional aprobado | 2026-02-24 | 235 |
| PRY-202 | Integración con el core | 2026-09-19 | 28 |
| PRY-211 Cobranza digital | Diseño funcional aprobado | 2026-03-22 | 209 |
| PRY-211 | Ambiente de pruebas certificado | 2026-08-06 | 72 |
| PRY-203 Open Banking | Ambiente de pruebas certificado | 2026-05-06 | 164 |
| PRY-203 | Integración con el core | 2026-08-02 | 76 |
| PRY-208 Motor de decisión | Integración con el core | 2026-06-29 | 110 |
| PRY-208 | Piloto con usuarios internos | 2026-09-03 | 44 |

## Proyectos en silencio (umbral 15 días)
| Proyecto | Días | Último documento |
|---|---|---|
| PRY-200 Originación digital | 23 | 2026-09-24 (informe de avance, PDF) |

## Dependencias en riesgo
Vacía: el cálculo no detecta dependencias rotas entre proyectos.

## Sin sustento (verde declarado contra la evidencia) — 4 verdes contradichos
| Proyecto | Declara | Qué lo respalda |
|---|---|---|
| PRY-200 | Verde (2026-09-24) | Contradicho: silencio de 23 días, avance 29% frente a 75–100% que sostiene el plan, 3 hitos sin evidencia |
| PRY-203 | Verde (2026-10-17) | Contradicho: sobrecosto proyectado 19,1%, 90,4% comprometido, avance 39% frente a 75–100%, 2 hitos sin evidencia, compromiso vencido |
| PRY-209 | Verde (2026-10-17) | Contradicho: sobrecosto proyectado 10,0% (COP 2.640 M sobre 2.400 M aprobados) |
| PRY-211 | Verde (2026-09-27) | Contradicho: 2 hitos declarados cumplidos sin evidencia |

## Vacíos de información
| Proyecto | Qué falta |
|---|---|
| Los 13 | Autoridad que aprueba el proyecto (no figura en ninguna ficha) |
| PRY-202, PRY-205, PRY-208, PRY-210 | Producto asociado |
| PRY-202 Migración a la nube | 3 compromisos sin fecha (Salas, Molina, Vélez); 2 reprogramados 5–6 veces (Vélez, Restrepo) |
| PRY-202 | Corrimiento de 76 días (14,7%) contra la línea base original sin cambio autorizado |
| PRY-206 Billetera y QR | Cambio CC-01 hace 97 días sin línea base nueva |
| PRY-201 Core de depósitos | Avance declarado 63% con 0 de 3 hitos cumplidos; compromiso de E. Duarte vencido hace 19 días |
| Proveedores | Entregables vencidos y pendientes: PRY-202 (Datacore, 196 y 149 días), PRY-208 (Redes del Norte, 91 días), PRY-210 (Talento Digital, 457 y 313 días). "Bolsa de horas" aceptada sin evidencia en PRY-202, PRY-208 y PRY-210 |

## Estado general
| Proyecto | Declarado | Sustento | Desviación vs original | Sobrecosto proyectado | Hallazgos |
|---|---|---|---|---|---|
| PRY-199 Renovación de cajeros | — | Sustentado | 0 d | 0% | 0 |
| PRY-200 Originación digital | Verde | No | — | — | 6 |
| PRY-201 Core de depósitos | — | Parcial | — | — | 2 |
| PRY-202 Migración a la nube | — | No | +76 d (14,7%) | — | 17 |
| PRY-203 Open Banking | Verde | No | — | +19,1% | 7 |
| PRY-204 Débito contactless | — | No | — | — | 3 |
| PRY-205 Prevención de lavado de activos | — | No | — | — | 4 |
| PRY-206 Billetera y QR | — | Parcial | cambio sin línea base | — | 1 |
| PRY-207 Onboarding PyME | — | Sustentado | — | — | 0 |
| PRY-208 Motor de decisión | — | No | — | +26,9% | 6 |
| PRY-209 Nómina electrónica | Verde | No | — | +10,0% | 2 |
| PRY-210 Portal de proveedores | — | No | — | — | 8 |
| PRY-211 Cobranza digital | Verde | No | — | — | 3 |

## Necesito que confirmes
Ninguna pregunta este mes: es la primera corrida y no hay campos viejos que confirmar (umbral de antigüedad: 12 meses).

---
**Informe HTML:** 26 páginas en `reportes/` — `index.html` (por campo, con la cadena de evidencia, para quien va a actuar) y `decisiones.html` (por decisión, para el patrocinador), más una página por proyecto. Se imprime a PDF desde el navegador.
**Pie:** criterio-portfolio 0.3.13 · fichas aplicadas: 13, barrido 2026-10-17 · campos inciertos: ninguno marcado como ambiguo; autoridad vacía en los 13 · términos v1.1: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.13
