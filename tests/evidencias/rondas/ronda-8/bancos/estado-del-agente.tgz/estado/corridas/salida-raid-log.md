## RAID — Portafolio (13 proyectos, PRY-199 a PRY-211) al 2026-10-17

**De qué documentos sale:** las fichas de `estado/records` (sección RAID de los 13 proyectos, cada ítem con su fuente), los informes de avance, las 15 minutas y notas de reunión (en su texto convertido, `estado/cache/texto`), las 13 actas de constitución (sección «Dependencias declaradas») y, para PRY-202, la solicitud de cambio CC-01 y el cronograma v2. No abrí los originales PDF/DOCX/XLSX, solo su texto convertido. No leí contratos, facturas ni actas de recibo buscando riesgos.

**Escala:** ningún documento trae probabilidad ni impacto. No inventé una escala: la columna dice «no informado».

**Ids:** los documentos no traen ids de RAID. Los Id de abajo (`199-R1`, etc.) los puse yo, solo para poder referirme a cada ítem.

**32 ítems en total, ya clasificados:** 8 riesgos · 0 supuestos · 14 incidencias · 10 dependencias
**32 sin doliente · 32 sin fecha · 1 no registrado formalmente · «sin movimiento»: no se puede medir** (cada ítem aparece en un solo informe y no hay historial de movimiento; no afirmo ni niego estancamiento)

Hallazgo de fondo: no hay ni un doliente ni una fecha de resolución en todo el portafolio. Ningún riesgo tiene probabilidad ni impacto. Ningún supuesto está levantado. Las 13 actas dicen «Ninguna declarada» en dependencias, aunque los informes reportan 10 dependencias reales.

### Necesitan decisión ahora
Cada fila cumple al menos un criterio de escalamiento: afecta a otros proyectos, o su doliente está fuera del proyecto y nadie lo ha asignado.

| Id | Tipo | Qué | Doliente | Desde | Por qué sube |
|---|---|---|---|---|---|
| 204-D1, 209-D1, 211-D1 (+ incidencias 201-I1, 203-I1, 208-I1) | Dependencia | Calendario de liberaciones del core. Además, 3 proyectos (201, 203, 208) reportan «dos historias fuera del sprint por dependencia con el core». | no identificado | 2026-09-27 (211), 2026-10-12 (204), 2026-10-17 (209) | Afecta a 6 proyectos. Los informes dicen «el core» sin código de proyecto. No puedo afirmar que sea PRY-201; hay que confirmarlo. Decisión: nombrar un doliente del calendario del core y registrar la dependencia con su código. |
| 199-D1, 201-D1, 206-D1, 208-D1 (+ incidencias 199-I1, 200-I1, 201-I2, 207-I2, 208-I2) | Dependencia / Incidencia | «Disponibilidad del equipo de seguridad para la revisión final» (4 proyectos) y «hallazgo de seguridad en la revisión de arquitectura» (5 proyectos, con redacción idéntica en los 5). | no identificado | 2026-09-23 a 2026-10-17 | Un mismo recurso ajeno a los proyectos (se asume que el equipo de seguridad es ajeno; los informes no lo dicen) sostiene 4 revisiones finales y hay 5 hallazgos abiertos. Decisión: capacidad y orden de atención del equipo de seguridad. Verificar si los 5 hallazgos son realmente distintos: la redacción idéntica puede ser plantilla. |
| 202-D1, 202-R1 | Dependencia / Riesgo | PRY-202: el proveedor no ha confirmado la fecha de la última entrega (informe 2026-10-17) y «podría no llegar con el equipo completo para la siguiente fase» (notas 2026-10-17). | no identificado | 2026-10-17 | Proyecto en rojo. El cronograma v2 ya movió la salida a producción de 2027-04-14 a 2027-06-29 (+76 días), igual al impacto de CC-01. CC-01 sigue «pendiente de presentación al comité» y la v2 figura como aprobada el 2026-10-17 sin motivo documentado. Decisión: presentar CC-01 al comité y exigirle al proveedor una fecha escrita. |
| 205-R1, 208-R2 | Riesgo | Cambio regulatorio en discusión que puede mover el alcance (PRY-205 y PRY-208). | no identificado | 2026-10-16 (205), 2026-10-17 (208) | Doliente fuera de los proyectos y sin asignar, en dos proyectos en rojo. Decisión: quién sigue el cambio regulatorio y cuándo se evalúa su efecto en el alcance. |

### Detectados en reuniones, no registrados
Revisé las 15 minutas y notas. Solo una trae un riesgo dicho al pasar.

| Qué | Tipo | Dicho en | Fecha |
|---|---|---|---|
| «El proveedor podría no llegar con el equipo completo para la siguiente fase; nadie lo anotó como riesgo». **No registrado formalmente.** El gerente decide si lo formaliza. | Riesgo | `PRY-202-migración-a-la-nube/2026-10-17-notas-reunion.txt` | 2026-10-17 |

Las demás minutas (PRY-199, 201, 203, 204, 205, 208, 210, 211 y los comités de PRY-202) solo traen compromisos. No encontré en ellas riesgos, supuestos ni dependencias, y no los inventé. Otros proyectos no tienen minutas en la carpeta (200, 206, 207, 209), así que de ellos no puedo decir qué se habló.

### Sin doliente o sin fecha
Los 32 ítems carecen de doliente y de fecha de resolución. No relleno ninguno. Se agrupan así:

| Id | Tipo | Qué | Qué falta |
|---|---|---|---|
| 199-D1, 199-I1 | Dep./Incid. | Equipo de seguridad; hallazgo de seguridad | Doliente, fecha |
| 200-R1, 200-I1 | Riesgo/Incid. | Concentración de conocimiento; hallazgo de seguridad | Doliente, fecha, valoración |
| 201-D1, 201-I1, 201-I2 | Dep./Incid. | Equipo de seguridad; 2 historias fuera del sprint; hallazgo de seguridad | Doliente, fecha |
| 202-D1, 202-R1, 202-I1, 202-I2 | Dep./Riesgo/Incid. | Fecha del proveedor; equipo del proveedor; rotación de desarrollador; prueba de carga | Doliente, fecha |
| 203-D1, 203-I1 | Dep./Incid. | Fecha del proveedor; 2 historias fuera del sprint | Doliente, fecha |
| 204-R1, 204-D1 | Riesgo/Dep. | Concentración de conocimiento; calendario del core | Doliente, fecha, valoración |
| 205-R1 | Riesgo | Cambio regulatorio | Doliente, fecha, valoración |
| 206-D1, 206-R1 | Dep./Riesgo | Equipo de seguridad; concentración de conocimiento | Doliente, fecha, valoración |
| 207-R1, 207-I1, 207-I2 | Riesgo/Incid. | Concentración; reprogramación por ventana de cambio; hallazgo de seguridad | Doliente, fecha, valoración |
| 208-D1, 208-R2, 208-I1, 208-I2 | Dep./Riesgo/Incid. | Equipo de seguridad; cambio regulatorio; 2 historias fuera del sprint; hallazgo de seguridad | Doliente, fecha |
| 209-D1, 209-I1 | Dep./Incid. | Calendario del core; prueba de carga | Doliente, fecha |
| 210-D1, 210-R1, 210-I1 | Dep./Riesgo/Incid. | Fecha del proveedor; concentración; rotación | Doliente, fecha, valoración |
| 211-D1, 211-I1 | Dep./Incid. | Calendario del core; rotación | Doliente, fecha |

Reclasificados porque la prueba rápida («si depende de alguien fuera del proyecto, es dependencia») los saca de riesgo:
- «Dependencia del calendario de liberaciones del core» (204, 209, 211): los informes lo listan como riesgo y es una dependencia.
- «El proveedor no ha confirmado la fecha de la última entrega» (202, 203, 210): es una dependencia con un tercero, no un riesgo.
- «Disponibilidad del equipo de seguridad para la revisión final» (199, 201, 206, 208): dependencia de un equipo ajeno. Es mi lectura; los informes no dicen de quién es el equipo.

### Dependencias en riesgo
Ninguna dependencia lleva el código del proyecto del que depende, así que el cruce con fechas de otros proyectos solo se puede hacer parcialmente. Todas están **declaradas, no acordadas**: ninguna tiene confirmación de la contraparte.

| Id | Depende de | Confirmada | Qué pasó |
|---|---|---|---|
| 204-D1, 209-D1, 211-D1 | «el core», sin código | No | Si el core es PRY-201, sus 3 hitos siguen en su fecha original (2026-11-16, 2027-04-23, 2027-09-28), sin movimiento. Esa relación no está documentada y no la doy por hecha. |
| 202-D1, 203-D1, 210-D1 | Proveedor (contrato), sin código de proyecto | No | Fecha de la última entrega sin confirmar. En PRY-202 el cronograma ya se movió 76 días. |
| 199-D1, 201-D1, 206-D1, 208-D1 | Equipo de seguridad, sin código | No | Sin fecha de revisión comprometida en ningún informe. |

### Frescura del dato
Con el umbral de 15 días de silencio, los informes de PRY-206 (2026-09-23, 24 días), PRY-200 (2026-09-24, 23 días) y PRY-211 (2026-09-27, 20 días) están vencidos. Su RAID puede haber cambiado sin que yo lo vea.

### Registro completo
Prob. e Impacto: «no informado» en los 32 ítems. Doliente: «no identificado» en los 32. Fecha: «—» en los 32. Último movimiento: solo se conoce la fecha del informe donde aparece cada ítem.

| Id | Tipo | Qué | Prob. | Impacto | Doliente | Fecha | Último movimiento |
|---|---|---|---|---|---|---|---|
| 199-D1 | Dependencia | Disponibilidad del equipo de seguridad para la revisión final | n/i | n/i | n/i | — | visto 2026-10-15 |
| 199-I1 | Incidencia | Hallazgo de seguridad en la revisión de arquitectura | — | — | n/i | — | desde 2026-10-15 |
| 200-R1 | Riesgo | Concentración del conocimiento en una sola persona | n/i | n/i | n/i | — | visto 2026-09-24 |
| 200-I1 | Incidencia | Hallazgo de seguridad en la revisión de arquitectura | — | — | n/i | — | desde 2026-09-24 |
| 201-D1 | Dependencia | Disponibilidad del equipo de seguridad | n/i | n/i | n/i | — | visto 2026-10-15 |
| 201-I1 | Incidencia | Dos historias fuera del sprint por dependencia con el core | — | — | n/i | — | desde 2026-10-15 |
| 201-I2 | Incidencia | Hallazgo de seguridad en la revisión de arquitectura | — | — | n/i | — | desde 2026-10-15 |
| 202-D1 | Dependencia | El proveedor no ha confirmado la fecha de la última entrega | n/i | n/i | n/i | — | visto 2026-10-17 |
| 202-R1 | Riesgo (no registrado formalmente) | El proveedor podría no llegar con el equipo completo para la siguiente fase | n/i | n/i | n/i | — | dicho 2026-10-17 |
| 202-I1 | Incidencia | Dos semanas perdidas por rotación de un desarrollador clave | — | — | n/i | — | informe 2026-10-17 |
| 202-I2 | Incidencia | La prueba de carga no alcanzó el umbral y se repite | — | — | n/i | — | informe 2026-10-17 |
| 203-D1 | Dependencia | El proveedor no ha confirmado la fecha de la última entrega | n/i | n/i | n/i | — | visto 2026-10-17 |
| 203-I1 | Incidencia | Dos historias fuera del sprint por dependencia con el core | — | — | n/i | — | desde 2026-10-17 |
| 204-R1 | Riesgo | Concentración del conocimiento en una sola persona | n/i | n/i | n/i | — | visto 2026-10-12 |
| 204-D1 | Dependencia | Calendario de liberaciones del core | n/i | n/i | n/i | — | visto 2026-10-12 |
| 205-R1 | Riesgo | Cambio regulatorio en discusión que puede mover el alcance | n/i | n/i | n/i | — | visto 2026-10-16 |
| 206-D1 | Dependencia | Disponibilidad del equipo de seguridad | n/i | n/i | n/i | — | visto 2026-09-23 |
| 206-R1 | Riesgo | Concentración del conocimiento en una sola persona | n/i | n/i | n/i | — | visto 2026-09-23 |
| 207-R1 | Riesgo | Concentración del conocimiento en una sola persona | n/i | n/i | n/i | — | visto 2026-10-07 |
| 207-I1 | Incidencia | Salida reprogramada por ventana de cambio de operaciones | — | — | n/i | — | desde 2026-10-07 |
| 207-I2 | Incidencia | Hallazgo de seguridad en la revisión de arquitectura | — | — | n/i | — | desde 2026-10-07 |
| 208-D1 | Dependencia | Disponibilidad del equipo de seguridad | n/i | n/i | n/i | — | visto 2026-10-17 |
| 208-R2 | Riesgo | Cambio regulatorio en discusión que puede mover el alcance | n/i | n/i | n/i | — | visto 2026-10-17 |
| 208-I1 | Incidencia | Dos historias fuera del sprint por dependencia con el core | — | — | n/i | — | desde 2026-10-17 |
| 208-I2 | Incidencia | Hallazgo de seguridad en la revisión de arquitectura | — | — | n/i | — | desde 2026-10-17 |
| 209-D1 | Dependencia | Calendario de liberaciones del core | n/i | n/i | n/i | — | visto 2026-10-17 |
| 209-I1 | Incidencia | La prueba de carga no alcanzó el umbral y se repite | — | — | n/i | — | desde 2026-10-17 |
| 210-D1 | Dependencia | El proveedor no ha confirmado la fecha de la última entrega | n/i | n/i | n/i | — | visto 2026-10-17 |
| 210-R1 | Riesgo | Concentración del conocimiento en una sola persona | n/i | n/i | n/i | — | visto 2026-10-17 |
| 210-I1 | Incidencia | Dos semanas perdidas por rotación de un desarrollador clave | — | — | n/i | — | desde 2026-10-17 |
| 211-D1 | Dependencia | Calendario de liberaciones del core | n/i | n/i | n/i | — | visto 2026-09-27 |
| 211-I1 | Incidencia | Dos semanas perdidas por rotación de un desarrollador clave | — | — | n/i | — | desde 2026-09-27 |

(n/i = no informado en los documentos.)

### Después
- **Subir a comité (martes 2026-10-20)**, con la decisión formulada: las cuatro filas de «Necesitan decisión ahora».
- **Proponer doliente, sin asignar:** los gerentes de proyecto de cada informe para los ítems propios. El calendario del core, el equipo de seguridad y el seguimiento regulatorio no tienen un candidato claro en los documentos. Lo decide el comité.
- **Formalizar o descartar** el riesgo no registrado de PRY-202.

### Pie de rigor
- **Lo que no sé:** si «el core» es PRY-201; de quién es el equipo de seguridad; si el movimiento de los ítems es real, porque no hay historial; probabilidad e impacto de todo. No hay supuestos porque nadie los levantó, no porque no existan.
- **Lo que no miré:** PRY-200, 206, 207 y 209 no tienen minutas, así que sus reuniones están en silencio. No abrí los originales, solo su texto convertido. Los ítems salen de la sección «Riesgos abiertos» y «Lo que pasó» de cada informe, tal como los extrajo la ficha, y no los reverifiqué uno a uno contra el original.
- **Verificación:** cada ítem trae la fuente en su ficha (`estado/records/PRY-xxx.json`). La verificación contra el documento es de quien lea este registro.
