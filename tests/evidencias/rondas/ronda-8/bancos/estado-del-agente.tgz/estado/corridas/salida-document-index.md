## Carpeta al 2026-10-17

**Documentos:** 78 · **Sin cambio:** 78 · **Hay que releer:** 0

### Cambió el contenido
Ninguno.

### Solo se reguardó
Ninguno. 0 documentos.

### Renombrado o movido
Ninguno.

### Ya no está
Ninguno.

### Citas que dejaron de resolver
Las 18 son de PRY-202 (migración a la nube); el índice las marca como fuente no encontrada:

| Proyecto | Campo | Documento citado |
|---|---|---|
| PRY-202 | identity.code | 00-gobierno/2025-11-03-acta-constitucion.docx |
| PRY-202 | identity.name | 00-gobierno/2025-11-03-acta-constitucion.docx |
| PRY-202 | identity.business_area | 00-gobierno/2025-11-03-acta-constitucion.docx |
| PRY-202 | identity.product | 00-gobierno/2025-11-03-acta-constitucion.docx |
| PRY-202 | identity.sponsor | 00-gobierno/2025-11-03-acta-constitucion.docx |
| PRY-202 | identity.manager | 20-seguimiento/2026-10-17-informe-avance.md |
| PRY-202 | identity.committee | 00-gobierno/2025-11-03-acta-constitucion.docx |
| PRY-202 | declared.status | 20-seguimiento/2026-10-17-informe-avance.md |
| PRY-202 | declared.progress_pct | 20-seguimiento/2026-10-17-informe-avance.md |
| PRY-202 | plan.start_date | 00-gobierno/2025-11-03-acta-constitucion.docx |
| PRY-202 | plan.end_date | 10-plan/2026-10-17-cronograma-v2.csv |
| PRY-202 | plan.scope_summary | 00-gobierno/2025-11-03-acta-constitucion.docx |
| PRY-202 | plan.exclusions | 00-gobierno/2025-11-03-acta-constitucion.docx |
| PRY-202 | money.approved | 20-seguimiento/2026-10-17-informe-avance.md |
| PRY-202 | money.committed | 20-seguimiento/2026-10-17-informe-avance.md |
| PRY-202 | money.executed | 20-seguimiento/2026-10-17-informe-avance.md |
| PRY-202 | money.projection | 20-seguimiento/2026-10-17-informe-avance.md |
| PRY-202 | vendors[0].invoiced | 20-seguimiento/2026-08-30-factura-ct-267.pdf |

Dato a verificar: esos archivos sí están en la carpeta de PRY-202, y el índice no los reporta como borrados ni renombrados. Es decir, la cita no resuelve aunque el documento existe; no sé la causa (¿ruta relativa distinta a la que usa el índice, o ficha escrita antes de que llegaran los archivos?). No lo di por explicado.

### Formatos que no se pudieron leer
El índice no reporta ninguno.

### Siguiente paso
No hay documentos por releer, así que no hace falta `/portfolio-scan`. Lo único pendiente es revisar las citas de PRY-202.
