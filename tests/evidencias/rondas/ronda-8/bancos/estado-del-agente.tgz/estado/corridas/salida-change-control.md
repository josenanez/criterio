Sale de la ficha `estado/records/PRY-208.json` (corte 2026-10-17) y del cálculo `portafolio.py impact` y `compute`. Términos vigentes: v1.1, aceptados por José Francisco Ñáñez el 2026-10-17.

## Solicitud de cambio — PRY-208 Motor de decisión — 2026-10-17

**Qué se pide:** mover 30 días la salida a producción (hito «Salida a producción»): de 2026-11-08 a 2026-12-08.
**Quién lo pide:** no consta en ningún documento de la carpeta. Se recibió como instrucción de la sesión, sin solicitante nombrado.
**Por qué:** no consta. El informe de avance del 2026-10-17 trae dos hechos que podrían explicarlo, pero ningún documento los une a esta petición: dos historias fuera del sprint por dependencia con el core, y un hallazgo de seguridad en la revisión de arquitectura. No lo doy por motivo.

### Línea base de partida
Una sola línea base: v1, aprobada el 2025-12-03 («aprobación inicial del acta de constitución»), cierre 2026-11-08, 4.200.000.000 COP. Cero replanificaciones, cero cambios registrados (`changes.total` = 0). Fuente: cronograma-v1.csv y acta de constitución.

### Impacto
| Dimensión | Hoy | Con el cambio | Diferencia |
|---|---|---|---|
| Alcance | Componentes 1, 2 y 3 | Sin dato: la petición no toca alcance | No declarada |
| Tiempo | Cierre 2026-11-08 | Cierre 2026-12-08 | +30 días (+22 días hasta el hito hoy; pasa a 52) |
| Costo | Aprobado 4.200.000.000; proyección 5.331.567.805 (+26,9 %) | Sin dato | No declarada |

**Quién absorbe lo que no se declaró.**
- **Costo:** ningún documento dice cuánto cuesta un mes más (equipo, proveedor, licencias). La proyección actual ya supera el aprobado en 1.131.567.805 COP y no incluye este corrimiento que yo pueda verificar. Si el equipo se queda 30 días más sin presupuesto adicional, lo absorbe la proyección, que ya está en rojo. No calculo un monto: sería inventarlo.
- **Alcance:** si el corrimiento viene del cambio regulatorio «que puede mover el alcance» (riesgo abierto sin dueño), alcance y fecha se mueven juntos y esta solicitud solo declara la fecha.
- **Proveedor:** el contrato CT-190 no trae cláusula de prórroga ni de vigencia en lo que se leyó. No sé qué pasa con el proveedor si la salida se mueve. Queda como pregunta.

### Efecto en el portafolio
| Proyecto afectado | Cómo | Gerente |
|---|---|---|
| Ninguno calculado | `impact` devolvió 0 proyectos alcanzados (0 directos, 0 indirectos, 0 que no puedan sostener fecha, 0 dependencias sin confirmar) | — |

**Hito por el que pasa el cambio:** «Salida a producción», 2026-11-08, a 22 días.

**Esto no es «sin efecto»: es «sin dependencias declaradas».** El acta dice «Ninguna declarada» y la ficha tiene `dependencies` vacío. Pero el informe de avance habla de una «dependencia con el core» que no está registrada como dependencia en ningún sitio. Si esa dependencia existe, el cálculo no la ve, y algún proyecto del portafolio podría estar afectado sin saberlo. Antes de decir que no pasa nada en otros proyectos, hay que confirmar con Gustavo Neira de qué proyecto o sistema depende y registrarla. Tampoco sé cuántos días se mueve cada actividad: la ficha no tiene holgura.

### Quién decide
**Autoridad requerida:** no declarada. `identity.authority` = not_found; el acta no fija umbrales de tiempo ni de costo para aprobar cambios.
**Según:** acta de constitución 2025-12-03. Solo dice que el Comité de Arquitectura aprobó el presupuesto.
**Va a comité:** sí, por defecto. Con la autoridad sin declarar y un corrimiento de 30 días sobre un proyecto en rojo, lo prudente es que lo vea el Comité de Arquitectura (patrocinadora: Natalia Ospina; gerente: Gustavo Neira). Próximo comité de la configuración: 2026-10-20. Es una recomendación mía, no una regla del acta.

**Hallazgo de fondo:** no hay autoridad declarada. Quien apruebe este cambio lo hace sin un documento que diga que puede.

### Si no se aprueba
El proyecto sigue con cierre 2026-11-08, declarado en rojo, con 57 % de avance declarado frente a 80–100 % que sostiene el plan (4 de 5 hitos «cumplidos»), y a 22 días de la fecha. Dos de esos hitos cumplidos no tienen evidencia (Integración con el core, 2026-06-29; Piloto con usuarios internos, 2026-09-03). El entregable del proveedor «Parametrización del tarifario» lleva 91 días vencido (2026-07-18) y sigue pendiente. Con ese cuadro, no hay evidencia en la carpeta de que la fecha actual se sostenga. Eso lo digo yo a partir de las señales: nadie lo ha declarado.

### Si se aprueba
Línea base 2 — cierre 2026-12-08 · presupuesto: sin cambio pedido (4.200.000.000 COP), proyección 5.331.567.805 COP · motivo: pendiente, el solicitante debe darlo y citar el documento que lo respalde.
La línea base 1 no se toca. Replanificaciones: de 0 a 1.
**Desviación acumulada contra la línea base original:** tiempo +30 días (2026-11-08 → 2026-12-08, 8,4 % de los ~331 días del plan; bajo el umbral de 10 %, pero cerca) · costo +26,9 % sobre el aprobado (proyección frente a aprobado, ya sobre el umbral de 10 %). Contra la línea base vigente, hoy 0 días. La nueva quedaría en 0 y la original en +30.

## Señales abiertas que este cambio no resuelve
- Avance declarado 57 % frente a 80–100 % que sostiene el plan (23 puntos de brecha).
- Dos hitos cumplidos sin evidencia.
- Costo proyectado +26,9 % sobre el aprobado.
- Parametrización del tarifario (CT-190) vencida hace 91 días; «Bolsa de horas de desarrollo» figura aceptada sin acta de recibo.
- Dos riesgos y dos incidencias sin dueño (seguridad, cambio regulatorio, historias fuera del sprint, hallazgo de seguridad).
- Campos no encontrados: autoridad, producto, fase.

## Lo que no sé
- Quién pidió el cambio y por qué.
- Cuánto cuesta el corrimiento.
- Si el corrimiento viene del alcance (cambio regulatorio).
- Qué dependencias reales tiene con el core.
- Qué pasa con el contrato CT-190 si la salida se mueve.
- Cuántos días se mueve cada actividad (la ficha no tiene holgura).

## Pie de rigor
Cifras de la ficha PRY-208 (corte 2026-10-17) y de `portafolio.py impact` y `compute`. La declaración del gerente (rojo, 57 %) es declaración, no evidencia: la carpeta tiene 0 fuentes de evidencia para esos datos. Esto es un borrador de trabajo, no una decisión: verifique cada dato contra el documento citado.

## Después
Ofrezco llevarlo al Comité de Arquitectura del 2026-10-20 como paquete de decisión (`/steering-pack`). No registro línea base nueva: nadie ha aprobado el cambio.
