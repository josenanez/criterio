# Corrida del 2026-10-17 · product-view

13 proyectos · 30 s · 60 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 7 |
| `vendor_deliverable_late` | 5 |
| `declared_vs_evidence` | 4 |
| `commitment_undated` | 3 |
| `vendor_accepted_without_evidence` | 3 |
| `variance_cost` | 3 |
| `commitment_rescheduled` | 2 |
| `silent` | 1 |
| `variance_time` | 1 |
| `rebaseline_unauthorized` | 1 |
| `budget_committed` | 1 |
| `change_without_baseline` | 1 |

Producto de un solo proyecto (PRY-209): sin sección aparte. Señales: variance_cost 10,0 % y verde declarado sin explicar el costo. Reporta 4 proyectos sin producto. No sabe si el sobrecosto tiene aprobación (falta authority).

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

**Vista por producto: nómina empresarial.** Sale de las fichas de `estado/records` (13 proyectos, 9 productos), recalculadas con `portafolio.py compute` al 2026-10-17. Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17).

## Productos al 2026-10-17 (producto pedido)

| Producto | Proyectos | Con alertas | Fecha más tardía | Aprobado | Comprometido |
|---|---|---|---|---|---|
| nómina empresarial | 1 (PRY-209) | 1 (2 señales) | 2026-09-21 (PRY-209) | COP 2.400.000.000 | COP 1.699.888.084 |

**Nómina empresarial tiene un solo proyecto, PRY-209 Nómina electrónica. La vista por producto no aporta nada distinto de la ficha del proyecto, así que no armo una sección aparte.** Lo que hay que ver, por si sirve:

- **Costo (`variance_cost`):** la proyección es COP 2.640.413.839 contra COP 2.400.000.000 aprobados, 10,0 % por encima. Ese es el umbral configurado (10 %).
- **Verde declarado frente a la evidencia (`declared_vs_evidence`):** el informe de avance del 2026-10-17 (`PRY-209-nómina-electrónica/20-seguimiento/2026-10-17-informe-avance.md`) declara verde y 50 % de avance. La señal de costo de arriba no la explica nadie en ese informe.
- **Dinero:** ejecutado COP 1.193.333.539 (49,7 %), comprometido 70,8 %, disponible real COP 700.111.916. Trae las cuatro cifras (aprobado, comprometido, ejecutado, proyección), así que la suma del producto está completa.
- **Fecha:** el fin vigente es 2026-09-21, anterior a la fecha de corte. El cálculo no marca hitos vencidos ni atraso contra la línea base (0 días, 0 replanificaciones). No tengo en las fichas un cierre ni una nueva fecha, y no lo supongo.
- **Dependencias internas:** ninguna registrada. Con un solo proyecto no puede haber dependencias entre proyectos del mismo producto.
- **Cambios:** 1 solicitud de cambio, sin impacto en tiempo y sin línea base movida.
- **Datos que faltan en la ficha:** `identity.authority` e `identity.phase`. Las fuentes: 0 con evidencia, 2 declaraciones y 15 sin marcar.

## Proyectos sin producto declarado

| Proyecto | Área dueña |
|---|---|
| PRY-202 Migración a la nube | Riesgo y Cumplimiento |
| PRY-205 Prevención de lavado de activos | Riesgo y Cumplimiento |
| PRY-208 Motor de decisión | Banca Hipotecaria |
| PRY-210 Portal de proveedores | Tesorería |

Nadie puede responder por el conjunto al que sirven estos cuatro proyectos. Es un hallazgo de gobierno. Además, PRY-199 declara el producto como «PRD-299», un código y no un nombre, así que no cruza con los demás productos.

## Después

No hay dependencias internas que llevar al comité de producto. Lo que sí puede ir al comité del 2026-10-20 es una sola decisión: PRY-209 está en verde declarado con 10,0 % de sobrecosto proyectado.

## Pie de rigor

- Cifras copiadas de la salida de `compute` del 2026-10-17. No calculé nada a mano.
- No sé si el sobrecosto de PRY-209 tiene aprobación del patrocinador. La ficha no trae `authority`.
- Las áreas dueñas salen de las actas de constitución citadas en cada ficha. La verificación es de la persona.
- El portafolio completo tiene 13 proyectos, 11 con alertas y 60 alertas en total. No las detallo aquí: esta vista es solo del producto pedido.
