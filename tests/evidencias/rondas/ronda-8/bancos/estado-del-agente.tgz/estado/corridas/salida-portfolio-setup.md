## Listo — Portafolio de proyectos

**Miré:** 78 documentos en 13 proyectos · formatos: .md (37), .docx (15), .pdf (13), .xlsx (7), .csv (4), .json (1), .txt (1) · más reciente: 2026-10-17
**Eres:** PMO del portafolio (propuesto: hay varios proyectos)
**Te aviso:** dos días antes del comité del 2026-10-20 (comité semanal, propuesto por los nombres `comite-semanal` de tus actas; el 2026-10-20 es mi suposición, corrígela si no es esa fecha)
**En:** presentación (valor sugerido)
**Términos:** aceptados para la versión 0.3.13 (términos 1.1) por José Francisco Ñáñez, con fecha 2026-10-17 · comprobante en `.criterio/terminos/aceptacion-criterio-portfolio-0.3.13-2026-10-17.md` y `.pdf` · SHA-256 (del comprobante .md) 6d4b67767ea3a1ea…

Dónde queda lo que voy encontrando: `estado/`; los informes irán a `reportes/`; la configuración, en `.criterio/portafolio/config.json`. Hice 0 preguntas (sesión sin interfaz: tomé las respuestas sugeridas).

### Probé con tres proyectos

Los de documentación más reciente: PRY-202, PRY-203 y PRY-208.

| Proyecto | Documentos | Qué supe | Qué no está |
|---|---|---|---|
| PRY-202 Migración a la nube | 20 | Patrocinadora María Restrepo, gerente Camilo Beltrán (acta 2025-11-03; informe 2026-10-17). Presupuesto 6.800 M COP, ejecutado 3.907 M. Cierre vigente 2027-06-29 contra 2027-04-14 del acta. Declara rojo, 77%. 26 compromisos de comité. Trae ficha del gerente (`ficha-pm.json`), guardada aparte. | Producto («No aplica»), facultad del gerente, fase |
| PRY-203 Open Banking | 5 | Patrocinadora Natalia Ospina, gerente María Restrepo, producto «APIs de datos». Presupuesto 6.800 M COP; proyección al cierre 8.099 M. Cierre 2026-10-29. Declara verde, 39%. | Facultad del gerente, fase; sin contrato de proveedor aunque el informe habla de uno |
| PRY-208 Motor de decisión | 10 | Patrocinadora Natalia Ospina, gerente Gustavo Neira. Presupuesto 4.200 M COP; proyección 5.331 M. Cierre 2026-11-08. Contrato CT-190 con Redes del Norte. Declara rojo, 57%. | Producto («No aplica»), facultad del gerente, fase |

### Hallazgos (los que levantó el cálculo, con su nombre)

**PRY-203 · declara verde y los datos no lo sostienen** (`declared_vs_evidence`)
- `progress_vs_plan`: declara 39% y el cronograma, con 3 de 4 hitos cerrados, sostiene entre 75% y 100%: 36 puntos de diferencia.
- `variance_cost`: la proyección (8.099 M) excede el aprobado (6.800 M) en 19,1%.
- `budget_committed`: 90,4% del presupuesto ya comprometido; quedan 654 M sin comprometer.
- `milestone_met_without_evidence`: «Ambiente de pruebas certificado» y «Integración con el core» están declarados cerrados sin acta. «Diseño funcional aprobado» sí tiene acta, pero del 2026-10-17, ocho meses después de su fecha.
- `commitment_overdue`: Paula Céspedes, «Entregar el punto 23», para el 2026-10-12, sin cierre (5 días).

**PRY-202 · cronograma movido sin autorización**
- `variance_time` y `rebaseline_unauthorized`: el cierre se movió 76 días (14,7%) y la única solicitud de cambio, CC-01 (+76 días, +152 M COP), sigue pendiente de comité: 0 días autorizados.
- `milestone_met_without_evidence`: «Diseño funcional aprobado» e «Integración con el core» declarados cerrados sin acta. «Ambiente de pruebas certificado» sí tiene acta.
- `commitment_rescheduled`: Laura Vélez, «Enviar el documento 1», prometido 6 veces de nuevo (del 2026-09-24 al 2026-12-28); María Restrepo, «Cerrar la prueba 2», 5 veces (del 2026-09-13 al 2026-12-15).
- `commitment_overdue`: 6 compromisos vencidos sin evidencia (por ejemplo Sandra Gil, «Validar el ambiente 12», 23 días). `commitment_undated`: 3 sin fecha.
- `vendor_deliverable_late`: «Licenciamiento del motor» de Datacore, 196 días en CT-267 y 149 en CT-243. `vendor_accepted_without_evidence`: «Bolsa de horas de desarrollo» (CT-267) figura recibida y facturada (428,6 M) sin acta de recibo.
- Lo ejecutado (3.907 M) supera lo comprometido (3.838 M) en la ficha; el cálculo no lo levantó como señal, lo dejo anotado.

**PRY-208 · rojo declarado, con tres cosas más**
- `progress_vs_plan`: declara 57% y el cronograma (4 de 5 hitos cerrados) sostiene entre 80% y 100%.
- `variance_cost`: proyección 26,9% sobre el aprobado.
- `milestone_met_without_evidence`: «Integración con el core» y «Piloto con usuarios internos» declarados cerrados sin acta.
- `vendor_deliverable_late`: «Parametrización del tarifario» (Redes del Norte), 91 días. `vendor_accepted_without_evidence`: «Bolsa de horas de desarrollo» figura recibida sin acta.

### El portafolio completo

10 proyectos más (43 documentos, en un solo lote), uno tras otro. Estimo unos 15 a 20 minutos con lo que viste; es una estimación, no una medición.

### Lo que le falta a tu carpeta

- PRY-206, PRY-207 y PRY-209 no traen cronograma, y PRY-200, PRY-206, PRY-207 y PRY-209 tampoco actas de reunión: sin plan no hay hitos que contrastar con lo que declaran.
- Ninguna de las tres actas de constitución dice hasta dónde puede decidir el gerente sin subir a comité: sin eso el control de cambios no sabe si algo excede su facultad.
- Las tres declaran hitos cerrados sin el acta que lo prueba; es lo que más pesa en el análisis.
- Las actas de constitución tienen un alcance genérico («Componente 1, 2 y 3») y «Dependencias: ninguna declarada», aunque los informes hablan de dependencia con el core.
- Hay compromisos de comité sin fecha («por definir», «la otra semana») y personas que dicen haber entregado sin acta.

Ninguno bloquea nada: esto funciona con lo que haya. ¿Corro el portafolio completo?
