# Corrida del 2026-10-17 · steering-pack

13 proyectos · 72 s · 60 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 7 |
| `vendor_deliverable_late` | 5 |
| `declared_vs_evidence` | 4 |
| `commitment_undated` | 3 |
| `vendor_accepted_without_evidence` | 3 |
| `variance_cost` | 3 |
| `commitment_rescheduled` | 2 |
| `silent` | 1 |
| `variance_time` | 1 |
| `rebaseline_unauthorized` | 1 |
| `budget_committed` | 1 |
| `change_without_baseline` | 1 |

Paquete de 6 decisiones y 6 escalamientos sobre 13 fichas. Dije que no sé: autoridad de los 13 proyectos, comité que aprobó PRY-206 CC-01, línea base de PRY-202 CC-01, fecha del comité y no hay comité anterior que cerrar.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

Términos: vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17); no hubo que registrar nada. Criterio produce borradores, no decisiones ni asesoría; la verificación contra las citas es suya. Nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal

Sesión sin interfaz: nadie respondió preguntas. Donde había una pregunta tomé la respuesta sugerida y la dejo dicha en una línea.

**Fichas cargadas:** 13 (PRY-199 a PRY-211), estado al 2026-10-17. Cifras recalculadas con `portafolio.py compute` el mismo día.

# Comité de proyectos — 2026-10-20
6 decisiones · 6 escalamientos · 11 de 13 proyectos con hallazgos (60 señales; 4 proyectos declaran verde y la evidencia los contradice: PRY-200, PRY-203, PRY-209, PRY-211)

La fecha 2026-10-20 sale de `cycle.committee_next` en la configuración. La salida de PM del 2026-10-17 de PRY-202 decía 2026-10-31; no sé cuál es la correcta, confírmenla.

## Decisiones del comité anterior
No hay registro de comité anterior en las fichas ni en las carpetas de proyectos: no encontré minutas de comité de portafolio, solo actas de comités semanales de proyecto. No puedo decir qué se decidió ni qué se hizo con ello. Hay una sola pista: PRY-206 CC-01 figura «autorizada por el comité» sin decir cuál ni cuándo (ver decisión 2).

| Decisión | Fecha | Qué pasó | Estado |
|---|---|---|---|
| Sin registro | — | — | No se puede cerrar el ciclo |

## Decisiones de hoy

### [1] ¿Quién tiene la facultad de aprobar cambios de alcance, tiempo y costo, y hasta qué umbral decide el gerente sin ir a comité?
**Proyecto:** los 13 (ninguna ficha tiene autoridad declarada) · **Quién decide:** el patrocinador o el comité, según cada acta; ninguna acta lo dice. Es mi lectura, no un dato.
**Si no se decide hoy:** los puntos 2, 3 y 4 se votan sin saber si este comité es quien debe aprobarlos.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Adenda a cada acta con facultades por umbral | Sin cambio | Una adenda por proyecto; los documentos no dan plazo | Sin costo declarado |
| B. Una política de portafolio con un umbral único | Sin cambio | Una sola decisión; no hay documento que indique si ya existe | Sin costo declarado |
| C. Seguir sin declarar | Sin cambio | Cada cambio se discute caso por caso | Sin costo declarado |

**Recomendación:** B, con A solo para los proyectos que necesiten un umbral distinto. Una regla sola es lo que permite verificar los puntos siguientes. Es criterio mío, no se sustenta en un documento.

### [2] PRY-206 Billetera y QR — ¿qué comité aprobó CC-01 y se registra la línea base nueva?
**Proyecto:** PRY-206 · **Quién decide:** sin determinar (el documento dice «autorizada por el comité» y no cuál). **Si no se decide hoy:** el proyecto sigue midiéndose contra una línea base que no incluye +97 días, aunque el cambio figura aprobado.

CC-01 (2026-10-08): ampliación de alcance, +97 días sobre la línea base vigente, 194.000.000 COP adicionales. La ficha tiene el cambio aprobado y la línea base sin mover (`baseline_moved_days` 0 contra `approved_time_days` 97).

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Ratificar y registrar línea base nueva | Ampliación | +97 días | +194.000.000 COP sobre 18.000.000.000 COP aprobados |
| B. Desconocer la aprobación (no hay acta) y presentar CC-01 de nuevo | Sin ampliación hasta decidir | Sin cambio hasta decidir | Sin cambio hasta decidir |

**Recomendación:** A solo si el comité que aprobó aparece con acta; si no aparece, B. Hoy no hay acta que lo sustente.

### [3] PRY-202 Migración a la nube — ¿se aprueba CC-01 y sobre cuál línea base?
**Proyecto:** PRY-202 · **Quién decide:** sin determinar (ver decisión 1). **Si no se decide hoy:** el cronograma v2 ya circula con el cierre movido 76 días sin cambio aprobado (`rebaseline_unauthorized`: 76 días movidos, 0 autorizados).

CC-01 (2026-10-08): ampliación de alcance, +76 días, 152.000.000 COP. La variación de tiempo contra la línea base original es 14,7 % (umbral 10 %).

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar sobre la línea base v1 | Ampliación (la solicitud no dice cuál) | +76 días | +152.000.000 COP sobre 6.800.000.000 COP aprobados |
| B. Aprobar sobre v2 | Igual | Más de 76 días contra v1 (la ficha no da el cierre) | +152.000.000 COP |
| C. Rechazar | Sin ampliación | Volver a la fecha original; hay que rehacer el cronograma v2 | Sin costo declarado; el de volver no está en ningún documento |

**Recomendación:** antes de votar, aclarar si los 76 días son sobre v1 o sobre v2. Entre A y C no puedo recomendar: ningún documento dice qué incluye la ampliación ni qué pasa si no se hace.

### [4] PRY-209 Nómina electrónica — ¿se aprueba CC-01?
**Proyecto:** PRY-209 · **Quién decide:** sin determinar (ver decisión 1). **Si no se decide hoy:** la solicitud sigue «pendiente de presentación al comité» desde el 2026-10-11 y el proyecto declara verde.

CC-01: ampliación de alcance, +34 días, 68.000.000 COP. La proyección ya supera el aprobado en 10,0 % (2.640.413.839 COP contra 2.400.000.000 COP), exactamente en el umbral. No sé si la proyección incluye los 68.000.000.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar | Ampliación | +34 días | +68.000.000 COP |
| B. Rechazar | Sin ampliación | Sin cambio | Sin costo adicional; la proyección ya está en 2.640.413.839 COP |

**Recomendación:** no hay base para recomendar. Pedir primero a Paula Céspedes si la proyección incluye el cambio.

### [5] PRY-203 Open Banking — ¿cómo se cubre una proyección de costo 19,1 % sobre lo aprobado?
**Proyecto:** PRY-203 · **Quién decide:** quien aprobó el presupuesto; el acta no lo dice. **Si no se decide hoy:** el comprometido está en 90,4 % (umbral 90 %) y quedan 654.414.337 COP disponibles reales; el informe de avance del 2026-10-17 declara verde.

Proyección 8.099.349.061 COP contra 6.800.000.000 COP aprobados. Avance declarado 39 % contra 75–100 % que sustentan los hitos (3 de 4 cumplidos, dos de ellos sin evidencia de recibo).

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Ampliar presupuesto a la proyección | Sin cambio | Sin cambio declarado | 8.099.349.061 COP |
| B. Recortar alcance al aprobado | Menor; la ficha no dice qué sale | Sin dato | 6.800.000.000 COP |
| C. Pedir plan de recuperación antes de decidir | Sin cambio | Sin dato | Sin cambio |

**Recomendación:** C, y que el gerente traiga la evidencia de los dos hitos «cumplidos» sin recibo. Con 39 % declarado contra 75–100 % que sustentan los hitos, la proyección no es confiable en ninguna dirección.

### [6] PRY-208 Motor de decisión — ¿cómo se cubre una proyección 26,9 % sobre lo aprobado?
**Proyecto:** PRY-208 · **Quién decide:** quien aprobó el presupuesto; el acta no lo dice. **Si no se decide hoy:** el comprometido es 2.627.159.697 COP de 4.200.000.000 COP y el ejecutado apenas 760.056.752 COP; queda un entregable del proveedor vencido hace 91 días.

Proyección 5.331.567.805 COP contra 4.200.000.000 COP aprobados. Avance declarado 57 % contra 80–100 % que sustentan los hitos.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Ampliar presupuesto a la proyección | Sin cambio | Sin cambio declarado | 5.331.567.805 COP |
| B. Recortar alcance al aprobado | Menor; la ficha no dice qué sale | Sin dato | 4.200.000.000 COP |
| C. Exigir al proveedor la parametrización del tarifario antes de decidir | Sin cambio | Sin dato | Sin cambio |

**Recomendación:** C primero: el entregable «Parametrización del tarifario» (Redes del Norte Ltda., vencido el 2026-07-18) puede explicar parte del sobrecosto, pero ningún documento lo dice. Es hipótesis mía.

## Escalamientos sin decisión asociada
| Proyecto | Qué | Desde cuándo | Qué se necesita |
|---|---|---|---|
| PRY-200 | En silencio 23 días (último documento 2026-09-24); declara verde con 29 % contra 75–100 % sustentado y 3 hitos «cumplidos» sin evidencia | 2026-09-24 | Que el gerente responda y traiga la evidencia de los hitos |
| PRY-210 | Proveedor Talento Digital S.A.S.: «Licenciamiento del motor» vencido hace 457 días y «Mesa de ayuda del primer trimestre» hace 313; «Bolsa de horas» aceptada sin evidencia de recibo | 2025-07-17 | Decisión contractual: exigir, penalizar o renegociar |
| PRY-202 | 6 compromisos vencidos (de 2 a 23 días). Reprogramados 6 veces: Laura Vélez «Enviar el documento 1»; 5 veces: María Restrepo «Cerrar la prueba 2». El proveedor Datacore tiene el «Licenciamiento del motor» vencido hace 196 y 149 días | 2026-09-13 (primera fecha de «Cerrar la prueba 2») | Dueño y fecha firme; María Restrepo es la patrocinadora |
| PRY-201 | Compromiso vencido hace 19 días (Elena Duarte, «Entregar el punto 39»); avance declarado 63 % con 0 de 3 hitos cumplidos | 2026-09-28 | Aclarar de dónde sale el 63 % |
| PRY-205 | Avance declarado 51 % con 4 de 4 hitos cumplidos; 3 sin evidencia de recibo (uno de 2025-09-28) | 2025-09-28 | Aclarar cuál de las dos cifras es la real |
| PRY-211 | Declara verde y tiene 2 hitos «cumplidos» sin evidencia | 2026-09-27 | Evidencia de recibo |

## Para conocimiento
- PRY-199: sin señales; avance 20 % contra 20–40 % sustentado.
- PRY-204: avance 58 % contra 75–100 % sustentado; 2 hitos sin evidencia de recibo.
- PRY-207: sin señales.

## Anexo
**Estado por proyecto:** 13 fichas, ninguna con problemas de esquema (`record_issues` 0), todas con línea base. 9 productos; PRY-203 (APIs de datos) concentra más señales (7).

**Vacíos de información:**
- Sin autoridad declarada en 13 de 13 fichas.
- Sin minutas de comité de portafolio previas.
- PRY-202: el ejecutado supera al comprometido (3.907.353.837 COP contra 3.838.191.725 COP según `compute`); nadie lo explica.
- 6 compromisos sin fecha en PRY-202.

**Contradicciones abiertas:** las 4 «verde contra evidencia» de arriba.

**Fecha del próximo comité:** 2026-10-20 (configuración) contra 2026-10-31 (PM de PRY-202); sin resolver.

---
**Pie:** Criterio Portfolio 0.3.13 · términos v1.1 · fichas aplicadas: 13 (estado al 2026-10-17) · campos inciertos: autoridad de los 13 proyectos; comité que aprobó PRY-206 CC-01; línea base de referencia de PRY-202 CC-01; si las proyecciones de PRY-202 y PRY-209 incluyen sus cambios; fecha del comité · términos: https://www.josenanez.com/es/agents/criterio-pmo/legal

Cuando el comité sesione, puedo registrar las decisiones en las fichas; así el material del próximo comité parte de ellas.
