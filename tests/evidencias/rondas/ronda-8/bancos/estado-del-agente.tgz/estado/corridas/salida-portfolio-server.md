# Rostrum — modo «para mirarlo un rato»

**Términos:** ya vigentes (v0.3.13, aceptados por José Francisco Ñáñez el 2026-10-17). No hizo falta volver a registrarlos.

**Modo elegido:** «para mirarlo un rato». Nadie respondió la pregunta de los dos modos; se tomó la respuesta sugerida, que es empezar por este: se levanta en segundos, se ve funcionando, y la conversación con seguridad llega después con algo en la mano.

**Informe servido:** `estado/reportes` (13 proyectos PRY-199 a PRY-211, 9 productos, portada, decisiones y listados), generado el 2026-10-17 17:20.

## Comando

```
python3 "/home/claude/banco/criterio/plugins/criterio-portfolio/scripts/servidor.py" --informe /home/claude/banco/ronda-8/bancos/espacio/estado/reportes --estado /home/claude/banco/ronda-8/bancos/espacio/estado --config /home/claude/banco/ronda-8/bancos/espacio/.criterio/portafolio/config.json --puerto 8788
```

Escucha en `127.0.0.1:8788` (el 8787 ya estaba ocupado por otro proceso ajeno a este informe, que no se tocó), solo en este equipo. Se para con Ctrl-C. Si el 8788 también se ocupa: otro `--puerto`.

## Qué hay y para quién

| Ruta | Qué es | Para quién |
|---|---|---|
| `/` | Portada con las tres secciones y el formulario de peticiones | Todos |
| `/pmo` | Cómo va el portafolio: verdes que la evidencia no sostiene, silencios, patrocinadores repetidos | La PMO |
| `/decisiones` | Lo que necesita decisión, como pregunta cerrada y con la consecuencia de no decidir | El comité y el patrocinador |
| `/proyectos` | Listado ordenado por lo que más pide atención | Todos |
| `/p/<código>` | Informe de un proyecto, con enlace a su producto | Quien gerencia, quien pregunta |
| `/productos` | Listado de productos y proyectos que no dicen qué producto construyen | Quien responde por un producto |
| `/producto/<nombre>` | Informe de un producto, con enlace a los proyectos que lo construyen | Quien responde por un producto |
| `/estado.json` | De cuándo es el informe y cuántas peticiones hay abiertas | Un mecanismo |

El enlace proyecto ↔ producto va en los dos sentidos. Si un producto lo construyen proyectos que reportan a comités distintos, solo ahí se ve.

## Lo que Rostrum no hace

- **No calcula.** Sirve lo que `informe.py` ya escribió; abrir una página no lee documentos.
- **No escribe fichas.** Lo único que crea es la petición, en `estado/peticiones/`.
- **No autentica.** Por eso en este modo solo escucha en 127.0.0.1.
- **No manda nada.** Sin correo ni notificaciones.

## Peticiones

El formulario de la portada deja la petición en `estado/peticiones/` y ahí queda hasta que el agente despierte: `due` las cuenta y rompen el silencio de `/portfolio-wake`. Se cierran con `portafolio.py answered`.

## Cierre

- **Enlace:** `http://127.0.0.1:8788/`. Funciona solo en esta máquina y mientras el proceso esté vivo; no sirve para pasárselo al patrocinador. Para eso es el modo «que quede corriendo», que requiere pedir un host y puerto internos y publicarlo detrás del control de acceso de la organización.
- **Vigencia del informe:** es del 2026-10-17 17:20. Queda desactualizado en cuanto cambie una ficha o un documento, o se corra otro `/portfolio-scan`; el comité semanal siguiente es el 2026-10-20, y conviene regenerarlo con `/portfolio-report html` antes. La portada muestra su fecha.
