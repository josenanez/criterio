**Documentos de los que sale:** ficha PRY-203 (estado/records/PRY-203.json), construida de `PRY-203-open-banking/20-seguimiento/2026-10-17-informe-avance.md`, el cronograma v1 (2025-11-01), el acta de constitución (2025-11-01), el acta de recibo del diseño funcional (2026-10-17) y el comité del 2026-10-12. Cifras recalculadas con `portafolio.py compute` al 2026-10-17.

## Presupuesto — PRY-203 Open Banking al 2026-10-17
**Moneda:** COP (única; no hay contratos en otra moneda ni conversión)

| | Monto (COP) | % del aprobado | Fuente | Fecha |
|---|---|---|---|---|
| Aprobado | 6.800.000.000 | 100% | informe-avance.md, sección Presupuesto | 2026-10-17 |
| Comprometido | 6.145.585.663 | 90,4% | informe-avance.md, sección Presupuesto | 2026-10-17 |
| Ejecutado | 1.436.705.266 | 21,1% | informe-avance.md, sección Presupuesto | 2026-10-17 |
| Proyección al cierre | 8.099.349.061 | 119,1% (excede el aprobado en 19,1%) | informe-avance.md, sección Presupuesto | 2026-10-17 |

**Disponible real** (aprobado menos comprometido): 654.414.337 COP

Las cuatro cifras vienen de un solo documento, el informe de avance del gerente (María Restrepo). Son declaración, no evidencia contable: ningún documento del proyecto es un extracto de ejecución ni un contrato. La proyección es una declaración del gerente con fecha 2026-10-17, igual que las demás cifras; no hay un movimiento de presupuesto posterior que la deje vieja.

### Contra la línea base
| | Original | Vigente | Desviación |
|---|---|---|---|
| Aprobado | 6.800.000.000 | 6.800.000.000 | 0 (no hay solicitudes de cambio registradas) |
| Proyección al cierre frente al aprobado | — | 8.099.349.061 | +19,1% (umbral 10%) |

Replanificaciones de presupuesto: 0. Solo se encontró un valor aprobado; no hay en los documentos una línea base de presupuesto anterior con la que compararlo, y no se inventa una.

### Ejecución frente a avance
Ejecutado 21,1% · Hitos cumplidos 3 de 4 (declarados), de los cuales solo 1 tiene evidencia de recibo · Avance declarado 39%; el plan sostiene entre 75% y 100% con esos hitos, brecha de 36,0 puntos.

Lectura: el dinero va en 21,1% ejecutado, pero 90,4% ya está comprometido, así que la holgura no es 78,9% sino 9,6%. Lo ejecutado va por debajo del avance declarado de hitos, pero esos hitos no están sustentados: dos marcados como cumplidos no tienen acta ni evidencia. No se puede decir si hay trabajo hecho sin facturar o hitos que no se cumplieron.

### Alertas
- **Comprometido en 90,4%, por encima del umbral de 90%.** Disponible real 654.414.337 COP, y falta el piloto con usuarios internos (2026-10-29, 12 días).
- **La proyección excede el aprobado en 19,1%** (8.099.349.061 frente a 6.800.000.000), por encima del umbral de 10%. Diferencia: 1.299.349.061 COP.
- **Hitos declarados cumplidos sin evidencia:** "Ambiente de pruebas certificado" (vencía 2026-05-06, 164 días) e "Integración con el core" (vencía 2026-08-02, 76 días).
- **Compromiso vencido:** Paula Céspedes, "Entregar el punto 23", vencía 2026-10-12 (5 días), fuente: 30-reuniones/2026-10-12-comite-semanal.md.
- **Estado declarado "verde" con cinco señales sin explicar:** comprometido, proyección, avance frente a plan, hitos sin evidencia y compromiso vencido.

### Sin dato
- Presupuesto original distinto del vigente: no declarado en ningún documento.
- Desglose del comprometido por proveedor o contrato: no hay contratos de proveedor en la documentación del proyecto.
- Fase del proyecto y autoridad de aprobación: `not_found`.

### Después
La proyección excede el aprobado, así que puedo preparar la solicitud de cambio de presupuesto, y como el comprometido está sobre el tope, el detalle por proveedor, si aportan los contratos. Ninguna de las dos cosas se ha hecho.

---
**Pie de rigor:** borrador de trabajo, no decisión ni asesoría. Cada cifra sale del informe de avance del 2026-10-17 (declaración del gerente, sin evidencia contable) y los cálculos de `compute`. La verificación es suya.
