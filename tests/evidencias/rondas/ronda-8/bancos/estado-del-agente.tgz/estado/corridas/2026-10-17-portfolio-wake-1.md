# Corrida del 2026-10-17 · portfolio-wake

13 proyectos · 25 s · 60 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 7 |
| `vendor_deliverable_late` | 5 |
| `declared_vs_evidence` | 4 |
| `commitment_undated` | 3 |
| `vendor_accepted_without_evidence` | 3 |
| `variance_cost` | 3 |
| `commitment_rescheduled` | 2 |
| `silent` | 1 |
| `variance_time` | 1 |
| `rebaseline_unauthorized` | 1 |
| `budget_committed` | 1 |
| `change_without_baseline` | 1 |

Barrido: 78 documentos sin cambios, 18 citas de PRY-202 sin resolver en el indice (los archivos existen en la carpeta del proyecto). Confirmacion: 5 campos preguntados, sin respuesta (sesion sin interfaz). No toco informe ni peticiones. No se verifico la causa de las citas rotas.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## 2026-10-17

**Revisé:** 78 documentos · 0 cambiaron · 0 proyectos recalculados

Términos vigentes (versión 1.1, aceptados el 2026-10-17 por José Francisco Ñáñez). No hubo nada que releer, así que no corrí `/portfolio-scan`.

### Lo que cruzó un umbral
Ningún umbral de cadencia, plazo o costo. Sí hay un hallazgo de trazabilidad: **18 citas de PRY-202 no resuelven en el índice** (`source_missing`). Los archivos citados existen dentro de la carpeta del proyecto (`00-gobierno/2025-11-03-acta-constitucion.docx`, `20-seguimiento/2026-10-17-informe-avance.md`, `10-plan/2026-10-17-cronograma-v2.csv`, `20-seguimiento/2026-08-30-factura-ct-267.pdf`), pero el índice no los encuentra con la ruta que usa la ficha. Es probable que la ruta de la ficha no lleve el prefijo de la carpeta del proyecto. No lo corregí: no es una conclusión, es una cita que hay que revisar. Afecta identidad, estado declarado, avance, plazos, dinero y facturación de PRY-202.

### Peticiones atendidas
Ninguna pendiente.

### Preguntas
Nadie responde en esta sesión. Respuesta sugerida tomada: no registrar nada. Los cinco campos que quedan por confirmar de PRY-202, los de mayor importancia y citas rotas:
1. Estado declarado (`declared.status`) — fuente: informe de avance 2026-10-17.
2. Avance declarado (`declared.progress_pct`) — fuente: informe de avance 2026-10-17.
3. Fecha de fin del plan (`plan.end_date`) — fuente: cronograma v2 2026-10-17.
4. Proyección de costo (`money.projection`) — fuente: informe de avance 2026-10-17.
5. Monto facturado del proveedor (`vendors[0].invoiced`) — fuente: factura CT-267 del 2026-08-30.

Preguntadas el 2026-10-17, sin respuesta.

**Vuelvo el 2026-10-18.** El comité es el 2026-10-20; el informe toca el 2026-10-18.
