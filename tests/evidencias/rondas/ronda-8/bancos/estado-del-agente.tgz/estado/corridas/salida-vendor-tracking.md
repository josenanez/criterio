Sale de: contratos CT-267 y CT-243 (`00-gobierno`), factura FV-1267 (`20-seguimiento/2026-08-30-factura-ct-267.pdf`), las actas de recibo de `20-seguimiento`, el informe de avance del 2026-10-17, las notas de reunión del 2026-10-17, los seis comités de septiembre–octubre y el cálculo de `portafolio.py compute` al 2026-10-17. Términos vigentes: aceptados por José Francisco Ñáñez el 2026-10-17 (versión 0.3.13).

## Proveedores — PRY-202 Migración a la nube al 2026-10-17

Un solo proveedor, Datacore Colombia, con dos contratos (CT-267 y CT-243). Los dos contratos están en la carpeta.

### Datacore Colombia — contrato CT-267
**Vigencia:** no consta (el contrato solo trae fecha de firma, 2025-10-27, y la tabla de entregables) · **Preaviso de no renovación:** no consta · **Vence el:** no consta
**Condición de pago (contrato):** «Cada entregable se factura contra acta de recibo firmada por el gerente del proyecto».

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento del motor (428.583.833 COP) | 2026-04-04 | `pending`; vencido hace 196 días | Ninguna | No consta |
| Bolsa de horas de desarrollo (428.583.833 COP) | 2026-08-24 | `accepted` (según la tabla del propio contrato: «recibido») | **Ninguna.** No hay acta de recibo, correo ni minuta que lo pruebe | FV-1267 por 428.583.833 COP, 2026-08-30 (concepto: «Entregables del contrato CT-267», sin decir cuál) |
| Parametrización del tarifario (428.583.833 COP) | 2027-01-13 | `pending` | Ninguna | No consta |

Montos declarados: 3 de 3 entregables. Aceptado según el cálculo: 1 de 3, por 428.583.833 COP. Facturado: 428.583.833 COP. No se levanta `vendor_invoiced_over_accepted` ni `vendor_invoiced_without_delivery`, porque la cifra facturada coincide con la del único entregable dado por aceptado. Pero esa aceptación no tiene documento (ver abajo).

### Datacore Colombia — contrato CT-243
**Vigencia:** no consta (fecha de firma 2025-11-08) · **Preaviso de no renovación:** no consta · **Vence el:** no consta
**Condición de pago (contrato):** igual que CT-267, contra acta de recibo firmada por el gerente.

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento del motor (321.737.192 COP) | 2026-05-21 | `pending`; vencido hace 149 días | Ninguna | No consta |
| Bolsa de horas de desarrollo (321.737.192 COP) | 2026-11-27 | `pending` | Ninguna | No consta |

Montos declarados: 2 de 2. Aceptado: 0. Facturado: ningún documento lo declara.

### Dónde no cuadra
| Qué | Dice el contrato | Dice la evidencia | Fuentes |
|---|---|---|---|
| Bolsa de horas de desarrollo, CT-267 | Se factura contra acta de recibo firmada por el gerente. La tabla la marca «recibido» | Hay una factura por 428.583.833 COP (2026-08-30, radicada en cuentas por pagar) y ningún acta de recibo de este entregable. Las actas de la carpeta (anexo 3, fecha 7, anexo 11, ambiente de pruebas) son de otras cosas | `00-gobierno/2025-10-27-contrato-ct-267.docx`; `20-seguimiento/2026-08-30-factura-ct-267.pdf`; `20-seguimiento/2026-09-19-acta-recibo-3.md`, `-7.md`, `2026-10-10-acta-recibo-11.md` |
| Misma tabla del contrato | La columna «Estado» del contrato dice «recibido» en un documento firmado el 2025-10-27, diez meses antes de la fecha comprometida | Una columna de estado dentro del contrato es una declaración, no un recibo | `00-gobierno/2025-10-27-contrato-ct-267.docx` |
| Dos contratos del mismo proveedor | CT-267 y CT-243 comprometen cada uno «Licenciamiento del motor» y «Bolsa de horas de desarrollo», con fechas y montos distintos | Ningún documento explica si son alcances separados o el mismo alcance contratado dos veces | `00-gobierno/2025-10-27-contrato-ct-267.docx`; `00-gobierno/2025-11-08-contrato-ct-243.md` |
| Informe de avance | Declara estado rojo y 77 % | No menciona al proveedor ni las entregas; solo dice, como riesgo, que el proveedor no ha confirmado la fecha de la última entrega | `20-seguimiento/2026-10-17-informe-avance.md` |

Puede haber una explicación que los documentos no ven: un acta firmada y no archivada, o una factura que corresponde a otro hito. El informe abre esa pregunta; no la cierra.

### Sin evidencia de recibo
| Entregable | Marcado como | Desde |
|---|---|---|
| Bolsa de horas de desarrollo (CT-267) | `accepted` (el contrato dice «recibido») | La factura es del 2026-08-30; la fecha comprometida era 2026-08-24. No hay fecha de aceptación en ningún documento |

Los hitos «Diseño funcional aprobado» (2026-02-24) e «Integración con el core» (2026-09-19) también figuran cumplidos sin evidencia. Son hitos del proyecto, no entregables del proveedor, y no se sabe si dependen de él.

### Entregables vencidos sin declarar entrega
| Entregable | Contrato | Comprometido | Días |
|---|---|---|---|
| Licenciamiento del motor | CT-267 | 2026-04-04 | 196 |
| Licenciamiento del motor | CT-243 | 2026-05-21 | 149 |

### Compromisos del proveedor vencidos
Ninguno atribuible. Los seis compromisos vencidos del proyecto están a nombre de Natalia Ospina (2), Ricardo Salas (2), Sandra Gil y Mauricio Pérez, y ningún documento dice que alguno de ellos sea del proveedor. Sin dato sobre quién, de las personas de las reuniones, representa a Datacore.

Pendiente relacionado: Óscar Ramírez, «revisión con el proveedor», para el 2026-10-27 (notas del 2026-10-17); todavía no vence. Se comentó en esa reunión que el proveedor podría no llegar con el equipo completo para la siguiente fase y nadie lo anotó como riesgo (`2026-10-17-notas-reunion.txt`).

### Contexto que afecta al proveedor
- La solicitud de cambio CC-01 (ampliación de alcance, +76 días, 152.000.000 COP) está pendiente de comité (`20-seguimiento/2026-10-08-solicitud-cambio-cc-01.md`). El cronograma v2 ya mueve «Salida a producción» de 2027-04-14 a 2027-06-29 y el cálculo lo marca como `rebaseline_unauthorized` (76 días movidos, 0 autorizados). Cualquier plazo contractual del proveedor ligado a esas fechas no se puede evaluar sin las cláusulas.

### Sin dato
- Vigencia, fecha de terminación, renovación automática y plazo de preaviso de CT-267 y CT-243: los contratos de la carpeta no los traen. Sin eso no se puede decir si algún preaviso vence antes del cierre del proyecto (2027-06-29 según el cronograma v2).
- Valor total de cada contrato: no consta fuera de la tabla de entregables; no se calcula ninguna suma.
- Facturación de CT-243: ningún documento la declara.
- Qué entregable cubre FV-1267: la factura dice «Entregables del contrato CT-267» en plural, sin detalle.
- Si CT-243 y CT-267 se solapan.

## Después
Hay una factura de 428.583.833 COP radicada sin el acta que, según el propio contrato, la sustenta. Recomiendo llevarlo al comité del 2026-10-20: pedir el acta de recibo de la bolsa de horas, o que se retenga el pago hasta tenerla, y aclarar la relación entre CT-267 y CT-243. También hay que pedir a Compras los textos de vigencia y preaviso de ambos contratos. No lo he llevado a ningún comité: eso lo decide usted.

---
Pie de rigor: borrador de trabajo, no decisión ni asesoría. Cifras copiadas de `portafolio.py compute` al 2026-10-17; los dos proveedores y sus entregables salen de los contratos citados. Lo que no está en los documentos se declaró como «sin dato». La verificación contra los originales es suya.
