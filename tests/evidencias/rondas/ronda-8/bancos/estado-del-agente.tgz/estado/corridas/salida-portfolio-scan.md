## Barrido — 2026-10-17

Encontré 78 documentos en `documentos/proyectos` y 13 carpetas de proyecto. Formatos: 37 .md, 15 .docx, 13 .pdf, 7 .xlsx, 4 .csv, 1 .json, 1 .txt. No hay archivos ilegibles. La carpeta `entrada/` no existe.

Términos: vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17). Resumen y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.13

**Documentos:** 78 en la carpeta · 43 leídos · 35 sin cambio desde la corrida anterior · 0 ilegibles
**Proyectos:** 13 con ficha · 10 nuevos · 0 sin carpeta propia

El plan leyó 43 de 78: los 10 proyectos que aún no tenían ficha (PRY-199, 200, 201, 204, 205, 206, 207, 209, 210, 211). PRY-202, 203 y 208 tenían su ficha sellada y no cambiaron, así que no se abrieron. Nada quedó diferido.

### Nuevos
| Proyecto | Documentos | Campos encontrados | Campos sin dato |
|---|---|---|---|
| PRY-199 Renovación de cajeros automáticos | 6 | identidad, estado declarado, plan, 5 hitos, dinero, contrato CT-199, riesgos, 1 compromiso | autoridad, fase |
| PRY-200 Originación digital | 3 | ídem, 4 hitos | autoridad, fase |
| PRY-201 Core de depósitos | 4 | ídem, 3 hitos, 2 compromisos | autoridad, fase |
| PRY-204 Débito contactless | 5 | ídem, 4 hitos, 1 compromiso | autoridad, fase |
| PRY-205 Prevención de lavado de activos | 5 | ídem, 4 hitos, 2 compromisos | autoridad, fase, producto (el acta dice «No aplica») |
| PRY-206 Billetera y QR | 3 | identidad, estado declarado, dinero, 1 solicitud de cambio | autoridad, fase, hitos (no hay cronograma) |
| PRY-207 Onboarding PyME | 2 | identidad, estado declarado, dinero | autoridad, fase, hitos (no hay cronograma) |
| PRY-209 Nómina electrónica | 3 | identidad, estado declarado, dinero, 1 solicitud de cambio | autoridad, fase, hitos (no hay cronograma) |
| PRY-210 Portal de proveedores | 8 | ídem, 5 hitos, contrato CT-100 con factura, 1 compromiso | autoridad, fase, producto («No aplica») |
| PRY-211 Cobranza digital | 4 | ídem, 3 hitos, 1 compromiso | autoridad, fase |

### Actualizados
| Proyecto | Qué cambió | Fuente |
|---|---|---|
| PRY-202, PRY-203, PRY-208 | Nada: ninguno de sus documentos cambió. No se releyeron. | `meta.documents_seen` |

### Lo que el cálculo marca en los 10 proyectos leídos
Cada línea cita el documento de donde sale. Las cifras las calculó el script, no yo.

- **Hitos declarados cerrados sin acta que lo pruebe** (`milestone_met_without_evidence`): PRY-200 (3 hitos), PRY-204 (2: diseño funcional e integración con el core; el ambiente de pruebas sí tiene acta de 2026-10-07), PRY-205 (3; solo el ambiente de pruebas tiene acta de 2026-10-04), PRY-210 (4; solo «Salida a producción» tiene acta, del 2026-10-12), PRY-211 (2). PRY-199 es el único con un hito cerrado y su acta (2026-10-09).
- **Verde contradicho por la evidencia** (`declared_vs_evidence`): PRY-200, PRY-209 y PRY-211 reportan verde y sus propios documentos dicen otra cosa (hitos sin acta y avance rezagado en 200; proyección 10,0 % sobre el aprobado en 209; hitos sin acta en 211).
- **PRY-200:** avance declarado 29 % contra 3 de 4 hitos cerrados (el plan sustenta entre 75 y 100 %). Sin documentos desde el 2026-09-24: 23 días en silencio.
- **PRY-204 y PRY-205:** avance declarado de 58 % y 51 % contra 3 de 4 y 4 de 4 hitos cerrados. En PRY-205 el cierre comprometido era 2026-06-17 y el informe del 2026-10-16 lo reporta en rojo.
- **PRY-210:** el cronograma da los 5 hitos por cerrados, incluida la salida a producción del 2026-01-03, pero el acta de recibo de esa salida es del 2026-10-12 (nueve meses después) y el informe reporta 73 %. En el contrato CT-100, «Licenciamiento del motor» (vencía 2025-07-17) y «Mesa de ayuda» (2025-12-08) siguen sin recibirse, y «Bolsa de horas» figura como recibida sin acta. La factura FV-1100 (413.260.638 COP, 2026-08-24) equivale a dos entregables y solo uno tiene acta.
- **PRY-201:** declarado 63 % con ningún hito cerrado (el plan sustenta hasta 33 %). Compromiso vencido: Elena Duarte, «punto 39», para el 2026-09-28; el acta del comité que lo recoge es del 2026-10-11, o sea que ya nació vencido.
- **PRY-206:** la solicitud CC-01 (+97 días, +194.000.000 COP) está autorizada «por el comité» (el documento no dice cuál), pero no hay cronograma ni línea base nueva que la refleje (`change_without_baseline`).
- **PRY-209:** proyección al cierre 2.640.413.839 contra 2.400.000.000 aprobados (+10,0 %), en verde. La CC-01 (+34 días, +68.000.000 COP) está pendiente de presentarse al comité. El cierre comprometido (2026-09-21) ya pasó y no hay cronograma.
- **PRY-207:** cierre comprometido 2026-03-03 ya pasado, rojo, 63 %, sin cronograma. El cálculo no emite señal porque no hay hitos que medir; eso es un vacío, no una buena noticia.
- **PRY-199:** sin señales. Verde, 20 %, un hito cerrado con acta, nada vencido.
- **Gobierno:** PRY-205 tiene el mismo nombre (Óscar Ramírez) como patrocinador y gerente, y el comité del 2026-10-12 lista a la misma persona dos veces como asistente. Solo lo señalo: los documentos no dicen si hay otra instancia que lo revise.
- **Dinero:** en PRY-201, PRY-207 y PRY-210 lo ejecutado supera lo comprometido (2.541.264.701 vs 2.421.427.933 en 201; 9.436.735.981 vs 8.804.213.210 en 207; 2.270.104.627 vs 1.938.815.478 en 210). Los informes lo traen así; no lo corregí.
- **Autoridad:** ninguna de las 13 fichas la tiene. Las actas no dicen hasta qué monto decide cada gerente sin subir a comité.

Totales del portafolio después del barrido: 13 proyectos, 11 con alertas, 60 alertas, 4 en verde contradicho (PRY-200, 203, 209, 211), 0 sin línea base, 0 problemas de estructura en las fichas.

### No pude leer
| Archivo | Por qué |
|---|---|
| (ninguno) | Los 78 archivos se convirtieron a texto. |

### Movidos desde entrada/
| Archivo | A qué proyecto | Por qué |
|---|---|---|
| (ninguno) | — | La carpeta `entrada/` no existe. |

### Pendientes de clasificar
| Archivo | Por qué no pude decidir |
|---|---|
| (ninguno) | — |

Un archivo suelto: `PRY-202-migración-a-la-nube/2026-10-17-notas-reunion.txt` está en la raíz de su carpeta de proyecto, fuera de `30-reuniones/`. No es de esta corrida (no cambió) y no lo moví.

### Para mirar aparte
El índice de documentos reporta 18 citas de PRY-202 que no resuelven (`source_missing`: acta de constitución, informe de avance, cronograma v2 y factura CT-267). Vienen de la ficha del gerente (`pm_record`), cuyas rutas no llevan el prefijo de la carpeta del proyecto. Los archivos existen en disco. No toqué esa ficha porque no es mía.

## Después
Hay más de un proyecto: puedo armar el informe consolidado (`/criterio-portfolio:portfolio-report`). Hay contradicciones y compromisos vencidos, y están arriba, no esperan al informe.

---
Criterio PMO · criterio-portfolio 0.3.13 · fichas tocadas: 10 (PRY-199, 200, 201, 204, 205, 206, 207, 209, 210, 211) · campos en `not_found`: autoridad y fase en las 10; producto en PRY-205 y PRY-210; hitos en PRY-206, 207 y 209 · Términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.13
