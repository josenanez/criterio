# Corrida del 2026-10-17 · health-check

13 proyectos · 87 s · 60 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 7 |
| `vendor_deliverable_late` | 5 |
| `declared_vs_evidence` | 4 |
| `commitment_undated` | 3 |
| `vendor_accepted_without_evidence` | 3 |
| `variance_cost` | 3 |
| `commitment_rescheduled` | 2 |
| `silent` | 1 |
| `variance_time` | 1 |
| `rebaseline_unauthorized` | 1 |
| `budget_committed` | 1 |
| `change_without_baseline` | 1 |

Diagnóstico de PRY-210 sobre 8 documentos. Dictamen 6 sostenidas, 9 sin sustento, 3 contradichas. No pudo establecer: avance real (73% declarado vs 100% del plan), dinero ejecutado, atraso real (plan nunca actualizado), autoridad del gerente, ni qué ocurrió entre 2025-11-01 y 2026-08-24.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## Diagnóstico · PRY-210 Portal de proveedores · 2026-10-17

**Leí:** 8 documentos · de 2025-05-21 a 2026-10-17 · formatos: .docx (1, leído por su conversión a texto en la caché), .md (6), .csv (1)
**No pude leer:** ninguno. Otras carpetas del portafolio: busqué "PRY-210", "portal de proveedores" y "CT-100" y ningún otro documento los menciona, así que no hay minutas ajenas que cruzar.

Nota de método: la ficha existente (`estado/records/PRY-210.json`) la usé solo para ubicar las fuentes; todo lo de abajo lo contrasté contra los documentos. Las cifras derivadas salen de `portafolio.py compute`.

### Dictamen
**Sostenido:** 6 afirmaciones · **Sin sustento:** 9 · **Contradicho:** 3

Desde esta carpeta se puede afirmar que el proyecto existe con patrocinador, gerente y comité nombrados, que tiene 4.200.000.000 COP aprobados, que el contrato CT-100 con Talento Digital S.A.S. tiene cuatro entregables, que solo uno tiene acta de recibo firmada en su época, que hay una factura radicada por 413.260.638 COP y que el 2026-10-12 se firmó un acta de recibo de "Salida a producción". No se puede afirmar el 73 % de avance, el estado amarillo, ninguna de las cifras de dinero del informe, ni que los cuatro primeros hitos se cumplieron: ninguno tiene un documento detrás. Las 18 afirmaciones evaluadas salen del informe de avance, del cronograma y del contrato. Todas las señales de la ficha vienen de declaraciones o de campos sin marcar: 0 fuentes son evidencia de recibo.

### Gobierno
| | Qué dice el documento | Fuente |
|---|---|---|
| Patrocinador | Camilo Beltrán | Acta de constitución, 2025-05-21 |
| Gerente | Paula Céspedes | Acta de constitución, 2025-05-21; firma las actas de recibo |
| Autoridad declarada | **No está.** El acta no dice qué puede aprobar el gerente en fechas ni en dinero | Acta de constitución, 2025-05-21 |
| Comité | Comité de Riesgos. Una sola minuta (2026-10-15), asisten Paula Céspedes y Camilo Beltrán | Acta; minuta 2026-10-15 |

Más sobre el acta: alcance y exclusiones son texto de plantilla ("Componente 1, 2 y 3"; "Lo que otro proyecto cubre"), y "Dependencias declaradas: Ninguna declarada". Los campos de gobierno tienen 17 meses sin confirmarse. Sin autoridad declarada, ninguna fecha distinta de la del acta tiene aprobación que la respalde.

### Contra el plan
- **Línea base original:** cronograma v1, aprobado 2025-05-21, cierre 2026-01-03 (acta y cronograma coinciden). Inicio 2025-05-31.
- **Vigente:** idéntica a la original en los 5 hitos. Replanificaciones: 0. Solicitudes de cambio: 0.
- **Lo que no cuadra:** el archivo `cronograma-v1.csv` está fechado 2025-05-21 pero trae los 5 hitos en estado "cerrado", incluida la salida a producción. Un plan aprobado en mayo de 2025 no puede saber en esa fecha qué se cerró después; el archivo se editó tras la aprobación, así que no es una línea base de solo agregar. No hay copia anterior contra la cual verificar qué cambió.
- **Salida a producción:** el plan dice 2026-01-03 (original y vigente); el acta de recibo es del 2026-10-12. El cierre comprometido ya pasó y el proyecto sigue abierto al 2026-10-17. `compute` da desviación 0 días contra la original y contra la vigente porque nadie actualizó el plan; esa cifra refleja el archivo, no la realidad. Para medir el atraso real hay que fijar con el gerente la fecha vigente y su motivo.
- **Avance:** el informe declara 73 %; el cronograma marca 5 de 5 hitos cerrados (el plan soporta 100 %). Brecha de 27 puntos, por encima del umbral de 10.

### Hitos vencidos sin evidencia
| Hito | Fecha | Días | Qué documento se esperaría |
|---|---|---|---|
| Diseño funcional aprobado | 2025-07-13 | 461 | Acta de aprobación del diseño firmada |
| Ambiente de pruebas certificado | 2025-08-25 | 418 | Acta o certificado del ambiente |
| Integración con el core | 2025-10-08 | 374 | Acta de pruebas de integración |
| Piloto con usuarios internos | 2025-11-20 | 331 | Acta o informe del piloto |

El quinto hito, Salida a producción, sí tiene acta (2026-10-12), pero esa acta no trae el detalle de lo recibido ni el criterio de éxito "medido".

Entregables del proveedor vencidos (CT-100):
| Entregable | Fecha | Días | Estado |
|---|---|---|---|
| Licenciamiento del motor | 2025-07-17 | 457 | pendiente |
| Mesa de ayuda del primer trimestre | 2025-12-08 | 313 | pendiente (el contrato dice "en curso") |

Además, "Bolsa de horas de desarrollo" figura como "recibido" en el contrato y no existe acta de recibo. La condición de pago del contrato exige acta firmada por el gerente.

### Dinero
| Aprobado | Comprometido | Ejecutado | Proyección | Disponible real |
|---|---|---|---|---|
| 4.200.000.000 | 1.938.815.478 | 2.270.104.627 | 3.916.250.636 | 2.261.184.522 |

Fuente de las cuatro primeras: informe de avance 2026-10-17 (declarado). Aprobado coincide con el acta. Ejecutado 54,1 % y comprometido 46,2 % del aprobado; la proyección queda 6,8 % por debajo del aprobado.

- **Comprometido menor que ejecutado.** Lo ejecutado debería estar contenido en lo comprometido; aquí no. El "disponible real" se calcula sobre lo comprometido, así que probablemente esté sobrestimado, y no puedo decir cuánto sin saber cuál de las dos cifras está mal.
- **Lo único con documento** es la factura FV-1100 del 2026-08-24 por 413.260.638 COP (2 × 206.630.319), con concepto "Entregables del contrato CT-100" sin decir cuáles. Si son los dos marcados "recibido", solo uno tiene acta. Ningún documento respalda los 2.270.104.627 ejecutados ni el resto del compromiso.
- Ejecución de 54,1 % frente a avance declarado de 73 %: las dos cifras no se explican entre sí.

### Lo que se dijo y nadie registró
- **Dependencia:** el informe celebra la "aprobación regulatoria pendiente desde el trimestre anterior". El acta declara "Ninguna" dependencia. Era una dependencia de hecho, no registrada, y no hay documento de la aprobación.
- **Incidencia:** pérdida de dos semanas por rotación de un desarrollador clave. Está solo en el informe, sin responsable ni fecha, y la minuta del comité no la menciona.
- **Riesgos del informe** (proveedor sin fecha de última entrega; conocimiento concentrado en una persona): sin responsable, probabilidad ni impacto, y ausentes de la minuta. El primero es además un hecho, no un riesgo: ya hay dos entregables vencidos.
- **Compromiso de la minuta 2026-10-15:** Jorge Medina, "Entregar el punto 3", para 2026-11-13. Abierto, no vencido. No se puede verificar: el "punto 3" no existe (la minuta lista solo "Avance" y "Compromisos"), y Jorge Medina no figura entre los asistentes ni en ningún otro documento.
- La minuta no registra decisiones ni menciona la salida a producción de tres días antes.

### Contradicho
| Afirmación | Documento A | Documento B |
|---|---|---|
| Avance 73 % | Informe 2026-10-17: 73 % | Cronograma: 5 de 5 hitos "cerrado" (100 %) |
| Salida a producción cumplida en su fecha vigente (2026-01-03, estado "cerrado") | Cronograma v1 | Acta de recibo: 2026-10-12 |
| Comprometido 1.938.815.478 COP | Informe: comprometido | Informe: ejecutado 2.270.104.627 COP, mayor que lo comprometido |

### Sin sustento
Lo que nada contradice y nada respalda:
1. Estado amarillo: ningún documento define el criterio; con dos entregables vencidos y la fecha de cierre superada, el color no se explica solo.
2. "Se ajustó el plan de pruebas con el área de seguridad": sin documento.
3. "Perdió dos semanas por rotación de un desarrollador clave": sin documento.
4. "Se recibió la aprobación regulatoria": sin documento.
5. "Concentración del conocimiento en una sola persona": sin documento.
6. Ejecutado 2.270.104.627 COP: solo hay 413.260.638 facturados.
7. Proyección al cierre 3.916.250.636 COP: sin método ni supuestos.
8. Cuatro hitos cerrados (diseño, ambiente de pruebas, integración, piloto): sin acta ni informe.
9. "Bolsa de horas de desarrollo" recibida: el contrato lo dice, pero no hay acta y el contrato se firmó el 2025-05-28, así que esa columna de estado se editó después.

Sostenido (para completar el conteo): presupuesto aprobado (acta); Parametrización del tarifario recibida (acta 2025-11-01; lo comprometido era 2025-10-21); Licenciamiento del motor pendiente (contrato, sin acta que lo contradiga); proveedor sin fecha de última entrega (coherente con los dos entregables vencidos); factura FV-1100 radicada; acta de recibo de Salida a producción del 2026-10-12.

### Lo que esta carpeta no permite saber
- **Si el proyecto está en producción y medido** (criterio de éxito del acta): el acta de recibo es de dos líneas y no hay medición. Consecuencia: no se puede cerrar ni declarar éxito.
- **Cuánto se atrasó realmente:** el plan nunca se actualizó. Consecuencia: la desviación en tiempo que calcula el sistema (0) es un artefacto y no sirve para comité.
- **Cuánto dinero se gastó y cuánto queda:** falta cualquier registro de ejecución distinto de una factura. Consecuencia: el disponible real no es confiable.
- **Quién autorizó el atraso:** no hay autoridad declarada ni solicitud de cambio. Consecuencia: hay fechas, no desviación aprobada.
- **Qué pasó entre 2025-11-01 y 2026-08-24:** no hay un solo documento en ese tramo. Consecuencia: la historia del proyecto en ese periodo es una caja vacía.
- **Quién es Jorge Medina y qué es el "punto 3".**
- **Estado real del proveedor:** dos entregables vencidos y uno aceptado sin acta, contra una factura por dos.

### Cómo sigue
No recomiendo detener, continuar ni reestructurar: eso lo decide quien tiene la facultad. Con esta carpeta, el diagnóstico es parcial: sirve para decir qué no está respaldado, no para dictaminar el estado real. Puedo preparar el punto de comité con la lista de lo que falta, y llevar al gerente las tres contradicciones como preguntas, una por una.

Sesión sin interfaz: nadie respondió preguntas; las ofertas anteriores quedan sin ejecutar.

---
*Pie de rigor: borrador de trabajo, no decisión ni asesoría. Cada dato citado sale de los documentos listados arriba; la verificación es de quien lo usa. Términos v1.1 aceptados por José Francisco Ñáñez el 2026-10-17 (comprobante en `.criterio/terminos/`).*
