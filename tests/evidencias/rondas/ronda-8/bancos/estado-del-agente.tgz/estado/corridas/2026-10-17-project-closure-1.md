# Corrida del 2026-10-17 · project-closure

13 proyectos · 46 s · 60 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 7 |
| `vendor_deliverable_late` | 5 |
| `declared_vs_evidence` | 4 |
| `commitment_undated` | 3 |
| `vendor_accepted_without_evidence` | 3 |
| `variance_cost` | 3 |
| `commitment_rescheduled` | 2 |
| `silent` | 1 |
| `variance_time` | 1 |
| `rebaseline_unauthorized` | 1 |
| `budget_committed` | 1 |
| `change_without_baseline` | 1 |

Evaluación de cierre de PRY-205 como borrador: nadie declaró el cierre, estado rojo con 51 %. Criterio de éxito no determinable, 3 de 4 hitos cerrados sin evidencia, riesgo regulatorio sin doliente, 2 compromisos abiertos. No supe si está en producción ni medido, ni qué son los componentes ni los puntos 21 y 40.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

**Cierre de PRY-205 · Prevención de lavado de activos · 2026-10-17**

Sale de la ficha `estado/records/PRY-205.json` y de cinco documentos: acta de constitución (2025-06-23), cronograma v1 (2025-06-23), acta de recibo del ambiente de pruebas (2026-10-04), minuta del comité semanal (2026-10-12) e informe de avance (2026-10-16). Las cifras salen de `portafolio.py compute` (corte 2026-10-17). Términos vigentes: aceptados por José Francisco Ñáñez el 2026-10-17 (versión 0.3.13), sin nuevo registro.

**Antes de la tabla:** en los documentos nadie ha declarado que el proyecto terminó. El informe del 2026-10-16 lo declara en **rojo**, con **51 %** de avance. Esto es una evaluación de cierre y un borrador. No es un acta de cierre firmable. Si el proyecto se cierra hoy, se cierra por decisión y no por cumplimiento del criterio de éxito.

### Contra lo comprometido

**Criterio de éxito:** «Prevención de lavado de activos en producción y medido». Fuente: acta de constitución, 2025-06-23.
**Se cumplió:** no se puede determinar. Ningún documento muestra el sistema en producción ni una medición. El único avance declarado es 51 % y el estado es rojo.

| Entregable comprometido | Estado | Evidencia |
|---|---|---|
| Diseño funcional aprobado (línea base 2025-09-28) | El cronograma dice «cerrado» | Ninguna. Sin acta ni aprobación. |
| Ambiente de pruebas certificado (línea base 2025-12-24) | El cronograma dice «cerrado» | Acta de recibo del 2026-10-04, firmada por Óscar Ramírez. |
| Integración con el core (línea base 2026-03-22) | El cronograma dice «cerrado» | Ninguna. |
| Piloto con usuarios internos (línea base 2026-06-17) | El cronograma dice «cerrado» | Ninguna. |
| Alcance: «Componente 1, 2 y 3» | No se puede contrastar | El acta no dice qué es cada componente. |

Contradicción: el cronograma marca los 4 hitos como cerrados, lo que según el script soporta 100 % de avance. El gerente declara 51 %, una brecha de 49.0 puntos. Tres de los cuatro hitos «cerrados» no tienen evidencia de recibo. El script las marca como `milestone_met_without_evidence`: diseño funcional, integración con el core y piloto.

### Fuera de alcance final

| Qué quedó fuera | Decidido por | Cuándo |
|---|---|---|
| Sin dato. Ningún documento registra recortes de alcance. | — | — |

El acta solo dice «Lo que otro proyecto cubre», sin nombrar el proyecto. Control de cambios: 0 solicitudes registradas. El riesgo regulatorio abierto «puede mover el alcance», pero no hay cambio formal.

### Números finales

| | Original | Vigente | Final | Desviación vs original |
|---|---|---|---|---|
| Fecha de cierre | 2026-06-17 | 2026-06-17 | Sin dato (no hay cierre declarado) | 0 días según el script |
| Presupuesto (COP) | 1.200.000.000 | 1.200.000.000 | Ejecutado 211.162.320 (17.6 %) | Proyección 1.199.500.067; -0.0 % sobre el aprobado |

Replanificaciones: **0**.

- **Fecha:** la desviación de 0 días no significa que se cumplió. La fecha comprometida (2026-06-17) ya pasó, el proyecto sigue abierto en rojo y nadie replanificó. Los días transcurridos desde esa fecha no los entrega el script y no los escribo.
- **Presupuesto:** comprometido 890.894.455 (74.2 %). Disponible real 309.105.545.
- **Ritmo:** la proyección al cierre es casi igual al aprobado con solo 17.6 % ejecutado y 51 % de avance. No hay documento que explique cómo se llega a esa cifra.

### RAID al cierre

**Materializados:** ninguno registrado.
**No materializados:** ninguno confirmado como tal.
**Abiertos, con doliente:**

- Riesgo: «Cambio regulatorio en discusión que puede mover el alcance» (informe 2026-10-16). **Sin doliente (`no_identificado`), sin probabilidad, impacto ni fecha.** Por la regla del cierre, no está cerrado.
- Compromiso de Jorge Medina: «Entregar el punto 40», para 2026-11-03 (minuta 2026-10-12). Sigue abierto y no hay documento que diga a qué se refiere el «punto 40».
- Compromiso de Paula Céspedes: «Entregar el punto 21», para 2026-10-21 (minuta 2026-10-12). Sigue abierto, con el mismo problema con el «punto 21».
- Incidencias: ninguna registrada. Dependencias: «Ninguna declarada» en el acta.

### Lecciones

| Qué pasó | Cuándo | Efecto | Qué haríamos distinto |
|---|---|---|---|
| El cronograma v1 marca los 4 hitos como cerrados con fecha vigente igual a la línea base, y no se replanificó nunca (0 replanificaciones) | Cronograma 2025-06-23; informe 2026-10-16 | El cronograma dice 100 % y el gerente 51 %. Tres hitos no tienen evidencia. | Exigir acta de recibo para cerrar un hito en el cronograma. |
| El acta de recibo del ambiente de pruebas certificado tiene fecha 2026-10-04. El hito tenía línea base 2025-12-24 y el cronograma muestra la misma fecha como vigente | 2026-10-04 | El recibo llegó después de la fecha de la línea base, y el cronograma no lo refleja. Los días de diferencia no los entrega el script. | Registrar la fecha real de recibo y replanificar cuando se mueve. |
| El patrocinador y el gerente son la misma persona (Óscar Ramírez), y es quien firma el recibo. En la minuta del 2026-10-12 figura como único asistente, repetido dos veces | Acta 2025-06-23; minuta 2026-10-12 | Ninguna aceptación ni decisión tiene un segundo par de ojos en los documentos. | Separar patrocinio, gerencia y aceptación. |

No incluí lecciones sobre comunicación, riesgo regulatorio ni proveedores: ningún documento permite anclarlas a un hecho con fecha y efecto.

### Sin dato

- Si el sistema está en producción y si se midió: ningún documento lo dice. Esto decide el criterio de éxito.
- Evidencia de aprobación del diseño funcional, de la integración con el core y del piloto.
- Qué son los Componentes 1, 2 y 3, y qué otro proyecto cubre lo excluido.
- Qué son el «punto 40» y el «punto 21».
- Doliente, probabilidad, impacto y fecha del riesgo regulatorio.
- Quién decidiría el cierre. Producto asociado: «No aplica» en el acta; autoridad y fase: no encontrados.
- Cifra final de presupuesto: el informe da ejecutado a 2026-10-16, no un cierre contable.
- Proveedores: ninguno en la ficha.
- El informe y el acta de recibo son PDF sin texto extraíble en el caché del script. Los leí directamente.

### Después

Respuesta tomada por defecto: **no** mover la carpeta a `archivo/` ni congelar la ficha. El proyecto sigue en rojo, con un riesgo sin doliente y dos compromisos abiertos. Mientras tanto debe seguir en el barrido diario. Cuando alguien con autoridad declare el cierre o la cancelación, hay que repetir este cierre con esa decisión como fuente.

*Pie de rigor: borrador de trabajo, no decisión ni asesoría. Cada dato lleva la cita del documento de donde salió y la verificación es suya. Lo que se habló fuera de estos documentos no está aquí.*
