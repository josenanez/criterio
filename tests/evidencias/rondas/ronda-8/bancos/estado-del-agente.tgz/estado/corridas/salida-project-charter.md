**Acta previa:** sí, existe: `PRY-207-onboarding-pyme/00-gobierno/2025-07-02-acta-constitucion.docx`, aprobada el 2025-07-02 (no hay versión posterior).

Términos vigentes (v0.3.13, aceptados por José Francisco Ñáñez el 2026-10-17); no se registraron de nuevo.

## Acta — PRY-207 Onboarding PyME
**Estado:** existe, del 2025-07-02 (modo revisar)

### Qué falta
| Campo | Estado | Consecuencia |
|---|---|---|
| Autoridad del gerente | **No declarada** (no está en el acta ni en el informe de avance) | Ningún cambio de fecha, monto o alcance tiene un umbral que lo resuelva en el proyecto: todo sube al Comité de Riesgos. Hoy hay una reprogramación de salida y un hallazgo de seguridad abiertos (informe 2026-10-07) y no se puede decir si la gerente podía decidirlos sola. |
| Objetivo de negocio | Presente pero **es la solución, no un resultado**: "Entregar onboarding pyme para Banca PyME" | Sin resultado esperado (tiempo de apertura, volumen de cuentas, costo), el proyecto puede terminar "entregado" sin haber servido; el cierre no tiene contra qué compararse. |
| Alcance | **Genérico**: "Componente 1, 2 y 3" | Los componentes no están nombrados; no se puede decir qué quedó dentro ni verificar el 63% reportado contra algo concreto. |
| Exclusiones | **Genérica**: "Lo que otro proyecto cubre" | No nombra qué proyecto ni qué cubre; ante un conflicto de alcance con otro proyecto no hay frontera escrita. |
| Patrocinador | Presente: Ricardo Salas | — |
| Gerente | Presente: Beatriz Cuéllar (en el acta y en el informe del 2026-10-07) | — |
| Comité y cadencia | Comité: Comité de Riesgos. **Cadencia: no declarada** | Sin cadencia no hay fecha en la que el comité esté obligado a mirar el proyecto, que hoy está en rojo. |
| Supuestos y restricciones | **No existen** (solo "Dependencias: ninguna declarada") | El riesgo de concentración del conocimiento en una persona (informe 2026-10-07) no tiene supuesto de origen ni dueño; "ninguna dependencia" contrasta con la ventana de cambio de operaciones que ya forzó una reprogramación. |
| Criterio de éxito | Presente pero **no medible**: "Onboarding PyME en producción y medido" | No dice qué se mide, con qué meta ni quién lo mide; "medido" se cumple con cualquier número. |
| Quién mide el éxito | **No declarado** | Nadie es responsable de decir si el proyecto cumplió. |
| Hitos principales | **No existen** (solo inicio 2025-07-12 y cierre 2026-03-03) | Sin hitos no hay forma de medir desviación intermedia. |

**Dato que no es del acta pero cambia su lectura:** el cierre comprometido (2026-03-03) está vencido hace más de siete meses y el informe del 2026-10-07 reporta 63% sin que exista una línea base nueva ni una solicitud de cambio aprobada en los documentos. Además, el informe muestra **ejecutado (9.436.735.981 COP) mayor que comprometido (8.804.213.210 COP)**, lo que no cuadra y que el informe no explica. La proyección al cierre (17.453.828.510 COP) queda bajo el aprobado (18.000.000.000 COP), pero el informe no dice con qué fecha de cierre se calculó.

### Contenido
**Objetivo de negocio:** "Entregar onboarding pyme para Banca PyME." Pendiente de definir como resultado medible. (Fuente: acta 2025-07-02)
**Alcance:** Componentes 1, 2 y 3, sin nombrar. Pendiente de definir. (Fuente: acta 2025-07-02)
**Exclusiones:** "Lo que otro proyecto cubre", sin nombrar. Pendiente de definir. (Fuente: acta 2025-07-02)
**Patrocinador:** Ricardo Salas · **Gerente:** Beatriz Cuéllar (Fuentes: acta 2025-07-02; informe 2026-10-07)
**Autoridad del gerente:** pendiente de definir (no hay fuente).
**Comité al que reporta:** Comité de Riesgos (aprobó el presupuesto el 2025-07-02) · **Cadencia:** pendiente de definir.
**Presupuesto aprobado:** 18.000.000.000 COP, Comité de Riesgos, 2025-07-02 (Fuente: acta).
**Supuestos:** pendiente de definir · **Restricciones:** pendiente de definir. Dependencias: "ninguna declarada" (acta).
**Criterio de éxito:** "Onboarding PyME en producción y medido." Pendiente de volverlo medible · **Lo mide:** pendiente de definir.
**Hitos principales:** pendiente de definir. Solo constan inicio 2025-07-12 y cierre 2026-03-03 (acta).

### Después
- El acta quedó **sin autoridad declarada**: se ofrece llevar esa definición al Comité de Riesgos como decisión (monto y tipo de cambio que Beatriz Cuéllar puede resolver sin subir), junto con una línea base nueva, porque la vigente está vencida.
- De la revisión salen supuestos a pasar al registro RAID (`/raid-log`): que el conocimiento crítico esté en una sola persona, que la ventana de cambio de operaciones esté disponible y que el área de operaciones y seguridad no sean dependencias externas.

### Pie de rigor
- Leí el acta (vía su copia de texto en caché; la cita apunta al original `.docx`) y el informe de avance del 2026-10-07: son los dos únicos documentos del proyecto.
- No sé qué se acordó fuera de esos documentos (comités, correos, cambios aprobados de palabra); si la autoridad del gerente existe en otro lugar, no la vi.
- No completé ningún campo con valores razonables: lo que no está queda como pendiente de definir.
- Ninguna pregunta quedó sin respuesta porque la sesión no tiene interfaz; no hubo que asumir respuestas sugeridas.
