## Reunión de seguimiento — PRY-202 Migración a la nube · 2026-10-31
6 puntos · 49 minutos · 8 personas requeridas (Camilo Beltrán, Laura Vélez, María Restrepo, Sandra Gil, Natalia Ospina, Ricardo Salas, Óscar Ramírez, Diana Molina)

Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17); no hubo que volver a pedirlos. Fecha tomada de `committee_next` de la configuración; no pasaste un límite de minutos, así que 49 es lo que suman los puntos. Las cifras están calculadas al 2026-10-17: lo vencido llegará más viejo a la reunión. No hay corrida anterior contra la cual comparar (primera corrida), así que «qué cambió» se leyó de las seis actas del comité y de las notas del 10-17.

### Lo que no se destraba solo

> **[1] Qué impide que el documento 1 salga, y una fecha que alguien se crea** · 8 min · **Laura Vélez**
> Prometido para el 2026-09-24, y antes para el 10-03, 10-15, 11-04, 11-24, 12-14 y ahora 12-28: **6 reprogramaciones**. Los documentos no dicen por qué se corre.
> Fuente: comités del 09-05, 09-12, 09-19, 09-26, 10-03 y 10-10; notas del 10-17 («no alcanzó, se compromete para el 28/12/2026»).
> **Si no se resuelve hoy:** el 12-28 se vuelve la séptima fecha; es lo único de la lista que el tiempo empeora.

> **[2] Qué bloquea la prueba 2, y quién del comité lo puede quitar** · 8 min · **María Restrepo** (que además figura como patrocinadora en el acta de constitución: no hay otra persona en la sala por encima de ella para este punto)
> Prometido para el 2026-09-13, y antes para el 10-02, 10-23, 11-05, 11-24 y ahora 12-15: **5 reprogramaciones**.
> Fuente: comités del 09-05 al 10-10 (la última fecha, dicha el 10-10).
> **Si no se resuelve hoy:** pasa de 5 a 6 sin que nadie haya nombrado el bloqueo.

### Vencido sin evidencia
Más viejo primero. «Hace» contado al 10-17.

| Quién | Qué | Desde | Qué se necesita hoy | Min |
|---|---|---|---|---|
| Sandra Gil | Validar el ambiente 12 | 2026-09-24 (23 días) | Acta de recibo, o una fecha nueva dicha en voz alta. Comités 09-19 a 10-10 | 2 |
| Natalia Ospina | Actualizar la matriz 6 | 2026-10-04 (13 días) | Ídem. Y el ambiente 20, vencido el 10-07 (10 días), en el mismo turno | 3 |
| Ricardo Salas | Entregar el punto 8 | 2026-10-05 (12 días) | Dijo el 09-19 que ya lo entregó y no hay acta: o se presenta, o sigue abierto. Mismo turno: entregar el punto 16, vencido el 10-13 (4 días) | 3 |

### Se decide hoy o se atrasa

| Qué | Quién decide | Si no se decide | Min |
|---|---|---|---|
| **CC-01**: ampliación de alcance, +76 días y 152.000.000 COP, solicitada el 2026-10-08 y «pendiente de presentación al comité». El cronograma v2 ya muestra «Salida a producción» en 2027-06-29 contra 2027-04-14 de la línea base, es decir, la fecha nueva está en el plan sin cambio aprobado. Fuente: `20-seguimiento/2026-10-08-solicitud-cambio-cc-01.md`, `10-plan/2026-10-17-cronograma-v2.csv`. Las notas del 10-17 no la mencionan. | El comité. Quién tiene la facultad no está en los documentos (la ficha trae la autoridad como no encontrada); la patrocinadora figura como María Restrepo. | El plan vigente y la línea base aprobada siguen diciendo cosas distintas, y la solicitud lleva 23 días sin decisión a la fecha de la reunión | 10 |
| **Datacore Colombia (CT-267 y CT-243)**: el licenciamiento del motor está sin acta en los dos contratos (vencía el 2026-04-04 en CT-267 y el 2026-05-21 en CT-243). La «Bolsa de horas de desarrollo» de CT-267 figura aceptada **sin acta** y facturada el 2026-08-30 por 428.583.833 COP. Y se dijo al pasar, sin registrarlo, que el proveedor podría no llegar con el equipo completo para la siguiente fase; el informe solo trae que no ha confirmado la fecha de la última entrega. Salida que se pide: el riesgo queda registrado con dueño, y se decide si se pide el acta de la factura. Fuentes: contratos CT-267 y CT-243, factura `2026-08-30-factura-ct-267.pdf`, notas del 10-17, informe de avance del 10-17. | Camilo Beltrán (firma las actas de recibo, según CT-243); Óscar Ramírez trae lo de la «revisión con el proveedor» del 10-27 | Una factura pagada sin acta, un riesgo sin dueño y dos entregables de licenciamiento vencidos que nadie nombra | 10 |
| **Fechas que faltan**: Ricardo Salas, «Aprobar el diseño 13» («por definir» desde el 09-26; el 10-03 dijo que ya lo entregó, sin acta); Diana Molina, «Actualizar la matriz 22» («por definir» desde el 10-10); Laura Vélez, «ajuste del presupuesto» («la otra semana», dicho el 10-17). | Cada doliente, en la sala | Compromisos sin fecha no pueden vencerse, y por eso nunca aparecen vencidos | 3 |

### Vence antes de la próxima
Si no llegan con acta antes del 10-31, entran a la lista de vencidos de la reunión siguiente. No se discuten: se leen en 2 minutos.

| Quién | Qué | Para cuándo |
|---|---|---|
| María Restrepo | Confirmar la fecha 15 (reprogramado 1 vez, antes 2026-09-30) | 2026-10-18 |
| Natalia Ospina | Enviar el documento 9 (reprogramado 1 vez, antes 10-06) | 2026-10-19 |
| Felipe Arango | Aprobar el diseño 5 (reprogramado 1 vez, antes 09-15) | 2026-10-20 |
| Laura Vélez | Actualizar la matriz 14 | 2026-10-21 |
| Diana Molina | Enviar el documento 17 | 2026-10-23 |
| Ricardo Salas | Aprobar el diseño 21 | 2026-10-23 |
| María Restrepo | Cerrar la prueba 10 (reprogramada 1 vez, antes 10-11) | 2026-10-26 |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-27 |

### No es de esta reunión

| Qué | Por qué | Dónde va |
|---|---|---|
| Mauricio Pérez, «Revisar el anexo 19», vencido el 2026-10-15; dijo el 10-10 que ya lo entregó, sin acta | No figura entre los asistentes del 10-17; sin él en la sala el punto no se mueve | Camilo le pide el acta antes de la reunión; si no la hay, entra con él o no entra |
| Hitos «Diseño funcional aprobado» (2026-02-24) e «Integración con el core» (2026-09-19) marcados cumplidos en el cronograma v2, sin acta de recibo | Se resuelve buscando documentos, no hablando entre once personas | Camilo, antes de la reunión; si aparecen, quedan cerrados |
| Fecha de la última entrega del proveedor (informe del 10-17) y pérdida de dos semanas por rotación de un desarrollador clave, ambas sin dueño en el RAID | Los dueños de esos registros no están identificados; formularlas es trabajo previo | `/criterio-project:pm-escalate` o asignar dueño en el RAID |

### Anexo — sin comparación disponible
Esta es la primera corrida: no hay foto anterior para decir «sin cambios desde». Lo que no entra en la reunión porque no vence antes de la próxima ni está trabado: Paula Céspedes, validar el ambiente 4 (2026-11-03, reprogramado 1 vez); Gustavo Neira, cerrar la prueba 18 (2026-11-05, 1 vez); Óscar Ramírez, confirmar la fecha 23 (2026-11-02); Ricardo Salas, entregar el punto 24 (2026-11-02). Cerrados contra acta y fuera de agenda: anexo 3 (Paula Céspedes), fecha 7 (Natalia Ospina), anexo 11 (Gustavo Neira).

Quedaron fuera por tiempo: nada. Si la reunión tiene que ser más corta, se corta de abajo hacia arriba: primero «Fechas que faltan» (3 min), luego la fila de Datacore.

Después de la reunión, `/criterio-project:pm-minutes` sobre las notas; los compromisos que salgan entran a `/criterio-project:pm-commitments`. Esta agenda no convoca a nadie: citar a los ocho es del gerente.
