# Plan — PRY-202 · Migración a la nube · borrador del 2026-10-17
**Desde:** `00-gobierno/2025-11-03-acta-constitucion.docx` (aprobada 2025-11-03) · **Criterio de éxito:** «Migración a la nube en producción y medido.» (acta, sección Criterio de éxito). No dice qué se mide, con qué umbral ni quién lo certifica.

> Aviso de contexto: este proyecto ya tiene línea base (`10-plan/2025-11-03-cronograma-v1.xlsx`) y una versión vigente (`10-plan/2026-10-17-cronograma-v2.csv`), y está en ejecución. Este borrador no las reemplaza ni crea una línea base. Sirve para ver qué sostiene el acta y qué no.

## Lo que le falta al acta
| Qué | Consecuencia de planificar sin eso |
|---|---|
| **Alcance sin contenido real.** Lista «Componente 1», «Componente 2», «Componente 3» | No hay de dónde sacar entregables. La WBS no puede descomponer «Componente 1»; los nodos de abajo salen de los hitos del cronograma y de los contratos, no del alcance. |
| **Fuera de alcance genérico:** «Lo que otro proyecto cubre» | No dice qué proyecto ni qué cosa. CC-01 (Ampliación de alcance, +76 días, +152.000.000 COP) no se puede evaluar contra un límite que no está escrito. |
| **Criterio de éxito sin medida:** «en producción y medido» | No se sabe cuándo el último nodo está terminado, ni quién lo acepta. |
| **Objetivo del negocio genérico:** «Entregar migración a la nube para Riesgo y Cumplimiento» | No hay beneficio ni indicador contra el cual juzgar el alcance. |
| **Sin autoridad declarada** | No se sabe qué puede decidir el gerente (Camilo Beltrán) al planificar y qué debe subir a María Restrepo o al Comité de Banca Empresas. |
| **Dependencias: «Ninguna declarada»**, y sin embargo hay dos contratos con Datacore Colombia | El plan hereda una dependencia externa que el acta no reconoce. |
| Patrocinador: **está** (María Restrepo) | Sin hallazgo. |

Sigo adelante marcando cada hueco. No lo relleno.

## WBS
Cada fila es algo que alguien recibe y acepta. Si el acta no dice quién lo acepta, queda «sin definir».

| # | Entregable | Quién lo acepta | De dónde sale | Duración |
|---|---|---|---|---|
| 1 | Migración a la nube en producción y medida | Sin definir (el acta aprueba el proyecto, no dice quién acepta el resultado) | **del acta** (criterio de éxito) | vacía |
| 1.1 | Diseño funcional aprobado | Sin definir | supuesto (hito del cronograma v1, estado «cerrado») | vacía |
| 1.2 | Ambiente de pruebas certificado | Sin definir | supuesto (hito del cronograma v1, estado «cerrado») | vacía |
| 1.3 | Integración con el core | Sin definir | supuesto (hito del cronograma v1, estado «cerrado») | vacía |
| 1.4 | Piloto con usuarios internos | Sin definir | supuesto (hito del cronograma v1, estado «en curso») | vacía |
| 1.5 | Salida a producción | Sin definir | supuesto (hito del cronograma v1, estado «en curso») | vacía |
| 1.6 | Medición de la migración en producción | Sin definir | **del acta** («y medido»); el contenido de la medición es **sin definir** | vacía |
| 2 | Entregables contractuales de Datacore Colombia | Gerente del proyecto firma el acta de recibo (CT-243 y CT-267, «Condición de pago») | supuesto (contratos; el acta no los menciona) | — |
| 2.1 | Licenciamiento del motor | Gerente del proyecto (acta de recibo) | supuesto (CT-267, comprometido 2026-04-04, «en curso»; CT-243, comprometido 2026-05-21, «en curso») | vacía; las fechas son del contrato, no del plan |
| 2.2 | Bolsa de horas de desarrollo | Gerente del proyecto (acta de recibo) | supuesto (CT-267, comprometido 2026-08-24, «recibido»; CT-243, comprometido 2026-11-27, «en curso») | vacía; ídem |
| 2.3 | Parametrización del tarifario | Gerente del proyecto (acta de recibo) | supuesto (CT-267, comprometido 2027-01-13, «pendiente») | vacía; ídem |

Fuera de la WBS: lo que pide CC-01 («Ampliación de alcance») no está en ninguna fila. La solicitud no dice qué entregable agrega, y sigue «pendiente de presentación al comité».

## Orden
Sin fechas. Todo el orden es mío, no del acta (ver Supuestos).

- 1.1 → 1.2 → 1.3 → 1.4 → 1.5 → 1.6 (secuencia que sigue el cronograma v1).
- 2.1 (licencia del motor) antes de 1.2 y de 2.3.
- 2.3 (parametrización del tarifario) antes de 1.4, si el piloto usa el tarifario.
- 2.2 (bolsa de horas) corre en paralelo a 1.3–1.4. No hay un entregable que dependa de ella con evidencia.
- 1.6 solo cierra cuando 1.5 está en producción y alguien defina qué es «medido».

## Supuestos sobre los que está construido
| Supuesto | Qué pasa si resulta falso |
|---|---|
| Los cinco hitos del cronograma v1 son los entregables del proyecto | Falta un entregable del alcance real, o sobra uno. No se sabe cuál porque el alcance dice «Componente 1/2/3». |
| La secuencia del cronograma es dependencia real y no solo orden de calendario | Hay trabajo que podía ir en paralelo, o dependencias ocultas que mueven la salida a producción. |
| Los entregables de Datacore son parte del alcance de PRY-202 y no un proyecto aparte | La WBS tiene nodos de otro alcance, o falta una parte del proyecto que sí es suyo. |
| Quien firma el acta de recibo de Datacore (el gerente) es quien acepta el entregable ante el negocio | Se paga o se cierra un entregable que el negocio no aceptó. |
| «Licenciamiento del motor» y «Bolsa de horas de desarrollo» de CT-243 y CT-267 son entregables distintos | Si son el mismo, hay un contrato duplicado y facturación posible por lo mismo (ver Sin definir). |
| Las fechas contractuales del proveedor son fiables | El riesgo declarado en el informe del 2026-10-17 («el proveedor no ha confirmado la fecha de la última entrega») ya cuestiona la última. |

Al aprobarse el plan, estos pasan al RAID con doliente.

## Sin definir
| Qué | Quién lo define |
|---|---|
| Alcance real (qué son los «Componentes 1, 2 y 3») | Patrocinador (María Restrepo) con el gerente |
| Qué queda fuera de alcance, y qué proyecto lo cubre | Patrocinador |
| Qué significa «medido» y con qué umbral | Patrocinador / Riesgo y Cumplimiento (área dueña) |
| Quién acepta cada entregable de la WBS (salvo los de Datacore) | Patrocinador |
| Qué puede decidir el gerente sin subir al comité | Patrocinador / Comité de Banca Empresas |
| Por qué hay dos contratos (CT-243 y CT-267) con Datacore con entregables de igual nombre y qué cubre cada uno | Gerente del proyecto con Datacore |
| Qué agrega CC-01 a la WBS | Solicitante (Camilo Beltrán), ante el comité |
| Dependencias externas del proyecto | Gerente del proyecto |

## Proyectos análogos
Ninguno a la vista. La configuración de PRY-202 no apunta a una carpeta de fichas de la PMO, y bajo `documentos/proyectos/` hay otras carpetas de proyectos (PRY-199 a PRY-211) sin fichas que yo pueda citar. No estimo por analogía; esto evita una falsa precisión.

## Preguntas para el equipo
Una por cada duración vacía.

1. ¿Cuánto toma el hito «Diseño funcional aprobado»? ¿Está terminado en el sentido del acta?
2. ¿Cuánto toma certificar el ambiente de pruebas, y quién lo certifica?
3. ¿Cuánto toma la integración con el core?
4. ¿Cuánto toma el piloto con usuarios internos y con cuántos usuarios?
5. ¿Cuánto toma la salida a producción desde que termina el piloto?
6. ¿Cuánto toma medir la migración y qué se mide?
7. ¿Cuánto toma recibir el licenciamiento del motor, y cuál de los dos contratos manda?
8. ¿Cuánto toma la bolsa de horas, y cuál de los dos contratos manda?
9. ¿Cuánto toma la parametrización del tarifario, y cuándo empieza Datacore?

## Para comprometer una fecha falta
- **Disponibilidad real del equipo.** El informe del 2026-10-17 dice que se perdieron dos semanas por la rotación de un desarrollador clave. Ningún documento dice con quién se cuenta de aquí en adelante.
- **Fecha confirmada del proveedor.** El informe lo declara como riesgo abierto. Las notas del 2026-10-17 dicen que Datacore podría no llegar con el equipo completo para la siguiente fase, y que nadie lo anotó como riesgo.
- **Ventana de la sala de producción.** No está en ningún documento.
- **Decisión de CC-01** (+76 días sobre la línea base vigente; coincide con la distancia entre 2027-04-14 y 2027-06-29 en el cronograma v2), que sigue pendiente del comité.
- **Alcance y criterio de «medido» definidos.** Sin ellos no hay cierre que fechar.

Este borrador no compromete ninguna fecha. Esa es una decisión del gerente.
