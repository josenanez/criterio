## PRY-202 Migración a la nube · 2026-10-17

Toca solo el barrido (primero de este proyecto: `last` vacío). Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17), no hubo que registrarlos.

**Revisé:** 20 documentos, todos «nuevos» solo porque el índice del estado se creó hoy · 0 cambiados · 0 renombrados o borrados · 7 reuniones (6 comités + las notas de hoy) ya extraídas en la ficha por `pm-setup` esta misma mañana. No releí los documentos en esta corrida; la ficha ya trae esos compromisos con su cita y no hay ninguna minuta posterior a ella.

### Lo que se venció solo
Nada nuevo desde la ficha de hoy. El recálculo da las mismas 17 señales:
- 6 compromisos vencidos sin evidencia (el más viejo: Sandra Gil, validar el ambiente 12, 23 días).
- 3 sin fecha (Ricardo Salas, diseño 13; Diana Molina, matriz 22; Laura Vélez, ajuste del presupuesto).
- 2 reprogramados por encima del umbral de 3: Laura Vélez, documento 1 (6 veces) y María Restrepo, prueba 2 (5 veces).
- Hitos y proveedor: 2 hitos «cumplidos» sin evidencia, 2 licenciamientos de Datacore vencidos (196 y 149 días), 1 entrega aceptada sin acta, atraso de +76 días (14,7 %) contra la línea base original.

Entre mañana y el 10-23 vencen 6 compromisos más (María Restrepo 10-18, Natalia Ospina 10-19, Felipe Arango 10-20, Laura Vélez 10-21, Diana Molina y Ricardo Salas 10-23).

### La reunión
El comité del 2026-10-31 está a 14 días: aún no toca agenda (ya existe una armada hoy) ni acta (no hay reunión pasada sin acta). El informe toca el 2026-10-30.

### Tu ficha publicada
Al día: se publicó hoy en `00-gobierno/ficha-pm.json` con corte 2026-10-17 y no ha cambiado desde entonces.

**Vuelvo el 2026-10-18.**
