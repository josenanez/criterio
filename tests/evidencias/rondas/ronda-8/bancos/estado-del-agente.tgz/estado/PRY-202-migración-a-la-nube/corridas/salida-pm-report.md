# Migración a la nube (PRY-202) — semana del 2026-10-10 al 2026-10-17

**Declara el gerente:** rojo · 77 % · al 2026-10-17 (Camilo Beltrán, `20-seguimiento/2026-10-17-informe-avance.md`)
**Sustento documental:** sustentado en cuanto al color (la evidencia no contradice el rojo); el 77 % descansa en hitos sin evidencia (ver abajo)
**Lo que el semáforo no explica:** compromisos vencidos, compromisos reprogramados, hitos dados por cumplidos sin evidencia, desviación de tiempo y entregables de proveedor vencidos

> Sobre la declaración: se pidió al gerente, después de mostrarle las señales, que declarara estado y avance. En esta corrida sin interfaz nadie respondió. Se usa la declaración que ya consta en el informe de avance del propio gerente; el agente no propuso ni sugirió ningún estado.

## Qué cambió esta semana
No hay contra qué comparar: la instantánea de hoy (2026-10-17) es la primera de este proyecto y `diff` no encontró cambios. Desde la ficha se ve lo nuevo de esta semana, sin poder decir qué «estaba»:

| Qué | Estaba | Está |
|---|---|---|
| Solicitud de cambio CC-01 (2026-10-08): ampliación de alcance, +76 días, 152.000.000 COP | — | Pendiente de decisión, sin decisor |
| Cronograma v2 (2026-10-17) | Salida a producción 2027-04-14 | 2027-06-29 |
| Acta de recibo 11 (2026-10-10) | «Revisar el anexo 11» abierto | Cumplido, con evidencia |
| Notas de reunión 2026-10-17 | — | 2 compromisos nuevos; «Enviar el documento 1» reprogramado por 6.ª vez |

## Lo que sigue igual y sigue mal
| Qué | Desde | Días así |
|---|---|---|
| Hito «Diseño funcional aprobado» dado por cumplido, sin evidencia | 2026-02-24 | 235 |
| Hito «Integración con el core» dado por cumplido, sin evidencia | 2026-09-19 | 28 |
| Datacore CT-267 · Licenciamiento del motor, pendiente | 2026-04-04 | 196 |
| Datacore CT-243 · Licenciamiento del motor, pendiente | 2026-05-21 | 149 |
| Sandra Gil · Validar el ambiente 12 | 2026-09-24 | 23 |
| Natalia Ospina · Actualizar la matriz 6 | 2026-10-04 | 13 |
| Ricardo Salas · Entregar el punto 8 | 2026-10-05 | 12 |
| Natalia Ospina · Validar el ambiente 20 | 2026-10-07 | 10 |
| Ricardo Salas · Entregar el punto 16 | 2026-10-13 | 4 |
| Mauricio Pérez · Revisar el anexo 19 | 2026-10-15 | 2 |

## Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2027-04-14 | 2027-06-29 | +76 días (14,7 %) sobre la original; umbral 10 % superado |
| Presupuesto | 6.800.000.000 COP aprobado | — | Proyección 6.544.762.976 COP (−3,8 % frente al aprobado) |

Replanificaciones: 0 registradas. La ficha tiene una sola línea base (v1, 2025-11-03) y el cronograma v2 ya trae la fecha 2027-06-29, que es la que CC-01 pide y nadie ha aprobado. Por eso la desviación contra la vigente sale igual a la original (76 días): la fecha se movió sin línea base nueva.

### Hitos de las próximas cuatro semanas (hasta 2026-11-14)
Ninguno. Los siguientes: Piloto con usuarios internos, base y vigente 2026-12-31, pendiente; Salida a producción, base 2027-04-14, vigente 2027-06-29, pendiente. Cumplidos 3 de 5, pero solo «Ambiente de pruebas certificado» tiene evidencia (acta de recibo 2026-10-04). El 77 % declarado cae dentro del rango que el plan sostiene (60–80 %), apoyado en dos hitos sin evidencia.

## Las cifras (COP)
| Aprobado | Comprometido | Ejecutado | Proyectado | Disponible real |
|---|---|---|---|---|
| 6.800.000.000 | 3.838.191.725 | 3.907.353.837 | 6.544.762.976 | 2.961.808.275 |

Disponible real = aprobado − comprometido (no aprobado − ejecutado). Ojo: lo ejecutado supera lo comprometido en 69.162.112 COP, lo cual no debería pasar; hay que preguntar de dónde sale la diferencia.

## Abierto
**Reprogramados:**
- Laura Vélez · «Enviar el documento 1»: 6 veces, de 2026-09-24 a 2026-12-28 (+95 días).
- María Restrepo · «Cerrar la prueba 2»: 5 veces, de 2026-09-13 a 2026-12-15 (+93 días).
(Los dos superan el umbral de 3. Otros reprogramados bajo el umbral: Paula Céspedes, «Validar el ambiente 4», 2 veces.)

**Vencidos sin evidencia:** los seis de la tabla anterior. Tres dicen «ya lo entregué» sin acta: Salas (punto 8), Pérez (anexo 19) y Salas (diseño 13, que además nunca tuvo fecha).
**Sin fecha:** Ricardo Salas · Aprobar el diseño 13; Diana Molina · Actualizar la matriz 22; Laura Vélez · Mandar el ajuste del presupuesto («la otra semana» no es fecha).
**RAID sin movimiento:** 2 riesgos y 2 incidencias, todos sin dueño identificado y sin fecha de último movimiento (no se pueden contar días):
- Riesgo: el proveedor no ha confirmado la fecha de la última entrega.
- Riesgo (dicho en reunión, nadie lo registró): el proveedor podría no llegar con el equipo completo a la siguiente fase.
- Incidencia: dos semanas perdidas por rotación de un desarrollador clave.
- Incidencia: la prueba de carga no alcanzó el umbral pactado y se repite.
**Proveedor (Datacore Colombia):** vencidos: Licenciamiento del motor en CT-267 (196 días) y en CT-243 (149 días). Aceptado sin documento: «Bolsa de horas de desarrollo» (CT-267). Facturado: 428.583.833 COP en CT-267 (factura 2026-08-30), igual al monto de la bolsa de horas aceptada sin acta; el licenciamiento sigue pendiente. CT-243 sin facturar.

## Lo que necesito de alguien
- Quien corresponda decida **CC-01** (+76 días, +152.000.000 COP, ampliación de alcance): sin decisor ni decisión. **Excede la autoridad del gerente: material de comité** (próximo 2026-10-31).
- Laura Vélez y María Restrepo: fecha firme o salida del compromiso; llevan 6 y 5 reprogramaciones.
- Natalia Ospina, Ricardo Salas, Sandra Gil y Mauricio Pérez: entregar o presentar el acta de lo vencido.
- Datacore Colombia: fecha de los dos licenciamientos y el acta de la bolsa de horas.
- Contabilidad / quien lleve los números: explicar por qué lo ejecutado supera lo comprometido.

## Lo que no se sabe
**Sin dato:** producto, autoridad (quién decide por encima del gerente) y fase del proyecto.
**Silencio:** último documento hace 0 días (informe de avance, 2026-10-17) · última reunión hace 0 días (notas de 2026-10-17; último comité semanal el 2026-10-10, hace 7 días).

---
Ficha: `estado/PRY-202-migración-a-la-nube/records/PRY-202.json`, actualizada el 2026-10-17 · 3 campos sin dato · 17 señales abiertas · fuentes leídas: 0 marcadas como evidencia, 2 declaraciones, 15 sin marcar. Términos (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17): https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.13
