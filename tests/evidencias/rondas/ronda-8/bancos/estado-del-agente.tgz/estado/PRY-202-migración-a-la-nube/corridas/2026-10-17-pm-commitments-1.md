# Corrida del 2026-10-17 · pm-commitments

1 proyectos · 36 s · 17 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_overdue` | 6 |
| `commitment_undated` | 3 |
| `milestone_met_without_evidence` | 2 |
| `commitment_rescheduled` | 2 |
| `vendor_deliverable_late` | 2 |
| `variance_time` | 1 |
| `vendor_accepted_without_evidence` | 1 |

Reprogramados: Laura Vélez (documento 1, 6 veces) y María Restrepo (prueba 2, 5 veces); 6 vencidos sin evidencia, 3 sin fecha

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## Compromisos — PRY-202 Migración a la nube · al 2026-10-17

Cifras del cálculo de la corrida: 6 vencidos, 3 sin fecha, 2 reprogramados por encima del umbral (3). Los términos de uso ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17).

### Se viene reprogramando

> **Laura Vélez** · Enviar el documento 1
> Prometido para el 2026-09-24 y reprogramado **6 veces**: 2026-10-03, 2026-10-15, 2026-11-04, 2026-11-24, 2026-12-14 y 2026-12-28 (la última, dicha en la reunión de hoy: «no alcanzó»).
> Fuentes: comités del 09-05, 09-12, 09-19, 09-26, 10-03 y 10-10, y las notas del 10-17.

> **María Restrepo** · Cerrar la prueba 2
> Prometido para el 2026-09-13 y reprogramado **5 veces**: 2026-10-02, 2026-10-23, 2026-11-05, 2026-11-24 y 2026-12-15 (vigente, dicha el 10-10).
> Fuentes: comités del 09-05 al 10-10.

**Cinco o seis veces no es un problema de seguimiento: es un bloqueo que nadie ha nombrado.** Los documentos no dicen por qué se corre la fecha; esa conversación es del gerente. Nota: María Restrepo figura como patrocinadora en el acta de constitución.

### Vencidos sin evidencia
| Quién | Qué | Prometido para | Hace |
|---|---|---|---|
| Sandra Gil | Validar el ambiente 12 | 2026-09-24 | 23 días |
| Natalia Ospina | Actualizar la matriz 6 | 2026-10-04 | 13 días |
| Ricardo Salas | Entregar el punto 8 | 2026-10-05 | 12 días |
| Natalia Ospina | Validar el ambiente 20 | 2026-10-07 | 10 días |
| Ricardo Salas | Entregar el punto 16 | 2026-10-13 | 4 días |
| Mauricio Pérez | Revisar el anexo 19 | 2026-10-15 | 2 días |

Dos de ellos tienen una afirmación sin respaldo: **Ricardo Salas dice que entregó el punto 8** (comité 09-19) y **Mauricio Pérez dice que entregó el anexo 19** (comité 10-10); en ambos casos no se presentó acta y no hay nada en el expediente que lo respalde, así que siguen abiertos. Algo parecido pasa con «Aprobar el diseño 13» de Ricardo Salas (ver sin fecha).

### Vencen esta semana
| Quién | Qué | Para cuándo |
|---|---|---|
| María Restrepo | Confirmar la fecha 15 (ya reprogramado una vez, antes 2026-09-30) | 2026-10-18 |
| Natalia Ospina | Enviar el documento 9 (ya reprogramado una vez, antes 2026-10-06) | 2026-10-19 |
| Felipe Arango | Aprobar el diseño 5 (ya reprogramado una vez, antes 2026-09-15) | 2026-10-20 |
| Laura Vélez | Actualizar la matriz 14 | 2026-10-21 |
| Diana Molina | Enviar el documento 17 | 2026-10-23 |
| Ricardo Salas | Aprobar el diseño 21 | 2026-10-23 |

### Sin fecha
| Quién | Qué | Dicho el |
|---|---|---|
| Ricardo Salas | Aprobar el diseño 13 («por definir»; el 10-03 dijo que ya lo entregó, sin acta) | 2026-09-26 |
| Diana Molina | Actualizar la matriz 22 («por definir») | 2026-10-10 |
| Laura Vélez | Mandar el ajuste del presupuesto («la otra semana», que no es una fecha) | 2026-10-17 |

No pueden estar vencidos; por eso se cuentan aparte.

### Cerrados desde la última revisión
Cerrados contra documento:
- Revisar el anexo 3 (Paula Céspedes): `20-seguimiento/2026-09-19-acta-recibo-3.md`
- Confirmar la fecha 7 (Natalia Ospina): `20-seguimiento/2026-09-19-acta-recibo-7.md`
- Revisar el anexo 11 (Gustavo Neira, reprogramado una vez): `20-seguimiento/2026-10-10-acta-recibo-11.md`

### Aparte
Otros 6 compromisos abiertos vencen después de esta semana, con una reprogramación como máximo: Paula Céspedes, validar el ambiente 4 (2026-11-03, reprogramado 1 vez); María Restrepo, cerrar la prueba 10 (2026-10-26, 1 vez); Gustavo Neira, cerrar la prueba 18 (2026-11-05, 1 vez); Óscar Ramírez, revisión con el proveedor (2026-10-27) y confirmar la fecha 23 (2026-11-02); Ricardo Salas, entregar el punto 24 (2026-11-02).

### Después
- Dos compromisos pasan del umbral de reprogramación (3). Se puede formular **«Enviar el documento 1» y «Cerrar la prueba 2» como decisión para el comité** (próximo 2026-10-31): qué se pide, qué pasa si no se decide y quién tiene la facultad. Excede la autoridad del gerente. Se puede hacer con `/criterio-project:pm-escalate`.
- Si algo de esto cambia lo que dice la ficha, `/criterio-project:pm-publish` lo deja a la vista de la PMO.
