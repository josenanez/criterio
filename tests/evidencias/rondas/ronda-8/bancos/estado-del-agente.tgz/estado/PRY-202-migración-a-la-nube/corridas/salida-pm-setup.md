Soy Samuel. Proceso lo que pasa en tu proyecto y llevo la cuenta de lo que se prometió en cada reunión.

Sesión sin interfaz: nadie respondió preguntas, tomé la respuesta sugerida en cada una.
- Quién eres y qué proyecto es: Camilo Beltrán, gerente de PRY-202 · Migración a la nube (del acta de constitución y el informe de avance).
- Reunión de seguimiento: los sábados, comité semanal (se ve en los nombres de las minutas). Las notas del 2026-10-17 dicen «próxima reunión en dos semanas», así que la anoté para el 2026-10-31.
- Dónde guardo lo que encuentro: `estado/PRY-202-migración-a-la-nube`, fuera de la carpeta de documentación y de `.criterio/`.
- Términos: los mostré y los acepté con el nombre y la fecha que dio la prueba, ver abajo.

**Términos (versión 1.1, familia 0.3.13):**
> Criterio produce borradores de trabajo, no decisiones ni asesoría. Procesa los documentos que usted le indique y dice lo que muestran; no sabe lo que se habló fuera de ellos. Puede equivocarse, y por eso cada dato viene con la cita del documento de donde salió: la verificación es suya. Sus documentos se procesan en la infraestructura de la plataforma de IA, no solo en su equipo. Cada versión se certifica antes de publicarse; garantía y responsabilidad: licencia Apache 2.0. Cada versión se acepta de nuevo y deja un comprobante en Markdown y PDF con su huella SHA-256. Términos completos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal

Aceptados por José Francisco Ñáñez el 2026-10-17 (la prueba indicó ese nombre y esa fecha como el sí explícito).

## Listo — PRY-202 · Migración a la nube

**Lo que miré:** 19 documentos · 6 minutas del comité (2026-09-05 a 2026-10-10) más las notas sueltas del 2026-10-17 · la última del 2026-10-17. Leí las siete en orden, de la más vieja a la más nueva, y las actas de recibo que nombran un compromiso. Todos los formatos se leyeron (.docx, .xlsx y .pdf incluidos).
**Términos:** aceptados para la versión 0.3.13 · comprobante en `.criterio/terminos/aceptacion-criterio-project-0.3.13-2026-10-17.md` y `.pdf` · SHA-256 b8d0cca7fea66fcb… (md) y 28e9cfed31cb47fb… (pdf)

En total son 26 compromisos: 3 cumplidos con acta, 6 vencidos sin evidencia, 14 abiertos con fecha y 3 sin fecha.

### Lo que está abierto, y cuántas veces se ha movido
| Quién | Qué | Para cuándo | Movimientos |
|---|---|---|---|
| Laura Vélez | Enviar el documento 1 | 2026-12-28 (original 2026-09-24) | **6 veces** · `2026-10-17-notas-reunion.txt` |
| María Restrepo | Cerrar la prueba 2 | 2026-12-15 (original 2026-09-13) | **5 veces** · `30-reuniones/2026-10-10-comite-semanal.md` |
| Paula Céspedes | Validar el ambiente 4 | 2026-11-03 (original 2026-09-24) | 2 veces · `30-reuniones/2026-10-10-comite-semanal.md` |
| Felipe Arango | Aprobar el diseño 5 | 2026-10-20 (original 2026-09-15) | 1 vez · `30-reuniones/2026-10-10-comite-semanal.md` |
| Natalia Ospina | Enviar el documento 9 | 2026-10-19 (original 2026-10-06) | 1 vez · `30-reuniones/2026-10-10-comite-semanal.md` |
| María Restrepo | Cerrar la prueba 10 | 2026-10-26 (original 2026-10-11) | 1 vez · `30-reuniones/2026-10-10-comite-semanal.md` |
| María Restrepo | Confirmar la fecha 15 | 2026-10-18 (original 2026-09-30) | 1 vez · `30-reuniones/2026-10-10-comite-semanal.md` |
| Gustavo Neira | Cerrar la prueba 18 | 2026-11-05 (original 2026-10-21) | 1 vez · `30-reuniones/2026-10-10-comite-semanal.md` |
| Laura Vélez | Actualizar la matriz 14 | 2026-10-21 | sin mover · `30-reuniones/2026-10-10-comite-semanal.md` |
| Diana Molina | Enviar el documento 17 | 2026-10-23 | sin mover · `30-reuniones/2026-10-10-comite-semanal.md` |
| Ricardo Salas | Aprobar el diseño 21 | 2026-10-23 | sin mover · `30-reuniones/2026-10-10-comite-semanal.md` |
| Óscar Ramírez | Confirmar la fecha 23 | 2026-11-02 | sin mover · `30-reuniones/2026-10-10-comite-semanal.md` |
| Ricardo Salas | Entregar el punto 24 | 2026-11-02 | sin mover · `30-reuniones/2026-10-10-comite-semanal.md` |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-27 | nuevo · `2026-10-17-notas-reunion.txt` |

**Vencidos sin evidencia** (la fecha pasó y ningún acta lo cierra):
| Quién | Qué | Venció | Días | Cita |
|---|---|---|---|---|
| Sandra Gil | Validar el ambiente 12 | 2026-09-24 | 23 | `30-reuniones/2026-09-19-comite-semanal.md`, sigue en la lista del 10-10 |
| Natalia Ospina | Actualizar la matriz 6 | 2026-10-04 | 13 | `30-reuniones/2026-09-12-comite-semanal.md`, sigue en la lista del 10-10 |
| Ricardo Salas | Entregar el punto 8 | 2026-10-05 | 12 | `30-reuniones/2026-09-19-comite-semanal.md`: dijo que ya lo entregó, sin acta; desde el 09-26 desaparece de la lista sin cierre |
| Natalia Ospina | Validar el ambiente 20 | 2026-10-07 | 10 | `30-reuniones/2026-10-03-comite-semanal.md`, sigue en la lista del 10-10 |
| Ricardo Salas | Entregar el punto 16 | 2026-10-13 | 4 | `30-reuniones/2026-09-26-comite-semanal.md`, sigue en la lista del 10-10 |
| Mauricio Pérez | Revisar el anexo 19 | 2026-10-15 | 2 | `30-reuniones/2026-10-10-comite-semanal.md`: dijo que ya lo entregó, sin acta; desaparece de la lista |

**Cumplidos con acta:** Revisar el anexo 3 (acta del 2026-09-19), Confirmar la fecha 7 (acta del 2026-09-19) y Revisar el anexo 11 (acta del 2026-10-10).

### Sin fecha
Nadie los fechó, así que no pueden estar vencidos y son los que suelen desaparecer:
- Ricardo Salas · Aprobar el diseño 13: «por definir» el 2026-09-26; el 10-03 dijo que ya lo entregó, sin acta, y salió de la lista (`30-reuniones/2026-09-26-comite-semanal.md`).
- Diana Molina · Actualizar la matriz 22: «por definir» (`30-reuniones/2026-10-10-comite-semanal.md`).
- Laura Vélez · Mandar el ajuste del presupuesto: «la otra semana» (`2026-10-17-notas-reunion.txt`).

### Otras señales que levantó el cálculo
- **Plan:** la salida a producción pasó del 2027-04-14 al 2027-06-29, 76 días (14.7 %) contra la línea base original. Coincide con la solicitud de cambio CC-01 (+76 días, 152.000.000 COP), que sigue «pendiente de presentación al comité» (`20-seguimiento/2026-10-08-solicitud-cambio-cc-01.md`).
- **Hitos declarados cerrados sin acta:** «Diseño funcional aprobado» (2026-02-24) e «Integración con el core» (2026-09-19). El acta del 2026-10-04 solo prueba el ambiente de pruebas certificado. Cuéntalos como pendientes de prueba, no como incumplidos.
- **Proveedor Datacore Colombia:** el licenciamiento del motor va 196 días tarde en el CT-267 (vencía 2026-04-04) y 149 en el CT-243 (vencía 2026-05-21), ambos en «pendiente». La bolsa de horas del CT-267 figura recibida en el contrato, sin acta de recibo. La factura FV-1267 (428.583.833 COP, 2026-08-30) está radicada.
- **Dicho en la reunión y sin registrar:** el proveedor podría no llegar con el equipo completo para la siguiente fase. Lo dejé como riesgo con fuente en las notas del 2026-10-17; falta que alguien lo asuma.
- **Estado declarado:** rojo, 77 %, al 2026-10-17. Las señales anteriores quedan fuera de lo que el informe cuenta; el informe no menciona los compromisos vencidos ni los reprogramados.

### Qué le falta a tu carpeta
- Actas de recibo de lo que se dice entregado: los puntos 8, 13 y 19 se dieron por entregados de palabra y ninguno tiene acta, así que se ven igual que uno incumplido.
- Actas de recibo del proveedor (bolsa de horas del CT-267 y el resto de entregables), para poder contrastar lo facturado.
- Quién decide CC-01 y la facultad del gerente sin subir a comité: el acta de constitución no declara ninguna de las dos.
- El acta de constitución no trae fase ni producto asociado (dice «No aplica»), así que esos campos quedaron vacíos.
- Minutas anteriores al 2026-09-05, si existen: la carpeta no trae ninguna, y ahí puede estar otro compromiso movido varias veces.

**Cuándo vuelvo:** el 2026-10-31, la próxima reunión según las notas del 10-17 (el comité es semanal, pero la reunión siguiente quedó a dos semanas).
