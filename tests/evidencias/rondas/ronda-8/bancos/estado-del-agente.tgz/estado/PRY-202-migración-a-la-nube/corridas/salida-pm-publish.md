Términos: vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17); no hizo falta volver a pedirlos.

Recalculé la ficha antes de publicar (corte 2026-10-17). La fecha de cierre vigente es 2027-06-29, tomada del cronograma v2 (2026-10-17); la original del acta, 2027-04-14, queda en `plan.baseline`. Hay 76 días de desvío contra la original (14,7 %).

Publiqué la ficha en `documentos/proyectos/PRY-202-migración-a-la-nube/00-gobierno/ficha-pm.json`, con corte al 2026-10-17.

**Lleva:** 16 campos con dato · 3 sin decir en ninguna parte (`identity.product`, `identity.authority`, `identity.phase`) · declara **rojo** al 2026-10-17 (77 % de avance declarado, informe `20-seguimiento/2026-10-17-informe-avance.md`)

**Lo más viejo que va ahí:** `identity.code`, `identity.name`, `identity.business_area`, `identity.sponsor`, `identity.committee` y `plan.start_date`, del 2025-11-03 (acta de constitución), con 348 días. No pasa de un año.

**Lo que la PMO va a ver de las ocho campos que contrasta:** patrocinador María Restrepo, gerente Camilo Beltrán, comité «Comité de Banca Empresas», producto sin dato (el acta dice «No aplica»), cierre 2027-06-29, aprobado 6.800.000.000 COP, estado rojo, corte 2026-10-17.

Es una copia de la ficha que Samuel ya tenía en su estado; no escribí en ningún otro archivo de la carpeta de documentación. No avisé a nadie: Vera la lee en su próximo barrido.
