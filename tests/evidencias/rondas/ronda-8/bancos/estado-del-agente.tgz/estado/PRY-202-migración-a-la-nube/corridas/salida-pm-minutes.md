# Acta — Migración a la nube (PRY-202) · 2026-10-17
**Asistieron:** Camilo Beltrán, Diana Molina, Felipe Arango, Gustavo Neira, Laura Vélez, María Restrepo, Natalia Ospina, Paula Céspedes, Ricardo Salas, Sandra Gil, Óscar Ramírez · **Fuente:** `2026-10-17-notas-reunion.txt` · **Ausentes con tema en agenda:** ninguno que se pueda decir (las notas no traen agenda). Mauricio Pérez, que estuvo el 10-03, no figura entre los asistentes.

Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17); no hubo que volver a pedirlos.

## Compromisos
| Quién | Qué | Para cuándo | |
|---|---|---|---|
| Laura Vélez | Enviar el documento 1 | 2026-12-28 | **Reprogramado 6 veces** (original 2026-09-24; 10-03, 10-15, 11-04, 11-24, 12-14, 12-28). Cita: «lo de "enviar el documento 1" no alcanzó, se compromete para el 28/12/2026». Mismo doliente, misma promesa, fecha nueva: no es un compromiso nuevo. Pasa el umbral de 3 reprogramaciones. |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-27 | Nuevo. Cita: «revisión con el proveedor, queda para el 2026-10-27». |

### Sin fecha
| Quién | Qué |
|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto — «la otra semana» no es una fecha; se registra como `no_declarada`. |

Siguen sin fecha de reuniones anteriores: Ricardo Salas, «Aprobar el diseño 13» (por definir desde 09-26), y Diana Molina, «Actualizar la matriz 22» (por definir desde 10-10). Esta reunión no los tocó.

## Decisiones
Ninguna. Las notas no recogen ninguna decisión con quién la tomó y qué se descartó.

## Quedó sin decidir
Ninguna cuestión quedó expresamente abierta en las notas. Tampoco hay decisión sobre la solicitud de cambio CC-01 (+76 días, 152.000.000 COP, pendiente desde el 10-08): no se habló de ella en las notas.

## Intenciones sin doliente
Ninguna.

## Dicho al pasar y no registrado
| Qué | Quién lo dijo | Categoría | Ya estaba en el RAID |
|---|---|---|---|
| «El proveedor podría no llegar con el equipo completo para la siguiente fase» — «nadie lo anotó como riesgo» | No se atribuye: las notas dicen «se comentó» | Riesgo (capacidad del proveedor, Datacore Colombia) | No. El RAID del informe de avance solo traía «el proveedor no ha confirmado la fecha de la última entrega», que es otro riesgo (fecha, no equipo). Quedó en la ficha con dueño `no_identificado`, probabilidad e impacto sin valorar. |

## Cerrado en esta reunión
Nada. Se omite el detalle: no se presentó ningún documento.

## Lo que esta reunión contradice
No contradice ningún campo de la ficha. Una observación: las notas dicen «próxima reunión en dos semanas» y el comité venía reuniéndose cada semana (config: `committee: weekly`); la fecha 2026-10-31 de `committee_next` coincide con eso, pero si la cadencia pasa a quincenal, la configuración y las actas del comité deben decirlo.

## Sin resolver de la transcripción
- «se comentó que el proveedor podría no llegar con el equipo completo»: no se sabe quién lo dijo ni a qué fase se refiere («la siguiente fase»; la ficha no tiene fase).
- «la otra semana» (ajuste del presupuesto): no se sabe si es la semana del 10-19 o la siguiente; no se eligió.
- Las notas no dicen a qué presupuesto se refiere el ajuste ni si tiene relación con CC-01.

## Cifras recalculadas (`compute`, sin `record_issues`)
- Compromisos vencidos sin evidencia: 6 (Natalia Ospina ×2, Ricardo Salas ×2, Sandra Gil, Mauricio Pérez). Ninguno de estos cambió en esta reunión.
- Sin fecha: 3. Reprogramados sobre el umbral: 2 (Laura Vélez, documento 1, 6 veces; María Restrepo, prueba 2, 5 veces — esta no se movió hoy).

## Siguiente
`/pm-commitments` para ver el seguimiento completo. `/pm-publish` solo si cambia algún campo de la ficha; esta acta no cambia ninguno. El acta sale aquí y la guardas tú.
