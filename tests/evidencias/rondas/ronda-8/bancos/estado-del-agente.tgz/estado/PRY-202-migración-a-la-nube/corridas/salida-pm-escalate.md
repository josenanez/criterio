## Para decisión — PRY-202 · Migración a la nube · 2026-10-17

Términos: vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17); no hubo que registrar nada.
Nadie respondió preguntas en esta sesión. No me pasaron un tema, así que tomé lo que está marcado como escalable: la autoridad que no está declarada y la solicitud CC-01, que está pendiente.

### Primer punto: el acta no declara la autoridad del gerente

El acta de constitución (2025-11-03) no dice qué puede decidir Camilo Beltrán. Tiene objetivo, alcance, presupuesto, fechas y criterio de éxito, pero ni una línea de facultades. Es el primer punto porque los demás dependen de él: sin autoridad declarada no puedo decir quién tiene la facultad en ninguno.

**¿Se declara por escrito, en una adenda al acta firmada por la patrocinadora, cuánto puede mover el gerente en alcance, tiempo y costo sin ir a comité?** (sí / no / otro umbral)

**Quién decide:** María Restrepo, patrocinadora (acta 2025-11-03). Que le toque a ella es mi lectura, no lo dice el acta.
**Si no se decide hoy:** no encuentro fecha en los documentos. Mientras no se decida, cada solicitud de cambio, incluida CC-01, se va a comité sin saber si valía la pena subirla. El comité siguiente es el 2026-10-31 (configuración y notas del 2026-10-17).

### Segundo punto: CC-01, ampliación de alcance (2026-10-08)

CC-01 pide +76 días y 152.000.000 COP. La autorización dice «Pendiente de presentación al comité» y no tiene fecha. Hay una inconsistencia que debe resolverse antes de llevarla.

- La ficha tiene una sola línea base aprobada: v1, cierre 2027-04-14. El cronograma v2 (2026-10-17) ya muestra «Salida a producción» el 2027-06-29. Eso es exactamente 76 días más que la línea base v1.
- CC-01 dice «+76 días sobre la línea base vigente». Si la vigente es v1, el cambio ya está metido en el cronograma v2 sin que nadie lo haya aprobado. Si la vigente es v2, el cierre sería el 2027-09-13.

**¿Se aprueba CC-01, con cierre en la fecha que el comité confirme de las dos de abajo, o se rechaza y se vuelve al 2027-04-14?**

**Quién decide:** el Comité de Banca Empresas, que aprobó el presupuesto en el acta. Es inferencia: el acta no declara quién aprueba cambios.
**Si no se decide hoy:** no tengo una fecha de vencimiento en los documentos y no la invento. Lo que sí hay es que el cronograma v2 ya circula con el cierre movido, sin cambio aprobado.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar CC-01 sobre v1 (v2 queda como línea base nueva) | Ampliación; el solicitante no dice cuál | Cierre 2027-06-29 (+76 d sobre v1) | +152.000.000 COP (2,2 % del aprobado) |
| B. Aprobar CC-01 sobre v2 | Igual | Cierre 2027-09-13 (+152 d sobre v1) | +152.000.000 COP |
| C. Rechazar | Sin ampliación | Vuelve a 2027-04-14; el cronograma v2 hay que rehacerlo | Sin costo adicional declarado; el costo de volver a 04-14 no está en ningún documento |

**Recomiendo:** primero aclarar si 76 días son sobre v1 o sobre v2, y recién después votar A o B. Hoy no se puede votar una opción con fecha dudosa. Entre A y C no puedo recomendar: ningún documento dice qué incluye la ampliación ni qué pasa si no se hace.

Sobre el costo, un cálculo mío con los números del informe: la proyección al cierre es 6.544.762.976 COP y el aprobado es 6.800.000.000, con holgura de 255.237.024. No sé si la proyección ya incluye los 152.000.000. Además el ejecutado (3.907.353.837) supera al comprometido (3.838.191.725), cosa que no debería pasar y que nadie explica.

### A quién alcanza

`impact` devolvió 0 proyectos alcanzados. Eso significa que en el estado hay una sola ficha (PRY-202), no que nadie dependa de este proyecto. El acta dice «Dependencias declaradas: Ninguna». El acta tampoco dice qué otro proyecto cubre lo excluido («Lo que otro proyecto cubre»). Antes del comité hay que preguntar quién es ese otro proyecto y si su fecha depende de la salida a producción.

| Proyecto | Gerente | ¿Sostiene su fecha? | Dependencia confirmada |
|---|---|---|---|
| ninguno en el estado | — | no se puede saber | ninguna declarada |

### Mis hitos por los que pasa

| Hito | Fecha vigente | En cuántos días |
|---|---|---|
| Piloto con usuarios internos | 2026-12-31 | 75 |
| Salida a producción | 2027-06-29 | 255 |

No sé cuántos días se mueve cada uno. Eso necesita holgura por actividad y la ficha no la tiene.

### Otros puntos que vi, sin armar el paquete

- Compromisos reprogramados tres veces o más: Laura Vélez, «Enviar el documento 1» (6 veces, de 2026-09-24 a 2026-12-28), y María Restrepo, «Cerrar la prueba 2» (5 veces, de 2026-09-13 a 2026-12-15). Ella es la patrocinadora, así que el compromiso lo debe quien decidiría. Es un punto de comité, no un cambio.
- Riesgo sin dueño y sin fecha: el proveedor Datacore no ha confirmado la última entrega y podría no llegar con el equipo completo (comentado el 2026-10-17, nadie lo anotó). Cerca está la «Bolsa de horas» de CT-243, con vencimiento el 2026-11-27. No es un escalamiento hasta que tenga dueño: lo primero es registrarlo.
- Aún sin escalar: nadie ha decidido sobre CC-01 y no existe un registro de decisión que cerrar.

### De dónde sale esto

- Autoridad no declarada: `00-gobierno/2025-11-03-acta-constitucion.docx`; campo `identity.authority` = not_found en la ficha.
- CC-01: `20-seguimiento/2026-10-08-solicitud-cambio-cc-01.md`.
- Línea base v1 (2027-04-14) y cierre v2 (2027-06-29): ficha `plan.baseline` y `10-plan/2026-10-17-cronograma-v2.csv`.
- Presupuesto y proyección: `20-seguimiento/2026-10-17-informe-avance.md`.
- Compromisos reprogramados: `30-reuniones/` (comités del 2026-09-05 al 2026-10-10) y `2026-10-17-notas-reunion.txt`.
- Riesgo del proveedor: `2026-10-17-notas-reunion.txt` y `20-seguimiento/2026-10-17-informe-avance.md`; CT-243: `00-gobierno/2025-11-08-contrato-ct-243.md`.
- Impacto: `portafolio.py impact --code PRY-202 --days 76`.
