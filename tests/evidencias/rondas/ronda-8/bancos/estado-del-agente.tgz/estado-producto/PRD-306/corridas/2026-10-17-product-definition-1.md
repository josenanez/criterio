# Corrida del 2026-10-17 · product-definition

PRD-306 · 14 requerimientos · 30 s · 32 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 11 |
| `evidence_stale` | 10 |
| `requirement_without_acceptance` | 3 |
| `requirement_undecided` | 3 |
| `requirement_accepted_without_evidence` | 2 |
| `requirement_without_owner` | 1 |
| `assumption_unverified` | 1 |
| `claim_vs_metric` | 1 |

La evidencia sostiene débilmente el problema (una entrevista de hace 12 meses); el volumen declarado está 28,9 % sobre lo medido; falta criterio de éxito y quién decide

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## Definición — Microseguros (PRD-306) · contrastada al 2026-10-17
**Documento:** `00-definicion/2026-07-22-definicion-producto.docx` (con `2026-07-22-caso-de-negocio.md`) · **del** 2026-07-22 · 6 afirmaciones

Términos vigentes de la familia 0.3.13, aceptados por José Francisco Ñáñez el 2026-10-17 (comprobante en `.criterio/terminos/`).

### Lo que la evidencia contradice
Nada. Ningún documento dice lo contrario de lo que afirma la definición. La única distancia es la de cifras, en la sección siguiente.

### El negocio y los datos
| Métrica | Declarado | Medido | Diferencia | Las dos fuentes y fechas |
|---|---|---|---|---|
| volumen_mensual | 140.572 | 99.900 | 28,9 % (declarado por encima; umbral 20 %) | Declarado: `00-definicion/2026-07-22-caso-de-negocio.md`, 2026-07-22. Medido: `20-metricas/2026-10-07-tablero-metricas.md` (bodega de datos, tablero de producto), corte 2026-10-07 |

La serie medida tiene un solo punto, así que esto es una diferencia entre dos fechas y no una tendencia. El tablero no dice si hubo campaña en el periodo.

### Afirmaciones numéricas que nadie mide
| Afirma | De qué documento | No hay serie |
|---|---|---|
| «Retorno esperado en 24 meses» | `2026-07-22-caso-de-negocio.md` | Sin cifra, sin base de cálculo y sin ninguna serie que lo mida. Como está escrita no es una cifra contrastable. |

### No está dicho en ninguna parte
- **La propuesta de valor.** La definición solo dice «Propuesta principal» y no la desarrolla.
- **Cuánto pagaría el cliente.** No hay precio, ni disposición a pagar, ni nadie que haya pagado.
- **Qué tan grande es el segmento PyME.** No hay tamaño ni cuántas PyME tienen el problema.
- **De qué se cuenta el «volumen_mensual».** No se define la unidad: pólizas, primas o clientes.
- **Qué proyecto lo construye.** El documento dice «Ninguno declarado», y el cálculo muestra 0 de 11 requerimientos aceptados con proyecto.
- **De dónde sale el retorno de 24 meses.** El caso de negocio da el plazo y nada más.
- **El criterio de éxito.** No está en ningún documento.
- **Quién decide.** El acta del 2026-10-05 lista como único asistente a Mauricio Pérez y no dice quién decide. «Comité de producto» es la propuesta por defecto de la configuración, no algo escrito en un documento.

### Sostenida por un supuesto
| Supuesto | Días sin verificar | Qué haría falta para verificarlo |
|---|---|---|
| La demanda declarada se sostiene sin campaña (declarado 2026-05-04) | 166 (umbral 30) | Una serie de volumen por mes con las fechas de campaña al lado, para separar el volumen con campaña del volumen sin ella. Hoy hay un solo punto (99.900 a 2026-10-07) y no consta si hubo campaña. Además hay que definir qué cifra cuenta como «la demanda declarada», porque la definición no la nombra. |

### Sostenida por evidencia
| Afirmación | Sostenida por | De cuándo | Qué tan fuerte |
|---|---|---|---|
| «El segmento PyME no tiene microseguros» (el problema) | Una entrevista a un «Cliente entrevistado»: «Lo necesito y hoy no lo tengo.» (`10-descubrimiento/2025-09-25-entrevistas.docx`, tema: Necesidad principal) | 2025-09-25 | Débil. Es una persona que dijo que lo necesita, no alguien que pagó. La entrevista no dice que sea PyME y es la única. |
| «El segmento es PyME» | Ninguna directa; solo la propia definición | 2026-07-22 | No sostenida por un documento aparte. |

### Evidencia que ya envejeció
| Afirmación | Lo más nuevo que la sostiene | Hace |
|---|---|---|
| El problema / la necesidad | Entrevista del 2025-09-25 | 12 meses (umbral 12). Es la única evidencia de demanda y ya llegó al límite. Alcanza a 10 de los 14 requerimientos. |

### Lo normativo que toca
| Qué toca | País | Obligación | Norma | Estado |
|---|---|---|---|---|
| Un producto de seguros dirigido a PyME suele caer bajo regulación del sector asegurador y de protección al consumidor | No consta en la configuración ni en los documentos | No determinada | — | **No tengo la norma a la vista.** Esto no es un cumplimiento. Hace falta el país y la norma antes de nombrar ninguna obligación. |

Esto va a revisión jurídica y no la reemplaza.

### Lo que falta para cerrar la definición
- **Criterio de éxito:** no declarado. Sin él la definición no se puede cerrar, porque el cierre se juzga contra él.
- **Quién decide:** no está escrito en ningún documento.
- El problema y para quién (PyME) sí están declarados, pero con la evidencia débil y vieja descrita arriba.

### Después
- El supuesto lleva 166 días sin verificarse. Se puede convertir en riesgo con doliente (raid-taxonomy).
- La definición no está cerrada, así que no corresponde ofrecer `/product-charter`.
