## Verificación previa — REQ-4600 (Microseguros, PRD-306) · 2026-10-17
Términos vigentes de la familia 0.3.13, ya aceptados por José Francisco Ñáñez el 2026-10-17 (comprobante en `.criterio/terminos/`).

| Condición | Resultado |
|---|---|
| Aceptado, no propuesto | Sí: «aceptado», desde 2026-04-11 (`30-decisiones/2026-10-05-comite-producto.md`). Pero el acta no dice **quién** lo aceptó. |
| Criterios de aceptación verificables | Parcial: «se verifica en producción». Es lo único escrito y no dice qué se mide ni con qué umbral. |
| Evidencia de demanda con cita | Débil: una entrevista (2025-09-25) «Lo necesito y hoy no lo tengo.» **No nombra este requerimiento.** Ya tiene 12 meses (umbral 12). |
| Autoridad declarada en la definición | **No.** La definición no la dice; «Comité de producto» es la propuesta por defecto de la configuración. |

Sin interfaz: tomo la respuesta sugerida —seguir sin lo que falta, marcado como vacío del acta, sin rellenarlo—.

# Acta de constitución — Microseguros · REQ-4600 · borrador del 2026-10-17
**Producto:** PRD-306 Microseguros · **Requerimientos:** REQ-4600

## Qué problema resuelve
«El segmento PyME no tiene microseguros.» (`00-definicion/2026-07-22-definicion-producto.docx`, 2026-07-22). El REQ-4600 no tiene necesidad propia escrita: su campo «necesidad» está **no encontrado**; el título es solo «Requerimiento REQ-4600».

## Criterio de éxito
| Criterio | Cómo se verifica | Fuente |
|---|---|---|
| «se verifica en producción» | **No dice cómo.** Sin métrica, umbral ni fecha. | `30-decisiones/2026-10-05-comite-producto.md` |

El criterio de éxito del **producto** no está en ningún documento (`success`: no encontrado). El cierre no se podrá juzgar contra algo medible.

## Alcance
### Entra
| REQ | Título | Evidencia que lo sostiene |
|---|---|---|
| REQ-4600 | «Requerimiento REQ-4600» (sin título descriptivo) | Entrevista 2025-09-25, «Cliente entrevistado», tema Necesidad principal; no nombra el requerimiento (`10-descubrimiento/2025-09-25-entrevistas.docx`). Débil: nadie pagó. |

### No entra
Esta acta cubre solo REQ-4600. Los demás no entran **porque no se pidieron en esta invocación**; no hay otra razón escrita en los documentos. Lo que sí consta de cada uno:

| REQ | Estado y observación (acta 2026-10-05) |
|---|---|
| REQ-4601, REQ-4603, REQ-4604, REQ-4607 | Aceptados, con criterio y con quién lo pidió. Podrían ir en esta u otra acta. |
| REQ-4602, REQ-4609, REQ-4611 | Aceptados **sin criterio de aceptación**. No se pueden incluir sin cerrar eso. |
| REQ-4605, REQ-4613 | Aceptados **sin quién los pidió**. |
| REQ-4612 | Aceptado **sin doliente** («sin asignar»). |
| REQ-4606, REQ-4608, REQ-4610 | **Propuestos**, no aceptados: sin decisión del gerente de producto no entran. |

## Gobierno
- **Patrocinador:** no dicho en ningún documento.
- **Gerente propuesto del proyecto:** no dicho. Mauricio Pérez es el gerente del **producto** (definición, 2026-07-22), no consta que lo sea del proyecto. Asignar a una persona le toca a quien tenga la autoridad.
- **Doliente del requerimiento:** Jorge Medina (acta 2026-10-05).
- **Comité:** el acta del 2026-10-05 lista como único asistente a Mauricio Pérez; la decisión registrada es «Se mantiene el plan» y no existe ningún plan en los documentos.
- **Autoridad del gerente:** **no dicha.** «Comité de producto» es propuesta por defecto de la configuración, no algo escrito.
- **Quién aceptó el REQ-4600:** `decision.who` vacío. La aceptación consta desde 2026-04-11, seis meses antes del único acta de comité, sin registro de esa decisión.

## Supuestos que se llevan al proyecto
| Supuesto | Verificado | Se convierte en riesgo de |
|---|---|---|
| «La demanda declarada se sostiene sin campaña» (declarado 2026-05-04) | No. 166 días sin verificar (umbral 30). Hay un solo punto medido: 99.900 a 2026-10-07; no consta si hubo campaña. | Riesgo del proyecto, **sin doliente**. Se propone al gerente que se nombre; no lo asigno yo. Registrar con raid-taxonomy. |

Distancia de cifras que acompaña al supuesto: volumen_mensual declarado 140.572 (`2026-07-22-caso-de-negocio.md`) frente a 99.900 medido (`20-metricas/2026-10-07-tablero-metricas.md`): 28,9 % por encima, umbral 20 %. La unidad (pólizas, primas o clientes) no está definida.

## Restricciones normativas sin resolver
| Qué toca | Obligación | Norma | Estado |
|---|---|---|---|
| Producto de seguros para PyME | No determinada | — | **No tengo la norma a la vista.** El país no consta en la configuración ni en los documentos. No es un cumplimiento; va a revisión jurídica y no la reemplaza. |

## Vacíos de este acta
| Qué falta | Consecuencia de firmar sin eso | Quién lo cierra |
|---|---|---|
| Autoridad del gerente | Un gerente que no sabe qué puede decidir escala todo o no escala nada. | Quien tenga la autoridad sobre el producto (sin determinar) |
| Criterio de éxito medible (producto y REQ-4600) | El cierre no se puede juzgar meses después. | Gerente de producto |
| Necesidad del REQ-4600 y título descriptivo | El proyecto arranca sin saber qué construye. | Doliente: Jorge Medina |
| Quién aceptó el REQ-4600 y cuándo | Una decisión sin dueño que nadie puede ratificar. | Gerente de producto |
| Evidencia que nombre el requerimiento y sea de PyME | La demanda se apoya en una entrevista de 12 meses que no dice que sea PyME. | Gerente de producto |
| Patrocinador y gerente del proyecto | No hay a quién entregar la ficha. | Sin determinar |
| Doliente del supuesto de demanda | El supuesto no se vuelve riesgo gestionado. | Gerente del proyecto |
| País y norma aplicable | Obligaciones sin revisar. | Jurídico |
| Presupuesto e hitos | El acta no declara ninguno; el caso de negocio solo dice «retorno esperado en 24 meses», sin cifra ni base. | Negocio |

---
**Esto es un borrador.** Lo firma: sin nombrar —quien tenga la autoridad—. **La ficha del proyecto no se crea**: no hay firma, y una ficha sobre un acta sin firmar sería un proyecto que existe en el sistema y no en la organización. Cuando haya firma, se crea con `portafolio.py init` y `identity.product = PRD-306`; el estado declarado queda vacío por diseño.

## Después
El gerente del proyecto, una vez nombrado, instala `criterio-project` y corre `/pm-setup`; cuando publique con `/pm-publish`, `/product-trace` podrá confirmar la traza y Alba sabrá si el producto se construye sin preguntar a nadie.
