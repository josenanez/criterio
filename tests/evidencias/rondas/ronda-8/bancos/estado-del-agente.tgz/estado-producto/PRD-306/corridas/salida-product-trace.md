## Trazabilidad — Microseguros (PRD-306) · al 2026-10-17
11 decididos · 0 con proyecto · 0 confirmados contra la ficha · 0 entregados

### Decidido y nadie lo está construyendo
Ninguno de los 11 requerimientos aceptados nombra un proyecto (`requirement_untraced` ×11). Se muestran del más antiguo al más reciente. El registro guarda la fecha de decisión; no guarda el acta ni quién decidió, así que "Por quién" se declara como no registrado (la autoridad configurada es el Comité de producto).

| REQ | Título | Decidido el | Por quién | Dueño |
|---|---|---|---|---|
| REQ-4602 | Requerimiento REQ-4602 | 2026-03-26 | no registrado | Óscar Ramírez |
| REQ-4601 | Requerimiento REQ-4601 | 2026-04-03 | no registrado | Rubén Cárdenas |
| REQ-4600 | Requerimiento REQ-4600 | 2026-04-11 | no registrado | Jorge Medina |
| REQ-4609 | Requerimiento REQ-4609 | 2026-04-23 | no registrado | Mauricio Pérez |
| REQ-4604 | Requerimiento REQ-4604 | 2026-05-24 | no registrado | María Restrepo |
| REQ-4613 | Requerimiento REQ-4613 | 2026-06-02 | no registrado | Diana Molina |
| REQ-4611 | Requerimiento REQ-4611 | 2026-06-14 | no registrado | Camilo Beltrán |
| REQ-4603 | Requerimiento REQ-4603 | 2026-07-09 | no registrado | Liliana Torres |
| REQ-4607 | Requerimiento REQ-4607 | 2026-07-09 | no registrado | Liliana Torres |
| REQ-4605 | Requerimiento REQ-4605 | 2026-07-28 | no registrado | Laura Vélez |
| REQ-4612 | Requerimiento REQ-4612 | 2026-09-01 | no registrado | sin dueño |

Ojo: el más antiguo lleva 205 días decidido sin proyecto. Además, 3 de estos tienen la decisión debilitada: REQ-4602, REQ-4609 y REQ-4611 sin criterio de aceptación; REQ-4605 y REQ-4613 sin evidencia de demanda; REQ-4612 sin dueño.

### La traza no se confirma
Nada que confirmar: ningún requerimiento dice ejecutarse en un proyecto, así que no hay traza que contrastar con una ficha.

### Lo que un proyecto construye y el registro no tiene
Se revisaron las 13 fichas de `estado/records` (PRY-199 a PRY-211). Ninguna menciona PRD-306, "Microseguros" ni un REQ-46xx. No hay proyecto que, según su ficha, ejecute este producto. Esto no prueba que no exista: puede ser que la ficha no tenga el campo de producto lleno (hallazgo del lado de cada ficha, no de este registro).

### La cadena completa
| REQ | Estado | Decisión | Proyecto | Confirmado | Entregables |
|---|---|---|---|---|---|
| REQ-4600 | aceptado | 2026-04-11 | — | no | — |
| REQ-4601 | aceptado | 2026-04-03 | — | no | — |
| REQ-4602 | aceptado | 2026-03-26 | — | no | — |
| REQ-4603 | aceptado | 2026-07-09 | — | no | — |
| REQ-4604 | aceptado | 2026-05-24 | — | no | — |
| REQ-4605 | aceptado | 2026-07-28 | — | no | — |
| REQ-4607 | aceptado | 2026-07-09 | — | no | — |
| REQ-4609 | aceptado | 2026-04-23 | — | no | — |
| REQ-4611 | aceptado | 2026-06-14 | — | no | — |
| REQ-4612 | aceptado | 2026-09-01 | — | no | — |
| REQ-4613 | aceptado | 2026-06-02 | — | no | — |
| REQ-4606, REQ-4608, REQ-4610 | propuesto | sin decidir (103 a 181 días) | — | — | — |

La cadena se rompe en el primer eslabón después de la decisión: ninguno tiene proyecto.

### Sin fichas a la vista
Hay 13 fichas, pero ninguna corresponde a este producto, de modo que no se pudo confirmar ninguna traza.

### Después
Hay 11 decididos sin proyecto: `/criterio-product:product-charter` para el que esté listo para serlo (los que tienen dueño, criterio de aceptación y evidencia: REQ-4600, REQ-4601, REQ-4603, REQ-4604, REQ-4607).
