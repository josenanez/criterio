No publiqué la ficha de PRD-306 (Microseguros): la configuración no define la carpeta de productos publicados (`config.json` solo trae `documents`, `state` y `fichas`), y no existe ninguna carpeta `productos/publicados`. Sin un sitio común acordado esto no sirve, y acordarlo es una conversación de la organización, no un comando. No inventé la ruta ni escribí ningún archivo.

**Lo que la ficha llevaría, con corte al 2026-10-17:** 14 requerimientos (11 aceptados, 3 propuestos) · 0 proyectos · 1 métrica afirmada
**Segmento declarado:** PyME
**Métricas:** volumen_mensual, 140572, de `documentos/productos/PRD-306/00-definicion/2026-07-22-caso-de-negocio.md` (2026-07-22)

**Para publicar falta:** que la organización acuerde la carpeta común y se configure. Con la ruta lista se vuelve a correr el comando.
