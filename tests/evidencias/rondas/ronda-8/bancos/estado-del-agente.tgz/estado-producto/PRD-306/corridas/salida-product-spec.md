> **Borrador del agente, 2026-10-17. Lo cierra Mauricio Pérez (gerente de producto); lo aprueba el Comité de producto. Este agente no aprueba.**

Términos: ya estaban vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17); no hizo falta registrarlos de nuevo.

# Especificación — Microseguros (PRD-306) · borrador del 2026-10-17

**Lo primero que hay que saber:** este borrador **no puede describir qué debe hacer el producto.** En el registro, los 14 requerimientos tienen como título «Requerimiento REQ-46xx» y ninguno tiene la necesidad escrita (`need`: no encontrada). Escribir el comportamiento sería inventarlo. Lo que sí sale del registro es el alcance por ID, el estado de cada criterio de aceptación y la lista de lo que falta decidir.

## Alcance
### Entra
Los 11 requerimientos en estado `aceptado` (acta de comité 2026-10-05). Por ID, sin descripción, porque el registro no la tiene:

REQ-4600, REQ-4601, REQ-4602, REQ-4603, REQ-4604, REQ-4605, REQ-4607, REQ-4609, REQ-4611, REQ-4612, REQ-4613.

Ninguno está en `en_construccion`: ninguno tiene proyecto que lo ejecute («—» en el acta; «Proyectos que lo construyen: Ninguno declarado» en la definición).

### No entra
- **REQ-4606, REQ-4608, REQ-4610**: siguen en `propuesto`. Especificarlos sería escribir lo que nadie decidió.
- Todo lo que el registro no menciona. En particular, **el registro no dice nada sobre** qué es el microseguro (cobertura, canal, precio, emisión, reclamación), ni qué entrega la «propuesta principal» (la definición solo dice ese rótulo). Nada de eso está decidido por escrito, así que nada de eso entra.
- Diseño, arquitectura, estimación, costo y fechas: no son de este comando.

## Criterios de aceptación

Ningún requerimiento tiene hoy un criterio de aceptación verificable. La prueba (dos personas, mirando lo construido, llegan a la misma respuesta) no la pasa ninguno.

| Criterio | Requerimiento | Cómo se verifica | ¿Se puede medir hoy? |
|---|---|---|---|
| «se verifica en producción» (acta 2026-10-05) | REQ-4600, 4601, 4603, 4604, 4605, 4607, 4612, 4613 | No dice qué se mira ni con qué umbral. Cada persona decidirá distinto qué cuenta como «verificado». | **No es verificable todavía**: no tiene magnitud, umbral ni fuente. |
| — (sin criterio) | REQ-4602, REQ-4609, REQ-4611 | — | **Sin criterio.** Aceptados sin decir cómo se sabrá que están hechos. |

La única medición que hoy existe en el expediente es `volumen_mensual` (tablero de métricas, 2026-10-07: 99.900). Ningún criterio la usa. Conectar alguno a esa métrica sería decisión de producto, no mía: **no propongo umbrales.**

## Supuestos sobre los que está escrita

| Supuesto | Verificado | Quién lo verificaría |
|---|---|---|
| «La demanda declarada se sostiene sin campaña» (definición, declarado el 2026-05-04) | **No.** Lleva 166 días sin verificar; el umbral configurado es 30. | Sin dueño en el documento. Propuesto: Mauricio Pérez, que firma la definición. |
| La cifra de `volumen_mensual` del caso de negocio (140.572, 2026-07-22) sostiene el producto | **Contradicha por la medición**: el tablero marca 99.900 (2026-10-07), 28,9 % por debajo de lo declarado; el umbral configurado es 20 %. | Mauricio Pérez (autor del caso de negocio) con quien mantiene el tablero; el tablero no nombra responsable. |
| La evidencia de demanda alcanza para los 11 requerimientos | **No.** Es una sola frase de un cliente entrevistado el 2025-09-25 («Lo necesito y hoy no lo tengo»), tema «Necesidad principal»; **no nombra ningún requerimiento** y tiene más de 12 meses (umbral: 12). REQ-4605 y REQ-4613 ni siquiera tienen esa. | Mauricio Pérez: reabrir descubrimiento o ligar cada REQ a quien lo pidió. |

## Vacíos

| Qué falta decidir | Consecuencia de no decidirlo | Quién lo cierra |
|---|---|---|
| Qué necesita cada requerimiento (los 14 sin `need`, títulos genéricos) | No hay nada que construir ni que verificar; la especificación queda como índice de IDs. | Cada doliente (ver abajo); Mauricio Pérez consolida. |
| Criterio de aceptación medible para los 8 con «se verifica en producción» | Se aprueba, se construye y se discute al final si cumple. | Dolientes: Jorge Medina (4600), Rubén Cárdenas (4601), Liliana Torres (4603, 4607), María Restrepo (4604), Laura Vélez (4605), Diana Molina (4613); **4612: sin doliente**. |
| Criterio de aceptación para REQ-4602, 4609, 4611 | Aceptados sin forma de saber si están hechos. | Óscar Ramírez (4602), Mauricio Pérez (4609), Camilo Beltrán (4611). |
| REQ-4612 **no tiene doliente** (acta: «sin asignar»; aceptado desde 2026-09-01) | Nadie responde por él ni por su criterio. | Comité de producto, a propuesta de Mauricio Pérez. |
| **Quién aceptó** los 11 requerimientos: ninguno registra decisor. El acta lista como único asistente a Mauricio Pérez y no dice quién decide; la única decisión escrita es «Se mantiene el plan». | La autoridad del comité es una propuesta por defecto de la configuración, no un hecho documentado. Las aceptaciones no son rastreables a una persona. | Comité de producto: dejar constancia de quién decide. |
| Éxito del producto (`success`: no encontrado en la definición) | Sin definición de éxito no hay con qué contrastar los criterios ni el cierre. | Mauricio Pérez. |
| Prioridad de los 14 (ninguna escrita) | Sin orden, no hay secuencia posible para quien construya. | Mauricio Pérez / Comité de producto. |
| Quién pidió REQ-4605 y REQ-4613 (el acta dice «—») y cuáles de los demás pidió realmente «Cliente entrevistado» (la entrevista no los nombra) | Aceptados sin demanda trazable. | Mauricio Pérez (realizó las entrevistas). |
| «Se mantiene el plan»: **no hay plan** en el expediente. | La decisión del comité no apunta a nada. | Mauricio Pérez. |
| Comportamiento en casos borde | No se puede escribir: no hay comportamiento base. Queda abierto para cuando exista la necesidad por requerimiento. | Dolientes de cada REQ. |
| **Lo que otro equipo tiene que hacer**: ningún requerimiento tiene proyecto ni entregable (`traces` vacío en los 14). No hay equipo que haya acordado construir nada, ni dependencias declaradas. | Los 11 aceptados no tienen quién los ejecute. No sé qué otros equipos (emisión, cobro, soporte, aliados) se tocan; no hay un solo documento que lo diga. | Mauricio Pérez con el Comité de producto. |
| **Obligaciones normativas: sin barrido.** Un microseguro es un producto de seguros con consumidores y datos personales. Ningún documento del expediente nombra norma alguna, y no cito obligaciones de memoria. | Se llega a construcción sin saber qué licencias, autorizaciones o reglas de protección al consumidor y de datos aplican. | Sin dueño en el expediente. Propuesto: Mauricio Pérez asigna a Legal/Cumplimiento; con las normas aportadas, se corre el barrido. |

## Requerimientos aceptados que esta especificación no cubre

Ninguno de los 11 aceptados queda fuera de las tablas anteriores, pero **ninguno queda cubierto en sustancia**: entran como ID con criterio no verificable o ausente. Tres de ellos entran solo como vacío:

| REQ | Título | Por qué no |
|---|---|---|
| REQ-4602 | Requerimiento REQ-4602 | Sin criterio de aceptación ni necesidad; no hay sección que escribir. |
| REQ-4609 | Requerimiento REQ-4609 | Ídem. |
| REQ-4611 | Requerimiento REQ-4611 | Ídem. |

Fuera por estado (no son aceptados, por eso no entran): REQ-4606 (Sandra Gil), REQ-4608 (Laura Vélez), REQ-4610 (Liliana Torres), los tres `propuesto`; REQ-4606 y REQ-4608 sin evidencia de demanda.

## Siguiente paso

**No ofrezco `/product-charter` todavía:** los vacíos no están cerrados y la definición no tiene criterio de éxito. Lo mínimo para volver a correr este comando: necesidad y criterio medible por requerimiento, doliente para REQ-4612 y constancia de quién decide.

---
**Pie.** Registro de origen: `estado-producto/PRD-306/requirements/` (14 requerimientos, 11 aceptados), construido sobre el acta de comité del 2026-10-05; tablero de métricas del 2026-10-07; caso de negocio y definición del 2026-07-22; entrevistas del 2025-09-25. Cubre 11 requerimientos, ninguno en sustancia. Términos v1.1 (aceptados por José Francisco Ñáñez, 2026-10-17): https://www.josenanez.com/es/agents/criterio-pmo/legal
