## Registro — Microseguros (PRD-306) · al 2026-10-17
14 requerimientos · 11 decididos · 81.8% con evidencia · 0% con proyecto que lo ejecuta

### Se va a construir y nadie lo pidió
| REQ | Título | Estado | Doliente |
|---|---|---|---|
| REQ-4605 | Requerimiento REQ-4605 | aceptado (2026-07-28) | Laura Vélez |
| REQ-4613 | Requerimiento REQ-4613 | aceptado (2026-06-02) | Diana Molina |

Sin una sola cita de quien lo pidió. Va primero.

### Decidido y nadie lo está construyendo
Los 11 aceptados: ninguno tiene proyecto asociado (0% con proyecto).
| REQ | Título | Decidido el |
|---|---|---|
| REQ-4602 | Requerimiento REQ-4602 | 2026-03-26 |
| REQ-4601 | Requerimiento REQ-4601 | 2026-04-03 |
| REQ-4600 | Requerimiento REQ-4600 | 2026-04-11 |
| REQ-4609 | Requerimiento REQ-4609 | 2026-04-23 |
| REQ-4604 | Requerimiento REQ-4604 | 2026-05-24 |
| REQ-4613 | Requerimiento REQ-4613 | 2026-06-02 |
| REQ-4611 | Requerimiento REQ-4611 | 2026-06-14 |
| REQ-4603 | Requerimiento REQ-4603 | 2026-07-09 |
| REQ-4607 | Requerimiento REQ-4607 | 2026-07-09 |
| REQ-4605 | Requerimiento REQ-4605 | 2026-07-28 |
| REQ-4612 | Requerimiento REQ-4612 | 2026-09-01 |

### Sin doliente, o con un área en vez de una persona
| REQ | Título | Dice |
|---|---|---|
| REQ-4612 | Requerimiento REQ-4612 | (vacío) — aceptado el 2026-09-01 sin doliente |

Los otros 13 tienen una persona como doliente.

### Sin criterio de aceptación
| REQ | Título | Estado |
|---|---|---|
| REQ-4602 | Requerimiento REQ-4602 | aceptado |
| REQ-4609 | Requerimiento REQ-4609 | aceptado |
| REQ-4611 | Requerimiento REQ-4611 | aceptado |

### Decidido sin documento que lo respalde
No se pudo calcular: el cálculo no trae el documento de decisión por requerimiento. No lo declaro vacío ni lleno; hay que revisarlo contra las fichas.

### Lleva meses y nadie lo decide
Umbral: 60 días. Facultad de decidir: Comité de producto (según la configuración).
| REQ | Título | Propuesto hace | Quién tiene la facultad |
|---|---|---|---|
| REQ-4606 | Requerimiento REQ-4606 | 181 días (desde 2026-04-19) | Comité de producto |
| REQ-4608 | Requerimiento REQ-4608 | 169 días (desde 2026-05-01) | Comité de producto |
| REQ-4610 | Requerimiento REQ-4610 | 103 días (desde 2026-07-06) | Comité de producto |

Proponer decidirlos (aceptar o descartar), no cerrarlos por viejos. A los propuestos no se les exige evidencia ni criterio.

### Evidencia vieja
Umbral: 12 meses. Todo lo que sostiene a estos 10 es la misma entrevista de cliente del 2025-09-25 («Lo necesito y hoy no lo tengo.», tema «Necesidad principal»), que **no nombra ninguno de los requerimientos**.
| REQ | Lo más nuevo que lo sostiene | Hace |
|---|---|---|
| REQ-4600, 4601, 4602, 4603, 4604, 4607, 4609, 4611, 4612 | entrevista 2025-09-25 | 12 meses |
| REQ-4610 (propuesto) | entrevista 2025-09-25 | 12 meses |

## Por estado
| propuesto | aceptado | en construcción | entregado | descartado |
|---|---|---|---|---|
| 3 | 11 | 0 | 0 | 0 |

### Fuera del registro, pero salió del mismo cálculo
- Cifra declarada vs medida: volumen_mensual declarado 140.572 (caso de negocio, 2026-07-22) frente a 99.900 medido (tablero de métricas, 2026-10-07): 28.9% por encima, sobre el umbral de 20%.
- Supuesto sin verificar hace 166 días: «La demanda declarada se sostiene sin campaña».
- La definición no tiene criterio de éxito.

Siguiente: `/product-trace` para los 11 decididos sin proyecto. No hay un aceptado con evidencia vigente, criterio y proyecto que justifique `/product-charter` todavía.
