## Listo — Microseguros (PRD-306)

Soy Alba. Trabajo antes de que haya proyecto: miro qué sostiene tu definición y qué se sostiene solo.

**Lo que miré:** 5 documentos · 1 de descubrimiento (una sola entrevista, 2025-09-25) · la definición y el caso de negocio del 2026-07-22 · lo más reciente es el tablero del 2026-10-07. Los 5 se pudieron leer (2 son .docx; ningún formato quedó sin leer).
**Términos:** aceptados (versión 1.1 de los términos, familia 0.3.13) por José Francisco Ñáñez el 2026-10-17 · comprobante en `.criterio/terminos/aceptacion-criterio-product-0.3.13-2026-10-17.md` y `.pdf` · SHA-256 d85e8bd2335ac89a…

**Preguntas:** ninguna se respondió en vivo (sesión sin interfaz); tomé la sugerida en cada una:
- Producto y gerente: Microseguros, PRD-306, Mauricio Pérez (sale de la definición y del caso de negocio).
- Quién decide: «Comité de producto» (propuesta por defecto; ningún documento lo dice: el acta del 2026-10-05 solo lista a Mauricio Pérez como asistente). Confírmalo.
- Dónde guardo: `estado-producto/PRD-306`, hermana de la documentación; no toqué `estado/`.

### Lo que tu definición afirma, y qué lo sostiene
| Afirmación | Sostenida por | De cuándo |
|---|---|---|
| «El segmento PyME no tiene microseguros.» | Una frase de un «cliente entrevistado»: «Lo necesito y hoy no lo tengo.» La entrevista no dice a qué segmento pertenece quien habla | 2025-09-25 (12 meses) |
| volumen_mensual = 140.572 | Caso de negocio. La serie medida dice 99.900 (bodega de datos, tablero de producto): el negocio declara por encima, con una diferencia de 28,9 % | Declarado 2026-07-22 · medido 2026-10-07 |
| «La demanda declarada se sostiene sin campaña» | Es un supuesto, sin verificar | Declarado 2026-05-04 (166 días) |
| Retorno esperado en 24 meses | Nada: el caso de negocio no trae cifra, fuente ni cálculo | — |

### Lo que no está dicho en ninguna parte
- **El criterio de éxito.** Ningún documento lo escribe.
- **De dónde sale 140.572.** El caso de negocio lo cita a sí mismo como fuente; no hay estudio, base de clientes ni cálculo.
- **El tamaño del segmento PyME ni cuántas PyME lo necesitan.** Una entrevista no lo dice.
- **Qué propuesta se construye.** La definición dice «Propuesta principal» y nada más.
- **Qué requerimiento nace de la entrevista.** Los 14 requerimientos del acta dicen «Cliente entrevistado», pero la entrevista no nombra ninguno: es una sola frase de «Necesidad principal». Los 9 aceptados con evidencia cuelgan de esa misma frase.
- **Quién decidió cada aceptación.** El acta no dice quién; la única decisión escrita es «Se mantiene el plan».
- **Qué proyecto ejecuta cada requerimiento.** La definición dice «Ninguno declarado» y el acta pone «—» en los 14.

### Supuestos sobre los que está escrita
Uno declarado: «La demanda declarada se sostiene sin campaña», sin verificar hace 166 días. Con la demanda medida 28,9 % por debajo de la declarada, es el supuesto que más importa verificar. No hay archivo de verificación para PRD-306.

### Lo que dicen los 14 requerimientos del acta (2026-10-05)
11 aceptados y 3 propuestos. Con proyecto que los ejecute: 0 de 11 (0,0 %). Con evidencia: 9 de 11 aceptados (81,8 %), toda de la misma entrevista.
- **Aceptados sin proyecto (11):** REQ-4600, 4601, 4602, 4603, 4604, 4605, 4607, 4609, 4611, 4612, 4613.
- **Aceptados sin criterio de aceptación (3):** REQ-4602, REQ-4609, REQ-4611.
- **Aceptados sin evidencia de quién lo pidió (2):** REQ-4605, REQ-4613 (el acta pone «—»).
- **Aceptado sin doliente (1):** REQ-4612 («sin asignar»).
- **Evidencia vencida (10):** la entrevista del 2025-09-25 cumple hoy 12 meses, el umbral. Afecta a 9 aceptados y a REQ-4610.
- **Propuestos sin decidir (3):** REQ-4606 (181 días), REQ-4608 (169), REQ-4610 (103); el umbral es 60.
- Los 14 se titulan «Requerimiento REQ-46xx» y ningún documento dice el problema de ninguno. Los criterios escritos («se verifica en producción») no son verificables.

### Qué le falta a tu carpeta
Como hallazgo, no como requisito:
- **Más descubrimiento y más reciente.** Hay una entrevista, de hace 12 meses, anterior a la definición.
- **Las transcripciones**, con a quién se entrevistó y qué pidió cada uno.
- **La serie de volumen_mensual.** Hay un solo punto (99.900 el 2026-10-07), así que no se puede ver tendencia.
- **El sustento del 140.572.**
- **Las decisiones del comité con quién decide y por qué.** Sin ellas, un requerimiento descartado se ve igual que uno que nadie miró.

**Siguiente:** `/product-discovery` sobre la entrevista, para ver si de ahí sale algún requerimiento con la cita de quién lo pidió.
