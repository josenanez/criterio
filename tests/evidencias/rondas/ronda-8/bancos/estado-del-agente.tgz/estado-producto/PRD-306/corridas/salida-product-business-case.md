# Caso de negocio — Microseguros (PRD-306) · borrador del 2026-10-17
**Desde:** `00-definicion/2026-07-22-definicion-producto.docx` y `2026-07-22-caso-de-negocio.md`, ambos del 2026-07-22 · **Cifras con fuente:** 1 de 2 (la otra, «retorno esperado en 24 meses», no es una cifra: ver Vacíos)

Términos vigentes de la familia 0.3.13, aceptados por José Francisco Ñáñez el 2026-10-17 (comprobante en `.criterio/terminos/`).

## Qué problema resuelve, y para quién
- **Problema:** «El segmento PyME no tiene microseguros.» (`00-definicion/2026-07-22-definicion-producto.docx`, 2026-07-22)
- **Para quién:** PyME (misma fuente y fecha).
- **Evidencia de demanda:** una sola entrevista a un «Cliente entrevistado»: «Lo necesito y hoy no lo tengo.» (`10-descubrimiento/2025-09-25-entrevistas.docx`, 2025-09-25). Es débil: no dice que sea PyME y no es alguien que haya pagado. Ya tiene 12 meses (umbral 12).

## Qué se construye
Entran al caso los 11 requerimientos **aceptados** (`30-decisiones/2026-10-05-comite-producto.md`, 2026-10-05). Los 3 propuestos (REQ-4606, 4608, 4610) quedan fuera hasta que el comité los decida. Los títulos del registro son genéricos («Requerimiento REQ-46xx»): no dicen qué se construye.

| Requerimiento | Estado | Evidencia de demanda |
|---|---|---|
| REQ-4600, 4601, 4602, 4603, 4604, 4607, 4609, 4611, 4612 | aceptado | «Cliente entrevistado», pero la entrevista del 2025-09-25 no nombra ninguno |
| REQ-4605 | aceptado (2026-07-28) | **Nadie lo pidió**: sin cita de quién |
| REQ-4613 | aceptado (2026-06-02) | **Nadie lo pidió**: sin cita de quién |

Notas del registro que afectan al caso: ninguno de los 11 tiene proyecto que lo ejecute; REQ-4602, 4609 y 4611 no tienen criterio de aceptación; REQ-4612 no tiene doliente.

## Las cifras
| Cifra | Valor | Clase | De dónde sale | De cuándo |
|---|---|---|---|---|
| volumen_mensual (declarada) | 140.572 | Declarada | `00-definicion/2026-07-22-caso-de-negocio.md`, preparado por Mauricio Pérez | 2026-07-22 |
| volumen_mensual (medida) | 99.900 | Medida | `20-metricas/2026-10-07-tablero-metricas.md` (bodega de datos, tablero de producto) | corte 2026-10-07 |
| «Retorno esperado en 24 meses» | sin valor | No es cifra | `2026-07-22-caso-de-negocio.md` da un plazo y nada más | 2026-07-22 |
| «La demanda se sostiene sin campaña» | sin valor | Supuesta | Definición, declarada el 2026-05-04, sin verificar | 2026-07-22 |

La unidad de «volumen_mensual» no está definida en ningún documento (¿pólizas, primas, clientes?).

### Donde la cifra declarada y la medida no coinciden
| Métrica | Declarada | Medida | Las dos fuentes y fechas |
|---|---|---|---|
| volumen_mensual | 140.572 | 99.900 (la declarada está 28,9 % por encima; umbral 20 %) | Declarada: caso de negocio, 2026-07-22. Medida: tablero de métricas, corte 2026-10-07 |

La serie medida tiene un solo punto: es una diferencia entre dos fechas, no una tendencia. El tablero no dice si hubo campaña. Esta diferencia va dentro del caso: es la primera pregunta que haría el comité.

## Los costos
| Concepto | Valor | De dónde sale |
|---|---|---|
| Costo de construir | **No consta** | Ningún documento |
| Costo del equipo | **No consta** | Ningún documento |
| Contratos o cotizaciones | **No constan** | Ningún documento |

Sin el costo de construir no hay caso de negocio que evaluar: hay una propuesta.

## Supuestos sobre los que se sostiene
| Supuesto | Qué pasa si resulta falso | Quién lo verificaría |
|---|---|---|
| La demanda declarada se sostiene sin campaña (declarado 2026-05-04; 166 días sin verificar, umbral 30) | Los 140.572 mensuales dependen de una campaña que el caso no presupuesta, y el volumen medido (99.900) sería el techo sin ella o menos | No consta. Hace falta una serie mensual con las fechas de campaña al lado, y que alguien del negocio diga qué cifra cuenta como «la demanda declarada» |

## Vacíos
| Qué falta | Por qué importa | Quién lo produce |
|---|---|---|
| Costo de construir y de operar | Sin costo no hay caso evaluable | No consta (el negocio / Mauricio Pérez como responsable del producto) |
| De dónde sale el «retorno esperado en 24 meses» | Es un plazo sin cifra ni base de cálculo; no se puede contrastar con nada | El negocio |
| Precio y disposición a pagar | Nadie ha dicho cuánto pagaría una PyME | No consta |
| Tamaño del segmento PyME | Sin él, 140.572 mensuales no se puede situar | No consta |
| Unidad de «volumen_mensual» | Declarada y medida podrían no contar lo mismo | Quien mantiene el tablero y quien redactó el caso |
| Qué pasa si no se hace; alternativas consideradas | El caso no las dice | El negocio |
| Criterio de éxito | No está en ningún documento | El negocio |
| Quién decide | El acta del 2026-10-05 lista solo a Mauricio Pérez y no dice quién decide; «Comité de producto» es la propuesta por defecto de la configuración | La autoridad del producto |
| País y norma aplicable | Producto de seguros: no tengo la norma a la vista. No es un juicio de cumplimiento; va a revisión jurídica | Jurídico |
| Quién construye | 0 de 11 aceptados con proyecto | Comité / PMO |

## Cómo se sabrá si funcionó
**No está declarado.** La definición no tiene criterio de éxito y el caso solo dice «retorno esperado en 24 meses», sin métrica ni fecha de corte. Sin esto el producto no se puede cerrar meses después. La única métrica con serie es volumen_mensual; ponerla como criterio, con su valor y su fecha, es una decisión del negocio, no mía.

## Si hay otros productos publicados
No hay ninguno publicado a la vista: la carpeta `estado/` existe con los códigos PRD-299 a PRD-309, pero sin fichas dentro. El cruce de volumen_mensual con otros productos no se pudo hacer.

---
Este documento no recomienda aprobar ni rechazar, no calcula rentabilidad ni periodo de recuperación y no estima ninguna cifra: con un costo ausente y un supuesto sin verificar, cualquier número sería una opinión.

**Después:** ofrezco pasar el supuesto «sin campaña» al seguimiento (assumption-tracking). `/product-charter` no corresponde todavía: la definición no está cerrada.
