## Microseguros (PRD-306) · 2026-10-17

**Primera corrida: no hay corte anterior.** Toda señal abierta se reporta como línea base; desde hoy solo se reportará lo que cruce un umbral después de este corte (`snapshots/2026-10-17.json`). Términos vigentes (v0.3.13, aceptados por José Francisco Ñáñez el 2026-10-17). Tocaba `review`; no tocaba `report` (`committee_next` está vacío en la configuración).

### Lo que necesita decisión
| Qué | REQ | Cuánto lleva | Qué se necesita | Quién |
|---|---|---|---|---|
| Propuesto sin decidir | REQ-4606 | 181 días (desde 2026-04-19) | Que el Comité de producto lo decida o lo descarte; el dato que falta es quién tiene la facultad | Sandra Gil (doliente) / Comité de producto |
| Propuesto sin decidir | REQ-4608 | 169 días (desde 2026-05-01) | Ídem | Laura Vélez / Comité de producto |
| Propuesto sin decidir | REQ-4610 | 103 días (desde 2026-07-06) | Ídem; además su única evidencia tiene 12 meses | Liliana Torres / Comité de producto |
| Supuesto sin verificar: «La demanda declarada se sostiene sin campaña» | — | 166 días (umbral 30) | Una medición de demanda en un periodo sin campaña. Ya pasó el punto en que conviene tratarlo como riesgo registrado (assumption-tracking) | Mauricio Pérez |
| Lo declarado contra lo medido: volumen mensual | — | declarado 140.572 (caso de negocio, 2026-07-22) frente a 99.900 medido (tablero, 2026-10-07): 28,9 % por encima (umbral 20 %) | Que el negocio corrija la cifra o explique la diferencia; el supuesto de arriba es la hipótesis más cercana | Mauricio Pérez / Comité de producto |

### Aceptado sin sustento
- **Sin evidencia de demanda:** REQ-4605 y REQ-4613.
- **Sin criterio de aceptación:** REQ-4602, REQ-4609 y REQ-4611.
- **Sin doliente:** REQ-4612 (aceptado el 2026-09-01).
- **Evidencia vencida (12 meses, entrevista del 2025-09-25):** REQ-4600, 4601, 4602, 4603, 4604, 4607, 4609, 4610, 4611 y 4612. Se queda sin sustento la afirmación de que la necesidad sigue vigente en esos requerimientos. Además, la entrevista habla de una «necesidad principal» y no nombra ninguno de ellos.

### Las trazas
Ninguno de los 11 requerimientos aceptados tiene proyecto (`traced` = 0 %). Se leyeron las 13 fichas de `estado/records` (PRY-199 a PRY-211): ninguna nombra PRD-306 ni Microseguros. No hay traza que confirmar ni que haya dejado de decirse. Esto no prueba que nadie esté construyendo: dice que ninguna ficha lo declara.

### Del descubrimiento
No hay lectura previa contra la cual comparar. El único documento de descubrimiento es la entrevista del 2025-09-25. No se ofrece `/product-discovery` ni `/product-definition`.

### Lo que no sé
- El criterio de éxito de la definición no está dicho en ningún documento (`success`: desconocido).
- No sé si lo aceptado se está construyendo fuera de lo que las fichas declaran.

**Vuelvo el 2026-11-16.**
