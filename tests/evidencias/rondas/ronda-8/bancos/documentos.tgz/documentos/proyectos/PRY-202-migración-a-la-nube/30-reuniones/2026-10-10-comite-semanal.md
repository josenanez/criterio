# Comité de Banca Empresas · Migración a la nube

**Fecha:** 2026-10-10
**Asistentes:** Camilo Beltrán, Diana Molina, Felipe Arango, Gustavo Neira, Laura Vélez, María Restrepo, Natalia Ospina, Paula Céspedes, Ricardo Salas, Sandra Gil, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Laura Vélez | Enviar el documento 1 | 2026-12-14 |
| María Restrepo | Cerrar la prueba 2 | 2026-12-15 |
| Paula Céspedes | Validar el ambiente 4 | 2026-11-03 |
| Felipe Arango | Aprobar el diseño 5 | 2026-10-20 |
| Natalia Ospina | Actualizar la matriz 6 | 2026-10-04 |
| Natalia Ospina | Enviar el documento 9 | 2026-10-19 |
| María Restrepo | Cerrar la prueba 10 | 2026-10-26 |
| Sandra Gil | Validar el ambiente 12 | 2026-09-24 |
| Laura Vélez | Actualizar la matriz 14 | 2026-10-21 |
| María Restrepo | Confirmar la fecha 15 | 2026-10-18 |
| Ricardo Salas | Entregar el punto 16 | 2026-10-13 |
| Diana Molina | Enviar el documento 17 | 2026-10-23 |
| Gustavo Neira | Cerrar la prueba 18 | 2026-11-05 |
| Natalia Ospina | Validar el ambiente 20 | 2026-10-07 |
| Ricardo Salas | Aprobar el diseño 21 | 2026-10-23 |
| Diana Molina | Actualizar la matriz 22 | por definir |
| Óscar Ramírez | Confirmar la fecha 23 | 2026-11-02 |
| Ricardo Salas | Entregar el punto 24 | 2026-11-02 |

## Cerrados en esta reunión

- Revisar el anexo 11 (Gustavo Neira): recibido, acta de recibo del 2026-10-10.

## Lo que se dijo

- Mauricio Pérez dice que ya entregó «revisar el anexo 19». No se presentó acta.
