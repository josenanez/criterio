# Solicitud de cambio CC-01

**Proyecto:** PRY-209 · Nómina electrónica
**Fecha:** 2026-10-11
**Solicitante:** Paula Céspedes

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +34 días sobre la línea base vigente |
| Costo | 68.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
