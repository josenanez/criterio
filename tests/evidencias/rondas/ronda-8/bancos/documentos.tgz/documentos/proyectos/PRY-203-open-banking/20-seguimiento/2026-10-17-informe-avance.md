# Informe de avance · Open Banking

**Código:** PRY-203
**Fecha de corte:** 2026-10-17
**Gerente:** María Restrepo

## Estado declarado

**Verde**

Avance reportado: **39%**

## Lo que pasó en el periodo

- Dos historias quedaron fuera del alcance del sprint por dependencia con el core
- Se recibió la aprobación regulatoria pendiente desde el trimestre anterior
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales

## Presupuesto

| | COP |
|---|---|
| Aprobado | 6.800.000.000 |
| Comprometido | 6.145.585.663 |
| Ejecutado | 1.436.705.266 |
| Proyección al cierre | 8.099.349.061 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
