# Comité de Transformación Digital · Open Banking

**Fecha:** 2026-10-12
**Asistentes:** María Restrepo, Natalia Ospina

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Paula Céspedes | Entregar el punto 23 | 2026-10-12 |
| Laura Vélez | Entregar el punto 33 | 2026-11-07 |
