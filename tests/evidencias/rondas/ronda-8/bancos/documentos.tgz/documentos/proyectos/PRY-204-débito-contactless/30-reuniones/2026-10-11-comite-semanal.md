# Comité de Arquitectura · Débito contactless

**Fecha:** 2026-10-11
**Asistentes:** Sandra Gil, Rubén Cárdenas

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| María Restrepo | Entregar el punto 19 | 2026-10-23 |
