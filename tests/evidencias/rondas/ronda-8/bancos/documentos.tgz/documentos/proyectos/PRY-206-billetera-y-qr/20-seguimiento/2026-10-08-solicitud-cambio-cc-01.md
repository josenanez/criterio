# Solicitud de cambio CC-01

**Proyecto:** PRY-206 · Billetera y QR
**Fecha:** 2026-10-08
**Solicitante:** Rubén Cárdenas

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +97 días sobre la línea base vigente |
| Costo | 194.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
