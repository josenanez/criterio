# Acta de recibo · Parametrización del tarifario

**Proyecto:** PRY-210 · Portal de proveedores
**Fecha de recibo:** 2025-11-01
**Recibido por:** Paula Céspedes

Se recibe a satisfacción el entregable **Parametrización del tarifario**.

Contrato CT-100 · Talento Digital S.A.S..
