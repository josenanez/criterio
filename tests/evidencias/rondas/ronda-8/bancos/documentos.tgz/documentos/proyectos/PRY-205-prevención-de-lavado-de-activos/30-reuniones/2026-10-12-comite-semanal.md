# Comité de Transformación Digital · Prevención de lavado de activos

**Fecha:** 2026-10-12
**Asistentes:** Óscar Ramírez, Óscar Ramírez

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Jorge Medina | Entregar el punto 40 | 2026-11-03 |
| Paula Céspedes | Entregar el punto 21 | 2026-10-21 |
