# Informe de avance · Migración a la nube

**Código:** PRY-202
**Fecha de corte:** 2026-10-17
**Gerente:** Camilo Beltrán

## Estado declarado

**Rojo**

Avance reportado: **77%**

## Lo que pasó en el periodo

- El equipo perdió dos semanas por rotación de un desarrollador clave
- Se recibió la aprobación regulatoria pendiente desde el trimestre anterior
- La prueba de carga no alcanzó el umbral pactado y se repite

## Presupuesto

| | COP |
|---|---|
| Aprobado | 6.800.000.000 |
| Comprometido | 3.838.191.725 |
| Ejecutado | 3.907.353.837 |
| Proyección al cierre | 6.544.762.976 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
