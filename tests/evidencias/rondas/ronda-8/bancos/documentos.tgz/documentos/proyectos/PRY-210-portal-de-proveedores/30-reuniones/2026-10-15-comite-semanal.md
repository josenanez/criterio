# Comité de Riesgos · Portal de proveedores

**Fecha:** 2026-10-15
**Asistentes:** Paula Céspedes, Camilo Beltrán

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Jorge Medina | Entregar el punto 3 | 2026-11-13 |
