# Solicitud de cambio CC-01

**Proyecto:** PRY-202 · Migración a la nube
**Fecha:** 2026-10-08
**Solicitante:** Camilo Beltrán

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +76 días sobre la línea base vigente |
| Costo | 152.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
