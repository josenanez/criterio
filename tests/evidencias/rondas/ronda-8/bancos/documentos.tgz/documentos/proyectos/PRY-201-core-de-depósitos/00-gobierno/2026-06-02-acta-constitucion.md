# Acta de constitución · Core de depósitos

**Código:** PRY-201
**Área dueña:** Banca de Personas
**Patrocinador:** Carlos Peña
**Gerente de proyecto:** Laura Vélez
**Comité:** Comité de Arquitectura
**Producto asociado:** cuenta de ahorros
**Fecha de aprobación:** 2026-06-02

## Objetivo del negocio

Entregar core de depósitos para Banca de Personas.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**4.200.000.000 COP**, aprobado por Comité de Arquitectura el 2026-06-02.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-06-12 |
| Cierre | 2027-09-28 |

## Criterio de éxito

Core de depósitos en producción y medido.

## Dependencias declaradas

- Ninguna declarada
