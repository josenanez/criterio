# Informe de avance · Onboarding PyME

**Código:** PRY-207
**Fecha de corte:** 2026-10-07
**Gerente:** Beatriz Cuéllar

## Estado declarado

**Rojo**

Avance reportado: **63%**

## Lo que pasó en el periodo

- Se reprogramó la salida por ventana de cambio del área de operaciones
- Se levantó un hallazgo de seguridad en la revisión de arquitectura

## Presupuesto

| | COP |
|---|---|
| Aprobado | 18.000.000.000 |
| Comprometido | 8.804.213.210 |
| Ejecutado | 9.436.735.981 |
| Proyección al cierre | 17.453.828.510 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
