# Comité de Banca Empresas · Migración a la nube

**Fecha:** 2026-09-26
**Asistentes:** Camilo Beltrán, Felipe Arango, Gustavo Neira, Laura Vélez, María Restrepo, Natalia Ospina, Paula Céspedes, Ricardo Salas, Sandra Gil

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Laura Vélez | Enviar el documento 1 | 2026-11-04 |
| María Restrepo | Cerrar la prueba 2 | 2026-11-05 |
| Paula Céspedes | Validar el ambiente 4 | 2026-10-14 |
| Felipe Arango | Aprobar el diseño 5 | 2026-09-15 |
| Natalia Ospina | Actualizar la matriz 6 | 2026-10-04 |
| Natalia Ospina | Enviar el documento 9 | 2026-10-19 |
| María Restrepo | Cerrar la prueba 10 | 2026-10-11 |
| Gustavo Neira | Revisar el anexo 11 | 2026-10-02 |
| Sandra Gil | Validar el ambiente 12 | 2026-09-24 |
| Ricardo Salas | Aprobar el diseño 13 | por definir |
| Laura Vélez | Actualizar la matriz 14 | 2026-10-21 |
| María Restrepo | Confirmar la fecha 15 | 2026-09-30 |
| Ricardo Salas | Entregar el punto 16 | 2026-10-13 |
