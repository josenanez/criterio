# Comité de Arquitectura · Core de depósitos

**Fecha:** 2026-10-11
**Asistentes:** Laura Vélez, Carlos Peña

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Camilo Beltrán | Entregar el punto 23 | 2026-11-06 |
| Elena Duarte | Entregar el punto 39 | 2026-09-28 |
