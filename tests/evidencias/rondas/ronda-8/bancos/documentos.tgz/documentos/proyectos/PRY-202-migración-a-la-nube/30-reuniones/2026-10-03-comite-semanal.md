# Comité de Banca Empresas · Migración a la nube

**Fecha:** 2026-10-03
**Asistentes:** Camilo Beltrán, Diana Molina, Felipe Arango, Gustavo Neira, Laura Vélez, María Restrepo, Mauricio Pérez, Natalia Ospina, Paula Céspedes, Ricardo Salas, Sandra Gil

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Laura Vélez | Enviar el documento 1 | 2026-11-24 |
| María Restrepo | Cerrar la prueba 2 | 2026-11-24 |
| Paula Céspedes | Validar el ambiente 4 | 2026-11-03 |
| Felipe Arango | Aprobar el diseño 5 | 2026-10-20 |
| Natalia Ospina | Actualizar la matriz 6 | 2026-10-04 |
| Natalia Ospina | Enviar el documento 9 | 2026-10-19 |
| María Restrepo | Cerrar la prueba 10 | 2026-10-11 |
| Gustavo Neira | Revisar el anexo 11 | 2026-10-15 |
| Sandra Gil | Validar el ambiente 12 | 2026-09-24 |
| Laura Vélez | Actualizar la matriz 14 | 2026-10-21 |
| María Restrepo | Confirmar la fecha 15 | 2026-09-30 |
| Ricardo Salas | Entregar el punto 16 | 2026-10-13 |
| Diana Molina | Enviar el documento 17 | 2026-10-23 |
| Gustavo Neira | Cerrar la prueba 18 | 2026-10-21 |
| Mauricio Pérez | Revisar el anexo 19 | 2026-10-15 |
| Natalia Ospina | Validar el ambiente 20 | 2026-10-07 |

## Lo que se dijo

- Ricardo Salas dice que ya entregó «aprobar el diseño 13». No se presentó acta.
