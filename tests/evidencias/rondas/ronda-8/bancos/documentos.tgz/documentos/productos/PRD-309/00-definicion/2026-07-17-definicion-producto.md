# Definición de producto · Crédito de libre inversión

**Código:** PRD-309
**Gerente de producto:** Felipe Arango
**Segmento:** Personas
**Fecha de la definición:** 2026-07-17

## El problema

El segmento Personas no tiene crédito de libre inversión.

## La propuesta

- Propuesta principal

## Supuestos

- **El proveedor cumple el tiempo pactado** · declarado el 2026-04-06 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
