# Caso de negocio · Recaudos y cobros

**Código:** PRD-305
**Fecha:** 2026-03-07
**Preparado por:** Felipe Arango

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 283.716 | Caso de negocio, 2026-03-07 |

## Retorno esperado

Retorno esperado en 24 meses.
