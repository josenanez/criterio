# Definición de producto · Tarjeta de crédito digital

**Código:** PRD-304
**Gerente de producto:** Mauricio Pérez
**Segmento:** Microcomercio
**Fecha de la definición:** 2026-03-08

## El problema

El segmento Microcomercio no tiene tarjeta de crédito digital.

## La propuesta

- Propuesta principal

## Supuestos

- **El proveedor cumple el tiempo pactado** · declarado el 2026-04-05 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
