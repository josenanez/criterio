# Tablero de métricas · Nómina empresarial

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-05

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 80.643 | 2026-10-05 |
