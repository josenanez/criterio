# Entrevistas · Cuenta PyME

**Ronda:** Ronda · 2026-05-02
**Realizadas por:** Rubén Cárdenas

### Cliente entrevistado · 2026-05-02

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
