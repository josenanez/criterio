# Caso de negocio · Tarjeta de crédito digital

**Código:** PRD-304
**Fecha:** 2026-03-08
**Preparado por:** Mauricio Pérez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 281.509 | Caso de negocio, 2026-03-08 |

## Retorno esperado

Retorno esperado en 24 meses.
