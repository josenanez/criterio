# Caso de negocio · Microseguros

**Código:** PRD-306
**Fecha:** 2026-07-22
**Preparado por:** Mauricio Pérez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 140.572 | Caso de negocio, 2026-07-22 |

## Retorno esperado

Retorno esperado en 24 meses.
