# Comité de producto · Microseguros

**Fecha:** 2026-10-05
**Asistentes:** Mauricio Pérez

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4600 | Requerimiento REQ-4600 | Jorge Medina | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-11 | — |
| REQ-4601 | Requerimiento REQ-4601 | Rubén Cárdenas | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-03 | — |
| REQ-4602 | Requerimiento REQ-4602 | Óscar Ramírez | — | Cliente entrevistado | aceptado | 2026-03-26 | — |
| REQ-4603 | Requerimiento REQ-4603 | Liliana Torres | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-09 | — |
| REQ-4604 | Requerimiento REQ-4604 | María Restrepo | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-24 | — |
| REQ-4605 | Requerimiento REQ-4605 | Laura Vélez | se verifica en producción | — | aceptado | 2026-07-28 | — |
| REQ-4606 | Requerimiento REQ-4606 | Sandra Gil | se verifica en producción | — | propuesto | 2026-04-19 | — |
| REQ-4607 | Requerimiento REQ-4607 | Liliana Torres | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-09 | — |
| REQ-4608 | Requerimiento REQ-4608 | Laura Vélez | se verifica en producción | — | propuesto | 2026-05-01 | — |
| REQ-4609 | Requerimiento REQ-4609 | Mauricio Pérez | — | Cliente entrevistado | aceptado | 2026-04-23 | — |
| REQ-4610 | Requerimiento REQ-4610 | Liliana Torres | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-06 | — |
| REQ-4611 | Requerimiento REQ-4611 | Camilo Beltrán | — | Cliente entrevistado | aceptado | 2026-06-14 | — |
| REQ-4612 | Requerimiento REQ-4612 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-09-01 | — |
| REQ-4613 | Requerimiento REQ-4613 | Diana Molina | se verifica en producción | — | aceptado | 2026-06-02 | — |

## Decisiones

- Se mantiene el plan
