# Entrevistas · Tarjeta de crédito digital

**Ronda:** Ronda · 2025-10-23
**Realizadas por:** Mauricio Pérez

### Cliente entrevistado · 2025-10-23

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
