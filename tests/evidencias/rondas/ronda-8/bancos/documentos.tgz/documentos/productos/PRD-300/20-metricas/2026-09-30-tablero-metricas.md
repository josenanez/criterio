# Tablero de métricas · Pagos QR comercios

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-09-30

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 240.604 | 2026-09-30 |
