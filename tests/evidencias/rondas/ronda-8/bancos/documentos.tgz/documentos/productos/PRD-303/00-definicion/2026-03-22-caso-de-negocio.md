# Caso de negocio · Cuenta PyME

**Código:** PRD-303
**Fecha:** 2026-03-22
**Preparado por:** Rubén Cárdenas

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 126.442 | Caso de negocio, 2026-03-22 |

## Retorno esperado

Retorno esperado en 24 meses.
