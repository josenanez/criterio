# Entrevistas · Cuenta de ahorros joven

**Ronda:** Ronda · 2026-05-15
**Realizadas por:** Beatriz Cuéllar

### Cliente entrevistado · 2026-05-15

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
