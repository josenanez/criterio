# Caso de negocio · Remesas familiares

**Código:** PRD-307
**Fecha:** 2026-01-21
**Preparado por:** Natalia Ospina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 263.516 | Caso de negocio, 2026-01-21 |

## Retorno esperado

Retorno esperado en 24 meses.
