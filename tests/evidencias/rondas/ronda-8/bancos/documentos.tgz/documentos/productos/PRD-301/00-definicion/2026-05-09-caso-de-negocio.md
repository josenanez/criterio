# Caso de negocio · Nómina empresarial

**Código:** PRD-301
**Fecha:** 2026-05-09
**Preparado por:** Andrés Lozano

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 92.577 | Caso de negocio, 2026-05-09 |

## Retorno esperado

Retorno esperado en 24 meses.
