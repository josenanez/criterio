# Tablero de métricas · Tarjeta de crédito digital

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-09

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 200.246 | 2026-10-09 |
