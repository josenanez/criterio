# Caso de negocio · Cuenta de ahorros joven

**Código:** PRD-308
**Fecha:** 2025-08-31
**Preparado por:** Beatriz Cuéllar

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 206.843 | Caso de negocio, 2025-08-31 |

## Retorno esperado

Retorno esperado en 24 meses.
