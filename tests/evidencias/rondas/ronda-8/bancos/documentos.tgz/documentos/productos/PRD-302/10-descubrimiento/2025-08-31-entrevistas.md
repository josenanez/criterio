# Entrevistas · Crédito hipotecario digital

**Ronda:** Ronda · 2025-08-31
**Realizadas por:** Jorge Medina

### Cliente entrevistado · 2025-08-31

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
