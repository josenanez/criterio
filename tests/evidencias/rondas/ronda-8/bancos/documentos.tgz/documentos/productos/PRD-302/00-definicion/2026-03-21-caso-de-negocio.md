# Caso de negocio · Crédito hipotecario digital

**Código:** PRD-302
**Fecha:** 2026-03-21
**Preparado por:** Jorge Medina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 123.993 | Caso de negocio, 2026-03-21 |

## Retorno esperado

Retorno esperado en 24 meses.
