# Definición de producto · Recaudos y cobros

**Código:** PRD-305
**Gerente de producto:** Felipe Arango
**Segmento:** Base de la pirámide
**Fecha de la definición:** 2026-03-07

## El problema

El segmento Base de la pirámide no tiene recaudos y cobros.

## La propuesta

- Propuesta principal

## Supuestos

- **El canal actual soporta el volumen** · declarado el 2026-09-19 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
