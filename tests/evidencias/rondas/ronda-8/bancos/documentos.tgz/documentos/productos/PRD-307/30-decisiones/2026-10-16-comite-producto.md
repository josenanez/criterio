# Comité de producto · Remesas familiares

**Fecha:** 2026-10-16
**Asistentes:** Natalia Ospina

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4700 | Requerimiento REQ-4700 | Carlos Peña | se verifica en producción | — | aceptado | 2026-07-10 | — |
| REQ-4701 | Requerimiento REQ-4701 | Jorge Medina | se verifica en producción | Cliente entrevistado | aceptado | 2026-09-02 | — |
| REQ-4702 | Requerimiento REQ-4702 | Mauricio Pérez | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-29 | — |
| REQ-4703 | Requerimiento REQ-4703 | Javier Hoyos | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-14 | — |
| REQ-4704 | Requerimiento REQ-4704 | Óscar Ramírez | — | — | aceptado | 2026-08-01 | — |
| REQ-4705 | Requerimiento REQ-4705 | Elena Duarte | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-07 | — |
| REQ-4706 | Requerimiento REQ-4706 | Carlos Peña | — | — | aceptado | 2026-04-24 | — |
| REQ-4707 | Requerimiento REQ-4707 | María Restrepo | se verifica en producción | — | aceptado | 2026-08-02 | — |
| REQ-4708 | Requerimiento REQ-4708 | sin asignar | se verifica en producción | Cliente entrevistado | propuesto | 2026-05-10 | — |
| REQ-4709 | Requerimiento REQ-4709 | Rubén Cárdenas | — | Cliente entrevistado | aceptado | 2026-04-13 | — |
| REQ-4710 | Requerimiento REQ-4710 | sin asignar | — | — | aceptado | 2026-04-21 | — |
| REQ-4711 | Requerimiento REQ-4711 | Mauricio Pérez | se verifica en producción | — | aceptado | 2026-03-22 | — |

## Decisiones

- Se mantiene el plan
