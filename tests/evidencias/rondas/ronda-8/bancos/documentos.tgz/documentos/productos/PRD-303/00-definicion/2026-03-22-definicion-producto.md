# Definición de producto · Cuenta PyME

**Código:** PRD-303
**Gerente de producto:** Rubén Cárdenas
**Segmento:** Personas
**Fecha de la definición:** 2026-03-22

## El problema

El segmento Personas no tiene cuenta pyme.

## La propuesta

- Propuesta principal

## Supuestos

- **El canal actual soporta el volumen** · declarado el 2026-07-25 · verificado con el concepto jurídico de cumplimiento del 2026-08-13 (anexo «Verificación del supuesto» del 2026-08-13)

## Proyectos que lo construyen

- Ninguno declarado
