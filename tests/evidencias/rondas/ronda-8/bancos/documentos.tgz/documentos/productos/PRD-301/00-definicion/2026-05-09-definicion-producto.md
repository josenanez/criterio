# Definición de producto · Nómina empresarial

**Código:** PRD-301
**Gerente de producto:** Andrés Lozano
**Segmento:** PyME
**Fecha de la definición:** 2026-05-09

## El problema

El segmento PyME no tiene nómina empresarial.

## La propuesta

- Propuesta principal

## Supuestos

- **El proveedor cumple el tiempo pactado** · declarado el 2026-09-03 · verificado con la medición del piloto del 2026-09-26 (anexo «Verificación del supuesto» del 2026-09-26)

## Proyectos que lo construyen

- Ninguno declarado
