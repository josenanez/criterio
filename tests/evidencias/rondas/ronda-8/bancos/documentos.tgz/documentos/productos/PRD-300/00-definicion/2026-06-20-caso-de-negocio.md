# Caso de negocio · Pagos QR comercios

**Código:** PRD-300
**Fecha:** 2026-06-20
**Preparado por:** Carlos Peña

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 291.853 | Caso de negocio, 2026-06-20 |

## Retorno esperado

Retorno esperado en 24 meses.
