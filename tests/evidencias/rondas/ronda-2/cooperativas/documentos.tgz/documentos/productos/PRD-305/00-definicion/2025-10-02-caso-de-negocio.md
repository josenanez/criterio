# Caso de negocio · Microcrédito

**Código:** PRD-305
**Fecha:** 2025-10-02
**Preparado por:** Rubén Cárdenas

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 126.953 | Caso de negocio, 2025-10-02 |

## Retorno esperado

Retorno esperado en 24 meses.
