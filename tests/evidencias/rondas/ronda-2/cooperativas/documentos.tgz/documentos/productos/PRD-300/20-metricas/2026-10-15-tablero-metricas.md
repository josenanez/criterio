# Tablero de métricas · Crédito de libranza

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-15

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 121.498 | 2026-10-15 |
