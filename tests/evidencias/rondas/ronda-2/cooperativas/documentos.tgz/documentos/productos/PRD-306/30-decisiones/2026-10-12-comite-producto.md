# Comité de producto · Recaudos

**Fecha:** 2026-10-12
**Asistentes:** Elena Duarte

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-1060 | Requerimiento REQ-1060 | Andrés Lozano | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-28 | — |
| REQ-1061 | Requerimiento REQ-1061 | Sandra Gil | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-20 | — |

## Decisiones

- Se mantiene el plan
