# Tablero de métricas · Ahorro a la vista

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-09-28

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 88.666 | 2026-09-28 |
