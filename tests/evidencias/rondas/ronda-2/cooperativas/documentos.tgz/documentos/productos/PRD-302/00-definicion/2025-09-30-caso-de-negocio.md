# Caso de negocio · Aportes sociales

**Código:** PRD-302
**Fecha:** 2025-09-30
**Preparado por:** Camilo Beltrán

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 57.051 | Caso de negocio, 2025-09-30 |

## Retorno esperado

Retorno esperado en 24 meses.
