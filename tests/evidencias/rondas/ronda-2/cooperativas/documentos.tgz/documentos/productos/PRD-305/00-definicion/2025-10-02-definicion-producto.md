# Definición de producto · Microcrédito

**Código:** PRD-305
**Gerente de producto:** Rubén Cárdenas
**Segmento:** Asociados urbanos
**Fecha de la definición:** 2025-10-02

## El problema

El segmento Asociados urbanos no tiene microcrédito.

## La propuesta

- Propuesta principal

## Supuestos

- **El proveedor cumple el tiempo pactado** · declarado el 2026-09-23 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
