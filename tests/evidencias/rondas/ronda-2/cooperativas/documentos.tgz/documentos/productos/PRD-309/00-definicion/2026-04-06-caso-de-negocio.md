# Caso de negocio · Microseguros

**Código:** PRD-309
**Fecha:** 2026-04-06
**Preparado por:** Jorge Medina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 294.475 | Caso de negocio, 2026-04-06 |

## Retorno esperado

Retorno esperado en 24 meses.
