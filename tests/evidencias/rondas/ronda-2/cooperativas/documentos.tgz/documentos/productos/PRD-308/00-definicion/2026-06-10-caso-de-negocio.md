# Caso de negocio · Remesas familiares

**Código:** PRD-308
**Fecha:** 2026-06-10
**Preparado por:** Javier Hoyos

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 180.643 | Caso de negocio, 2026-06-10 |

## Retorno esperado

Retorno esperado en 24 meses.
