# Comité de producto · Remesas familiares

**Fecha:** 2026-10-12
**Asistentes:** Javier Hoyos

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-1080 | Requerimiento REQ-1080 | María Restrepo | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-10 | — |
| REQ-1081 | Requerimiento REQ-1081 | Óscar Ramírez | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-25 | — |
| REQ-2016 | Requerimiento REQ-2016 | Carlos Peña | se verifica en producción | Cliente entrevistado | aceptado | 2026-09-18 | — |

## Decisiones

- Se mantiene el plan
