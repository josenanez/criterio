# Entrevistas · Pagos QR

**Ronda:** Ronda · 2026-01-15
**Realizadas por:** Jorge Medina

### Cliente entrevistado · 2026-01-15

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
