# Definición de producto · Remesas familiares

**Código:** PRD-308
**Gerente de producto:** Javier Hoyos
**Segmento:** Microempresarios
**Fecha de la definición:** 2026-06-10

## El problema

El segmento Microempresarios no tiene remesas familiares.

## La propuesta

- Propuesta principal

## Supuestos

- **El core soporta el volumen** · declarado el 2026-03-21 · verificado

## Proyectos que lo construyen

- Ninguno declarado
