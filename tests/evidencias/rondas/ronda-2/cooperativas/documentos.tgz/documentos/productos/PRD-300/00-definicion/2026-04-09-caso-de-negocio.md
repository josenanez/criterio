# Caso de negocio · Crédito de libranza

**Código:** PRD-300
**Fecha:** 2026-04-09
**Preparado por:** Gustavo Neira

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 156.447 | Caso de negocio, 2026-04-09 |

## Retorno esperado

Retorno esperado en 24 meses.
