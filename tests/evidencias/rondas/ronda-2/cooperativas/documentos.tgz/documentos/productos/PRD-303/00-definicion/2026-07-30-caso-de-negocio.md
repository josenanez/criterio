# Caso de negocio · Tarjeta débito

**Código:** PRD-303
**Fecha:** 2026-07-30
**Preparado por:** Laura Vélez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 224.988 | Caso de negocio, 2026-07-30 |

## Retorno esperado

Retorno esperado en 24 meses.
