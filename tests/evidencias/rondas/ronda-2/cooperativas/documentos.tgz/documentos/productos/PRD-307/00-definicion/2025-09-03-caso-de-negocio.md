# Caso de negocio · Auxilios de solidaridad

**Código:** PRD-307
**Fecha:** 2025-09-03
**Preparado por:** Ricardo Salas

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 245.942 | Caso de negocio, 2025-09-03 |

## Retorno esperado

Retorno esperado en 24 meses.
