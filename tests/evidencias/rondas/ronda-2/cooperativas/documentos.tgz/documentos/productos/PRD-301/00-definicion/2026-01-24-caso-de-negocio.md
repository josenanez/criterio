# Caso de negocio · Ahorro a la vista

**Código:** PRD-301
**Fecha:** 2026-01-24
**Preparado por:** Carlos Peña

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 119.938 | Caso de negocio, 2026-01-24 |

## Retorno esperado

Retorno esperado en 24 meses.
