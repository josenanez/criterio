# Caso de negocio · Recaudos

**Código:** PRD-306
**Fecha:** 2025-10-26
**Preparado por:** Elena Duarte

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 273.297 | Caso de negocio, 2025-10-26 |

## Retorno esperado

Retorno esperado en 24 meses.
