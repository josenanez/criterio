# Tablero de métricas · Pagos QR

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-05

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 238.448 | 2026-10-05 |
