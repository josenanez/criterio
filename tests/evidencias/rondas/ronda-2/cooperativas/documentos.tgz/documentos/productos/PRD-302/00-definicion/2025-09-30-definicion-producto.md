# Definición de producto · Aportes sociales

**Código:** PRD-302
**Gerente de producto:** Camilo Beltrán
**Segmento:** Microempresarios
**Fecha de la definición:** 2025-09-30

## El problema

El segmento Microempresarios no tiene aportes sociales.

## La propuesta

- Propuesta principal

## Supuestos

- **El core soporta el volumen** · declarado el 2026-07-05 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
