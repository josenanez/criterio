# Informe de avance · Crédito de libranza digital

**Código:** PRY-200
**Fecha de corte:** 2026-10-11
**Gerente:** Ricardo Salas

## Estado declarado

**Amarillo**

Avance reportado: **53%**

## Lo que pasó en el periodo

- El equipo perdió dos semanas por rotación de un desarrollador clave

## Presupuesto

| | COP |
|---|---|
| Aprobado | 4.200.000.000 |
| Comprometido | 2.082.032.705 |
| Ejecutado | 1.158.162.686 |
| Proyección al cierre | 4.085.574.704 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
