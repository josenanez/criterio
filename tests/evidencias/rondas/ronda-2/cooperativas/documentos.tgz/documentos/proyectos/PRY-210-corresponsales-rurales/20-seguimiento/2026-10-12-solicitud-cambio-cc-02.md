# Solicitud de cambio CC-02

**Proyecto:** PRY-210 · Corresponsales rurales
**Fecha:** 2026-10-12
**Solicitante:** Sandra Gil

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +101 días sobre la línea base vigente |
| Costo | 202.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
