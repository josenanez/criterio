# Informe de avance · Cambio de mobiliario de agencias

**Código:** PRY-199
**Fecha de corte:** 2026-10-13
**Gerente:** Andrés Lozano

## Estado declarado

**Verde**

Avance reportado: **20%**

## Lo que pasó en el periodo

- La prueba de carga no alcanzó el umbral pactado y se repite
- Se reprogramó la salida por el cierre contable de fin de mes

## Presupuesto

| | COP |
|---|---|
| Aprobado | 2.400.000.000 |
| Comprometido | 1.080.000.000 |
| Ejecutado | 720.000.000 |
| Proyección al cierre | 2.400.000.000 |

## Riesgos abiertos

- Cambio normativo del supervisor que puede mover el alcance
