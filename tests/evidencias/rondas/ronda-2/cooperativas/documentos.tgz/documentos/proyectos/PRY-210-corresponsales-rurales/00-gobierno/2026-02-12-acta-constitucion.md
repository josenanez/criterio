# Acta de constitución · Corresponsales rurales

**Código:** PRY-210
**Área dueña:** Crédito
**Patrocinador:** Gustavo Neira
**Gerente de proyecto:** Sandra Gil
**Comité:** Consejo de Administración
**Producto asociado:** No aplica
**Fecha de aprobación:** 2026-02-12

## Objetivo del negocio

Entregar corresponsales rurales para Crédito.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**4.200.000.000 COP**, aprobado por Consejo de Administración el 2026-02-12.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-02-22 |
| Cierre | 2026-11-28 |

## Criterio de éxito

Corresponsales rurales en producción y medido.

## Dependencias declaradas

- Ninguna declarada
