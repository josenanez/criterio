# Comité de Crédito · Pagos con QR

**Fecha:** 2026-10-12
**Asistentes:** Javier Hoyos, Felipe Arango

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Ricardo Salas | Entregar el punto 36 | 2026-10-22 |
| María Restrepo | Entregar el punto 15 | 2026-09-27 |
