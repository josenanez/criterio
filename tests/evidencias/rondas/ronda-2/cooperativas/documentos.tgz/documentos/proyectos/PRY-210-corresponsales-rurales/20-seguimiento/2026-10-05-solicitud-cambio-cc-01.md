# Solicitud de cambio CC-01

**Proyecto:** PRY-210 · Corresponsales rurales
**Fecha:** 2026-10-05
**Solicitante:** Sandra Gil

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +76 días sobre la línea base vigente |
| Costo | 152.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
