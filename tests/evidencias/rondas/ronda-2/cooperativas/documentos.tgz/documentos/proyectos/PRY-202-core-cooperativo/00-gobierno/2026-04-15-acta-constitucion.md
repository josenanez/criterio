# Acta de constitución · Core cooperativo

**Código:** PRY-202
**Área dueña:** Cartera y cobranza
**Patrocinador:** Diana Molina
**Gerente de proyecto:** Camilo Beltrán
**Comité:** Comité de Tecnología
**Producto asociado:** No aplica
**Fecha de aprobación:** 2026-04-15

## Objetivo del negocio

Entregar core cooperativo para Cartera y cobranza.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**2.400.000.000 COP**, aprobado por Comité de Tecnología el 2026-04-15.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-04-25 |
| Cierre | 2027-07-16 |

## Criterio de éxito

Core cooperativo en producción y medido.

## Dependencias declaradas

- Ninguna declarada
