# Comité de Riesgos · Apertura de ahorro en línea

**Fecha:** 2026-10-15
**Asistentes:** Javier Hoyos, Felipe Arango

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Carlos Peña | Entregar el punto 12 | 2026-09-27 |
