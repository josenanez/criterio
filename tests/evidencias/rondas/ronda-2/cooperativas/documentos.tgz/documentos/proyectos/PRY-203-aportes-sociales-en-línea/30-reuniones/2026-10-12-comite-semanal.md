# Comité de Riesgos · Aportes sociales en línea

**Fecha:** 2026-10-12
**Asistentes:** Elena Duarte, Andrés Lozano

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Beatriz Cuéllar | Entregar el punto 32 | 2026-11-06 |
| Carlos Peña | Entregar el punto 2 | 2026-10-11 |
