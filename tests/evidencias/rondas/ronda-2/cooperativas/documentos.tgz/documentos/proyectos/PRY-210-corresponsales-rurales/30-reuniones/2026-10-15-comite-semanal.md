# Consejo de Administración · Corresponsales rurales

**Fecha:** 2026-10-15
**Asistentes:** Sandra Gil, Gustavo Neira

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Rubén Cárdenas | Entregar el punto 12 | 2026-10-07 |
