# Comité de Riesgos · Cobranza digital

**Fecha:** 2026-10-03
**Asistentes:** Mauricio Pérez, Ricardo Salas

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Óscar Ramírez | Entregar el punto 35 | 2026-11-03 |
