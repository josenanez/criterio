# Informe de avance · Tarjeta débito para asociados

**Código:** PRY-204
**Fecha de corte:** 2026-10-07
**Gerente:** Sandra Gil

## Estado declarado

**Amarillo**

Avance reportado: **73%**

## Lo que pasó en el periodo

- Se reprogramó la salida por el cierre contable de fin de mes

## Presupuesto

| | COP |
|---|---|
| Aprobado | 6.800.000.000 |
| Comprometido | 3.051.187.337 |
| Ejecutado | 1.451.249.736 |
| Proyección al cierre | 7.967.490.454 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
- Aprobación del reglamento por el Consejo de Administración
