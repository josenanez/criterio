# Acta de constitución · Pagos con QR

**Código:** PRY-206
**Área dueña:** Crédito
**Patrocinador:** Felipe Arango
**Gerente de proyecto:** Javier Hoyos
**Comité:** Comité de Crédito
**Producto asociado:** pagos QR
**Fecha de aprobación:** 2026-04-21

## Objetivo del negocio

Entregar pagos con qr para Crédito.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**800.000.000 COP**, aprobado por Comité de Crédito el 2026-04-21.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-05-01 |
| Cierre | 2027-09-10 |

## Criterio de éxito

Pagos con QR en producción y medido.

## Dependencias declaradas

- Ninguna declarada
