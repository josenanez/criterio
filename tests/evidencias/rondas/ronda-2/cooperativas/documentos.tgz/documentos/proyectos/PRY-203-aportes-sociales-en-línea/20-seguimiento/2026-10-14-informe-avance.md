# Informe de avance · Aportes sociales en línea

**Código:** PRY-203
**Fecha de corte:** 2026-10-14
**Gerente:** Elena Duarte

## Estado declarado

**Rojo**

Avance reportado: **34%**

## Lo que pasó en el periodo

- Se reprogramó la salida por el cierre contable de fin de mes
- Se levantó un hallazgo de seguridad en la revisión de arquitectura
- Se ajustó el plan de pruebas con el área de seguridad

## Presupuesto

| | COP |
|---|---|
| Aprobado | 4.200.000.000 |
| Comprometido | 2.705.437.450 |
| Ejecutado | 1.996.494.350 |
| Proyección al cierre | 3.996.935.557 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
- Concentración del conocimiento en una sola persona
