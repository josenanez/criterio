# Comité de Educación · Prevención de lavado de activos

**Fecha:** 2026-10-11
**Asistentes:** Camilo Beltrán, Sandra Gil

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| María Restrepo | Entregar el punto 2 | por definir |
