# Solicitud de cambio CC-01

**Proyecto:** PRY-200 · Crédito de libranza digital
**Fecha:** 2026-10-03
**Solicitante:** Ricardo Salas

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +118 días sobre la línea base vigente |
| Costo | 236.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
