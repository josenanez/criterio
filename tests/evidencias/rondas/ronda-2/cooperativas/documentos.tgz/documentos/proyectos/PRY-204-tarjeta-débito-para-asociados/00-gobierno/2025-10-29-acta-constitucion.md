# Acta de constitución · Tarjeta débito para asociados

**Código:** PRY-204
**Área dueña:** Tesorería
**Patrocinador:** Camilo Beltrán
**Gerente de proyecto:** Sandra Gil
**Comité:** Comité de Educación
**Producto asociado:** tarjeta débito
**Fecha de aprobación:** 2025-10-29

## Objetivo del negocio

Entregar tarjeta débito para asociados para Tesorería.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**6.800.000.000 COP**, aprobado por Comité de Educación el 2025-10-29.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-11-08 |
| Cierre | 2026-06-20 |

## Criterio de éxito

Tarjeta débito para asociados en producción y medido.

## Dependencias declaradas

- Ninguna declarada
