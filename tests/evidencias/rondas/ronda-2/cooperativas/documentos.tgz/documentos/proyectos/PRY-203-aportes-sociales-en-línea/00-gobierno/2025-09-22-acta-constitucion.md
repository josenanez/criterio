# Acta de constitución · Aportes sociales en línea

**Código:** PRY-203
**Área dueña:** Bienestar social
**Patrocinador:** Andrés Lozano
**Gerente de proyecto:** Elena Duarte
**Comité:** Comité de Riesgos
**Producto asociado:** aportes sociales
**Fecha de aprobación:** 2025-09-22

## Objetivo del negocio

Entregar aportes sociales en línea para Bienestar social.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**4.200.000.000 COP**, aprobado por Comité de Riesgos el 2025-09-22.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-10-02 |
| Cierre | 2026-10-15 |

## Criterio de éxito

Aportes sociales en línea en producción y medido.

## Dependencias declaradas

- Ninguna declarada
