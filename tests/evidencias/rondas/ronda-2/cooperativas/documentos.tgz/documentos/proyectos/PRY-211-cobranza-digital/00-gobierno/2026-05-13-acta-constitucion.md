# Acta de constitución · Cobranza digital

**Código:** PRY-211
**Área dueña:** Servicio al asociado
**Patrocinador:** Ricardo Salas
**Gerente de proyecto:** Mauricio Pérez
**Comité:** Comité de Riesgos
**Producto asociado:** recaudos
**Fecha de aprobación:** 2026-05-13

## Objetivo del negocio

Entregar cobranza digital para Servicio al asociado.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**6.800.000.000 COP**, aprobado por Comité de Riesgos el 2026-05-13.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-05-23 |
| Cierre | 2027-03-06 |

## Criterio de éxito

Cobranza digital en producción y medido.

## Dependencias declaradas

- Ninguna declarada
