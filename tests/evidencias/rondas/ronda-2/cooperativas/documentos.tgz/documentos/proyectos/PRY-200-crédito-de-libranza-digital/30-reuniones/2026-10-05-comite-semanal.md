# Comité de Riesgos · Crédito de libranza digital

**Fecha:** 2026-10-05
**Asistentes:** Ricardo Salas, Paula Céspedes

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Liliana Torres | Entregar el punto 6 | 2026-11-02 |
