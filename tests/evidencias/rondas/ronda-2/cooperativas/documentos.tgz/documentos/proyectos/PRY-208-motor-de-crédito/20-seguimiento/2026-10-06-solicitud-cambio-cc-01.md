# Solicitud de cambio CC-01

**Proyecto:** PRY-208 · Motor de crédito
**Fecha:** 2026-10-06
**Solicitante:** Paula Céspedes

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +113 días sobre la línea base vigente |
| Costo | 226.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
