# Informe de avance · Prevención de lavado de activos

**Código:** PRY-205
**Fecha de corte:** 2026-10-14
**Gerente:** Camilo Beltrán

## Estado declarado

**Rojo**

Avance reportado: **27%**

## Lo que pasó en el periodo

- El equipo perdió dos semanas por rotación de un desarrollador clave

## Presupuesto

| | COP |
|---|---|
| Aprobado | 9.500.000.000 |
| Comprometido | 2.805.154.469 |
| Ejecutado | 3.928.364.439 |
| Proyección al cierre | 8.886.361.055 |

## Riesgos abiertos

- Aprobación del reglamento por el Consejo de Administración
- Dependencia del proveedor del core cooperativo
