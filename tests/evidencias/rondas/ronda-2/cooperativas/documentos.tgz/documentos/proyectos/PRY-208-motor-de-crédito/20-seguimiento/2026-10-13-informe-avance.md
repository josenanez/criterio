# Informe de avance · Motor de crédito

**Código:** PRY-208
**Fecha de corte:** 2026-10-13
**Gerente:** Paula Céspedes

## Estado declarado

**Amarillo**

Avance reportado: **58%**

## Lo que pasó en el periodo

- El Consejo de Administración pidió ajustar el reglamento antes del piloto
- El proveedor entregó el componente de integración, pendiente de aceptación
- Se recibió el concepto pendiente del ente supervisor

## Presupuesto

| | COP |
|---|---|
| Aprobado | 3.300.000.000 |
| Comprometido | 1.006.828.323 |
| Ejecutado | 1.497.208.124 |
| Proyección al cierre | 3.046.755.482 |

## Riesgos abiertos

- Aprobación del reglamento por el Consejo de Administración
