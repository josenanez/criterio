## Definición — Crédito de libranza (PRD-300) · contrastada al 2026-10-15
**Documento:** `00-definicion/2026-04-09-definicion-producto.docx` y `00-definicion/2026-04-09-caso-de-negocio.md` · **del** 2026-04-09 · 7 afirmaciones

Términos vigentes: versión 0.3.8 (términos 1.1), aceptados por José Francisco Ñáñez el 2026-10-15. Respuestas por defecto (sin interfaz): se usó la configuración tal cual.

### Lo que la evidencia contradice
Nada que dos fuentes digan en sentido opuesto. Lo único que no coincide es una cifra (ver la sección siguiente), y eso es diferencia de medición, no contradicción de documentos.

### El negocio y los datos
| Métrica | Declarado | Medido | Diferencia | Las dos fuentes y fechas |
|---|---|---|---|---|
| volumen_mensual | 156.447 | 121.498 | 22,3 % (declarado por encima; umbral 20 %) | Caso de negocio, 2026-04-09 · Tablero de producto (bodega de datos), 2026-10-15 |

Hay un solo punto medido: no se puede decir si la serie sube o baja. El tablero tampoco dice si el volumen es de este producto o de otra cosa.

### Afirmaciones numéricas que nadie mide
| Afirma | De qué documento | No hay serie |
|---|---|---|
| Retorno esperado «en 24 meses» | Caso de negocio, 2026-04-09 | No trae cifra, así que no hay nada que medir; tampoco hay serie de retorno |

### No está dicho en ninguna parte
- El criterio de éxito del producto: no aparece ni en la definición ni en el caso de negocio.
- De dónde sale la cifra de 156.447: el caso de negocio se cita a sí mismo como fuente; no hay estudio, base ni supuesto detrás.
- El monto, la tasa o la base de cálculo del retorno esperado.
- La propuesta: el título «Propuesta principal» está en la definición y no tiene contenido.
- Qué proyecto construye el producto: la definición dice «Ninguno declarado».
- Quién decide qué se construye: ningún documento lo dice; «Comité de producto» es lo que quedó en la configuración. El comité del 2026-10-10 tiene un solo asistente, Gustavo Neira.
- Que Asociados rurales sea el segmento que pidió el crédito: la única entrevista no dice a qué segmento pertenece quien habla.
- Qué pide cada uno de los cuatro requerimientos aceptados: los documentos solo los llaman «Requerimiento REQ-100x».
- En qué país se ofrece el producto: ningún documento lo dice.

### Sostenida por un supuesto
| Supuesto | Días sin verificar | Qué haría falta para verificarlo |
|---|---|---|
| El proveedor cumple el tiempo pactado (declarado 2026-05-14) | Ninguno: figura «verificado», pero sin documento que muestre la verificación. Además la fecha del supuesto es posterior a la de la definición (2026-04-09) | El documento de la verificación: el contrato o el plazo pactado y el registro de entregas contra ese plazo |

La demanda de Asociados rurales y el volumen mensual están escritos como hechos, no como supuestos. Si no hay estudio detrás, son supuestos que no se declararon.

### Sostenida por evidencia
| Afirmación | Sostenida por | De cuándo | Qué tan fuerte |
|---|---|---|---|
| El segmento no tiene crédito de libranza / hay necesidad | Una entrevista a un «cliente entrevistado»: «Lo necesito y hoy no lo tengo.» | 2025-09-20 | Débil: alguien dijo que lo necesita; nadie pagó ni pidió formalmente. Una sola persona, sin segmento |
| Volumen mensual del orden declarado | El tablero mide 121.498, que acompaña el orden de magnitud pero queda 22,3 % por debajo | 2026-10-15 | Medida real, pero de un solo punto |

### Evidencia que ya envejeció
| Afirmación | Lo más nuevo que la sostiene | Hace |
|---|---|---|
| Necesidad de Asociados rurales; sostiene también REQ-1000 a REQ-1003 | Entrevista del 2025-09-20 («la entrevista no nombra este requerimiento» en los cuatro casos) | 12 meses (umbral: 12) |

### Lo normativo que toca
| Qué toca | País | Obligación | Norma | Estado |
|---|---|---|---|---|
| Datos personales de los Asociados (solicitud, ingresos, descuentos) | No declarado | Tratamiento y autorización de datos personales | — | No tengo la norma a la vista |
| Crédito a personas naturales por descuento de nómina o de aportes (libranza) | No declarado | Condiciones del descuento, información al consumidor y topes | — | No tengo la norma a la vista |
| Consumidor financiero | No declarado | Información y protección del consumidor | — | No tengo la norma a la vista |
| Conservación de la información del crédito | No declarado | Plazos de retención | — | No tengo la norma a la vista |

Esto nombra lo que toca; no dice si el producto cumple. Va a revisión jurídica, no la reemplaza. Sin país declarado no se puede citar ninguna norma.

### Lo que falta para cerrar la definición
- **Criterio de éxito:** no está. Sin él el producto no se puede cerrar, porque el cierre se juzga contra él.
- **Quién decide:** ningún documento lo dice.
- El problema y para quién sí están (Asociados rurales), aunque la evidencia que los sostiene tiene 12 meses y no nombra el segmento.
- Hay además una propuesta sin contenido y un retorno sin cifra.

El cálculo de la corrida trae `unknown` vacío; esa lista no marca el criterio de éxito aunque la ficha lo tenga como no encontrado. Aquí se toma la ficha.

### Después
El supuesto del proveedor y las cifras sin fuente podrían convertirse en riesgo con doliente (`raid-taxonomy`). La definición no está cerrada (sin criterio de éxito ni autoridad), así que no corresponde ofrecer `/product-charter` todavía.
