## Registro — Crédito de libranza (PRD-300) · al 2026-10-15
4 requerimientos · 4 decididos · 100% con evidencia · 0% con proyecto que lo ejecuta

### Se va a construir y nadie lo pidió
Ninguno por la señal calculada: los cuatro tienen una cita. **Pero** la única evidencia de los cuatro es la misma frase de la entrevista del 2025-09-20 («Lo necesito y hoy no lo tengo»), y el propio registro anota que *la entrevista no nombra este requerimiento*. El 100% con evidencia es de forma; ninguna cita pide REQ-1000 a REQ-1003 en concreto.

### Decidido y nadie lo está construyendo
| REQ | Título | Decidido el | Proyecto |
|---|---|---|---|
| REQ-1000 | Requerimiento REQ-1000 | 2026-10-10 | ninguno |
| REQ-1001 | Requerimiento REQ-1001 | 2026-10-10 | ninguno |
| REQ-1002 | Requerimiento REQ-1002 | 2026-10-10 | ninguno |
| REQ-1003 | Requerimiento REQ-1003 | 2026-10-10 | ninguno |

Quien lo cierra: Gustavo Neira (gerente de producto) con el Comité de producto, que es quien decide. Siguiente paso: `/product-trace`, y `/product-charter` para el que quede con evidencia y criterio sólidos.

### Sin doliente, o con un área en vez de una persona
Ninguno. Dolientes: REQ-1000 Rubén Cárdenas, REQ-1001 Gustavo Neira, REQ-1002 Laura Vélez, REQ-1003 Mauricio Pérez.

### Sin criterio de aceptación
Ninguno por conteo (los cuatro tienen uno). Para REQ-1000 el criterio es «se verifica en producción», que no se puede medir hoy.

### Decidido sin documento que lo respalde
Ninguno. Todos citan el acta del comité del 2026-10-10. Ojo: la decisión registrada es «Se mantiene el plan», una decisión general del comité, no de cada requerimiento.

### Lleva meses y nadie lo decide
Ninguno: los cuatro se decidieron el 2026-10-10.

### Evidencia vieja
| REQ | Lo más nuevo que lo sostiene | Hace |
|---|---|---|
| REQ-1000 | 2025-09-20 (entrevistas) | 12 meses |
| REQ-1001 | 2025-09-20 (entrevistas) | 12 meses |
| REQ-1002 | 2025-09-20 (entrevistas) | 12 meses |
| REQ-1003 | 2025-09-20 (entrevistas) | 12 meses |

Cierra el vacío: Gustavo Neira, con una ronda nueva de entrevistas.

### Fuera del registro, pero salió en el cálculo
Volumen mensual: el caso de negocio (2026-04-09) declara 156.447 y el tablero medido el 2026-10-15 muestra 121.498; lo declarado está 22,3% por encima (umbral 20%). La definición tampoco trae criterio de éxito (`not_found`).

## Por estado
| propuesto | aceptado | en construcción | entregado | descartado |
|---|---|---|---|---|
| 0 | 4 | 0 | 0 | 0 |
