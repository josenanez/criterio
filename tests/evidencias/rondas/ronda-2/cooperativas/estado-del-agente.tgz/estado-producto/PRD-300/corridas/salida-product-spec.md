> **Borrador de trabajo, no una especificación aprobada.** Lo escribe el agente; lo cierra Gustavo Neira (gerente de producto) con la autoridad del Comité de producto. Este agente no aprueba, no diseña y no estima.

# Especificación — Crédito de libranza (PRD-300) · borrador del 2026-10-15

## Qué problema resuelve
«El segmento Asociados rurales no tiene crédito de libranza.» (`00-definicion/2026-04-09-definicion-producto.docx`). Quién lo pide: Asociados rurales. **Criterio de éxito del producto: no está dicho en ninguna parte** (`success: not_found`). **La propuesta no tiene contenido**: la definición solo dice «Propuesta principal».

## Alcance
### Entra
Los cuatro requerimientos en estado `aceptado` según el Comité de producto del 2026-10-10: REQ-1000, REQ-1001, REQ-1002, REQ-1003.
**Ninguno tiene título ni necesidad escrita** (el registro solo trae «Requerimiento REQ-100x» y `need: not_found`). Por eso esta especificación no puede describir su comportamiento: no hay texto de qué problema resuelve cada uno, y escribirlo sería inventarlo.

### No entra
- Cualquier cosa fuera de REQ-1000 a REQ-1003: el registro no tiene otros requerimientos.
- Comportamiento, flujo, tasas, montos, plazos, canales o convenios de libranza: ningún documento los dice, así que no entran. Son vacíos (ver abajo), no exclusiones decididas.
- Diseño técnico, estimación, costo y fecha: no son de este documento.

## Comportamiento
No se redacta. Ningún requerimiento tiene `need`, y la decisión del comité («Se mantiene el plan») es general, no de un requerimiento. Cada sección futura debe citar el requerimiento que cubre; hoy no hay contenido que citar. (REQ-1000 a REQ-1003 · `30-decisiones/2026-10-10-comite-producto.docx`)

## Criterios de aceptación
Los cuatro requerimientos traen el mismo criterio: «se verifica en producción».

| Criterio | Requerimiento | Cómo se verifica | ¿Se puede medir hoy? |
|---|---|---|---|
| «se verifica en producción» | REQ-1000 | No es verificable: dos personas no llegarían a la misma respuesta. No dice qué se observa, ni umbral, ni plazo | **No.** Es un lugar, no un criterio |
| «se verifica en producción» | REQ-1001 | Ídem | **No** |
| «se verifica en producción» | REQ-1002 | Ídem | **No** |
| «se verifica en producción» | REQ-1003 | Ídem | **No** |

En la práctica, **los cuatro requerimientos están sin criterio de aceptación verificable.** No propongo uno: sin el `need` cualquier umbral que escribiera sería inventado. Lo que sí hay medido es `volumen_mensual` (tablero, 121.498 al 2026-10-15), pero ningún requerimiento lo usa como criterio.

## Supuestos sobre los que está escrita

| Supuesto | Verificado | Quién lo verificaría |
|---|---|---|
| «El proveedor cumple el tiempo pactado» (declarado 2026-05-14, `definition.assumptions`) | Figura `verified: true`, **pero no cita nada que lo verifique** (ni medición, ni documento del proveedor). Además, está fechado 2026-05-14 dentro de una definición del 2026-04-09, y la definición no nombra al proveedor ni el tiempo pactado. Lo trato como **no verificado con cita** | Gustavo Neira, aportando el documento o medición que lo sostiene |
| Supuestos de los requerimientos (REQ-1000 a 1003) | `assumptions` vacío en los cuatro. No se asumen supuestos que nadie declaró | — |

## Vacíos

| Qué falta decidir | Consecuencia de no decidirlo | Quién lo cierra |
|---|---|---|
| **Sin criterio de aceptación verificable** en REQ-1000, 1001, 1002, 1003 | Nadie podrá decir si lo construido está bien; la discusión ocurrirá después de construir | Dolientes: Rubén Cárdenas (1000), Gustavo Neira (1001), Laura Vélez (1002), Mauricio Pérez (1003); aprueba Gustavo Neira |
| **Necesidad y título de cada requerimiento** (`need: not_found`) | No se puede especificar comportamiento; la especificación queda vacía | Los mismos cuatro dolientes |
| **Evidencia de demanda que no los sostiene.** La única evidencia es la entrevista del 2025-09-20 («Lo necesito y hoy no lo tengo»), de un «cliente entrevistado» sin nombre, que **no nombra ninguno de los cuatro**, y tiene más de 12 meses (umbral `evidence_stale_months` = 12) | Cuatro requerimientos aceptados sin evidencia propia, con evidencia vencida | Gustavo Neira (quien hizo las entrevistas) |
| **Ningún proyecto los ejecuta** (`traces.project: null`; el acta del comité dice «—» en los cuatro; la definición dice «Ninguno declarado») | Lo aceptado no se construye; no se puede pasar a acta de constitución | Comité de producto / Gustavo Neira |
| **Prioridad** (`not_found` en los cuatro) | Sin orden de construcción | Gustavo Neira |
| **Casos borde**: nada definido para solicitud rechazada, libranza no descontada por el pagador, cambio de pagador o de empleador, retiro del asociado, mora, solicitud duplicada, desistimiento antes del desembolso | Cada equipo lo resolverá por su cuenta | Gustavo Neira, con los dolientes; el área de riesgo/crédito debería opinar (no está nombrada en ningún documento) |
| **Lo que otro equipo tiene que hacer**: la existencia de un «proveedor» sugiere un tercero, pero ningún documento dice quién, qué entrega ni qué se acordó. Tampoco hay pagadores/convenios de libranza para el segmento rural | Dependencia sin acuerdo, sin dueño | Gustavo Neira |
| **Criterio de éxito del producto** (`success: not_found`) y **retorno esperado sin cifra** («Retorno esperado en 24 meses») | Sin forma de saber si el producto funcionó | Gustavo Neira / Comité de producto |
| **La decisión del comité** («Se mantiene el plan») es general; ningún documento dice qué plan ni decide cada requerimiento | La aceptación de cada REQ descansa en una decisión que no lo nombra | Comité de producto |
| **Quién decide**: la autoridad «Comité de producto» es sugerida; ningún documento dice quién decide | Cierre de la especificación sin firmante establecido | Gustavo Neira |
| **Cifra en conflicto, no resuelta**: el caso de negocio declara volumen_mensual 156.447 (2026-04-09); el tablero mide 121.498 (2026-10-15). Diferencia ≈ 22 % (umbral `claim_gap_pct` = 20), en la dirección de que lo medido es menor | Si algún requerimiento se dimensiona con 156.447, queda sobredimensionado. No sé cuál es la cifra correcta ni si miden lo mismo | Gustavo Neira (negocio) y dueño del tablero (datos). Ninguno gana por defecto |

### Obligaciones normativas (barrido, sin dictamen de cumplimiento)
Un crédito de libranza toca datos personales y financieros, el consumidor financiero y el descuento de nómina. **Ningún documento dice en qué país opera el producto**, y yo no tengo la norma a la vista. No cito normas.

| Qué toca la definición | País | Obligación | Norma citada | Estado |
|---|---|---|---|---|
| Datos personales y financieros de asociados (identificación, ingresos, empleador/pagador) | no dicho | Autorización previa y finalidad | — | no tengo la norma a la vista |
| Crédito a un consumidor financiero (información previa, reclamos, cobros) | no dicho | Obligaciones del consumidor financiero | — | no tengo la norma a la vista |
| Descuento por libranza sobre ingresos | no dicho | Autorización de descuento y límites | — | no tengo la norma a la vista |
| Retención y trazabilidad de la solicitud y la autorización | no dicho | Tiempo de conservación | — | no tengo la norma a la vista |
| Consentimiento del asociado (firma y prueba) | no dicho | Prueba del consentimiento | — | no tengo la norma a la vista |

Quién lo cierra: revisión jurídica de la organización. Lo que no se resuelva debe entrar al registro como restricción del requerimiento o como riesgo con doliente.

## Requerimientos aceptados que esta especificación no cubre

| REQ | Título | Por qué no |
|---|---|---|
| REQ-1000 | Requerimiento REQ-1000 (sin título real) | Sin `need` ni criterio verificable; no hay contenido que especificar |
| REQ-1001 | Requerimiento REQ-1001 (sin título real) | Ídem |
| REQ-1002 | Requerimiento REQ-1002 (sin título real) | Ídem |
| REQ-1003 | Requerimiento REQ-1003 (sin título real) | Ídem |

**Los 4 aceptados quedan sin cubrir.** No es un olvido: el registro no da material para cubrirlos sin rellenar los huecos con lo razonable.

---
**Pie.** Sale del registro `estado-producto/PRD-300/requirements/` (REQ-1000 a REQ-1003), actualizado el 2026-10-15; fuentes más recientes: acta del comité 2026-10-10 y tablero 2026-10-15. Cubre 0 de 4 requerimientos con contenido (4 en alcance, 4 sin cubrir). Términos aceptados por José Francisco Ñáñez el 2026-10-15 (versión 1.1, familia 0.3.8): https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.8

**Después:** no ofrezco `/criterio-product:product-charter` todavía: los vacíos no están cerrados y el producto no tiene criterio de éxito.
