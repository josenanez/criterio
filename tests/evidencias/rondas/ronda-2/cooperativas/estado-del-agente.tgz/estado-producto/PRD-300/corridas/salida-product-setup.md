## Listo — Crédito de libranza (PRD-300)

**Lo que miré:** 5 documentos · 1 de descubrimiento (una entrevista, 2025-09-20) · la definición y el caso de negocio del 2026-04-09 · acta del comité de producto del 2026-10-10 · tablero de métricas del 2026-10-15. Lo más reciente es del 2026-10-15. Los 5 se pudieron leer.
**Términos:** aceptados para la versión 0.3.8 (términos 1.1) por José Francisco Ñáñez, 2026-10-15 · comprobante en `.criterio/terminos/aceptacion-criterio-product-0.3.8-2026-10-15.md` y `.pdf` · SHA-256 d532cc0636d081a9… (md) y 2198986eb2e729d5… (pdf)

Respuestas tomadas por defecto (sin interfaz): gerente de producto Gustavo Neira (la definición lo dice); quien decide, «Comité de producto» (ningún documento lo dice; es una propuesta mía); estado en `estado-producto/PRD-300`.

### Lo que tu definición afirma, y qué lo sostiene
| Afirmación | Sostenida por | De cuándo |
|---|---|---|
| Asociados rurales no tiene crédito de libranza | Una entrevista a un «cliente entrevistado»: «Lo necesito y hoy no lo tengo». No dice si es de Asociados rurales | 2025-09-20 (12 meses) |
| Volumen mensual de 156.447 | Solo el propio caso de negocio, que se cita a sí mismo como fuente. El tablero mide 121.498: la cifra declarada está 22,3 % por encima | declarada 2026-04-09 · medida 2026-10-15 |
| El proveedor cumple el tiempo pactado | Supuesto marcado «verificado», sin documento que muestre la verificación | declarado 2026-05-14 |
| Hay 4 requerimientos aceptados (REQ-1000 a REQ-1003) | La misma frase de la misma entrevista, en los cuatro. La entrevista no nombra ninguno | 2025-09-20 |

### Lo que no está dicho en ninguna parte
- El criterio de éxito del producto: no aparece en la definición ni en el caso de negocio.
- La fuente de la cifra de 156.447: no hay estudio, base ni supuesto detrás.
- El retorno esperado: dice «en 24 meses», sin monto, sin tasa, sin base de cálculo.
- La propuesta: el título «Propuesta principal» está en la definición y no tiene contenido.
- Qué pidió cada requerimiento: los cuatro se llaman «Requerimiento REQ-100x» y ninguna fuente dice el problema de cada uno. «Quién lo pidió» es «Cliente entrevistado» en los cuatro.
- Qué proyecto ejecuta cada uno: la columna está vacía en los cuatro y la definición dice «Ninguno declarado». El comité decidió «Se mantiene el plan» y ningún documento muestra qué plan.
- La decisión de cada requerimiento por separado: hay una decisión general del comité, no una por requerimiento.
- Quién decide qué se construye: ningún documento lo dice. El comité del 2026-10-10 tiene un solo asistente, Gustavo Neira, que además es doliente de REQ-1001.

### Supuestos sobre los que está escrita
Uno: «El proveedor cumple el tiempo pactado», declarado el 2026-05-14 —después de la fecha de la definición, 2026-04-09— y marcado verificado sin evidencia a la vista. La definición no declara ningún otro supuesto; la demanda de Asociados rurales y el volumen están escritos como hechos.

### Contraste con lo medido
- volumen_mensual: declarado 156.447 (caso de negocio, 2026-04-09) · medido 121.498 (tablero de producto, 2026-10-15) · diferencia 22,3 %, sobre el umbral de 20 %. Hay un solo punto medido: no se puede decir si sube o baja. Además el tablero no dice si el crédito de libranza ya está en venta, así que no sé si ese volumen es del producto o de otra cosa.

### Qué le falta a tu carpeta
Como hallazgo, no como requisito:
- Las transcripciones de las entrevistas: hay una sola, de una línea, de hace 12 meses, y la evidencia de los cuatro requerimientos está vencida por ese motivo.
- La serie de la métrica principal con su fuente: hoy hay un solo punto.
- Las decisiones del comité requerimiento por requerimiento, y con más de una persona en la sala.
- Los 4 requerimientos aceptados llevan entre 47 y 214 días sin proyecto que los ejecute.

Siguiente paso: `/product-discovery` sobre el material de entrevistas, para convertir los temas en requerimientos con la cita de quién los pidió.
