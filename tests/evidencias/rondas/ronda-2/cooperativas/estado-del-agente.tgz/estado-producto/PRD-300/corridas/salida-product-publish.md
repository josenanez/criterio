**No publiqué la ficha de PRD-300 (Crédito de libranza): no hay carpeta de productos publicados configurada.**

En `.criterio/producto/PRD-300/config.json`, `paths.fichas` está vacío. Sin un sitio común acordado, publicar no sirve, y acordarlo es una conversación de la organización, no un comando. No inventé una ruta ni creé ninguna carpeta. No escribí ningún archivo de ficha.

Términos: ya estaban vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-15), así que no hubo que registrar nada.

**Lo que habría publicado, con corte al 2026-10-15:**

- **Lleva:** 4 requerimientos · 0 proyectos · 1 métrica afirmada
- **Segmento declarado:** Asociados rurales
- **Métricas:** `volumen_mensual` = 156447, de `documentos/productos/PRD-300/00-definicion/2026-04-09-caso-de-negocio.md` (2026-04-09)
- **Requerimientos:** REQ-1000, REQ-1001, REQ-1002 y REQ-1003, todos en estado aceptado y ninguno con proyecto asignado.

**Dos cosas que conviene saber antes de publicar:**

- Ningún requerimiento tiene proyecto, así que la ficha no permitiría cruzar por proyecto con otros productos.
- El cálculo da una brecha del 22.3 % entre la cifra declarada de `volumen_mensual` (156447) y la medida (121498, tablero del 2026-10-15). La ficha lleva la cifra declarada, no la medida.

**Para publicar:** definir `paths.fichas` en la configuración con la carpeta común acordada (`productos/publicados/`) y volver a correr `/product-publish`.
