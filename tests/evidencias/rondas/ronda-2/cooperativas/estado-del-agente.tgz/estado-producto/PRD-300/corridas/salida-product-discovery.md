5 piezas revisadas, 0 nuevas o cambiadas desde la última lectura; ningún tema que el registro no tenga ya.
