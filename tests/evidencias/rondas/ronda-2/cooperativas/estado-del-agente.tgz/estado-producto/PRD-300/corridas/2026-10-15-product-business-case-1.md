# Corrida del 2026-10-15 · product-business-case

PRD-300 · 4 requerimientos · 28 s · 9 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 4 |
| `requirement_untraced` | 4 |
| `claim_vs_metric` | 1 |

Caso de negocio armado: 1 cifra declarada sin fuente propia (156.447) contra 121.498 medida (22,3 %, sobre el umbral de 20 %); retorno sin cifra; sin costos, sin criterio de éxito, sin cruce con otros productos (ninguno publicado).

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

# Caso de negocio — Crédito de libranza (PRD-300) · borrador del 2026-10-15
**Desde:** `00-definicion/2026-04-09-definicion-producto.docx` y `00-definicion/2026-04-09-caso-de-negocio.md`, ambos del 2026-04-09 · **Cifras con fuente:** 1 de 2 (la declarada tiene fuente que solo se cita a sí misma; el retorno no trae cifra)

Términos vigentes: versión 0.3.8 (términos 1.1), aceptados por José Francisco Ñáñez el 2026-10-15. Sin interfaz: respuestas por defecto.

## Qué problema resuelve, y para quién
- **Problema:** «El segmento Asociados rurales no tiene crédito de libranza.» (definición, 2026-04-09)
- **Para quién:** Asociados rurales (definición, 2026-04-09).
- **Qué lo sostiene:** una sola entrevista del 2025-09-20 («Lo necesito y hoy no lo tengo»), de un «cliente entrevistado» sin segmento nombrado. Evidencia débil, con 12 meses de antigüedad (umbral: 12).

## Qué se construye
| Requerimiento | Estado | Evidencia de demanda |
|---|---|---|
| REQ-1000 (Rubén Cárdenas) | aceptado, 2026-10-10 | Entrevista 2025-09-20; no nombra el requerimiento |
| REQ-1001 (Gustavo Neira) | aceptado, 2026-10-10 | Misma frase; no nombra el requerimiento |
| REQ-1002 (Laura Vélez) | aceptado, 2026-10-10 | Misma frase; no nombra el requerimiento |
| REQ-1003 (Mauricio Pérez) | aceptado, 2026-10-10 | Misma frase; no nombra el requerimiento |

Los documentos solo los llaman «Requerimiento REQ-100x»: **no se sabe qué pide cada uno**. La decisión del acta es «Se mantiene el plan», general, no por requerimiento. Ninguno tiene proyecto que lo ejecute.

## Las cifras
| Cifra | Valor | Clase | De dónde sale | De cuándo |
|---|---|---|---|---|
| volumen_mensual | 156.447 | Declarada | Caso de negocio, que se cita a sí mismo como fuente; no hay estudio ni base detrás | 2026-04-09 |
| volumen_mensual | 121.498 | Medida | Tablero de producto (bodega de datos), un solo punto | 2026-10-15 |
| Retorno esperado «en 24 meses» | sin cifra | — | Caso de negocio | 2026-04-09 |

No hay cifras de clase supuesta registradas, pero la 156.447 y la demanda de Asociados rurales están escritas como hechos sin fuente: **son supuestos que nadie declaró** y pasan a la sección de supuestos.

### Donde la cifra declarada y la medida no coinciden
| Métrica | Declarada | Medida | Las dos fuentes y fechas |
|---|---|---|---|
| volumen_mensual | 156.447 | 121.498 (declarado 22,3 % por encima; umbral 20 %) | Caso de negocio, 2026-04-09 · Tablero de producto, 2026-10-15 |

Con un solo punto medido no se puede decir si la serie sube o baja. El tablero tampoco dice si el volumen es de este producto o de otra cosa.

## Los costos
| Concepto | Valor | De dónde sale |
|---|---|---|
| Costo de construir | **No hay** | Ningún documento |
| Contratos / cotizaciones | **No hay** | Ningún documento |
| Costo del equipo | **No hay** | Ningún documento |

Sin el costo de construir no hay caso de negocio que evaluar: hay una propuesta.

## Supuestos sobre los que se sostiene
| Supuesto | Qué pasa si resulta falso | Quién lo verificaría |
|---|---|---|
| El volumen mensual será del orden de 156.447 | Todo el retorno que dependa de él se cae; ya hoy el medido está 22,3 % por debajo | Gustavo Neira, con la base de la cifra o con la serie de la bodega de datos |
| Asociados rurales es el segmento que pide el crédito | El producto atiende a quien no lo pidió | Gustavo Neira, con una ronda nueva de entrevistas que nombre el segmento |
| El proveedor cumple el tiempo pactado (declarado 2026-05-14, marcado «verificado») | Retraso en la entrega | Quien tenga el contrato y el registro de entregas: no hay documento de la verificación, y la fecha del supuesto es posterior a la de la definición |

Se ofrece pasarlos a `assumption-tracking`.

## Vacíos
| Qué falta | Por qué importa | Quién lo produce |
|---|---|---|
| Costo de construir (primer vacío) | Sin él no hay caso de negocio | Quien administre el presupuesto; no identificado en los documentos |
| Monto, tasa o base del retorno esperado | «Retorno en 24 meses» sin cifra no se puede evaluar ni medir | El negocio (Gustavo Neira) |
| Origen de 156.447 | La cifra central no tiene de dónde salió | Gustavo Neira |
| Criterio de éxito | El cierre se juzga contra él | Gustavo Neira con el Comité de producto |
| Propuesta (título sin contenido) | No se sabe qué se ofrece | Gustavo Neira |
| Qué pide cada REQ-1000 a REQ-1003 | No se puede dimensionar lo que se construye | Dolientes de cada requerimiento |
| Proyecto que construye el producto | Hoy «Ninguno declarado» | Comité de producto |
| Quién decide | Ningún documento lo dice; el comité del 2026-10-10 tiene un solo asistente | La organización |
| País de oferta | Sin país no se puede citar la norma que aplica (datos personales, libranza, consumidor financiero, retención) | Gustavo Neira; va a revisión jurídica |
| Alternativas consideradas y qué pasa si no se hace | No están en ningún documento | El negocio |

## Cómo se sabrá si funcionó
**No está declarado.** Ni la definición ni el caso de negocio traen criterio de éxito, métrica o fecha de corte. Sin esto el producto no se puede cerrar meses después. La única métrica con serie es volumen_mensual, y no está atada a ningún criterio.

## Si hay otros productos publicados
No hay ninguno a la vista (la ruta de fichas está vacía en la configuración); no se pudo hacer el cruce de `/product-overlap`. Queda pendiente cuando haya productos publicados.

## Después
Los supuestos y las cifras sin fuente pueden pasar a `assumption-tracking` y a `raid-taxonomy`. `/product-charter` no corresponde todavía: el caso no tiene costos, criterio de éxito ni autoridad que decida. Este documento no recomienda aprobar ni rechazar.
