Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-15). Sigo con las respuestas sugeridas: REQ-1000 tiene vacíos y se redacta el borrador marcándolos como vacío del acta, sin rellenarlos.

**Verificación previa (requirement-record):**
- Aceptado: sí, estado `aceptado` desde el comité del 2026-10-10 (asistente registrado: Gustavo Neira).
- Criterio de aceptación: existe, pero «se verifica en producción» no es verificable (no dice qué se mide ni contra qué).
- Evidencia de demanda: una cita del 2025-09-20 («Lo necesito y hoy no lo tengo»); la entrevista no nombra este requerimiento y ya tiene 12 meses (umbral de evidencia vieja: 12).
- Autoridad: la definición no la declara (en la ficha del producto figura «Comité de producto», sugerido).

---

# Acta de constitución — Crédito de libranza, REQ-1000 · borrador del 2026-10-15
**Producto:** PRD-300 Crédito de libranza · **Requerimientos:** REQ-1000

## Qué problema resuelve
«El segmento Asociados rurales no tiene crédito de libranza.» (definición de producto, 2026-04-09). La definición no trae criterio de éxito del producto (`not_found`) y la propuesta aparece sin contenido («Propuesta principal»).

## Criterio de éxito
| Criterio | Fuente | Cómo se verifica |
|---|---|---|
| «se verifica en producción» | comité de producto, 2026-10-10 | **No está dicho.** No hay métrica, umbral ni fecha; hoy no se puede juzgar el cierre con esto. |

## Alcance
### Entra
| REQ | Título | Evidencia que lo sostiene |
|---|---|---|
| REQ-1000 | Requerimiento REQ-1000 (el título es genérico; el documento no dice qué pide) | Entrevistas 2025-09-20: «Lo necesito y hoy no lo tengo». **No nombra REQ-1000**; el qué de la necesidad es `not_found`. |

### No entra
| REQ | Título | Por qué no |
|---|---|---|
| REQ-1001, REQ-1002, REQ-1003 | Requerimientos REQ-1001 a REQ-1003 | Este acta cubre solo REQ-1000, por el argumento del comando. Ningún documento dice que se excluyan por una razón de fondo: si deben ir juntos, es decisión de quien firma. |

## Gobierno
- **Patrocinador:** no está dicho en ningún documento.
- **Gerente propuesto:** no está dicho. Gustavo Neira es el gerente de producto, no se propone como gerente de proyecto. Nombrar a una persona lo decide quien tiene la autoridad.
- **Comité:** Comité de producto (acta 2026-10-10), único órgano que aparece decidiendo; su composición no consta (solo asistió Gustavo Neira).
- **Doliente del requerimiento:** Rubén Cárdenas (acta del comité, 2026-10-10).
- **Autoridad del gerente del proyecto:** no está dicho. Es el campo que más cuesta después.
- **Decisión que respalda el acta:** «Se mantiene el plan», decisión general del comité, no específica de REQ-1000.

## Supuestos que se llevan al proyecto
| Supuesto | Verificado | Se convierte en riesgo de |
|---|---|---|
| El proveedor cumple el tiempo pactado (declarado el 2026-05-14, definición) | Marcado «verificado», sin evidencia de la verificación en los documentos | Pasa a RAID del proyecto con doliente por asignar; el documento no nombra proveedor ni plazo. |
| La demanda de Asociados rurales es la de REQ-1000 (implícito) | No: la entrevista no nombra el requerimiento | Riesgo de construir lo que nadie pidió; doliente por asignar. |
| Volumen mensual de 156.447 (caso de negocio, 2026-04-09) | Contradicho: el tablero del 2026-10-15 mide 121.498; lo declarado está 22,3% por encima (umbral 20%) | Riesgo sobre el retorno esperado; doliente: quien firmó el caso de negocio. |

## Restricciones normativas sin resolver
| Qué toca | Obligación | Norma | Estado |
|---|---|---|---|
| Crédito con descuento por nómina, datos personales y de consumidor financiero | No evaluadas | No se hizo el barrido normativo en esta corrida | Sin resolver; no se opina sobre cumplimiento |

## Vacíos de este acta
| Qué falta | Consecuencia de firmar sin eso | Quién lo cierra |
|---|---|---|
| Qué pide REQ-1000 (necesidad `not_found`) | El proyecto arranca sin saber qué construir | Rubén Cárdenas, con Gustavo Neira |
| Criterio de éxito medible | El cierre no se podrá juzgar meses después | Gustavo Neira con el Comité de producto |
| Evidencia que nombre REQ-1000 y sea reciente (hoy 12 meses) | Se construye sobre una cita general y vieja | Gustavo Neira (nueva ronda de entrevistas) |
| Autoridad y gerente del proyecto | El gerente no sabrá qué puede decidir: escala todo o nada | Comité de producto |
| Patrocinador y presupuesto | Sin línea base contra la cual medir | Quien tenga la autoridad |
| Prioridad (`not_found`) y criterio de éxito de la definición | No se puede ordenar frente a otros requerimientos | Gustavo Neira |
| Hitos | No declarados en ningún documento; el acta no lleva cronograma | Gerente del proyecto, después |

---
**Esto es un borrador.** Lo firma quien tenga la autoridad (por definir; hoy el Comité de producto, sugerido). **La ficha del proyecto NO se creó**: se crea después de la firma, con `portafolio.py init`, llevando `identity.product = PRD-300` y dejando `declared` vacío.

## Quién sigue
El proyecto necesita un gerente, que instala `criterio-project` y corre `/pm-setup` primero. Cuando publique su ficha con `/pm-publish`, `/product-trace` podrá confirmar la traza.
