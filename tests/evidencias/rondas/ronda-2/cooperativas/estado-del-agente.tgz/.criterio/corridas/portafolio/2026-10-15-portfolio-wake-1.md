# Corrida · 2026-10-15-portfolio-wake-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-wake (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-15T09:56:51 · **Fin:** 2026-10-15T09:57:35 · **Duración:** 44 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-wake` | 13 | — | 29 | 59 | Barrido: 71 documentos sin cambios, 0 recalculos; 13 citas de PRY-203 reportadas como fuente no encontrada aunque el archivo existe (causa no verificada). Confirmacion: 5 preguntas sobre PRY-203 formuladas sin respuesta (sesion sin interfaz). No se sabe si PRY-203 cerro hoy. |

Por señal (`portfolio-wake`): `milestone_met_without_evidence` 21, `progress_vs_plan` 6, `vendor_deliverable_late` 5, `declared_vs_evidence` 5, `commitment_overdue` 4, `vendor_accepted_without_evidence` 3, `variance_cost` 3, `variance_time` 2, `milestone_overdue` 2, `commitment_undated` 2, `change_without_baseline` 2, `vendor_invoiced_without_delivery` 1, `silent` 1, `pm_vs_pmo` 1, `vendor_invoiced_over_accepted` 1

## Lo que el agente mostró

Corrida del 15 de octubre hecha y registrada. Revisé 71 documentos, ninguno cambió y no recalculé ningún proyecto. No había peticiones pendientes en el servidor.

- **Términos:** ya estaban vigentes, aceptados por José Francisco Ñáñez el 2026-10-15 (versión 0.3.8). No hizo falta registrarlos otra vez.
- **Citas rotas en PRY-203:** el índice marca 13 citas de la ficha (identidad, plan y presupuesto aprobado) como fuente no encontrada. El acta `00-gobierno/2025-09-22-acta-constitucion.md` sí existe en la carpeta del proyecto. Sospecho de la tilde en «línea» del nombre de la carpeta, pero no lo comprobé, y no toqué la ficha.
- **Confirmación periódica:** nadie podía responder. Dejé cinco preguntas sobre PRY-203 como «preguntadas el 15, sin respuesta»: fecha de fin, presupuesto aprobado, gerente, patrocinador y alcance. El fin planeado de PRY-203 es hoy, y no sé si cerró.
- **Hallazgos abiertos:** `corrida` contó 59 en los 13 proyectos, sobre todo hitos cumplidos sin evidencia (21) y avance contra plan (6). No los revisé en esta corrida.

La salida quedó en `estado/corridas/salida-portfolio-wake.md` y la corrida en `estado/corridas/2026-10-15-portfolio-wake-1.md`. Tardó 29 segundos.

Vuelvo el 2026-10-16. El informe de comité toca el 2026-10-20, para el comité del 2026-10-22.
