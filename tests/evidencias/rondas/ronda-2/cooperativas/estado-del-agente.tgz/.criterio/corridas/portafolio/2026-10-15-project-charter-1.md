# Corrida · 2026-10-15-project-charter-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-charter PRY-205 revisar

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-205

**Inicio:** 2026-10-15T09:48:09 · **Fin:** 2026-10-15T09:49:15 · **Duración:** 66 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-charter` | 13 | — | 50 | 59 | Revisión del acta PRY-205 (2026-06-06): sin autoridad del gerente, sin quién mide el éxito, sin supuestos ni restricciones, objetivo descrito como solución, exclusión sin nombrar, cierre del acta (2028-01-05) distinto al del cronograma (2027-11-02). No abrí el cronograma xlsx; no sé qué se habló fuera de los documentos. |

Por señal (`project-charter`): `milestone_met_without_evidence` 21, `progress_vs_plan` 6, `vendor_deliverable_late` 5, `declared_vs_evidence` 5, `commitment_overdue` 4, `vendor_accepted_without_evidence` 3, `variance_cost` 3, `variance_time` 2, `milestone_overdue` 2, `commitment_undated` 2, `change_without_baseline` 2, `vendor_invoiced_without_delivery` 1, `silent` 1, `pm_vs_pmo` 1, `vendor_invoiced_over_accepted` 1

## Lo que el agente mostró

El acta de PRY-205 (Prevención de lavado de activos) existe, es del 2026-06-06, y le faltan seis campos que importan. El principal es la autoridad del gerente.

Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15), así que no volví a registrarlos.

**Qué falta y qué consecuencia tiene**
- **Autoridad del gerente:** el acta no dice hasta qué monto ni qué cambios puede decidir Camilo Beltrán sin subir a comité. Cualquier ajuste va al Comité de Educación. El proyecto está en rojo y perdió dos semanas por la rotación de un desarrollador clave, y no hay regla sobre quién decide cómo recuperarlas.
- **Objetivo, alcance y exclusiones:** el objetivo describe la solución, no un resultado. El alcance son «Componente 1, 2 y 3» sin detalle. La única exclusión es «Lo que otro proyecto cubre», sin nombrar ese proyecto. Sin esto no hay forma de decir qué cuenta como cambio de alcance.
- **Criterio de éxito:** dice «en producción y medido», sin umbral y sin decir quién lo mide. El cierre queda a discreción de quien reporta.
- **Supuestos y restricciones:** el acta no tiene sección para ninguno. El informe de avance ya trae dos que son supuestos sin declarar: la aprobación del reglamento por el Consejo y la dependencia del proveedor del core. Ambos están sin dueño ni fecha.
- **Dependencias:** el acta dice «Ninguna declarada», lo que contradice el informe del 2026-10-14.
- **Cadencia del comité y hitos:** no hay cadencia declarada. Los hitos están en el cronograma, no en el acta.
- **Lo que sí cumple:** el patrocinador, Sandra Gil, tiene nombre de persona.

**Dos puntos que debe aclarar el gerente**
- **Fecha de cierre:** el acta dice 2028-01-05 y el cronograma v1 termina el 2027-11-02. No sé si la diferencia es un colchón o una contradicción.
- **Presupuesto:** el ejecutado (3.928 M COP, 41 % del aprobado) va por delante del avance declarado (27 %) y supera a lo comprometido (2.805 M COP). Esto último es raro, porque lo ejecutado debería estar incluido en lo comprometido.

**Límites:** no abrí el cronograma `.xlsx` y tomé sus fechas de la ficha. No sé qué se habló fuera de los documentos.

**Siguiente paso:** la regla de autoridad quedó sin definir, y propongo llevarla al Comité de Educación como decisión, no como trámite. Si quiere, paso los dos supuestos sin declarar al registro RAID con `/criterio-portfolio:raid-log`.

La corrida quedó registrada con 50 segundos. El conteo de hallazgos que devolvió el registro (59 en 13 proyectos) es del estado general del portafolio, no de esta revisión. Para PRY-205 solo marca un compromiso sin fecha.

La salida completa está en `/home/claude/banco/ronda-2/cooperativas/espacio/estado/corridas/salida-project-charter.md`. El registro de la corrida es `2026-10-15-project-charter-1`.
