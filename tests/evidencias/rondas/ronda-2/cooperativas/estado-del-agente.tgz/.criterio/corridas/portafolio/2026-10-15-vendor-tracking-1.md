# Corrida · 2026-10-15-vendor-tracking-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:vendor-tracking PRY-200

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-200

**Inicio:** 2026-10-15T09:42:53 · **Fin:** 2026-10-15T09:43:38 · **Duración:** 45 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `vendor-tracking` | 13 | — | 26 | 59 | Cruce de CT-992 de PRY-200: 3 entregables vencidos sin evidencia ni factura. No sabe vigencia ni preaviso del contrato, ni si hay facturas fuera de la ficha. |

Por señal (`vendor-tracking`): `milestone_met_without_evidence` 21, `progress_vs_plan` 6, `vendor_deliverable_late` 5, `declared_vs_evidence` 5, `commitment_overdue` 4, `vendor_accepted_without_evidence` 3, `variance_cost` 3, `variance_time` 2, `milestone_overdue` 2, `commitment_undated` 2, `change_without_baseline` 2, `vendor_invoiced_without_delivery` 1, `silent` 1, `pm_vs_pmo` 1, `vendor_invoiced_over_accepted` 1

## Lo que el agente mostró

En PRY-200, los tres entregables del contrato CT-992 con Talento Solidario Ltda. están vencidos, sin acta de recibo y sin factura declarada.

Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15), así que no los registré otra vez.

| Entregable | Fecha comprometida | Días de atraso | Monto (COP) |
|---|---|---|---|
| Licenciamiento del módulo | 2026-01-01 | 287 | 489.962.167 |
| Bolsa de horas de desarrollo | 2026-03-07 | 222 | 489.962.167 |
| Parametrización de líneas de crédito | 2026-05-11 | 157 | 489.962.167 |

- **Contrato:** dice que Licenciamiento y Parametrización están "en curso", pero ningún documento lo respalda. El contrato exige facturar cada entregable contra un acta de recibo firmada por el gerente (Ricardo Salas), y no existe ninguna.
- **Facturación:** el script reporta 0 facturado y ninguna señal de factura sin entrega. Ese cero sale de la ficha; ningún documento lo confirma.
- **Compromisos:** ninguno vencido. El único es de Liliana Torres, para 2026-11-02, y el acta no dice si es del proveedor.
- **Hitos del proyecto:** tres figuran como cumplidos sin evidencia. No puedo decir cuánto de eso depende del proveedor.
- **Sin dato:** el contrato no trae vigencia, renovación ni preaviso, así que no puedo decir si hay un preaviso por vencer.
- **Comité:** ofrezco llevarlo al comité del 2026-10-22. Los tres montos suman 1.469.886.501 COP; esa suma es mía, el script no la da.

Dejé la salida en `estado/corridas/salida-vendor-tracking.md` y registré la corrida con id `2026-10-15-vendor-tracking-1`. Los conteos de señales de esa corrida son de los 13 proyectos, no solo de PRY-200.
