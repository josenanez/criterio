# Corrida · 2026-10-15-product-view-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:product-view aportes sociales

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-15T09:54:48 · **Fin:** 2026-10-15T09:55:43 · **Duración:** 55 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-view` | 13 | — | 37 | 59 | Vista de aportes sociales: un solo proyecto (PRY-203), 8 alertas, conflicto de fecha fin PM vs PMO sin resolver; 5 proyectos sin producto declarado listados. No se sabe autoridad, fase ni evidencia de los 4 hitos. |

Por señal (`product-view`): `milestone_met_without_evidence` 21, `progress_vs_plan` 6, `vendor_deliverable_late` 5, `declared_vs_evidence` 5, `commitment_overdue` 4, `vendor_accepted_without_evidence` 3, `variance_cost` 3, `variance_time` 2, `milestone_overdue` 2, `commitment_undated` 2, `change_without_baseline` 2, `vendor_invoiced_without_delivery` 1, `silent` 1, `pm_vs_pmo` 1, `vendor_invoiced_over_accepted` 1

## Lo que el agente mostró

## Aportes sociales al 2026-10-15

Los términos ya estaban vigentes (aceptados por José Francisco Ñáñez el 2026-10-15), así que no los registré de nuevo. El producto tiene un solo proyecto, PRY-203 «Aportes sociales en línea», así que la vista por producto no agrega nada a la del proyecto. Es un proyecto en rojo, con 8 alertas.

- **Dinero:** el proyecto trae las cuatro cifras, así que la suma está completa.

  | Concepto | Monto (COP) | Porcentaje |
  |---|---|---|
  | Aprobado | 4.200.000.000 | |
  | Comprometido | 2.705.437.450 | 64,4 % |
  | Ejecutado | 1.996.494.350 | 47,5 % |
  | Proyección | 3.996.935.557 | −4,8 % frente a lo aprobado |

- **Avance:** el avance declarado es 34 %, pero el plan da los 4 hitos como cumplidos, que equivale a 100 %. La brecha es de 66 puntos. Esos 4 hitos están marcados como cumplidos sin evidencia (el más antiguo, hace 294 días).
- **Compromisos:** a Carlos Peña se le venció «Entregar el punto 2» hace 4 días. Laura Vélez tiene «Mandar el ajuste del presupuesto» sin fecha.
- **Fecha de fin sin resolver:** el cronograma de la PMO dice 2026-09-03, que ya pasó. El acta de constitución dice 2026-10-15. Las dos fuentes son de la misma fecha, así que no se puede decir cuál manda y el dueño tiene que confirmarla.
- **Dependencias internas:** ninguna.
- **No se sabe:** la autoridad y la fase del proyecto. Los campos de identidad y plan tienen 13 meses (el umbral es 12) y ninguna fuente está marcada como evidencia.
- **Sin producto declarado:** PRY-202 (Cartera y cobranza), PRY-205 (Ahorro y aportes), PRY-208 (Servicio al asociado), PRY-209 (Bienestar social) y PRY-210 (Crédito). Mientras no declaren producto, nadie responde por el conjunto al que sirven.

Dejé el texto completo en `estado/corridas/salida-product-view.md`. La corrida quedó registrada como `2026-10-15-product-view-1`, con 37 segundos medidos.
