# Corrida · 2026-10-15-budget-tracking-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:budget-tracking PRY-204

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-204

**Inicio:** 2026-10-15T09:42:07 · **Fin:** 2026-10-15T09:42:47 · **Duración:** 40 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `budget-tracking` | 13 | — | 23 | 59 | Informe de presupuesto PRY-204: proyección 17.2% sobre aprobado, comprometido 44.9% (sin alerta), 3 hitos cumplidos sin evidencia. Dijo que no sabe: detalle por proveedor, causa de la proyección, autoridad y fase; no se preparó la solicitud de cambio. |

Por señal (`budget-tracking`): `milestone_met_without_evidence` 21, `progress_vs_plan` 6, `vendor_deliverable_late` 5, `declared_vs_evidence` 5, `commitment_overdue` 4, `vendor_accepted_without_evidence` 3, `variance_cost` 3, `variance_time` 2, `milestone_overdue` 2, `commitment_undated` 2, `change_without_baseline` 2, `vendor_invoiced_without_delivery` 1, `silent` 1, `pm_vs_pmo` 1, `vendor_invoiced_over_accepted` 1

## Lo que el agente mostró

El informe de presupuesto de PRY-204 está hecho y la corrida quedó registrada. La proyección al cierre excede el presupuesto aprobado en 17.2%. El umbral de alerta es 10%.

Salió de la ficha del proyecto, que viene del acta de constitución, el cronograma v1 y el informe de avance del 2026-10-07. Los términos ya estaban vigentes a nombre de José Francisco Ñáñez, así que no los registré de nuevo.

| COP | Monto | % del aprobado |
|---|---|---|
| Aprobado | 6.800.000.000 | 100 |
| Comprometido | 3.051.187.337 | 44.9 |
| Ejecutado | 1.451.249.736 | 21.3 |
| Proyección al cierre | 7.967.490.454 | excede en 17.2 |

- **Disponible real:** 3.748.812.663 COP (aprobado menos comprometido). El comprometido está por debajo del umbral de 90%, así que no hay alerta de tope.
- **Línea base:** hay una sola, la v1 del 2025-10-29. No hay replanificaciones ni solicitudes de cambio de presupuesto.
- **Ejecución frente a avance:** el avance declarado es 73.0% y los tres hitos constan como cumplidos. El plan sostendría 100%, una brecha de 27.0 puntos, y solo se ha ejecutado el 21.3%. Los documentos no dicen si hay trabajo hecho y sin facturar o hitos declarados que no se cumplieron.
- **Hitos sin evidencia:** los tres constan como cumplidos sin evidencia de recibo.
- **Sin dato:**
  - La proyección y las demás cifras tienen una sola fuente, el informe de avance, y no son evidencia contable.
  - No hay detalle por proveedor ni causa de la proyección.
  - Faltan la autoridad y la fase del proyecto.
  - No calculé en pesos el exceso proyectado porque el script no lo entrega.

No preparé la solicitud de cambio de presupuesto, que habría correspondido por la proyección. Queda ofrecida.

Archivos en `/home/claude/banco/ronda-2/cooperativas/espacio/estado/corridas/`:
- `salida-budget-tracking.md`
- `2026-10-15-budget-tracking.md`
