# Corrida · 2026-10-15-status-report-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:status-report PRY-202

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-202

**Inicio:** 2026-10-15T09:39:54 · **Fin:** 2026-10-15T09:40:39 · **Duración:** 45 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `status-report` | 13 | — | 25 | 59 | Estado de PRY-202: verde declarado (2026-09-27) contradicho por hito vencido, hito cumplido sin evidencia, 18 días de silencio y entregable CT-665 aceptado sin acta. Dijo que no sabe: última reunión, producto, autoridad, fase, responsables de RAID. |

Por señal (`status-report`): `milestone_met_without_evidence` 21, `progress_vs_plan` 6, `vendor_deliverable_late` 5, `declared_vs_evidence` 5, `commitment_overdue` 4, `vendor_accepted_without_evidence` 3, `variance_cost` 3, `variance_time` 2, `milestone_overdue` 2, `commitment_undated` 2, `change_without_baseline` 2, `vendor_invoiced_without_delivery` 1, `silent` 1, `pm_vs_pmo` 1, `vendor_invoiced_over_accepted` 1

## Lo que el agente mostró

## PRY-202 Core cooperativo — estado al 2026-10-15

*Sale de la ficha `estado/records/PRY-202.json` (actualizada 2026-10-15) y del cálculo con corte al 2026-10-15. Los términos están vigentes y los aceptó José Francisco Ñáñez el 2026-10-15.*

**El gerente (Camilo Beltrán) declara verde y 31%, al 2026-09-27.** La declaración tiene 18 días, así que no está vencida (el umbral es 30). La evidencia la contradice: la ficha no tiene ningún documento de evidencia, solo 2 declaraciones. El 31% sí cae dentro de lo que el plan soporta (20–40%), pero el verde no.

**Lo que el semáforo no explica:**
- **Hito cumplido sin evidencia:** «Diseño funcional aprobado», previsto para el 2026-07-15 (92 días atrás), no tiene documento que lo respalde.
- **Hito vencido:** «Ambiente de pruebas certificado» venció el 2026-10-04, hace 11 días.
- **Silencio:** el último documento es del 2026-09-27, hace 18 días (el umbral es 15). No hay dato de la última reunión.

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2027-06-05 | 2027-06-05 | 0 días |
| Presupuesto | COP 2.400.000.000 | COP 2.400.000.000 | proyección COP 2.381.420.013 (-0,8%) |

- **Ejecutado:** COP 576.917.858 (24,0%).
- **Comprometido:** COP 1.542.183.719 (64,3%).
- **Disponible real:** COP 857.816.281.
- **Replanificaciones y cambios:** ninguno. Solo existe la línea base v1, aprobada el 2026-04-15.

### Hitos
| Hito | Base = vigente | Estado | Evidencia |
|---|---|---|---|
| Diseño funcional aprobado | 2026-07-15 | declarado cumplido | ninguna |
| Ambiente de pruebas certificado | 2026-10-04 | pendiente, vencido 11 días | ninguna |
| Integración con el core cooperativo | 2026-12-24 | pendiente | — |
| Piloto con asociados | 2027-03-16 | pendiente | — |
| Salida a producción | 2027-06-05 | pendiente | — |

### Dónde no coincide
- **Informe del gerente frente al cronograma:** el informe del 2026-09-27 dice verde y a la vez reporta tres incidencias: la prueba de carga no alcanzó el umbral y se repite, se reprogramó la salida por el cierre contable, y el Consejo pidió ajustar el reglamento antes del piloto. El cronograma conserva las fechas originales, sin replanificación ni cambio formalizado.
- **CT-665 (Sistemas Cooperativos Ltda.):** «Licenciamiento del módulo» figura aceptado y facturado por COP 96.527.977, sin acta de recibo. El mismo entregable con CT-527 (Datos para Cooperativas) sí tiene acta, del 2026-08-09.

### Abierto
- **Sin movimiento desde 2026-09-27, todos sin responsable identificado:** dos riesgos y tres incidencias, y ninguno trae probabilidad, impacto ni fecha.
  - Riesgo: cambio normativo del supervisor que puede mover el alcance.
  - Riesgo: el proveedor no ha confirmado la fecha de la última entrega.
  - Incidencia: el Consejo pidió ajustar el reglamento antes del piloto.
  - Incidencia: se reprogramó la salida por el cierre contable.
  - Incidencia: la prueba de carga no alcanzó el umbral y se repite.
- **Compromisos vencidos y dependencias:** ninguno registrado. La ficha no tiene compromisos ni dependencias, lo cual no prueba que no existan.

### Sin dato
Producto (el acta dice «No aplica»), autoridad, fase, última reunión y responsables de los riesgos e incidencias.

---
Versión 0.3.8 (criterio-portfolio) · ficha PRY-202 actualizada 2026-10-15, declaración del 2026-09-27 · Campos inciertos: producto, autoridad, fase · Términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.8

Con el hito vencido, el verde sin sustento y los riesgos sin dueño, se puede preparar el punto de comité del 2026-10-22. No lo preparé porque no se pidió.

La corrida quedó registrada como `2026-10-15-status-report-1` (25 segundos), con la salida guardada en `estado/corridas/salida-status-report.md`.
