<!-- origen: PRY-205-prevención-de-lavado-de-activos/00-gobierno/2026-06-06-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Prevención de lavado de activos

Código: PRY-205

Área dueña: Ahorro y aportes

Patrocinador: Sandra Gil

Gerente de proyecto: Camilo Beltrán

Comité: Comité de Educación

Producto asociado: No aplica

Fecha de aprobación: 2026-06-06

Objetivo del negocio

Entregar prevención de lavado de activos para Ahorro y aportes.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

9.500.000.000 COP, aprobado por Comité de Educación el 2026-06-06.

Fechas comprometidas

Fecha

Inicio

2026-06-16

Cierre

2028-01-05

Criterio de éxito

Prevención de lavado de activos en producción y medido.

Dependencias declaradas

• Ninguna declarada
