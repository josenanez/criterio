## Listo — Cooperativa

**Miré:** 71 documentos en 13 proyectos · formatos: .md 31, .pdf 14, .docx 11, .xlsx 9, .csv 4, .json 1, .txt 1 · más reciente: 2026-10-15
**Eres:** PMO del portafolio (sugerido: hay varios proyectos)
**Te aviso:** dos días antes del comité (sugerido: comité semanal, próximo 2026-10-22, informe el 2026-10-20)
**En:** presentación (sugerido)
**Términos:** aceptados para la versión 0.3.8 (términos 1.1) por José Francisco Ñáñez, 2026-10-15 · comprobante en `.criterio/terminos/aceptacion-criterio-portfolio-0.3.8-2026-10-15.md` y `.pdf` · SHA-256 906ca52cb3296d17…

Dónde queda: configuración en `.criterio/portafolio/config.json`, lo que voy encontrando en `estado/`, informes en `reportes/`.

### Probé con tres proyectos

| Proyecto | Documentos | Qué supe | Qué no está |
|---|---|---|---|
| PRY-203 Aportes sociales en línea | 6 | Patrocinador Andrés Lozano, gerente Elena Duarte, Comité de Riesgos. Declara **rojo, 34 %** (corte 2026-10-14). Aprobado 4.200 M COP, comprometido 2.705 M, ejecutado 1.996 M, proyección 3.997 M. Cierre comprometido **2026-10-15**. Publicó su propia ficha (`ficha-pm.json`), guardada aparte | Autoridad del gerente, fase |
| PRY-210 Corresponsales rurales | 7 | Patrocinador Gustavo Neira, gerente Sandra Gil, Consejo de Administración. Declara **rojo, 35 %** (2026-10-06). Aprobado 4.200 M COP, comprometido 2.300 M, ejecutado 1.677 M, proyección 4.219 M. Dos ampliaciones de alcance autorizadas (CC-01 +76 días y 152 M; CC-02 +101 días y 202 M) | Producto («No aplica»), autoridad, fase, nombre de quién autorizó |
| PRY-201 Apertura de ahorro en línea | 6 | Patrocinador Felipe Arango, gerente Javier Hoyos, Comité de Riesgos, producto ahorro a la vista. Declara **verde, 47 %** (2026-09-24). Aprobado 1.200 M COP, comprometido 428 M, ejecutado 295 M. Contrato CT-683 con Soluciones Solidarias | Autoridad, fase |

### Hallazgos (los que levantó el cálculo, 25 señales en total)

**PRY-201 — 11 señales. El verde está contradicho** (`declared_vs_evidence`):
- `progress_vs_plan`: declara 47 %; el cronograma tiene los 5 hitos cerrados (el plan sustenta 100 %), 53 puntos de diferencia.
- `milestone_met_without_evidence` ×5: los cinco hitos figuran cerrados y no hay un solo acta de recibo (el último, «Salida a producción», 2026-07-14).
- `vendor_deliverable_late` ×2: «Licenciamiento del módulo» (vencido 2026-02-12, 245 días) y «Bolsa de horas de desarrollo» (2026-05-11, 157 días), ambos sin recibo.
- `vendor_invoiced_without_delivery`: factura FV-1683 por 121.861.832 COP radicada el 2026-09-06 con ambos entregables sin acta de recibo.
- `commitment_overdue`: Carlos Peña, «Entregar el punto 12», vencido 2026-09-27 (18 días).

**PRY-203 — 8 señales:**
- `progress_vs_plan`: declara 34 % con los 4 hitos cerrados (66 puntos de diferencia).
- `milestone_met_without_evidence` ×4: ningún hito tiene acta de recibo.
- `pm_vs_pmo` sobre `plan.end_date`: el cronograma dice 2026-09-03 y la ficha del gerente, 2026-10-15.
- `commitment_overdue`: Carlos Peña, «Entregar el punto 2», vencido 2026-10-11.
- `commitment_undated`: Laura Vélez, ajuste del presupuesto, «la otra semana» sin fecha.
- En las notas del 2026-10-15 se comentó un riesgo (el proveedor podría no llegar con el equipo completo) que nadie anotó; quedó en la ficha sin dueño.

**PRY-210 — 6 señales:**
- `variance_time`: 177 días (74,1 %) contra la línea base original.
- `change_without_baseline`: CC-02 (+101 días) no tiene línea base nueva.
- `progress_vs_plan`: declara 35 %; el plan sustenta entre 67 % y 100 %.
- `milestone_met_without_evidence` ×2: Diseño funcional aprobado y Ambiente de pruebas certificado, sin acta.
- `commitment_overdue`: Rubén Cárdenas, «Entregar el punto 12», vencido 2026-10-07.

Además: ninguno de los tres tiene definida la autoridad del gerente (`no_authority` 3 de 3).

### El portafolio completo
10 proyectos más (PRY-199, 200, 202, 204 al 209, 211) y 51 documentos · aproximadamente 25 a 35 minutos, en un lote de diez, uno tras otro.

### Lo que le falta a tu carpeta
- Ninguna acta de recibo en estos tres proyectos: los hitos «cerrados» no se pueden probar. (PRY-199, 200 y 202 sí traen algunas.)
- Las actas de constitución no dicen hasta dónde puede decidir el gerente sin subir a comité.
- El alcance de las actas dice «Componente 1, 2, 3»: no hay nada concreto contra qué medir.
- Las notas de reunión de PRY-203 están sueltas en la raíz del proyecto, no en `30-reuniones/`.
- PRY-210 no dice quién autorizó los cambios («el comité»).

Ninguno es bloqueante.
