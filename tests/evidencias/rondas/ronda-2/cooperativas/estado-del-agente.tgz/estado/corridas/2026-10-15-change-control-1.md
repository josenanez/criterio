# Corrida del 2026-10-15 · change-control

13 proyectos · 58 s · 59 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 21 |
| `progress_vs_plan` | 6 |
| `vendor_deliverable_late` | 5 |
| `declared_vs_evidence` | 5 |
| `commitment_overdue` | 4 |
| `vendor_accepted_without_evidence` | 3 |
| `variance_cost` | 3 |
| `variance_time` | 2 |
| `milestone_overdue` | 2 |
| `commitment_undated` | 2 |
| `change_without_baseline` | 2 |
| `vendor_invoiced_without_delivery` | 1 |
| `silent` | 1 |
| `pm_vs_pmo` | 1 |
| `vendor_invoiced_over_accepted` | 1 |

Solicitud PRY-200 +30 días: sin solicitante, motivo ni impacto en alcance/costo; la salida a producción figura ya recibida (acta 2026-10-04) y cerrada; sin autoridad declarada en el acta, va a comité; CC-01 aprobado sin nombre ni acta; impacto en portafolio 0 por dependencias declaradas (ninguna), no se sabe si hay no declaradas; no se calculó costo ni holgura.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

Sale de la ficha `estado/records/PRY-200.json` (actualizada 2026-10-15) y de los documentos de `documentos/proyectos/PRY-200-crédito-de-libranza-digital/`. Términos vigentes: aceptados por José Francisco Ñáñez el 2026-10-15 (versión 0.3.8).

## Solicitud de cambio — PRY-200 Crédito de libranza digital — 2026-10-15

**Qué se pide:** mover la salida a producción 30 días, del 2026-10-18 al 2026-11-17.
**Quién lo pide:** no consta. La solicitud llegó como argumento de la invocación; no hay documento de solicitud en la carpeta (el único es CC-01, del 2026-10-03, que es otro cambio).
**Por qué:** no consta. El informe de avance del 2026-10-11 habla de dos semanas perdidas por la rotación de un desarrollador clave, pero no lo vincula a este pedido, y dos semanas no son 30 días.

### Lo que hay que resolver antes de evaluar

La salida a producción **ya figura como recibida**. El acta de recibo del 2026-10-04 dice «se recibe a satisfacción el entregable Salida a producción», firmada por Ricardo Salas (el gerente; no aparece patrocinador ni usuario), y el cronograma v2 la marca `cerrado` con fecha vigente 2026-10-18. Es decir, se pide mover 30 días un hito que los documentos dan por cumplido 14 días antes de su fecha. Sólo una de estas dos cosas puede ser cierta:

1. La salida a producción no ocurrió, y el acta de recibo y el estado `cerrado` están mal. Entonces el cambio no es «mover 30 días»: es corregir el registro y el hito está abierto.
2. La salida ocurrió el 2026-10-04, y entonces no hay nada que mover; lo que se pide sería otra cosa (¿el cierre del proyecto?).

El avance declarado (53 %) acompaña a la primera lectura: con 5 de 5 hitos cerrados el plan sostiene 100 %, y el gerente declara 53 %, una brecha de 47 puntos. Esa contradicción no la resuelvo yo; la tiene que resolver Ricardo Salas.

### Impacto
| Dimensión | Hoy | Con el cambio | Diferencia |
|---|---|---|---|
| Alcance | Sin cambio declarado en esta solicitud | No consta | **Sin impacto declarado.** Si el alcance se mantiene y el plazo crece, alguien lo absorbe: en calidad, en horas no pagadas o en el piloto que ya se dio por hecho. No consta quién. |
| Tiempo | Salida 2026-10-18 (línea base vigente v2) | 2026-11-17 | +30 días. Contra la línea base original (2026-06-22): **+148 días**, hoy +118. |
| Costo | Aprobado 4.200.000.000 COP; comprometido 2.082.032.705; ejecutado 1.158.162.686; proyección 4.085.574.704 | No consta | **Sin impacto declarado.** La proyección ya está 2,7 % por debajo del aprobado, sin fundamento visible tras +118 días y +236.000.000 COP aprobados en CC-01. Treinta días más de equipo no salen gratis; cuánto cuestan no se puede calcular con lo que hay. |

### Efecto en el portafolio
| Proyecto afectado | Cómo | Gerente |
|---|---|---|
| Ninguno | `impact` recorrió las dependencias declaradas y no alcanza a nadie: 0 directos, 0 indirectos, 0 que no puedan sostener su fecha, 0 sin confirmar. | — |

Esto sólo dice que **nadie declaró depender de PRY-200**: el acta dice «Ninguna declarada» y la ficha no tiene dependencias en ningún proyecto. No dice que no haya. PRY-209 (Convenios de libranza con empresas, Sandra Gil) trata un tema vecino; no hay documento que los ligue, y lo dejo como pregunta, no como hallazgo. Tampoco sé cuántos días se movería cada actividad: la ficha no tiene holgura.

### Quién decide
**Autoridad requerida:** no se puede determinar. La ficha no tiene autoridad declarada (`identity.authority`: no encontrada) y el acta no fija umbrales de tiempo ni de costo para el gerente, el patrocinador o el comité.
**Según:** el acta (2025-10-18) sólo dice que el Comité de Riesgos aprobó el presupuesto. Patrocinador: Paula Céspedes. Gerente: Ricardo Salas.
**Va a comité:** sí, por defecto. Sin autoridad escrita, un cambio de fecha de una línea base ya movida una vez no lo puede decidir el gerente, que además es quien firmó el acta de recibo. Ese vacío es el hallazgo de fondo.

Sobre el antecedente: CC-01 figura aprobado con «Autorizada por el comité», sin nombre, sin fecha de decisión y sin acta. El comité del 2026-10-05, posterior a CC-01, trató «Avance» y «Compromisos» y no lo menciona. La línea base v2 se aprobó el 2026-10-11 por CC-01. La reconciliación da 0 días sin autorizar (118 movidos, 118 autorizados), pero esa autorización descansa en una frase sin autor. Que cuadre la aritmética no prueba que alguien con autoridad lo haya decidido.

### Si no se aprueba
Queda la línea base v2: salida 2026-10-18, que los documentos ya dan por cumplida. El proyecto tal como está tiene 8 señales abiertas: desviación de 118 días (49,8 %) contra la original, avance declarado 47 puntos por debajo de lo que el plan sostiene, tres hitos cerrados sin evidencia (ambiente de pruebas, integración con el core, piloto con asociados) y tres entregables del proveedor Talento Solidario (CT-992) vencidos y sin aceptar, de 157 a 287 días, con 0 facturado. Mover 30 días más no cambia nada de eso; lo que hay que explicar es la brecha del 53 %.

### Si se aprueba
Línea base v3 — salida **2026-11-17** · presupuesto **no consta** (vigente 4.200.000.000 COP; a CC-01 se le atribuyen 236.000.000 adicionales que la ficha no suma al aprobado) · motivo: **no consta; hay que escribirlo**. Documento que la aprobó: ninguno todavía.
Desviación acumulada contra la línea base original: **+148 días** en la salida a producción (22 jun → 17 nov 2026) · costo: **no se puede calcular**, sin cifra de impacto. Sería la tercera línea base (la v2 ya movió 118 días); el conteo de replanificaciones sube de 1 a 2.

Otra cosa que no cuadra: el acta fija el cierre del proyecto en 2026-07-16, y el cronograma v2 no trae fecha de cierre. La ficha usa la salida a producción como fecha final por falta de otra. Aunque se apruebe el cambio, no hay una fecha de cierre vigente.

### Qué no sé
- Quién pide el cambio, por qué y con qué documento.
- Si la salida a producción ocurrió el 2026-10-04 o no.
- El impacto en alcance y costo de los 30 días.
- Quién tiene autoridad para aprobar: no está escrito en el acta.
- Qué actividades se moverían y cuántos días cada una.
- Si algún otro proyecto depende de PRY-200 sin haberlo declarado.

## Después
Esto debe ir a comité, no se puede registrar como línea base v3 aún. Antes: (1) que Ricardo Salas aclare si la salida a producción ocurrió, (2) que la solicitud se escriba con motivo y con costo, (3) que el comité decida quién tiene la autoridad. Puedo preparar el paquete de comité (steering-pack) cuando esté (1).

_Nota de la corrida: en la sesión sin interfaz tomé la respuesta sugerida a cada pregunta, que fue ninguna: no se pidió nada a nadie._
