# Rostrum — modo «para mirarlo un rato»

Términos vigentes (versión 1.1, aceptada por José Francisco Ñáñez el 2026-10-15). Hay informe HTML en `reportes/` (13 proyectos, 8 productos, decisiones).

Elegiste la primera forma (rato): se levanta, se mira y se apaga. Escucha en `127.0.0.1:8787`, solo en este equipo. Si el puerto está ocupado: `--puerto 8788`. Se detiene con Ctrl-C.

```
python3 "/home/claude/banco/criterio/plugins/criterio-portfolio/scripts/servidor.py" --informe /home/claude/banco/ronda-2/cooperativas/espacio/reportes --estado /home/claude/banco/ronda-2/cooperativas/espacio/estado --config /home/claude/banco/ronda-2/cooperativas/espacio/.criterio/portafolio/config.json
```

| Ruta | Qué es | Para quién |
|---|---|---|
| `/` | Portada con las secciones y el formulario de peticiones | Todos |
| `/pmo` | Cómo va el portafolio: verdes sin sustento, silencios, patrocinadores repetidos | La PMO |
| `/decisiones` | Lo que necesita decisión, con la consecuencia de no decidir | Comité y patrocinador |
| `/proyectos` | Listado ordenado por lo que más pide atención | Todos |
| `/p/<código>` | Informe de un proyecto, con enlace a su producto | Quien gerencia |
| `/productos` | Listado de productos y proyectos sin producto declarado | Quien responde por un producto |
| `/producto/<nombre>` | Informe de un producto, con enlace a sus proyectos | Quien responde por un producto |
| `/estado.json` | Fecha del informe y peticiones abiertas | Un mecanismo |

Lo que Rostrum no hace: no calcula (sirve lo que `informe.py` ya escribió), no escribe fichas (solo la petición, en `estado/peticiones/`), no autentica y no manda correos. El formulario deja la petición en cola; el agente la ve en `due`/`requests`.

Nombre de la organización en el portal: Cooperativa.

**Cierre:** este enlace (`http://127.0.0.1:8787/`) sirve solo en este equipo y solo mientras corra el proceso; no se le puede pasar a un patrocinador. El informe es del 2026-10-15 (fecha de los archivos en `reportes/`) y queda desactualizado cuando cambien las fichas o los documentos: hay que volver a correr `/portfolio-report html`. Para un enlace estable, la segunda forma («que quede corriendo») requiere pedir a la organización un host y puerto internos y publicarlo detrás de su control de acceso.
