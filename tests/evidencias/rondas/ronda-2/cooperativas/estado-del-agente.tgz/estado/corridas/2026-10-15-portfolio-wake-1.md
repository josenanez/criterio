# Corrida del 2026-10-15 · portfolio-wake

13 proyectos · 29 s · 59 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 21 |
| `progress_vs_plan` | 6 |
| `vendor_deliverable_late` | 5 |
| `declared_vs_evidence` | 5 |
| `commitment_overdue` | 4 |
| `vendor_accepted_without_evidence` | 3 |
| `variance_cost` | 3 |
| `variance_time` | 2 |
| `milestone_overdue` | 2 |
| `commitment_undated` | 2 |
| `change_without_baseline` | 2 |
| `vendor_invoiced_without_delivery` | 1 |
| `silent` | 1 |
| `pm_vs_pmo` | 1 |
| `vendor_invoiced_over_accepted` | 1 |

Barrido: 71 documentos sin cambios, 0 recalculos; 13 citas de PRY-203 reportadas como fuente no encontrada aunque el archivo existe (causa no verificada). Confirmacion: 5 preguntas sobre PRY-203 formuladas sin respuesta (sesion sin interfaz). No se sabe si PRY-203 cerro hoy.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## 2026-10-15

**Revisé:** 71 documentos · 0 cambiaron · 0 proyectos recalculados. Peticiones en el servidor: ninguna.

### Lo que cruzó un umbral
Nada cruzó un umbral. Sí hay una anomalía en el índice: 13 citas de PRY-203 (identidad, plan y presupuesto aprobado) apuntan a `00-gobierno/2025-09-22-acta-constitucion.md` y el índice las reporta como fuente no encontrada, aunque ese archivo existe en la carpeta del proyecto (`PRY-203-aportes-sociales-en-línea/00-gobierno/`). No releí nada ni toqué la ficha; la causa probable es cómo el índice resuelve la ruta de esa carpeta (lleva tilde: «línea»), pero no lo verifiqué. Hasta que se aclare, esas 13 citas no están comprobadas por el índice.

### Preguntas
Sin nadie en la sesión, no se hicieron: quedan preguntadas el 15 de octubre, sin respuesta. Los cinco campos, por importancia, de PRY-203 (cuyo fin planeado es hoy, 2026-10-15):
1. Fecha de fin (`plan.end_date` = 2026-10-15), fuente: acta de constitución 2025-09-22. ¿Sigue vigente o hubo reprogramación?
2. Presupuesto aprobado (`money.approved` = COP 4.200.000.000), misma fuente. ¿Cambió con algún control de cambios?
3. Gerente (`identity.manager` = Elena Duarte), misma fuente. ¿Sigue siéndolo?
4. Patrocinador (`identity.sponsor` = Andrés Lozano), misma fuente. ¿Sigue siéndolo?
5. Alcance (`plan.scope_summary` = «Componente 1; Componente 2; Componente 3»), misma fuente. ¿Se mantiene?

**Vuelvo el 2026-10-16.** Informe de comité: el 2026-10-20, para el comité del 2026-10-22.
