# Corrida del 2026-10-15 · vendor-tracking

13 proyectos · 26 s · 59 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 21 |
| `progress_vs_plan` | 6 |
| `vendor_deliverable_late` | 5 |
| `declared_vs_evidence` | 5 |
| `commitment_overdue` | 4 |
| `vendor_accepted_without_evidence` | 3 |
| `variance_cost` | 3 |
| `variance_time` | 2 |
| `milestone_overdue` | 2 |
| `commitment_undated` | 2 |
| `change_without_baseline` | 2 |
| `vendor_invoiced_without_delivery` | 1 |
| `silent` | 1 |
| `pm_vs_pmo` | 1 |
| `vendor_invoiced_over_accepted` | 1 |

Cruce de CT-992 de PRY-200: 3 entregables vencidos sin evidencia ni factura. No sabe vigencia ni preaviso del contrato, ni si hay facturas fuera de la ficha.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

**Sale de:** 00-gobierno/2025-10-23-contrato-ct-992.docx, ficha estado/records/PRY-200.json, 30-reuniones/2026-10-05-comite-semanal.md, 20-seguimiento/2026-10-11-informe-avance.md y la salida de `portafolio.py compute` (as_of 2026-10-15). Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15).

## Proveedores — PRY-200 Crédito de libranza digital al 2026-10-15

### Talento Solidario Ltda. — contrato CT-992
**Vigencia:** sin dato (el contrato solo trae fecha de firma, 2025-10-23) · **Preaviso de no renovación:** sin dato · **Vence el:** sin dato

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento del módulo (489.962.167 COP) | 2026-01-01 | pending (el contrato dice "en curso") | ninguna | 0 |
| Bolsa de horas de desarrollo (489.962.167 COP) | 2026-03-07 | pending (el contrato dice "pendiente") | ninguna | 0 |
| Parametrización de líneas de crédito (489.962.167 COP) | 2026-05-11 | pending (el contrato dice "en curso") | ninguna | 0 |

Cifras del script: 3 entregables, 0 aceptados, `invoiced` = 0.0, `accepted_without_evidence` = [].

### Dónde no cuadra
| Qué | Dice el contrato | Dice la evidencia | Fuentes |
|---|---|---|---|
| Atraso de los 3 entregables | Fechas 2026-01-01, 2026-03-07, 2026-05-11 | Sin acta de recibo ni aceptación: atrasados 287, 222 y 157 días (`vendor_deliverable_late`) | contrato CT-992; compute |
| Estado de "Licenciamiento" y "Parametrización" | "en curso" | Sin ningún documento que lo respalde; el estado queda `pending` | contrato CT-992 |
| Hitos del proyecto vs. proveedor | n/a | "Ambiente de pruebas certificado", "Integración con el core" y "Piloto con asociados" figuran `met` sin evidencia (258, 210 y 163 días); "Salida a producción" figura `met` con fecha vigente 2026-10-18, posterior a hoy. Con 0 entregables del proveedor aceptados, no se puede decir qué parte de eso depende de Talento Solidario. | ficha PRY-200; compute |

No se levantó `vendor_invoiced_without_delivery`: no hay factura declarada (facturado = 0).

### Sin evidencia de recibo
| Entregable | Marcado como | Desde |
|---|---|---|
| Licenciamiento del módulo | pending / "en curso" | 2026-01-01 |
| Bolsa de horas de desarrollo | pending / "pendiente" | 2026-03-07 |
| Parametrización de líneas de crédito | pending / "en curso" | 2026-05-11 |

Las actas de recibo de la carpeta (diseño funcional, salida a producción) son de hitos del proyecto, no de entregables del contrato CT-992.

### Compromisos del proveedor vencidos
Ninguno. El único compromiso registrado (Liliana Torres, "Entregar el punto 6", para 2026-11-02, comité del 2026-10-05) no está vencido, y el acta no dice si Liliana Torres es del proveedor.

### Sin dato
- Vigencia, terminación, renovación automática y preaviso de CT-992: el contrato no los trae. No se puede decir si hay un preaviso por vencer.
- Facturas: no hay documento que declare facturación; se toma 0 como declarado en la ficha, no como confirmado.
- Condición de pago: cada entregable se factura contra acta de recibo firmada por el gerente (Ricardo Salas). Ninguna existe.
- Si el CC-01 (+118 días, 236.000.000 COP) afectó el contrato con el proveedor: no está dicho.

### Después
Hay tres entregables vencidos, que suman 1.469.886.501 COP comprometidos (3 × 489.962.167), sin recibo y sin factura. Si quiere llevarlo a comité (próximo: 2026-10-22), la pregunta es si el proveedor entregó algo no documentado, o si el proyecto declara hitos cumplidos sin lo que el contrato debía aportar.

*Pie de rigor: borrador de trabajo, no asesoría. Cada dato sale del documento citado y la verificación es suya. El script no dio el total de 1.469.886.501; es una suma mía de los tres montos del contrato, así que revísela.*
