# Corrida del 2026-10-15 · portfolio-report

13 proyectos · 71 documentos, 0 releídos y 71 sin cambio · 34 s · 59 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 21 |
| `progress_vs_plan` | 6 |
| `vendor_deliverable_late` | 5 |
| `declared_vs_evidence` | 5 |
| `commitment_overdue` | 4 |
| `vendor_accepted_without_evidence` | 3 |
| `variance_cost` | 3 |
| `variance_time` | 2 |
| `milestone_overdue` | 2 |
| `commitment_undated` | 2 |
| `change_without_baseline` | 2 |
| `vendor_invoiced_without_delivery` | 1 |
| `silent` | 1 |
| `pm_vs_pmo` | 1 |
| `vendor_invoiced_over_accepted` | 1 |

El informe quedó en `/home/claude/banco/ronda-2/cooperativas/espacio/reportes/index.html`.

Primer informe HTML; sin instantánea previa, sin delta. Mirar los 5 verdes contradichos y las facturas de PRY-201 y PRY-206.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

# Portafolio — 2026-10-15
13 proyectos · 12 con hallazgos (59 señales) · último barrido 2026-10-15

**Fichas cargadas:** 13 (`estado/records/PRY-199` … `PRY-211`), todas del barrido de hoy, 2026-10-15; ninguna supera la semana.
**Términos:** vigentes, aceptados por José Francisco Ñáñez el 2026-10-15 (versión 0.3.8).

## Qué cambió desde la corrida anterior
Sin cambios desde la corrida anterior. La única instantánea es la de hoy (`snapshots/2026-10-15.json`): este es el punto de partida, no hay delta.

## Contradicciones abiertas
Hay una: **PRY-203** `plan.end_date` — la PMO tiene 2026-09-03 (cronograma v1, 2025-09-22) y el gerente del proyecto declara 2026-10-15.
Además, 5 proyectos declaran verde y la evidencia lo contradice: PRY-201, PRY-202, PRY-207, PRY-209, PRY-211 (ver «Sin sustento»).

## Hitos vencidos sin evidencia
| Proyecto | Hito | Fecha | Días |
|---|---|---|---|
| PRY-202 Core cooperativo | Ambiente de pruebas certificado | 2026-10-04 | 11 |
| PRY-207 Microcrédito rural | Integración con el core cooperativo | 2026-10-10 | 5 |

## Proyectos en silencio
| Proyecto | Días | Desde |
|---|---|---|
| PRY-202 Core cooperativo | 18 (umbral 15) | 2026-09-27 |

## Dependencias en riesgo
Sin dependencias en riesgo detectadas por el cálculo. PRY-202 (Core cooperativo) está en silencio y con un hito vencido; los proyectos con «Integración con el core cooperativo» (PRY-200, 201, 203, 204, 207) dependen de él por nombre de hito, pero ninguna ficha declara la dependencia por código. Queda como pregunta, no como hallazgo.

## Sin sustento
Hitos declarados cumplidos sin evidencia que los respalde:
| Proyecto | Hitos «cumplidos» sin evidencia |
|---|---|
| PRY-201 Apertura de ahorro en línea | 5 de 5 (el más antiguo, 285 días) |
| PRY-203 Aportes sociales en línea | 4 de 4 (hasta 294 días) |
| PRY-200 Crédito de libranza digital | 3 |
| PRY-204 Tarjeta débito | 3 |
| PRY-210 Corresponsales rurales | 2 |
| PRY-211 Cobranza digital | 2 |
| PRY-202 Core cooperativo | 1 |
| PRY-207 Microcrédito rural | 1 |

Avance declarado vs. lo que el plan sustenta: PRY-201 (47 % vs. 100 %), PRY-203 (34 % vs. 100 %), PRY-200 (53 % vs. 100 %), PRY-210 (35 % vs. 67–100 %), PRY-204 (73 % vs. 100 %) van por detrás; PRY-207 declara 91 % cuando el plan sustenta 50–75 %.

Proveedores: PRY-201 facturó 121.861.832 sin entrega (Soluciones Solidarias S.A.S.); PRY-206 facturó 73.545.581 contra 55.571.557 aceptados (diferencia 17.974.024); PRY-202 y PRY-206 tienen entregables «aceptados» sin evidencia; PRY-200 (3) y PRY-201 (2) tienen entregables de proveedor vencidos y pendientes.

## Vacíos de información
- Ningún proyecto tiene autoridad (patrocinador/aprobador) identificada: 13 de 13.
- 5 proyectos sin producto asignado: PRY-202, 205, 208, 209, 210.
- Compromisos sin fecha: PRY-203 (Laura Vélez, ajuste del presupuesto), PRY-205 (María Restrepo, punto 2).
- Compromisos vencidos: PRY-201 (Carlos Peña, 18 d), PRY-206 (María Restrepo, 18 d), PRY-210 (Rubén Cárdenas, 8 d), PRY-203 (Carlos Peña, 4 d).
- Cambios sin línea base: PRY-208 CC-01 (113 d), PRY-210 CC-02 (101 d).

## Estado general
| Proyecto | Desviación vs original | Otras señales |
|---|---|---|
| PRY-199 Mobiliario de agencias | 0 | sin señales |
| PRY-200 Libranza digital | +118 días (49,8 %), 1 replanificación | avance, hitos, proveedor |
| PRY-201 Ahorro en línea | 0 | declara verde, contradicho |
| PRY-202 Core cooperativo | 0 | silencio, hito vencido, declara verde, contradicho |
| PRY-203 Aportes sociales | 0 | contradicción de fecha fin |
| PRY-204 Tarjeta débito | 0 | costo +17,2 % (proyección 7.967.490.454 vs. 6.800.000.000) |
| PRY-205 Prevención LA | 0 | compromiso sin fecha |
| PRY-206 Pagos QR | 0 | proveedor facturado sobre lo aceptado |
| PRY-207 Microcrédito rural | 0 | costo +28,9 % (4.254.910.977 vs. 3.300.000.000), declara verde, contradicho |
| PRY-208 Motor de crédito | 0 | cambio sin línea base |
| PRY-209 Convenios de libranza | 0 | costo +28,4 % (4.235.779.323 vs. 3.300.000.000), declara verde, contradicho |
| PRY-210 Corresponsales rurales | +177 días (74,1 %), 1 replanificación | cambio sin línea base |
| PRY-211 Cobranza digital | 0 | declara verde, contradicho |

## Necesito que confirmes
Sin confirmación mensual en esta corrida (sesión de prueba sin interfaz; nadie responde). Se toma la respuesta sugerida: no preguntar y seguir.

---
## Informe en HTML
Carpeta: `reportes/` (25 páginas).
- `reportes/index.html` — vista **por campo**, con la cadena de evidencia completa. Para quien va a actuar (gerente de PMO, gerentes de proyecto).
- `reportes/decisiones.html` — vista **por decisión**, para el patrocinador y el comité: solo lo que excede la facultad del gerente, como pregunta cerrada y con la consecuencia de no decidir.
- Además: `proyectos.html`, `productos.html`, una página por proyecto (PRY-199 … PRY-211) y una por producto (8).
- El PDF sale de imprimir el HTML.

**Pie:** criterio-portfolio 0.3.8 · fichas aplicadas: 13, del 2026-10-15 · campos inciertos: PRY-203 `plan.end_date` (dos fuentes distintas) · términos: https://www.josenanez.com/es/agents/criterio-pmo/legal
