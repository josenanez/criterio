## Diagnóstico · PRY-201 Apertura de ahorro en línea · 2026-10-15

**Leí:** 6 documentos · de 2025-11-07 a 2026-10-15 · formatos: .md (3), .pdf (2), .xlsx (1). Busqué el código y el nombre en las demás carpetas de documentos: ninguna otra minuta ni documento menciona el proyecto. Las cifras derivadas salen de `portafolio.py compute` (as_of 2026-10-15).
**No pude leer:** nada quedó sin leer.

**Términos:** vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-15); no hizo falta registrarlos de nuevo.

### Dictamen
**Sostenido:** 2 afirmaciones · **Sin sustento:** 7 · **Contradicho:** 4

Desde esta carpeta se puede afirmar quién es el patrocinador y el gerente, cuánto se aprobó y que existe un contrato con un proveedor y una factura radicada. No se puede afirmar que el proyecto esté en verde ni al 47 %: el informe del 2026-09-24 lo declara y cinco señales lo contradicen. Los cinco hitos del cronograma figuran como cerrados y ninguno tiene acta de recibo. La carpeta no tiene un solo documento de evidencia (0 fuentes de evidencia; 2 de declaración; 16 sin marcar).

### Gobierno
| | Qué dice el documento | Fuente |
|---|---|---|
| Patrocinador | Felipe Arango | 00-gobierno/2025-11-07-acta-constitucion.md |
| Gerente | Javier Hoyos | 00-gobierno/2025-11-07-acta-constitucion.md; asistió al comité del 2026-10-15 |
| Autoridad declarada | No está. El acta no dice qué puede aprobar el gerente (campo `identity.authority` faltante) | 00-gobierno/2025-11-07-acta-constitucion.md |
| Comité | Comité de Riesgos; aprobó el presupuesto el 2025-11-07. Hay una sola minuta, la del 2026-10-15 | acta; 30-reuniones/2026-10-15-comite-semanal.md |

Sin autoridad declarada no hay desviación aprobada: las fechas son las que alguien escribió. Además, el acta tiene el alcance con marcadores ("Componente 1, 2, 3") y no declara dependencias ("Ninguna declarada").

### Contra el plan
Hay línea base: cronograma v1 (2025-11-07), con 5 hitos. Línea base original y vigente son idénticas en los cinco; replanificaciones: 0; desviación contra la original: 0 días; contra la vigente: 0 días; solicitudes de cambio: 0 (no hay ninguna en la carpeta). Fin del plan: 2026-07-14 (salida a producción). El acta compromete cierre el 2026-08-07.

Que todo esté sin movimiento convive con un informe que dice 47 % y con un Consejo que pidió ajustar el reglamento "antes del piloto", hito que el cronograma da por cerrado desde el 2026-05-27. Esa distancia no tiene ni replanificación ni cambio aprobado que la explique.

### Hitos vencidos sin evidencia
Ninguno figura vencido y abierto: los 5 figuran cerrados, pero los 5 están "cumplidos sin evidencia".

| Hito | Fecha | Días desde la fecha | Qué documento se esperaría |
|---|---|---|---|
| Diseño funcional aprobado | 2026-01-03 | 285 | Acta de recibo del diseño funcional aprobado |
| Ambiente de pruebas certificado | 2026-02-20 | 237 | Acta de recibo / certificado del ambiente |
| Integración con el core cooperativo | 2026-04-09 | 189 | Acta de recibo de la integración |
| Piloto con asociados | 2026-05-27 | 141 | Acta o informe del piloto |
| Salida a producción | 2026-07-14 | 93 | Acta de recibo de salida a producción |

Entregables del proveedor (CT-683), ambos en estado pendiente y vencidos: Licenciamiento del módulo (2026-02-12, 245 días) y Bolsa de horas de desarrollo (2026-05-11, 157 días); aceptados: 0.

### Dinero
Moneda: COP. Fuente de las cuatro cifras: informe de avance del 2026-09-24 (declarado), salvo el aprobado, que también está en el acta.

| Aprobado | Comprometido | Ejecutado | Proyección | Disponible real |
|---|---|---|---|---|
| 1.200.000.000 | 428.136.706 | 295.371.974 | 1.172.224.803 | 771.863.294 |

Ejecutado 24,6 % del aprobado; comprometido 35,7 %; proyección −2,3 % frente al aprobado.

Lo que sí consta en documentos: el contrato CT-683 tiene dos entregables de 121.861.832 COP cada uno, y hay una factura FV-1683 por 121.861.832 COP radicada en cuentas por pagar el 2026-09-06. Facturado a proveedor: 121.861.832 COP; monto aceptado: 0. El comprometido y el ejecutado declarados son mayores que lo que los documentos del proveedor respaldan, y la carpeta no trae el soporte del resto (libro, órdenes, otros contratos).

### Lo que se dijo y nadie registró
- **Compromiso vencido (commitment-tracking):** Carlos Peña, "Entregar el punto 12", para 2026-09-27 — 18 días vencido. Está en la minuta del 2026-10-15, no en ningún registro de seguimiento. Carlos Peña no figura en el acta ni entre los asistentes, y la carpeta no dice qué es el "punto 12". La fecha del compromiso es anterior a la minuta que lo registra.
- **Riesgo (raid-taxonomy):** aprobación del reglamento por el Consejo de Administración. Está en el informe del 2026-09-24; no está en la minuta ni hay registro RAID en la carpeta.
- **Dependencias no declaradas:** el Consejo de Administración (reglamento) y el ente supervisor (concepto). El acta dice "Ninguna declarada".
- **Silencio:** el proyecto no está en silencio (días sin documento: 0, por la minuta de hoy). Pero la minuta lista "Avance" y "Compromisos" sin contenido de avance, y lo declarado por el gerente tiene 21 días. Entre el acta y el informe no hay documento de seguimiento alguno en la carpeta: el silencio es de evidencia, no de reunión.

### Contradicho
| Afirmación | Documento A | Documento B |
|---|---|---|
| Estado verde | Informe 2026-09-24: "Verde" | Señales abiertas no explicadas en el informe: compromiso vencido, hitos cumplidos sin evidencia, avance contra plan, entregables del proveedor vencidos, facturado sin entrega |
| Avance 47 % | Informe 2026-09-24: 47 % | Cronograma v1: 5 de 5 hitos cerrados (el plan respalda 100 %); brecha de 53 puntos |
| El piloto ya ocurrió (cerrado 2026-05-27) | Cronograma v1: "Piloto con asociados — cerrado" | Informe 2026-09-24: el Consejo pidió ajustar el reglamento "antes del piloto" |
| La factura cobra entregables del contrato | Factura FV-1683, 2026-09-06: "Entregables del contrato CT-683", 121.861.832 COP | Contrato CT-683: entregables "en curso"; pago contra acta de recibo firmada por el gerente; no hay acta |

### Sin sustento
- Comprometido 428.136.706 COP: solo constan 2 entregables de 121.861.832 COP cada uno.
- Ejecutado 295.371.974 COP: solo consta una factura radicada de 121.861.832 COP; no hay soporte de pago.
- Proyección al cierre 1.172.224.803 COP: sin modelo ni fuente.
- Los 5 hitos "cerrados" del cronograma: ningún acta de recibo.
- "Se recibió el concepto pendiente del ente supervisor": no hay el concepto ni mención en otro documento.
- "El Consejo de Administración pidió ajustar el reglamento antes del piloto": no hay acta del Consejo.
- Riesgo abierto "aprobación del reglamento": sin registro ni valoración.

### Lo que esta carpeta no permite saber
- **Si el proyecto salió a producción:** no hay acta de recibo de ese hito (previsto 2026-07-14); sin ella no se puede decir si el criterio de éxito ("en producción y medido") se cumple.
- **Qué puede aprobar el gerente:** el acta no declara autoridad; cualquier cambio de fechas o de dinero queda sin aprobador identificable.
- **Cuánto se ha gastado de verdad:** sin libro, órdenes ni otros contratos, el comprometido y el ejecutado son solo declaración.
- **Si se debió pagar la factura FV-1683:** sin acta de recibo firmada, la condición de pago del contrato no está probada; el pago está en cuentas por pagar.
- **Qué es el "punto 12" y de quién es Carlos Peña:** no se puede dar seguimiento al compromiso.
- **Por qué el cierre comprometido del 2026-08-07 ya pasó sin cierre ni replanificación:** no hay solicitud de cambio ni minuta anterior.
- **Qué contiene el alcance:** "Componente 1, 2, 3" no es un alcance verificable.

### Después
No recomiendo detener, continuar ni reestructurar: eso lo decide quien tiene la facultad. Puedo preparar el punto de comité con la lista de lo que falta, o llevar al gerente las 4 contradicciones como preguntas, una por una.

---
**Rigor:** cifras derivadas copiadas de `portafolio.py compute`; cada dato con su fuente en el documento citado; lo declarado (informe) se separa de lo probado (acta, contrato, factura). Sin evidencia de recibo en la carpeta, ningún hito se da por probado.
