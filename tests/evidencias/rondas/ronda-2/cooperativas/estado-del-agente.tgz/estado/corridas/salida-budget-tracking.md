Documentos de los que sale: ficha PRY-204 (estado/records/PRY-204.json), construida del acta de constitución (2025-10-29), el cronograma v1 (2025-10-29) y el informe de avance (2026-10-07). Cifras derivadas: salida de `portafolio.py compute`, as_of 2026-10-15.
Términos: vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-15; no hizo falta registrarlos de nuevo).

## Presupuesto — PRY-204 Tarjeta débito para asociados, al 2026-10-15
**Moneda:** COP (única; no hay contratos en otra moneda ni conversión)

| | Monto (COP) | % del aprobado | Fuente | Fecha |
|---|---|---|---|---|
| Aprobado | 6.800.000.000 | 100 | Acta de constitución | 2025-10-29 |
| Comprometido | 3.051.187.337 | 44.9 | Informe de avance | 2026-10-07 |
| Ejecutado | 1.451.249.736 | 21.3 | Informe de avance | 2026-10-07 |
| Proyección al cierre | 7.967.490.454 | excede el aprobado en 17.2 | Informe de avance | 2026-10-07 |

**Disponible real** (aprobado menos comprometido): 3.748.812.663 COP

### Contra la línea base
Hay una sola línea base (v1, 2025-10-29, aprobación inicial por el Comité de Educación). El presupuesto aprobado no tiene versión vigente distinta de la original: no hay solicitudes de cambio registradas.
Replanificaciones de presupuesto: 0. Desviación vigente vs. original del aprobado: no aplica (un solo valor). Desviación de la proyección contra el aprobado: 17.2%.

### Ejecución frente a avance
Ejecutado 21.3% · Hitos cumplidos 3 de 3 · Avance declarado 73.0% · El plan sostendría 100%, con una brecha de 27.0 puntos.
Lectura: las cifras no se explican entre sí. Con los 3 hitos declarados cumplidos y fecha final 2026-05-19 (ya pasada), solo se ha ejecutado el 21.3% del aprobado y el avance declarado es 73.0%. Puede ser trabajo hecho y no facturado que aparecerá de golpe, o hitos declarados cumplidos que no lo están; los documentos no permiten distinguirlo.

### Alertas
- **Proyección por encima del aprobado:** 17.2%, sobre el umbral de 10%. Es una declaración del informe del 2026-10-07 (8 días), no un dato duro. Es posterior al acta; no hay movimiento de presupuesto más reciente que la deje vieja.
- **Comprometido:** 44.9%, por debajo del umbral de 90%. No hay alerta de tope.
- **Hitos cumplidos sin evidencia:** los 3 (Diseño funcional aprobado, Ambiente de pruebas certificado, Integración con el core cooperativo) constan como cumplidos sin evidencia de recibo; hace 277, 213 y 149 días que vencieron.
- **Avance vs. plan:** declarado 73.0% frente a 100% que sostiene el plan; 27.0 puntos.
- Los tres cruces (hitos sin evidencia, avance vs. plan, variación de costo) no los recoge el estado declarado "amarillo" del informe.

### Sin dato
- Comprometido, ejecutado y proyección tienen una sola fuente declarada (el informe de avance); ninguna es evidencia contable. Fuentes marcadas como evidencia en la ficha: 0.
- Aprobado con fecha de 12 meses (acta 2025-10-29), en el umbral de vigencia de campos.
- No hay detalle por proveedor (la ficha no registra contratos de proveedor) ni causa de la proyección sobre el aprobado.
- No está declarada la autoridad que aprobó el presupuesto (identity.authority) ni la fase (identity.phase).
- No calculé en pesos el exceso proyectado sobre el aprobado porque `compute` no lo entrega.

### Después
La proyección excede el aprobado: queda ofrecer preparar la solicitud de cambio de presupuesto. No se preparó en esta corrida, porque no hay quién confirme el alcance.

*Pie de rigor: borrador de trabajo, no decisión. Cada cifra sale de la ficha y del cálculo del script; verifique contra los documentos citados.*
