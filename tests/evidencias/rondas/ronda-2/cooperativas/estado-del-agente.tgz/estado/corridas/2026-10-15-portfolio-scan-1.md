# Corrida del 2026-10-15 · portfolio-scan

13 proyectos · 71 documentos, 0 releídos y 71 sin cambio · 151 s · 59 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 21 |
| `progress_vs_plan` | 6 |
| `vendor_deliverable_late` | 5 |
| `declared_vs_evidence` | 5 |
| `commitment_overdue` | 4 |
| `vendor_accepted_without_evidence` | 3 |
| `variance_cost` | 3 |
| `variance_time` | 2 |
| `milestone_overdue` | 2 |
| `commitment_undated` | 2 |
| `change_without_baseline` | 2 |
| `vendor_invoiced_without_delivery` | 1 |
| `silent` | 1 |
| `pm_vs_pmo` | 1 |
| `vendor_invoiced_over_accepted` | 1 |

10 fichas nuevas (PRY-199,200,202,204-209,211), 52 de 71 documentos leídos, 19 sin cambio (PRY-201,203,210). Nada movido ni omitido; no hay entrada/. Mirar: PRY-200 (cierre ambiguo, 3 hitos sin acta, proveedor vencido), PRY-202/206 (recibos sin acta, factura sobre lo aceptado), PRY-204/207/209 (proyección de costo), PRY-205/208 (ejecutado mayor que comprometido), PRY-208 (CC-01 sin línea base nueva).

Contra la corrida del 2026-10-15: +34 hallazgos.

## Lo que produjo

## Barrido — 2026-10-15

Encontré 71 documentos en `documentos/proyectos`, repartidos en 13 carpetas de proyecto. Los formatos son 31 `.md`, 14 `.pdf`, 11 `.docx`, 9 `.xlsx`, 4 `.csv`, 1 `.txt` y 1 `.json`. Pude leer los 71.

Los términos (versión 1.1) ya estaban aceptados por José Francisco Ñáñez el 2026-10-15, con comprobante vigente. No los registré otra vez.

**Documentos:** 71 en la carpeta · 52 leídos · 19 sin cambio desde la corrida anterior · 0 ilegibles
**Proyectos:** 13 con ficha · 10 nuevos · 0 sin carpeta propia

El plan pedía leer 52 de 71 documentos, en 1 lote de 10 proyectos y con 0 diferidos. Fui de un proyecto a otro en esta misma conversación, con `workers: 1`. Cada ficha se escribió y se selló apenas terminó su proyecto.

### Nuevos
| Proyecto | Documentos | Campos encontrados | Campos sin dato |
|---|---|---|---|
| PRY-199 Cambio de mobiliario de agencias | 6 | identidad, plan, presupuesto, 1 contrato, 1 riesgo, 1 compromiso | autoridad, fase |
| PRY-200 Crédito de libranza digital | 9 | ídem + CC-01 y línea base v2 | autoridad, fase |
| PRY-202 Core cooperativo | 8 | ídem + 2 contratos y 2 facturas | producto («No aplica»), autoridad, fase |
| PRY-204 Tarjeta débito para asociados | 3 | identidad, plan, presupuesto | autoridad, fase |
| PRY-205 Prevención de lavado de activos | 4 | identidad, plan, presupuesto | producto («No aplica»), autoridad, fase |
| PRY-206 Pagos con QR | 9 | ídem + 2 contratos y 2 facturas | autoridad, fase |
| PRY-207 Microcrédito rural | 4 | identidad, plan, presupuesto | autoridad, fase |
| PRY-208 Motor de crédito | 3 | identidad, presupuesto, CC-01 | producto («No aplica»), autoridad, fase; no hay cronograma |
| PRY-209 Convenios de libranza con empresas | 2 | identidad, presupuesto | producto («No aplica»), autoridad, fase; no hay cronograma |
| PRY-211 Cobranza digital | 4 | identidad, plan, presupuesto | autoridad, fase |

### Actualizados
Ninguno. PRY-201, PRY-203 y PRY-210 no cambiaron desde la corrida anterior, así que sus fichas se conservan tal cual. Son los 19 documentos que no releí.

### Lo que hay que mirar (señales calculadas por el script)
**Contradicciones**
- **PRY-200.** El acta fija el cierre en 2026-07-16, pero el cronograma v2 mueve «Salida a producción» al 2026-10-18, después de esa fecha. `plan.end_date` queda `ambiguous` con las dos fuentes. CC-01 aprobó +118 días (236 M COP) y el acta de constitución no se reexpidió.
- **PRY-200.** Reporta 53 % de avance y amarillo, pero su cronograma declara los 5 hitos cerrados.
- **PRY-200.** El acta de recibo de «Salida a producción» es del 2026-10-04. La fecha vigente de ese hito es el 2026-10-18.
- **PRY-202, PRY-207, PRY-209 y PRY-211.** Declaran verde, pero hay señales en contra:
  - PRY-202: silencio de 18 días, hito «Ambiente de pruebas» vencido desde el 2026-10-04 y un hito cerrado sin acta.
  - PRY-207: hito «Integración con el core» vencido desde el 2026-10-10 y proyección 28,9 % sobre el presupuesto.
  - PRY-209: proyección 28,4 % sobre el presupuesto.
  - PRY-211: 2 hitos cerrados sin acta.

**Hitos declarados cerrados sin acta que lo pruebe**
- PRY-200: 3 hitos (Ambiente de pruebas, Integración con el core, Piloto).
- PRY-202: 1 hito (Diseño funcional).
- PRY-204: 3 hitos.
- PRY-207: 1 hito (Diseño funcional).
- PRY-211: 2 hitos.

**Costo**
- PRY-204: proyección 17,2 % sobre el presupuesto aprobado.
- PRY-207: 28,9 % sobre el presupuesto.
- PRY-209: 28,4 % sobre el presupuesto.
- PRY-205 y PRY-208: lo ejecutado supera lo comprometido (3.928 M contra 2.805 M, y 1.497 M contra 1.007 M). Es una incoherencia de las cifras del informe que el script no marca; la dejo aquí para que alguien la mire.

**Proveedores**
- PRY-200: los 3 entregables de CT-992 (Talento Solidario) están vencidos entre 157 y 287 días, sin recibo.
- PRY-202: el licenciamiento de CT-665 figura «recibido» y se facturó (FV-2665, 96,5 M), pero no hay acta de recibo.
- PRY-206: el licenciamiento figura «recibido» en CT-583 y CT-319, sin acta en ninguno. Además FV-1319 es por 73,5 M y el entregable de CT-319 vale 55,6 M, una diferencia de 18 M.

**Cambios**
- PRY-208: CC-01 (+113 días, 226 M COP, «autorizada por el comité») no tiene línea base nueva. No hay cronograma de ese proyecto.

**Compromisos**
- Vencidos sin evidencia: María Restrepo en PRY-206 (era para el 2026-09-27).
- Sin fecha: María Restrepo en PRY-205 («por definir»).

**Contra el estado anterior (fichas ya existentes):** no las toqué, pero el cálculo sobre todo el portafolio arroja las mismas señales que ya tenían: PRY-201, PRY-203 y PRY-210. Entre ellas está `pm_vs_pmo` en PRY-203.

**Cita que no resuelve (PRY-203).** `pmo.py index` marca 13 campos de la ficha del gerente (`pm_record`) de PRY-203 con la fuente `00-gobierno/2025-09-22-acta-constitucion.md`. El archivo existe en disco, pero esa cita no lleva el prefijo de la carpeta del proyecto, así que no cruza. No es una ficha mía y no la corregí.

### No pude leer
Ninguno.

### Movidos desde entrada/
No hay carpeta `entrada/`. No moví nada.

### Pendientes de clasificar
Ninguno. Hay un archivo suelto, `PRY-203-.../2026-10-15-notas-reunion.txt`, que está en la carpeta de PRY-203 y ya tiene dueño. Ese proyecto no cambió en esta corrida.

### Decisiones tomadas sin preguntar (sesión sin interfaz)
- «Producto asociado: No aplica» se registró como `not_found` en `identity.product`, con la nota, y no como un producto con ese nombre.
- «Autorizada por el comité» (PRY-200 y PRY-208) se registró como `decided_by: el comité (sin nombre en el documento)`.
- No inventé dependencias entre proyectos, aunque PRY-205 menciona un riesgo del proveedor del core. Las actas dicen «Ninguna declarada».

Versión del plugin 0.3.8 · fichas tocadas: 10 (PRY-199, 200, 202, 204, 205, 206, 207, 208, 209, 211) · campos en `not_found`: `identity.authority` y `identity.phase` en las 10, más `identity.product` en PRY-202, 205, 208 y 209 · [Términos y nota legal](https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.8)
