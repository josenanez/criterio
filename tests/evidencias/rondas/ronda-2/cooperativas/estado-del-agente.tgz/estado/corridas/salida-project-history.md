## Historia · PRY-210 Corresponsales rurales · 2026-02-12 a 2026-10-15

**Leí:** 7 documentos entre 2026-02-12 y 2026-10-15 (acta, 2 cronogramas, 2 solicitudes de cambio, 1 informe de avance, 1 acta de comité). Las cifras salen de `portafolio.py compute` con corte 2026-10-15.
**Trimestres sin un solo documento:** 2.º trimestre de 2026 (abr–jun) y 3.er trimestre de 2026 (jul–sep). El 1.er trimestre solo tiene el 2026-02-12.

Términos: ya estaban vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-15), no hizo falta registrarlos de nuevo.

### En una línea
El proyecto se aprobó el 2026-02-12 y no deja ningún documento hasta el 2026-10-05. En ese mes de octubre aparecen de golpe dos solicitudes de cambio (05 y 12), un cronograma v3 (06) que mueve el último hito del 2026-10-19 al 2027-04-14, un informe de avance en rojo con 35 % (06) y un comité (15). Los dos hitos que el cronograma marca como cerrados (2026-05-12 y 2026-07-31) no tienen ningún documento de respaldo en la carpeta.

### Las cuatro cifras
| Replanificaciones | Atraso acumulado vs. original | Meses declarando sin sustento | Cambios de gobierno |
|---|---|---|---|
| 1 (v1 → v3) | 177 días (74.1 %) | No calculable: hay una sola declaración (2026-10-06), no una serie | 0 detectados |

### Línea de tiempo
| Fecha | Documento | Qué cambió |
|---|---|---|
| 2026-02-12 | 00-gobierno/2026-02-12-acta-constitucion.md | Se aprueba el proyecto: 4.200.000.000 COP, inicio 2026-02-22, cierre 2026-11-28. Patrocinador Gustavo Neira, gerente Sandra Gil, comité Consejo de Administración. |
| 2026-02-12 | 10-plan/2026-02-12-cronograma-v1.xlsx | Línea base v1: hitos 2026-05-12, 2026-07-31 y 2026-10-19. |
| 2026-05-12 / 2026-07-31 | (sin documento) | El cronograma v3 marca estos dos hitos como cerrados; la carpeta no tiene evidencia de ninguno. |
| 2026-10-05 | 20-seguimiento/2026-10-05-solicitud-cambio-cc-01.md | CC-01: ampliación de alcance, +76 días, +152.000.000 COP. "Autorizada por el comité", sin nombre ni fecha de decisión. |
| 2026-10-06 | 10-plan/2026-10-06-cronograma-v3.xlsx | Línea base v3: "Integración con el core cooperativo" pasa de 2026-10-19 a 2027-04-14. No hay v2 en la carpeta. |
| 2026-10-06 | 20-seguimiento/2026-10-06-informe-avance.pdf | Estado declarado rojo, avance 35 %; proyección 4.218.973.032 COP; menciona que "se reprogramó la salida". |
| 2026-10-12 | 20-seguimiento/2026-10-12-solicitud-cambio-cc-02.md | CC-02: ampliación de alcance, +101 días, +202.000.000 COP. "Autorizada por el comité", sin nombre. |
| 2026-10-15 | 30-reuniones/2026-10-15-comite-semanal.md | Comité con Sandra Gil y Gustavo Neira. Registra un compromiso de Rubén Cárdenas con fecha 2026-10-07. |

### Replanificaciones
| Nº | Fecha | Fecha de cierre nueva | Motivo declarado | Documento que la aprobó |
|---|---|---|---|---|
| 1 | 2026-10-06 (v3) | 2027-04-14 | No documentado | Ninguno. Las CC-01 y CC-02 dicen "autorizada por el comité" sin nombre, y la v3 es anterior a CC-02. |

Atraso contra la línea base original: 177 días (74.1 %). La suma de CC-01 (+76) y CC-02 (+101) coincide con esos 177 días, pero la v3 lleva fecha 2026-10-06 y CC-02 se pidió el 2026-10-12: el cronograma ya incluía el efecto de un cambio que aún no existía. CC-02 queda aprobado sin línea base nueva propia (señal `change_without_baseline`, 101 días). Ambas solicitudes dicen "sobre la línea base vigente"; no se puede saber cuál era vigente en cada momento sin la v2. La fecha de cierre del acta (2026-11-28) no coincide con la de la línea base v1 (2026-10-19, último hito); el documento no explica la diferencia.

### Gobierno
| Fecha | Qué cambió | Documento |
|---|---|---|
| — | No se detectan cambios de patrocinador, gerente ni comité. | — |

Nota: en la asistencia del comité del 2026-10-15 solo figuran Sandra Gil y Gustavo Neira; Rubén Cárdenas, que tiene el compromiso, no aparece como asistente.

### Compromisos que se repitieron
| Doliente | Qué | Veces | Fechas prometidas |
|---|---|---|---|
| Ninguno se repite | — | — | — |

Hay un compromiso abierto y vencido: Rubén Cárdenas, "Entregar el punto 12", para 2026-10-07, 8 días vencido al corte. Está escrito en un comité del 2026-10-15, es decir, ya vencido cuando se anotó; no hay reunión anterior que permita saber si se había prometido antes.

### Desde cuándo lo declarado no se sostiene
No se puede fechar el deslizamiento: la carpeta tiene una sola declaración de estado (2026-10-06, rojo, 35 %) y ninguna serie anterior. Lo que sí se ve:
- El primer hito declarado cumplido sin evidencia es "Diseño funcional aprobado", con fecha 2026-05-12 (156 días atrás). Le sigue "Ambiente de pruebas certificado", 2026-07-31 (76 días).
- El 35 % declarado contra 2 de 3 hitos cumplidos: el plan sustenta entre 67 y 100 %, una diferencia de 32 puntos, en sentido de más atraso del que declara el plan, no de menos.
- El rojo declarado sí reconoce un problema, pero el informe no menciona el atraso de 177 días, el hito vencido ni el compromiso vencido.
- El informe habla de una salida reprogramada sin documento que la respalde ni motivo.

### Lecciones ancladas a un hecho
- **Hecho:** el cronograma v3 (2026-10-06) ya suma 177 días, y CC-02 (+101) es del 2026-10-12. **Efecto:** el orden de los documentos impide saber qué se aprobó antes de qué; conviene que la línea base se emita después de la aprobación del cambio, y que cada versión (aquí falta la v2) quede en la carpeta.
- **Hecho:** CC-01 y CC-02 dicen "autorizada por el comité" sin nombre ni acta de decisión (2026-10-05 y 2026-10-12). **Efecto:** 354.000.000 COP adicionales aprobados en dos solicitudes (152.000.000 y 202.000.000) sin que se pueda verificar quién los autorizó.
- **Hecho:** los hitos de 2026-05-12 y 2026-07-31 figuran cerrados y no hay documento de aceptación. **Efecto:** el 35 % de avance se apoya en dos cierres que nadie puede comprobar desde la carpeta.
- **Hecho:** ningún documento entre 2026-02-12 y 2026-10-05 (casi ocho meses). **Efecto:** el atraso se conoce cuando ya está materializado, no mientras se acumulaba.

### Lo que no sé
Por qué se replanificó (el motivo no está escrito); quién autorizó los cambios; si existió una v2 del cronograma; si el punto 12 de Rubén Cárdenas ya se entregó; si hubo comités o informes anteriores que no están en la carpeta; y cuántos meses lleva el estado declarando sin sustento, por falta de serie.

No atribuyo intención: que no haya documentos de respaldo no dice que alguien los haya omitido; esa conversación la tiene una persona con estos datos. Puedo llevar esta historia al comité o al cierre del proyecto si hay una decisión que salga de ella.

*Pie de rigor: esto es un borrador de trabajo, no una decisión ni asesoría; lee solo los documentos de la carpeta, puede equivocarse, y cada dato lleva su documento para que usted lo verifique.*
