# Corrida del 2026-10-15 · status-report

13 proyectos · 25 s · 59 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 21 |
| `progress_vs_plan` | 6 |
| `vendor_deliverable_late` | 5 |
| `declared_vs_evidence` | 5 |
| `commitment_overdue` | 4 |
| `vendor_accepted_without_evidence` | 3 |
| `variance_cost` | 3 |
| `variance_time` | 2 |
| `milestone_overdue` | 2 |
| `commitment_undated` | 2 |
| `change_without_baseline` | 2 |
| `vendor_invoiced_without_delivery` | 1 |
| `silent` | 1 |
| `pm_vs_pmo` | 1 |
| `vendor_invoiced_over_accepted` | 1 |

Estado de PRY-202: verde declarado (2026-09-27) contradicho por hito vencido, hito cumplido sin evidencia, 18 días de silencio y entregable CT-665 aceptado sin acta. Dijo que no sabe: última reunión, producto, autoridad, fase, responsables de RAID.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

*Informe generado a partir de la ficha `estado/records/PRY-202.json` (actualizada 2026-10-15) y del cálculo `compute` con corte al 2026-10-15. Términos vigentes aceptados por José Francisco Ñáñez el 2026-10-15.*

## PRY-202 Core cooperativo — estado al 2026-10-15

**Declara el gerente (Camilo Beltrán):** verde · 31% · al 2026-09-27 (informe de avance, `PRY-202-core-cooperativo/20-seguimiento/2026-09-27-informe-avance.pdf`). La declaración tiene 18 días: no está vencida (umbral 30).
**Sustento documental:** contradicho. La ficha no registra ningún documento de evidencia (0 de evidencia, 2 declaraciones); el avance del 31% cae dentro de lo que el plan soporta (20–40%), pero el semáforo verde no.
**Lo que el semáforo no explica:** `milestone_met_without_evidence` (Diseño funcional aprobado), `milestone_overdue` (Ambiente de pruebas certificado), `silent` (18 días sin documentos). Alerta `declared_vs_evidence` activa.
**Último documento:** 2026-09-27 (18 días de silencio; umbral 15) · **Última reunión:** sin dato — la ficha no tiene reuniones ni compromisos registrados.

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2027-06-05 | 2027-06-05 | 0 días |
| Presupuesto aprobado | COP 2.400.000.000 | COP 2.400.000.000 | proyección COP 2.381.420.013 (-0,8%) |

Ejecutado COP 576.917.858 (24,0%) · comprometido COP 1.542.183.719 (64,3%) · disponible real COP 857.816.281.
Replanificaciones: 0. Cambios formales: 0. Una sola línea base (v1, aprobada 2026-04-15 por el Comité de Tecnología).

### Hitos
| Hito | Base | Vigente | Estado | Evidencia |
|---|---|---|---|---|
| Diseño funcional aprobado | 2026-07-15 | 2026-07-15 | declarado cumplido | **ninguna** (92 días desde la fecha) |
| Ambiente de pruebas certificado | 2026-10-04 | 2026-10-04 | pendiente, **vencido 11 días** | ninguna |
| Integración con el core cooperativo | 2026-12-24 | 2026-12-24 | pendiente | — |
| Piloto con asociados | 2027-03-16 | 2027-03-16 | pendiente | — |
| Salida a producción | 2027-06-05 | 2027-06-05 | pendiente | — |

Cumplidos: 1 de 5 (y ese sin evidencia).

### Dónde no coincide
- **Declarado:** verde (informe del 2026-09-27). **Documentos:** el mismo informe reporta como incidencias que la prueba de carga no alcanzó el umbral pactado y se repite, que se reprogramó la salida por el cierre contable y que el Consejo pidió ajustar el reglamento antes del piloto; el cronograma sigue con las fechas originales, sin replanificación ni cambio formalizado.
- **Proveedor Sistemas Cooperativos Ltda. (CT-665):** entregable «Licenciamiento del módulo» figura aceptado y facturado (COP 96.527.977) **sin acta de recibo** en la carpeta. El mismo entregable con Datos para Cooperativas (CT-527) sí tiene acta (2026-08-09) y COP 256.580.993 facturados.

### Abierto
**Riesgos e incidencias sin movimiento (desde 2026-09-27, 18 días, todos sin responsable identificado):**
- Riesgo: cambio normativo del supervisor que puede mover el alcance.
- Riesgo: el proveedor no ha confirmado la fecha de la última entrega.
- Incidencia: el Consejo pidió ajustar el reglamento antes del piloto.
- Incidencia: se reprogramó la salida por el cierre contable de fin de mes.
- Incidencia: la prueba de carga no alcanzó el umbral y se repite.

Ninguno trae probabilidad, impacto ni fecha.
**Compromisos vencidos:** ninguno registrado (la ficha no tiene compromisos; no significa que no existan).
**Dependencias sin confirmar:** ninguna registrada.

### Sin dato
Producto (el acta dice «No aplica»), autoridad de aprobación, fase, última reunión, responsables de los riesgos e incidencias.

---
Versión de la familia 0.3.8 (criterio-portfolio) · ficha PRY-202 aplicada, actualizada 2026-10-15; declaración del 2026-09-27 · Campos inciertos: producto, autoridad, fase · Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.8

**Siguiente paso posible:** el hito vencido, el verde sin sustento y los riesgos sin dueño justifican preparar el punto de comité del 2026-10-22; no se preparó porque no se pidió.
