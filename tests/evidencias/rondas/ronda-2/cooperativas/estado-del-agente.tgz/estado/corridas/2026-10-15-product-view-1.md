# Corrida del 2026-10-15 · product-view

13 proyectos · 37 s · 59 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 21 |
| `progress_vs_plan` | 6 |
| `vendor_deliverable_late` | 5 |
| `declared_vs_evidence` | 5 |
| `commitment_overdue` | 4 |
| `vendor_accepted_without_evidence` | 3 |
| `variance_cost` | 3 |
| `variance_time` | 2 |
| `milestone_overdue` | 2 |
| `commitment_undated` | 2 |
| `change_without_baseline` | 2 |
| `vendor_invoiced_without_delivery` | 1 |
| `silent` | 1 |
| `pm_vs_pmo` | 1 |
| `vendor_invoiced_over_accepted` | 1 |

Vista de aportes sociales: un solo proyecto (PRY-203), 8 alertas, conflicto de fecha fin PM vs PMO sin resolver; 5 proyectos sin producto declarado listados. No se sabe autoridad, fase ni evidencia de los 4 hitos.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

**Fuente:** fichas en `estado/records` (13 proyectos), cálculo `portafolio.py compute` al 2026-10-15. Términos vigentes (aceptados por José Francisco Ñáñez, 2026-10-15).

## Productos al 2026-10-15 — aportes sociales

«Aportes sociales» tiene un solo proyecto (PRY-203), así que la vista por producto no aporta más que la vista del proyecto. Va solo lo que el cálculo da.

| Producto | Proyectos | Con alertas | Fecha más tardía | Aprobado | Comprometido |
|---|---|---|---|---|---|
| aportes sociales | 1 (PRY-203 Aportes sociales en línea) | 1 de 1 (8 alertas) | 2026-09-03 (ya vencida; ver conflicto abajo) | COP 4.200.000.000 | COP 2.705.437.450 |

**Dinero:** el único proyecto trae las cuatro cifras (1 de 1), así que la suma está completa. Ejecutado COP 1.996.494.350 (47,5 %); comprometido 64,4 %; proyección COP 3.996.935.557 (−4,8 % frente a lo aprobado); disponible real COP 1.494.562.550.

**Lo que hay que ver (PRY-203):**
- Avance declarado 34 % (informe del 2026-10-14, estado «rojo») frente a 4 de 4 hitos declarados cumplidos, que el plan sostiene como 100 %: brecha de 66 puntos.
- Los 4 hitos figuran como cumplidos sin evidencia de cumplimiento: Diseño funcional aprobado (2025-12-25, 294 días), Ambiente de pruebas certificado (2026-03-19, 210 días), Integración con el core cooperativo (2026-06-11, 126 días), Piloto con asociados (2026-09-03, 42 días).
- Compromiso vencido: Carlos Peña, «Entregar el punto 2», vencía el 2026-10-11 (4 días), según `30-reuniones/2026-10-12-comite-semanal.md`.
- Compromiso sin fecha: Laura Vélez, «Mandar el ajuste del presupuesto», según `2026-10-15-notas-reunion.txt`.
- El gerente y la PMO no coinciden en la fecha de fin (`pm_vs_pmo`), ver abajo.

**Dependencias internas:** ninguna; el producto tiene un solo proyecto y la ficha no declara dependencias.

**Fecha comprometida del producto:** 2026-09-03, la del PRY-203 según el cronograma v1 (2025-09-22). Hay un conflicto sin resolver: el acta de constitución (misma fecha, 2025-09-22) da como fecha de fin 2026-10-15, y ninguna de las dos fuentes es más reciente que la otra. No se puede decir cuál manda; hace falta que el dueño lo confirme. Sin reprogramaciones registradas (0 replanteamientos, 0 cambios).

**Lo que no se sabe:** la autoridad del proyecto y su fase no están en ninguna fuente; los campos de identidad y plan tienen 13 meses de antigüedad (umbral: 12) y ninguna fuente está marcada como evidencia (0 de 31).

### Proyectos sin producto declarado

| Proyecto | Área dueña |
|---|---|
| PRY-202 Core cooperativo | Cartera y cobranza |
| PRY-205 Prevención de lavado de activos | Ahorro y aportes |
| PRY-208 Motor de crédito | Servicio al asociado |
| PRY-209 Convenios de libranza con empresas | Bienestar social |
| PRY-210 Corresponsales rurales | Crédito |

Consecuencia: nadie puede responder por el conjunto al que sirven. Que PRY-205 (área «Ahorro y aportes») y PRY-202 (core) no declaren producto impide saber si tocan «aportes sociales»; PRY-203 declara «Integración con el core cooperativo» como hito y no hay cruce posible mientras PRY-202 no diga a qué producto sirve.

**Pie de rigor:** borrador de trabajo; las cifras salen del cálculo del script, cada dato lleva su fuente en la ficha, y la verificación es de quien lo lee. No se sabe lo que se habló fuera de los documentos.
