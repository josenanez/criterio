## Carpeta al 2026-10-15

**Documentos:** 71 · **Sin cambio:** 71 · **Hay que releer:** 0

### Cambió el contenido
Ninguno.

### Solo se reguardó
Ninguno.

### Renombrado o movido
Ninguno.

### Ya no está
Ninguno.

### Citas que dejaron de resolver
| Proyecto | Campo | Documento citado |
|---|---|---|
| PRY-203 | pm_record.identity.code, name, business_area, product, sponsor, manager, committee (7) | 00-gobierno/2025-09-22-acta-constitucion.md |
| PRY-203 | pm_record.plan.start_date, end_date, scope_summary, exclusions (4) | 00-gobierno/2025-09-22-acta-constitucion.md |
| PRY-203 | pm_record.money.currency, approved (2) | 00-gobierno/2025-09-22-acta-constitucion.md |

13 campos en total, todos de PRY-203 y todos hacia el mismo documento. El archivo sí existe en `PRY-203-aportes-sociales-en-línea/00-gobierno/2025-09-22-acta-constitucion.md`, y no figura como borrado ni renombrado. Lo más probable es que la cita esté escrita sin la carpeta del proyecto o con la tilde de "línea" en otra codificación. No lo confirmé: es una hipótesis. Hasta corregirla, la ficha muestra esos 13 campos como sustentados y el índice no puede resolverlos. No se reescribió ninguna ficha.

### Formatos que no se pudieron leer
Ninguno.

**Siguiente paso:** no hay nada que releer, así que no hace falta un `/portfolio-scan`. Queda por decidir si se corrigen las 13 citas de PRY-203, una por una y mostrando el cambio.
