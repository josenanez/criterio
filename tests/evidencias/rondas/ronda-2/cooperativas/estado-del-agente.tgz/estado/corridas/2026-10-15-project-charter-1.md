# Corrida del 2026-10-15 · project-charter

13 proyectos · 50 s · 59 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 21 |
| `progress_vs_plan` | 6 |
| `vendor_deliverable_late` | 5 |
| `declared_vs_evidence` | 5 |
| `commitment_overdue` | 4 |
| `vendor_accepted_without_evidence` | 3 |
| `variance_cost` | 3 |
| `variance_time` | 2 |
| `milestone_overdue` | 2 |
| `commitment_undated` | 2 |
| `change_without_baseline` | 2 |
| `vendor_invoiced_without_delivery` | 1 |
| `silent` | 1 |
| `pm_vs_pmo` | 1 |
| `vendor_invoiced_over_accepted` | 1 |

Revisión del acta PRY-205 (2026-06-06): sin autoridad del gerente, sin quién mide el éxito, sin supuestos ni restricciones, objetivo descrito como solución, exclusión sin nombrar, cierre del acta (2028-01-05) distinto al del cronograma (2027-11-02). No abrí el cronograma xlsx; no sé qué se habló fuera de los documentos.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

Acta previa: sí, existe, del 2026-06-06 (aprobada por el Comité de Educación). Términos vigentes: v1.1, aceptados por José Francisco Ñáñez el 2026-10-15 (comprobante ya registrado).

## Acta — PRY-205 · Prevención de lavado de activos
**Estado:** existe, del 2026-06-06 (`PRY-205-prevención-de-lavado-de-activos/00-gobierno/2026-06-06-acta-constitucion.docx`)

### Qué falta
| Campo | Estado | Consecuencia |
|---|---|---|
| Autoridad del gerente | **No está.** El acta no dice hasta qué monto ni qué cambio de alcance o fechas puede decidir Camilo Beltrán sin subir a comité. | Cualquier cambio, por pequeño que sea, solo puede resolverse en el Comité de Educación. Hoy el proyecto está en rojo, perdió dos semanas por rotación de un desarrollador clave (informe 2026-10-14) y no hay regla que diga si recuperar ese tiempo lo decide el gerente o el comité. |
| Objetivo de negocio | Describe la solución, no un resultado: «Entregar prevención de lavado de activos para Ahorro y aportes». | Sin resultado esperado (qué riesgo baja, qué obligación se cumple, para cuándo) no se puede juzgar si el proyecto vale lo que cuesta ni cuándo dejó de valerlo. |
| Alcance | Tres viñetas genéricas: «Componente 1; Componente 2; Componente 3». | Nadie puede decir qué es un cambio de alcance. El control de cambios no tiene contra qué comparar. |
| Exclusiones | Una sola, vacía: «Lo que otro proyecto cubre». No nombra el otro proyecto. | Si el core cooperativo o el reglamento los cubre otro proyecto, no se sabe cuál. La dependencia del proveedor del core, que el informe reporta como riesgo, queda sin dueño. |
| Patrocinador | Sandra Gil. Cumple: es una persona con nombre. | — |
| Criterio de éxito | «Prevención de lavado de activos en producción y medido.» No dice qué se mide, con qué umbral ni quién lo mide. | El piloto puede terminar y nadie puede afirmar que se cumplió ni que no. El cierre quedaría a discreción de quien reporta. |
| Quién mide el éxito | **No está.** | Quien ejecuta sería quien se evalúa. |
| Supuestos | **No hay sección.** | El informe ya trae dos riesgos que son supuestos sin declarar: que el Consejo de Administración apruebe el reglamento y que el proveedor del core llegue a tiempo. Ambos están sin dueño ni fecha. |
| Restricciones | **No hay sección.** | Quedan sin escribir los plazos o requisitos externos que condicionan el calendario. No puedo decir cuáles son: el acta no los menciona. |
| Dependencias | Dice «Ninguna declarada». | Contradice el informe del 2026-10-14, que reporta dependencia del proveedor del core. La dependencia existe en la práctica y no está en el acta. |
| Comité y cadencia | Comité de Educación declarado. **Cadencia no declarada.** | No hay compás para decidir. La minuta del 2026-10-11 tiene un compromiso sin fecha («por definir»). |
| Hitos principales | No están en el acta. Están en el cronograma v1 (4 hitos, el primero el 2026-10-20). | Los hitos no están amarrados al acta, así que moverlos no cuenta como cambio de lo aprobado. |
| Fecha de cierre | El acta dice **2028-01-05**; el cronograma v1 termina el **2027-11-02** (hito «Piloto con asociados»). | Hay 64 días entre ambas fechas y nada explica la diferencia. Puede ser un colchón o una contradicción; no lo sé. Debe aclararlo el gerente. |
| Producto asociado | «No aplica». | Si el producto de Ahorro y aportes sí depende de esto, el proyecto no aparece en ninguna vista de producto. |

### Contenido
**Objetivo de negocio:** pendiente de definir como resultado medible. El acta solo dice «Entregar prevención de lavado de activos para Ahorro y aportes» (acta, sección Objetivo del negocio).
**Alcance:** Componente 1; Componente 2; Componente 3 (acta). Sin detalle. Pendiente de definir.
**Exclusiones:** «Lo que otro proyecto cubre» (acta). Pendiente de nombrar el proyecto.
**Patrocinador:** Sandra Gil · **Gerente:** Camilo Beltrán (acta)
**Autoridad del gerente:** pendiente de definir. No hay monto ni tipo de cambio en ningún documento.
**Comité al que reporta:** Comité de Educación (acta) · **Cadencia:** pendiente de definir
**Presupuesto aprobado:** 9.500.000.000 COP, aprobado el 2026-06-06 por el Comité de Educación (acta)
**Fechas:** inicio 2026-06-16; cierre 2028-01-05 según el acta, 2027-11-02 según el cronograma v1 (sin conciliar)
**Supuestos:** pendiente de definir. El acta no tiene sección. · **Restricciones:** pendiente de definir.
**Criterio de éxito:** «Prevención de lavado de activos en producción y medido» (acta). Sin umbral. · **Lo mide:** pendiente de definir.
**Hitos principales** (cronograma v1, 2026-06-06): Diseño funcional aprobado 2026-10-20 · Ambiente de pruebas certificado 2027-02-23 · Integración con el core cooperativo 2027-06-29 · Piloto con asociados 2027-11-02.

### Lo que el acta no dice y el informe de avance sí deja ver
- Ejecutado 3.928.364.439 COP (41 % del aprobado) frente a un avance declarado de 27 %. Además el ejecutado supera al comprometido (2.805.154.469 COP), cuando lo ejecutado debería estar incluido en lo comprometido. Es una inconsistencia del informe que conviene aclarar. Proyección al cierre: 8.886.361.055 COP, el 93,5 % del aprobado, con la mayor parte del trabajo por hacer.
- Sin autoridad definida, cualquier ajuste para absorber ese desvío tendría que ir al comité.

## Después
- El acta quedó **sin autoridad declarada**. Propongo llevar esa definición al Comité de Educación (monto y tipo de cambio que decide el gerente) como decisión formal, no como trámite. No la tomo yo.
- De esta revisión salen dos supuestos sin declarar (aprobación del reglamento por el Consejo; entrega a tiempo del proveedor del core). Ofrezco pasarlos al registro RAID con `/criterio-portfolio:raid-log`.

---
**Pie de rigor.** Revisé el acta (.docx), el informe de avance del 2026-10-14, la minuta del comité del 2026-10-11 y la ficha PRY-205. No abrí el cronograma v1 (.xlsx): sus fechas las tomo de la ficha. No sé qué se habló fuera de estos documentos, ni si existe algún otro documento de autoridad delegada que no esté en la carpeta. Esta es una revisión de trabajo, no una decisión, y la verificación es del gerente.
