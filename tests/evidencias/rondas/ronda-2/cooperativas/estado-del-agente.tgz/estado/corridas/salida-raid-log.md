Este registro sale de las 13 fichas del portafolio (`estado/records/PRY-199` a `PRY-211`, al 2026-10-15), de las 8 actas de comité en Markdown y de las notas de reunión de PRY-203 (2026-10-15). No releí los informes de avance en PDF (PRY-201, 202, 206, 207, 209, 210, 211) ni los comités de producto: lo que dicen llega a través de las fichas. La escala de valoración no está definida en la configuración; usaría alta, media y baja, pero ningún ítem trae probabilidad ni impacto, así que no valoré ninguno.

## RAID — portafolio al 2026-10-15
8 riesgos · 0 supuestos · 16 incidencias · 12 dependencias (36 ítems)
36 sin doliente · 20 sin fecha de compromiso (los 20 riesgos y dependencias que antes eran riesgos) · 2 sin movimiento · 1 no registrado formalmente

Las referencias (`PRY-203·R3`) son de este informe, no del registro: las fichas no traen un identificador por ítem. «Último movimiento» es la fecha del documento donde el ítem se vio por última vez; ningún documento registra movimientos propios del ítem.

### Reclasificados (12 de 20 riesgos de las fichas)
Pasan la prueba rápida de dependencia: el ítem depende de alguien fuera del proyecto.
- **«Aprobación del reglamento por el Consejo de Administración»** (PRY-201, 204, 205, 207, 208, 209, 210): la decide un órgano externo al proyecto. Pasa de riesgo a dependencia declarada, sin confirmar por la contraparte.
- **«El proveedor no ha confirmado la fecha de la última entrega»** (PRY-202, 203, 211): depende de un tercero que no ha confirmado. Pasa de riesgo a dependencia.
- **«Dependencia del proveedor del core cooperativo»** (PRY-205, 210): el propio texto la llama dependencia. Pasa de riesgo a dependencia.

### Necesitan decisión ahora
| Ref. | Tipo | Qué | Doliente | Desde | Por qué sube |
|---|---|---|---|---|---|
| Reglamento (7 proyectos) | Dependencia | Aprobación del reglamento por el Consejo de Administración (PRY-201, 204, 205, 207, 208, 209, 210) | sin doliente | 2026-09-24 a 2026-10-14 | Afecta a otros proyectos del portafolio. El Consejo ya pidió ajustes antes del piloto en PRY-202 y PRY-208, así que no es un trámite. |
| PRY-203·I1, PRY-206·I1, PRY-207·I1 | Incidencia | Hallazgo de seguridad en la revisión de arquitectura | sin doliente | 2026-10-12 a 2026-10-14 | Ya ocurrió y está en tres proyectos sin doliente ni fecha de resolución. |
| PRY-200·I1, PRY-205·I1 | Incidencia | Dos semanas perdidas por la rotación de un desarrollador clave | sin doliente | 2026-10-11 / 2026-10-14 | PRY-205 declara estado rojo. En PRY-200 y PRY-203 el riesgo de concentración del conocimiento sigue abierto (PRY-204 lo tiene también). |
| PRY-199·I1, PRY-202·I3 | Incidencia | La prueba de carga no alcanzó el umbral pactado y se repite | sin doliente | 2026-10-13 / 2026-09-27 | No hay fecha de la nueva prueba. PRY-202 no tiene movimiento hace 18 días. |
| Cambio normativo (4 proyectos) | Riesgo | Cambio normativo del supervisor que puede mover el alcance (PRY-199, 202, 206, 209) | sin doliente | 2026-09-27 a 2026-10-13 | Es el mismo riesgo en cuatro proyectos, con cuatro dolientes ausentes. Conviene un único doliente de portafolio. |

### Detectados en reuniones, no registrados formalmente
| Qué | Tipo | Dicho en | Fecha |
|---|---|---|---|
| «Se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo» (PRY-203·R3) | Riesgo | `PRY-203-aportes-sociales-en-línea/2026-10-15-notas-reunion.txt` | 2026-10-15 |

Es el único. Las otras siete actas de comité en Markdown solo tienen temas genéricos y compromisos; no dicen ningún riesgo. No inventé más.

### Sin doliente o sin fecha
Los 36 ítems no tienen doliente. Los 20 riesgos y dependencias tampoco tienen fecha de compromiso; las 16 incidencias traen la fecha desde la que están abiertas, pero ninguna tiene fecha de resolución. Los 8 riesgos no tienen probabilidad ni impacto. Lo reporto como hallazgo, sin rellenarlo.

| Id | Tipo | Qué | Qué falta |
|---|---|---|---|
| Los 36 ítems (ver el registro completo) | todos | todos | doliente |
| Los 8 riesgos | Riesgo | ver el registro completo | probabilidad, impacto, fecha |
| Las 12 dependencias | Dependencia | ver el registro completo | fecha, y confirmación de la contraparte |
| Las 16 incidencias | Incidencia | ver el registro completo | fecha de resolución |

### Sin movimiento
La configuración fija 15 días de silencio. PRY-201 (último documento 2026-09-24, 21 días) y PRY-202 (2026-09-27, 18 días) lo superan, y los dos tienen ítems abiertos: PRY-201 una dependencia y PRY-202 un riesgo, una dependencia y tres incidencias. Si un ítem no cambia entre dos informes no puedo decirlo: las fichas no guardan versiones del ítem.

### Dependencias en riesgo
| Id | Depende de | Confirmada | Qué pasó |
|---|---|---|---|
| PRY-205·D2, PRY-210·D2 | Proveedor del core cooperativo | No | Los documentos no nombran el proyecto. PRY-202 se llama «Core cooperativo», pero las actas dicen «Ninguna dependencia declarada» y no lo vinculo por inferencia. Dato que sí consta: el hito «Ambiente de pruebas certificado» de PRY-202 vencía el 2026-10-04 y sigue pendiente, sin evidencia. PRY-210 movió su integración con el core del 2026-10-19 al 2027-04-14 (CC-01 y CC-02 aprobados). Confirmar con la PMO si el proveedor es el de PRY-202 y registrar el código. |
| Reglamento (7 proyectos) | Consejo de Administración (sin código de proyecto) | No | PRY-202 y PRY-208 reportan que el Consejo pidió ajustes antes del piloto. En PRY-208 el riesgo y la incidencia conviven: la aprobación ya se condicionó. |
| PRY-202·D1, PRY-203·D1, PRY-211·D1 | Proveedor (sin código de proyecto) | No | El proveedor no ha confirmado la última entrega; PRY-202 lleva 18 días sin documento nuevo. |

Ningún ítem de las fichas declara dependencia con código de proyecto, así que no hay cruce que detecte un movimiento de fecha en otro proyecto.

### Registro completo
Prob. e impacto: no valorados en ninguna ficha. Doliente: sin doliente en todos. Fecha: sin fecha en riesgos y dependencias; en incidencias, la columna muestra desde cuándo está abierta. Último movimiento: fecha del documento fuente.

| Id | Tipo | Qué | Prob. | Impacto | Doliente | Fecha | Último mov. |
|---|---|---|---|---|---|---|---|
| PRY-199·R1 | Riesgo | Cambio normativo del supervisor que puede mover el alcance | — | — | sin doliente | — | 2026-10-13 |
| PRY-199·I1 | Incidencia | La prueba de carga no alcanzó el umbral pactado y se repite | — | — | sin doliente | desde 2026-10-13 | 2026-10-13 |
| PRY-199·I2 | Incidencia | Se reprogramó la salida por el cierre contable de fin de mes | — | — | sin doliente | desde 2026-10-13 | 2026-10-13 |
| PRY-200·R1 | Riesgo | Concentración del conocimiento en una sola persona | — | — | sin doliente | — | 2026-10-11 |
| PRY-200·I1 | Incidencia | El equipo perdió dos semanas por rotación de un desarrollador clave | — | — | sin doliente | desde 2026-10-11 | 2026-10-11 |
| PRY-201·D1 | Dependencia (antes riesgo) | Aprobación del reglamento por el Consejo de Administración | — | — | sin doliente | — | 2026-09-24 |
| PRY-202·R1 | Riesgo | Cambio normativo del supervisor que puede mover el alcance | — | — | sin doliente | — | 2026-09-27 |
| PRY-202·D1 | Dependencia (antes riesgo) | El proveedor no ha confirmado la fecha de la última entrega | — | — | sin doliente | — | 2026-09-27 |
| PRY-202·I1 | Incidencia | El Consejo de Administración pidió ajustar el reglamento antes del piloto | — | — | sin doliente | desde 2026-09-27 | 2026-09-27 |
| PRY-202·I2 | Incidencia | Se reprogramó la salida por el cierre contable de fin de mes | — | — | sin doliente | desde 2026-09-27 | 2026-09-27 |
| PRY-202·I3 | Incidencia | La prueba de carga no alcanzó el umbral pactado y se repite | — | — | sin doliente | desde 2026-09-27 | 2026-09-27 |
| PRY-203·R1 | Riesgo | Concentración del conocimiento en una sola persona | — | — | sin doliente | — | 2026-10-14 |
| PRY-203·R2 | Riesgo | El proveedor podría no llegar con el equipo completo para la siguiente fase (**no registrado formalmente**) | — | — | sin doliente | — | 2026-10-15 |
| PRY-203·D1 | Dependencia (antes riesgo) | El proveedor no ha confirmado la fecha de la última entrega | — | — | sin doliente | — | 2026-10-14 |
| PRY-203·I1 | Incidencia | Hallazgo de seguridad levantado en la revisión de arquitectura | — | — | sin doliente | desde 2026-10-14 | 2026-10-14 |
| PRY-204·R1 | Riesgo | Concentración del conocimiento en una sola persona | — | — | sin doliente | — | 2026-10-07 |
| PRY-204·D1 | Dependencia (antes riesgo) | Aprobación del reglamento por el Consejo de Administración | — | — | sin doliente | — | 2026-10-07 |
| PRY-204·I1 | Incidencia | Se reprogramó la salida por el cierre contable de fin de mes | — | — | sin doliente | desde 2026-10-07 | 2026-10-07 |
| PRY-205·D1 | Dependencia (antes riesgo) | Aprobación del reglamento por el Consejo de Administración | — | — | sin doliente | — | 2026-10-14 |
| PRY-205·D2 | Dependencia (antes riesgo) | Dependencia del proveedor del core cooperativo | — | — | sin doliente | — | 2026-10-14 |
| PRY-205·I1 | Incidencia | El equipo perdió dos semanas por rotación de un desarrollador clave | — | — | sin doliente | desde 2026-10-14 | 2026-10-14 |
| PRY-206·R1 | Riesgo | Cambio normativo del supervisor que puede mover el alcance | — | — | sin doliente | — | 2026-10-12 |
| PRY-206·I1 | Incidencia | Hallazgo de seguridad en la revisión de arquitectura | — | — | sin doliente | desde 2026-10-12 | 2026-10-12 |
| PRY-207·D1 | Dependencia (antes riesgo) | Aprobación del reglamento por el Consejo de Administración | — | — | sin doliente | — | 2026-10-12 |
| PRY-207·I1 | Incidencia | Hallazgo de seguridad en la revisión de arquitectura | — | — | sin doliente | desde 2026-10-12 | 2026-10-12 |
| PRY-207·I2 | Incidencia | El proveedor entregó el componente de integración, pendiente de aceptación | — | — | sin doliente | desde 2026-10-12 | 2026-10-12 |
| PRY-207·I3 | Incidencia | Se reprogramó la salida por el cierre contable de fin de mes | — | — | sin doliente | desde 2026-10-12 | 2026-10-12 |
| PRY-208·D1 | Dependencia (antes riesgo) | Aprobación del reglamento por el Consejo de Administración | — | — | sin doliente | — | 2026-10-13 |
| PRY-208·I1 | Incidencia | El Consejo de Administración pidió ajustar el reglamento antes del piloto | — | — | sin doliente | desde 2026-10-13 | 2026-10-13 |
| PRY-208·I2 | Incidencia | El proveedor entregó el componente de integración, pendiente de aceptación | — | — | sin doliente | desde 2026-10-13 | 2026-10-13 |
| PRY-209·R1 | Riesgo | Cambio normativo del supervisor que puede mover el alcance | — | — | sin doliente | — | 2026-10-08 |
| PRY-209·D1 | Dependencia (antes riesgo) | Aprobación del reglamento por el Consejo de Administración | — | — | sin doliente | — | 2026-10-08 |
| PRY-209·I1 | Incidencia | El proveedor entregó el componente de integración, pendiente de aceptación | — | — | sin doliente | desde 2026-10-08 | 2026-10-08 |
| PRY-210·D1 | Dependencia (antes riesgo) | Aprobación del reglamento por el Consejo de Administración | — | — | sin doliente | — | 2026-10-06 |
| PRY-210·D2 | Dependencia (antes riesgo) | Dependencia del proveedor del core cooperativo | — | — | sin doliente | — | 2026-10-06 |
| PRY-211·D1 | Dependencia (antes riesgo) | El proveedor no ha confirmado la fecha de la última entrega | — | — | sin doliente | — | 2026-10-08 |

Revisé que ninguno de los ítems tenga una mitigación registrada, así que no puedo decir si alguna venció sin evidencia: las fichas no traen ese campo. Tampoco hay supuestos en ninguna ficha, y eso no quiere decir que no existan: nadie los levantó.

## Después
Puedo subir a comité los cinco puntos de «Necesitan decisión ahora», que cumplen el criterio de escalamiento (afectan a otros proyectos, o llevan sin doliente ni movimiento). Cuando me digas quién lleva cada proyecto, propongo un doliente para cada ítem; ahora no lo hago porque ninguna ficha ni acta lo nombra, y proponer es distinto de asignar.

Versión del plugin 0.3.8 · fichas leídas: 13 · [Términos y nota legal](https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.8)
