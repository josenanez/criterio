**Sale de:** la ficha `estado/records/PRY-200.json` (actualizada 2026-10-15), la salida de `portafolio.py compute` del 2026-10-15 y los documentos de `PRY-200-crédito-de-libranza-digital/`: acta de constitución (2025-10-18), contrato CT-992 (2025-10-23), cronogramas v1 y v2, solicitud de cambio CC-01 (2026-10-03), actas de recibo (2026-10-04 y 2026-10-14), informe de avance (corte 2026-10-11) y acta del comité del 2026-10-05.

Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15). No hubo nada que registrar.

## Cierre — PRY-200 Crédito de libranza digital — 2026-10-15

**Esto es un borrador de cierre, no una declaración de cierre.** Declarar que el proyecto terminó le corresponde al patrocinador (Paula Céspedes) con el Comité de Riesgos, y los documentos no traen esa declaración.

### Contra lo comprometido

**Criterio de éxito:** "Crédito de libranza digital en producción y medido." (acta de constitución, 2025-10-18, sección Fechas comprometidas).
**Se cumplió:** **parcialmente / no se puede determinar.**
- *En producción:* hay acta de recibo de "Salida a producción" del 2026-10-04, firmada solo por Ricardo Salas (el gerente). El cronograma v2 fija la fecha vigente de ese hito en 2026-10-18, posterior al acta y posterior a hoy.
- *Medido:* no hay ningún documento con una medición (ni indicador definido, ni cifra, ni fecha). Esa mitad del criterio no tiene evidencia.

| Entregable comprometido | Estado | Evidencia |
|---|---|---|
| Diseño funcional aprobado (comprometido 2025-12-14) | Declarado cerrado | Acta de recibo del 2026-10-14 (`20-seguimiento/2026-10-14-acta-recibo-diseño-funcional-aprobado.pdf`), firmada por el gerente |
| Ambiente de pruebas certificado (2026-01-30) | Declarado cerrado | **Sin evidencia** (compute: 258 días) |
| Integración con el core cooperativo (2026-03-19) | Declarado cerrado | **Sin evidencia** (compute: 210 días) |
| Piloto con asociados (2026-05-05) | Declarado cerrado | **Sin evidencia** (compute: 163 días) |
| Salida a producción (línea base 2026-06-22; vigente 2026-10-18) | Declarado cerrado | Acta de recibo del 2026-10-04, firmada por el gerente |
| "Componente 1, 2 y 3" (alcance del acta) | No se puede determinar | El acta no los describe ni los liga a ningún hito |
| Entregables del proveedor Talento Solidario (CT-992): licenciamiento, bolsa de horas, parametrización | **0 de 3 aceptados**, 0 facturado | Ningún acta de recibo; vencidos 287, 222 y 157 días (compute) |

### Fuera de alcance final

| Qué quedó fuera | Decidido por | Cuándo |
|---|---|---|
| Ninguna reducción de alcance documentada | — | — |

El acta excluye "Lo que otro proyecto cubre", sin decir qué. Lo que sí hay es una **ampliación** de alcance (CC-01) cuyo contenido no se describe: la solicitud dice solo "Ampliación de alcance". Qué se agregó no se puede determinar.

### Números finales

| | Original | Vigente | Final | Desviación vs original |
|---|---|---|---|---|
| Fecha (salida a producción) | 2026-06-22 | 2026-10-18 | No determinable: el acta de recibo es del 2026-10-04 y la fecha vigente aún no llega | 118 días (49.8 %) |
| Presupuesto aprobado | 4.200.000.000 COP | 4.200.000.000 COP (no hay presupuesto nuevo aprobado) | No determinable: no hay cierre financiero | Proyección 4.085.574.704 COP: −2.7 % vs aprobado |

- Desviación de fecha contra la vigente: 0 días.
- **Replanificaciones: 1** (v2, 2026-10-11, por CC-01).
- Comprometido: 2.082.032.705 COP (49.6 %). Ejecutado: 1.158.162.686 COP (27.6 %). Ambos al corte del 2026-10-11.
- CC-01 suma 236.000.000 COP "adicionales", pero ningún documento los incorpora a un presupuesto aprobado. La proyección del informe se compara contra 4.2 mil millones, no contra una base con ese cambio.
- El acta fija como cierre del proyecto 2026-07-16; el cronograma v2 no trae fecha de cierre. Contra esa fecha no hay cálculo del script.

### RAID al cierre

**Materializados:** el informe de avance registra como incidencia "el equipo perdió dos semanas por rotación de un desarrollador clave" (desde 2026-10-11). Los documentos no la ligan a un riesgo previo registrado.
**No materializados:** no se puede determinar. No existe registro de riesgos anterior al informe del 2026-10-11, y el acta declara "Ninguna" dependencia.
**Abiertos, con doliente:**

| Qué | Doliente | Estado de cierre |
|---|---|---|
| Riesgo: concentración del conocimiento en una sola persona | **No identificado** | No está cerrado: sin doliente |
| Incidencia: dos semanas perdidas por rotación | **No identificado** | No está cerrado: sin doliente |
| Compromiso: "Entregar el punto 6", para 2026-11-02 (comité 2026-10-05) | Liliana Torres | Abierto, no vencido. El acta del comité lista solo dos temas ("Avance", "Compromisos"), así que no se sabe qué es "el punto 6" |
| Entregables de CT-992 sin aceptar (3) | No identificado | Abierto: sin aceptación, sin facturación; falta decidir qué pasa con el contrato |

### Lecciones

| Qué pasó | Cuándo | Efecto | Qué haríamos distinto |
|---|---|---|---|
| La fecha de salida a producción (2026-06-22) pasó sin cambio registrado; CC-01 se pidió el 2026-10-03 y la línea base v2 se aprobó el 2026-10-11, **después** del acta de recibo de producción (2026-10-04) | 2026-06-22 a 2026-10-11 | 118 días de atraso contra la línea base original, regularizados a posteriori | Propuesta: pedir el cambio antes del vencimiento del hito |
| Tres hitos (ambiente de pruebas, integración con el core, piloto) figuran como cerrados sin acta ni evidencia; el acta de "Diseño funcional aprobado" es del 2026-10-14, con hito comprometido para 2025-12-14 | Hitos de 2026-01-30, 2026-03-19, 2026-05-05; acta 2026-10-14 | El cierre de esos hitos no se puede verificar; el 53 % reportado choca con 5 de 5 hitos cerrados (brecha de 47 puntos, compute) | Propuesta: no marcar un hito como cerrado sin su acta de recibo |
| Se salió a producción con los 3 entregables del proveedor sin aceptar | Entregables vencidos desde 2026-01-01, 2026-03-07 y 2026-05-11; producción 2026-10-04 | 0 aceptado y 0 facturado de 3. No se puede saber qué corre en producción ni qué se debe | Propuesta: exigir el acta del proveedor antes de dar por recibido el hito que depende de él |
| CC-01 figura "autorizada por el comité", sin nombre ni fecha de decisión; el comité del 2026-10-05 (Ricardo Salas y Paula Céspedes) no lista el cambio entre sus temas | 2026-10-03 a 2026-10-05 | No hay decisión rastreable para +118 días y 236.000.000 COP | Propuesta: dejar la decisión del cambio en el acta del comité, con quién y cuándo |
| Rotación de un desarrollador clave | Informe del 2026-10-11 | Dos semanas perdidas, según el informe; sin doliente ni fecha | Propuesta: asignar doliente a la incidencia cuando se registra |

Quedan fuera las lecciones que no se anclan a un hecho de los documentos.

### Sin dato

- Medición del crédito en producción (mitad del criterio de éxito).
- Contenido de la ampliación de alcance de CC-01 y quién la decidió.
- Evidencia de los hitos "ambiente de pruebas", "integración con el core" y "piloto".
- Fecha real de salida a producción (acta 2026-10-04 vs fecha vigente 2026-10-18).
- Presupuesto vigente con los 236.000.000 COP y cierre financiero.
- Qué es "el punto 6" y qué pasó con los entregables de CT-992.
- Doliente del riesgo, de la incidencia y del contrato después del cierre.
- Autoridad del proyecto y fase (campos no encontrados en la ficha). Los campos de identidad, plan y presupuesto tienen 12 meses de antigüedad, todos tomados del acta de 2025-10-18.
- Declarado por el gerente: estado **amarillo**, 53 % (2026-10-11). Eso es una declaración, no evidencia: las señales de variación en tiempo, avance contra plan, hitos sin evidencia y entregables tardíos del proveedor no figuran explicadas en el informe.

### Después

Recomiendo **no mover todavía la carpeta a `archivo/`**: hay tres frentes abiertos sin doliente y el cierre aún no está declarado. Cuando el patrocinador lo declare y se asignen dolientes, se mueve y se deja la ficha congelada con su última instantánea.

### Pie de rigor

Verificado: cifras derivadas copiadas de `compute` (as_of 2026-10-15) y documentos leídos completos. No verificado: nada de lo hablado fuera de los documentos, el contenido de los sistemas o del ambiente de producción, ni el origen de las firmas de las actas. El script no calculó la suma de los montos de CT-992 ni la desviación contra la fecha de cierre del acta (2026-07-16), así que no las incluyo. Esto es un borrador de trabajo: la verificación contra las fuentes citadas es suya.
