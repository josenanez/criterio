# Corrida del 2026-10-15 · document-index

13 proyectos · 16 s · 59 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 21 |
| `progress_vs_plan` | 6 |
| `vendor_deliverable_late` | 5 |
| `declared_vs_evidence` | 5 |
| `commitment_overdue` | 4 |
| `vendor_accepted_without_evidence` | 3 |
| `variance_cost` | 3 |
| `variance_time` | 2 |
| `milestone_overdue` | 2 |
| `commitment_undated` | 2 |
| `change_without_baseline` | 2 |
| `vendor_invoiced_without_delivery` | 1 |
| `silent` | 1 |
| `pm_vs_pmo` | 1 |
| `vendor_invoiced_over_accepted` | 1 |

71 documentos sin cambio, 0 por releer. 13 citas de PRY-203 no resuelven aunque el archivo existe (probable ruta sin carpeta del proyecto o tilde de 'línea'); hipótesis no confirmada, fichas sin tocar.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## Carpeta al 2026-10-15

**Documentos:** 71 · **Sin cambio:** 71 · **Hay que releer:** 0

### Cambió el contenido
Ninguno.

### Solo se reguardó
Ninguno.

### Renombrado o movido
Ninguno.

### Ya no está
Ninguno.

### Citas que dejaron de resolver
| Proyecto | Campo | Documento citado |
|---|---|---|
| PRY-203 | pm_record.identity.code, name, business_area, product, sponsor, manager, committee (7) | 00-gobierno/2025-09-22-acta-constitucion.md |
| PRY-203 | pm_record.plan.start_date, end_date, scope_summary, exclusions (4) | 00-gobierno/2025-09-22-acta-constitucion.md |
| PRY-203 | pm_record.money.currency, approved (2) | 00-gobierno/2025-09-22-acta-constitucion.md |

13 campos en total, todos de PRY-203 y todos hacia el mismo documento. El archivo sí existe en `PRY-203-aportes-sociales-en-línea/00-gobierno/2025-09-22-acta-constitucion.md`, y no figura como borrado ni renombrado. Lo más probable es que la cita esté escrita sin la carpeta del proyecto o con la tilde de "línea" en otra codificación. No lo confirmé: es una hipótesis. Hasta corregirla, la ficha muestra esos 13 campos como sustentados y el índice no puede resolverlos. No se reescribió ninguna ficha.

### Formatos que no se pudieron leer
Ninguno.

**Siguiente paso:** no hay nada que releer, así que no hace falta un `/portfolio-scan`. Queda por decidir si se corrigen las 13 citas de PRY-203, una por una y mostrando el cambio.
