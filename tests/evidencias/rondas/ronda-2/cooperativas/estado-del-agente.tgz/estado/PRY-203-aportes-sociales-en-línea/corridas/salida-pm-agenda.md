## Reunión de seguimiento — Aportes sociales en línea (PRY-203) · 2026-10-19
6 puntos · 30 minutos · 5 personas requeridas (Elena Duarte, Carlos Peña, Beatriz Cuéllar, Laura Vélez, Óscar Ramírez)

Fecha tomada de la configuración (comité semanal, próximo 2026-10-19). Los 30 minutos son una propuesta mía: no hay duración configurada ni pedida.

### Lo que no se destraba solo
Nada está reprogramado tres veces (el máximo es Beatriz Cuéllar, una vez), así que no hay un punto de ese tipo. Lo más viejo y lo único que el tiempo empeora es el vencido de abajo; abre la reunión.

### Vencido sin evidencia
| Quién | Qué | Desde | Qué se necesita hoy | Min |
|---|---|---|---|---|
| Carlos Peña | Entregar el punto 2 | Prometido para el 2026-10-11 (8 días al 2026-10-19, si sigue sin entrega) | Entrega con fecha, o fecha nueva dicha por él. Confirmar también la fecha: es anterior al comité donde se registró (2026-10-12). | 5 |

Fuente: minuta del comité 2026-10-12. Las notas del 2026-10-15 no lo mencionan y el expediente no tiene entrega que lo respalde.

### Se decide hoy o se atrasa
| Qué | Quién decide | Si no se decide | Min |
|---|---|---|---|
| Riesgo del proveedor (podría no llegar con el equipo completo para la siguiente fase): registrarlo con dueño y definir qué se le pide al proveedor antes de la revisión del 2026-10-25 | Elena Duarte nombra al dueño. Las notas no dicen quién tiene la facultad de actuar sobre el proveedor. | Se comentó el 2026-10-15 y nadie lo anotó. Sin dueño llega a la revisión del 2026-10-25 sin que nadie lo haya planteado. | 10 |
| Beatriz Cuéllar, «punto 32»: qué es, y si el 2026-11-20 se sostiene | Beatriz Cuéllar | Es el único compromiso ya reprogramado (2026-11-06 → 2026-11-20). Un segundo movimiento lo vuelve patrón. | 5 |
| Cadencia: las notas dicen «próxima reunión en dos semanas» y la configuración dice comité semanal | Elena Duarte | Nadie sabe si el 2026-10-26 hay reunión. | 2 |

Fuentes: notas 2026-10-15 (líneas 4 y 7–8), minuta 2026-10-12, acta del 2026-10-15.

### Vence antes de la próxima
| Quién | Qué | Para cuándo | Min |
|---|---|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto («la otra semana», sin fecha) | Sin fecha declarada. Hoy se le pide una fecha; no la calculo yo. | 3 |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-25 | 5 |

El punto de Óscar sirve para preparar la revisión con el riesgo del proveedor ya en la mesa. Fuente: notas 2026-10-15.

### No es de esta reunión
| Qué | Por qué | Dónde va |
|---|---|---|
| Cierre del proyecto: el acta fija el 2026-10-15 (hoy, 2026-10-15) y hay una entrega comprometida el 2026-11-20. No hay línea base nueva ni solicitud de cambio en la carpeta. | Mover el cierre excede la autoridad de la gerente. El patrocinador (Andrés Lozano) no estuvo el 2026-10-15. | Comité de Riesgos. Se puede formular con `/pm-escalate` o `/pm-commitments`. |
| Estado Rojo y 34 % de avance declarados en el informe del 2026-10-14, con el plazo cumplido | Es lo declarado por la gerente; la ficha aún no tiene esos campos y no los contrasté. Es decisión de comité, no de seguimiento. | Material de comité |
| Hallazgo de seguridad de la revisión de arquitectura (informe 2026-10-14) | Sin dueño ni fecha en ningún documento. No sé si lo atiende alguien de esta sala. | Preguntar a Elena si va aquí; no lo agendo por no tener dueño. |

### Anexo — sin cambios (no hay reunión anterior contra la cual comparar)
No puedo armarlo: es la primera corrida y no hay foto anterior (`diff` devolvió «no previous snapshot»). Lo que sigue en el expediente, sin repasarlo en la reunión: riesgos del informe del 2026-10-14 («el proveedor no ha confirmado la fecha de la última entrega», «concentración del conocimiento en una sola persona»), sin movimiento fechado.

---
No sé: a qué corresponden «el punto 32» y «el punto 2»; quién comentó lo del proveedor; qué proveedor y qué fase; ni si Andrés Lozano asiste el 2026-10-19. No convoco a nadie. Cuando termine la reunión, `/pm-minutes` sobre las notas.
Términos: vigentes, aceptados por José Francisco Ñáñez el 2026-10-15.
