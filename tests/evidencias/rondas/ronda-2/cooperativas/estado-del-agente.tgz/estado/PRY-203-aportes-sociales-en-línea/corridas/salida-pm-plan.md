# Plan — Aportes sociales en línea (PRY-203) · borrador del 2026-10-15
**Desde:** acta de constitución del 2025-09-22 (`00-gobierno/2025-09-22-acta-constitucion.md`) · **Criterio de éxito:** «Aportes sociales en línea en producción y medido» (acta, sección Criterio de éxito)

> Términos: vigentes (v0.3.8, aceptados por José Francisco Ñáñez el 2026-10-15); no hubo que registrarlos de nuevo.
> Sesión sin interfaz: en cada pregunta tomé la respuesta sugerida. Argumento sin ruta → partí del acta de `00-gobierno`.

**Una advertencia antes de leer:** este proyecto no está arrancando. El acta es de hace 13 meses y su fecha de cierre comprometida es **hoy (2026-10-15)**. Ya existe un cronograma v1 (2025-09-22) y un informe de avance en rojo (34 %, corte 2026-10-14). Este borrador reconstruye la estructura desde el acta; no reemplaza el plan vigente ni crea línea base.

## Lo que le falta al acta
| Qué | Consecuencia de planificar sin eso |
|---|---|
| **Alcance sin contenido:** lista «Componente 1, 2, 3» | No hay entregables que descomponer. La WBS completa queda en «supuesto» o «sin definir»; nada de lo que se acepte puede contrastarse con el acta. |
| **Fuera de alcance vacío en la práctica:** «Lo que otro proyecto cubre», sin decir cuál | No se sabe dónde termina este proyecto; el solapamiento con otros (p. ej. el core o el ahorro en línea) no se puede verificar. |
| **Criterio de éxito sin medida:** «en producción y medido» | «Medido» no dice qué métrica, con qué meta ni quién la mide; no hay forma de decir si el proyecto cumplió. |
| **Sin autoridad declarada del gerente** | No se sabe qué puede decidir la gerente al planificar (cambios de alcance, reprogramaciones, reasignaciones) y qué debe subir. |
| **Dependencias: «Ninguna declarada»** | Contradice lo que muestran los demás documentos (proveedor con entrega pendiente, integración con el core). Un plan sin dependencias declaradas esconde justo el riesgo que hoy está abierto. |
| **Sin aceptantes por entregable** | El acta nombra patrocinador (Andrés Lozano) y comité (Comité de Riesgos), pero no quién recibe y acepta cada entregable. |
| Patrocinador | Sí está: Andrés Lozano. No falta. |

No rellené ninguno de estos huecos.

## WBS
Ningún nodo terminal sale del acta con la granularidad de «alguien lo recibe y lo acepta». Los de «supuesto» salen de documentos posteriores al acta, no de ella.

| # | Entregable | Quién lo acepta | De dónde sale | Duración |
|---|---|---|---|---|
| 1 | Componente 1 | Sin definir | **Sin definir** (el acta solo dice «Componente 1») | vacía |
| 2 | Componente 2 | Sin definir | **Sin definir** | vacía |
| 3 | Componente 3 | Sin definir | **Sin definir** | vacía |
| 4 | Diseño funcional aprobado | Sin definir | **Supuesto** — hito del cronograma v1 (2025-12-25, «cerrado»); no está en el acta | vacía |
| 5 | Ambiente de pruebas certificado | Sin definir | **Supuesto** — hito del cronograma v1 («cerrado») | vacía |
| 6 | Integración con el core cooperativo | Sin definir | **Supuesto** — hito del cronograma v1 («cerrado») | vacía |
| 7 | Piloto con asociados | Sin definir | **Supuesto** — hito del cronograma v1 («cerrado») | vacía |
| 8 | Entrega final del proveedor | Sin definir | **Supuesto** — informe 2026-10-14: «el proveedor no ha confirmado la fecha de la última entrega» | vacía |
| 9 | Resolución del hallazgo de seguridad y plan de pruebas ajustado con Seguridad | Sin definir | **Supuesto** — informe 2026-10-14, «Lo que pasó en el periodo» | vacía |
| 10 | Aportes sociales en producción | Sin definir (patrocinador: Andrés Lozano, pero el acta no dice que acepte) | **Del acta** — criterio de éxito «en producción» | vacía; cierre comprometido 2026-10-15 (acta) |
| 11 | Medición de aportes sociales en producción | Sin definir | **Del acta** — criterio de éxito «medido»; qué se mide: **sin definir** | vacía |
| 12 | «Punto 32» (Beatriz Cuéllar) y «punto 2» (Carlos Peña) | Sin definir | **Sin definir** — el comité del 2026-10-12 los cita sin decir a qué entregable corresponden | vacía |

Observación: el cronograma v1 marca los cuatro hitos como «cerrado» (el último, el piloto, con fecha 2026-09-03), mientras el informe declara rojo y 34 % de avance. No lo resuelvo; son dos lecturas que alguien debe conciliar.

## Orden
Sin fechas. Solo lo que el material permite afirmar:
- 4 → 5 → 6 → 7 es el orden del cronograma v1 (supuesto: se conserva).
- 7 (piloto) → 10 (producción) → 11 (medición): «medido» exige estar en producción (acta).
- 9 (hallazgo de seguridad y pruebas) debe cerrar antes de 10; el informe lo trata como parte del plan de pruebas. Supuesto.
- 8 (entrega final del proveedor) → 10: supuesto; el acta no declara la dependencia.
- 1, 2, 3 y 12: **sin orden posible** hasta que se sepa qué son.

## Supuestos sobre los que está construido
| Supuesto | Qué pasa si resulta falso |
|---|---|
| Los cuatro hitos del cronograma v1 equivalen a entregables del alcance | Si los «Componentes» del acta son otra cosa, la WBS no cubre el alcance real. |
| Los hitos marcados «cerrado» lo están con evidencia de aceptación | Si el 34 % es correcto, algo de lo «cerrado» no está terminado; el plan parte de una base falsa. |
| La última entrega del proveedor es condición previa de producción | Si no lo es, se subestima el camino crítico; si lo es y no se declara, el riesgo sigue invisible. |
| El hallazgo de seguridad bloquea el paso a producción | Si no lo bloquea, la ruta a producción es más corta; si bloquea y no hay plan, no hay salida. |
| «Punto 32» y «punto 2» corresponden a entregables de este proyecto | Si son de otro proyecto o documento, hay compromisos huérfanos. |
| El Comité de Riesgos sigue siendo la instancia de aprobación | Si cambió, el aceptante de las excepciones es otro. |

Pasan a riesgos del proyecto (RAID, con doliente) en cuanto el plan se apruebe.

## Sin definir
| Qué | Quién lo define |
|---|---|
| Contenido de los Componentes 1, 2 y 3 | Patrocinador (Andrés Lozano) con la gerente |
| Qué queda fuera de alcance y qué proyecto lo cubre | Patrocinador |
| Métrica y meta de «medido» | Patrocinador / Bienestar social (área dueña) |
| Aceptante de cada entregable | Patrocinador |
| Autoridad de la gerente al planificar | Patrocinador / Comité de Riesgos |
| Dependencias reales (proveedor, core) | Gerente, con el proveedor |
| A qué corresponden el «punto 32» y el «punto 2» | Beatriz Cuéllar y Carlos Peña |
| Quién recibe el riesgo «el proveedor podría no llegar con el equipo completo para la siguiente fase» (comentado el 2026-10-15, nadie lo anotó) | Gerente: decidir si lo registra |

## Proyectos análogos
Ninguno a la vista: la configuración no apunta a una carpeta de fichas de la PMO, y en el estado del proyecto no hay fichas de otros. Existen carpetas de otros proyectos en `documentos/proyectos/` (PRY-199 a PRY-211), pero no las leí ni las tomo como análogos sin una ficha que lo sustente. No hay referencia, y no invento una.

## Preguntas para el equipo
Una por duración vacía:
1. Componentes 1, 2 y 3: ¿qué son y cuánto toma cada uno?
2. Diseño funcional aprobado: ¿está realmente cerrado? ¿Quién lo aceptó y con qué documento?
3. Ambiente de pruebas certificado: ¿ídem? ¿Cuánto tomaría recertificarlo si el plan de pruebas cambió?
4. Integración con el core cooperativo: ¿ídem? ¿Depende de otro proyecto?
5. Piloto con asociados: ¿qué quedó pendiente si el avance es 34 %?
6. Entrega final del proveedor: ¿cuándo la confirma y con qué equipo?
7. Hallazgo de seguridad y pruebas ajustadas: ¿cuánto toma corregir y re-probar, y quién de Seguridad lo cierra?
8. Paso a producción: ¿cuánto toma y en qué ventana?
9. Medición: ¿qué se mide, desde cuándo y quién da el visto bueno?
10. «Punto 32» y «punto 2»: ¿qué entregable son y cuánto falta?

## Para comprometer una fecha falta
- Disponibilidad real del equipo (el informe declara concentración del conocimiento en una sola persona; no dice quién).
- La fecha confirmada del proveedor para su última entrega y la composición de su equipo.
- La ventana de producción y de cierre contable (el informe cita el cierre de fin de mes como causa de una reprogramación).
- Una decisión del patrocinador sobre el cierre comprometido (2026-10-15) que hoy vence con el proyecto en rojo. Eso no es una fecha de este plan: es una excepción que va al comité, y la fecha nueva la compromete la gerente.

---
Este borrador no compromete fechas, no estima por analogía, no asigna personas y no crea línea base.
