# Acta — Aportes sociales en línea (PRY-203) · 2026-10-15
**Asistieron:** Beatriz Cuéllar, Carlos Peña, Elena Duarte, Laura Vélez, Óscar Ramírez · **Fuente:** `2026-10-15-notas-reunion.txt` · **Ausentes con tema en agenda:** no hay agenda en el insumo; no se puede decir. (Andrés Lozano, patrocinador según el acta de constitución, no figura entre los asistentes.)

## Compromisos
| Quién | Qué | Para cuándo | |
|---|---|---|---|
| Beatriz Cuéllar | Entregar el punto 32 | 2026-11-20 | **Reprogramado 1 vez.** Antes: 2026-11-06 (comité del 2026-10-12). Nota línea 4: «lo de entregar el punto 32 no alcanzó, se compromete para el 20/11/2026» |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-25 | Nuevo (nota línea 6) |

### Sin fecha
| Quién | Qué |
|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto — dijo «la otra semana» (nota línea 5). Se registra con `due_date: no_declarada`; no se calcula una fecha desde la frase. |

## Decisiones
| Qué se decidió | Quién | Qué se descartó |
|---|---|---|
| Ninguna decisión en las notas. | | |

## Quedó sin decidir
| Qué | Por qué | Quién tiene la facultad |
|---|---|---|
| Qué hacer ante el posible incumplimiento del proveedor (equipo incompleto) | Se comentó; las notas no registran que se haya resuelto nada | No dicho en el insumo |

## Intenciones sin doliente
| Qué se dijo | Quién lo dijo |
|---|---|
| Ninguna. | |

## Dicho al pasar y no registrado
| Qué | Quién lo dijo | Categoría | Ya estaba en el RAID |
|---|---|---|---|
| «El proveedor podría no llegar con el equipo completo para la siguiente fase; nadie lo anotó como riesgo» (nota línea 7) | No atribuido en las notas | Riesgo (proveedor / capacidad); dueño `no_identificado` | **No hay RAID formal.** El informe de avance del 2026-10-14 lista un riesgo cercano —«el proveedor no ha confirmado la fecha de la última entrega»— pero trata la fecha, no la completitud del equipo; no es el mismo. |

## Cerrado en esta reunión
No se cerró nada con documento. Se omite el detalle, salvo esto: el compromiso de **Carlos Peña** («Entregar el punto 2», vence 2026-10-11, del comité del 2026-10-12) **no se menciona en las notas** y sigue sin evidencia de entrega; queda como vencido hace 4 días, no como cerrado.

## Lo que esta reunión contradice
| Campo | Dijo la reunión | Dice el expediente | Fuente y fecha de cada uno |
|---|---|---|---|
| Fecha de cierre del proyecto | Hay entregas comprometidas después del cierre: 2026-11-20 (Beatriz Cuéllar) | Cierre 2026-10-15 | Notas 2026-10-15 / acta de constitución 2025-09-22 |
| Cadencia de reuniones | «Próxima reunión en dos semanas» (~2026-10-29) | Comité semanal, próximo 2026-10-19 | Notas 2026-10-15 / configuración del proyecto |

Ninguna de las dos es un cambio de campo declarado en la reunión; son tensiones que alguien debería resolver. El cierre del 2026-10-15 es hoy y no hay línea base nueva ni solicitud de cambio en la carpeta.

## Sin resolver de la transcripción
- «Laura Vélez queda de mandar el ajuste del presupuesto la otra semana»: no se sabe a qué fecha de referencia se cuenta «la otra semana».
- «Próxima reunión en dos semanas»: sin fecha exacta; no queda claro si reemplaza o se suma al comité semanal.
- «Se comentó que el proveedor podría no llegar…»: no se dice quién lo comentó ni a qué proveedor ni a qué fase se refiere.
- No se dice a qué corresponden «el punto 32» ni «el punto 2».

## Cifras recalculadas (`portafolio.py compute`)
- Vencidos sin evidencia: 1 (Carlos Peña, punto 2, 4 días).
- Sin fecha: 1 (Laura Vélez).
- Reprogramados: 1 (Beatriz Cuéllar, 1 vez; el umbral para marcar es 3).
- Campos de la ficha sin dato: estado declarado, avance, fase, autoridad, comprometido/ejecutado/proyección. El informe de avance del 2026-10-14 declara Rojo, 34% y cifras de presupuesto, pero la ficha aún no los tiene.
