## Listo — PRY-203 · Aportes sociales en línea

**Lo que miré:** 5 documentos · 2 minutas (las notas del 2026-10-15 y el comité del 2026-10-12) · la última del 2026-10-15. Leí la minuta más reciente, el comité anterior (para ver la promesa original) y el acta de constitución. El informe de avance del 2026-10-14 y el cronograma (.xlsx) no los he leído todavía.
**Términos:** aceptados para la versión 0.3.8 (términos 1.1), a nombre de José Francisco Ñáñez · comprobante en `.criterio/terminos/aceptacion-criterio-project-0.3.8-2026-10-15.md` y `.pdf` · SHA-256 fd18d9cd0b3d5a0f…

Respuestas tomadas por defecto (sesión sin interfaz): gerente Elena Duarte según el acta; reunión de seguimiento semanal, lunes (el comité del 12 de octubre fue lunes; próxima propuesta 2026-10-19); estado en `estado/PRY-203-aportes-sociales-en-línea`. Nota: quien acepta los términos (José Francisco Ñáñez) no es el gerente que nombra el acta (Elena Duarte).

### Lo que se prometió en tu última reunión
| Quién | Qué | Para cuándo | |
|---|---|---|---|
| Beatriz Cuéllar | Entregar el punto 32 | 2026-11-20 (antes 2026-11-06: reprogramado una vez) | Abierto. «lo de “entregar el punto 32” no alcanzó, se compromete para el 20/11/2026» — notas 2026-10-15 |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-25 | Abierto. «revisión con el proveedor, queda para el 2026-10-25» — notas 2026-10-15 |
| Carlos Peña | Entregar el punto 2 | 2026-10-11 | **Vencido hace 4 días, sin evidencia.** Promesa registrada en el comité del 2026-10-12 (que ya la traía con fecha pasada); las notas del 15 no la mencionan. |

### Sin fecha
- **Laura Vélez** — mandar el ajuste del presupuesto; dijo «la otra semana», que no es una fecha. No puede estar vencido, y por eso mismo es el que desaparece de los informes. Conviene preguntar el día en la próxima reunión.

### Señales que levantó el cálculo
2 señales: `commitment_overdue` (Carlos Peña) y `commitment_undated` (Laura Vélez). Nada más.

### Dicho en la reunión y sin registrar
- Se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase; nadie lo anotó como riesgo. Lo dejé en la ficha como riesgo sin responsable.

### Qué le falta a tu carpeta
- Minutas de reuniones anteriores al 2026-10-12: sin ellas no se ve el historial de reprogramaciones.
- El cronograma vigente: solo hay la v1 del 2025-09-22, y el acta fija el cierre para el 2026-10-15, es decir hoy.
- Actas de recibo de lo entregado: sin ellas un compromiso cumplido se ve igual que uno incumplido.
- Presupuesto comprometido y ejecutado: solo aparece el aprobado (4.200.000.000 COP); el ajuste de Laura Vélez aún no está.
- Los datos del acta tienen 13 meses y no hay confirmación posterior; el acta no declara facultad del gerente ni dependencias.
- La declaración de estado del gerente: no la tengo (el informe de avance sigue sin leer).

**Cuándo vuelvo:** lunes 2026-10-19, con la reunión de seguimiento semanal. Si quieres, leo ahora las minutas anteriores y el informe de avance para completar el historial de compromisos.
