# Corrida del 2026-10-15 · pm-escalate

1 proyectos · 34 s · 2 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_overdue` | 1 |
| `commitment_undated` | 1 |

Paquete de un punto: el acta no declara la autoridad del gerente. Impacto de 36 días sin proyectos ni hitos alcanzados (la ficha no tiene hitos ni dependencias). No sé el costo de las opciones, ni los días que se mueve cada proyecto alcanzado.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## Para decisión — PRY-203 Aportes sociales en línea · 2026-10-15

Términos: vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-15); no hizo falta registrarlos de nuevo.

Sin argumento y sin ítems marcados como escalables en la ficha, apliqué el criterio de qué escala. Solo escala un punto, y es el que la regla pone primero: **el acta no declara la autoridad del gerente.**

### ¿Se enmienda el acta del 2025-09-22 para declarar por escrito qué puede decidir la gerente sin pasar por el Comité de Riesgos (mover fechas, mover presupuesto, cambiar de proveedor, cambiar alcance), con un umbral para cada una? Sí / No (y todo cambio de línea base va al comité)

**Quién decide:** el acta no lo dice. La aprobó el Comité de Riesgos con Andrés Lozano como patrocinador, así que lo natural es que lo decida el comité; esto es una inferencia, no una cita. · **Si no se decide hoy:** el cierre comprometido es hoy, 2026-10-15, y ya hay un compromiso al 2026-11-20 (36 días después) sin que nadie sepa quién puede aprobar mover la línea base. Si no se decide en el comité del 2026-10-19, ese cierre se mueve sin facultad declarada y la decisión puede resultar inválida después.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Enmendar el acta con umbrales de autoridad | No cambia | Una sesión de comité (2026-10-19) | No determinable: no hay documento que lo cuantifique |
| B. Sin enmienda: todo cambio de línea base va al comité | No cambia | Cada cambio espera la sesión semanal | No determinable: no hay documento que lo cuantifique |

**Recomiendo:** A. Es la única que evita escalar todo o nada, y cabe en una sesión.

### A quién alcanza
El cálculo con 36 días (cierre 2026-10-15 → 2026-11-20) no devuelve proyectos alcanzados ni hitos: la ficha no tiene hitos y el acta dice «Dependencias: Ninguna declarada». Eso no prueba que no haya dependencias; solo que ninguna está declarada. No se estimó cuántos días se mueve cada proyecto alcanzado: no hay holgura por actividad.

### Mis hitos por los que pasa
Ninguno: la ficha no tiene hitos cargados.

### Lo que miré y no escala (todavía)
- **Compromiso de Beatriz Cuéllar, «entregar el punto 32»:** se reprogramó una vez, del 2026-11-06 al 2026-11-20. Son dos fechas, no tres, así que no cumple el umbral de escalar. Pero 2026-11-20 queda 36 días después del cierre de la línea base: eso es control de cambios, no escalamiento. Hasta que se enmiende el acta, ese cambio es el primero que necesita la respuesta de arriba.
- **Riesgo «el proveedor podría no llegar con el equipo completo»:** se dijo en la reunión del 2026-10-15 y nadie lo anotó. No tiene dueño, probabilidad ni impacto, y se movió hoy. Primero registrarlo; no escala.
- **Compromiso de Carlos Peña, «entregar el punto 2»:** vencía el 2026-10-11 y no hay evidencia. Se destraba con una llamada. No escala.
- **Presupuesto:** el informe del 2026-10-14 declara proyección de 3.996.935.557 COP contra 4.200.000.000 aprobados, sin sobrecosto. No hay nada que escalar por costo hoy.

### De dónde sale esto
- Autoridad no declarada: `00-gobierno/2025-09-22-acta-constitucion.md` (no hay sección de autoridad; en la ficha, `identity.authority` = no encontrado).
- Cierre 2026-10-15, presupuesto, dependencias «ninguna declarada», Comité de Riesgos, patrocinador: la misma acta.
- Compromiso de Beatriz Cuéllar: `30-reuniones/2026-10-12-comite-semanal.md` (para el 2026-11-06) y `2026-10-15-notas-reunion.txt` (nuevo plazo 20/11/2026).
- Compromiso de Carlos Peña: `30-reuniones/2026-10-12-comite-semanal.md`.
- Riesgo del proveedor: `2026-10-15-notas-reunion.txt`.
- Proyección: `20-seguimiento/2026-10-14-informe-avance.md`.
- Próximo comité 2026-10-19: configuración del proyecto.

### Lo que no sé
No sé qué facultades tiene la gerente en la práctica fuera de los documentos. No sé el costo de cada opción. No sé si hay proyectos que dependan de este.
