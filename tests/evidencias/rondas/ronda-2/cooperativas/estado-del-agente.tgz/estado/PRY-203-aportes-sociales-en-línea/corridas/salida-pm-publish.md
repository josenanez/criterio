Publiqué la ficha en `/home/claude/banco/ronda-2/cooperativas/espacio/documentos/proyectos/PRY-203-aportes-sociales-en-línea/00-gobierno/ficha-pm.json`, con corte al 2026-10-15.

**Lleva:** 13 campos con dato · 9 sin decir en ninguna parte · **no declara estado**: `declared.status`, `declared.progress_pct`, `declared.as_of` y `declared.source` están sin decir en ninguna parte. La PMO verá el estado vacío, y es lo primero que va a mirar.

**Lo más viejo que va ahí:** los 13 campos con dato salen del acta de constitución del 2025-09-22 (13 meses; pasa de un año). Incluye `identity.sponsor`, `identity.manager`, `identity.committee`, `identity.product`, `plan.end_date` y `money.approved`, que son campos que la PMO contrasta. El acta no se ha actualizado desde entonces.

**Sin decir en ninguna parte:** identity.authority, identity.phase, declared.status, declared.progress_pct, declared.as_of, declared.source, money.committed, money.executed, money.projection.

**Señales que la ficha trae del recálculo:**
- Compromiso vencido: Carlos Peña, «Entregar el punto 2», vencía el 2026-10-11 (4 días), fuente `30-reuniones/2026-10-12-comite-semanal.md`.
- Compromiso sin fecha: Laura Vélez, «Mandar el ajuste del presupuesto» («la otra semana»).
- `plan.end_date` es 2026-10-15, es decir hoy, y la ficha no registra hitos.

Antes de publicar, no existía `ficha-pm.json` en esa carpeta; no se tocó ningún otro archivo de la documentación. Vera la encontrará en su próximo barrido; este comando no avisa a nadie.
