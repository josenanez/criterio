# Corrida del 2026-10-15 · pm-commitments

1 proyectos · 18 s · 2 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_overdue` | 1 |
| `commitment_undated` | 1 |

Sin reprogramaciones en umbral; Carlos Peña vencido sin evidencia, Laura Vélez sin fecha, Beatriz Cuéllar reprogramada 1 vez

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## Compromisos — Aportes sociales en línea (PRY-203) · al 2026-10-15

4 compromisos abiertos: 1 vencido sin evidencia, 1 sin fecha, 1 reprogramado una vez, 1 en plazo.

### Se viene reprogramando
Nada llega al umbral de 3 reprogramaciones. Se deja a la vista el que ya se movió una vez:

> **Beatriz Cuéllar** · Entregar el punto 32
> Prometido para el 2026-11-20, y antes para el 2026-11-06 (comité del 2026-10-12).
> Una reprogramación en tres días. Todavía no es un patrón, pero la nueva fecha cae después del cierre del proyecto (2026-10-15 en el acta de constitución).

### Vencidos sin evidencia
| Quién | Qué | Prometido para | Hace |
|---|---|---|---|
| Carlos Peña | Entregar el punto 2 | 2026-10-11 | 4 días |

Las notas del 2026-10-15 no mencionan este compromiso y el expediente no tiene entrega que lo respalde. Sigue abierto.
Detalle: la fecha prometida (2026-10-11) es anterior al comité donde se registró (2026-10-12). Conviene confirmar la fecha con él.

### Vencen esta semana
Ninguno. El más próximo es Óscar Ramírez, revisión con el proveedor, el 2026-10-25 (10 días).

### Sin fecha
| Quién | Qué | Dicho el |
|---|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto («la otra semana») | 2026-10-15 |

Se registra con `due_date: no_declarada`. No se calcula una fecha desde la frase.

### Cerrados desde la última revisión
Ninguno. Ningún compromiso tiene documento que lo cierre.

---
Cifras de `portafolio.py compute`: vencidos 1, sin fecha 1, reprogramados que alcanzan el umbral 0 (umbral 3; Beatriz Cuéllar lleva 1).
Términos: vigentes y aceptados por José Francisco Ñáñez el 2026-10-15; no hizo falta registrarlos de nuevo.
