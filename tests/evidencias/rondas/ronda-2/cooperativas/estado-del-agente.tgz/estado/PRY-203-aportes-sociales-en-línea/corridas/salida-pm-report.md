# Aportes sociales en línea (PRY-203) — corte al 2026-10-15

*Prueba sin interfaz: la pregunta de la declaración (paso 2) no pudo hacerse y no se propuso ningún estado. Con respuesta sugerida = no declarar, esa línea queda en blanco.*

**Declara el gerente:** — (sin declaración registrada en la ficha) · — · al —
**Sustento documental:** no evaluable: sin declaración registrada no hay contra qué contrastar
**Lo que el semáforo no explica:** sin semáforo declarado, todo queda sin explicar. Señal abierta: compromiso vencido (Carlos Peña).

> Aparte: el informe de avance del 2026-10-14 (`20-seguimiento/2026-10-14-informe-avance.md`) dice «Rojo, 34%». La ficha no lo tomó como declaración (`declared.status` sin dato; el cálculo no lo marcó como declaración). No lo uso como tal. Si Elena Duarte lo ratifica, hay que registrarlo.

## Qué cambió esta semana
No hay corrida anterior con la que comparar: el diff contra el snapshot de hoy da 0 cambios. Este informe sirve de línea de partida, no de comparación.

## Lo que sigue igual y sigue mal
| Qué | Desde | Días así |
|---|---|---|
| Compromiso de Carlos Peña «Entregar el punto 2», vencido sin evidencia (30-reuniones/2026-10-12-comite-semanal.md) | 2026-10-11 | 4 |

## Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2026-10-15 | 2026-10-15 | 0 días |
| Presupuesto | COP 4.200.000.000 | COP 4.200.000.000 | sin dato de proyección en la ficha |

Replanificaciones: 0 en la ficha. El informe del 14-oct menciona que «se reprogramó la salida por el cierre contable de fin de mes», pero no hay línea base nueva registrada: no cuadra con 0 replanificaciones y hay que revisarlo.
Atención: la fecha de cierre vigente es hoy, y el informe del 14-oct reporta 34% de avance. Sin hitos registrados, el cálculo no lo marca como atraso. Es una brecha que hay que mirar.

### Hitos de las próximas cuatro semanas
Sin hitos en la ficha.

## Las cifras
| Aprobado | Comprometido | Ejecutado | Proyectado | Disponible real |
|---|---|---|---|---|
| 4.200.000.000 | sin dato | sin dato | sin dato | no calculable |

Las cifras del informe del 14-oct (comprometido 2.705.437.450; ejecutado 1.996.494.350; proyección 3.996.935.557) no están en la ficha. Las dejo como referencia, no como dato calculado.

## Abierto
**Reprogramados:** ninguno.
**Vencidos sin evidencia:** Carlos Peña — «Entregar el punto 2» — desde 2026-10-11 (4 días).
**Sin fecha:** Laura Vélez — «Mandar el ajuste del presupuesto» (2026-10-15-notas-reunion.txt).
**RAID sin movimiento:** sin registro RAID en la ficha. El informe del 14-oct nombra dos riesgos (proveedor sin confirmar la fecha de la última entrega; conocimiento concentrado en una persona).
**Proveedor:** sin proveedores en la ficha.

## Lo que necesito de alguien
- Elena Duarte: declarar estado y avance al corte de hoy (o ratificar el «Rojo, 34%» del 14-oct).
- Carlos Peña: evidencia de «Entregar el punto 2».
- Laura Vélez: fecha para «Mandar el ajuste del presupuesto».

## Lo que no se sabe
**Sin dato:** autoridad, fase, estado declarado, avance declarado, fecha y fuente de la declaración, comprometido, ejecutado, proyección.
**Antigüedad:** 13 campos de identidad, plan y presupuesto vienen del acta del 2025-09-22 (13 meses).
**Silencio:** último documento hace 0 días (2026-10-15) · última reunión hace 3 días (2026-10-12).

---
Ficha: PRY-203, estado/PRY-203-aportes-sociales-en-línea/records/PRY-203.json, corte 2026-10-15 · 9 campos sin dato · Términos v1.1 aceptados por José Francisco Ñáñez el 2026-10-15: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.8
