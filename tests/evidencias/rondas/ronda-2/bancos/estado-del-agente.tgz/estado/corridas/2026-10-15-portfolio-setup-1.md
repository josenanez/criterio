# Corrida del 2026-10-15 · portfolio-setup

3 proyectos · 75 documentos, 51 releídos y 24 sin cambio · 95 s · 19 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 7 |
| `variance_cost` | 2 |
| `commitment_undated` | 2 |
| `vendor_deliverable_late` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `declared_vs_evidence` | 1 |
| `progress_vs_plan` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `pm_vs_pmo` | 1 |

0 preguntas (sesión sin interfaz, respuestas sugeridas); tiempo hasta el primer resultado no medido, una sola conversación; 3 proyectos (PRY-204, PRY-206, PRY-202), 24 documentos, 19 señales, 1 verde contradicho (PRY-202)

Primera corrida: no hay una anterior contra la cual comparar.

## Lo que produjo

## Listo — Portafolio de proyectos

**Miré:** 75 documentos en 13 proyectos · formatos: .md (36), .xlsx (11), .docx (10), .pdf (10), .csv (6), .json (1), .txt (1) · más reciente: 2026-10-15
**Eres:** PMO del portafolio (propuesto: hay varios proyectos)
**Te aviso:** dos días antes del comité; los comités son semanales, y el próximo lo supuse el 2026-10-22 (supuesto mío, no está en tus documentos)
**En:** presentación
**Términos:** aceptados por José Francisco Ñáñez para la versión 0.3.8 (términos 1.1), 2026-10-15 · comprobante en `.criterio/terminos/aceptacion-criterio-portfolio-0.3.8-2026-10-15.md` y `.pdf` · SHA-256 906ca52cb3296d17…

Sin interfaz no hubo preguntas: tomé la respuesta sugerida en cada una (rol, cadencia, formato, ubicación del estado `estado/` y de los informes `reportes/`).

### Probé con tres proyectos
Los de documentación más reciente: PRY-204, PRY-206 y PRY-202.

| Proyecto | Documentos | Qué supe | Qué no está |
|---|---|---|---|
| PRY-204 Débito contactless | 4 | Gerente Paula Céspedes, patrocinador Mauricio Pérez. Declara **rojo**, 58 %. Aprobado 800 M COP, proyección 1.020,7 M (informe 2026-10-12). | Autoridad del gerente, fase. Alcance sin detalle ("Componente 1, 2, 3"). |
| PRY-206 Billetera y QR | 14 | Gerente Camilo Beltrán, patrocinador Natalia Ospina. Declara **rojo**, 31 %. Aprobado 6.800 M, proyección 7.686 M (informe 2026-10-04). Dos contratos de proveedor y dos facturas. Tiene `ficha-pm.json`, que quedó aparte en `pm_record`. | Autoridad, fase. La ficha del gerente no trae estado ni avance. |
| PRY-202 Migración a la nube | 6 | Gerente Mauricio Pérez, patrocinador Jorge Medina. Declara **verde**, 82 %. Aprobado 18.000 M, proyección 17.240 M. CC-01 (+42 días, 84 M) autorizada por comité. | Producto ("No aplica"), autoridad, fase. |

**Hallazgos (señales que levantó `compute`, 19 en total):**

- **PRY-202, verde contradicho (`declared_vs_evidence`).** Declara verde, pero sus dos hitos cerrados (diseño funcional, ambiente de pruebas) no tienen acta que lo pruebe (`milestone_met_without_evidence`). Su atraso contra la línea base original es de 42 días (9 %), y viene de CC-01.
- **PRY-204.**
  - Hitos cerrados sin acta: diseño funcional (214 días) y ambiente de pruebas (97 días).
  - `variance_cost`: la proyección supera el aprobado en 27,6 %.
  - `commitment_undated`: Jorge Medina, "Entregar el punto 12", sin fecha.
- **PRY-206, 12 señales.**
  - `progress_vs_plan`: declara 31 % y el cronograma tiene 5 de 5 hitos cerrados (diferencia de 69 puntos).
  - `milestone_met_without_evidence`: ambiente de pruebas, integración con el core y piloto, sin acta.
  - `variance_cost`: la proyección supera el aprobado en 13 %.
  - `vendor_invoiced_over_accepted`: Redes del Norte (CT-725) facturó 1.317,8 M contra 920,1 M aceptados, 397,8 M de diferencia.
  - `vendor_accepted_without_evidence`: dos entregables de CT-725 dados por recibidos sin acta.
  - `vendor_deliverable_late`: el tarifario de CT-279 (103 días) y la bolsa de horas de CT-725 (232 días).
  - `commitment_undated`: Laura Vélez, ajuste del presupuesto.
  - `pm_vs_pmo`: fin de proyecto 2026-09-25 según el cronograma y 2026-11-11 según el acta.

Un riesgo dicho en reunión y que nadie registró quedó anotado en PRY-206 (el proveedor podría no llegar con el equipo completo). No es señal de `compute`; es lectura mía de las notas del 2026-10-15.

### El portafolio completo
10 proyectos más (PRY-199 a PRY-201, PRY-203, PRY-205, PRY-207 a PRY-211), 56 documentos. Estimo unos 30–40 minutos, un proyecto tras otro.

### Lo que le falta a tu carpeta
Ninguno bloquea.
- Ningún proyecto tiene declarada la autoridad del gerente, hasta qué monto decide sin subir a comité (3 de 3). Tampoco la fase.
- Los hitos cerrados casi nunca traen su acta de recibo: 7 de los 9 hitos cerrados leídos no tienen.
- Los compromisos de comité llegan con "por definir" o "la otra semana".
- Las actas de constitución traen alcance genérico ("Componente 1, 2, 3") y dependencias en "Ninguna declarada".
- PRY-205 no tiene cronograma ni reunión, y PRY-211 no tiene cronograma.
