# Corrida del 2026-10-15 · steering-pack

13 proyectos · 96 s · 67 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 24 |
| `progress_vs_plan` | 6 |
| `vendor_accepted_without_evidence` | 6 |
| `declared_vs_evidence` | 6 |
| `variance_time` | 4 |
| `commitment_undated` | 4 |
| `variance_cost` | 4 |
| `change_without_baseline` | 4 |
| `commitment_overdue` | 3 |
| `rebaseline_unauthorized` | 2 |
| `vendor_deliverable_late` | 2 |
| `vendor_invoiced_over_accepted` | 1 |
| `pm_vs_pmo` | 1 |

0 preguntas (sesión sin interfaz); términos ya vigentes; 6 decisiones, 7 escalamientos sobre 13 proyectos; no hay comité anterior registrado; autoridad no encontrada en 13 fichas; no leí las actas de 8 proyectos

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

Material de comité — fecha de corte de los datos: 2026-10-15 · próximo comité según la configuración: 2026-10-22
Fichas cargadas: 13 proyectos (PRY-199 a PRY-211), cifras recalculadas hoy con `portafolio.py compute` (as_of 2026-10-15). Términos v1.1 vigentes (aceptados por José Francisco Ñáñez, 2026-10-15).

# Comité de proyectos — 2026-10-22
6 decisiones · 7 escalamientos · 11 de 13 proyectos con hallazgos (67 señales abiertas)

## Decisiones del comité anterior
No hay acta ni registro de un comité anterior en las fichas ni en las corridas: no puedo decir qué se decidió ni qué se hizo con ello. Lo único que existe son seis solicitudes de cambio que dicen «Autorizada por el comité», sin acta que lo respalde:

| Decisión (según la solicitud) | Fecha | Qué pasó | Estado |
|---|---|---|---|
| PRY-202 CC-01: +42 días, 84.000.000 COP | 2026-10-04 | Línea base movida 42 días | Autorizada sin acta; línea base al día |
| PRY-203 CC-01: +78 días, 156.000.000 COP | 2026-10-04 | Señal `change_without_baseline` (78 días) | Autorizada sin acta; línea base sin actualizar |
| PRY-205 CC-01: +109 días, 218.000.000 COP | 2026-10-06 | Señal `change_without_baseline` (109 días); línea base movida 0 días | Autorizada sin acta; línea base sin actualizar |
| PRY-207 CC-01: +23 días, 46.000.000 COP | 2026-10-05 | Señal `change_without_baseline` (23 días) | Autorizada sin acta; línea base sin actualizar |
| PRY-207 CC-02: +120 días, 240.000.000 COP | 2026-10-13 | Señal `change_without_baseline` (120 días) | Autorizada sin acta; línea base sin actualizar |
| PRY-208 CC-01: +20 días, 40.000.000 COP | 2026-10-10 | Línea base movida 20 días | Autorizada sin acta; línea base al día |

## Decisiones de hoy

### [1] ¿Quién tiene la facultad de aprobar cambios de alcance, tiempo y costo en cada proyecto?
**Proyecto:** los 13 · **Quién decide:** patrocinador del portafolio / PMO — no está claro, por eso es el primer punto · **Si no se decide hoy:** los puntos 2 a 4 pueden quedar decididos por quien no tiene la facultad, y las seis autorizaciones de arriba siguen sin respaldo.
Hecho: `authority` no se encuentra en ninguna de las 13 fichas. Los documentos nombran tres comités distintos (Banca Empresas en PRY-200, Transformación Digital en PRY-205, Arquitectura en PRY-206) y ninguno dice hasta qué monto o días decide.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Un solo comité con umbrales escritos (días y COP) | Sin cambio | Decisión en una sesión | Sin costo directo |
| B. Cada comité de proyecto conserva su facultad, con umbrales escritos | Sin cambio | Más lento: hay que reunir varios comités | Sin costo directo |
| C. No definir hoy | Sin cambio | Se arrastra | Riesgo de pagar o ampliar sin autorización válida |
**Recomendación:** A. Los puntos 2 a 4 piden decidir con facultad y hoy no se puede demostrar quién la tiene.

### [2] ¿Se ratifica el cambio CC-01 de PRY-200 (+98 días, 196.000.000 COP), que ya se aplicó antes de ser presentado?
**Proyecto:** PRY-200 Originación digital · **Quién decide:** por definir (punto 1); el acta nombra al Comité de Banca Empresas · **Si no se decide hoy:** el cronograma v2 (fin 2026-08-16) sigue como línea base vigente sin autorización.
Hecho: el cronograma v2 es del 2026-10-10 y el CC-01 es del 2026-10-13, «pendiente de presentación al comité»; el motivo de la v2 no aparece. Señal `rebaseline_unauthorized`: 98 días movidos, 0 autorizados. Variación de tiempo contra la original: 98 días, 54.7 %. El informe declara rojo y 43 % de avance, mientras los 3 hitos figuran cumplidos, ninguno con evidencia.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Ratificar | Se amplía | +98 días | +196.000.000 COP (proyección actual 3.368.898.966 vs aprobado 3.300.000.000: 2.1 %) |
| B. Rechazar y volver a la línea base original (fin 2026-05-10) | Sin ampliación | Se reconoce el atraso real sin cubrirlo con una línea base nueva | Sin costo adicional |
| C. Ratificar solo con evidencia de los 3 hitos y motivo escrito | Se amplía condicionado | +98 días si se cumple | +196.000.000 COP condicionado |
**Recomendación:** C. Ratificar sin evidencia de hitos «cumplidos» valida un avance que nadie ha podido mostrar. Dato incierto: el acta dice cierre 2026-06-09 y el cronograma v1 dice 2026-05-10; no lo pude reconciliar.

### [3] ¿Se aprueba el cambio CC-01 de PRY-210 (+22 días, 44.000.000 COP)?
**Proyecto:** PRY-210 Portal de proveedores · **Quién decide:** por definir (punto 1) · **Si no se decide hoy:** el cronograma v2 (2026-10-10) sigue vigente sin autorización.
Hecho: señal `rebaseline_unauthorized` (22 días movidos, 0 autorizados); variación 22 días, 12.0 %. Fecha de cierre vigente: 2025-12-24, ya pasada. Declara verde con 39 % de avance, y sus 4 hitos figuran cumplidos sin evidencia (`progress_vs_plan`: el plan sostiene 100 %, brecha 61.0 puntos).
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar | Se amplía | +22 días | +44.000.000 COP (proyección 2.498.619.894 vs 2.400.000.000: 4.1 %) |
| B. Rechazar | Sin ampliación | La fecha ya vencida queda sin explicar | Sin costo adicional |
| C. Devolver hasta que el gerente presente nueva fecha de cierre y evidencia de hitos | Pendiente | Decisión al comité siguiente | Sin costo |
**Recomendación:** C. La fecha de cierre vigente ya venció; aprobar +22 días sobre una fecha pasada no dice cuándo termina.

### [4] ¿Se aprueba el cambio CC-02 de PRY-205 (+36 días, 72.000.000 COP), con el CC-01 aún sin reflejar en la línea base?
**Proyecto:** PRY-205 Prevención de lavado de activos · **Quién decide:** por definir (punto 1); el acta nombra al Comité de Transformación Digital · **Si no se decide hoy:** se acumulan dos cambios sobre una línea base que no se movió.
Hecho: CC-01 (+109 días) figura autorizado y la línea base se movió 0 días. CC-02 es del 2026-10-12, pendiente. Proyección 3.460.336.570 vs 3.300.000.000 aprobado (4.9 %); ejecutado 59.2 % frente a comprometido 38.0 %, algo que no he podido explicar (ejecutado por encima de lo comprometido). Sin hitos cargados, no puedo medir avance contra plan.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar CC-02 y registrar ambas líneas base | Se amplía | +36 días (más los 109 del CC-01) | +72.000.000 COP |
| B. Aprobar CC-02 solo cuando el CC-01 tenga acta y línea base nueva | Se amplía después | Posterior | +72.000.000 COP |
| C. Rechazar | Sin ampliación | Sin cambio | Sin costo adicional |
**Recomendación:** B. Antes de sumar un cambio hay que dejar asentado el anterior.

### [5] ¿Se suspende la aprobación de nuevas facturas del proveedor Redes del Norte Ltda. en PRY-206 hasta conciliar lo facturado con lo aceptado?
**Proyecto:** PRY-206 Billetera y QR · **Quién decide:** por definir (punto 1); comité nombrado: Arquitectura · **Si no se decide hoy:** se puede seguir pagando por encima de lo aceptado.
Hecho: facturado 1.317.839.587 COP, aceptado con monto 920.079.190 COP, diferencia 397.760.397 COP (señal `vendor_invoiced_over_accepted`). Sus entregables «Licenciamiento del motor» y «Parametrización del tarifario» figuran aceptados sin evidencia de recibo; «Bolsa de horas de desarrollo» está pendiente y venció 2026-02-25 (232 días). Consultora Andina: facturado igual a lo aceptado (762.675.710 COP), pero «Parametrización del tarifario» está pendiente desde 2026-07-04 (103 días).
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Suspender y pedir evidencia de aceptación | Sin cambio | Puede retrasar la fase siguiente | Retiene 397.760.397 COP de exposición |
| B. Seguir pagando y reclamar luego | Sin cambio | Sin demora | Exposición abierta |
| C. Suspender solo lo que exceda lo aceptado | Sin cambio | Demora parcial | Igual que A, más acotado |
**Recomendación:** C. Ninguna cifra mía implica que haya incumplimiento: solo que lo facturado supera lo aceptado en los documentos; pido la evidencia antes de pagar más.

### [6] ¿Se exige plan de contención o ampliación de presupuesto a los proyectos cuya proyección supera el 10 % del aprobado?
**Proyecto:** PRY-204, PRY-208, PRY-203, PRY-206 · **Quién decide:** por definir (punto 1) · **Si no se decide hoy:** el sobrecosto se vuelve gasto comprometido sin aprobación.
| Proyecto | Aprobado COP | Proyección COP | Desviación |
|---|---|---|---|
| PRY-204 Débito contactless | 800.000.000 | 1.020.707.324 | 27.6 % |
| PRY-208 Motor de decisión | 2.400.000.000 | 3.022.670.609 | 25.9 % |
| PRY-203 Open Banking | 3.300.000.000 | 3.753.660.017 | 13.7 % |
| PRY-206 Billetera y QR | 6.800.000.000 | 7.686.267.486 | 13.0 % |
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Pedir plan de contención dentro del presupuesto aprobado | Se puede recortar | Replaneación | Sin costo adicional |
| B. Ampliar presupuesto caso por caso | Se mantiene | Sin cambio | Sube el aprobado |
| C. Contención en los proyectos aún no cerrados y ampliación solo para PRY-204 (cierra 2026-11-05) | Mixto | Mixto | Mixto |
**Recomendación:** A como regla general, a revisar por proyecto. Esta recomendación es mi lectura, no un cálculo: la ficha no trae el motivo de cada sobrecosto.

## Escalamientos sin decisión asociada
| Proyecto | Qué | Desde cuándo | Qué se necesita |
|---|---|---|---|
| PRY-206 | Fecha de cierre en conflicto entre el cronograma (2026-09-25) y el acta (2026-11-11), ambos del 2025-06-02; sin informe de avance del gerente en la ficha del PM | 2025-06-02 | Que el patrocinador diga cuál rige |
| PRY-206 | En la reunión del 2026-10-15 se comentó que el proveedor podría no llegar con el equipo completo; nadie lo anotó como riesgo | 2026-10-15 | Registrarlo en el RAID, con doliente |
| PRY-200, PRY-203, PRY-208 | Compromisos vencidos: Diana Molina (PRY-200, «punto 22», 7 días; PRY-203, «punto 35», 17 días), María Restrepo (PRY-208, «punto 38», 23 días) | 2026-09-22 a 2026-10-08 | Nueva fecha o cierre, con evidencia |
| Seis verdes contradichos | PRY-202, 203, 207, 208, 209, 210 declaran verde y tienen señales abiertas | Informes del 2026-09-26 al 2026-10-14 | Que el gerente responda a las señales o cambie el estado |
| Hitos «cumplidos» sin evidencia | 10 proyectos (200, 201, 202, 203, 204, 206, 207, 208, 209, 210); en PRY-206 la ficha mantiene el avance declarado en 31 % con los 5 hitos cumplidos | Varios, desde 2025-07-17 | Decidir qué evidencia cuenta como aceptación |
| PRY-201, 203, 207, 209 | Entregable de proveedor «Componente de integración» recibido sin proveedor identificado ni evidencia | n/d | Identificar el proveedor y el contrato |
| Fichas con datos de más de 12 meses | PRY-201, 205, 206, 208, 210 | Desde 2025-05-22 | Confirmar los datos de identidad y plan |

## Para conocimiento
- PRY-199 Renovación de cajeros: verde, sin señales abiertas; sin fase ni autoridad en la ficha.
- PRY-211 Cobranza digital: declara rojo (25 %), sin señales abiertas; el motivo del rojo no está en lo que leí.
- PRY-201 Core de depósitos: amarillo, 3 hitos cumplidos sin evidencia y un compromiso sin fecha (Gustavo Neira, «punto 30»).
- PRY-202 Migración a la nube: verde, cambio autorizado con línea base al día; 2 hitos sin evidencia.
- PRY-204 Débito contactless: rojo declarado, cierre previsto 2026-11-05, compromiso sin fecha (Jorge Medina, «punto 12»).
- PRY-207 Onboarding PyME: avance declarado 75 % contra 25–50 % que sostiene el plan; dos cambios sin línea base.
- PRY-209 Nómina electrónica: verde, un hito sin evidencia, comprometido 77.2 %.

## Anexo
- Autoridad: sin dato en las 13 fichas. Fase del proyecto: sin dato en las 13.
- Contradicciones abiertas: PRY-206 `pm_vs_pmo` (fecha de cierre).
- Vacíos: ninguna ficha tiene evidencia marcada (evidence 0 en todas; las fuentes figuran «sin marcar»), así que ninguna cifra de avance puede declararse verificada.
- Presupuesto comprometido vs aprobado en el umbral de 90 %: ningún proyecto lo alcanza.
- No leí las actas de constitución de PRY-201, 202, 203, 207, 208, 209, 210 y 211 para este paquete; me apoyé en las fichas y las solicitudes de cambio. Si algún acta nombra una autoridad, el punto 1 cambia.

Pie: criterio-portfolio 0.3.8 · fichas aplicadas: 13 (cargadas al 2026-10-15) · campos inciertos: autoridad y fase (13 de 13), motivo del cronograma v2 de PRY-200 y PRY-210, cierre de PRY-200 (acta 2026-06-09 vs cronograma v1 2026-05-10), proveedor de «Componente de integración» · Términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.8
