Fuentes: ficha PRY-206 (estado/records/PRY-206.json) y `portafolio.py compute`, calculado el 2026-10-15. Las cuatro cifras salen del informe de avance del 2026-10-04 (PRY-206-billetera-y-qr/20-seguimiento/2026-10-04-informe-avance.pdf). El monto aprobado también figura en el acta de constitución del 2025-06-02.

## Presupuesto — PRY-206 Billetera y QR al 2026-10-15
**Moneda:** COP (única; no hay contratos en otra moneda, no se convirtió nada)

| | Monto (COP) | % del aprobado | Fuente | Fecha |
|---|---|---|---|---|
| Aprobado | 6.800.000.000 | — | Informe de avance 2026-10-04; coincide con el acta de constitución | 2026-10-04 (acta: 2025-06-02) |
| Comprometido | 3.979.137.385 | 58,5 % | Informe de avance 2026-10-04 | 2026-10-04 |
| Ejecutado | 2.925.165.723 | 43,0 % | Informe de avance 2026-10-04 | 2026-10-04 |
| Proyección al cierre | 7.686.267.486 | 13,0 % por encima del aprobado | Informe de avance 2026-10-04 (declaración del gerente, no dato duro) | 2026-10-04 |

**Disponible real** (aprobado menos comprometido): 2.820.862.615 COP

El comprometido (58,5 %) está por debajo del umbral de alerta de 90 %. Aquí el riesgo no está en el comprometido sino en la proyección.

### Contra la línea base
| | Original | Vigente | Desviación |
|---|---|---|---|
| Presupuesto aprobado | 6.800.000.000 | 6.800.000.000 | 0 en el aprobado |
| Proyección frente al aprobado | — | 7.686.267.486 | +13,0 % (umbral: 10 %) |

Replanificaciones de presupuesto: 0. No hay solicitudes de cambio registradas (`changes` vacío), así que el aprobado no se ha movido. El sobrecosto proyectado no tiene ningún cambio aprobado que lo respalde.

### Ejecución frente a avance
Ejecutado 43,0 % · Hitos cumplidos 5 de 5 · Avance declarado 31 %.
Lectura: el gerente declara 31 % de avance con 5 de 5 hitos "cumplidos" y el plan sostendría 100 %. Las dos lecturas no caben juntas (brecha de 69 puntos). Lo ejecutado (43,0 %) está por encima del avance declarado (31 %), que es la señal que este informe busca. Además, 3 de los 5 hitos marcados como cumplidos no tienen evidencia: Ambiente de pruebas certificado (vencido hace 302 días), Integración con el core (208 días) y Piloto con usuarios internos (114 días). Por eso el "5 de 5" no se puede usar para medir avance.

### Alertas
- **Proyección por encima del aprobado:** +13,0 %, sobre el umbral de 10 %. La proyección es una declaración con fecha 2026-10-04; hay 11 días de antigüedad, dentro del rango normal. No hay ningún movimiento de presupuesto posterior.
- **Ejecución desalineada del avance:** ejecutado 43,0 % contra avance declarado 31 % (ver arriba).
- **Facturado por encima de lo aceptado, Redes del Norte Ltda. (CT-725):** facturado 1.317.839.587 COP contra aceptado 920.079.190 COP; diferencia 397.760.397 COP. Dos de sus entregables figuran como aceptados sin evidencia (Licenciamiento del motor; Parametrización del tarifario). Hay un tercero pendiente y vencido, la Bolsa de horas de desarrollo (232 días de atraso). Parte de lo ejecutado puede estar pagado por entregables que no están sustentados.
- **Consultora Andina S.A.S. (CT-279):** facturado 762.675.710 COP, igual a lo aceptado. Le queda un entregable vencido, la Parametrización del tarifario (103 días de atraso).
- **Compromiso sin fecha:** Laura Vélez, "Mandar el ajuste del presupuesto" (notas de reunión del 2026-10-15). No tiene fecha y es el ajuste que este presupuesto necesita.
- **Fecha de fin en conflicto:** el cronograma dice 2026-09-25 y el acta de constitución dice 2026-11-11. Ambos son del 2025-06-02 y el agente no puede decir cuál manda. Esto afecta cuánto tiempo queda para absorber el sobrecosto.

### Sin dato
- Presupuesto original frente a vigente: no hay historial de versiones del presupuesto. Solo existe el aprobado, así que la desviación contra la línea base de costo se reduce a la proyección frente al aprobado.
- Desglose del comprometido por proveedor y por concepto: no está en los documentos leídos; las cifras vienen de una sola fuente.
- Estado, avance y fecha de corte del lado del gerente en la ficha (`pm_record.declared.*`): sin dato en esa sección. El avance declarado de 31 % sale del informe de avance del 2026-10-04.
- Tasa de cambio: no aplica, una sola moneda.
- Las cifras de dinero vienen de una sola fuente (el informe de avance) y están marcadas como declaración, no como evidencia contable. Ningún documento contable las confirma.

### Siguiente paso
La proyección excede el aprobado: puedo preparar la solicitud de cambio de presupuesto (`/criterio-portfolio:change-control`). También puedo detallar lo facturado por proveedor (`/criterio-portfolio:vendor-tracking`).

---
Pie de rigor: borrador de trabajo, no decisión ni asesoría. Cada cifra sale de `portafolio.py compute` y de la ficha, con la cita al documento de origen; la verificación es de quien lo lea. Términos v1.1 vigentes, aceptados por José Francisco Ñáñez el 2026-10-15.
