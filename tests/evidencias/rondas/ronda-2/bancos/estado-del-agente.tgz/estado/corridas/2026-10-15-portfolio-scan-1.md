# Corrida del 2026-10-15 · portfolio-scan

13 proyectos · 75 documentos, 0 releídos y 75 sin cambio · 203 s · 67 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 24 |
| `progress_vs_plan` | 6 |
| `vendor_accepted_without_evidence` | 6 |
| `declared_vs_evidence` | 6 |
| `variance_time` | 4 |
| `commitment_undated` | 4 |
| `variance_cost` | 4 |
| `change_without_baseline` | 4 |
| `commitment_overdue` | 3 |
| `rebaseline_unauthorized` | 2 |
| `vendor_deliverable_late` | 2 |
| `vendor_invoiced_over_accepted` | 1 |
| `pm_vs_pmo` | 1 |

10 fichas nuevas (PRY-199,200,201,203,205,207,208,209,210,211) de 51 documentos; 24 sin cambio (PRY-202,204,206) no se releyeron; nada que mover (no hay entrada/); mirar: 5 proyectos en verde con señales en contra, hitos cerrados sin acta, cambios autorizados sin línea base nueva (203,205,207), compromisos vencidos (200,203,208).

Contra la corrida del 2026-10-15: +48 hallazgos.

## Lo que produjo

## Barrido — 2026-10-15

**Términos:** vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15). Criterio produce borradores de trabajo, no decisiones ni asesoría; cada dato lleva la cita del documento y la verificación es de quien lo usa. Nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal

**Qué encontré:** 75 documentos en 13 carpetas de proyecto (.md 36, .xlsx 11, .docx 10, .pdf 10, .csv 6, .json 1, .txt 1). Un solo lote de 10 proyectos, uno tras otro (`workers: 1`); no hubo proyectos diferidos.

**Documentos:** 75 en la carpeta · 51 leídos · 24 sin cambio desde la corrida anterior (PRY-202, PRY-204, PRY-206) · 0 ilegibles
**Proyectos:** 13 con ficha · 10 nuevos · 0 sin carpeta propia

### Nuevos
| Proyecto | Documentos | Campos encontrados | Campos sin dato |
|---|---|---|---|
| PRY-199 Renovación de cajeros automáticos | 6 | identidad, plan (5 hitos), presupuesto, 1 contrato (3 entregables), 1 compromiso | authority, phase, facturado del contrato |
| PRY-200 Originación digital | 6 | identidad, plan v1 y v2 (3 hitos), presupuesto, CC-01, 1 compromiso | authority, phase |
| PRY-201 Core de depósitos | 4 | identidad, plan (4 hitos), presupuesto, 1 compromiso sin fecha | authority, phase, proveedor y facturado del componente entregado |
| PRY-203 Open Banking | 7 | identidad, plan v1 y v2 (4 hitos), presupuesto, CC-01, 1 compromiso, 1 acta de recibo | authority, phase, proveedor y facturado |
| PRY-205 Prevención de lavado de activos | 4 | identidad, presupuesto, CC-01 y CC-02 | product («No aplica»), authority, phase; no hay cronograma, hitos ni minuta |
| PRY-207 Onboarding PyME | 6 | identidad, plan v1 y v3 (4 hitos), presupuesto, CC-01 y CC-02 | authority, phase, proveedor y facturado |
| PRY-208 Motor de decisión | 6 | identidad, plan v1 y v2 (3 hitos), presupuesto, CC-01, 2 compromisos | product («No aplica»), authority, phase |
| PRY-209 Nómina electrónica | 4 | identidad, plan (4 hitos), presupuesto, 1 acta de recibo | authority, phase, proveedor y facturado |
| PRY-210 Portal de proveedores | 6 | identidad, plan v1 y v2 (4 hitos), presupuesto, CC-01, 1 compromiso sin fecha | product («No aplica»), authority, phase |
| PRY-211 Cobranza digital | 2 | identidad, presupuesto | authority, phase; no hay cronograma, hitos, comité ni minuta |

### Actualizados
| Proyecto | Qué cambió | Fuente |
|---|---|---|
| PRY-202, PRY-204, PRY-206 | Nada: documentos con el mismo hash que en la corrida anterior; no se releyeron | `estado/records/` |

### No pude leer
| Archivo | Por qué |
|---|---|
| — | Ninguno: los 75 se convirtieron a texto (PDF con `pdftotext`; Word y Excel con la librería estándar) |

### Movidos desde entrada/
| Archivo | A qué proyecto | Por qué |
|---|---|---|
| — | — | No hay carpeta `entrada/` en la documentación; no se movió nada |

### Pendientes de clasificar
| Archivo | Por qué no pude decidir |
|---|---|
| — | Ninguno |

### Lo que hay que mirar (señales calculadas por el script, no opiniones)

**Contradicciones y alertas de gobierno**
- **Declarado vs. evidencia.** PRY-203, 207, 208, 209 y 210 reportan **verde** y el cálculo encuentra señales en contra (hitos cerrados sin acta, avance fuera de lo que sostiene el plan, sobrecosto, compromisos vencidos). PRY-200 y PRY-211 reportan rojo, de acuerdo con lo que se ve.
- **Hitos declarados cerrados sin documento que lo pruebe** (`milestone_met_without_evidence`): PRY-200 (3), 201 (3), 203 (2), 207 (1), 208 (3), 209 (1), 210 (4). Con acta de recibo: el diseño funcional de PRY-199 y PRY-209 y el ambiente de pruebas de PRY-203.
- **Línea base movida sin autorización registrada.** PRY-200: el cronograma v2 (2026-10-10) ya corrió «Integración con el core» +98 días y la CC-01 (+98) está pendiente de comité. PRY-210: v2 ya corrió el piloto +22 días y la CC-01 (+22) está pendiente.
- **Cambios autorizados sin línea base nueva** (`change_without_baseline`): PRY-203 CC-01 (+78 d), PRY-205 CC-01 (+109 d), PRY-207 CC-01 (+23 d) y CC-02 (+120 d). En ningún caso hay acta ni fecha de la decisión del comité. PRY-207: el cronograma v3 es del 2026-09-26, anterior a ambas solicitudes, aunque ya refleja +143 días; no existe v2.

**Presupuesto**
- Proyección sobre lo aprobado: PRY-208 +25,9 % (3,02 mil millones frente a 2,4), PRY-203 +13,7 %.
- PRY-205: lo **ejecutado** (1.952 M) supera lo **comprometido** (1.254 M); el informe lo declara así y no hay otro documento que lo explique.

**Compromisos**
- Vencidos sin evidencia: Diana Molina (PRY-200 punto 22, 7 días; PRY-203 punto 35, 17 días), María Restrepo (PRY-208 punto 38, 23 días).
- Sin fecha: Gustavo Neira (PRY-201 punto 30) y Rubén Cárdenas (PRY-210 punto 10).
- Carlos Peña (PRY-199), Diana Molina, María Restrepo y Gustavo Neira figuran como responsables sin aparecer entre los asistentes de la minuta.

**Fechas ya vencidas con el proyecto abierto.** El cierre del acta ya pasó en PRY-210 (2025-12-26), PRY-208 (2026-05-20) y PRY-200 (2026-06-09); ninguno tiene una fecha de cierre nueva en un documento.

**Otros**
- Proveedor sin nombre ni contrato en PRY-201, 203, 207 y 209: los informes dicen «el proveedor entregó el componente de integración, pendiente de aceptación» y no hay acta de recibo. Solo PRY-199 tiene contrato (CT-199, Consultora Andina; 3 entregables de 144 M, ninguno vencido aún, primero el 2026-11-14).
- Los informes de PRY-199 y PRY-205 y PRY-211 dicen que la salida se reprogramó, pero no existe un cronograma posterior que lo refleje.
- Ningún acta nombra la facultad del gerente (`authority`) ni la fase.
- Ninguna acta declara dependencias; los informes sí mencionan la dependencia del calendario de liberaciones del core (PRY-199, 201, 205, 207) sin indicar de qué proyecto. Quedó como riesgo, no como dependencia, porque no hay código de proyecto que citar.
- Una misma persona ocupa roles distintos entre proyectos: Óscar Ramírez (gerente de PRY-200 y PRY-210, patrocinador de PRY-207 y PRY-211), Elena Duarte (gerente de PRY-203, patrocinadora de PRY-201), Javier Hoyos (gerente de PRY-207, patrocinador de PRY-208), Natalia Ospina (patrocinadora de PRY-200, 205 y 209), Paula Céspedes (gerente de PRY-209 y PRY-211). No es un defecto de la ficha; se deja a la vista.
- El índice sigue marcando como «fuente sin resolver» los campos de `pm_record` de PRY-206 (rutas relativas a la carpeta del proyecto, no a la raíz de documentación). No se tocó: es la ficha del gerente y no la reescribe este barrido.

### Después
Hay más de un proyecto: puedo producir el informe consolidado de portafolio (`/criterio-portfolio:portfolio-report`). Las contradicciones y los compromisos vencidos de arriba entran ahí.

---
Criterio Portfolio 0.3.8 · fichas tocadas: 10 (PRY-199, 200, 201, 203, 205, 207, 208, 209, 210, 211) · campos en `not_found`: 28 (authority 10, phase 10, product 3, facturado del proveedor 5) · Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal
