# Corrida del 2026-10-15 · portfolio-server

13 proyectos · 67 hallazgos

> El tiempo no se midió: faltó `corrida-inicio` al arrancar. Un tiempo escrito a mano es un recuerdo, no una medición.

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 24 |
| `progress_vs_plan` | 6 |
| `vendor_accepted_without_evidence` | 6 |
| `declared_vs_evidence` | 6 |
| `variance_time` | 4 |
| `commitment_undated` | 4 |
| `variance_cost` | 4 |
| `change_without_baseline` | 4 |
| `commitment_overdue` | 3 |
| `rebaseline_unauthorized` | 2 |
| `vendor_deliverable_late` | 2 |
| `vendor_invoiced_over_accepted` | 1 |
| `pm_vs_pmo` | 1 |

puerto 8787, carpeta del informe reportes, modo rato

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

# Rostrum — modo «para mirarlo un rato»

Términos: vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-15). No hizo falta registrar de nuevo.

Modo elegido: **para mirarlo un rato** (indicado en el argumento `rato`). Es la forma recomendada para empezar: se levanta en segundos, se ve funcionando, y con eso en la mano la conversación con seguridad es otra.

Informe: `reportes/` (hay informes HTML por proyecto, PRY-199 a PRY-208). El servidor no genera el informe, lo sirve.

Comando:

```
python3 "/home/claude/banco/criterio/plugins/criterio-portfolio/scripts/servidor.py" --informe reportes --estado estado --config .criterio/portafolio/config.json
```

Escucha en `127.0.0.1:8787`, solo en este equipo. Se para con Ctrl-C. Si el puerto está ocupado, `--puerto 8788`.

| Ruta | Qué es | Para quién |
|---|---|---|
| `/` | Portada con las tres secciones y el formulario de peticiones | Todos |
| `/pmo` | Cómo va el portafolio: verdes sin sustento, silencios, patrocinadores repetidos | La PMO |
| `/decisiones` | Lo que necesita decisión, con la consecuencia de no decidir | Comité y patrocinador |
| `/proyectos` | Listado ordenado por lo que más pide atención | Todos |
| `/p/<código>` | Informe de un proyecto, con enlace a su producto | Quien gerencia |
| `/productos` | Listado de productos y proyectos sin producto declarado | Quien responde por un producto |
| `/producto/<nombre>` | Informe de un producto, con enlace a sus proyectos | Quien responde por un producto |
| `/estado.json` | Fecha del informe y peticiones abiertas | Un mecanismo |

Lo que Rostrum no hace: no calcula (sirve lo que `informe.py` ya escribió), no escribe fichas (solo la petición, en `estado/peticiones/`), no autentica, no manda nada.

Cierre: este enlace (`http://127.0.0.1:8787/`) solo sirve en este equipo, para quien esté sentado aquí. No se lo pases a un patrocinador: no lo abriría. Para que él tenga un enlace estable hace falta la segunda forma («que quede corriendo»), con `--abierto` y un host, un puerto y el control de acceso de la organización. El informe está tan actualizado como la última corrida de `/portfolio-report` (2026-10-15); la portada muestra la fecha.
