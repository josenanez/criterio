# Corrida del 2026-10-15 · change-control

13 proyectos · 43 s · 67 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 24 |
| `progress_vs_plan` | 6 |
| `vendor_accepted_without_evidence` | 6 |
| `declared_vs_evidence` | 6 |
| `variance_time` | 4 |
| `commitment_undated` | 4 |
| `variance_cost` | 4 |
| `change_without_baseline` | 4 |
| `commitment_overdue` | 3 |
| `rebaseline_unauthorized` | 2 |
| `vendor_deliverable_late` | 2 |
| `vendor_invoiced_over_accepted` | 1 |
| `pm_vs_pmo` | 1 |

Solicitud de mover 30 días la salida a producción de PRY-206. Sin solicitante ni motivo. El hito ya figura recibido el 2026-10-04. Dos fechas de cierre sin resolver (2026-09-25 y 2026-11-11). Sin autoridad declarada, así que va a comité por defecto. Cero dependencias declaradas. No se sabe el impacto en alcance ni en costo, ni la holgura por actividad. No se creó línea base nueva.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

Sale de la ficha `estado/records/PRY-206.json` (actualizada 2026-10-15), calculada con `portafolio.py impact` y `compute`. Términos v1.1 vigentes, aceptados por José Francisco Ñáñez el 2026-10-15.

## Solicitud de cambio — PRY-206 Billetera y QR — 2026-10-15

**Qué se pide:** mover la salida a producción 30 días.
**Quién lo pide:** no consta. La solicitud llegó sin solicitante, y ningún documento de la carpeta lo nombra.
**Por qué:** no consta. No hay motivo escrito.

### Antes de evaluar: dos cosas que la carpeta contradice

1. **La salida a producción ya figura como recibida.** `20-seguimiento/2026-10-04-acta-recibo-salida-a-producción.md` dice que Camilo Beltrán la recibió a satisfacción el 2026-10-04, y la ficha marca el hito como `met`. Mover 30 días un hito ya recibido solo tiene sentido en una de estas tres lecturas, y la carpeta no dice cuál es la cierta:
   - el acta de recibo es un error y la salida no ocurrió;
   - ocurrió, y lo que se pide es otra cosa (por ejemplo, una nueva salida o una fase siguiente);
   - se pide mover un hito que ya pasó, lo cual no es un cambio de plan sino una corrección del registro.
   El acta de recibo tiene dos líneas y no trae evidencia de despliegue. El informe de avance (2026-10-04) declara 31 % de avance y estado rojo; eso no cuadra con una salida a producción cumplida. Quien solicita el cambio debe aclararlo antes de que alguien lo evalúe.
2. **Hay dos fechas de cierre sin resolver.** El cronograma v1 (2025-06-02) dice **2026-09-25** y el acta de constitución (2025-06-02) dice **2026-11-11**. Los dos documentos son del mismo día y la ficha no puede decir cuál manda (`pm_vs_pmo`, sin `newer`). La línea base v1 registrada usa 2026-09-25.

### Impacto
| Dimensión | Hoy | Con el cambio | Diferencia |
| Alcance | Componentes 1 a 3, sin descripción concreta en el acta | No declarado | **Sin impacto declarado** |
| Tiempo | Salida a producción 2026-09-25 (cronograma v1); cierre 2026-09-25 (cronograma) o 2026-11-11 (acta) | Salida 2026-10-25; cierre 2026-10-25 contra el cronograma, o 2026-12-11 contra el acta (aritmética de calendario, sin holgura) | +30 días |
| Costo | Aprobado 6.800.000.000 COP; proyección 7.686.267.486 COP (+13,0 %, ya sobre el umbral del 10 %) | No declarado | **Sin impacto declarado** |

**Quién absorbe lo que no se declaró.** Mover la fecha 30 días sin tocar alcance ni costo significa que alguien lo absorbe en horas no pagadas o en calidad. En costo hay además un dato concreto: la proyección ya excede lo aprobado en 886.267.486 COP, y Laura Vélez quedó de mandar «el ajuste del presupuesto la otra semana» sin fecha (compromiso sin fecha, abierto desde el 2026-10-15). Un retraso de 30 días con equipos de proveedor contratados puede subir esa proyección, pero **no hay cifra en los documentos** y no se inventa una.

### Efecto en el portafolio
| Proyecto afectado | Cómo | Gerente |
| Ninguno | El acta de constitución dice «Ninguna declarada» en dependencias y la ficha no tiene ninguna. El cálculo (`impact`) alcanza 0 proyectos, 0 hitos, 0 que no puedan sostener su fecha y 0 sin confirmar. | — |

**Lo que este resultado no dice:** que el cambio no afecte a nadie. Dice que **nadie lo declaró**. Un producto de pagos QR que se conecta con el core y con proveedores tiene dependencias reales; la ausencia de ellas en el acta es un hallazgo, no una tranquilidad. Tampoco se sabe cuántos días se mueve cada actividad: la ficha no tiene holgura por actividad.

**Riesgo no registrado que toca este cambio:** en la reunión del 2026-10-15 se dijo que el proveedor podría no llegar con el equipo completo para la siguiente fase; nadie lo anotó como riesgo (fuente: `2026-10-15-notas-reunion.txt`).

### Quién decide
**Autoridad requerida:** no se puede determinar. `identity.authority` no se encuentra en ningún documento: el acta no declara qué cambios decide el gerente, cuáles el patrocinador y cuáles el comité.
**Según:** acta de constitución 2025-06-02, sin cláusula de autoridad. Lo único que consta es que el Comité de Arquitectura aprobó el acta y que el patrocinador es Natalia Ospina.
**Va a comité:** **sí, por defecto.** Sin autoridad declarada, ese es el hallazgo de fondo, y lo prudente es llevarlo al Comité de Arquitectura. El comité semanal de la PMO es el 2026-10-22.

### Si no se aprueba
El proyecto sigue con la fecha del cronograma v1 (2026-09-25), que ya pasó: son 20 días de vencida contra el hoy. Con el acta de recibo de la salida a producción esto se explica; sin ella, el proyecto está vencido. La contradicción de la sección inicial decide cuál de las dos situaciones es la real. Se mantienen además los 69 puntos de brecha entre el 31 % declarado y los 5 de 5 hitos cumplidos, 3 de ellos sin evidencia.

### Si se aprueba
Línea base **2** — salida 2026-10-25 · presupuesto 6.800.000.000 COP (sin cambio declarado) · motivo: **no consta; hay que escribirlo antes de aprobar**. Se añade como registro nuevo; la línea base 1 (2025-06-02, cierre 2026-09-25) no se toca.
Desviación acumulada contra la línea base original: **tiempo +30 días** (hoy 0 días y 0 replanificaciones registradas) · **costo +886.267.486 COP (+13,0 %)** por proyección, que no depende de este cambio.
Reconciliación (`changes`): hoy 0 cambios registrados, 0 días autorizados, 0 días de línea base movidos y 0 días sin autorización. Si se mueve la línea base sin un cambio aprobado por quien tenga autoridad, quedarían 30 días sin autorizar.

### Qué no se hizo
- No se registró ninguna línea base nueva: la solicitud no está aprobada.
- No se asumió solicitante, motivo, ni impacto en alcance o costo.
- No se estimó cuántos días se mueve cada proyecto o actividad.

### Siguiente paso
Llevar al Comité de Arquitectura, con estas tres preguntas abiertas: ¿ocurrió la salida a producción del 2026-10-04?, ¿cuál fecha de cierre rige, 2026-09-25 o 2026-11-11?, ¿quién tiene autoridad para aprobar un cambio de fecha? Si ya fue aprobado por quien podía hacerlo, se registra la línea base 2.

---
**Pie de rigor.** Sale de 14 documentos de la carpeta de PRY-206 vistos en la ficha; se releyeron para esta solicitud el acta de constitución, el acta de recibo de la salida a producción, el acta del comité del 2026-10-12 y las notas del 2026-10-15. No se leyeron el cronograma ni los PDF (no tienen texto extraído); sus datos vienen de la ficha. Lo que no está en los documentos: solicitante, motivo, autoridad, dependencias, holgura por actividad, impacto en costo. La verificación de cada cita es de quien lo lea.
