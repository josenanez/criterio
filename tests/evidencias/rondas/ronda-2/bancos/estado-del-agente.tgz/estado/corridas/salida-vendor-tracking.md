Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15); no se volvieron a registrar.

Esta salida sale de los documentos de PRY-206 en `documentos/proyectos/PRY-206-billetera-y-qr/`: los dos contratos (`00-gobierno/2025-05-23-contrato-ct-279.md`, `00-gobierno/2025-06-06-contrato-ct-725.docx`), el acta de constitución, las cinco actas de recibo y las dos facturas de `20-seguimiento/`, el informe de avance del 2026-10-04, el comité del 2026-10-12 y las notas del 2026-10-15. Las cifras derivadas salen de `portafolio.py compute`.

## Proveedores — PRY-206 Billetera y QR al 2026-10-15

Cada contrato dice que el entregable se factura contra un acta de recibo firmada por el gerente del proyecto (Camilo Beltrán). Ese es el criterio con el que se cruza abajo.

### Consultora Andina S.A.S. — contrato CT-279
**Vigencia:** sin dato (el contrato firmado el 2025-05-23 no trae fecha de terminación) · **Preaviso de no renovación:** sin dato · **Vence el:** sin dato

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento del motor (381.337.855 COP) | 2025-10-19 | Aceptado | Acta de recibo 2025-11-05 (`20-seguimiento/2025-11-05-acta-recibo-ct-279-licenciamiento-del-motor.pdf`) | Sí, dentro de FV-2279 |
| Bolsa de horas de desarrollo (381.337.855 COP) | 2026-02-25 | Aceptado | Acta de recibo 2026-03-16 (`20-seguimiento/2026-03-16-acta-recibo-ct-279-bolsa-de-horas-de-desarrollo.md`) | Sí, dentro de FV-2279 |
| Parametrización del tarifario (381.337.855 COP) | 2026-07-04 | Pendiente, vencido 103 días | Ninguna; el contrato lo marca «pendiente» | No |

Factura FV-2279 (2026-09-10): 762.675.710 COP, igual a lo aceptado con acta (762.675.710 COP). Aquí lo facturado cuadra con la evidencia.

### Redes del Norte Ltda. — contrato CT-725
**Vigencia:** sin dato (contrato firmado el 2025-06-06, sin fecha de terminación) · **Preaviso de no renovación:** sin dato · **Vence el:** sin dato

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento del motor (460.039.595 COP) | 2025-10-19 | `unknown`; el contrato dice «recibido» | Ninguna: no hay acta de CT-725 | Dentro de FV-1725, sin desglose |
| Bolsa de horas de desarrollo (460.039.595 COP) | 2026-02-25 | En curso, vencido 232 días | Ninguna; el contrato lo marca «en curso» | Sin desglose |
| Parametrización del tarifario (460.039.595 COP) | 2026-07-04 | `unknown`; el contrato dice «recibido» | Ninguna: no hay acta de CT-725 | Dentro de FV-1725, sin desglose |

Factura FV-1725 (2026-09-10): 1.317.839.587 COP.

### Dónde no cuadra
| Qué | Dice el contrato | Dice la evidencia | Fuentes |
|---|---|---|---|
| Facturado de CT-725 contra lo aceptado | Dos entregables «recibidos» suman 920.079.190 COP | Se facturó 1.317.839.587 COP: 397.760.397 COP por encima de lo que el propio contrato da por recibido | `2025-06-06-contrato-ct-725.docx`, `2026-09-10-factura-ct-725.pdf` |
| Aceptación de CT-725 | «Recibido» en licenciamiento y parametrización | No hay ningún acta de recibo que cite CT-725. Las dos actas con esos nombres de entregable (licenciamiento, bolsa de horas) citan CT-279 | contrato CT-725; actas de 2025-11-05 y 2026-03-16 |
| Parametrización del tarifario | CT-279: «pendiente». CT-725: «recibido» | El mismo entregable, con la misma fecha (2026-07-04), figura pendiente con un proveedor y recibido con el otro, sin acta en ninguno | ambos contratos |
| Pago contra acta | Los dos contratos exigen acta firmada por el gerente para facturar | Para CT-725 la factura está radicada en cuentas por pagar sin ningún acta que la respalde | contrato CT-725, factura FV-1725 |

Además, los dos contratos listan los mismos tres entregables con las mismas fechas. Los documentos no dicen si es el mismo alcance contratado dos veces, un reparto entre proveedores o un error de transcripción. Esa pregunta es de quien firmó los contratos, no se resuelve desde aquí.

El informe de avance del 2026-10-04 dice que «el proveedor entregó el componente de integración, pendiente de aceptación». No dice qué proveedor, y «integración» no es un entregable de ninguno de los dos contratos. No lo cuento como entregado ni lo asigno a un contrato.

### Sin evidencia de recibo
| Entregable | Marcado como | Desde |
|---|---|---|
| Licenciamiento del motor (CT-725) | Recibido | Sin fecha de aceptación declarada; el contrato es del 2025-06-06 y el entregable vencía el 2025-10-19 |
| Parametrización del tarifario (CT-725) | Recibido | Sin fecha de aceptación declarada; el contrato es del 2025-06-06 y vencía el 2026-07-04 |

Las actas del 2026-10-04 (Salida a producción) y del 2026-10-11 (Diseño funcional aprobado) no citan contrato ni proveedor; no las atribuyo a ninguno.

### Compromisos del proveedor vencidos
Ninguno. Las notas del 2026-10-15 recogen tres compromisos y ninguno es del proveedor ni está vencido:
- Óscar Ramírez, «revisión con el proveedor», para 2026-10-25 (es una revisión interna sobre el proveedor, no una promesa de él).
- Liliana Torres, «entregar el punto 21», movido del 2026-10-05 al 2026-10-29. Los documentos no dicen si Liliana es del proveedor o interna.
- Laura Vélez, «mandar el ajuste del presupuesto», sin fecha (dijo «la otra semana»). No es del proveedor.

Las mismas notas dicen que el proveedor podría no llegar con el equipo completo a la siguiente fase y que nadie lo anotó como riesgo. No dicen de cuál proveedor hablan. Sigue sin estar en el registro de riesgos.

### Sin dato
- Vigencia, fecha de terminación, renovación automática y preaviso de los dos contratos: ninguno los trae. No puedo decir si algún preaviso vence antes del cierre del proyecto. Hay que pedir los contratos completos o sus anexos.
- Dos fechas de cierre del proyecto que no se reconcilian: 2026-09-25 en el cronograma (`10-plan/2025-06-02-cronograma-v1.xlsx`) y 2026-11-11 en el acta de constitución. Las dos son del 2025-06-02.
- Nada indica si «recibido» en CT-725 viene de un acta que no está en la carpeta o de una anotación sin respaldo. Que no esté en la carpeta no prueba que no exista.
- No se sabe a quién corresponde el «componente de integración» del informe de avance.

## Después

Lo más urgente es CT-725: 1.317.839.587 COP facturados y radicados en cuentas por pagar sin ningún acta de recibo, 397.760.397 COP por encima de lo que el propio contrato da por recibido. Conviene frenar el pago hasta que aparezcan las actas o se aclare el alcance. Ofrezco llevarlo a comité (el próximo es el 2026-10-22) con `/criterio-portfolio:steering-pack`. Antes de eso, hay que pedirle a Camilo Beltrán las actas de CT-725 y a quien firmó los contratos que aclare si los dos cubren el mismo alcance.

Del lado de Andina, la parametrización lleva 103 días vencida y el contrato la marca pendiente, sin otra explicación en los documentos.

Preaviso de contratos: no se puede evaluar (ver «Sin dato»).

## Pie de rigor
- **Leído:** los 13 documentos de PRY-206 citados arriba, en su copia de texto de `estado/texto/`; cada línea cita el original.
- **No leído / no existe en la carpeta:** actas de recibo de CT-725, desglose de las facturas, anexos de contrato, registro de riesgos.
- **Cifras:** copiadas de `portafolio.py compute` al 2026-10-15; las sumas de las facturas y las actas coinciden con esa salida.
- **Esto es un borrador de trabajo, no una decisión ni una asesoría.** Criterio puede equivocarse; la verificación contra los originales es suya.
