# Corrida del 2026-10-15 · portfolio-wake

13 proyectos · 31 s · 67 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 24 |
| `progress_vs_plan` | 6 |
| `vendor_accepted_without_evidence` | 6 |
| `declared_vs_evidence` | 6 |
| `variance_time` | 4 |
| `commitment_undated` | 4 |
| `variance_cost` | 4 |
| `change_without_baseline` | 4 |
| `commitment_overdue` | 3 |
| `rebaseline_unauthorized` | 2 |
| `vendor_deliverable_late` | 2 |
| `vendor_invoiced_over_accepted` | 1 |
| `pm_vs_pmo` | 1 |

Barrido: 75 documentos sin cambios, nada que releer. 17 citas de PRY-206 no resuelven (acta y notas del 15-oct); ficha sin tocar. Confirmación: 5 preguntas sobre PRY-206 hechas, sin respuesta (sesión sin interfaz). No se atendieron peticiones (no tocaban).

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## 2026-10-15

**Revisé:** 75 documentos · 0 cambiaron · 0 proyectos recalculados

Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-15); no se volvieron a pedir.

### Lo que cruzó un umbral
Nada cruzó un umbral: no hay documentos nuevos, cambiados, renombrados ni borrados, así que no se corrió `/portfolio-scan`.

**Hallazgo — citas que no resuelven (PRY-206):** el índice marca 17 campos de la ficha cuyo texto citado no se encuentra en su fuente:
- 9 de `00-gobierno/2025-06-02-acta-constitucion.md` (código, nombre, sponsor, gerente, comité, producto, fecha de inicio, fecha de fin, presupuesto aprobado).
- 9 de `2026-10-15-notas-reunion.txt` (quién, qué y fecha de los tres compromisos).
Ambos archivos existen; lo que no resuelve es la cita dentro de ellos. No se corrigió la ficha: queda para que alguien relea esos dos documentos.

### Peticiones atendidas
Ninguna (`requests` no tocaba hoy).

### Preguntas
Nadie respondió en esta sesión sin interfaz, así que quedan **preguntadas el 2026-10-15, sin respuesta**. Cinco campos de PRY-206, por importancia (el dato actual viene de las fichas, sin fecha de corte registrada):
1. Fecha de fin 2026-11-11 (acta 2025-06-02): ¿sigue vigente?
2. Presupuesto aprobado 6.800.000.000 (acta 2025-06-02): ¿sigue vigente?
3. Gerente Camilo Beltrán: ¿sigue siendo el gerente?
4. Compromiso de Laura Vélez, «Mandar el ajuste del presupuesto»: ¿para qué fecha? (hoy: no declarada)
5. Compromiso de Liliana Torres, «Entregar el punto 21», 2026-10-29: ¿se mantiene?

**Vuelvo el 2026-10-16.**
