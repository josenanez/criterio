## Historia · PRY-207 Onboarding PyME · 2026-05-17 a 2026-10-13

**Leí:** 6 documentos entre 2026-05-17 y 2026-10-13
**Trimestres sin un solo documento:** ninguno. Pero entre el 2026-05-17 y el 2026-09-26 no hay ningún documento: el arranque y el informe de avance quedan separados por ese hueco.

### En una línea
El proyecto nació el 2026-05-17 con cierre del último hito al 2027-03-20. El 2026-09-26 el cronograma v3 movió el piloto al 2027-08-10 y, ese mismo día, el informe de avance declaró verde y 75%. Las dos solicitudes de cambio que suman ese mismo corrimiento (CC-01 del 2026-10-05, CC-02 del 2026-10-13) son posteriores al cronograma que ya lo contenía.

### Las cuatro cifras
| Replanificaciones | Atraso acumulado vs. original | Meses declarando sin sustento | Cambios de gobierno |
|---|---|---|---|
| 1 | 143 días (48.1 %) | No calculable: hay un solo estado declarado (2026-09-26); no hay serie | 0 documentados |

### Línea de tiempo
| Fecha | Documento | Qué cambió |
|---|---|---|
| 2026-05-17 | Acta de constitución (docx) | Aprobación por el Comité de Transformación Digital. Presupuesto 3.300.000.000 COP. Inicio 2026-05-27, cierre 2027-04-27. Patrocinador Óscar Ramírez, gerente Javier Hoyos. |
| 2026-05-17 | Cronograma v1 (csv) | Línea base: 4 hitos, último (piloto) 2027-03-20. |
| 2026-09-26 | Cronograma v3 (xlsx) | Piloto vigente pasa a 2027-08-10; la línea base queda en 2027-03-20. Sin motivo escrito. No existe v2 en la carpeta. |
| 2026-09-26 | Informe de avance | Declara verde, 75 %. Entrega del proveedor pendiente de aceptación; prueba de carga no alcanzó el umbral y se repite. |
| 2026-10-05 | Solicitud de cambio CC-01 | Ampliación de alcance, +23 días, +46.000.000 COP. "Autorizada por el comité", sin fecha ni acta. |
| 2026-10-13 | Solicitud de cambio CC-02 | Ampliación de alcance, +120 días, +240.000.000 COP. "Autorizada por el comité", sin fecha ni acta. |

### Replanificaciones
| Nº | Fecha | Fecha de cierre nueva | Motivo declarado | Documento que la aprobó |
|---|---|---|---|---|
| 1 (cronograma v3) | 2026-09-26 | 2027-08-10 | Sin motivo documentado | Ninguno |

CC-01 (23 días) y CC-02 (120 días) suman los 143 días del corrimiento, pero ambas son posteriores al v3 y ninguna dejó línea base nueva. El v3 contiene un movimiento que sus propios sustentos todavía no habían pedido.

### Gobierno
| Fecha | Qué cambió | Documento |
|---|---|---|
| — | Ningún cambio de patrocinador, gerente o comité en los documentos leídos | — |

Nota: la autoridad y la fase del proyecto no aparecen en ningún documento. Y las dos autorizaciones del comité no tienen fecha ni acta, de modo que no hay dónde ver quién decidió.

### Compromisos que se repitieron
| Doliente | Qué | Veces | Fechas prometidas |
|---|---|---|---|
| — | No hay minutas ni transcripciones en la carpeta, así que no hay compromisos que seguir | — | — |

### Desde cuándo lo declarado no se sostiene
Desde el 2026-08-09, fecha del hito "Diseño funcional aprobado": figura como cerrado/cumplido y no hay ningún documento que lo evidencie. Lo que se siguió reportando: el 2026-09-26, verde y 75 %, cuando el plan sostiene entre 25 y 50 % (1 de 4 hitos cumplido). Después de esa fecha no hay otro informe de estado; solo las dos solicitudes de cambio.

Un matiz a verificar: el informe dice que el componente de integración está "pendiente de aceptación", y la ficha lo cuenta como entregado/aceptado sin evidencia. Falta el documento de recibo para saber cuál es el caso.

### Lecciones ancladas a un hecho
- El corrimiento de 143 días figura en el cronograma v3 del 2026-09-26, nueve días antes de la primera solicitud que lo justifica (CC-01, 2026-10-05). Efecto: el informe verde del mismo día se emitió con el atraso ya en el plan.
- Ni el v3 ni CC-01/CC-02 dejan línea base nueva ni acta de decisión. Efecto: hoy el atraso solo se ve comparando con el v1.
- El cronograma v1 (fechado 2026-05-17) trae un hito "cerrado" cuya fecha es 2026-08-09 y otros "en curso": no puede reflejar el estado de mayo. Efecto: no se puede tomar la fecha del archivo como la de su contenido; conviene confirmar su versión original.

### Lo que no sé
Por qué se replanificó, quién aprobó el v3, cuándo y con qué acta decidió el comité las dos solicitudes, y dónde está el v2. Esto no atribuye intención a nadie: sirve para tener esa conversación con datos.

Puedo llevar esta historia al cierre del proyecto o al comité del 2026-10-22, que tiene una decisión pendiente: dar base a CC-01 y CC-02.

**Pie de rigor:** cifras copiadas de `portafolio.py compute` (2026-10-15); cada dato sale de los 6 documentos citados; Criterio produce borradores, la verificación es suya.
