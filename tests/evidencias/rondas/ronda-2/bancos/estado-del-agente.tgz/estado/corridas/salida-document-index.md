## Carpeta al 2026-10-15

**Documentos:** 75 · **Sin cambio:** 75 · **Hay que releer:** 0

### Cambió el contenido
Ninguno.

### Solo se reguardó
Ninguno.

### Renombrado o movido
Ninguno.

### Ya no está
Ninguno.

### Citas que dejaron de resolver
| Proyecto | Campo | Documento citado |
|---|---|---|
| PRY-206 | identity (code, name, sponsor, manager, committee, product), plan (start_date, end_date), money.approved — 9 campos | 00-gobierno/2025-06-02-acta-constitucion.md |
| PRY-206 | commitments[0..2] (who, what, due_date) — 9 campos | 2026-10-15-notas-reunion.txt |

Total: 18 citas, todas de PRY-206. Los dos archivos citados SÍ existen en la carpeta
(PRY-206-billetera-y-qr/00-gobierno/2025-06-02-acta-constitucion.md y
PRY-206-billetera-y-qr/2026-10-15-notas-reunion.txt); el índice no los resuelve, probablemente
porque la ficha los cita sin el prefijo de la carpeta del proyecto. No se verificó la causa
abriendo la ficha; no se corrigió nada.

### Formatos que no se pudieron leer
Ninguno reportado por el índice.

### Siguiente paso
Nada que releer: no hay barrido que ofrecer. Queda ofrecer revisar las citas de la ficha de PRY-206, una por una, mostrando el cambio.
