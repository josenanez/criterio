Fuentes: las 13 fichas de `estado/records/` (extraídas de los informes de avance, actas de constitución y comités, citados en cada fila), las minutas de comité de PRY-199, 200, 201, 202, 203, 204, 206, 208 y 210, y las notas de reunión de PRY-206 del 2026-10-15. Escala de valoración: no hay una definida en la configuración; se usaría alta/media/baja, y ningún ítem trae probabilidad ni impacto, así que no los relleno.

## RAID — Portafolio al 2026-10-15
6 riesgos · 0 supuestos · 14 incidencias · 13 dependencias (33 ítems en 13 proyectos)
33 sin doliente · 33 sin fecha · 0 con movimiento medible (ninguna ficha trae fecha de último movimiento) · 1 no registrado formalmente

**Id.** Los Id son de esta salida (`código-Rnn`), porque el registro de origen no numera sus ítems.

### Necesitan decisión ahora
| Id | Tipo | Qué | Doliente | Desde | Por qué sube |
|---|---|---|---|---|---|
| PRY-199-R01, PRY-201-R06, PRY-205-R16, PRY-207-R21 | dependencia | Calendario de liberaciones del core (PRY-199, 201, 205, 207) | sin doliente | sin fecha | Afecta a varios proyectos del portafolio y a ninguno le consta una contraparte; ningún acta declara la dependencia ni el código del proyecto del que depende |
| PRY-202-R10, PRY-207-R22, PRY-209-R29, PRY-210-R31, PRY-211-R32 | dependencia | El proveedor no ha confirmado la fecha de la última entrega (PRY-202, 207, 209, 210, 211) | sin doliente | sin fecha | Doliente fuera del proyecto sin respuesta registrada; cinco proyectos con la misma exposición |
| PRY-206-R20 | dependencia | El proveedor podría no llegar con el equipo completo a la siguiente fase (PRY-206) | sin doliente | 2026-10-15 | Dicho en reunión, nadie lo anotó; el gerente decide si lo formaliza (ver abajo) |
| PRY-200-R05, PRY-207-R23 | incidencia | La prueba de carga no alcanzó el umbral pactado y se repite (PRY-200, 207) | sin doliente | 2026-10-10 (PRY-200) · 2026-09-26 (PRY-207) | La de PRY-207 es la incidencia abierta más antigua del portafolio (19 días) y no tiene doliente |
| PRY-204-R15 | incidencia | Hallazgo de seguridad en la revisión de arquitectura (PRY-204) | sin doliente | 2026-10-12 | Incidencia sin doliente ni fecha; el informe no dice qué decisión pide |

No puedo afirmar que algún ítem lleve «más de dos períodos sin movimiento»: las fichas no registran cuándo se movió cada uno, solo cuándo apareció en un informe. Esa señal queda sin medir.

### Detectados en reuniones, no registrados formalmente
| Qué | Tipo | Dicho en | Fecha |
|---|---|---|---|
| El proveedor podría no llegar con el equipo completo para la siguiente fase («nadie lo anotó como riesgo») | dependencia (proveedor; la ficha lo traía como riesgo) | PRY-206 · `2026-10-15-notas-reunion.txt` | 2026-10-15 |

Es el único. Las otras nueve minutas de comité (PRY-199, 200, 201, 202, 203, 204, 206 del 10-12, 208 y 210) solo traen asistentes, temas «Avance» y «Compromisos», y una tabla de compromisos: no dicen nada de riesgos. Los compromisos vencidos o sin fecha de esas minutas son materia de `/pm-commitments`, no de este registro.

### Sin doliente o sin fecha
Los 33 ítems carecen de doliente y de fecha. Se reporta como hallazgo y no se rellena. Detalle por ítem en el registro completo (columnas Doliente y Fecha en «—»).

### Reclasificados (y por qué)
| Id | Estaba | Pasa a | Por qué |
|---|---|---|---|
| PRY-199-R01 | riesgo | dependencia | Depende de un tercero (el calendario del core); no es incierto sino ajeno |
| PRY-201-R06 | riesgo | dependencia | Depende de un tercero (el calendario del core); no es incierto sino ajeno |
| PRY-201-R07 | riesgo | dependencia | Depende de la disponibilidad de un equipo ajeno al proyecto |
| PRY-202-R10 | riesgo | dependencia | Depende de un proveedor externo que no ha confirmado |
| PRY-205-R16 | riesgo | dependencia | Depende de un tercero (el calendario del core); no es incierto sino ajeno |
| PRY-206-R20 | riesgo | dependencia | Depende de un proveedor externo |
| PRY-207-R21 | riesgo | dependencia | Depende de un tercero (el calendario del core); no es incierto sino ajeno |
| PRY-207-R22 | riesgo | dependencia | Depende de un proveedor externo que no ha confirmado |
| PRY-208-R25 | riesgo | dependencia | Depende de la disponibilidad de un equipo ajeno al proyecto |
| PRY-209-R28 | riesgo | dependencia | Depende de la disponibilidad de un equipo ajeno al proyecto |
| PRY-209-R29 | riesgo | dependencia | Depende de un proveedor externo que no ha confirmado |
| PRY-210-R31 | riesgo | dependencia | Depende de un proveedor externo que no ha confirmado |
| PRY-211-R32 | riesgo | dependencia | Depende de un proveedor externo que no ha confirmado |

Se quedan como riesgo: concentración del conocimiento en una persona (PRY-200, 202, 204) y cambio regulatorio en discusión (PRY-203, 206, 208). Se quedan como incidencia las que ya ocurrieron (prueba de carga, rotación del desarrollador, hallazgo de seguridad, historias fuera del sprint, salida reprogramada). No encontré ningún supuesto registrado ni dicho en los documentos; no invento uno.

### Dependencias en riesgo
| Id | Depende de | Confirmada | Qué pasó |
|---|---|---|---|
| Las 13 dependencias (ver registro) | Ninguna lleva código de proyecto: son «el core», «el proveedor» o «el equipo de seguridad» | No: declaradas, no acordadas; ningún documento muestra confirmación de la contraparte | Las 13 actas de constitución dicen «Ninguna declarada» en dependencias, aunque los informes sí las reportan |

No puedo hacer el cruce de portafolio: sin código de proyecto no sé si «el core» es PRY-201 (Core de depósitos), y no lo asumo. Lo que sí consta: PRY-200, 202, 203, 207, 208 y 210 tienen cronograma posterior a la v1 (movieron fechas); PRY-199, 204, 205 y 211 reprogramaron la salida o tienen historias fuera por el core sin cronograma que lo refleje. Si el gerente confirma de qué proyecto depende cada una, el cruce se hace.

### Registro completo
| Id | Tipo | Qué | Prob. | Impacto | Doliente | Fecha | Último movimiento | Fuente |
|---|---|---|---|---|---|---|---|---|
| PRY-199-R01 | dependencia ⟲ | Dependencia del calendario de liberaciones del core | — | — | — | — | — | 2026-10-13-informe-avance.md |
| PRY-199-R02 | incidencia | Dos historias quedaron fuera del alcance del sprint por dependencia con el core (desde 2026-10-13) | — | — | — | — | — | 2026-10-13-informe-avance.md |
| PRY-199-R03 | incidencia | Se reprogramó la salida por ventana de cambio de operaciones, pero no hay cronograma posterior a la v1 que lo refleje (desde 2026-10-13) | — | — | — | — | — | 2026-10-13-informe-avance.md |
| PRY-200-R04 | riesgo | Concentración del conocimiento en una sola persona | — | — | — | — | — | 2026-10-10-informe-avance.md |
| PRY-200-R05 | incidencia | La prueba de carga no alcanzó el umbral pactado y se repite (desde 2026-10-10) | — | — | — | — | — | 2026-10-10-informe-avance.md |
| PRY-201-R06 | dependencia ⟲ | Dependencia del calendario de liberaciones del core | — | — | — | — | — | 2026-10-04-informe-avance.pdf |
| PRY-201-R07 | dependencia ⟲ | Disponibilidad del equipo de seguridad para la revisión final | — | — | — | — | — | 2026-10-04-informe-avance.pdf |
| PRY-201-R08 | incidencia | El equipo perdió dos semanas por rotación de un desarrollador clave (desde 2026-10-04) | — | — | — | — | — | 2026-10-04-informe-avance.pdf |
| PRY-202-R09 | riesgo | Concentración del conocimiento en una sola persona | — | — | — | — | — | 2026-10-14-informe-avance.md |
| PRY-202-R10 | dependencia ⟲ | El proveedor no ha confirmado la fecha de la última entrega | — | — | — | — | — | 2026-10-14-informe-avance.md |
| PRY-202-R11 | incidencia | Salida reprogramada por ventana de cambio del área de operaciones (desde 2026-10-14) | — | — | — | — | — | 2026-10-14-informe-avance.md |
| PRY-202-R12 | incidencia | Dos historias fuera del sprint por dependencia con el core (desde 2026-10-14) | — | — | — | — | — | 2026-10-14-informe-avance.md |
| PRY-203-R13 | riesgo | Cambio regulatorio en discusión que puede mover el alcance | — | — | — | — | — | 2026-10-03-informe-avance.md |
| PRY-204-R14 | riesgo | Concentración del conocimiento en una sola persona | — | — | — | — | — | 2026-10-12-informe-avance.pdf |
| PRY-204-R15 | incidencia | Hallazgo de seguridad en la revisión de arquitectura (desde 2026-10-12) | — | — | — | — | — | 2026-10-12-informe-avance.pdf |
| PRY-205-R16 | dependencia ⟲ | Dependencia del calendario de liberaciones del core | — | — | — | — | — | 2026-10-04-informe-avance.pdf |
| PRY-205-R17 | incidencia | Dos historias quedaron fuera del alcance del sprint por dependencia con el core (desde 2026-10-04) | — | — | — | — | — | 2026-10-04-informe-avance.pdf |
| PRY-205-R18 | incidencia | Se reprogramó la salida por ventana de cambio del área de operaciones; no hay cronograma que lo refleje (desde 2026-10-04) | — | — | — | — | — | 2026-10-04-informe-avance.pdf |
| PRY-206-R19 | riesgo | Cambio regulatorio en discusión que puede mover el alcance | — | — | — | — | — | 2026-10-04-informe-avance.pdf |
| PRY-206-R20 | dependencia ⟲ | El proveedor podría no llegar con el equipo completo para la siguiente fase (dicho en reunión, nadie lo registró) | — | — | — | — | — | 2026-10-15-notas-reunion.txt |
| PRY-207-R21 | dependencia ⟲ | Dependencia del calendario de liberaciones del core | — | — | — | — | — | 2026-09-26-informe-avance.md |
| PRY-207-R22 | dependencia ⟲ | El proveedor no ha confirmado la fecha de la última entrega | — | — | — | — | — | 2026-09-26-informe-avance.md |
| PRY-207-R23 | incidencia | La prueba de carga no alcanzó el umbral pactado y se repite (desde 2026-09-26) | — | — | — | — | — | 2026-09-26-informe-avance.md |
| PRY-208-R24 | riesgo | Cambio regulatorio en discusión que puede mover el alcance | — | — | — | — | — | 2026-10-11-informe-avance.md |
| PRY-208-R25 | dependencia ⟲ | Disponibilidad del equipo de seguridad para la revisión final | — | — | — | — | — | 2026-10-11-informe-avance.md |
| PRY-208-R26 | incidencia | El equipo perdió dos semanas por rotación de un desarrollador clave (desde 2026-10-11) | — | — | — | — | — | 2026-10-11-informe-avance.md |
| PRY-208-R27 | incidencia | Dos historias quedaron fuera del alcance del sprint por dependencia con el core (desde 2026-10-11) | — | — | — | — | — | 2026-10-11-informe-avance.md |
| PRY-209-R28 | dependencia ⟲ | Disponibilidad del equipo de seguridad para la revisión final | — | — | — | — | — | 2026-10-04-informe-avance.pdf |
| PRY-209-R29 | dependencia ⟲ | El proveedor no ha confirmado la fecha de la última entrega | — | — | — | — | — | 2026-10-04-informe-avance.pdf |
| PRY-209-R30 | incidencia | El equipo perdió dos semanas por rotación de un desarrollador clave (desde 2026-10-04) | — | — | — | — | — | 2026-10-04-informe-avance.pdf |
| PRY-210-R31 | dependencia ⟲ | El proveedor no ha confirmado la fecha de la última entrega | — | — | — | — | — | 2026-10-10-informe-avance.md |
| PRY-211-R32 | dependencia ⟲ | El proveedor no ha confirmado la fecha de la última entrega | — | — | — | — | — | 2026-10-07-informe-avance.md |
| PRY-211-R33 | incidencia | Se reprogramó la salida por ventana de cambio del área de operaciones; no hay cronograma que lo refleje (desde 2026-10-07) | — | — | — | — | — | 2026-10-07-informe-avance.md |

⟲ = reclasificado. «—» = el documento no lo dice.

## Después
Subiría a comité (2026-10-22) con la decisión formulada: (1) quién es el doliente del calendario del core y de qué proyecto depende, para PRY-199, 201, 205 y 207; (2) quién gestiona con el proveedor la fecha de última entrega en PRY-202, 207, 209, 210 y 211. Para el resto propongo doliente, sin asignarlo: el gerente de cada proyecto (los nombres están en las fichas) como candidato natural. Es una propuesta; la asignación es de ustedes.

---
**Pie de rigor.** Salen de documentos: lo reportado en informes, actas y minutas, citado por ítem. No sé: qué se habló fuera de esos documentos, si algún ítem se movió desde su aparición, ni si hay dolientes o mitigaciones fuera de la ficha. No he modificado las fichas ni asignado nada. Criterio produce borradores de trabajo, no decisiones; la verificación es suya.