Sale de la ficha `estado/records/PRY-210.json` (actualizada el 2026-10-15) y de `compute` con corte al 2026-10-15.

## PRY-210 Portal de proveedores — estado al 2026-10-15

**Declara el gerente (Óscar Ramírez):** verde · 39% · al 2026-10-10 (5 días; la declaración está vigente)
**Sustento documental:** contradicho. La alerta `declared_vs_evidence` está activa; no hay ningún campo de la ficha marcado como evidencia (0 evidencia, 0 declaración, 14 sin marcar).
**Lo que el semáforo no explica:**
- `variance_time`: 22 días, 12.0% contra la línea base original (umbral 10%).
- `progress_vs_plan`: el gerente declara 39% y el plan sostiene 100% (4 de 4 hitos cumplidos); diferencia de 61.0 puntos.
- `milestone_met_without_evidence`: los 4 hitos figuran como cumplidos y ninguno trae evidencia.
- `rebaseline_unauthorized`: la línea base se movió 22 días y ninguno está autorizado.

**Último documento:** 2026-10-13 · **Última reunión:** 2026-10-13 (comité semanal). Silencio: 2 días. Este proyecto no está en silencio; el problema es lo que dicen los documentos, no que falten.

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2025-12-02 | 2025-12-24 | +22 días / 12.0% contra la original; 0 contra la vigente |
| Presupuesto | sin línea base original de costo en la ficha | 2.400.000.000 COP aprobado | sin dato contra original. Proyección 2.498.619.894 COP: 4.1% sobre lo aprobado |

Replanificaciones: 1. La v2 del cronograma se aprobó el 2026-10-10 y lleva el motivo `not_found` (no hay motivo declarado). La solicitud CC-01 (2026-10-08) pide +22 días y 44.000.000 COP, y sigue pendiente, sin decisión ni decisor.

Dinero (COP): comprometido 1.636.053.902 (68.2%), ejecutado 456.513.809 (19.0%), disponible real 763.946.098.

### Hitos
| Hito | Base | Vigente | Estado | Evidencia |
|---|---|---|---|---|
| Diseño funcional aprobado | 2025-07-17 | 2025-07-17 | cumplido (declarado) | ninguna |
| Ambiente de pruebas certificado | 2025-09-01 | 2025-09-01 | cumplido (declarado) | ninguna |
| Integración con el core | 2025-10-17 | 2025-10-17 | cumplido (declarado) | ninguna |
| Piloto con usuarios internos | 2025-12-02 | 2025-12-24 | cumplido (declarado) | ninguna |

### Dónde no coincide
- **Verde frente a lo medido.** El informe de avance del 2026-10-10 dice verde y 39%. Esa misma fecha, el cronograma v2 (2026-10-10) marca los 4 hitos como cumplidos, lo que equivale a 100%. Las dos cifras salen de documentos del mismo día y no pueden ser ciertas a la vez.
- **Cumplidos sin evidencia.** Los 4 hitos figuran como cumplidos en el cronograma v2, pero ninguno tiene evidencia de cumplimiento. El plazo vencido más antiguo es de hace 455 días y el más reciente de hace 295.
- **Línea base movida sin autorización.** El cronograma v2 corrió el cierre 22 días (del 2025-12-02 al 2025-12-24) el 2026-10-10, sin motivo. El cambio que justificaría esos días, CC-01, sigue pendiente. Por tanto 22 días de movimiento y 0 autorizados.
- **Cierre ya vencido.** La fecha vigente de cierre (2025-12-24) quedó atrás hace casi 10 meses, y el proyecto se declara en 39% y en verde. Lo anoto como hecho de las fechas; la ficha no explica la causa.

### Abierto
**Riesgos e incidencias sin movimiento:** un riesgo («el proveedor no ha confirmado la fecha de la última entrega») sin probabilidad, impacto, dueño, fecha ni último movimiento, así que no se pueden contar días sin movimiento. Incidencias: ninguna registrada.
**Compromisos vencidos:** ninguno. Hay uno sin fecha: Rubén Cárdenas, «Entregar el punto 10», dicho en el comité del 2026-10-13. Sin fecha no puede vencer, y por eso nunca saldrá como vencido.
**Dependencias sin confirmar:** ninguna registrada. Observo que el riesgo anterior apunta a un proveedor y la ficha no tiene proveedores (`vendors` vacío), así que no hay entregables contractuales contra los cuales contrastarlo.

### Sin dato
- `identity.product`, `identity.authority` e `identity.phase`: no encontrados.
- Presupuesto original de línea base: no hay, por eso no se calcula desviación de costo contra la original.
- Motivo de la replanificación v2 y decisión de CC-01.
- Campos de identidad y plan con fuente del acta del 2025-05-22 (17 meses, por encima del umbral de 12): código, nombre, área, producto, patrocinador, fecha de inicio y exclusiones.

### Qué sigue
Hay desviación por encima del umbral (12.0% frente a 10%) y una línea base movida sin autorización. Puedo preparar el punto de comité (`/steering-pack`) y la solicitud de cambio formal para CC-01. No los he generado.

---
criterio-portfolio 0.3.8 · ficha aplicada: PRY-210, actualizada el 2026-10-15 · campos inciertos: product, authority, phase (no encontrados) y 7 campos de identidad/plan con más de 12 meses · Términos 1.1 aceptados por José Francisco Ñáñez el 2026-10-15: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.8
