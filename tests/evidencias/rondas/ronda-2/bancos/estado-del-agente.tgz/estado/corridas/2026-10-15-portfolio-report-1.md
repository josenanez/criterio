# Corrida del 2026-10-15 · portfolio-report

13 proyectos · 75 documentos, 0 releídos y 75 sin cambio · 41 s · 67 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 24 |
| `progress_vs_plan` | 6 |
| `vendor_accepted_without_evidence` | 6 |
| `declared_vs_evidence` | 6 |
| `variance_time` | 4 |
| `commitment_undated` | 4 |
| `variance_cost` | 4 |
| `change_without_baseline` | 4 |
| `commitment_overdue` | 3 |
| `rebaseline_unauthorized` | 2 |
| `vendor_deliverable_late` | 2 |
| `vendor_invoiced_over_accepted` | 1 |
| `pm_vs_pmo` | 1 |

El informe quedó en `/home/claude/banco/ronda-2/bancos/espacio/reportes/index.html`.

Primera instantánea: sin delta. 6 proyectos en verde contradichos por la evidencia; PRY-206 con fecha de fin contradictoria y facturación por encima de lo aceptado.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

# Portafolio — 2026-10-15
13 proyectos · 11 con hallazgos (67 señales) · último barrido 2026-10-15 (13 fichas en `estado/records/`, todas del mismo día)

Términos vigentes: v0.3.8, aceptados por José Francisco Ñáñez el 2026-10-15.

## Qué cambió desde la corrida anterior
Sin cambios desde la corrida anterior. La única instantánea es la de hoy (2026-10-15), así que este informe es el punto de partida: no hay delta real contra el que medir.

## Contradicciones abiertas
| Proyecto | Campo | Dice | Fuente | Dice también | Fuente |
|---|---|---|---|---|---|
| PRY-206 Billetera y QR | fin del plan | 2026-09-25 | 10-plan/2025-06-02-cronograma-v1.xlsx | 2026-11-11 | 00-gobierno/2025-06-02-acta-constitucion.md |

Las dos fuentes tienen la misma fecha (2025-06-02): ninguna es más reciente, así que el script no puede decir cuál prevalece. Lo decide una persona.

## Hitos vencidos sin evidencia
Ninguno vencido y abierto. Sí hay hitos **declarados cumplidos sin evidencia** en 10 proyectos (PRY-200, 201, 202, 203, 204, 206, 207, 208, 209, 210; los más viejos: PRY-210, 455 días; PRY-208, 370 días; PRY-201, 337 días). Ver «Sin sustento».

## Proyectos en silencio
Vacía: ningún proyecto supera los 15 días sin documentos (el máximo es PRY-201, 11 días).

## Dependencias en riesgo
Vacía: el script no marcó ninguna dependencia rota.

## Sin sustento
Seis proyectos están declarados en verde y la evidencia los contradice (PRY-202, 203, 207, 208, 209, 210).

| Proyecto | Declara | Qué lo respalda |
|---|---|---|
| PRY-203 Open Banking | verde (2026-10-03) | Contradicho por 5 señales: compromiso vencido (17 días), hito cumplido sin evidencia, avance 25 % frente a 75–100 % que sostiene el plan, costo +13,7 %, atraso de 78 días |
| PRY-208 Motor de decisión | verde (2026-10-11) | Contradicho por 4 señales: compromiso vencido (23 días), 3 hitos sin evidencia, avance 45 % frente a 100 % del plan, costo +25,9 % |
| PRY-210 Portal de proveedores | verde (2026-10-10) | Contradicho por 4 señales: 4 hitos sin evidencia, avance 39 % frente a 100 % del plan, atraso de 22 días sin autorización |
| PRY-207 Onboarding PyME | verde (2026-09-26) | Contradicho por 3 señales: hito sin evidencia, avance 75 % frente a 25–50 % del plan, atraso de 143 días |
| PRY-202 Migración a la nube | verde (2026-10-14) | 2 hitos declarados cumplidos sin evidencia |
| PRY-209 Nómina electrónica | verde (2026-10-04) | Hito de pruebas declarado cumplido sin evidencia |

Otros desvíos de dinero y plan:
- PRY-204: costo +27,6 % (proyección 1.020,7 M contra 800 M aprobados).
- PRY-206: costo +13,0 % (7.686 M contra 6.800 M); Redes del Norte facturó 1.317,8 M y lo aceptado suma 920,1 M (diferencia 397,8 M); 2 entregables de proveedor vencidos (232 y 103 días).
- PRY-200: atraso de 98 días contra la línea base original, sin autorización.
- PRY-205, 203 y 207: cambios de control de cambios sin línea base asociada (CC-01, CC-02).

## Vacíos de información
| Proyecto | Qué falta |
|---|---|
| 13 de 13 | Autoridad de aprobación sin identificar (`authority` vacío) |
| PRY-202, 205, 208, 210 | Sin producto asociado |
| PRY-201, 204, 206, 210 | Compromisos sin fecha |
| PRY-201, 203, 207, 209 | Entregable de proveedor «delivered» sin proveedor identificado ni evidencia |

## Estado general
Los números salen de `portafolio.py compute` y no se recalcularon a mano.

| Proyecto | Declarado | Sustento | Desviación vs original | vs vigente | Replanificaciones |
|---|---|---|---|---|---|
| PRY-199 Renovación de cajeros | no consta en el cómputo | Sin señales | 0 d | 0 d | 0 |
| PRY-200 Originación digital | no consta en el cómputo | Débil (7 señales) | +98 d | 0 d | 1 |
| PRY-201 Core de depósitos | no consta en el cómputo | Débil (5 señales) | 0 d | 0 d | 0 |
| PRY-202 Migración a la nube | verde | Contradicho | +42 d | 0 d | 1 |
| PRY-203 Open Banking | verde | Contradicho | +78 d | 0 d | 1 |
| PRY-204 Débito contactless | no consta en el cómputo | Débil (4 señales) | 0 d | 0 d | 0 |
| PRY-205 Prevención de lavado | no consta en el cómputo | 1 señal | 0 d | 0 d | 0 |
| PRY-206 Billetera y QR | no consta en el cómputo | Débil (12 señales) | 0 d | 0 d | 0 |
| PRY-207 Onboarding PyME | verde | Contradicho | +143 d | 0 d | 1 |
| PRY-208 Motor de decisión | verde | Contradicho | +20 d | 0 d | 1 |
| PRY-209 Nómina electrónica | verde | Contradicho | 0 d | 0 d | 0 |
| PRY-210 Portal de proveedores | verde | Contradicho | +22 d | 0 d | 1 |
| PRY-211 Cobranza digital | no consta en el cómputo | Sin señales | 0 d | 0 d | 0 |

## Necesito que confirmes
No se genera la confirmación del mes: la sesión no tiene interfaz y nadie puede responder. Queda pendiente para la próxima corrida con persona.

## Dónde quedaron los archivos
Carpeta: `/home/claude/banco/ronda-2/bancos/espacio/reportes/` (26 páginas).
- `index.html`: vista por campo, con la cadena de evidencia completa. Para quien va a actuar.
- `decisiones.html`: vista por decisión. Para el patrocinador y el comité del 2026-10-22.
- Además, una página por proyecto, por producto, `productos.html` y `proyectos.html`.

Para el PDF se imprime el HTML desde el navegador.

---
criterio-portfolio 0.3.8 · fichas aplicadas: 13 (2026-10-15) · campos inciertos: contradicción de fecha de fin en PRY-206, 13 autoridades sin identificar, 4 proyectos sin producto · términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.8
