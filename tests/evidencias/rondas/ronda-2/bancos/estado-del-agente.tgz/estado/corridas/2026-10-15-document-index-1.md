# Corrida del 2026-10-15 · document-index

13 proyectos · 14 s · 67 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 24 |
| `progress_vs_plan` | 6 |
| `vendor_accepted_without_evidence` | 6 |
| `declared_vs_evidence` | 6 |
| `variance_time` | 4 |
| `commitment_undated` | 4 |
| `variance_cost` | 4 |
| `change_without_baseline` | 4 |
| `commitment_overdue` | 3 |
| `rebaseline_unauthorized` | 2 |
| `vendor_deliverable_late` | 2 |
| `vendor_invoiced_over_accepted` | 1 |
| `pm_vs_pmo` | 1 |

75 documentos sin cambio, 0 por releer; 18 citas de PRY-206 no resuelven aunque los archivos existen (posible prefijo de ruta); causa no verificada

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## Carpeta al 2026-10-15

**Documentos:** 75 · **Sin cambio:** 75 · **Hay que releer:** 0

### Cambió el contenido
Ninguno.

### Solo se reguardó
Ninguno.

### Renombrado o movido
Ninguno.

### Ya no está
Ninguno.

### Citas que dejaron de resolver
| Proyecto | Campo | Documento citado |
|---|---|---|
| PRY-206 | identity (code, name, sponsor, manager, committee, product), plan (start_date, end_date), money.approved — 9 campos | 00-gobierno/2025-06-02-acta-constitucion.md |
| PRY-206 | commitments[0..2] (who, what, due_date) — 9 campos | 2026-10-15-notas-reunion.txt |

Total: 18 citas, todas de PRY-206. Los dos archivos citados SÍ existen en la carpeta
(PRY-206-billetera-y-qr/00-gobierno/2025-06-02-acta-constitucion.md y
PRY-206-billetera-y-qr/2026-10-15-notas-reunion.txt); el índice no los resuelve, probablemente
porque la ficha los cita sin el prefijo de la carpeta del proyecto. No se verificó la causa
abriendo la ficha; no se corrigió nada.

### Formatos que no se pudieron leer
Ninguno reportado por el índice.

### Siguiente paso
Nada que releer: no hay barrido que ofrecer. Queda ofrecer revisar las citas de la ficha de PRY-206, una por una, mostrando el cambio.
