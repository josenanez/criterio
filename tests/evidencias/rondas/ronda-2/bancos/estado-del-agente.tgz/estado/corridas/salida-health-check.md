## Diagnóstico · PRY-206 Billetera y QR · 2026-10-15

**Leí:** 14 documentos de la carpeta del proyecto · del 2025-05-23 al 2026-10-15 (la `ficha-pm.json` no trae fecha) · formatos: 5 .md, 5 .pdf, 1 .docx, 1 .xlsx, 1 .txt, 1 .json. Busqué también menciones del proyecto en las demás carpetas del portafolio: no hay ninguna minuta ajena que hable de PRY-206 (solo aparecen nombres compartidos, ver Gobierno).
**No pude leer:** nada quedó ilegible. Los PDF, el .docx y el .xlsx los leí en su texto convertido (caché), no en el original; si una tabla o imagen no sobrevivió a la conversión, no la vi.
**Aviso de método:** los datos del informe de avance y de la `ficha-pm.json` los escribe quien reporta; los traté como *declaración*, no como prueba. Los 42 datos de la ficha de estado de este proyecto aún no vienen marcados como evidencia o declaración (0 / 0 / 42 sin marcar); esa separación la hice a mano aquí.

### Dictamen
**Sostenido:** 8 afirmaciones · **Sin sustento:** 7 · **Contradicho:** 4

Desde esta carpeta se puede afirmar que el proyecto existe con patrocinador, gerente y presupuesto aprobado de 6.800.000.000 COP, que el proveedor Consultora Andina (CT-279) tiene dos entregables con acta de recibo y una factura que coincide con ellos, y que el gerente declara el proyecto en rojo. No se puede afirmar en qué fase está: el cronograma lo muestra con 5 de 5 hitos cerrados, el informe de avance dice 31 %, y ninguno de los dos documentos explica al otro. Tampoco se puede afirmar la fecha de cierre (hay dos), ni que el proveedor Redes del Norte entregó algo: no hay ni un acta de recibo suya y aun así tiene una factura radicada por 1.317.839.587 COP.

### Gobierno
| | Qué dice el documento | Fuente |
|---|---|---|
| Patrocinador | Natalia Ospina | `00-gobierno/2025-06-02-acta-constitucion.md` |
| Gerente | Camilo Beltrán (también figura como gerente en el acta de PRY-205) | acta de constitución; `20-seguimiento/2026-10-04-informe-avance.pdf` |
| Autoridad declarada | **No declarada en ningún documento.** El acta no define qué puede aprobar el gerente | — |
| Comité | Comité de Arquitectura. La reunión del 2026-10-12 lista dos temas («Avance», «Compromisos»), dos asistentes (Camilo Beltrán, Natalia Ospina) y ninguna decisión | acta; `30-reuniones/2026-10-12-comite-semanal.md` |

Sin autoridad declarada no hay desviación aprobada: lo que hay son fechas que alguien escribió. Además, el acta es genérica: alcance «Componente 1, 2, 3», exclusión «Lo que otro proyecto cubre», dependencias «Ninguna declarada», área dueña Banca Hipotecaria para un producto de pagos QR. Y el contrato CT-279 se firmó el 2025-05-23 y el CT-725 el 2025-06-06, ambos con fecha anterior o cercana a la aprobación del acta (2025-06-02) y del inicio (2025-06-12): el acta no dice si esos contratos estaban dentro del presupuesto aprobado.

### Contra el plan
- **Línea base original:** `10-plan/2025-06-02-cronograma-v1.xlsx`, aprobada el 2025-06-02, cierre 2026-09-25.
- **Vigente:** igual a la original. Cero replanificaciones, cero solicitudes de cambio en la carpeta, desviación en tiempo 0 días (cifra del script, calculada sobre las fechas del propio cronograma).
- **El cierre tiene dos fechas:** el cronograma dice 2026-09-25 y el acta dice 2026-11-11. Ambas con fecha 2025-06-02; ninguna es más nueva. No hay documento que diga cuál rige.
- **Esa desviación de 0 días no es confiable.** El cronograma mantiene «Diseño funcional aprobado» en 2025-09-14 como cerrado, pero su acta de recibo es del 2026-10-11. «Salida a producción» figura para 2026-09-25 y su acta es del 2026-10-04. Es decir, la salida a producción se recibió una semana *antes* que el diseño funcional que debía precederla. El script no calcula días entre acta y fecha de plan, así que no pongo la cifra.

### Hitos vencidos sin evidencia
Ninguno figura como vencido; los 5 están declarados cerrados. Tres están cerrados sin ningún documento que lo pruebe:

| Hito | Fecha | Días desde la fecha | Qué documento se esperaría |
|---|---|---|---|
| Ambiente de pruebas certificado | 2025-12-17 | 302 | Acta de recibo o certificación del ambiente |
| Integración con el core | 2026-03-21 | 208 | Acta de recibo o informe de pruebas de integración |
| Piloto con usuarios internos | 2026-06-23 | 114 | Acta de cierre del piloto o resultados |

Los entregables de proveedor vencidos y sin cerrar son otros dos:
- Parametrización del tarifario (CT-279, Consultora Andina), vencido el 2026-07-04, **103 días**, pendiente.
- Bolsa de horas de desarrollo (CT-725, Redes del Norte), vencido el 2026-02-25, **232 días**, pendiente según el cálculo del script (el contrato dice «en curso»).

### Dinero
Fuente: informe de avance del 2026-10-04 (declaración; no hay en la carpeta un reporte contable que lo respalde).

| Aprobado | Comprometido | Ejecutado | Proyección | Disponible real |
|---|---|---|---|---|
| 6.800.000.000 COP | 3.979.137.385 COP (58,5 %) | 2.925.165.723 COP (43,0 %) | 7.686.267.486 COP (13,0 % sobre lo aprobado; umbral 10 %) | 2.820.862.615 COP |

La proyección pasa el umbral de desviación en costo y no hay solicitud de cambio ni aprobación del sobrecosto. Se ha ejecutado el 43,0 % del dinero con un avance declarado de 31 %.

**Proveedores**
- **Consultora Andina (CT-279):** facturado 762.675.710 COP; aceptado con acta 762.675.710 COP. Cuadra.
- **Redes del Norte (CT-725):** facturado 1.317.839.587 COP; aceptado según su propio contrato 920.079.190 COP (2 de 3 entregables); diferencia **397.760.397 COP** facturada sin entregable aceptado. Y ese «aceptado» no tiene ni un acta: con evidencia, lo respaldado es 0 COP. El contrato condiciona el pago a «acta de recibo firmada por el gerente».

### Lo que se dijo y nadie registró
- **Riesgo, 2026-10-15 (notas de reunión):** «el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo». No dice cuál de los dos proveedores, ni dueño, ni probabilidad, ni impacto. No existe registro RAID en la carpeta.
- **Riesgo regulatorio, informe 2026-10-04:** «cambio regulatorio en discusión que puede mover el alcance». Está en el informe pero sin dueño, probabilidad, impacto ni fecha.
- **Dependencia no declarada:** el acta dice «Ninguna declarada», pero el informe habla de una aprobación regulatoria que estuvo pendiente un trimestre y hay dos proveedores con entregables en la ruta.
- **Compromisos (3):**
  - Liliana Torres, «entregar el punto 21»: se acordó para 2026-10-05 (aparece en la minuta del 2026-10-12, es decir ya vencido al registrarse) y se reprograma el 2026-10-15 para 2026-10-29. Una reprogramación; el umbral de alerta es 3. «Punto 21» no resuelve a ningún documento de la carpeta, y Liliana Torres no figura entre los asistentes del comité del 12.
  - Laura Vélez, «mandar el ajuste del presupuesto la otra semana»: **sin fecha** (relativa). Señal abierta. Es coherente con la proyección sobre lo aprobado, pero no hay solicitud de cambio.
  - Óscar Ramírez, «revisión con el proveedor», 2026-10-25: no dice qué proveedor.
- Ninguna de estas cosas está en un registro; solo en minutas o notas.

### Contradicho
| Afirmación | Documento A | Documento B |
|---|---|---|
| Avance 31 % | Informe 2026-10-04: «Avance reportado: 31 %», estado Rojo | Cronograma v1: 5 de 5 hitos cerrados (el plan respalda 100 %); acta de recibo «Salida a producción» del mismo 2026-10-04. Brecha de 69 puntos |
| Fecha de cierre del proyecto | Acta de constitución: 2026-11-11 | Cronograma v1: 2026-09-25 (ambos del 2025-06-02) |
| Fechas vigentes = línea base, sin atraso | Cronograma: «Diseño funcional aprobado» 2025-09-14, «Salida a producción» 2026-09-25, ambos cerrados, sin replanificación | Actas de recibo: diseño funcional 2026-10-11; salida a producción 2026-10-04 (antes que el diseño) |
| Factura FV-1725 por 1.317.839.587 COP | Factura FV-1725 (Redes del Norte), radicada 2026-09-10 | CT-725: 2 entregables «recibidos» = 920.079.190 COP; diferencia de 397.760.397 COP. Sin acta de recibo alguna |

Tensión que no puedo dictaminar: el informe dice «el proveedor entregó el componente de integración, pendiente de aceptación» mientras el hito «Integración con el core» está cerrado desde 2026-03-21. No dice que sea el mismo componente.

### Sin sustento
- Ambiente de pruebas certificado, cerrado: sin documento.
- Integración con el core, cerrado: sin documento (ver la tensión de arriba).
- Piloto con usuarios internos, cerrado: sin documento.
- CT-725, licenciamiento del motor «recibido»: sin acta. El campo «Estado» de un contrato firmado en 2025-06-06 no puede probar una recepción posterior.
- CT-725, parametrización del tarifario «recibido»: sin acta, mismo motivo.
- CT-725, bolsa de horas «en curso» (el script la computa como pendiente): sin acta ni informe.
- Cifras de dinero del informe (comprometido, ejecutado, proyección): sin reporte contable ni de compras que las respalde.

Es también el bloque donde caería casi cualquier cosa que el informe afirme sobre calidad o resultado: el criterio de éxito («Billetera y QR en producción y medido») no tiene ninguna medición en la carpeta.

### Lo que esta carpeta no permite saber
- **Si el gerente puede aprobar cambios.** Sin autoridad declarada, no se puede llamar «aprobado» ningún cambio de fecha o presupuesto, ni el ajuste que Laura Vélez prepara.
- **Cuándo cierra el proyecto.** Hay dos fechas sin documento que decida; el atraso real queda sin medir.
- **Si ambiente, integración y piloto ocurrieron.** El 100 % de avance del plan descansa en 3 hitos sin soporte y en dos actas fuera de secuencia.
- **Si Redes del Norte entregó algo.** Sin actas y con una factura que supera lo aceptado, no se puede decir si lo facturado es legítimo.
- **Cuánto se ha gastado realmente.** Hay cifras del informe, no un reporte contable; no se sabe si las dos facturas ya se pagaron.
- **Qué incluye el alcance.** «Componente 1, 2, 3» no permite saber si «salida a producción» es el proyecto terminado o un hito intermedio, que sería la forma de reconciliar 31 % con 5 de 5 hitos. Es una hipótesis mía, no un dato.
- **Qué es «el punto 21»** ni qué proveedor es «el proveedor» de las notas.

No recomiendo continuar, detener ni reestructurar: eso lo decide quien tiene la facultad. Puedo preparar las cuatro contradicciones como preguntas al gerente, una por una, o el punto de comité con la lista de lo que falta (acta de autoridad, actas de recibo de Redes del Norte y de los tres hitos, fecha de cierre vigente, registro de riesgos). El próximo comité es el 2026-10-22.

---
*Criterio PMO · criterio-portfolio 0.3.8 · términos 1.1 aceptados por José Francisco Ñáñez el 2026-10-15 · https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.8*
*Ficha aplicada: `estado/records/PRY-206.json` (actualizada 2026-10-15); este diagnóstico parte de los documentos, no de ella. Campos inciertos: `identity.authority` y `identity.phase` (no encontrados); estado, avance y fecha de corte del PM (`ficha-pm.json`) vacíos. Borrador de trabajo: la verificación contra los originales es suya.*
