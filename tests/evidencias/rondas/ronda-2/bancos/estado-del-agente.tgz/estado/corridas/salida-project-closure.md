*Fuente: salida de `portafolio.py compute` (as_of 2026-10-15) y los seis documentos de `PRY-200-originación-digital/`: acta de constitución (2025-11-02), cronogramas v1 (2025-11-02) y v2 (2026-10-10), informe de avance (2026-10-10), solicitud de cambio CC-01 (2026-10-13) y acta del comité semanal (2026-10-12). Términos vigentes, aceptados por José Francisco Ñáñez el 2026-10-15.*

## Cierre — PRY-200 Originación digital — 2026-10-15

**Veredicto: el proyecto no está en condiciones de cerrarse contra su criterio de éxito.** Hay un criterio pactado, pero ningún documento muestra que se cumplió. El propio gerente reporta el proyecto en **rojo, con 43 % de avance**, al 2026-10-10. Si alguien lo cierra hoy, se cierra por decisión y no por cumplimiento, y esa decisión no está registrada en ningún documento.

### Contra lo comprometido
**Criterio de éxito:** "Originación digital en producción y medido." (acta de constitución, 2025-11-02, sección *Criterio de éxito*). No fija umbral de medición, qué se mide ni fecha.
**Se cumplió:** **no se puede determinar; lo disponible apunta a que no.** Ningún documento dice que esté en producción ni trae una medición. El informe de avance dice que "la prueba de carga no alcanzó el umbral pactado y se repite" (informe 2026-10-10).

| Entregable comprometido | Estado | Evidencia |
|---|---|---|
| Alcance: "Componente 1, 2 y 3" | No verificable | El acta lista el alcance con nombres genéricos. No hay contra qué contrastar lo entregado. |
| Hito: Diseño funcional aprobado (línea base 2026-01-10) | Declarado "cerrado" | Sin evidencia de aprobación en la carpeta (señal `milestone_met_without_evidence`, 278 días). |
| Hito: Ambiente de pruebas certificado (2026-03-11) | Declarado "cerrado" | Sin evidencia de certificación (218 días). |
| Hito: Integración con el core (línea base 2026-05-10; vigente 2026-08-16) | Declarado "cerrado" | Sin evidencia de integración (60 días). El informe del 2026-10-10 dice que la prueba de carga se repite, lo que no concuerda con un hito cerrado. |
| Originación digital en producción y medida (criterio de éxito) | Sin evidencia | No hay documento de puesta en producción ni de medición. |

Los tres hitos están "cerrados" en el cronograma y sin soporte documental. El script calcula que el plan respalda 100 % de avance, mientras el gerente declara 43 %: una diferencia de 57 puntos. Uno de los dos números está mal, y la carpeta no dice cuál.

### Fuera de alcance final
| Qué quedó fuera | Decidido por | Cuándo |
|---|---|---|
| Acta: "Lo que otro proyecto cubre" (sin nombrar proyecto ni elemento) | Acta de constitución | 2025-11-02 |
| Recorte de alcance durante la ejecución | **Sin dato: no hay ninguna decisión registrada** | n/d |

**CC-01** (2026-10-13) pide una **ampliación** de alcance, no un recorte. Dice "Pendiente de presentación al comité" y no describe qué se amplía. El acta del comité del 2026-10-12 no la menciona.

### Números finales
Esto no son cifras finales: el proyecto sigue abierto. Son las cifras a la fecha. Se copian de `compute`.

| | Original | Vigente | Final | Desviación vs original |
|---|---|---|---|---|
| Fecha (último hito) | 2026-05-10 | 2026-08-16 | **No hay: sin cierre ni fecha real** | **+98 días (54,7 %)** |
| Fecha de cierre del acta | 2026-06-09 | n/d | n/d | Ver nota abajo |
| Presupuesto aprobado | 3.300.000.000 COP | 3.300.000.000 COP | n/d | n/d |
| Ejecutado | | | 636.458.838 COP (19,3 %) | n/d |
| Comprometido | | | 1.968.323.704 COP (59,6 %) | n/d |
| Proyección al cierre | | | 3.368.898.966 COP | **+2,1 % sobre lo aprobado** |

- **Replanificaciones: 1.** El hito "Integración con el core" pasó del 2026-05-10 al 2026-08-16 en el cronograma v2, con fecha de archivo 2026-10-10. Respecto a la vigente, la desviación es 0 días.
- **Esa replanificación no tiene autorización:** `compute` marca `rebaseline_unauthorized` con 98 días movidos, 0 autorizados y 1 cambio visto.
- **Presupuesto:** hay un solo monto aprobado. Los 196.000.000 COP de CC-01 no están aprobados (pendiente de comité), así que no mueven la línea base. La proyección de 3.368.898.966 COP ya supera en 68.898.966 COP el aprobado y no incluye esos 196.000.000 COP. Ese valor sale de restar, no de `compute`; la desviación de 2,1 % sí es la que da el script.
- **Inconsistencia en la fecha de cierre:** el acta compromete cierre el 2026-06-09, y el cronograma v1 termina en su último hito el 2026-05-10. El acta no dice cuál es la referencia, y el script usa el último hito.
- **Inconsistencia en CC-01:** dice "+98 días sobre la línea base vigente". Pero la vigente ya incluye esos 98 días respecto a la original, y `compute` da 0 días de desviación contra la vigente. No queda claro si CC-01 pide otros 98 días o busca legalizar los ya movidos. No lo decido.
- **Periodo cubierto por la fecha vigente:** el 2026-08-16 ya pasó (hace 60 días) y no hay evidencia de que el hito se cumpliera.

### RAID al cierre
No hay registro RAID en la carpeta; esto sale de los documentos disponibles.

**Materializados:** ninguno confirmado. La repetición de la prueba de carga (informe 2026-10-10) es una incidencia en curso, no un riesgo materializado y cerrado.
**No materializados:** no se puede determinar, porque no hay registro de riesgos.
**Abiertos, con doliente:**
- Riesgo "Concentración del conocimiento en una sola persona" (informe 2026-10-10): **sin doliente nombrado y sin la persona identificada**. No está cerrado.
- Incidencia: la prueba de carga no alcanzó el umbral pactado y se repite (informe 2026-10-10): **sin doliente, sin fecha de repetición, sin umbral citado**.
- Compromiso vencido: Diana Molina, "Entregar el punto 22", para el 2026-10-08, con 7 días de vencido al 2026-10-15 (acta del comité 2026-10-12). El acta no define qué es "el punto 22".
- CC-01 pendiente de comité (2026-10-13), a cargo de Óscar Ramírez como solicitante. No hay fecha de comité para tratarla.

### Lecciones
Solo entran las que se anclan a un hecho documentado.

| Qué pasó | Cuándo | Efecto | Qué haríamos distinto |
|---|---|---|---|
| El hito "Integración con el core" se movió del 2026-05-10 al 2026-08-16 en el cronograma v2, sin cambio autorizado | v2 fechado 2026-10-10 (la nueva fecha ya estaba 55 días vencida) | 98 días de desviación contra la original (54,7 %), todos sin autorización. La causa **no está documentada**. | Registrar el cambio por control de cambios antes de mover la fecha, con la causa escrita. |
| La solicitud CC-01 se redactó con fecha 2026-10-13 sobre el plan que ya llevaba el atraso, y se mide "sobre la vigente" | 2026-10-13 | No se sabe si pide 98 días nuevos o legaliza los ya movidos. | Medir siempre contra la línea base original y la vigente, indicando cuál. |
| Los tres hitos se cerraron en el cronograma sin evidencia de aprobación, certificación o integración | Fechas de hito: 2026-01-10, 2026-03-11 y 2026-05-10 (vigente 2026-08-16) | El avance declarado (43 %) y el avance que respalda el plan (100 %) difieren en 57 puntos. | Cerrar un hito solo con el documento de aceptación en la carpeta. |
| El acta fijó el alcance como "Componente 1, 2 y 3" | 2025-11-02 | Hoy no hay forma de contrastar lo entregado contra lo comprometido. | Describir el alcance con entregables verificables. |
| El acta fijó el criterio de éxito sin umbral de medición | 2025-11-02 | La prueba de carga "no alcanzó el umbral pactado", pero el umbral no está en ningún documento de la carpeta. | Fijar la métrica y el umbral en el acta. |

No incluyo una lección sobre la causa del atraso: ningún documento la explica.

### Sin dato
- Si el producto está en producción y si se midió (criterio de éxito).
- Cuál es el avance real: 43 % declarado frente a 100 % que respalda el plan.
- La causa del movimiento de 98 días del hito de integración, y quién lo autorizó (el script cuenta 0 autorizados).
- Qué amplía CC-01, y si sus 98 días son nuevos o los ya movidos.
- Qué es "el punto 22" y su estado.
- Qué otro proyecto cubre lo que el acta deja "fuera de alcance".
- Quién es la persona en quien se concentra el conocimiento.
- Autoridad y fase del proyecto (campos `identity.authority` e `identity.phase` faltantes en la ficha).
- Fuentes: de 15 datos en la ficha, 0 están marcados como evidencia y 0 como declaración; los 15 quedaron sin marcar.
- La fecha real de cierre y el presupuesto final: no existen, porque no hay cierre.

### Después
Mi propuesta es **no mover la carpeta a `archivo/` ni congelar la ficha**. Sin respuesta de la persona, tomo esa opción: el proyecto sigue en el barrido diario hasta que haya una decisión de cierre registrada, por incumplimiento o por cumplimiento. No hay acta de cierre aprobada que presentar.

**Para que pueda cerrarse:** (1) una decisión del comité sobre CC-01 y sobre los 98 días ya movidos; (2) evidencia de aprobación, certificación e integración de los tres hitos; (3) resultado de la prueba de carga repetida; (4) doliente para el riesgo de concentración y para el compromiso vencido.

---
**Rigor:** cifras derivadas copiadas de `portafolio.py compute`, salvo los 68.898.966 COP (resta de dos cifras del script). Ficha: `estado/records/PRY-200.json`. Documentos: seis, listados arriba. Se declara sin dato todo lo que ninguno sostiene. La verificación contra los originales es suya.
