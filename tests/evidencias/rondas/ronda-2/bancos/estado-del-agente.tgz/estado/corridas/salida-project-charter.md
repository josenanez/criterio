**Acta previa:** sí, del 2026-05-11 (`PRY-211-cobranza-digital/00-gobierno/2026-05-11-acta-constitucion.docx`). Términos vigentes (versión 0.3.8, aceptados por José Francisco Ñáñez el 2026-10-15). Modo: revisar.

## Acta — PRY-211 Cobranza digital
**Estado:** existe, del 2026-05-11 (aprobada por el Comité de Medios de Pago). Es la única acta; el único otro documento del proyecto es el informe de avance del 2026-10-07.

### Qué falta
| Campo | Estado | Consecuencia |
|---|---|---|
| Autoridad del gerente | **Ausente** (el acta no la menciona) | Paula Céspedes no sabe hasta qué monto ni qué cambio de alcance o fecha puede decidir sola. Hoy el proyecto proyecta 3.394.680.472 COP contra 3.300.000.000 aprobados (+94.680.472, +2,9 %) y tiene una salida reprogramada: sin autoridad declarada, ambas cosas solo pueden resolverse subiendo al comité. |
| Objetivo de negocio | **Insuficiente**: "Entregar cobranza digital para Tecnología" | Describe la solución, no el resultado de negocio. No hay forma de saber si el proyecto cumplió su propósito aunque entregue lo construido. Además, el área dueña es Tecnología y el producto asociado es "recaudos": no se dice qué mejora para recaudos. |
| Alcance | **Vacío en sustancia**: "Componente 1, 2, 3" | El acta no dice qué son los componentes. Cualquier cambio posterior no tiene contra qué compararse; el control de cambios queda sin línea base de alcance. |
| Exclusiones | **Genérica**: "Lo que otro proyecto cubre" | No nombra qué ni qué otro proyecto. No sirve para rechazar una solicitud ni para detectar un traslape con otro proyecto. |
| Patrocinador | Presente: Óscar Ramírez | — |
| Gerente | Presente: Paula Céspedes | — |
| Comité y cadencia | Comité de Medios de Pago presente; **cadencia ausente** | Sin cadencia no hay fecha en la que se espere una decisión; las decisiones pendientes no tienen fecha de revisión. |
| Supuestos y restricciones | **Ausentes** | El informe del 07-10 menciona una aprobación regulatoria que llevaba un trimestre pendiente: era un supuesto o una dependencia que nadie había escrito. |
| Dependencias | Declara "Ninguna declarada" | Contradice el informe del 07-10: hay un proveedor que no confirma la última entrega, una aprobación regulatoria y una ventana de cambio de operaciones. Tres dependencias externas reales fuera del acta. |
| Criterio de éxito | **No medible**: "Cobranza digital en producción y medido" | No dice qué métrica, qué valor ni cuándo. Tampoco **quién lo mide**. "Medido" no es un criterio. |
| Hitos principales | **Ausentes** (solo inicio 2026-05-21 y cierre 2027-04-28) | Con 25 % de avance reportado y estado rojo, no hay hitos contra los cuales decir cuánto se atrasó. El informe dice que la salida se reprogramó, pero no hay cronograma que lo refleje. |
| Presupuesto aprobado | Presente: 3.300.000.000 COP, 2026-05-11 | — |

### Contenido
**Objetivo de negocio:** pendiente de definir. El acta solo dice "Entregar cobranza digital para Tecnología" (solución, no resultado).
**Alcance:** "Componente 1, Componente 2, Componente 3" — sin descripción. *(Acta, 2026-05-11)*
**Exclusiones:** "Lo que otro proyecto cubre" — sin nombrar. *(Acta)*
**Patrocinador:** Óscar Ramírez *(Acta)* · **Gerente:** Paula Céspedes *(Acta; informe 2026-10-07)*
**Autoridad del gerente:** pendiente de definir — no existe en ningún documento.
**Comité al que reporta:** Comité de Medios de Pago *(Acta)* · **Cadencia:** pendiente de definir.
**Supuestos:** pendiente de definir. **Restricciones:** pendiente de definir.
**Criterio de éxito:** "Cobranza digital en producción y medido" *(Acta)*, sin métrica · **Lo mide:** pendiente de definir.
**Hitos principales:** pendiente de definir. Solo constan inicio 2026-05-21 y cierre 2027-04-28 *(Acta)*.
**Presupuesto aprobado:** 3.300.000.000 COP *(Acta; informe 2026-10-07)*.

### Otras observaciones que surgen del cruce con el informe (no son del acta, pero la dejan en evidencia)
- Ejecutado 1.351.157.629 COP = 40,9 % del aprobado, con 25 % de avance reportado. Comprometido 2.612.295.707 → 79,2 % del aprobado. La proyección supera el aprobado en 2,9 %, por debajo del umbral de 10 % de la configuración: no dispara alerta por sí sola, pero sí exige decidir quién cubre el excedente, y el acta no lo dice.
- El estado declarado es rojo; el informe no explica por qué ni cuánto atraso hay.
- El riesgo del proveedor no tiene dueño, probabilidad, impacto ni fecha. La reprogramación de la salida aparece como incidencia sin dueño.

Lo que no sé: qué son los tres componentes, qué otro proyecto cubre lo excluido, y si existe alguna definición de autoridad fuera de la carpeta. Solo vi dos documentos.

### Después
- **Autoridad del gerente:** el acta quedó sin ella. Te propongo llevar esa definición al Comité de Medios de Pago del 2026-10-22: es una decisión (monto y tipo de cambio que Paula puede resolver sola), no un trámite. Sigue en pie con el excedente de 94.680.472 COP sobre la mesa.
- **Supuestos:** de la revisión salen la aprobación regulatoria, la confirmación del proveedor y la ventana de operaciones. Propongo pasarlos al registro RAID (`/raid-log PRY-211`).

*Pie de rigor: borrador de trabajo, no decisión ni asesoría. Cada dato cita su documento; la verificación es tuya. Es una revisión: no se redactó ningún campo; lo no sustentado queda como pendiente de definir.*
