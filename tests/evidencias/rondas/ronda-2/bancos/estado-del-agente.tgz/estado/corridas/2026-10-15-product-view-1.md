# Corrida del 2026-10-15 · product-view

13 proyectos · 26 s · 67 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 24 |
| `progress_vs_plan` | 6 |
| `vendor_accepted_without_evidence` | 6 |
| `declared_vs_evidence` | 6 |
| `variance_time` | 4 |
| `commitment_undated` | 4 |
| `variance_cost` | 4 |
| `change_without_baseline` | 4 |
| `commitment_overdue` | 3 |
| `rebaseline_unauthorized` | 2 |
| `vendor_deliverable_late` | 2 |
| `vendor_invoiced_over_accepted` | 1 |
| `pm_vs_pmo` | 1 |

Producto con un solo proyecto (PRY-206); sin sección de producto, señales del proyecto resumidas. No se sabe cuál fecha de fin es la vigente (PMO 2026-09-25 vs PM 2026-11-11) ni el área dueña de los 4 proyectos sin producto.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## Productos al 2026-10-15 — pagos QR

Sale de las fichas del portafolio con corte 2026-10-15 (cálculo de `portafolio.py compute`). Términos vigentes (versión 0.3.8, aceptados por José Francisco Ñáñez el 2026-10-15).

**«pagos QR» tiene un solo proyecto: PRY-206 Billetera y QR.** La vista por producto no aporta nada distinto a la del proyecto, así que no armo sección de producto; lo que sigue es lo que el cálculo marca en ese proyecto.

| Producto | Proyectos | Con alertas | Fecha más tardía | Aprobado | Comprometido |
|---|---|---|---|---|---|
| pagos QR | 1 (PRY-206) | 12 alertas, 8 señales distintas | 2026-09-25 o 2026-11-11 (ver abajo) | 6.800.000.000 COP | 3.979.137.385 COP |

**Lo que hay que ver (PRY-206)**
- Avance: declara 31 %; el plan da por cumplidos 5 de 5 hitos (100 %). Brecha de 69 puntos.
- Hitos dados por cumplidos sin evidencia: «Ambiente de pruebas certificado» (vencía 2025-12-17), «Integración con el core» (2026-03-21), «Piloto con usuarios internos» (2026-06-23).
- Costo: proyección 7.686.267.486 COP contra 6.800.000.000 aprobados, 13,0 % por encima (umbral 10 %). Ejecutado 2.925.165.723 (43,0 %); comprometido 58,5 %. Las cuatro cifras vienen completas.
- Proveedores: Redes del Norte Ltda. (CT-725) tiene facturado 1.317.839.587 contra 920.079.190 aceptado, 397.760.397 por encima de lo aceptado; dos entregables aceptados sin evidencia («Licenciamiento del motor», «Parametrización del tarifario») y la «Bolsa de horas de desarrollo» pendiente hace 232 días. Consultora Andina S.A.S. (CT-279) tiene «Parametrización del tarifario» pendiente hace 103 días.
- Compromiso sin fecha: Laura Vélez, «Mandar el ajuste del presupuesto» (notas de reunión del 2026-10-15).
- El gerente declara rojo (31 %, informe del 2026-10-04, 11 días). Cinco de las señales no están explicadas en esa declaración: hitos sin evidencia, avance contra plan, desviación de costo, entregable tardío de proveedor y facturación sobre lo aceptado.

**Dependencias internas:** no aplica, el producto tiene un solo proyecto; el cálculo no registra dependencias de PRY-206.

**Fecha comprometida del producto:** no puedo darla con una sola fecha. La PMO tiene 2026-09-25 (cronograma v1, 2025-06-02) y el gerente 2026-11-11 (acta de constitución, también 2025-06-02); ninguna es más reciente que la otra. Con la primera el proyecto ya venció; con la segunda le quedan 27 días. Hay que confirmar cuál es la vigente.

**Proyectos sin producto declarado:** PRY-202 Migración a la nube, PRY-205 Prevención de lavado de activos, PRY-208 Motor de decisión y PRY-210 Portal de proveedores. No pertenecen a «pagos QR»; nadie puede responder por el conjunto al que sirven. El área dueña no la dio el cálculo y no la invento.

**Ofrecimiento:** al no haber dependencias internas, no hay nada que llevar al comité de producto como decisión conjunta. El comité del 2026-10-22 sí podría decidir la fecha vigente de PRY-206, el ajuste de presupuesto y la facturación de Redes del Norte.

---
Pie de rigor: fuentes y cifras salen de las fichas y del cálculo de esta corrida; «unmarked» en 42 datos (ninguno marcado como evidencia ni como declaración), así que las citas hay que verificarlas contra los documentos. Criterio produce borradores, no decisiones; la verificación es suya.
