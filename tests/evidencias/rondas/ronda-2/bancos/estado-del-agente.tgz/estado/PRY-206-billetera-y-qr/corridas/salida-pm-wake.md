Revisé PRY-206 Billetera y QR: no toca barrido, agenda ni informe (comité el 2026-10-29, a 14 días). Nada venció. Vuelvo el 2026-10-28.
