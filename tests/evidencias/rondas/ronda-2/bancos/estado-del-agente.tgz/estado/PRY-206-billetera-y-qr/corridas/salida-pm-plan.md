# Plan — Billetera y QR (PRY-206) · borrador del 2026-10-15
**Desde:** acta de constitución del 2025-06-02 (`00-gobierno/2025-06-02-acta-constitucion.md`) · **Criterio de éxito:** «Billetera y QR en producción y medido» (acta)

**Términos:** ya vigentes (versión 1.1, aceptada el 2026-10-15 por José Francisco Ñáñez); no se registró de nuevo.

**Advertencia de contexto.** Este plan se pide con el proyecto ya en marcha: el acta tiene 16 meses, `10-plan/2025-06-02-cronograma-v1.xlsx` ya existe con cinco hitos todos «cerrado», y el acta de recibo del 2026-10-04 da por recibida la «Salida a producción». Lo que sigue es una WBS reconstruida desde los documentos, no un plan nuevo desde cero. No hay línea base nueva ni fechas comprometidas.

## Lo que le falta al acta
| Qué | Consecuencia de planificar sin eso |
|---|---|
| **Alcance vacío:** lista «Componente 1, Componente 2, Componente 3» | No hay entregables que descomponer; la WBS no puede partir del alcance. Los nodos salen de contratos y del cronograma, y van marcados así. |
| **Fuera de alcance genérico:** «Lo que otro proyecto cubre» | No se sabe qué otro proyecto ni qué queda excluido; el límite del plan queda abierto. |
| **«Medido» sin métrica:** el criterio de éxito no dice qué se mide, con qué umbral ni quién lo acepta | El último entregable no es aceptable por nadie; es el nodo que nadie va a cerrar. |
| **Autoridad del gerente no declarada** (`authority: null` en la configuración; el acta no la menciona) | No se sabe qué puede decidir quien planifica y qué hay que subir. |
| **Objetivo del negocio tautológico:** «Entregar billetera y qr para Banca Hipotecaria» | No hay beneficio esperado contra el cual priorizar. |
| **Dependencias:** «Ninguna declarada», pero hay dos proveedores contratados y una «siguiente fase» mencionada en la reunión | Dependencias reales sin dueño. |

Sigo marcándolo y no lo relleno.

## WBS
| # | Entregable | Quién lo acepta | De dónde sale | Duración |
|---|---|---|---|---|
| 1 | Diseño funcional aprobado | sin definir (el acta de recibo es un PDF) | cronograma v1 (hito) | vacía |
| 2 | Ambiente de pruebas certificado | sin definir | cronograma v1 (hito) | vacía |
| 3 | Integración con el core | sin definir | cronograma v1 (hito) | vacía |
| 4 | Piloto con usuarios internos | sin definir | cronograma v1 (hito) | vacía |
| 5 | Salida a producción | Camilo Beltrán (acta de recibo 2026-10-04) | cronograma v1 + acta de recibo | vacía |
| 6 | Licenciamiento del motor (CT-279, Consultora Andina; CT-725, Redes del Norte) | gerente del proyecto, por la condición de pago | contratos | las fechas comprometidas están en los contratos (2025-10-19); no se usan como duración |
| 7 | Bolsa de horas de desarrollo (CT-279 y CT-725) | ídem | contratos | ídem (2026-02-25) |
| 8 | Parametrización del tarifario (CT-279 y CT-725) | ídem | contratos | ídem (2026-07-04) |
| 9 | Medición de Billetera y QR en producción | sin definir | criterio de éxito del acta, sin métrica | vacía |
| 10 | Componentes 1, 2 y 3 | sin definir | acta, sin contenido | no se descompone |
| 11 | «Siguiente fase» | sin definir | notas del 2026-10-15, una mención | no se descompone |

## Orden
Sin fechas. Lo que sale de los documentos:
- Los hitos del cronograma v1 van en cadena: 1 → 2 → 3 → 4 → 5.
- 9 necesita 5: no se mide lo que no está en producción.
- Los entregables contractuales 6, 7 y 8 no tienen en ningún documento una relación declarada con los hitos 1–5. Supuesto: alimentan la integración y la salida; no está escrito.
- La relación entre 10 y 1–5 está sin definir.

## Supuestos sobre los que está construido
| Supuesto | Qué pasa si resulta falso |
|---|---|
| Los cinco hitos del cronograma v1 son la estructura de entregables del proyecto | Si los «Componentes 1–3» son otra cosa, la WBS omite alcance. |
| Los contratos CT-279 y CT-725 cubren los mismos tres entregables con dos proveedores, no es un error de copia | Si es un error, hay montos y entregables contratados que no existen, o duplicados. |
| «En producción» del acta equivale a la «Salida a producción» recibida el 2026-10-04 | Si no, el criterio de éxito puede estar cumplido o sin cumplir, según quién lo lea. |
| La «siguiente fase» es parte de este proyecto | Si es otro proyecto, no entra en esta WBS. |
| El cierre comprometido (2026-11-11) sigue vigente | Si cambió, no está en ningún documento. |

Estos pasan a riesgos del proyecto en cuanto el plan se apruebe.

## Sin definir
| Qué | Quién lo define |
|---|---|
| Contenido de los Componentes 1–3 y el límite real del alcance | Patrocinador (Natalia Ospina), con el gerente |
| Qué es «medido» y con qué umbral | Patrocinador |
| Quién acepta los hitos 1–4 | Patrocinador / Comité de Arquitectura |
| Autoridad del gerente al planificar | Patrocinador |
| Qué es la «siguiente fase» y si es de este proyecto | Patrocinador / Comité |
| Relación entre contratos e hitos | Gerente |

## Proyectos análogos
No hay ninguno a la vista: la configuración no apunta a una carpeta de fichas de la PMO. No se estima por analogía.

## Contradicciones que el plan hereda (para verificar, no para resolver aquí)
- **Contratos:** CT-279 tiene «Parametrización del tarifario» en *pendiente*, con fecha comprometida 2026-07-04 ya vencida. CT-725 la tiene *recibida* y tiene «Bolsa de horas» *en curso* con fecha 2026-02-25 vencida. Los dos contratos listan los mismos entregables con fechas idénticas. Hay facturas de ambos contratos del 2026-09-10; no se contrastaron aquí.
- **Cronograma v1:** `fecha_vigente` es idéntica a `fecha_linea_base` en los cinco hitos, y «Salida a producción» figura para 2026-09-25, pero el acta de recibo es del 2026-10-04 (9 días después). O el cronograma no se actualizó, o la fecha del acta no es la del hecho.
- **Acta de recibo de Salida a producción:** una sola línea, sin evidencia de qué se recibió ni cómo se verificó.

## Preguntas para el equipo
1. ¿Cuánto toma el diseño funcional, el ambiente de pruebas, la integración, el piloto y la salida a producción en esta fase? (una por nodo, 1–5)
2. ¿Cuánto toma medir? ¿Qué se mide y cuándo se declara «medido»?
3. ¿Qué son los Componentes 1, 2 y 3?
4. ¿Qué es la «siguiente fase», quién la financia y cuándo empieza?
5. ¿CT-725 duplica a CT-279, o son entregables distintos con el mismo nombre?
6. ¿Quién acepta cada hito del cronograma?
7. ¿El equipo completo del proveedor está confirmado para la siguiente fase? (riesgo mencionado el 2026-10-15 y no registrado)

## Para comprometer una fecha falta
- Disponibilidad real del equipo y de los proveedores (el riesgo de la reunión del 2026-10-15 apunta aquí).
- Fecha del proveedor para la siguiente fase.
- Ventana de despliegue y de medición en producción.
- Definición de «medido».

Ninguna de las cuatro está en un documento.

## Después
Si el plan se aprueba, queda por registrar como línea base original (hoy solo existe el cronograma v1 sin variación) y pasar los supuestos al RAID con doliente. El riesgo del proveedor del 2026-10-15 sigue sin registrar.
