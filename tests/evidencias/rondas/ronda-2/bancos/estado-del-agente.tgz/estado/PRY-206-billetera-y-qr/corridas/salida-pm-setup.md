## Listo — Billetera y QR (PRY-206)

**Lo que miré:** 13 documentos · 2 minutas (notas del 2026-10-15 y comité del 2026-10-12) · la última del 2026-10-15. Todos los formatos (.md, .pdf, .docx, .xlsx, .txt) se pueden leer.
**Términos:** aceptados por José Francisco Ñáñez para la versión 0.3.8 · comprobante en `.criterio/terminos/aceptacion-criterio-project-0.3.8-2026-10-15.md` y `.pdf` · SHA-256 fd18d9cd0b3d5a0f…

Preguntas (sesión sin interfaz, respuestas sugeridas):
1. Eres Camilo Beltrán, gerente de Billetera y QR (PRY-206), patrocina Natalia Ospina (acta de constitución).
2. Reunión de seguimiento: jueves cada dos semanas (la última, jueves 2026-10-15; «próxima reunión en dos semanas», es decir 2026-10-29).
3. Estado en `estado/PRY-206-billetera-y-qr`.
4. Términos: aceptados con el nombre indicado.

### Lo que se prometió en tu última reunión (2026-10-15)
| Quién | Qué | Para cuándo | |
|---|---|---|---|
| Liliana Torres | Entregar el punto 21 | 2026-10-29 | Reprogramado: el comité del 2026-10-12 lo fechó para el 2026-10-05 y «no alcanzó». «se compromete para el 29/10/2026» |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-25 | «queda para el 2026-10-25» |
| Laura Vélez | Mandar el ajuste del presupuesto | sin fecha | «la otra semana» |

Ninguno está vencido hoy (2026-10-15).

### Sin fecha
- Laura Vélez, ajuste del presupuesto: «la otra semana» no es una fecha; queda como no declarada. Es la señal que `compute` levantó (commitment_undated). Es el que desaparece de los informes.

### Qué le falta a tu carpeta
- Riesgo sin registrar: en la reunión se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase y «nadie lo anotó como riesgo». Está en la ficha como riesgo no registrado, no como hallazgo calculado.
- Las notas del 2026-10-15 no traen formato de acta: sin encabezado ni asistentes por rol; el comité del 2026-10-12 lista a Camilo Beltrán y Natalia Ospina, y las notas del 15 a otras cuatro personas. Conviene confirmar cuál es tu reunión de seguimiento.
- Minutas de las reuniones anteriores (solo hay dos): sin ellas no se ve cuántas veces se ha reprogramado cada compromiso.
- Cronograma vigente: solo está `cronograma-v1.xlsx` de 2025-06-02, y no leí su contenido en esta pasada.
- Datos de la ficha con 16 meses de antigüedad (acta de 2025-06-02): código, patrocinador, fechas y presupuesto aprobado de 6.800.000.000 COP. Sin línea base posterior, sin presupuesto comprometido ni ejecutado.
- Actas de recibo y facturas existen en `20-seguimiento`, pero no las crucé con contratos en esta pasada: leí una reunión, no el proyecto. La ficha no está sellada.

**Cuándo vuelvo:** jueves 2026-10-29, la siguiente reunión de seguimiento (cada dos semanas).

Te ofrezco leer las minutas anteriores y el resto de documentos para completar el historial de compromisos.
