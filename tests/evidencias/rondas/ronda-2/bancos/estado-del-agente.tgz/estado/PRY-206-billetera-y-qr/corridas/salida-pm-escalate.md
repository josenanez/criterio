## Para decisión — Billetera y QR (PRY-206) · 2026-10-15

**Supuestos de esta corrida** (nadie respondió, tomé lo sugerido): escalo lo marcado en la agenda de hoy, la proyección contra el presupuesto aprobado. Términos ya vigentes (0.3.8, aceptados por José Francisco Ñáñez el 2026-10-15), no se pidió otro registro.

### Primero: la autoridad del gerente no está declarada
La configuración la trae como `null` y el acta de constitución (2025-06-02) no tiene sección de autoridad ni de umbrales. No puedo decir si Camilo Beltrán puede mover presupuesto. Ese es el primer punto que escala, antes que el del presupuesto: que el comité o la patrocinadora (Natalia Ospina) declare por escrito qué puede decidir el gerente.

### ¿El Comité de Arquitectura amplía el presupuesto de PRY-206 de 6.800.000.000 a 7.686.267.486 COP (+886.267.486, +13,0%), o mantiene el techo y se recorta el alcance?

**Quién decide:** el Comité de Arquitectura, que fue quien aprobó el presupuesto el 2025-06-02 (acta de constitución). Si el gerente tiene facultad propia para esto, no consta. · **Si no se decide hoy:** no hay fecha de vencimiento escrita en ningún documento. Lo que sí está fechado: el comité es el 2026-10-29 y el cierre comprometido es el 2026-11-11, 13 días después. El informe del 04/10 reporta 31 % de avance y estado Rojo. Cada comité sin decisión es tiempo que se consume del cierre. No invento un vencimiento que los documentos no traen.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Ampliar a 7.686.267.486 COP | Se mantiene el alcance del acta | Cierre 2026-11-11 sin cambio declarado. Con 31 % de avance, no está sustentado que se sostenga | +886.267.486 COP (+13,0 %) |
| B. Mantener 6.800.000.000 COP | Se recorta. No sé qué: el acta lista «Componente 1, 2, 3» sin detalle | No sé | Techo de 6.800.000.000 COP. Ya hay 3.979.137.385 comprometidos y 2.925.165.723 ejecutados |

No hay base documental para dar días ni para decir cuánto alcance cubre el recorte de B. Sin ese dato, B no es una opción completa. Falta que el gerente lo estime.

**Recomiendo:** llevar la pregunta al comité del 29/10 con el ajuste de presupuesto de Laura Vélez en la mano, y no decidir A ni B antes de tenerlo. Las notas del 15/10 solo dicen que lo manda «la otra semana». Razón: la cifra de 7.686.267.486 sale del informe del 04/10 y no sé qué supuestos tiene. Pedir ampliación sobre ella sin el ajuste es pedir una decisión sobre un número sin sustento.

### A quién alcanza
No calculé el efecto con `impact`: este punto no mueve una fecha, y el cálculo necesita un cambio en días. Inventarlo sería falso. Tampoco hay dependencias declaradas (acta: «Ninguna declarada»), así que no puedo nombrar proyectos alcanzados. Si el comité decide B y el cierre se corre, vuelve a correrse con `--days`.

### Mis hitos por los que pasa
Ninguno calculado, por lo mismo. El único hito fechado en los documentos es el cierre, 2026-11-11.

### De dónde sale esto
- Aprobado, comprometido, ejecutado, proyección y estado Rojo: `20-seguimiento/2026-10-04-informe-avance.pdf`.
- Presupuesto aprobado por el Comité de Arquitectura, fechas y «Dependencias: ninguna declarada»: `00-gobierno/2025-06-02-acta-constitucion.md`.
- Autoridad `null`: `.criterio/proyecto/PRY-206/config.json`.
- Ajuste de presupuesto de Laura Vélez, sin fecha: `2026-10-15-notas-reunion.txt`.
- Fecha del comité: configuración (`committee_next` 2026-10-29).

**Lo que no sé:** si la proyección ya incluye el ajuste de Laura; si el 29/10 es el comité con Natalia Ospina (la configuración dice que sí, las notas no); qué facultad tiene el gerente.

*Esto no escala solo: llevarlo al comité es tuyo. El comité decide.*
