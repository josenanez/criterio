# Billetera y QR (PRY-206) — semana al 2026-10-15

**Declara el gerente:** sin declaración · sin avance · sin fecha
**Sustento documental:** no se puede juzgar: no hay estado declarado que contrastar
**Lo que el semáforo no explica:** nada (no hay semáforo declarado). Señal abierta: 1 compromiso sin fecha.

> Sesión sin interfaz: nadie pudo contestar la pregunta del paso 2 (qué estado declara y con qué avance). El agente no declara ni sugiere un estado, así que la línea queda en blanco. Un informe sin declaración es incómodo a propósito.

## Señales abiertas (lo que tenía a la vista antes de preguntar)
- Compromiso sin fecha: Laura Vélez, «mandar el ajuste del presupuesto», dicho como «la otra semana» (2026-10-15-notas-reunion.txt).
- Riesgo dicho en reunión y no registrado: el proveedor podría no llegar con el equipo completo para la siguiente fase («nadie lo anotó como riesgo»).
- Sin autoridad del gerente configurada (`authority`: null).

## Qué cambió esta semana
No hay corrida anterior: este es el primer snapshot (2026-10-15), así que el diff da 0 cambios. No se puede decir qué cambió, solo qué hay.

## Lo que sigue igual y sigue mal
Sin histórico no se pueden contar días así. Ninguna desviación medible por ahora.

## Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | sin línea base registrada | 2026-11-11 (acta del 2025-06-02) | no calculable |
| Presupuesto | sin línea base registrada | COP 6.800.000.000 | no calculable |

Replanificaciones: 0 registradas. Sin línea base no se puede medir atraso: se dice, no se asume cero.

### Hitos de las próximas cuatro semanas
No hay hitos en la ficha. El único dato de fecha es el cierre, 2026-11-11 (27 días).

## Las cifras
| Aprobado | Comprometido | Ejecutado | Proyectado | Disponible real |
|---|---|---|---|---|
| COP 6.800.000.000 | sin dato | sin dato | sin dato | no calculable (necesita comprometido) |

## Abierto
**Reprogramados:** Liliana Torres, «entregar el punto 21»: del 2026-10-05 al 2026-10-29, 1 vez (bajo el umbral de 3).
**Vencidos sin evidencia:** ninguno.
**Sin fecha:** Laura Vélez, ajuste del presupuesto.
**Próximos:** Óscar Ramírez, revisión con el proveedor, 2026-10-25.
**RAID sin movimiento:** el riesgo del proveedor no está registrado.
**Proveedor:** sin entregables de proveedor en la ficha.

## Lo que necesito de alguien
- Camilo Beltrán: declarar estado y avance (queda pendiente).
- Laura Vélez: una fecha para el ajuste del presupuesto, que además es la cifra que falta para el disponible real.
- Camilo Beltrán: decidir si registra el riesgo del proveedor.
- Definir la autoridad del gerente; sin ella no se puede marcar qué excede su autoridad.

## Lo que no se sabe
**Sin dato:** línea base (fecha y presupuesto), comprometido, ejecutado, proyectado, hitos, proveedores, estado declarado. Los 9 campos con dato de la ficha vienen del acta de 2025-06-02 (16 meses de antigüedad); ninguna fuente está marcada como evidencia o declaración (29 sin marcar).
**Silencio:** último documento hace 0 días · última reunión hace 0 días (2026-10-15).

---
Ficha: estado/PRY-206-billetera-y-qr/records/PRY-206.json · corte 2026-10-15 · 9 campos desactualizados, 8 conceptos sin dato · Términos (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15): https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.8
