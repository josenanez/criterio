## Compromisos — Billetera y QR (PRY-206) · al 2026-10-15

3 compromisos abiertos. Ninguno vencido, ninguno reprogramado tres veces, ninguno cerrado con evidencia.

### Se viene reprogramando
Nada que alcance el umbral (3 reprogramaciones; `compute` no marca ninguno). Un compromiso ya cambió de fecha una vez:

> **Liliana Torres** · Entregar el punto 21
> Prometido para el 2026-10-29, y antes para el 2026-10-05 (`30-reuniones/2026-10-12-comite-semanal.md`).
> Dicho el 2026-10-15: «lo de "entregar el punto 21" no alcanzó» (`2026-10-15-notas-reunion.txt`).
> Una sola reprogramación; se vigila, no es todavía un bloqueo. Nota: el acta del 12/10 registró como fecha una que ya había pasado (05/10).

### Vencidos sin evidencia
Ninguno.

### Vencen esta semana
Ninguno. El más cercano es el del 2026-10-25.

### Abiertos con fecha
| Quién | Qué | Para cuándo |
|---|---|---|
| Óscar Ramírez | Revisión con el proveedor | 2026-10-25 |
| Liliana Torres | Entregar el punto 21 | 2026-10-29 |

### Sin fecha
| Quién | Qué | Dicho el |
|---|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto | 2026-10-15 |

«La otra semana» no es una fecha. No puede estar vencido, y por eso es el que se pierde: queda contado aparte (`commitments_undated` = 1).

### Cerrados desde la última revisión
Ninguno. Buscado en el expediente: no hay documento que respalde la entrega del punto 21, el ajuste del presupuesto ni la revisión con el proveedor.

### Fuera de esta lista
El comentario sobre que el proveedor podría no llegar con el equipo completo para la siguiente fase es un riesgo no registrado, no un compromiso. Va a `/pm-report` o al registro RAID.

### Después
- Nada llega a tres reprogramaciones, así que no hay decisión que subir al comité (próximo: 2026-10-29).
- Sin cambios a la ficha por estos compromisos; no hace falta `/pm-publish` por ahora.
