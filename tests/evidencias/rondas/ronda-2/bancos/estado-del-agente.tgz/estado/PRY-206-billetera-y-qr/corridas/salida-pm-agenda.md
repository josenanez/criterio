## Reunión de seguimiento — Billetera y QR (PRY-206) · 2026-10-29
6 puntos · 27 minutos · 3 personas requeridas (Camilo Beltrán, Óscar Ramírez, Laura Vélez)

**Términos:** vigentes (versión 0.3.8, aceptados por José Francisco Ñáñez el 2026-10-15).
**Supuestos de esta agenda** (nadie respondió, tomé lo sugerido): fecha 2026-10-29, que es lo que dan «próxima reunión en dos semanas» (notas del 15/10) y la configuración (`committee_next`); duración 30 min, porque no se pidió otra. Las notas del 15/10 no dicen si el 29/10 es la reunión de seguimiento, el comité o ambas; si es el comité con Natalia Ospina, los puntos de «No es de esta reunión» suben a la agenda.
**Primera corrida:** no hay snapshot anterior, así que no puedo decir qué cambió desde la reunión pasada. Armé la agenda contra lo que el expediente sostiene hoy, y el anexo no dice «sin cambios desde» ninguna fecha.

### Lo que no se destraba solo
Nada reprogramado tres veces. El único compromiso con cambio de fecha es el de Liliana Torres, una sola vez. La reunión es de seguimiento, y lo más pesado es lo vencido del proveedor.

### Vencido sin evidencia
Entregables de proveedor vencidos y sin recibo. Se queda cada uno porque quien recibe (Camilo) y quien tiene la revisión con el proveedor (Óscar, 25/10) van a estar.

| Quién | Qué | Desde | Qué se necesita hoy | Min |
|---|---|---|---|---|
| Redes del Norte Ltda. (CT-725) · recibe Camilo Beltrán | Bolsa de horas de desarrollo, «en curso» | Comprometida 2026-02-25: 232 días | Fecha firme de entrega, o decir que no la hay. Si Óscar la trata el 25/10, que traiga la respuesta | 5 |
| Consultora Andina S.A.S. (CT-279) · recibe Camilo Beltrán | Parametrización del tarifario, «pendiente» | Comprometida 2026-07-04: 103 días | Lo mismo: fecha firme o reconocer que no la hay | 5 |

Fuente: `00-gobierno/2025-06-06-contrato-ct-725.docx` y `00-gobierno/2025-05-23-contrato-ct-279.md`, tabla de entregables.
Las notas del 15/10 no dicen de qué trata la «revisión con el proveedor» de Óscar. Que sea sobre estos entregables es mi inferencia.
**Si no se resuelve:** el cierre comprometido es el 2026-11-11 (acta de constitución, 2025-06-02). Del 29/10 quedan 13 días y dos entregables contractuales sin recibir.

### Se decide hoy o se atrasa
| Qué | Quién decide | Si no se decide | Min |
|---|---|---|---|
| **Factura FV-1725 (Redes del Norte, 1.317.839.587 COP) radicada sin actas de recibo de CT-725 en la carpeta.** El contrato marca «recibido» dos entregables (Licenciamiento y Parametrización, 460.039.595 c/u = 920.079.190). La factura supera eso en 397.760.397 y no coincide con ninguna combinación de entregables (los tres suman 1.380.118.785). El contrato pide pagar contra acta firmada por el gerente. | Camilo Beltrán: ¿aprueba, retiene o pide las actas? | Sigue radicada en cuentas por pagar (`2026-09-10-factura-ct-725.pdf`) sin sustento documental | 8 |
| **Actas sin entregable de contrato:** «Salida a producción» (2026-10-04) y «Diseño funcional aprobado» (2026-10-11) no nombran contrato, y esos entregables no están en CT-279 ni en CT-725. ¿Qué cierran, y de qué contrato? El informe del 04/10 también habla de un «componente de integración» entregado «pendiente de aceptación». | Camilo Beltrán | No se sabe qué recibió el proyecto ni contra qué se puede facturar | 3 |
| **Riesgo comentado y no registrado:** el proveedor podría no llegar con el equipo completo para la siguiente fase («nadie lo anotó como riesgo»). No hay RAID en la carpeta. Se decide si se registra, con doliente. | Camilo Beltrán | Sigue dicho de pasada, sin doliente ni seguimiento | 4 |

Fuentes: `20-seguimiento/2026-09-10-factura-ct-725.pdf`; `00-gobierno/2025-06-06-contrato-ct-725.docx`; `20-seguimiento/2026-10-04-acta-recibo-salida-a-producción.md`; `20-seguimiento/2026-10-11-acta-recibo-diseño-funcional-aprobado.pdf`; `20-seguimiento/2026-10-04-informe-avance.pdf`; `2026-10-15-notas-reunion.txt` (no dicen quién lo comentó ni de qué fase hablan).
No sé si la factura ya se pagó. Solo consta «radicada en cuentas por pagar».

### Vence antes de la próxima
| Quién | Qué | Para cuándo |
|---|---|---|
| Óscar Ramírez | Revisión con el proveedor | 2026-10-25 (domingo). Confirmar si es ese día o el viernes 23 |
| Laura Vélez | Mandar el ajuste del presupuesto | Sin fecha: «la otra semana» (notas 15/10). **Fijar fecha en la reunión, 2 min.** |

Los 2 minutos de Laura están dentro de los 27. Hoy no puede estar vencido, y por eso es el que se pierde.

### No es de esta reunión
| Qué | Por qué | Dónde va |
|---|---|---|
| Proyección al cierre 7.686.267.486 COP contra 6.800.000.000 aprobados: +886.267.486 (13,0%). Estado declarado: Rojo (`2026-10-04-informe-avance.pdf`) | El presupuesto lo aprobó el Comité de Arquitectura (acta de constitución). La autoridad del gerente figura como `null` en la configuración y no puedo decir si la excede. Nadie en la sala aprueba presupuesto | Comité del 2026-10-29. `/pm-escalate` para formularla. El ajuste de Laura puede estar relacionado, pero las notas no lo dicen |
| «Cambio regulatorio en discusión que puede mover el alcance» (riesgo abierto del informe del 04/10) | Sin doliente en la sala, y no depende de nadie que asista | Comité; registrar en el RAID junto con el riesgo del proveedor |

### Anexo — no se repasa en la reunión
Sin snapshot anterior para comparar. Esto es lo que revisé y no necesita a nadie:
- Liliana Torres · Entregar el punto 21 · 2026-10-29. Vence el día de la reunión, no antes. Una reprogramación (antes 2026-10-05, según el comité del 12/10). Preguntar «¿está entregado?» al abrir. Si no, sube a segunda reprogramación.
- CT-279, Licenciamiento del motor: acta de recibo 2025-11-05.
- CT-279, Bolsa de horas de desarrollo: acta de recibo 2026-03-16.
- Factura FV-2279 (Consultora Andina, 762.675.710 COP) = dos entregables de 381.337.855, ambos con acta. Cuadra.
- Decisiones pendientes de reuniones anteriores: ninguna explícita. El comité del 12/10 no registra decisiones y las notas del 15/10 tampoco.

### Después
- Cuando termine la reunión, `/pm-minutes` sobre las notas o la transcripción.
- Para el comité: `/pm-escalate` con la proyección contra el presupuesto aprobado.
- No convoqué a nadie. Citar a Camilo, Óscar y Laura es del gerente.
