# Acta — Billetera y QR (PRY-206) · 2026-10-15
**Asistieron:** Camilo Beltrán, Liliana Torres, Laura Vélez, Óscar Ramírez · **Fuente:** `2026-10-15-notas-reunion.txt` · **Ausentes con tema en agenda:** no hay agenda en las notas; no se puede decir.

**Términos:** vigentes (versión 0.3.8, aceptados por José Francisco Ñáñez el 2026-10-15; comprobante en `.criterio/terminos/`).

## Compromisos
| Quién | Qué | Para cuándo | |
|---|---|---|---|
| Liliana Torres | Entregar el punto 21 | 2026-10-29 | Reprogramado 1 vez: el comité del 2026-10-12 lo fechó para el 2026-10-05; «no alcanzó, se compromete para el 29/10/2026» |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-25 | «queda para el 2026-10-25» (cae en domingo) |

### Sin fecha
| Quién | Qué |
|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto. «La otra semana» no es una fecha y se queda como `no_declarada`. |

## Decisiones
Ninguna. Las notas no registran ninguna decisión con quién la tomó y qué se descartó.

## Quedó sin decidir
Las notas no nombran ningún tema que haya quedado abierto de forma explícita.

## Intenciones sin doliente
Ninguna.

## Dicho al pasar y no registrado
| Qué | Quién lo dijo | Categoría | Ya estaba en el RAID |
|---|---|---|---|
| «Se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo» | No consta: las notas dicen «se comentó» | Riesgo (dependencia del proveedor) | No. No hay RAID en la carpeta. |

## Cerrado en esta reunión
Nada. Se omite la sección.

## Lo que esta reunión contradice
Nada. Las notas no cambian patrocinador, fecha de cierre ni comité. El expediente (acta de 2025-06-02) dice patrocinador Natalia Ospina, comité de Arquitectura y cierre 2026-11-11.

## Sin resolver de la transcripción
- «próxima reunión en dos semanas» → se lee como 2026-10-29, pero las notas no dan la fecha.
- «la otra semana» (Laura Vélez) → no se sabe qué día. No elegí uno.
- Las notas no dicen quién comentó lo del proveedor, ni de qué fase hablan.
- Las notas no ponen cargo ni rol. Laura Vélez y Óscar Ramírez no salen en el comité del 2026-10-12.
- El comité del 2026-10-12 fechó el compromiso de Liliana para el 2026-10-05, antes de la propia reunión. No se puede saber si ya estaba vencido ahí.

## Recálculo (`compute`)
- Señal levantada: 1, `commitment_undated` (Laura Vélez).
- Vencidos: 0. Reprogramados sobre el umbral de 3: 0.
- Hallazgos de la ficha, aparte del acta: datos con 16 meses de antigüedad, sin línea base y sin autoridad definida.

## Cambio al estado
Corregí el historial de reprogramaciones de Liliana Torres en la ficha: guardaba la fecha nueva (2026-10-29) y debía guardar la anterior (2026-10-05).

**El acta sale en la conversación y la guardas tú.** No la escribí en `30-reuniones`.

## Siguiente
`/pm-commitments` para ver el seguimiento completo. `/pm-publish` no hace falta por ahora: el acta no contradice ningún campo de la ficha.
