Publiqué la ficha en `/home/claude/banco/ronda-2/bancos/espacio/documentos/proyectos/PRY-206-billetera-y-qr/00-gobierno/ficha-pm.json`, con corte al 2026-10-15.

**Lleva:** 9 campos con dato · 4 sin decir en ninguna parte (todo el bloque `declared`: estado, avance, fecha y fuente) · declara **nada**: no hay estado declarado al 2026-10-15

**Lo más viejo que va ahí:** los 9 campos con dato (identity.code, name, sponsor, manager, committee, product; plan.start_date, end_date; money.approved) son del acta de constitución del 2025-06-02, con 16 meses: pasa de un año. La PMO va a contrastar sponsor, manager, committee, product, end_date y approved contra esa misma acta, y puede que el acta ya no refleje la realidad.

**Antes de escribir:** recalculé la ficha con `compute`; trae una señal abierta (compromiso sin fecha: Laura Vélez, «mandar el ajuste del presupuesto»). Ninguna fuente está marcada como evidencia o declaración (29 sin marcar). No se publicó ningún campo fuera del esquema (descarté `registered` y `note` del riesgo).

**Nota de la sesión:** sesión sin interfaz; la carpeta de gobierno ya existía, así que no hubo que crearla. Los términos ya estaban vigentes (v1.1, José Francisco Ñáñez, 2026-10-15), no se registraron de nuevo.
