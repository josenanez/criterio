<!-- origen: PRY-200-originación-digital/30-reuniones/2026-10-12-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Banca Empresas · Originación digital

**Fecha:** 2026-10-12
**Asistentes:** Óscar Ramírez, Natalia Ospina

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Diana Molina | Entregar el punto 22 | 2026-10-08 |
