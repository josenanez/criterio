<!-- origen: PRY-207-onboarding-pyme/00-gobierno/2026-05-17-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Onboarding PyME

Código: PRY-207

Área dueña: Banca de Personas

Patrocinador: Óscar Ramírez

Gerente de proyecto: Javier Hoyos

Comité: Comité de Transformación Digital

Producto asociado: cuenta PyME

Fecha de aprobación: 2026-05-17

Objetivo del negocio

Entregar onboarding pyme para Banca de Personas.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

3.300.000.000 COP, aprobado por Comité de Transformación Digital el 2026-05-17.

Fechas comprometidas

Fecha

Inicio

2026-05-27

Cierre

2027-04-27

Criterio de éxito

Onboarding PyME en producción y medido.

Dependencias declaradas

• Ninguna declarada
