<!-- origen: PRY-208-motor-de-decisión/00-gobierno/2025-07-04-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Motor de decisión

**Código:** PRY-208
**Área dueña:** Banca Empresas
**Patrocinador:** Javier Hoyos
**Gerente de proyecto:** Carlos Peña
**Comité:** Comité de Transformación Digital
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-07-04

## Objetivo del negocio

Entregar motor de decisión para Banca Empresas.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**2.400.000.000 COP**, aprobado por Comité de Transformación Digital el 2025-07-04.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-07-14 |
| Cierre | 2026-05-20 |

## Criterio de éxito

Motor de decisión en producción y medido.

## Dependencias declaradas

- Ninguna declarada
