<!-- origen: PRY-203-open-banking/20-seguimiento/2026-10-03-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Open Banking

**Código:** PRY-203
**Fecha de corte:** 2026-10-03
**Gerente:** Elena Duarte

## Estado declarado

**Verde**

Avance reportado: **25%**

## Lo que pasó en el periodo

- El proveedor entregó el componente de integración, pendiente de aceptación

## Presupuesto

| | COP |
|---|---|
| Aprobado | 3.300.000.000 |
| Comprometido | 2.642.425.382 |
| Ejecutado | 1.076.636.264 |
| Proyección al cierre | 3.753.660.017 |

## Riesgos abiertos

- Cambio regulatorio en discusión que puede mover el alcance
