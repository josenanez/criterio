<!-- origen: PRY-207-onboarding-pyme/20-seguimiento/2026-10-13-solicitud-cambio-cc-02.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-02

**Proyecto:** PRY-207 · Onboarding PyME
**Fecha:** 2026-10-13
**Solicitante:** Javier Hoyos

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +120 días sobre la línea base vigente |
| Costo | 240.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
