<!-- origen: PRY-206-billetera-y-qr/00-gobierno/ficha-pm.json · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

{
 "schema_version": "0.2",
 "identity": {
 "code": {"value": "PRY-206", "source": "00-gobierno/2025-06-02-acta-constitucion.md", "source_date": "2025-06-02", "state": "found"},
 "name": {"value": "Billetera y QR", "source": "00-gobierno/2025-06-02-acta-constitucion.md", "source_date": "2025-06-02", "state": "found"},
 "sponsor": {"value": "Natalia Ospina", "source": "00-gobierno/2025-06-02-acta-constitucion.md", "source_date": "2025-06-02", "state": "found"},
 "manager": {"value": "Camilo Beltrán", "source": "00-gobierno/2025-06-02-acta-constitucion.md", "source_date": "2025-06-02", "state": "found"},
 "committee": {"value": "Comité de Arquitectura", "source": "00-gobierno/2025-06-02-acta-constitucion.md", "source_date": "2025-06-02", "state": "found"},
 "product": {"value": "pagos QR", "source": "00-gobierno/2025-06-02-acta-constitucion.md", "source_date": "2025-06-02", "state": "found"}
 },
 "declared": {
 "status": {"value": null, "state": "not_found"},
 "progress_pct": {"value": null, "state": "not_found"},
 "as_of": {"value": null, "state": "not_found"},
 "source": {"value": null, "state": "not_found"}
 },
 "plan": {
 "start_date": {"value": "2025-06-12", "source": "00-gobierno/2025-06-02-acta-constitucion.md", "source_date": "2025-06-02", "state": "found"},
 "end_date": {"value": "2026-11-11", "source": "00-gobierno/2025-06-02-acta-constitucion.md", "source_date": "2025-06-02", "state": "found"}
 },
 "money": {
 "currency": {"value": "COP"},
 "approved": {"value": 6800000000, "source": "00-gobierno/2025-06-02-acta-constitucion.md", "source_date": "2025-06-02", "state": "found"}
 },
 "commitments": [
 {
 "who": {"value": "Liliana Torres", "source": "2026-10-15-notas-reunion.txt", "source_date": "2026-10-15"},
 "what": {"value": "Entregar el punto 21", "source": "2026-10-15-notas-reunion.txt", "source_date": "2026-10-15"},
 "due_date": {"value": "2026-10-29", "source": "2026-10-15-notas-reunion.txt", "source_date": "2026-10-15"},
 "original_due_date": {"value": "2026-10-05"},
 "state": {"value": "open"},
 "source": {"value": "2026-10-15-notas-reunion.txt: «Liliana Torres dice que lo de «entregar el punto 21» no alcanzó, se compromete para el 29/10/2026»; fecha anterior 2026-10-05 en 30-reuniones/2026-10-12-comite-semanal.md"},
 "reschedules": [{"due_date": "2026-10-05"}]
 },
 {
 "who": {"value": "Laura Vélez", "source": "2026-10-15-notas-reunion.txt", "source_date": "2026-10-15"},
 "what": {"value": "Mandar el ajuste del presupuesto", "source": "2026-10-15-notas-reunion.txt", "source_date": "2026-10-15"},
 "due_date": {"value": "no_declarada", "source": "2026-10-15-notas-reunion.txt", "source_date": "2026-10-15"},
 "state": {"value": "open"},
 "source": {"value": "2026-10-15-notas-reunion.txt: «Laura Vélez queda de mandar el ajuste del presupuesto la otra semana»"}
 },
 {
 "who": {"value": "Óscar Ramírez", "source": "2026-10-15-notas-reunion.txt", "source_date": "2026-10-15"},
 "what": {"value": "Revisión con el proveedor", "source": "2026-10-15-notas-reunion.txt", "source_date": "2026-10-15"},
 "due_date": {"value": "2026-10-25", "source": "2026-10-15-notas-reunion.txt", "source_date": "2026-10-15"},
 "state": {"value": "open"},
 "source": {"value": "2026-10-15-notas-reunion.txt: «Óscar Ramírez: revisión con el proveedor, queda para el 2026-10-25»"}
 }
 ],
 "raid": {
 "risks": [
 {"what": "El proveedor podría no llegar con el equipo completo para la siguiente fase", "source": "2026-10-15-notas-reunion.txt"}
 ]
 },
 "activity": {"last_document_date": {"value": "2026-10-15"}},
 "meta": {
 "record_updated": "2026-10-15",
 "fields_not_found": ["declared.status", "declared.progress_pct", "declared.as_of", "declared.source"]
 }
}
