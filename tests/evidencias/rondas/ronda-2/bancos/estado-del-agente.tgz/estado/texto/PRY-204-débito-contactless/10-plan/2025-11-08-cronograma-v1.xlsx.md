<!-- origen: PRY-204-débito-contactless/10-plan/2025-11-08-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-03-15 | 2026-03-15 | cerrado
Ambiente de pruebas certificado | 2026-07-10 | 2026-07-10 | cerrado
Integración con el core | 2026-11-05 | 2026-11-05 | en curso
