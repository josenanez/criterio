<!-- origen: PRY-203-open-banking/10-plan/2025-12-22-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-03-20 | 2026-03-20 | cerrado
Ambiente de pruebas certificado | 2026-06-06 | 2026-06-06 | cerrado
Integración con el core | 2026-08-23 | 2026-08-23 | cerrado
Piloto con usuarios internos | 2026-11-09 | 2026-11-09 | en curso
