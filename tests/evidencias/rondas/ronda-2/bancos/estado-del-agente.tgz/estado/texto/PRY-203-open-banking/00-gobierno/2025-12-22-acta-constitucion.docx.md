<!-- origen: PRY-203-open-banking/00-gobierno/2025-12-22-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Open Banking

Código: PRY-203

Área dueña: Banca de Personas

Patrocinador: Felipe Arango

Gerente de proyecto: Elena Duarte

Comité: Comité de Arquitectura

Producto asociado: APIs de datos

Fecha de aprobación: 2025-12-22

Objetivo del negocio

Entregar open banking para Banca de Personas.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

3.300.000.000 COP, aprobado por Comité de Arquitectura el 2025-12-22.

Fechas comprometidas

Fecha

Inicio

2026-01-01

Cierre

2026-12-18

Criterio de éxito

Open Banking en producción y medido.

Dependencias declaradas

• Ninguna declarada
