<!-- origen: PRY-202-migración-a-la-nube/20-seguimiento/2026-10-14-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Migración a la nube

**Código:** PRY-202
**Fecha de corte:** 2026-10-14
**Gerente:** Mauricio Pérez

## Estado declarado

**Verde**

Avance reportado: **82%**

## Lo que pasó en el periodo

- Se recibió la aprobación regulatoria pendiente desde el trimestre anterior
- Se reprogramó la salida por ventana de cambio del área de operaciones
- Dos historias quedaron fuera del alcance del sprint por dependencia con el core

## Presupuesto

| | COP |
|---|---|
| Aprobado | 18.000.000.000 |
| Comprometido | 9.783.706.068 |
| Ejecutado | 9.343.786.948 |
| Proyección al cierre | 17.240.746.390 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
- El proveedor no ha confirmado la fecha de la última entrega
