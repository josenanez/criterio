<!-- origen: PRY-206-billetera-y-qr/30-reuniones/2026-10-12-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Arquitectura · Billetera y QR

**Fecha:** 2026-10-12
**Asistentes:** Camilo Beltrán, Natalia Ospina

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Liliana Torres | Entregar el punto 21 | 2026-10-05 |
