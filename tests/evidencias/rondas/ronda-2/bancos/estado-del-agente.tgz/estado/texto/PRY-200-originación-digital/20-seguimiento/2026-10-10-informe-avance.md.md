<!-- origen: PRY-200-originación-digital/20-seguimiento/2026-10-10-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Originación digital

**Código:** PRY-200
**Fecha de corte:** 2026-10-10
**Gerente:** Óscar Ramírez

## Estado declarado

**Rojo**

Avance reportado: **43%**

## Lo que pasó en el periodo

- La prueba de carga no alcanzó el umbral pactado y se repite

## Presupuesto

| | COP |
|---|---|
| Aprobado | 3.300.000.000 |
| Comprometido | 1.968.323.704 |
| Ejecutado | 636.458.838 |
| Proyección al cierre | 3.368.898.966 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
