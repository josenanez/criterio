<!-- origen: PRY-211-cobranza-digital/00-gobierno/2026-05-11-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Cobranza digital

Código: PRY-211

Área dueña: Tecnología

Patrocinador: Óscar Ramírez

Gerente de proyecto: Paula Céspedes

Comité: Comité de Medios de Pago

Producto asociado: recaudos

Fecha de aprobación: 2026-05-11

Objetivo del negocio

Entregar cobranza digital para Tecnología.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

3.300.000.000 COP, aprobado por Comité de Medios de Pago el 2026-05-11.

Fechas comprometidas

Fecha

Inicio

2026-05-21

Cierre

2027-04-28

Criterio de éxito

Cobranza digital en producción y medido.

Dependencias declaradas

• Ninguna declarada
