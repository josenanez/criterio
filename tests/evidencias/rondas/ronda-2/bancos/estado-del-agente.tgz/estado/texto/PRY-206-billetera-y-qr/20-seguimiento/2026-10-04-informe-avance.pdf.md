<!-- origen: PRY-206-billetera-y-qr/20-seguimiento/2026-10-04-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Billetera y QR
Código: PRY-206
Fecha de corte: 2026-10-04
Gerente: Camilo Beltrán

Estado declarado
Rojo
Avance reportado: 31%

Lo que pasó en el periodo
- Se recibió la aprobación regulatoria pendiente desde el trimestre anterior
- El proveedor entregó el componente de integración, pendiente de aceptación

Presupuesto
COP
Aprobado 6.800.000.000
Comprometido 3.979.137.385
Ejecutado 2.925.165.723
Proyección al cierre 7.686.267.486

Riesgos abiertos
- Cambio regulatorio en discusión que puede mover el alcance
