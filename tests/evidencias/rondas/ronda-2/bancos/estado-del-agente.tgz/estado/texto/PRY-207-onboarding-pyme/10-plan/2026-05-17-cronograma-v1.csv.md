<!-- origen: PRY-207-onboarding-pyme/10-plan/2026-05-17-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2026-08-09,2026-08-09,cerrado
Ambiente de pruebas certificado,2026-10-22,2026-10-22,en curso
Integración con el core,2027-01-05,2027-01-05,en curso
Piloto con usuarios internos,2027-03-20,2027-03-20,en curso
