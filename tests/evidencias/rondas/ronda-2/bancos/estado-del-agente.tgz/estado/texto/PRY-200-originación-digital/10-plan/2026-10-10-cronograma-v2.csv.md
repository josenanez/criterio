<!-- origen: PRY-200-originación-digital/10-plan/2026-10-10-cronograma-v2.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2026-01-10,2026-01-10,cerrado
Ambiente de pruebas certificado,2026-03-11,2026-03-11,cerrado
Integración con el core,2026-05-10,2026-08-16,cerrado
