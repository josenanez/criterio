<!-- origen: PRY-202-migración-a-la-nube/10-plan/2026-01-14-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-05-21 | 2026-05-21 | cerrado
Ambiente de pruebas certificado | 2026-09-15 | 2026-09-15 | cerrado
Integración con el core | 2027-01-11 | 2027-01-11 | en curso
Piloto con usuarios internos | 2027-05-08 | 2027-05-08 | en curso
