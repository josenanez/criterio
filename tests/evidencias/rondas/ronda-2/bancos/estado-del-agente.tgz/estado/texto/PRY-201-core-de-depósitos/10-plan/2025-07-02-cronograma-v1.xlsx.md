<!-- origen: PRY-201-core-de-depósitos/10-plan/2025-07-02-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2025-11-12 | 2025-11-12 | cerrado
Ambiente de pruebas certificado | 2026-03-16 | 2026-03-16 | cerrado
Integración con el core | 2026-07-17 | 2026-07-17 | cerrado
Piloto con usuarios internos | 2026-11-18 | 2026-11-18 | en curso
