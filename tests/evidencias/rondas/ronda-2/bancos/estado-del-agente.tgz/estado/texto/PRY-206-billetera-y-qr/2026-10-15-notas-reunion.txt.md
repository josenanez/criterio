<!-- origen: PRY-206-billetera-y-qr/2026-10-15-notas-reunion.txt · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

notas reunión billetera y qr — 2026-10-15
estuvieron: Camilo Beltrán, Liliana Torres, Laura Vélez, Óscar Ramírez

- Liliana Torres dice que lo de «entregar el punto 21» no alcanzó, se compromete para el 29/10/2026
- Laura Vélez queda de mandar el ajuste del presupuesto la otra semana
- Óscar Ramírez: revisión con el proveedor, queda para el 2026-10-25
- se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo
- próxima reunión en dos semanas
