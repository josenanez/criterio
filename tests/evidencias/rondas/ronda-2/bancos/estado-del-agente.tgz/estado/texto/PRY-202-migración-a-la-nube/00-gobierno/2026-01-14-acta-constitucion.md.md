<!-- origen: PRY-202-migración-a-la-nube/00-gobierno/2026-01-14-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Migración a la nube

**Código:** PRY-202
**Área dueña:** Banca Empresas
**Patrocinador:** Jorge Medina
**Gerente de proyecto:** Mauricio Pérez
**Comité:** Comité de Transformación Digital
**Producto asociado:** No aplica
**Fecha de aprobación:** 2026-01-14

## Objetivo del negocio

Entregar migración a la nube para Banca Empresas.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**18.000.000.000 COP**, aprobado por Comité de Transformación Digital el 2026-01-14.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-01-24 |
| Cierre | 2027-07-06 |

## Criterio de éxito

Migración a la nube en producción y medido.

## Dependencias declaradas

- Ninguna declarada
