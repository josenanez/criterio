<!-- origen: PRY-208-motor-de-decisión/30-reuniones/2026-10-10-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Transformación Digital · Motor de decisión

Fecha: 2026-10-10

Asistentes: Carlos Peña, Javier Hoyos

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

María Restrepo

Entregar el punto 38

2026-09-22

Rubén Cárdenas

Entregar el punto 12

2026-11-09
