<!-- origen: PRY-202-migración-a-la-nube/30-reuniones/2026-10-11-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Transformación Digital · Migración a la nube

**Fecha:** 2026-10-11
**Asistentes:** Mauricio Pérez, Jorge Medina

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Gustavo Neira | Entregar el punto 5 | 2026-10-25 |
