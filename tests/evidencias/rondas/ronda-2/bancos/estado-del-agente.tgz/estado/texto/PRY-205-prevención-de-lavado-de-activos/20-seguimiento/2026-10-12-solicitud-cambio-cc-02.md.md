<!-- origen: PRY-205-prevención-de-lavado-de-activos/20-seguimiento/2026-10-12-solicitud-cambio-cc-02.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-02

**Proyecto:** PRY-205 · Prevención de lavado de activos
**Fecha:** 2026-10-12
**Solicitante:** Camilo Beltrán

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +36 días sobre la línea base vigente |
| Costo | 72.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
