<!-- origen: PRY-200-originación-digital/00-gobierno/2025-11-02-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Originación digital

**Código:** PRY-200
**Área dueña:** Tesorería
**Patrocinador:** Natalia Ospina
**Gerente de proyecto:** Óscar Ramírez
**Comité:** Comité de Banca Empresas
**Producto asociado:** crédito de consumo
**Fecha de aprobación:** 2025-11-02

## Objetivo del negocio

Entregar originación digital para Tesorería.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**3.300.000.000 COP**, aprobado por Comité de Banca Empresas el 2025-11-02.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-11-12 |
| Cierre | 2026-06-09 |

## Criterio de éxito

Originación digital en producción y medido.

## Dependencias declaradas

- Ninguna declarada
