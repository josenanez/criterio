<!-- origen: PRY-210-portal-de-proveedores/10-plan/2025-05-22-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2025-07-17,2025-07-17,cerrado
Ambiente de pruebas certificado,2025-09-01,2025-09-01,cerrado
Integración con el core,2025-10-17,2025-10-17,cerrado
Piloto con usuarios internos,2025-12-02,2025-12-02,cerrado
