<!-- origen: PRY-201-core-de-depósitos/20-seguimiento/2026-10-04-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Core de depósitos
Código: PRY-201
Fecha de corte: 2026-10-04
Gerente: Sandra Gil

Estado declarado
Amarillo
Avance reportado: 71%

Lo que pasó en el periodo
- El equipo perdió dos semanas por rotación de un desarrollador clave
- El proveedor entregó el componente de integración, pendiente de aceptación
- Se ajustó el plan de pruebas con el área de seguridad

Presupuesto
COP
Aprobado 800.000.000
Comprometido 540.313.160
Ejecutado 346.245.546
Proyección al cierre 824.430.173

Riesgos abiertos
- Dependencia del calendario de liberaciones del core
- Disponibilidad del equipo de seguridad para la revisión final
