<!-- origen: PRY-201-core-de-depósitos/30-reuniones/2026-10-04-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Medios de Pago · Core de depósitos

Fecha: 2026-10-04

Asistentes: Sandra Gil, Elena Duarte

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Gustavo Neira

Entregar el punto 30

por definir
