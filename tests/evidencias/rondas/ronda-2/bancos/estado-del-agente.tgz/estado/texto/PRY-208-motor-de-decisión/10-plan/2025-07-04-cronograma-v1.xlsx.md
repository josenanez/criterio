<!-- origen: PRY-208-motor-de-decisión/10-plan/2025-07-04-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2025-10-10 | 2025-10-10 | cerrado
Ambiente de pruebas certificado | 2026-01-07 | 2026-01-07 | cerrado
Integración con el core | 2026-04-05 | 2026-04-05 | cerrado
