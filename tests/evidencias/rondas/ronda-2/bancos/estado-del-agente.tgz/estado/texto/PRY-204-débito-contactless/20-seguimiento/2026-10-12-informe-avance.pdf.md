<!-- origen: PRY-204-débito-contactless/20-seguimiento/2026-10-12-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Débito contactless
Código: PRY-204
Fecha de corte: 2026-10-12
Gerente: Paula Céspedes

Estado declarado
Rojo
Avance reportado: 58%

Lo que pasó en el periodo
- Se levantó un hallazgo de seguridad en la revisión de arquitectura

Presupuesto
COP
Aprobado 800.000.000
Comprometido 444.443.611
Ejecutado 268.589.102
Proyección al cierre 1.020.707.324

Riesgos abiertos
- Concentración del conocimiento en una sola persona
