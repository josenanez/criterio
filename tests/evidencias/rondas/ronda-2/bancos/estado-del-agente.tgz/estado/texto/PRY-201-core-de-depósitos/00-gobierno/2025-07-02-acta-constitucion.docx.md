<!-- origen: PRY-201-core-de-depósitos/00-gobierno/2025-07-02-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Core de depósitos

Código: PRY-201

Área dueña: Riesgo y Cumplimiento

Patrocinador: Elena Duarte

Gerente de proyecto: Sandra Gil

Comité: Comité de Medios de Pago

Producto asociado: cuenta de ahorros

Fecha de aprobación: 2025-07-02

Objetivo del negocio

Entregar core de depósitos para Riesgo y Cumplimiento.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

800.000.000 COP, aprobado por Comité de Medios de Pago el 2025-07-02.

Fechas comprometidas

Fecha

Inicio

2025-07-12

Cierre

2027-01-19

Criterio de éxito

Core de depósitos en producción y medido.

Dependencias declaradas

• Ninguna declarada
