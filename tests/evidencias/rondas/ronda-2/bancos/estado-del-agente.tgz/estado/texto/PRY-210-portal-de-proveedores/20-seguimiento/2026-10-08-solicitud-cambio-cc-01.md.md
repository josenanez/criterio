<!-- origen: PRY-210-portal-de-proveedores/20-seguimiento/2026-10-08-solicitud-cambio-cc-01.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-01

**Proyecto:** PRY-210 · Portal de proveedores
**Fecha:** 2026-10-08
**Solicitante:** Óscar Ramírez

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +22 días sobre la línea base vigente |
| Costo | 44.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
