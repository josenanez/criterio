<!-- origen: PRY-210-portal-de-proveedores/30-reuniones/2026-10-13-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Banca Empresas · Portal de proveedores

Fecha: 2026-10-13

Asistentes: Óscar Ramírez, Rubén Cárdenas

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Rubén Cárdenas

Entregar el punto 10

por definir
