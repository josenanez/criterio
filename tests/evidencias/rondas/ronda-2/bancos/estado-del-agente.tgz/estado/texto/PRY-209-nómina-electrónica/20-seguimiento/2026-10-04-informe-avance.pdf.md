<!-- origen: PRY-209-nómina-electrónica/20-seguimiento/2026-10-04-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Nómina electrónica
Código: PRY-209
Fecha de corte: 2026-10-04
Gerente: Paula Céspedes

Estado declarado
Verde
Avance reportado: 45%

Lo que pasó en el periodo
- Se ajustó el plan de pruebas con el área de seguridad
- El proveedor entregó el componente de integración, pendiente de aceptación
- El equipo perdió dos semanas por rotación de un desarrollador clave

Presupuesto
COP
Aprobado 800.000.000
Comprometido 617.749.136
Ejecutado 241.881.517
Proyección al cierre 742.906.512

Riesgos abiertos
- Disponibilidad del equipo de seguridad para la revisión final
- El proveedor no ha confirmado la fecha de la última entrega
