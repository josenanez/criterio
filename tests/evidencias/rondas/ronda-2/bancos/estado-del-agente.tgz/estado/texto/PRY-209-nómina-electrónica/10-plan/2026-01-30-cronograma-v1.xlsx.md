<!-- origen: PRY-209-nómina-electrónica/10-plan/2026-01-30-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-05-07 | 2026-05-07 | cerrado
Ambiente de pruebas certificado | 2026-08-03 | 2026-08-03 | cerrado
Integración con el core | 2026-10-29 | 2026-10-29 | en curso
Piloto con usuarios internos | 2027-01-25 | 2027-01-25 | en curso
