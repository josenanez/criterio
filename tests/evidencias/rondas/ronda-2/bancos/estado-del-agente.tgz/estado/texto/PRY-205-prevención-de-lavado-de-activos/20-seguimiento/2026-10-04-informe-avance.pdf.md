<!-- origen: PRY-205-prevención-de-lavado-de-activos/20-seguimiento/2026-10-04-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Prevención de lavado de activos
Código: PRY-205
Fecha de corte: 2026-10-04
Gerente: Camilo Beltrán

Estado declarado
Amarillo
Avance reportado: 63%

Lo que pasó en el periodo
- Se recibió la aprobación regulatoria pendiente desde el trimestre anterior
- Dos historias quedaron fuera del alcance del sprint por dependencia con el core
- Se reprogramó la salida por ventana de cambio del área de operaciones

Presupuesto
COP
Aprobado 3.300.000.000
Comprometido 1.253.821.894
Ejecutado 1.952.355.864
Proyección al cierre 3.460.336.570

Riesgos abiertos
- Dependencia del calendario de liberaciones del core
