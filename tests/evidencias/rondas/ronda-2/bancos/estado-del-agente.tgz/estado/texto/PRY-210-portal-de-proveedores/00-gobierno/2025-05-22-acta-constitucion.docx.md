<!-- origen: PRY-210-portal-de-proveedores/00-gobierno/2025-05-22-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Portal de proveedores

Código: PRY-210

Área dueña: Riesgo y Cumplimiento

Patrocinador: Rubén Cárdenas

Gerente de proyecto: Óscar Ramírez

Comité: Comité de Banca Empresas

Producto asociado: No aplica

Fecha de aprobación: 2025-05-22

Objetivo del negocio

Entregar portal de proveedores para Riesgo y Cumplimiento.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

2.400.000.000 COP, aprobado por Comité de Banca Empresas el 2025-05-22.

Fechas comprometidas

Fecha

Inicio

2025-06-01

Cierre

2025-12-26

Criterio de éxito

Portal de proveedores en producción y medido.

Dependencias declaradas

• Ninguna declarada
