<!-- origen: PRY-206-billetera-y-qr/10-plan/2025-06-02-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2025-09-14 | 2025-09-14 | cerrado
Ambiente de pruebas certificado | 2025-12-17 | 2025-12-17 | cerrado
Integración con el core | 2026-03-21 | 2026-03-21 | cerrado
Piloto con usuarios internos | 2026-06-23 | 2026-06-23 | cerrado
Salida a producción | 2026-09-25 | 2026-09-25 | cerrado
