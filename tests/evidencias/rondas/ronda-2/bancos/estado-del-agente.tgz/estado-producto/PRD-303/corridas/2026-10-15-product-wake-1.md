# Corrida del 2026-10-15 · product-wake

PRD-303 · 5 requerimientos · 29 s · 16 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 5 |
| `decision_without_source` | 5 |
| `requirement_untraced` | 5 |
| `requirement_without_acceptance` | 1 |

Primera corrida, sin corte anterior: reportó el estado de partida (5 REQ aceptados, evidencia de 14 meses, sin fuente de decisión, sin proyecto). No leyó el acta del comité del 2026-10-13 ni confirmó trazas por falta de carpeta de fichas.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## Cuenta PyME (PRD-303) · 2026-10-15

**Primera corrida: no hay corte anterior.** Por eso no puedo separar lo nuevo de lo viejo. Todo lo de abajo es el estado de partida, y desde la próxima corrida solo reportaré lo que cruce un umbral después de hoy.

Registro: 5 requerimientos, todos en estado `aceptado`, ninguno trazado a un proyecto.

### Qué hay en el registro
| Qué | REQ | Cuánto lleva | Qué se necesita | Quién |
|---|---|---|---|---|
| Evidencia vencida: la única entrevista es del 2025-08-11 (14 meses, umbral 12). Dice «Lo necesito y hoy no lo tengo», sin nombrar el requerimiento ni a quién habló. | 1030, 1031, 1032, 1033, 2018 | 14 meses | Decidir qué afirmación de la definición queda sin sustento. Hace falta evidencia de demanda nueva. | Camilo Beltrán, Liliana Torres, Paula Céspedes, Carlos Peña, María Restrepo (dolientes) |
| Aceptado sin decisión con fuente: no consta quién ni cuándo lo decidió | 1030, 1031, 1032, 1033, 2018 | 102 a 190 días desde que se planteó (REQ-2018: 22) | Que alguien con la facultad de decidir lo confirme. La autoridad del producto figura como `null` en la configuración. | Sin dueño de la decisión. Lo primero es nombrar quién tiene la facultad. |
| Aceptado sin criterio de aceptación | 2018 | 22 días | Escribir el criterio antes de especificar | María Restrepo |
| Aceptado y sin proyecto que lo construya | 1030, 1031, 1032, 1033, 2018 | n/a | Llevar al comité. Hoy nadie lo construye. | Beatriz Cuéllar |

### Contradicción entre negocio y datos
El caso de negocio (2026-02-02) declara `volumen_mensual` = 276.747. El tablero de la bodega de datos del 2026-10-09 mide 246.553. La brecha es de 10,9%, bajo el umbral de 20%, así que **no es hallazgo**. La dejo anotada.

### Las trazas
No tengo la carpeta de fichas de proyectos en la configuración. **Ninguna traza se da por confirmada.**

### Del descubrimiento
No contrasté los documentos contra el registro en esta corrida. Existe el acta del comité de producto del 2026-10-13 (`30-decisiones/2026-10-13-comite-producto.docx`), que no leí a fondo. No sé si ya decide alguno de los cinco requerimientos.

**Vuelvo el 2026-11-14.**
