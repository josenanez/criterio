## Definición — Cuenta PyME (PRD-303) · contrastada al 2026-10-15
**Documento:** 00-definicion/2026-02-02-definicion-producto.docx (+ caso de negocio del mismo día) · **del** 2026-02-02 · 6 afirmaciones

### Lo que la evidencia contradice
Nada. La única cifra comparable difiere 10,9 %, bajo el umbral de 20 %: es imprecisión, no contradicción.

### El negocio y los datos
| Métrica | Declarado | Medido | Diferencia | Las dos fuentes y fechas |
|---|---|---|---|---|
| (ninguna pasa el umbral de 20 %) | | | | |

Para que conste, lo que quedó bajo el umbral: `volumen_mensual` declarado 276.747 (caso de negocio, 2026-02-02) vs. medido 246.553 (tablero de métricas, bodega de datos, corte 2026-10-09): 10,9 % por debajo. Es una sola medición, no una tendencia.

### Afirmaciones numéricas que nadie mide
| Afirma | De qué documento | No hay serie |
|---|---|---|
| «Retorno esperado en 24 meses» | caso de negocio, 2026-02-02 | Sin cifra declarada y sin serie: ni se puede contrastar ni nadie lo está midiendo |

### No está dicho en ninguna parte
- **Criterio de éxito:** no figura en la definición ni en el caso de negocio.
- **Quién decide (autoridad):** `authority` sin declarar en la configuración ni en los documentos.
- **Qué es «Propuesta principal»:** la definición solo trae ese rótulo, sin contenido.
- **Cuántas PyMEs hay en el segmento ni cuánto pagarían:** no hay cifra de mercado ni de precio.
- **Qué proyecto lo construye:** la definición dice «Ninguno declarado», y los cinco requerimientos aceptados tampoco tienen proyecto.
- **Cuánto retorno, y sobre qué inversión:** la frase del retorno no trae número ni inversión.

### Sostenida por un supuesto
| Supuesto | Días sin verificar | Qué haría falta para verificarlo |
|---|---|---|
| «El segmento paga por esto» (declarado 2026-09-21, sin verificar) | 24 (umbral 30; aún no lo cruza, lo hará el 2026-10-21) | Un pago real o un compromiso firmado de una PyME: precio, plan y fecha. Una entrevista no lo verifica. |

Nota: la definición está fechada 2026-02-02 pero el supuesto lleva fecha 2026-09-21; no se sabe si se añadió después. El supuesto sostiene el producto entero.

### Sostenida por evidencia
| Afirmación | Sostenida por | De cuándo | Qué tan fuerte |
|---|---|---|---|
| «El segmento Empresas no tiene cuenta pyme» (problema) | Entrevista a «Cliente entrevistado»: «Lo necesito y hoy no lo tengo.» (tema: Necesidad principal) | 2025-08-11 | Débil: lo dicho es una declaración de uso futuro, de una persona sin nombre, que no menciona el producto ni el segmento. |

### Evidencia que ya envejeció
| Afirmación | Lo más nuevo que la sostiene | Hace |
|---|---|---|
| El problema y los 5 requerimientos aceptados (REQ-1030, 1031, 1032, 1033, 2018) | Entrevista del 2025-08-11 | 14 meses (umbral 12) |

Los cinco requerimientos citan la misma entrevista y el acta del comité (2026-10-13) no dice quién los pidió con nombre.

### Lo normativo que toca
| Qué toca | País | Obligación | Norma | Estado |
|---|---|---|---|---|
| Cuenta empresarial: posibles pagos, consumidor financiero, datos personales y retención de información | No declarado | — | — | **No tengo la norma a la vista.** No se sabe en qué país opera; esto no dice que cumpla ni que no cumpla. Va a revisión jurídica. |

### Lo que falta para cerrar la definición
- **Criterio de éxito:** falta. Sin él el producto no se puede cerrar, porque el cierre se juzga contra él.
- **Quién decide:** falta.
- El problema y para quién están escritos, pero con evidencia de 14 meses.
- Aparte: el cálculo no listó estos campos en `unknown` aunque el registro dice `not_found` para `success` y `authority`. Se reporta lo que dice el registro.

*Ofrecimiento:* el supuesto de pago llegará al umbral de 30 días el 2026-10-21; si se quiere, se puede registrar como riesgo con doliente (raid-taxonomy). `/product-charter` no corresponde todavía: faltan criterio de éxito y autoridad.
