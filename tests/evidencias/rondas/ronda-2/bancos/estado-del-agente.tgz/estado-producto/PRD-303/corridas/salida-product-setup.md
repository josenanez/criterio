## Listo — Cuenta PyME (PRD-303)

**Lo que miré:** 5 documentos · 1 de descubrimiento (una sola entrevista, 2025-08-11) · la definición del 2026-02-02. Lo más reciente: el tablero de métricas del 2026-10-09. Todos se leyeron (el .docx por su texto interno).
**Términos:** aceptados para la versión 0.3.8 (términos 1.1) por José Francisco Ñáñez, 2026-10-15 · comprobante en `.criterio/terminos/aceptacion-criterio-product-0.3.8-2026-10-15.md` y `.pdf` · SHA-256 de los términos d31e6b36110416…
**Quién decide:** no está dicho en ninguna parte (ver abajo).
**Estado:** `estado-producto/PRD-303` (hermana de la documentación, no dentro).

### Lo que tu definición afirma, y qué lo sostiene
| Afirmación | Sostenida por | De cuándo |
|---|---|---|
| El segmento Empresas no tiene cuenta pyme | Una entrevista: «Lo necesito y hoy no lo tengo.» No dice qué producto ni qué segmento | 2025-08-11 (14 meses) |
| El segmento paga por esto | Nada. Es un supuesto declarado el 2026-09-21, sin verificar | 2026-09-21 |
| volumen_mensual = 276.747 | Caso de negocio (Beatriz Cuéllar). Medido: 246.553 en el tablero de producto; el negocio declara 10,9% por encima de lo medido (por debajo del umbral de 20%, no es contradicción) | declarado 2026-02-02 · medido 2026-10-09 |
| Retorno esperado en 24 meses | Nada: sin cifra, sin base de cálculo | 2026-02-02 |

### Lo que no está dicho en ninguna parte
- **Criterio de éxito:** la definición no lo trae; el cierre no tendrá contra qué juzgarse.
- **Quién decide qué se construye:** el acta del comité (2026-10-13) lista como único asistente a la gerente de producto; ningún documento nombra la autoridad. Sin ella no hay acta de constitución posible.
- **Que el segmento paga:** es el supuesto central y está sin verificar.
- **Cuánto retorna y cómo:** «Retorno esperado en 24 meses» sin cifra.
- **Qué hace la propuesta:** la definición dice «Propuesta principal» y nada más.
- **Quién pidió cada requerimiento:** el acta pone «Cliente entrevistado» en los cinco, que es una categoría, no una persona; la única entrevista no nombra requerimiento ni cliente.
- **Una decisión por requerimiento:** los cinco figuran «aceptado», pero ningún documento registra quién los aceptó ni cuándo; la única decisión del acta es «Se mantiene el plan» (5 de 5 sin fuente de decisión).
- **Un proyecto que ejecute cualquiera de los cinco:** 0 de 5 con traza (0,0%); la definición dice «Ninguno declarado».
- **Criterio de aceptación de REQ-2018:** aceptado, sin criterio.
- **Evidencia vigente:** la única entrevista tiene 14 meses; sostiene los 5 requerimientos y los 5 salen con evidencia vencida (umbral 12 meses).

### Supuestos sobre los que está escrita
Uno declarado: «El segmento paga por esto», 2026-09-21, sin verificar. Lleva 24 días, así que aún no cruza el umbral de 30. Detalle raro: la definición es del 2026-02-02 y el supuesto está fechado ocho meses después; alguien editó la definición sin cambiar su fecha, o el supuesto se añadió tarde.

### Qué le falta a tu carpeta
- Las transcripciones de las entrevistas: hay una frase de una entrevista, no un descubrimiento.
- La serie de la métrica principal: hay un solo punto (2026-10-09), no una serie; no se ve la tendencia.
- Las decisiones del comité por requerimiento: sin ellas un aceptado y uno que nadie decidió se ven igual.
- Un documento que nombre a quien decide.

Totales del cálculo: 5 requerimientos, todos aceptados; 5 con evidencia (100,0%); 0 con traza (0,0%). Señales: evidence_stale 5 · decision_without_source 5 · requirement_untraced 5 · requirement_without_acceptance 1.

**Preguntas:** 0 hechas (sesión sin interfaz; tomé la respuesta sugerida en cada una).
**Siguiente:** `/product-discovery` sobre el material de entrevistas.
