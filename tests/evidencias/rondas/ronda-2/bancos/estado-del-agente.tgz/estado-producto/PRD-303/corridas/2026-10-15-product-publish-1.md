# Corrida del 2026-10-15 · product-publish

PRD-303 · 5 requerimientos · 19 s · 16 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 5 |
| `decision_without_source` | 5 |
| `requirement_untraced` | 5 |
| `requirement_without_acceptance` | 1 |

No se publicó: la configuración no define carpeta de productos publicados

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

**No publiqué la ficha de PRD-303 (Cuenta PyME): la configuración no tiene una carpeta de productos publicados.**

`config.json` solo declara `documents` y `state`. Sin un sitio común acordado, publicar no sirve, y acordarlo es una conversación de la organización, no un comando. No lo inventé ni escribí nada fuera de `estado-producto/PRD-303/corridas/`. (Los términos estaban vigentes: v1.1, aceptados por José Francisco Ñáñez el 2026-10-15.)

**Lo que habría llevado la ficha (corte al 2026-10-15):**
- **Requerimientos:** 5 (REQ-1030, REQ-1031, REQ-1032, REQ-1033, REQ-2018), todos en estado «aceptado» y sin proyecto asignado.
- **Proyectos:** 0.
- **Métricas afirmadas:** 1.
  - `volumen_mensual` declarado en 276747.0, tomado de `documentos/productos/PRD-303/00-definicion/2026-02-02-caso-de-negocio.md`, tabla «Cifras que sostienen el caso» (2026-02-02).
- **Segmento declarado:** Segmento Empresas.
- **Gerente:** Beatriz Cuéllar.

La ficha no lleva la cifra medida (246553.0 al 2026-10-09, 10.9 % por debajo de lo declarado), porque las series medidas no se publican.

**Para publicar:** definir la carpeta común de productos publicados (por ejemplo `productos/publicados/`) y registrarla en la configuración; luego se vuelve a correr `/product-publish`.
