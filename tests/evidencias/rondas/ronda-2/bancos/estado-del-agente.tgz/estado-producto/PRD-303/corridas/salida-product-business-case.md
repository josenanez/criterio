# Caso de negocio — Cuenta PyME (PRD-303) · borrador del 2026-10-15
**Desde:** definición y caso de negocio del 2026-02-02 · **Cifras con fuente:** 1 de 1 cifra numérica (el retorno esperado no trae cifra)

*Términos: ya vigentes para esta versión (1.1, familia 0.3.8, aceptados por José Francisco Ñáñez el 2026-10-15). Preguntas de la sesión: nadie responde; se tomó la respuesta sugerida.*

## Qué problema resuelve, y para quién
- **Problema:** «El segmento Empresas no tiene cuenta pyme.» (definición, 2026-02-02, «El problema»).
- **Para quién:** Segmento Empresas (definición, «Segmento»).
- **Propuesta:** la definición solo trae el rótulo «Propuesta principal», sin contenido (definición, «La propuesta»).

## Qué se construye
| Requerimiento | Estado | Evidencia de demanda |
|---|---|---|
| REQ-1030 (Camilo Beltrán) | aceptado, comité 2026-10-13 | «Cliente entrevistado»: «Lo necesito y hoy no lo tengo.» (entrevista 2025-08-11) |
| REQ-1031 (Liliana Torres) | aceptado, 2026-10-13 | la misma entrevista |
| REQ-1032 (Paula Céspedes) | aceptado, 2026-10-13 | la misma entrevista |
| REQ-1033 (Carlos Peña) | aceptado, 2026-10-13 | la misma entrevista |
| REQ-2018 (María Restrepo) | aceptado, 2026-10-13 | la misma entrevista; sin criterio de aceptación |

Las cinco evidencias son una sola entrevista de hace 14 meses (umbral 12), de una persona sin nombre, que no menciona ningún requerimiento. Es demanda de la cuenta, no de cada requerimiento. El acta no deja dicho quién decidió. Ninguno tiene proyecto que lo ejecute.

## Las cifras
| Cifra | Valor | Clase | De dónde sale | De cuándo |
|---|---|---|---|---|
| volumen_mensual | 276.747 | Declarada | Caso de negocio, tabla «Cifras que sostienen el caso» (Beatriz Cuéllar) | 2026-02-02 |
| volumen_mensual | 246.553 | Medida | Bodega de datos, tablero de producto | corte 2026-10-09 |
| «Retorno esperado en 24 meses» | sin cifra | Declarada sin valor | Caso de negocio | 2026-02-02 |
| Que el segmento paga por el producto | sin cifra | Supuesta | Definición, «Supuestos» | 2026-09-21 |

La serie medida tiene un solo punto: no es tendencia.

### Donde la cifra declarada y la medida no coinciden
| Métrica | Declarada | Medida | Las dos fuentes y fechas |
|---|---|---|---|
| volumen_mensual | 276.747 | 246.553 (30.194 menos, 10,9 % por debajo) | Caso de negocio 2026-02-02 · tablero de métricas, corte 2026-10-09 |

Está bajo el umbral de 20 % configurado, así que es imprecisión, no contradicción. Pero va dentro del caso: la declarada es de febrero y la medida de octubre, y el comité preguntará cuál manda. Declarar qué volumen se esperaba y a qué fecha es del negocio.

## Los costos
| Concepto | Valor | De dónde sale |
|---|---|---|
| Costo de construir | **no consta** | Ningún documento |
| Costo del equipo | **no consta** | Ningún documento |
| Contratos o cotizaciones | **no consta** | Ningún documento |

El costo de construir no está en ningún documento. Es el primer vacío: sin él lo que hay es una propuesta, no un caso de negocio que evaluar.

## Supuestos sobre los que se sostiene
| Supuesto | Qué pasa si resulta falso | Quién lo verificaría |
|---|---|---|
| «El segmento paga por esto» (2026-09-21, sin verificar; 24 días, cruza el umbral de 30 el 2026-10-21) | No hay ingreso que sostenga el retorno ni el volumen; el producto entero pierde su razón | Beatriz Cuéllar, con un pago real o un compromiso firmado de una PyME (precio, plan, fecha). Una entrevista no lo verifica |
| Que la entrevista del 2025-08-11 representa a las cinco demandas | Los cinco requerimientos quedan sin demanda propia | El doliente de cada uno, con una entrevista nueva que nombre el requerimiento |
| Que el volumen declarado en febrero sigue vigente | El caso cuenta con 30.194 transacciones mensuales menos | El negocio |

## Vacíos
| Qué falta | Por qué importa | Quién lo produce |
|---|---|---|
| Costo de construir y operar | Sin costo no hay caso, hay propuesta | Quien lleve la decisión del comité; no consta nombre |
| Cifra del retorno esperado y la inversión sobre la que se mide | «Retorno esperado en 24 meses» no se puede contrastar ni medir | Beatriz Cuéllar |
| Criterio de éxito y fecha de corte | El cierre se juzga contra él | Beatriz Cuéllar |
| Alternativas consideradas y qué pasa si no se hace | El comité no tiene contra qué comparar | Beatriz Cuéllar |
| Tamaño del segmento y precio | No hay cifra de mercado ni de precio | El negocio |
| Quién decide (autoridad) | `authority` sin declarar | Beatriz Cuéllar |
| Proyecto que construye los cinco requerimientos | 0 % trazado | Quien lleve la decisión del 2026-10-13 |
| País donde opera | Cuenta empresarial toca pagos, consumidor financiero y datos personales; no se tiene la norma a la vista, va a revisión jurídica | Jurídico |

## Cómo se sabrá si funcionó
**No está declarado.** Ni la definición ni el caso de negocio traen criterio de éxito, métrica o fecha de corte. La única métrica con serie es volumen_mensual, pero nadie dijo que sea el criterio de éxito. Sin esto el producto no se puede cerrar meses después.

## Si hay otros productos publicados
No hay productos publicados a la vista en esta configuración, así que no se hizo el cruce de `/product-overlap`. Si otro producto afirma volumen_mensual sobre las mismas transacciones, la suma no existiría.

## Después
- Pasar a **assumption-tracking** el supuesto «El segmento paga por esto» (cruza el umbral de 30 días el 2026-10-21).
- `/product-charter` no corresponde todavía: faltan criterio de éxito, autoridad y costo.

*No se proyectó ingreso, retorno ni periodo de recuperación, ni se recomienda aprobar o rechazar; decidir es de quien tiene la autoridad.*
