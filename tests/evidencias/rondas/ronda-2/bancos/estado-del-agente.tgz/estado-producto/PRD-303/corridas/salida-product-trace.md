## Trazabilidad — Cuenta PyME (PRD-303) · al 2026-10-15
5 decididos · 0 con proyecto · 0 confirmados contra la ficha · 0 entregados

*Términos: ya vigentes para esta versión (1.1, familia 0.3.8, por José Francisco Ñáñez, 2026-10-15); no hizo falta volver a pedirlos.*
*Sesión sin interfaz: nadie responde; se tomó la respuesta sugerida en cada pregunta. No hay carpeta de fichas de proyecto a la vista (no existe ninguna ficha en el espacio): se arma la cadena hasta la decisión y la parte que falta queda declarada.*

### Decidido y nadie lo está construyendo
Los 5 requerimientos están `aceptado` en el acta del comité del 2026-10-13 y ninguno tiene proyecto en su traza (0% trazado). Ojo con el alcance de esa frase: sin fichas no se puede saber si un proyecto los ejecuta sin que el registro lo diga; lo que se afirma es que **el registro no nombra a ningún proyecto**.

| REQ | Título | Decidido el | Por quién |
|---|---|---|---|
| REQ-1030 | sin título propio en el acta | 2026-10-13 (acta del comité) | no consta |
| REQ-1031 | sin título propio en el acta | 2026-10-13 | no consta |
| REQ-1032 | sin título propio en el acta | 2026-10-13 | no consta |
| REQ-1033 | sin título propio en el acta | 2026-10-13 | no consta |
| REQ-2018 | sin título propio en el acta | 2026-10-13 | no consta |

El acta no deja dicho quién decidió (`who` vacío en los cinco) y la configuración tiene `authority` en blanco: el eslabón «decisión» tiene fecha y documento, pero no persona.

### La traza no se confirma
Ninguna fila: no hay traza declarada que confirmar, porque ningún requerimiento dice qué proyecto lo ejecuta. Tampoco hay fichas contra las cuales contrastar.

### Lo que un proyecto construye y el registro no tiene
No se puede evaluar: sin fichas de proyecto no hay a quién preguntarle qué producto dice ejecutar. Esta dirección de la brecha queda sin mirar, no en cero.

### La cadena completa
| REQ | Estado | Decisión | Proyecto | Confirmado | Entregables |
|---|---|---|---|---|---|
| REQ-1030 | aceptado | comité 2026-10-13 · `documentos/productos/PRD-303/30-decisiones/2026-10-13-comite-producto.docx` | — (cadena rota aquí) | no | — |
| REQ-1031 | aceptado | ídem | — (cadena rota aquí) | no | — |
| REQ-1032 | aceptado | ídem | — (cadena rota aquí) | no | — |
| REQ-1033 | aceptado | ídem | — (cadena rota aquí) | no | — |
| REQ-2018 | aceptado | ídem | — (cadena rota aquí) | no | — |

Los cinco se rompen en el mismo eslabón: de la decisión al proyecto no hay cita. Aparte, REQ-2018 no trae criterio de aceptación.

### Sin fichas a la vista
Ningún proyecto se pudo confirmar, porque no hay ficha de ninguno. En una corrida anterior se mencionó PRY-207 (onboarding PyME) como candidato **solo por el nombre**; sin ficha ni cita en el registro, no se toma como traza.

### Lo que sigue
- **Decididos sin proyecto (5):** cuando alguno esté listo para serlo, `/criterio-product:product-charter`. Antes conviene cerrar el criterio de aceptación de REQ-2018 (María Restrepo) y la evidencia, que es la misma entrevista del 2025-08-11 para los cinco y tiene 14 meses (umbral: 12).
- **Quién decidió y quién tiene la facultad:** lo cierra Beatriz Cuéllar (gerente del producto) completando el acta y `authority`.
- **Fichas:** que la PMO o cada gerente publique la ficha con `/pm-publish` es una conversación con ellos, no algo que este comando pida. Con las fichas en la carpeta, se vuelve a correr `/product-trace`.
