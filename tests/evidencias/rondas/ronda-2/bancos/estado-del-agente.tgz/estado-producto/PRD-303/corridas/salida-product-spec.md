> **Borrador del 2026-10-15, escrito por Alba. Lo cierra Beatriz Cuéllar (gerente de producto); este agente no aprueba.**

# Especificación — Cuenta PyME (PRD-303) · borrador del 2026-10-15

*Términos: ya estaban aceptados para esta versión (1.1, familia 0.3.8, por José Francisco Ñáñez, 2026-10-15). Preguntas de la sesión: nadie responde; se tomó la respuesta sugerida.*

**Lectura corta:** el registro tiene 5 requerimientos aceptados, pero ninguno trae su necesidad escrita (los cinco se titulan «Requerimiento REQ-xxxx» y el acta no dice qué piden). Con eso no se puede redactar comportamiento sin inventarlo, y no se inventó. Lo que sigue es el esqueleto con todos los huecos a la vista.

## Qué problema resuelve
La definición dice, completo: *«El segmento Empresas no tiene cuenta pyme.»* (definición, 2026-02-02, «El problema»). La propuesta se llama «Propuesta principal» y no dice nada más. No hay criterio de éxito (`success` no consta).

## Alcance
### Entra
Los cinco requerimientos aceptados el 2026-10-13 (acta del comité), **sin que el acta diga qué es cada uno**: REQ-1030, REQ-1031, REQ-1032, REQ-1033, REQ-2018.

### No entra
- Cualquier cosa no registrada como `aceptado` o `en_construccion`: hoy no hay propuestos, descartados ni entregados.
- Todo comportamiento, canal, funcionalidad o límite de la cuenta: ninguna fuente los dice, así que no están ni dentro ni fuera por decisión; **están sin decidir** (ver Vacíos).
- Diseño técnico, estimación, costo y fecha: no son de este documento.

## Comportamiento
No se redacta. Ninguno de los cinco requerimientos tiene necesidad escrita en las palabras de quien la tiene; escribir comportamiento aquí sería decidirlo en su lugar.

| Sección | Requerimientos | Estado |
|---|---|---|
| (sin secciones: ningún requerimiento dice qué problema concreto resuelve) | REQ-1030, 1031, 1032, 1033, 2018 | No redactable |

## Criterios de aceptación
| Criterio | Requerimiento | Cómo se verifica | ¿Se puede medir hoy? |
|---|---|---|---|
| «se verifica en producción» | REQ-1030 | No pasa la prueba de las dos personas: no dice qué se verifica ni contra qué | No: no hay nada que medir |
| «se verifica en producción» | REQ-1031 | Ídem | No |
| «se verifica en producción» | REQ-1032 | Ídem | No |
| «se verifica en producción» | REQ-1033 | Ídem | No |
| *(ninguno)* | REQ-2018 | — | No existe criterio |

Los cuatro criterios son el mismo texto, dicen *cuándo* y no *qué*. No se reescribieron en forma verificable porque eso requeriría saber qué pide cada requerimiento. Hallazgo: ningún criterio es verificable hoy.

## Supuestos sobre los que está escrita
| Supuesto | Verificado | Quién lo verificaría |
|---|---|---|
| «El segmento paga por esto» (declarado 2026-09-21, definición) | No (sin verificar; el umbral es de 30 días y ya pasaron 24 desde su declaración, vence el 2026-10-21) | Beatriz Cuéllar |
| Que la entrevista del 2025-08-11 («Lo necesito y hoy no lo tengo») sostiene cada uno de los cinco requerimientos | No: no nombra requerimiento ni a quién habló | Beatriz Cuéllar (realizó la ronda) |
| Que el volumen declarado (276.747/mes) es el mercado que el producto atiende | Parcial: medido 246.553 al 2026-10-09 (−10,9%, bajo el umbral de 20%) | Beatriz Cuéllar |

## Vacíos
| Qué falta decidir | Consecuencia de no decidirlo | Quién lo cierra |
|---|---|---|
| Qué pide cada requerimiento (título y necesidad) | No hay especificación posible; cualquier texto sería del agente | Dolientes: Camilo Beltrán (1030), Liliana Torres (1031), Paula Céspedes (1032), Carlos Peña (1033), María Restrepo (2018) |
| Criterio de aceptación de REQ-2018 | Aceptado sin forma de saber si quedó bien | María Restrepo |
| Criterio verificable en REQ-1030/1031/1032/1033 | «Se verifica en producción» deja la discusión para después de construir | Camilo Beltrán, Liliana Torres, Paula Céspedes, Carlos Peña |
| Quién pidió cada requerimiento (el acta dice «Cliente entrevistado» en los cinco) | Evidencia de demanda de 14 meses (umbral 12) que no distingue requerimientos | Beatriz Cuéllar, con entrevista nueva |
| Quién decidió el 2026-10-13 (`who` vacío); el acta solo dice «Se mantiene el plan», y el plan no consta | La decisión no tiene responsable ni documento que la respalde | Beatriz Cuéllar |
| Facultad de decidir (`authority` vacía en la configuración) | Los propuestos futuros no tienen a quién llegar | Beatriz Cuéllar |
| **Casos borde:** ningún comportamiento ante falla, duplicado, abandono o ausencia de datos está definido | Lo decidirá quien construya, sin que nadie lo haya acordado | Beatriz Cuéllar con cada doliente, una vez haya necesidad escrita |
| **Otros equipos:** ningún documento dice qué debe hacer otro equipo (riesgo, cumplimiento, canales, tecnología) ni que se haya acordado | Dependencias que aparecen durante la construcción | Beatriz Cuéllar |
| **Obligaciones normativas:** no se corrió el barrido; la definición no dice qué hace la cuenta (datos personales, pagos, consumidor financiero, retención), así que no se puede ni acotar qué toca | Obligaciones sin resolver desde el inicio. Esto no es un dictamen de cumplimiento | Beatriz Cuéllar, con el área que ella designe (no consta) |
| Proyecto que ejecute cada requerimiento: 0 de 5; la definición dice «Ninguno declarado»; la carpeta de fichas está vacía | Aceptado sin quién construya; no se puede pasar a acta de constitución | Beatriz Cuéllar |
| Criterio de éxito del producto | No hay contra qué juzgar si la cuenta funcionó | Beatriz Cuéllar |

## Requerimientos aceptados que esta especificación no cubre
| REQ | Título | Por qué no |
|---|---|---|
| REQ-1030 | Sin título propio en el acta | No tiene necesidad escrita; criterio no verificable |
| REQ-1031 | Sin título propio en el acta | Ídem |
| REQ-1032 | Sin título propio en el acta | Ídem |
| REQ-1033 | Sin título propio en el acta | Ídem |
| REQ-2018 | Sin título propio en el acta | Ídem, y sin criterio de aceptación |

**Cobertura: 0 de 5.** No es una omisión de esta corrida: es lo que el registro permite hoy.

## Pie
Sale del registro `estado-producto/PRD-303/requirements/` (5 requerimientos, todos `aceptado`, corte 2026-10-13, acta del comité) y de la definición y el caso de negocio del 2026-02-02. Cubre 0 de 5 requerimientos. Términos 1.1: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.8

## Después
**No ofrezco `/product-charter` todavía**: los vacíos no están cerrados y el producto no tiene criterio de éxito. Siguiente paso útil: que los dolientes escriban la necesidad de cada requerimiento y se vuelva a correr `/product-spec`.
