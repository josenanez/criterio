# Corrida del 2026-10-15 · product-charter

PRD-303 · 5 requerimientos · 35 s · 16 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 5 |
| `decision_without_source` | 5 |
| `requirement_untraced` | 5 |
| `requirement_without_acceptance` | 1 |

Borrador de acta para REQ-1030. Vacíos marcados, no rellenados: criterio de aceptación no verificable, demanda anónima de hace 14 meses, autoridad, patrocinador, presupuesto e hitos. Sin firma, la ficha no se creó.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

Sesión de prueba sin interfaz: nadie respondió preguntas. Términos: ya vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-15, familia 0.3.8); no hizo falta registrarlos de nuevo. En la pregunta «¿sigo con los vacíos marcados?» tomé la respuesta sugerida: sí, seguir marcándolos como vacíos del acta, sin rellenarlos.

# Acta de constitución — Cuenta PyME / REQ-1030 · borrador del 2026-10-15
**Producto:** PRD-303 · Cuenta PyME · **Requerimientos:** REQ-1030

## Verificación previa (requirement-record)
| Condición | Resultado |
|---|---|
| Aceptado, no propuesto | Sí: estado «aceptado» desde 2026-06-25 en el acta del comité del 2026-10-13 (`30-decisiones/2026-10-13-comite-producto.docx`). Único asistente registrado: Beatriz Cuéllar, gerente de producto. |
| Criterios de aceptación verificables | **No.** El único criterio es «se verifica en producción»: no dice qué se mide, con qué umbral ni quién lo verifica. Se trata como vacío. |
| Evidencia de demanda con cita | **Débil.** Pedido por «Cliente entrevistado» (sin nombre ni empresa). La única entrevista (`10-descubrimiento/2025-08-11-entrevistas.md`) dice «Lo necesito y hoy no lo tengo.» y no nombra al requerimiento. Es anterior al requerimiento (2025-08-11 contra 2026-06-25) y tiene 14 meses, por encima del umbral de 12. |
| Autoridad declarada en la definición | **No.** `authority: not_found` en la ficha del producto y `null` en la configuración. |

Seguir sin estos tres es decisión de quien firma; queda marcado como vacío, no rellenado.

## Qué problema resuelve
«El segmento Empresas no tiene cuenta pyme.» (`00-definicion/2026-02-02-definicion-producto.docx` · «El problema»). La definición no dice qué parte de ese problema resuelve REQ-1030: el título del requerimiento es solo «Requerimiento REQ-1030».

## Criterio de éxito
| Criterio | Cómo se verifica | Estado |
|---|---|---|
| «se verifica en producción» (comité 2026-10-13) | No dicho: sin métrica, umbral ni responsable | **Vacío.** Con esto el cierre no se podrá juzgar. |
| Éxito del producto | La definición no lo declara (`success: not_found`) | **Vacío** |

## Alcance
### Entra
| REQ | Título | Evidencia que lo sostiene |
|---|---|---|
| REQ-1030 | Requerimiento REQ-1030 (dueño: Camilo Beltrán) | Entrevista 2025-08-11, «Lo necesito y hoy no lo tengo.» No lo nombra y el cliente no está identificado. |

### No entra
| REQ | Título | Por qué no |
|---|---|---|
| REQ-1031 | Requerimiento REQ-1031 | No se pidió en esta invocación; su acta, si procede, es aparte. |
| REQ-1032 | Requerimiento REQ-1032 | Ídem. |
| REQ-1033 | Requerimiento REQ-1033 | Ídem. |
| REQ-2018 | Requerimiento REQ-2018 | Ídem. Además no tiene criterio de aceptación en el acta del comité. |

La razón de fondo de cada exclusión es de quien firma; aquí solo consta que no se pidieron.

## Gobierno
**Patrocinador:** no dicho en ningún documento. · **Gerente propuesto:** no propongo a nadie; ningún documento lo indica (Camilo Beltrán es doliente del requerimiento, no gerente de proyecto). Beatriz Cuéllar es la gerente de producto. · **Comité:** comité de producto mensual (configuración), con Beatriz Cuéllar como única asistente en el acta del 2026-10-13; su decisión fue «Se mantiene el plan». · **Autoridad del gerente:** no dicha (`not_found`).

## Supuestos que se llevan al proyecto
| Supuesto | Verificado | Se convierte en riesgo de |
|---|---|---|
| «El segmento paga por esto» (declarado 2026-09-21, definición · «Supuestos») | No. Lleva 24 días sin verificar, bajo el umbral de 30 pero cerca. | Riesgo del proyecto: la disposición a pagar del segmento. **Doliente: sin asignar.** |

Hay una cifra, no un supuesto, que conviene tener a la vista: el caso de negocio declara `volumen_mensual` = 276.747 y el tablero del 2026-10-09 mide 246.553, una brecha de 10,9 %, por debajo del umbral de 20 %. No es hallazgo.

## Restricciones normativas sin resolver
| Qué toca | Obligación | Norma | Estado |
|---|---|---|---|
| Ninguna detectada | Los documentos no mencionan datos personales, pagos ni retención. Una cuenta pyme probablemente sí los toque, pero no está dicho. | — | Sin barrido: nada que citar. |

## Vacíos de este acta
| Qué falta | Consecuencia de firmar sin eso | Quién lo cierra |
|---|---|---|
| Criterio de aceptación verificable | El cierre no se puede juzgar meses después. | Beatriz Cuéllar, con Camilo Beltrán |
| Demanda identificable del requerimiento | Se construye sobre un cliente anónimo y una entrevista de hace 14 meses que no lo nombra. | Beatriz Cuéllar |
| Autoridad del gerente | El proyecto escala todo o no escala nada. | Quien tenga autoridad sobre el producto (no identificado) |
| Patrocinador | No hay quién responda por el presupuesto ni por las decisiones fuera de la autoridad del gerente. | No identificado |
| Presupuesto e hitos | Ningún documento los declara. El acta no los inventa, ni trae plan. | Quien firme |
| Doliente del supuesto de pago | El supuesto pasa a riesgo sin dueño. | Beatriz Cuéllar |
| Proyecto vigente | La definición declara «Ninguno declarado»; el comité deja «—» en «Proyecto que lo ejecuta». REQ-1030 no tiene traza todavía. | Se cierra con la ficha, después de la firma |

---
**Esto es un borrador.** Lo firma una persona con autoridad sobre el producto; ningún documento dice quién (Beatriz Cuéllar es la candidata natural como gerente de producto, pero no lo doy por hecho). **La ficha del proyecto no se creó** (`portafolio.py init` no corrió): se crea después de la firma. El estado declarado no lo escribe este comando.

## Qué sigue
Quien firme resuelve los vacíos o los acepta por escrito. El gerente que se nombre instala `criterio-project` y corre `/pm-setup`; cuando publique su ficha con `/pm-publish`, `/product-trace` podrá confirmar la traza contra ella, y Alba sabrá si el producto se está construyendo sin preguntarle a nadie.
