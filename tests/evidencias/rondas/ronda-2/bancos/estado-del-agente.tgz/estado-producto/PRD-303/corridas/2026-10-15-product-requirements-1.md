# Corrida del 2026-10-15 · product-requirements

PRD-303 · 5 requerimientos · 33 s · 16 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 5 |
| `decision_without_source` | 5 |
| `requirement_untraced` | 5 |
| `requirement_without_acceptance` | 1 |

5 aceptados sin proyecto, sin quién decidió y con evidencia de 14 meses que no nombra el requerimiento; REQ-2018 sin criterio de aceptación

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## Registro — Cuenta PyME (PRD-303) · al 2026-10-15
5 requerimientos · 5 decididos (todos `aceptado`) · 100% con evidencia citada · 0% con proyecto que lo ejecute

*Terminos: ya estaban aceptados para esta versión (1.1, familia 0.3.8, por José Francisco Ñáñez, 2026-10-15); no hizo falta volver a pedirlos.*
*Preguntas de la sesión: nadie responde; se tomó la respuesta sugerida. Carpeta de fichas de proyectos (`estado`) vacía: la columna «lo ejecuta» no se pudo confirmar contra ninguna ficha.*

### Se va a construir y nadie lo pidió
Ninguno según el cálculo (los 5 tienen una evidencia citada). **Pero la cifra del 100% hay que leerla con cuidado:** las cinco evidencias son la misma, la entrevista del 2025-08-11 (*«Lo necesito y hoy no lo tengo.»*, tema «Necesidad principal»). Esa entrevista no nombra a ningún requerimiento ni a quién habló; el acta del comité del 2026-10-13 dice solo «Cliente entrevistado». Es evidencia de demanda de la cuenta, no de cada requerimiento.

| REQ | Título | Estado | Doliente |
|---|---|---|---|
| REQ-1030 | sin título propio en el acta | aceptado | Camilo Beltrán |
| REQ-1031 | sin título propio en el acta | aceptado | Liliana Torres |
| REQ-1032 | sin título propio en el acta | aceptado | Paula Céspedes |
| REQ-1033 | sin título propio en el acta | aceptado | Carlos Peña |
| REQ-2018 | sin título propio en el acta | aceptado | María Restrepo |

### Decidido y nadie lo está construyendo
Los 5 aceptados no tienen proyecto asociado en su traza (0% trazado). No se pudo contrastar con fichas: la carpeta está vacía.

| REQ | Título | Decidido el | |
|---|---|---|---|
| REQ-1030 | — | 2026-10-13 (acta del comité) | sin proyecto |
| REQ-1031 | — | 2026-10-13 | sin proyecto |
| REQ-1032 | — | 2026-10-13 | sin proyecto |
| REQ-1033 | — | 2026-10-13 | sin proyecto |
| REQ-2018 | — | 2026-10-13 | sin proyecto |

### Sin doliente, o con un área en vez de una persona
Ninguno. Los 5 tienen una persona nombrada.

### Sin criterio de aceptación
| REQ | Título | Estado |
|---|---|---|
| REQ-2018 | — | aceptado |

Los otros cuatro traen un criterio: «se verifica en producción» (REQ-1030 como ejemplo). Es verificable en el momento, no medible de antemano.

### Decidido sin documento que lo respalde
Los 5 tienen el acta del comité del 2026-10-13 como fuente del estado, pero **el acta no deja dicho quién decidió** (`who` vacío en los cinco).

| REQ | Quién decidió | Cuándo |
|---|---|---|
| REQ-1030 | no consta | 2026-10-13 |
| REQ-1031 | no consta | 2026-10-13 |
| REQ-1032 | no consta | 2026-10-13 |
| REQ-1033 | no consta | 2026-10-13 |
| REQ-2018 | no consta | 2026-10-13 |

### Lleva meses y nadie lo decide
Ninguno: todo está decidido. Quién tiene la facultad de decidir **no consta**: la configuración deja `authority` en blanco. Cuando aparezca un requerimiento propuesto, no habrá a quién asignarle la decisión; esto lo cierra Beatriz Cuéllar (gerente del producto) al indicar quién decide.

### Evidencia vieja
Umbral: 12 meses.

| REQ | Lo más nuevo que lo sostiene | Hace |
|---|---|---|
| REQ-1030 | entrevista 2025-08-11 | 14 meses |
| REQ-1031 | entrevista 2025-08-11 | 14 meses |
| REQ-1032 | entrevista 2025-08-11 | 14 meses |
| REQ-1033 | entrevista 2025-08-11 | 14 meses |
| REQ-2018 | entrevista 2025-08-11 | 14 meses |

### Quién cerraría cada vacío
- **Sin proyecto / sin traza (5):** quien lleve la decisión del 2026-10-13 debe abrir o indicar el proyecto. Con el proyecto en su carpeta, `/product-trace` lo confirma. Candidato de lectura sin confirmar: PRY-207 (onboarding PyME), solo por el nombre.
- **Quién decidió (5):** quien redactó el acta del comité; la gerente de producto, Beatriz Cuéllar, puede pedir que se complete.
- **Evidencia vieja (5):** el doliente de cada requerimiento, con una entrevista nueva que nombre el requerimiento.
- **Criterio de aceptación de REQ-2018:** María Restrepo.
- **Facultad de decidir:** Beatriz Cuéllar.

### Fuera de este registro, por si sirve
La definición del producto declara un volumen mensual de 276.747 (caso de negocio, 2026-02-02) frente a 246.553 medido el 2026-10-09: diferencia de 10,9%, por debajo del umbral de 20%. No es hallazgo. La definición no trae criterio de éxito (`success` no consta).

## Por estado
| propuesto | aceptado | en construcción | entregado | descartado |
|---|---|---|---|---|
| 0 | 5 | 0 | 0 | 0 |

**Siguiente paso:** `/product-trace` cuando existan las fichas de proyecto; `/product-charter` solo después de cerrar evidencia y criterio de REQ-2018.
