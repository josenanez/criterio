# Corrida · 2026-10-15-product-wake-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-wake (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-15T09:16:49 · **Fin:** 2026-10-15T09:17:34 · **Duración:** 45 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-wake` | 5 | — | 29 | 16 | Primera corrida, sin corte anterior: reportó el estado de partida (5 REQ aceptados, evidencia de 14 meses, sin fuente de decisión, sin proyecto). No leyó el acta del comité del 2026-10-13 ni confirmó trazas por falta de carpeta de fichas. |

Por señal (`product-wake`): `evidence_stale` 5, `decision_without_source` 5, `requirement_untraced` 5, `requirement_without_acceptance` 1

## Lo que el agente mostró

## Cuenta PyME (PRD-303) · 2026-10-15

Esta es la primera corrida y no hay corte anterior, así que no puedo separar lo nuevo de lo viejo. Lo que sigue es el estado de partida. Desde la próxima corrida solo reportaré lo que cruce un umbral después de hoy.

Los términos ya estaban vigentes y aceptados (v1.1, por José Francisco Ñáñez, 2026-10-15). Usé esa aceptación y no registré otra.

El registro tiene 5 requerimientos, todos `aceptado` y ninguno con proyecto que lo construya.

| Qué | REQ | Cuánto lleva | Qué se necesita | Quién |
|---|---|---|---|---|
| Evidencia vencida: la única entrevista es del 2025-08-11. No nombra el requerimiento ni a quién habló. | 1030, 1031, 1032, 1033, 2018 | 14 meses (umbral 12) | Evidencia de demanda nueva. Hoy no se sabe qué afirmación de la definición queda sin sustento. | Camilo Beltrán, Liliana Torres, Paula Céspedes, Carlos Peña, María Restrepo (dolientes) |
| Aceptado sin decisión con fuente: no consta quién ni cuándo lo decidió. | Los cinco | 102 a 190 días desde que se planteó (REQ-2018: 22) | Que alguien con la facultad lo confirme. La autoridad del producto figura como `null` en la configuración. | Sin dueño: primero hay que nombrar quién decide. |
| Aceptado sin criterio de aceptación. | 2018 | 22 días | Escribir el criterio antes de especificar. | María Restrepo |
| Aceptado y sin proyecto. | Los cinco | n/a | Llevarlo al comité. | Beatriz Cuéllar |

**Negocio contra datos:** el caso de negocio declara un volumen mensual de 276.747 y el tablero del 2026-10-09 mide 246.553. La brecha es de 10,9%, bajo el umbral de 20%. No es hallazgo y solo la anoto.

**Lo que no sé:**
- **Trazas:** la configuración no trae la carpeta de fichas de proyectos, así que ninguna traza queda confirmada.
- **Acta del comité:** no leí a fondo el acta del 2026-10-13, así que no sé si ya decide alguno de los cinco requerimientos.

Dejé el corte en `snapshots/2026-10-15.json` y la corrida registrada como `2026-10-15-product-wake-1` (29 segundos, 16 hallazgos). La salida completa quedó en `estado-producto/PRD-303/corridas/salida-product-wake.md`.

**Vuelvo el 2026-11-14.**
