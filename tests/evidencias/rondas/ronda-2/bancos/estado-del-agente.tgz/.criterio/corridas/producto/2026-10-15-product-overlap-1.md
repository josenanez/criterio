# Corrida · 2026-10-15-product-overlap-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-overlap PRD-302

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRD-302

**Inicio:** 2026-10-15T09:16:35 · **Fin:** 2026-10-15T09:16:44 · **Duración:** 9 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

> Esta corrida no dejó cifras medidas por `corrida`: lo que hay es lo que el agente mostró. Si el comando debía correr los scripts y no lo hizo, eso es un hallazgo de la prueba.

## Lo que el agente mostró

No encontré la configuración de PRD-302, así que paro aquí.

Esperaba `.criterio/producto/PRD-302/config.json` en `/home/claude/banco/ronda-2/bancos/espacio`. Esa carpeta no existe. En `.criterio/producto/` solo hay un producto configurado, PRD-303.

No usé la configuración de PRD-303 en su lugar, porque el argumento pedía PRD-302 y no quiero cruzar otro producto. Tampoco inventé una configuración.

No corrí `terminos`, `corrida-inicio` ni `overlap`, y no registré la aceptación de términos de José Francisco Ñáñez. Sin configuración no hay un producto al que atar el comprobante.

Dos formas de seguir:
- Si PRD-302 debía existir, corre `/criterio-product:product-setup` para crearlo y luego repite `/product-overlap PRD-302`.
- Si en realidad querías PRD-303, repite el comando con ese código.
