# Corrida · 2026-10-15-budget-tracking-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:budget-tracking PRY-206

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-206

**Inicio:** 2026-10-15T09:01:23 · **Fin:** 2026-10-15T09:02:17 · **Duración:** 54 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `budget-tracking` | 13 | — | 37 | 67 | Presupuesto PRY-206: proyección +13,0 % sobre el aprobado, ejecutado 43,0 % frente a avance declarado 31 %, Redes del Norte facturado por encima de lo aceptado. Sin historial de versiones de presupuesto, sin desglose por proveedor y cifras de una sola fuente. |

Por señal (`budget-tracking`): `milestone_met_without_evidence` 24, `progress_vs_plan` 6, `vendor_accepted_without_evidence` 6, `declared_vs_evidence` 6, `variance_time` 4, `commitment_undated` 4, `variance_cost` 4, `change_without_baseline` 4, `commitment_overdue` 3, `rebaseline_unauthorized` 2, `vendor_deliverable_late` 2, `vendor_invoiced_over_accepted` 1, `pm_vs_pmo` 1

## Lo que el agente mostró

## Presupuesto — PRY-206 Billetera y QR al 2026-10-15

Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15), así que no hubo que registrarlos de nuevo. Las cuatro cifras salen del informe de avance del 2026-10-04. Todo está en COP, una sola moneda, sin conversiones.

| | Monto (COP) | % del aprobado |
|---|---|---|
| Aprobado | 6.800.000.000 | — |
| Comprometido | 3.979.137.385 | 58,5 % |
| Ejecutado | 2.925.165.723 | 43,0 % |
| Proyección al cierre | 7.686.267.486 | 13,0 % por encima del aprobado |

- **Disponible real** (aprobado menos comprometido): 2.820.862.615 COP.
- **Comprometido:** está por debajo del umbral de 90 %, así que el problema no está ahí.
- **Proyección:** supera el umbral de 10 % y es una declaración del 2026-10-04, no un dato contable. No hay ningún cambio de presupuesto aprobado que la respalde.
- **Ejecución frente a avance:** ejecutado 43,0 % contra un avance declarado de 31 %. Los 5 hitos figuran como cumplidos, pero 3 de ellos no tienen evidencia, así que ese "5 de 5" no sirve para medir avance.
- **Facturado sobre lo aceptado:** Redes del Norte (CT-725) facturó 1.317.839.587 COP y tiene aceptados 920.079.190 COP, una diferencia de 397.760.397 COP. Dos de sus entregables aparecen como aceptados sin evidencia.
- **Compromiso sin fecha:** Laura Vélez tiene pendiente "mandar el ajuste del presupuesto" y no tiene fecha.
- **Fechas de fin en conflicto:** el cronograma dice 2026-09-25 y el acta de constitución dice 2026-11-11, ambos del 2025-06-02. No puedo decir cuál manda.

**Sin dato:**
- No hay historial de versiones del presupuesto, solo el aprobado.
- No hay desglose del comprometido por proveedor.
- Las cuatro cifras vienen de una sola fuente que ningún documento contable confirma.

La proyección excede el aprobado, así que puedo preparar la solicitud de cambio de presupuesto con `/criterio-portfolio:change-control`. También puedo detallar lo facturado por proveedor con `/criterio-portfolio:vendor-tracking`.

La corrida quedó registrada como `2026-10-15-budget-tracking-1`. El informe completo está en `estado/corridas/salida-budget-tracking.md`.

*Borrador de trabajo, no decisión ni asesoría. Cada cifra sale de `portafolio.py compute` y de la ficha, con su cita; la verificación es de quien lo lea.*
