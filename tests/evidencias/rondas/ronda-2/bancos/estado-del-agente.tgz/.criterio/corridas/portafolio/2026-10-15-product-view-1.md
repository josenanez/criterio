# Corrida · 2026-10-15-product-view-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:product-view pagos QR

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-15T09:12:19 · **Fin:** 2026-10-15T09:13:07 · **Duración:** 48 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-view` | 13 | — | 26 | 67 | Producto con un solo proyecto (PRY-206); sin sección de producto, señales del proyecto resumidas. No se sabe cuál fecha de fin es la vigente (PMO 2026-09-25 vs PM 2026-11-11) ni el área dueña de los 4 proyectos sin producto. |

Por señal (`product-view`): `milestone_met_without_evidence` 24, `progress_vs_plan` 6, `vendor_accepted_without_evidence` 6, `declared_vs_evidence` 6, `variance_time` 4, `commitment_undated` 4, `variance_cost` 4, `change_without_baseline` 4, `commitment_overdue` 3, `rebaseline_unauthorized` 2, `vendor_deliverable_late` 2, `vendor_invoiced_over_accepted` 1, `pm_vs_pmo` 1

## Lo que el agente mostró

**Productos al 2026-10-15 — pagos QR**

Los términos ya estaban vigentes (versión 0.3.8, aceptados por José Francisco Ñáñez el 2026-10-15), así que no pedí aceptación otra vez. Las cifras salen de `portafolio.py compute` de esta corrida.

«pagos QR» tiene un solo proyecto, PRY-206 Billetera y QR. No armo sección de producto porque la vista por producto no aporta nada distinto a la del proyecto. Esto es lo que el cálculo marca en PRY-206, con 12 alertas y 8 señales distintas:

- **Avance:** declara 31 %, pero el plan da por cumplidos 5 de 5 hitos. La brecha es de 69 puntos.
- **Hitos sin evidencia:** tres hitos figuran cumplidos sin sustento:
  - «Ambiente de pruebas certificado», que vencía el 2025-12-17.
  - «Integración con el core», que vencía el 2026-03-21.
  - «Piloto con usuarios internos», que vencía el 2026-06-23.
- **Costo:** la proyección es 7.686.267.486 COP contra 6.800.000.000 aprobados, un 13,0 % por encima (el umbral es 10 %). Ejecutado: 2.925.165.723. Comprometido: 3.979.137.385 (58,5 %). Las cuatro cifras del proyecto vienen completas.
- **Proveedores:**
  - Redes del Norte Ltda. (CT-725) tiene facturados 1.317.839.587 contra 920.079.190 aceptados, 397.760.397 por encima.
  - A Redes del Norte le figuran dos entregables aceptados sin evidencia, «Licenciamiento del motor» y «Parametrización del tarifario». Su «Bolsa de horas de desarrollo» sigue pendiente hace 232 días.
  - Consultora Andina S.A.S. (CT-279) tiene «Parametrización del tarifario» pendiente hace 103 días.
- **Compromiso sin fecha:** Laura Vélez, «Mandar el ajuste del presupuesto».
- **Declaración del gerente:** declara rojo (31 %, informe del 2026-10-04). Cinco de las señales no están explicadas en esa declaración.
- **Dependencias internas:** no aplica, porque el producto tiene un solo proyecto.

**Fecha del producto.** No puedo dar una sola fecha. La PMO tiene 2026-09-25 (cronograma v1) y el gerente tiene 2026-11-11 (acta de constitución). Ambas fuentes son del 2025-06-02 y ninguna es más reciente. Con la primera el proyecto ya venció; con la segunda le quedan 27 días. Hay que confirmar cuál es la vigente.

**Proyectos sin producto declarado.** Son PRY-202 Migración a la nube, PRY-205 Prevención de lavado de activos, PRY-208 Motor de decisión y PRY-210 Portal de proveedores. Nadie puede responder por el conjunto al que sirven. El cálculo no trae el área dueña de esos cuatro y no la inventé.

**Para el comité del 2026-10-22.** No hay dependencias internas que llevar como una sola decisión. Sí hay tres cosas que decidir sobre PRY-206: la fecha vigente, el ajuste de presupuesto y la facturación de Redes del Norte.

**Pie de rigor.** Los 42 datos de PRY-206 vienen sin marcar como evidencia ni como declaración, así que las citas hay que verificarlas contra los documentos. Criterio produce borradores, no decisiones, y la verificación es suya.

La corrida quedó registrada como `2026-10-15-product-view-1` y tardó 26 segundos. Lo que te mostré está en `estado/corridas/salida-product-view.md`.
