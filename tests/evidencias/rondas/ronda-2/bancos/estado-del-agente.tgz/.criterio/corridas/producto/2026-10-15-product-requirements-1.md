# Corrida · 2026-10-15-product-requirements-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-requirements (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-15T08:36:41 · **Fin:** 2026-10-15T08:37:32 · **Duración:** 51 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-requirements` | 5 | — | 33 | 16 | 5 aceptados sin proyecto, sin quién decidió y con evidencia de 14 meses que no nombra el requerimiento; REQ-2018 sin criterio de aceptación |

Por señal (`product-requirements`): `evidence_stale` 5, `decision_without_source` 5, `requirement_untraced` 5, `requirement_without_acceptance` 1

## Lo que el agente mostró

## Registro — Cuenta PyME (PRD-303) · al 2026-10-15

El registro tiene 5 requerimientos, todos `aceptado`, y ninguno tiene un proyecto que lo ejecute. Los términos ya estaban aceptados para esta versión (1.1, a nombre de José Francisco Ñáñez, 2026-10-15), así que no los volví a pedir.

La carpeta de fichas de proyectos (`estado`) está vacía. Por eso no pude confirmar la traza contra ninguna ficha. La corrida quedó registrada como `2026-10-15-product-requirements-1`: 16 hallazgos en 33 segundos.

- **Evidencia:** el cálculo da 100%, pero ese número engaña. Las cinco evidencias son la misma entrevista del 2025-08-11 («Lo necesito y hoy no lo tengo.»). La entrevista no nombra ningún requerimiento y el acta solo dice «Cliente entrevistado». Además tiene 14 meses, y el umbral es 12.
- **Sin proyecto:** REQ-1030, REQ-1031, REQ-1032, REQ-1033 y REQ-2018 no tienen proyecto. Candidato por el nombre, sin confirmar: PRY-207 (onboarding PyME).
- **Sin quién decidió:** el acta del comité del 2026-10-13 respalda el estado, pero no dice quién decidió. Falta en los cinco.
- **Sin criterio de aceptación:** REQ-2018 (doliente: María Restrepo). Los otros cuatro traen «se verifica en producción».
- **Sin doliente o con un área en vez de persona:** ninguno.
- **Lleva meses sin decidirse:** ninguno, pero la configuración no dice quién tiene la facultad de decidir (`authority` vacío). Eso lo cierra Beatriz Cuéllar, la gerente del producto.
- **Fuera del registro:** el volumen mensual declarado en el caso de negocio es 276.747 y el medido es 246.553. La diferencia es 10,9%, bajo el umbral de 20%, así que no es hallazgo.

Siguiente paso: `/product-trace` cuando existan las fichas de proyecto.

El texto completo quedó en `/home/claude/banco/ronda-2/bancos/espacio/estado-producto/PRD-303/corridas/salida-product-requirements.md`.
