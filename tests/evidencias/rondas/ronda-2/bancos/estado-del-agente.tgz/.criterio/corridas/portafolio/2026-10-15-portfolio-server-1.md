# Corrida · 2026-10-15-portfolio-server-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-server rato

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-15T09:15:11 · **Fin:** 2026-10-15T09:15:41 · **Duración:** 30 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-server` | 13 | — | — | 67 | puerto 8787, carpeta del informe reportes, modo rato |

Por señal (`portfolio-server`): `milestone_met_without_evidence` 24, `progress_vs_plan` 6, `vendor_accepted_without_evidence` 6, `declared_vs_evidence` 6, `variance_time` 4, `commitment_undated` 4, `variance_cost` 4, `change_without_baseline` 4, `commitment_overdue` 3, `rebaseline_unauthorized` 2, `vendor_deliverable_late` 2, `vendor_invoiced_over_accepted` 1, `pm_vs_pmo` 1

## Lo que el agente mostró

Rostrum está corriendo en modo «para mirarlo un rato» y la portada responde 200 en `http://127.0.0.1:8787/`.

- **Términos:** ya estaban vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-15), así que no registré nada nuevo.
- **Modo:** el argumento era `rato`, y es además la forma que recomienda el comando para empezar.
- **Qué sirve:** el informe de `reportes/`, con 13 proyectos, 9 productos y 32 corridas.
- **Registro:** guardé lo mostrado en `estado/corridas/salida-portfolio-server.md` y la corrida quedó como `2026-10-15-portfolio-server-1`.

Direcciones:
- Portada: `http://127.0.0.1:8787/`
- Cómo va el portafolio (PMO): `/pmo`
- Decisiones (comité y patrocinador): `/decisiones`
- Proyectos: `/proyectos`
- Productos: `/productos`
- Corridas: `/corridas`
- Frescura: `/estado.json`

**A quién pasarle el enlace:** a nadie todavía. Solo funciona en este equipo, así que un patrocinador no lo abriría. Para darle un enlace estable hay que pasar a «que quede corriendo». Eso es arrancar con `--abierto` y pedirle a la organización un host, un puerto y su control de acceso. El servidor no autentica.

**Cuándo se desactualiza:** el informe es el de la última corrida de `/portfolio-report`, del 2026-10-15. La portada muestra esa fecha.

El servidor sigue en segundo plano y escribe su registro en `/tmp/claude-0/rostrum.log`. Para pararlo, termina el proceso `servidor.py`.
