# Informe de avance · Onboarding PyME

**Código:** PRY-207
**Fecha de corte:** 2026-09-26
**Gerente:** Javier Hoyos

## Estado declarado

**Verde**

Avance reportado: **75%**

## Lo que pasó en el periodo

- El proveedor entregó el componente de integración, pendiente de aceptación
- La prueba de carga no alcanzó el umbral pactado y se repite

## Presupuesto

| | COP |
|---|---|
| Aprobado | 3.300.000.000 |
| Comprometido | 1.403.747.264 |
| Ejecutado | 988.461.552 |
| Proyección al cierre | 3.119.708.600 |

## Riesgos abiertos

- Dependencia del calendario de liberaciones del core
- El proveedor no ha confirmado la fecha de la última entrega
