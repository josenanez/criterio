# Comité de Banca Empresas · Débito contactless

**Fecha:** 2026-10-15
**Asistentes:** Paula Céspedes, Mauricio Pérez

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Jorge Medina | Entregar el punto 12 | por definir |
