# Solicitud de cambio CC-01

**Proyecto:** PRY-208 · Motor de decisión
**Fecha:** 2026-10-10
**Solicitante:** Carlos Peña

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +20 días sobre la línea base vigente |
| Costo | 40.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
