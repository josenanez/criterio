# Solicitud de cambio CC-01

**Proyecto:** PRY-202 · Migración a la nube
**Fecha:** 2026-10-04
**Solicitante:** Mauricio Pérez

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +42 días sobre la línea base vigente |
| Costo | 84.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
