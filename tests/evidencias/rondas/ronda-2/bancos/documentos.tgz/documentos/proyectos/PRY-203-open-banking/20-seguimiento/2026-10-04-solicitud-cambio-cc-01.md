# Solicitud de cambio CC-01

**Proyecto:** PRY-203 · Open Banking
**Fecha:** 2026-10-04
**Solicitante:** Elena Duarte

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +78 días sobre la línea base vigente |
| Costo | 156.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
