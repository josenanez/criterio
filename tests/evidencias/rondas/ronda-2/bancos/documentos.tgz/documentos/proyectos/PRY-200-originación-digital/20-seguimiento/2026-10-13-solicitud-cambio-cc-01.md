# Solicitud de cambio CC-01

**Proyecto:** PRY-200 · Originación digital
**Fecha:** 2026-10-13
**Solicitante:** Óscar Ramírez

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +98 días sobre la línea base vigente |
| Costo | 196.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
