# Solicitud de cambio CC-02

**Proyecto:** PRY-207 · Onboarding PyME
**Fecha:** 2026-10-13
**Solicitante:** Javier Hoyos

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +120 días sobre la línea base vigente |
| Costo | 240.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
