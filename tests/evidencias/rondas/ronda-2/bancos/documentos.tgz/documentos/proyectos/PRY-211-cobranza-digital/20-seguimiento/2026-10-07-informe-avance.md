# Informe de avance · Cobranza digital

**Código:** PRY-211
**Fecha de corte:** 2026-10-07
**Gerente:** Paula Céspedes

## Estado declarado

**Rojo**

Avance reportado: **25%**

## Lo que pasó en el periodo

- Se recibió la aprobación regulatoria pendiente desde el trimestre anterior
- Se reprogramó la salida por ventana de cambio del área de operaciones

## Presupuesto

| | COP |
|---|---|
| Aprobado | 3.300.000.000 |
| Comprometido | 2.612.295.707 |
| Ejecutado | 1.351.157.629 |
| Proyección al cierre | 3.394.680.472 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
