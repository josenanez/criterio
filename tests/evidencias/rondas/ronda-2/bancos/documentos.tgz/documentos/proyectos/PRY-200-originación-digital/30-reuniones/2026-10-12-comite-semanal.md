# Comité de Banca Empresas · Originación digital

**Fecha:** 2026-10-12
**Asistentes:** Óscar Ramírez, Natalia Ospina

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Diana Molina | Entregar el punto 22 | 2026-10-08 |
