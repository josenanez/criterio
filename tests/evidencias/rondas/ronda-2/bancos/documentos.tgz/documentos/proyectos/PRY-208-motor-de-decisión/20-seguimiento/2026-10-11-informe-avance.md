# Informe de avance · Motor de decisión

**Código:** PRY-208
**Fecha de corte:** 2026-10-11
**Gerente:** Carlos Peña

## Estado declarado

**Verde**

Avance reportado: **45%**

## Lo que pasó en el periodo

- El equipo perdió dos semanas por rotación de un desarrollador clave
- Dos historias quedaron fuera del alcance del sprint por dependencia con el core

## Presupuesto

| | COP |
|---|---|
| Aprobado | 2.400.000.000 |
| Comprometido | 1.968.902.025 |
| Ejecutado | 375.756.283 |
| Proyección al cierre | 3.022.670.609 |

## Riesgos abiertos

- Cambio regulatorio en discusión que puede mover el alcance
- Disponibilidad del equipo de seguridad para la revisión final
