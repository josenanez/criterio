# Acta de constitución · Débito contactless

**Código:** PRY-204
**Área dueña:** Medios de Pago
**Patrocinador:** Mauricio Pérez
**Gerente de proyecto:** Paula Céspedes
**Comité:** Comité de Banca Empresas
**Producto asociado:** tarjeta débito
**Fecha de aprobación:** 2025-11-08

## Objetivo del negocio

Entregar débito contactless para Medios de Pago.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**800.000.000 COP**, aprobado por Comité de Banca Empresas el 2025-11-08.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-11-18 |
| Cierre | 2027-01-03 |

## Criterio de éxito

Débito contactless en producción y medido.

## Dependencias declaradas

- Ninguna declarada
