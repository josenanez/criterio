# Informe de avance · Portal de proveedores

**Código:** PRY-210
**Fecha de corte:** 2026-10-10
**Gerente:** Óscar Ramírez

## Estado declarado

**Verde**

Avance reportado: **39%**

## Lo que pasó en el periodo

- Se ajustó el plan de pruebas con el área de seguridad

## Presupuesto

| | COP |
|---|---|
| Aprobado | 2.400.000.000 |
| Comprometido | 1.636.053.902 |
| Ejecutado | 456.513.809 |
| Proyección al cierre | 2.498.619.894 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
