# Comité de Arquitectura · Open Banking

**Fecha:** 2026-10-11
**Asistentes:** Elena Duarte, Felipe Arango

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Diana Molina | Entregar el punto 35 | 2026-09-28 |
