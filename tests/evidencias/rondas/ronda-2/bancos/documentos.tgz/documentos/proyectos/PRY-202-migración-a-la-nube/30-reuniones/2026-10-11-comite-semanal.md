# Comité de Transformación Digital · Migración a la nube

**Fecha:** 2026-10-11
**Asistentes:** Mauricio Pérez, Jorge Medina

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Gustavo Neira | Entregar el punto 5 | 2026-10-25 |
