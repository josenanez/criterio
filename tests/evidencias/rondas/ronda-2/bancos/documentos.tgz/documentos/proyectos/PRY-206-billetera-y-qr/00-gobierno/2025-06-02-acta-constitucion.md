# Acta de constitución · Billetera y QR

**Código:** PRY-206
**Área dueña:** Banca Hipotecaria
**Patrocinador:** Natalia Ospina
**Gerente de proyecto:** Camilo Beltrán
**Comité:** Comité de Arquitectura
**Producto asociado:** pagos QR
**Fecha de aprobación:** 2025-06-02

## Objetivo del negocio

Entregar billetera y qr para Banca Hipotecaria.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**6.800.000.000 COP**, aprobado por Comité de Arquitectura el 2025-06-02.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-06-12 |
| Cierre | 2026-11-11 |

## Criterio de éxito

Billetera y QR en producción y medido.

## Dependencias declaradas

- Ninguna declarada
