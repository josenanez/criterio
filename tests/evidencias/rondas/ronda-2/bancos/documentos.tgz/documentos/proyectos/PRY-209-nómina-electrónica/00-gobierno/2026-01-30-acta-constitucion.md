# Acta de constitución · Nómina electrónica

**Código:** PRY-209
**Área dueña:** Medios de Pago
**Patrocinador:** Natalia Ospina
**Gerente de proyecto:** Paula Céspedes
**Comité:** Comité de Arquitectura
**Producto asociado:** nómina empresarial
**Fecha de aprobación:** 2026-01-30

## Objetivo del negocio

Entregar nómina electrónica para Medios de Pago.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**800.000.000 COP**, aprobado por Comité de Arquitectura el 2026-01-30.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-02-09 |
| Cierre | 2027-03-10 |

## Criterio de éxito

Nómina electrónica en producción y medido.

## Dependencias declaradas

- Ninguna declarada
