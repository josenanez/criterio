# Comité de Arquitectura · Billetera y QR

**Fecha:** 2026-10-12
**Asistentes:** Camilo Beltrán, Natalia Ospina

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Liliana Torres | Entregar el punto 21 | 2026-10-05 |
