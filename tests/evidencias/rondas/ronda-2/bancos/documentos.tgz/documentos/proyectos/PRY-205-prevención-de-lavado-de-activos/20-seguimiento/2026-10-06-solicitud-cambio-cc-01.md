# Solicitud de cambio CC-01

**Proyecto:** PRY-205 · Prevención de lavado de activos
**Fecha:** 2026-10-06
**Solicitante:** Camilo Beltrán

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +109 días sobre la línea base vigente |
| Costo | 218.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
