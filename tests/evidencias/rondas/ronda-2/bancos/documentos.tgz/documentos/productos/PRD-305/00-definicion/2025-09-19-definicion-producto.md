# Definición de producto · Recaudos y cobros

**Código:** PRD-305
**Gerente de producto:** Ricardo Salas
**Segmento:** PyME
**Fecha de la definición:** 2025-09-19

## El problema

El segmento PyME no tiene recaudos y cobros.

## La propuesta

- Propuesta principal

## Supuestos

- **La regulación vigente lo permite** · declarado el 2026-07-18 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
