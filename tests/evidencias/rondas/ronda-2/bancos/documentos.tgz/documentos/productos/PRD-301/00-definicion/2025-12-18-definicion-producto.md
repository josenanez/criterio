# Definición de producto · Nómina empresarial

**Código:** PRD-301
**Gerente de producto:** Javier Hoyos
**Segmento:** PyME
**Fecha de la definición:** 2025-12-18

## El problema

El segmento PyME no tiene nómina empresarial.

## La propuesta

- Propuesta principal

## Supuestos

- **El canal actual soporta el volumen** · declarado el 2026-04-26 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
