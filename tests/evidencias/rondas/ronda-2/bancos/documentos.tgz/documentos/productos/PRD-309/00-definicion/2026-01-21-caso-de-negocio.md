# Caso de negocio · Crédito de libre inversión

**Código:** PRD-309
**Fecha:** 2026-01-21
**Preparado por:** Laura Vélez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 203.609 | Caso de negocio, 2026-01-21 |

## Retorno esperado

Retorno esperado en 24 meses.
