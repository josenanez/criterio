# Caso de negocio · Crédito hipotecario digital

**Código:** PRD-302
**Fecha:** 2026-05-16
**Preparado por:** Óscar Ramírez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 160.570 | Caso de negocio, 2026-05-16 |

## Retorno esperado

Retorno esperado en 24 meses.
