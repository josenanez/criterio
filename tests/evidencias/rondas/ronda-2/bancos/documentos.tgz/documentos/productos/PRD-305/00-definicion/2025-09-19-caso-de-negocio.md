# Caso de negocio · Recaudos y cobros

**Código:** PRD-305
**Fecha:** 2025-09-19
**Preparado por:** Ricardo Salas

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 145.388 | Caso de negocio, 2025-09-19 |

## Retorno esperado

Retorno esperado en 24 meses.
