# Caso de negocio · Nómina empresarial

**Código:** PRD-301
**Fecha:** 2025-12-18
**Preparado por:** Javier Hoyos

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 128.606 | Caso de negocio, 2025-12-18 |

## Retorno esperado

Retorno esperado en 24 meses.
