# Caso de negocio · Microseguros

**Código:** PRD-306
**Fecha:** 2026-06-29
**Preparado por:** Paula Céspedes

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 198.938 | Caso de negocio, 2026-06-29 |

## Retorno esperado

Retorno esperado en 24 meses.
