# Definición de producto · Remesas familiares

**Código:** PRD-307
**Gerente de producto:** Gustavo Neira
**Segmento:** Base de la pirámide
**Fecha de la definición:** 2025-09-26

## El problema

El segmento Base de la pirámide no tiene remesas familiares.

## La propuesta

- Propuesta principal

## Supuestos

- **La demanda declarada se sostiene sin campaña** · declarado el 2026-06-27 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
