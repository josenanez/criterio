# Caso de negocio · Cuenta de ahorros joven

**Código:** PRD-308
**Fecha:** 2025-12-19
**Preparado por:** Andrés Lozano

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 101.993 | Caso de negocio, 2025-12-19 |

## Retorno esperado

Retorno esperado en 24 meses.
