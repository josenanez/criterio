# Entrevistas · Recaudos y cobros

**Ronda:** Ronda · 2026-08-26
**Realizadas por:** Ricardo Salas

### Cliente entrevistado · 2026-08-26

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
