# Tablero de métricas · Cuenta PyME

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-09

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 246.553 | 2026-10-09 |
