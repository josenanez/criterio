# Tablero de métricas · Pagos QR comercios

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-08

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 219.534 | 2026-10-08 |
