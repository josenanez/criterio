# Caso de negocio · Tarjeta de crédito digital

**Código:** PRD-304
**Fecha:** 2026-01-01
**Preparado por:** Paula Céspedes

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 183.611 | Caso de negocio, 2026-01-01 |

## Retorno esperado

Retorno esperado en 24 meses.
