# Definición de producto · Microseguros

**Código:** PRD-306
**Gerente de producto:** Paula Céspedes
**Segmento:** Base de la pirámide
**Fecha de la definición:** 2026-06-29

## El problema

El segmento Base de la pirámide no tiene microseguros.

## La propuesta

- Propuesta principal

## Supuestos

- **El proveedor cumple el tiempo pactado** · declarado el 2026-09-13 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
