# Caso de negocio · Remesas familiares

**Código:** PRD-307
**Fecha:** 2025-09-26
**Preparado por:** Gustavo Neira

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 252.237 | Caso de negocio, 2025-09-26 |

## Retorno esperado

Retorno esperado en 24 meses.
