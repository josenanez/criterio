# Caso de negocio · Cuenta PyME

**Código:** PRD-303
**Fecha:** 2026-02-02
**Preparado por:** Beatriz Cuéllar

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 276.747 | Caso de negocio, 2026-02-02 |

## Retorno esperado

Retorno esperado en 24 meses.
