# Corrida · 2026-10-15-project-charter-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-charter PRY-209 revisar

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-209

**Inicio:** 2026-10-15T11:15:33 · **Fin:** 2026-10-15T11:16:21 · **Duración:** 48 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-charter` | 13 | — | 33 | 44 | Revisión del acta de PRY-209 (2025-10-14): faltan autoridad del gerente, supuestos, restricciones, hitos, quién mide el éxito y cadencia; objetivo, alcance y exclusiones son genéricos. No sé qué se habló fuera de acta e informe; no hay minutas ni cronograma. |

Por señal (`project-charter`): `milestone_met_without_evidence` 12, `declared_vs_evidence` 8, `commitment_overdue` 3, `progress_vs_plan` 3, `commitment_undated` 3, `variance_time` 3, `vendor_deliverable_late` 3, `vendor_invoiced_without_delivery` 2, `rebaseline_unauthorized` 2, `pm_vs_pmo` 1, `silent` 1, `milestone_overdue` 1, `vendor_accepted_without_evidence` 1, `variance_cost` 1

## Lo que el agente mostró

Revisé el acta de PRY-209 y registré la corrida como `2026-10-15-project-charter-1`. La revisión completa está en `estado/corridas/salida-project-charter.md`. Los términos ya estaban vigentes (v0.3.8, aceptados por José Francisco Ñáñez el 2026-10-15), así que no registré nada nuevo.

El acta existe, es del 2025-10-14 y tiene vacíos importantes. Esto es lo que falta y lo que implica:

- **Autoridad del gerente:** no existe. No se sabe hasta qué monto ni qué cambio de alcance decide Sandra Gil sin comité. Pesa ahora porque la proyección (9.936.230.266 COP) supera lo aprobado (9.500.000.000 COP) en 436.230.266 COP, un 4,6 %. Nadie puede decir si ella puede absorberlo o si tiene que subir al comité.
- **Objetivo de negocio:** repite la solución («Entregar electrificación de equipos para Medio Ambiente») y no tiene cifra, beneficio ni fecha. El comité no tendría referencia para decidir un cambio de alcance.
- **Alcance y exclusiones:** el alcance es «Componente 1, 2, 3», sin contenido. La exclusión es «Lo que otro proyecto cubre», sin nombrar ningún proyecto. Tampoco hay dependencias declaradas. Con eso no se puede juzgar el riesgo de licencia ambiental que, según el informe, puede mover el alcance.
- **Supuestos, restricciones, hitos y quién mide el éxito:** no existen. El criterio de éxito («en producción y medido») no tiene umbral. Sin hitos, el 48 % de avance no se contrasta con ningún plan.
- **Cadencia del comité:** no está declarada y no hay minutas en la carpeta, así que no se puede comprobar que el Comité de Inversiones haya visto el rojo.
- **Lo que sí cumple:** patrocinador (Laura Vélez), gerente (Sandra Gil) y presupuesto aprobado.

Dejé todo lo que falta como «pendiente de definir». No completé nada con lo razonable.

Como el acta no declara la autoridad del gerente, ofrezco llevar esa definición al Comité de Inversiones como decisión. También ofrezco pasar al registro RAID los supuestos que salieron: la licencia ambiental vigente y la disponibilidad del ingeniero clave. Tomé «sí» a ambas ofertas por ser una prueba sin interfaz, pero no ejecuté ninguna.

Solo vi el acta y el informe de avance del 2026-10-08. No hay minutas, cronograma ni contratos, así que no sé qué se habló fuera de esos dos documentos.
