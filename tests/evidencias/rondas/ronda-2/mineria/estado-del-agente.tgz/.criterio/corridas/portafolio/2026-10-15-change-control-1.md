# Corrida · 2026-10-15-change-control-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:change-control PRY-202 mover la salida a producción 30 días

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-202

**Inicio:** 2026-10-15T11:10:17 · **Fin:** 2026-10-15T11:11:09 · **Duración:** 53 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `change-control` | 13 | — | 36 | 44 | Solicitud PRY-202 +30 días sobre el hito final (Pruebas en operación), supuesto declarado. Sin autoridad de cambios, sin motivo ni solicitante, sin costo estimado. Acta (cierre 2028-02-05) contradice cronograma v1 (2027-12-13). Sin dependencias declaradas; no se sabe si no existen. No se registró línea base nueva. |

Por señal (`change-control`): `milestone_met_without_evidence` 12, `declared_vs_evidence` 8, `commitment_overdue` 3, `progress_vs_plan` 3, `commitment_undated` 3, `variance_time` 3, `vendor_deliverable_late` 3, `vendor_invoiced_without_delivery` 2, `rebaseline_unauthorized` 2, `pm_vs_pmo` 1, `silent` 1, `milestone_overdue` 1, `vendor_accepted_without_evidence` 1, `variance_cost` 1

## Lo que el agente mostró

Terminé la solicitud de cambio de PRY-202 (+30 días) y la corrida quedó registrada. Es un paquete para comité: no registré ninguna línea base nueva, porque no hay aprobación.

**La solicitud**
- **Qué mueve:** la ficha no tiene un hito de «salida a producción». Tomé el hito final «Pruebas en operación». Pasa del 2027-12-13 al 2028-01-12.
- **Costo:** no hay estimación en ningún documento. La proyección declarada deja solo un 2 % de holgura sobre los 1.200 millones COP aprobados.
- **Quién decide:** el acta no declara autoridad de cambios, así que va a comité. Ese es el hallazgo de fondo.
- **Motivo y solicitante:** ningún documento dice quién lo pide ni por qué.
- **Contradicción de fechas:** el acta fija el cierre en 2028-02-05 y el cronograma v1 en 2027-12-13. Con el cambio, el cierre queda 24 días antes de la fecha del acta, pero sin holgura contra el cronograma.
- **Efecto en el portafolio:** no alcanza a ningún otro proyecto, pero solo porque ninguna ficha declara dependencia con PRY-202. No prueba que no existan.
- **Proveedor:** el contrato CT-503 no declara fecha de vencimiento. No puedo decir si 30 días más lo dejan vencido.
- **Estado actual:** el proyecto está en rojo, con 48 % de avance, un compromiso vencido y un hito que vence hoy sin evidencia.
- **Si se aprueba:** la línea base 2 llevaría una desviación de +30 días contra la original. La de costo queda sin dato.

**Términos:** ya estaban vigentes (versión 0.3.8, aceptados por José Francisco Ñáñez el 2026-10-15). No hizo falta registrarlos otra vez.

Dos cosas que tomé por mi cuenta, porque nadie iba a responder: que «salida a producción» es el hito final, y que el comité es el destino por defecto al no haber autoridad declarada.

Archivos en `/home/claude/banco/ronda-2/mineria/espacio/estado/corridas/`:
- `salida-change-control.md`
- `2026-10-15-change-control-1.md`
