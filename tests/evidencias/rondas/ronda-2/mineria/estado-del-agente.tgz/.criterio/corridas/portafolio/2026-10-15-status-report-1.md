# Corrida · 2026-10-15-status-report-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:status-report PRY-206

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-206

**Inicio:** 2026-10-15T11:05:57 · **Fin:** 2026-10-15T11:06:45 · **Duración:** 48 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `status-report` | 13 | — | 29 | 44 | Informe de estado de PRY-206: amarillo 77% declarado, sin evidencia, 20 días en silencio, cierre base ya pasado. Dijo que no sabe: hitos, proveedores, última reunión, producto/autoridad/fase. |

Por señal (`status-report`): `milestone_met_without_evidence` 12, `declared_vs_evidence` 8, `commitment_overdue` 3, `progress_vs_plan` 3, `commitment_undated` 3, `variance_time` 3, `vendor_deliverable_late` 3, `vendor_invoiced_without_delivery` 2, `rebaseline_unauthorized` 2, `pm_vs_pmo` 1, `silent` 1, `milestone_overdue` 1, `vendor_accepted_without_evidence` 1, `variance_cost` 1

## Lo que el agente mostró

## PRY-206 · Red privada LTE en mina — estado al 2026-10-15

Este informe sale de la ficha `estado/records/PRY-206.json` (actualizada el 2026-10-15) y del cálculo `compute` de hoy. Los términos ya estaban vigentes, aceptados el 2026-10-15 por José Francisco Ñáñez. Registré la corrida como `2026-10-15-status-report-1`.

- **Declara el gerente (Liliana Torres):** amarillo y 77 %, al 2026-09-25. Han pasado 20 días, así que la declaración no está vencida (el límite es 30).
- **Sustento documental:** sin sustento. Ninguna fuente de la ficha es evidencia, y cinco son declaraciones del propio informe de avance.
- **Lo que el semáforo no explica:** el silencio, con 20 días sin documentos (el umbral es 15).
- **Último documento:** 2026-09-25. **Última reunión:** sin dato, porque no hay minutas en la carpeta.

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2026-09-22 | 2026-09-22 | 0 días, pero el script no la mide sin hitos |
| Presupuesto | COP 4.200.000.000 | COP 4.200.000.000 | proyección declarada de COP 4.043.433.327 (-3,7 %) |

- **Replanificaciones:** 0.
- **Presupuesto:** el comprometido es COP 2.939.043.394 (70,0 %) y el ejecutado COP 823.740.094 (19,6 %). El disponible real es COP 1.260.956.606. Son cifras declaradas en el informe, sin contrastar con facturas.
- **Fecha de cierre pasada (observación mía, no del script):** la fecha de cierre de la línea base ya pasó. Aun así, el proyecto declara 77 % y amarillo. Sin cronograma no se puede medir cuánto falta.

### Hitos y dónde no coincide
- **Hitos:** sin dato, porque no hay cronograma en la carpeta.
- **Contradicciones:** no hay dos fuentes que se contradigan. Lo que hay es una declaración sin ningún documento que la sustente, y sin nada posterior en 20 días.

### Abierto
- **Riesgos e incidencias:** ninguno tiene fecha de último movimiento, así que no se pueden contar días. Hay tres, sin responsable ni fecha:
  - El proveedor no ha confirmado la fecha de la última entrega.
  - La ventana de parada de planta la define operaciones.
  - Un hallazgo abierto en la auditoría de seguridad.
- **Compromisos vencidos:** ninguno, pero tampoco hay compromisos registrados.
- **Dependencias sin confirmar:** ninguna registrada. El riesgo del proveedor sugiere una dependencia externa, pero la ficha no tiene proveedores ni contrato.

### Sin dato
- Producto, autoridad y fase.
- Hitos y cronograma.
- Proveedores, contratos y entregables.
- Fecha, responsable y probabilidad e impacto de los dos riesgos y la incidencia.
- Los campos que salen del acta de 2025-07-19 tienen 15 meses, por encima del límite de 12. Entre ellos están las fechas, el alcance y el presupuesto aprobado.

### Siguiente paso
El proyecto lleva más de 15 días en silencio, con la fecha de cierre pasada y una declaración sin sustento. Puedo preparar el punto de comité. Para avanzar hace falta el cronograma y una actualización del gerente.

---
Criterio Portfolio 0.3.8 · Ficha aplicada: `estado/records/PRY-206.json`, del 2026-10-15 · Campos inciertos: ver «Sin dato» · Términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.8

El mismo texto está guardado en `estado/corridas/salida-status-report.md`.
