# Corrida · 2026-10-15-portfolio-server-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-server rato

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-15T11:21:44 · **Fin:** 2026-10-15T11:22:29 · **Duración:** 44 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-server` | 13 | — | — | 44 | puerto 8787 local, informe en reportes, modo rato |

Por señal (`portfolio-server`): `milestone_met_without_evidence` 12, `declared_vs_evidence` 8, `commitment_overdue` 3, `progress_vs_plan` 3, `commitment_undated` 3, `variance_time` 3, `vendor_deliverable_late` 3, `vendor_invoiced_without_delivery` 2, `rebaseline_unauthorized` 2, `pm_vs_pmo` 1, `silent` 1, `milestone_overdue` 1, `vendor_accepted_without_evidence` 1, `variance_cost` 1

## Lo que el agente mostró

Rostrum quedó levantado en **http://127.0.0.1:8817/**, no en el 8787 que sugiere el comando. Lo comprobé con `/estado.json`: lista los 13 proyectos y los 6 productos de `reportes/`.

- **Puertos:** el 8787 y el 8788 ya los tenían otros servidores. Sirven informes distintos al de `reportes/` (otros productos y otra hora de generación), así que no abra esos dos.
- **Términos:** ya estaban vigentes (versión 0.3.8, aceptados por José Francisco Ñáñez el 2026-10-15), y no hizo falta registrarlos otra vez.
- **Modo:** «para mirarlo un rato», como pidió el argumento. Escucha solo en este equipo, no autentica y no manda nada. Para pararlo hay que matar su proceso, porque corre en segundo plano y no tiene Ctrl-C.
- **Rutas:** `/` portada y formulario de peticiones, `/pmo`, `/decisiones`, `/proyectos`, `/productos`, `/p/<código>`, `/producto/<nombre>`, `/corridas` y `/estado.json`.
- **Enlace:** solo lo abre quien esté en este equipo, así que no se le pasa a nadie. Un patrocinador necesita la segunda forma, «que quede corriendo». Para eso hay que pedir a la organización un host y un puerto en la red, publicarlo detrás de su control de acceso y que el equipo siga encendido.
- **Informe:** es del 2026-10-15 y queda desactualizado cuando cambie un documento o corra otro barrido. Antes de mandarle algo al patrocinador, regenérelo con `/portfolio-report html`.
- **Registro:** dejé lo mostrado en `estado/corridas/salida-portfolio-server.md` y registré la corrida `2026-10-15-portfolio-server-1`. Esos archivos dicen 8787, que fue el puerto previsto, no el que quedó.
