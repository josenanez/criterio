# Corrida · 2026-10-15-product-view-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:product-view despacho de flota

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-15T11:19:04 · **Fin:** 2026-10-15T11:19:42 · **Duración:** 38 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-view` | 13 | — | 20 | 44 | Producto de un solo proyecto (PRY-203): sin sección de producto. Dos hitos cumplidos sin evidencia y verde declarado contradicho. 7 proyectos sin producto declarado. No se sabe el área dueña (no sale del cálculo) ni si monitoreo de flota y despacho de flota son el mismo producto. |

Por señal (`product-view`): `milestone_met_without_evidence` 12, `declared_vs_evidence` 8, `commitment_overdue` 3, `progress_vs_plan` 3, `commitment_undated` 3, `variance_time` 3, `vendor_deliverable_late` 3, `vendor_invoiced_without_delivery` 2, `rebaseline_unauthorized` 2, `pm_vs_pmo` 1, `silent` 1, `milestone_overdue` 1, `vendor_accepted_without_evidence` 1, `variance_cost` 1

## Lo que el agente mostró

## Productos al 2026-10-15

Esta vista sale de las fichas del portafolio y del cálculo `compute` de hoy. Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15), así que no los registré de nuevo.

| Producto | Proyectos | Con alertas | Fecha más tardía | Aprobado | Comprometido |
|---|---|---|---|---|---|
| despacho de flota | 1 (PRY-203) | 1 (3 alertas) | 2026-10-17 | COP 1.200.000.000 | COP 772.433.451 |

**Despacho de flota tiene un solo proyecto (PRY-203).** La vista por producto no aporta nada ahí, así que no armé sección de producto. Esto es lo que muestran las fichas de ese proyecto:

- **Señales:**
  - Dos hitos figuran como cumplidos sin evidencia: «Ingeniería básica aprobada», que vencía el 2025-12-07, hace 312 días, y «Ingeniería de detalle aprobada», que vencía el 2026-05-13, hace 155 días.
  - El informe del 2026-10-12 declara verde, pero esos dos hitos no tienen soporte.
- **Avance:** declara 73 % y el plan soporta entre 67 % y 100 %, con 2 de 3 hitos cumplidos.
- **Fecha:** 2026-10-17, sin replanificaciones y sin desviación contra la línea base.
- **Dinero:** las cuatro cifras están completas.
  - Ejecutado: 514.897.208 (42,9 %).
  - Comprometido: 64,4 %.
  - Proyección: 1.120.646.033, que es −6,6 % frente al aprobado.
- **Dependencias internas:** ninguna, y no hay otro proyecto del producto con el que cruzarlas.
- **Lo que no se sabe:**
  - Ninguna fuente de la ficha es evidencia directa.
  - Faltan la autoridad que aprueba y la fase del proyecto.
  - Nueve campos tienen 16 meses de antigüedad.

**Proyectos sin producto declarado:** son siete de los 13: PRY-201, 202, 205, 206, 209, 210 y 211. Es un hallazgo de gobierno, porque nadie puede responder por el conjunto al que sirven. El cálculo no entrega el área dueña de ninguno, así que no la inventé.

«Monitoreo de flota» (PRY-200) es otro producto declarado y no lo uní con «despacho de flota». Si son el mismo producto con dos nombres, tiene que confirmarlo quien lo conozca.

La corrida quedó registrada como `2026-10-15-product-view-1`, con la salida completa en `estado/corridas/salida-product-view.md`. Es un borrador de trabajo con cita a las fichas, y la verificación es de quien lo lee.
