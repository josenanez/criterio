# Corrida · 2026-10-15-project-history-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-history PRY-207

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-207

**Inicio:** 2026-10-15T11:11:15 · **Fin:** 2026-10-15T11:12:49 · **Duración:** 95 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-history` | 13 | — | 76 | 44 | Historia de PRY-207 sobre 10 documentos (2026-05-21 a 2026-10-07): 1 replanificación (+106 días, 32,5%) sin aprobación; verde declarado con 6 señales abiertas; facturas sin acta de recibo. No sé: causa de la diferencia entre cierre del acta (2027-05-28) y v1 (2027-04-25), qué es el punto 33, el hallazgo de seguridad, ni los meses declarando sin sustento (un solo estado declarado). |

Por señal (`project-history`): `milestone_met_without_evidence` 12, `declared_vs_evidence` 8, `commitment_overdue` 3, `progress_vs_plan` 3, `commitment_undated` 3, `variance_time` 3, `vendor_deliverable_late` 3, `vendor_invoiced_without_delivery` 2, `rebaseline_unauthorized` 2, `pm_vs_pmo` 1, `silent` 1, `milestone_overdue` 1, `vendor_accepted_without_evidence` 1, `variance_cost` 1

## Lo que el agente mostró

## Historia · PRY-207 Gemelo digital de la planta · 2026-05-21 a 2026-10-07

**Leí:** 10 documentos entre 2026-05-21 y 2026-10-07. Ningún trimestre queda sin documentos, pero entre 2026-05-30 y 2026-08-26 no hay ninguno. De los datos de la ficha, 0 son evidencia, 5 son declaración y 11 no están marcados.

Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15), así que no se registraron de nuevo.

**En una línea:** el cronograma v2 del 2026-10-06 mueve el cierre de 2027-04-25 a 2027-08-09. Son 106 días de atraso, el 32,5% contra el original. Ese mismo día el informe declaró verde con 34% de avance. La solicitud de cambio CC-01, que justifica el movimiento, es del 2026-10-07 y sigue pendiente de presentación al comité. En agosto se radicaron dos facturas, una por contrato, sin acta de recibo. En una de ellas el entregable sigue pendiente y vencido.

| Replanificaciones | Atraso vs. original | Meses declarando sin sustento | Cambios de gobierno |
|---|---|---|---|
| 1 | 106 días (32,5%) | No calculable: hay un solo estado declarado | 0 |

**Hechos clave**
- **Replanificación:** el cronograma v2 es un día anterior a la solicitud que lo justifica. Hay 0 de 106 días autorizados.
- **Hito sin evidencia:** "Ingeniería básica aprobada" (2026-08-07) figura cerrado sin ningún acta en la carpeta. "Ingeniería de detalle aprobada" venció el 2026-10-11, hace 4 días.
- **Facturas:** FV-2517 (69.251.482 COP) y FV-1555 (102.304.427 COP) se radicaron antes del vencimiento del 2026-08-31. Los contratos exigen acta de recibo firmada por el gerente, y no hay ninguna. En CT-517 el entregable lleva 45 días vencido.
- **Informe en verde:** el informe del 2026-10-06 no menciona ninguna de las 6 señales abiertas.
- **Compromisos:** ninguno se repitió. Queda uno abierto y sin fecha, de Laura Vélez, "Entregar el punto 33", dicho el 2026-10-04.
- **Gobierno:** sin cambios de patrocinador, gerente ni comité.

**Lo que no sé**
- Por qué el acta dice cierre 2027-05-28 y el cronograma v1 dice 2027-04-25. El 106 sale de comparar contra v1, y no calculé la cifra contra la fecha del acta.
- Si el recibo de CT-555 existió fuera de la carpeta.
- Qué es el "punto 33".
- Cuál fue el hallazgo de la auditoría de seguridad.

**Intención:** que el atraso apareciera en un cronograma antes que en una solicitud no dice que alguien lo ocultara. Esa conversación la tiene una persona.

Puedo llevar la historia al comité, donde CC-01 espera presentación, o al cierre del proyecto si llega a haberlo.

La salida completa quedó en `/home/claude/banco/ronda-2/mineria/espacio/estado/corridas/salida-project-history.md`. La corrida quedó registrada como `2026-10-15-project-history-1` y tardó 76 segundos, con caso PRY-207.

*Pie de rigor: es un borrador de trabajo basado solo en los 10 documentos de la carpeta. Cada dato tiene su fuente en la ficha `estado/records/PRY-207.json`, y la verificación es de quien lo lea.*
