# Corrida · 2026-10-15-project-closure-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-closure PRY-206

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-206

**Inicio:** 2026-10-15T11:16:27 · **Fin:** 2026-10-15T11:17:20 · **Duración:** 53 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-closure` | 13 | — | 35 | 44 | Cierre no emitido como cumplimiento: no hay declaración de terminado ni evidencia del criterio de éxito (red en producción y medida). Ultimo informe 2026-09-25, amarillo 77%, fecha comprometida 2026-09-22 vencida sin replanificacion, 20 dias en silencio. Tres abiertos sin doliente. Sin lecciones sustentables. No se archivo. No se pudo determinar: cumplimiento, hitos, entregables, proveedor, causa de la brecha avance/ejecucion. |

Por señal (`project-closure`): `milestone_met_without_evidence` 12, `declared_vs_evidence` 8, `commitment_overdue` 3, `progress_vs_plan` 3, `commitment_undated` 3, `variance_time` 3, `vendor_deliverable_late` 3, `vendor_invoiced_without_delivery` 2, `rebaseline_unauthorized` 2, `pm_vs_pmo` 1, `silent` 1, `milestone_overdue` 1, `vendor_accepted_without_evidence` 1, `variance_cost` 1

## Lo que el agente mostró

## Cierre de PRY-206, Red privada LTE en mina (2026-10-15)

PRY-206 no se puede cerrar contra el criterio de éxito. Ningún documento dice que haya terminado.

**De dónde sale.** Leí la ficha `estado/records/PRY-206.json`, el acta de constitución del 2025-07-19 y el informe de avance del 2026-09-25. Las cifras derivadas vienen de `compute`. Los términos ya estaban vigentes a nombre de José Francisco Ñáñez, versión 0.3.8, así que no los registré de nuevo.

- **Criterio de éxito:** el acta pide "Red privada LTE en mina en producción y medido". No hay evidencia de que esté en producción ni de ninguna medición, así que no se puede determinar si se cumplió.
- **Estado reportado:** el último informe es del 2026-09-25 y declara amarillo, 77 % de avance. Esa cifra es solo declaración de la gerente, sin evidencia que la respalde.
- **Fecha:** el cierre comprometido era el 2026-09-22 y ya pasó. No hay replanificaciones, así que el atraso no está reconocido. El 0 de desviación quiere decir que nadie registró un cambio, no que se cumpliera.
- **Presupuesto (COP):**
  - Aprobado: 4.200.000.000.
  - Ejecutado a corte 2026-09-25: 823.740.094 (19,6 %).
  - Comprometido: 70,0 %.
  - Proyección declarada: 4.043.433.327 (−3,7 % sobre lo aprobado).
  - Con 77 % de avance declarado, las cifras no cuadran entre sí y la carpeta no explica por qué.
- **RAID:** hay tres puntos abiertos y ninguno tiene doliente con nombre, por lo que no se pueden dar por cerrados.
  - Un riesgo: el proveedor no ha confirmado la fecha de la última entrega.
  - Un riesgo: la ventana de parada de planta la define operaciones.
  - Una incidencia: un hallazgo de la auditoría de seguridad.
- **Lecciones:** ninguna se puede sustentar. La carpeta solo tiene el acta y un informe.
- **Silencio:** el proyecto lleva 20 días sin informe (umbral 15).

Para cerrarlo, la gerente Liliana Torres o el patrocinador Mauricio Pérez tendría que declarar por escrito que terminó y con qué evidencia. Si no terminó, hace falta una replanificación formal con su motivo, o una decisión explícita de cerrar sin cumplir el criterio. Además, cada punto abierto necesita un doliente con nombre.

No moví la carpeta a `archivo/` (respuesta sugerida tomada). Archivarlo lo sacaría del barrido diario cuando está vencido, en silencio y en amarillo.

La salida completa quedó en `estado/corridas/salida-project-closure.md`, y la corrida está registrada con id `2026-10-15-project-closure-1`.
