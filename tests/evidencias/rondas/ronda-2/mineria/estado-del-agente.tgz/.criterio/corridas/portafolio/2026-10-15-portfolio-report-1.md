# Corrida · 2026-10-15-portfolio-report-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-report html

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-15T11:19:47 · **Fin:** 2026-10-15T11:20:48 · **Duración:** 61 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-report` | 13 | 74 | 41 | 44 | 8 de 13 proyectos en verde contradichos por la evidencia; rebaseline sin autorización en PRY-207 y PRY-211; PRY-210 facturado sin entrega; PRY-206 en silencio |

Por señal (`portfolio-report`): `milestone_met_without_evidence` 12, `declared_vs_evidence` 8, `commitment_overdue` 3, `progress_vs_plan` 3, `commitment_undated` 3, `variance_time` 3, `vendor_deliverable_late` 3, `vendor_invoiced_without_delivery` 2, `rebaseline_unauthorized` 2, `pm_vs_pmo` 1, `silent` 1, `milestone_overdue` 1, `vendor_accepted_without_evidence` 1, `variance_cost` 1

## Lo que el agente mostró

El informe en HTML está generado. Está en `/home/claude/banco/ronda-2/mineria/espacio/reportes/` (23 páginas, 13 proyectos). El cálculo da 44 señales en 11 de los 13 proyectos y 8 de los 13 declaran verde con evidencia en contra. No se pidió ningún dato nuevo, y los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15).

**Qué vista va a cada audiencia**
- **`index.html`:** va por campo, con la cadena de evidencia completa. Es para quien va a actuar sobre los datos.
- **`decisiones.html`:** va por decisión, con lo que excede la facultad de quien gerencia. Es para el patrocinador.
- **PDF:** sale de imprimir el HTML.

**Lo que muestra el informe**
- **Qué cambió:** nada. La instantánea anterior es del mismo día y el diff dio 0 cambios.
- **Verdes contradichos (8):** son PRY-201, 203, 204, 205, 208, 210 y 211, más PRY-207 por sus nueve señales.
- **PRY-204 y PRY-205:** declaran 30 % y 26 % de avance, y el plan sostiene 67–100 %.
- **Línea base movida sin cambio aprobado:** PRY-207 (+106 días) y PRY-211 (+65 días, costo +12,6 %).
- **PRY-210:** el proveedor Montajes facturó $553.602.024 sin entregar.
- **PRY-206:** lleva 20 días en silencio y su fecha de fin (2026-09-22) ya pasó.
- **Hitos dados por cumplidos sin evidencia:** hay 12 señales de este tipo en 7 proyectos.
- **Autoridad de aprobación:** ninguno de los 13 proyectos la tiene identificada.

**Límites de esta corrida**
- El resumen que dejé en `estado/corridas/salida-portfolio-report.md` no recoge dos de las 44 señales: la que compara lo que dice el gerente con lo que dice la PMO en PRY-205, y la de facturación sin entrega en PRY-207. Están en el HTML y en el registro de la corrida.
- Las fichas estaban en `estado/records/`, no en `estado/fichas/`. Además hay una carpeta suelta `estado/PRY-205-…/` con su propio estado, que conviene revisar.
- La confirmación mensual de cinco campos quedó pendiente porque no había nadie para responder.

La corrida quedó registrada como `2026-10-15-portfolio-report-1`, con 41 segundos y 74 documentos sin relectura. Si hay comité próximo, el siguiente paso es el material de comité o entrar al detalle de PRY-207, 210 y 211.

Versión 0.3.8 · fichas aplicadas: 13, con corte 2026-10-15 · términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.8
