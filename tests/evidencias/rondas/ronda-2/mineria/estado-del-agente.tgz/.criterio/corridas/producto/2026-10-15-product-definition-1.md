# Corrida · 2026-10-15-product-definition-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-definition (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-15T10:45:27 · **Fin:** 2026-10-15T10:46:13 · **Duración:** 46 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-definition` | 4 | — | 29 | 14 | La evidencia sostiene débilmente el problema (una entrevista de hace 12 meses); contradice la cifra de volumen (37,7 % por debajo); faltan criterio de éxito y autoridad |

Por señal (`product-definition`): `decision_without_source` 4, `requirement_untraced` 4, `evidence_stale` 3, `requirement_accepted_without_evidence` 1, `assumption_unverified` 1, `claim_vs_metric` 1

## Lo que el agente mostró

La definición de PRD-300 (Monitoreo de flota) no se puede cerrar: faltan el criterio de éxito y quién decide. Corrí el contraste al 2026-10-15 y la corrida quedó registrada como `2026-10-15-product-definition-1`. Los términos ya estaban vigentes y registrados a nombre de José Francisco Ñáñez (2026-10-15), así que no los registré de nuevo.

- **Lo que la evidencia contradice:** el caso de negocio declara un `volumen_mensual` de 164.808 (2026-02-02). El tablero mide 102.629 (corte 2026-09-28). Lo declarado queda 37,7 % por encima, y el umbral es 20 %. La serie tiene un solo punto, así que no hay tendencia.
- **Afirmaciones numéricas que nadie mide:** el «retorno esperado en 24 meses» y el ahorro implícito no tienen cifra ni serie.
- **Lo que no está dicho:**
  - No hay criterio de éxito ni autoridad.
  - La propuesta es solo «Propuesta principal».
  - No hay método para la cifra de 164.808.
  - Ningún proyecto lo construye.
- **Supuesto sin verificar:** «el ahorro se sostiene sin inversión adicional» lleva 131 días (umbral 30). Para verificarlo hace falta una cifra de ahorro con línea base y el costo proyectado de operación; hoy no hay ninguno de los dos.
- **Lo que sostiene el problema:** una sola frase de un cliente sin nombre: «Lo necesito y hoy no lo tengo». Es evidencia débil y tiene 12 meses. No nombra el segmento Gerencia. Los requerimientos REQ-1000, REQ-1001 y REQ-1002 se apoyan en esa misma frase, y REQ-2017 no tiene evidencia.
- **Lo normativo:** no tengo la norma a la vista. Ningún documento dice el país ni qué datos recoge el producto (ubicación de vehículos o conductores, por ejemplo). No cité ninguna norma, y eso no significa que cumpla.
- **Aviso sobre las fechas:** el supuesto del ahorro lleva fecha 2026-06-06, pero la definición está fechada 2026-02-02. Se editó después sin cambiar la fecha del encabezado.
- **Después:**
  - El supuesto del ahorro se puede convertir en riesgo con doliente.
  - No ofrezco `/product-charter` porque la definición no está cerrada.

Salida completa: `estado-producto/PRD-300/corridas/salida-product-definition.md`
