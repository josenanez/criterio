# PRY-205 Sistema de gestión de seguridad — semana del 2026-10-09 al 2026-10-15

**Declara el gerente:** *(en blanco: no se declaró en esta sesión, que corre sin interfaz y nadie respondió. Lo último documentado es el informe del 2026-10-11: verde · 26 % — es un documento de hace 4 días, no la declaración de hoy.)*
**Sustento documental:** sin sustento. De las 15 fuentes del registro, 0 son evidencia, 5 son declaración y 10 no están marcadas.
**Lo que el semáforo no explica:** nada. Pero con cero evidencia que lo respalde o lo contradiga, eso no es lo mismo que «verde confirmado».

## Qué cambió esta semana
Primera corrida con snapshot en este estado: no hay corrida anterior contra la cual comparar, y el diff sale vacío (0 cambios). Lo siguiente es lo que apareció en los documentos de la semana, no un diff medido.

| Qué | Estaba | Está | |
|---|---|---|---|
| Compromiso «Entregar el punto 4» (Mauricio Pérez) | 2026-10-12 | 2026-10-29 | Reprogramado 1 vez, +17 días (notas 2026-10-15) |
| Compromiso «Mandar el ajuste del presupuesto» (Laura Vélez) | — | «la otra semana», sin fecha | Nuevo, **sin fecha** |
| Compromiso «Revisión con el proveedor» (Óscar Ramírez) | — | 2026-10-25 | Nuevo |
| Riesgo: el proveedor podría no llegar con el equipo completo para la siguiente fase | — | Dicho en reunión | Nuevo; **nadie lo anotó** (sin dueño, probabilidad ni impacto) |
| «Se reprogramó la parada de planta por la ventana de mantenimiento» | — | Dicho en el informe del 11-oct | Ver abajo: no hay replanificación en la línea base |

## Lo que sigue igual y sigue mal
| Qué | Desde | Días así |
|---|---|---|
| Los dos riesgos del informe (vía de acceso a la mina; ventana de parada de planta) no tienen dueño, probabilidad, impacto ni fecha de movimiento | 2026-10-11 (primer documento que los cita) | 4 |
| Sin hitos registrados en el plan (`plan.milestones` vacío) | Sin fecha de origen | No medible |

## Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2027-01-19 | 2027-01-19 | 0 días contra ambas |
| Presupuesto | COP 9.500.000.000 | COP 9.500.000.000 | Proyección COP 9.244.059.945 (−2,7 % sobre lo aprobado) |

Replanificaciones: 0. Pero el informe del 11-oct dice que se reprogramó la parada de planta, y la línea base sigue en la versión 1 (acta del 2025-08-11), sin solicitud de cambio. O el movimiento no tocó el plan, o hay un cambio sin registrar. Los documentos no lo aclaran.

### Hitos de las próximas cuatro semanas
No hay hitos cargados en la ficha. Existe `10-plan/2025-08-11-cronograma-v1.xlsx`, pero la ficha no tiene hitos extraídos de él. No se puede medir avance contra plan ni decir qué viene en las próximas cuatro semanas.

## Las cifras
| Aprobado | Comprometido | Ejecutado | Proyectado | Disponible real |
|---|---|---|---|---|
| 9.500.000.000 | 6.239.682.167 (65,7 %) | 5.491.598.094 (57,8 %) | 9.244.059.945 | **3.260.317.833** (aprobado − comprometido) |

Cifras en COP, todas de la declaración del informe del 2026-10-11 salvo el aprobado, que es del acta. Una lectura que el gerente debe mirar: el 57,8 % ejecutado frente al 26 % de avance declarado.

## Abierto
**Reprogramados:** Mauricio Pérez, «Entregar el punto 4» — 1 vez (12-oct → 29-oct). Aún no llega al umbral de 3.
**Vencidos sin evidencia:** ninguno.
**Sin fecha:** Laura Vélez, «Mandar el ajuste del presupuesto» — «la otra semana» (dicho el 2026-10-15). No hay forma de saber si vence.
**RAID sin movimiento:** los dos riesgos del informe del 11-oct, sin fecha de movimiento (4 días).
**Proveedor:** la ficha no tiene proveedores registrados, pero en reunión se habló de uno (revisión el 2026-10-25 y posible equipo incompleto). Sin contrato ni entregables cargados no hay nada que contrastar contra lo facturado.

## Lo que necesito de alguien
- **Rubén Cárdenas:** declarar estado y avance. Esta línea sale en blanco hasta entonces.
- **Rubén Cárdenas:** decir si la reprogramación de la parada de planta movió el plan; si lo movió, falta la solicitud de cambio y la línea base nueva.
- **Laura Vélez:** fijar fecha al ajuste del presupuesto.
- **Rubén Cárdenas / Óscar Ramírez:** registrar el riesgo del proveedor con dueño, probabilidad e impacto.
- **Quien mantenga el plan:** extraer los hitos del cronograma v1 a la ficha.

Nada de esto excede la autoridad del gerente, así que no hay material de comité por ahora.

## Lo que no se sabe
**Sin dato:** producto, autoridad, fase, hitos. 10 campos de identidad, plan y aprobado vienen del acta de hace 14 meses (2025-08-11) y están desactualizados (umbral: 12 meses).
**Silencio:** último documento hace 0 días (notas del 2026-10-15) · última reunión hace 0 días (2026-10-15). No hay silencio, pero tampoco evidencia: lo reciente son notas y declaraciones, no entregables.

---
Ficha: `records/PRY-205.json`, actualizada el 2026-10-15 · 4 campos sin dato (producto, autoridad, fase, hitos) · Términos: v1.1, aceptados por José Francisco Ñáñez el 2026-10-15 — https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.8
