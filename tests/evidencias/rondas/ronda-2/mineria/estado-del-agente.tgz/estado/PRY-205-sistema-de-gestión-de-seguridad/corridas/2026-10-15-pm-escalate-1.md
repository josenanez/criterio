# Corrida del 2026-10-15 · pm-escalate

1 proyectos · 37 s · 1 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_undated` | 1 |

Un solo punto escala: el acta no declara la autoridad del gerente. Se armó el paquete de esa decisión con tres opciones y recomendación. No se calculó impacto (nada mueve una fecha y la ficha no tiene hitos). No escalan: riesgo del proveedor sin doliente, 'punto 4' reprogramado una vez, ajuste de presupuesto sin fecha. No se sabe qué umbrales de autoridad pondría el comité.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## Para decisión — Sistema de gestión de seguridad (PRY-205) · 2026-10-15

*Supuestos, dichos de una vez: no vino un tema concreto ni había nada marcado como escalable, así que apliqué el criterio de la tabla «qué escala». Los términos ya estaban vigentes (José Francisco Ñáñez, versión 0.3.8, 2026-10-15); no se registraron de nuevo.*

### ¿Se declara por escrito qué puede decidir el gerente del proyecto sin subir al comité —alcance, fechas, presupuesto y proveedor—, o se acuerda que todo cambio pasa por el Comité de Operaciones?

**Quién decide:** María Restrepo (patrocinadora) con el Comité de Operaciones, que aprobó el presupuesto y el acta el 2025-08-11. El acta no dice quién puede decidir esto; lo asumo por ser quien aprobó el acta, y es lo que hay que confirmar. · **Si no se decide hoy:** no hay una fecha externa que venza; ningún documento trae una. Lo que pasa es que cada futuro punto (el riesgo del proveedor, un ajuste de presupuesto, un corrimiento de fecha) no se podrá clasificar como «decide el gerente» o «sube», y el gerente tendrá que escalar todo o nada. Primera ocasión para decidirlo: el comité del 2026-10-19 (`committee_next`; la cadencia está en duda, ver abajo).

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Declarar umbrales por escrito (por ejemplo, hasta cuántos días o cuántos COP decide el gerente) y anexarlos al acta | Sin cambio al alcance del proyecto; el acta gana una sección | Una sesión de comité más la redacción; sin impacto en el cronograma | Sin costo directo. **No sé** cuáles serían los umbrales: es decisión del comité, no mía |
| B. Todo cambio de alcance, fecha o presupuesto pasa por el Comité de Operaciones | Sin cambio | Cada cambio espera al comité (semanal según la configuración, cada dos semanas según las notas del 15) | Sin costo directo; más sesiones con puntos de decisión y más lentitud en lo menor |
| C. No declarar nada y seguir como hasta hoy | Sin cambio | Sin tiempo ahora | Gerente que no sabe qué puede decidir; puntos devueltos con un «eso lo decide usted» o decisiones tomadas sin facultad |

**Recomiendo:** A — porque el acta ya fija presupuesto (COP 9.500.000.000), fechas (2025-08-21 a 2027-01-19) y alcance, y solo falta el umbral. Con B se vuelve a escalar casi todo, y con C no se resuelve nada. Los umbrales concretos los pone el comité, no yo.

### A quién alcanza
No calculé el efecto con `portafolio.py impact`: lo que se escala no mueve ninguna fecha, y la ficha no tiene hitos (`plan.milestones` vacío). No afirmo que otros proyectos queden alcanzados; la propia acta dice «Dependencias declaradas: Ninguna declarada».

| Proyecto | Gerente | ¿Sostiene su fecha? | Dependencia confirmada |
|---|---|---|---|
| No calculado | — | — | — |

### Mis hitos por los que pasa
| Hito | Fecha vigente | En cuántos días |
|---|---|---|
| Ninguno registrado en la ficha | — | — |

### Lo que miré y no escala
| Punto | Por qué no escala |
|---|---|
| Riesgo «el proveedor podría no llegar con el equipo completo» | Se dijo el 15 y nadie lo anotó. Es un riesgo sin doliente, probabilidad ni impacto: se resuelve dentro del proyecto (ya está en la agenda de la reunión del 2026-10-19) y no hay evidencia de que exceda tu autoridad. Si crece, ese será el siguiente punto, y para eso hace falta la autoridad declarada |
| «Entregar el punto 4» (Mauricio Pérez) | Reprogramado una vez (12→29 de octubre); el umbral es tres |
| Ajuste del presupuesto (Laura Vélez) | Compromiso sin fecha; se arregla con una llamada |
| Revisión con el proveedor (Óscar Ramírez, 2026-10-25) | Dentro del proyecto |
| Proyección al cierre COP 9.244.059.945 contra aprobado 9.500.000.000 | Declarada por el gerente, dentro de lo aprobado; no hay sobrecosto que exceda nada |

### De dónde sale esto
- Sin autoridad declarada: `00-gobierno/2025-08-11-acta-constitucion.docx` (leída entera; no contiene ninguna sección de facultades) y `identity.authority` en `records/PRY-205.json`: `not_found`.
- Patrocinadora, comité, presupuesto, fechas y «Ninguna declarada»: la misma acta.
- Cadencia del comité: `.criterio/proyecto/PRY-205/config.json` (semanal, próximo 2026-10-19) frente a `2026-10-15-notas-reunion.txt` («próxima reunión en dos semanas»).
- Compromisos y riesgo del proveedor: `30-reuniones/2026-10-12-comite-semanal.md` y `2026-10-15-notas-reunion.txt`.
- Presupuesto y estado «verde, 26 %»: `20-seguimiento/2026-10-11-informe-avance.md`, declaración del gerente sin evidencia independiente.

*Llevarlo al comité es tuyo; esto no escala solo. No le escribí a nadie.*
