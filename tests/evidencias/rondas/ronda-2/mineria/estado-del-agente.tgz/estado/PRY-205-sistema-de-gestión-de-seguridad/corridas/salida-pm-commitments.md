## Compromisos — Sistema de gestión de seguridad (PRY-205) · al 2026-10-15

3 compromisos abiertos. Ninguno vencido, ninguno reprogramado 3 veces, ninguno cerrado con evidencia. Cifras de `portafolio.py compute`.

### Se viene reprogramando
Nada en el umbral (3 reprogramaciones). Hay un compromiso reprogramado una vez, para que se vea:

> **Mauricio Pérez** · Entregar el punto 4
> Prometido para el 2026-10-29, y antes para el 2026-10-12 (comité del 12, `30-reuniones/2026-10-12-comite-semanal.md`).
> Las notas del 15 dicen que «no alcanzó» (`2026-10-15-notas-reunion.txt`). No hay documento de entrega. Una vez no es un patrón; si el 29 se corre otra vez, son dos. Tampoco queda claro de qué entregable es «el punto 4».

Nota: `compute` no lo lista en `commitments_rescheduled` (queda bajo el umbral), y la fecha anterior ya pasó con el compromiso reprogramado, por eso `commitments_overdue` es 0.

### Vencidos sin evidencia
Ninguno hoy. La fecha original de Mauricio Pérez (2026-10-12) venció sin evidencia, pero ya fue reprogramada.

### Vencen esta semana
Ninguno. Lo más próximo:

| Quién | Qué | Para cuándo |
|---|---|---|
| Óscar Ramírez | Revisión con el proveedor | 2026-10-25 (cae en domingo; por confirmar si es la fecha real y si es compromiso suyo o una reunión ya agendada) |
| Mauricio Pérez | Entregar el punto 4 | 2026-10-29 |

### Sin fecha
| Quién | Qué | Dicho el |
|---|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto («la otra semana») | 2026-10-15 |

No puede estar vencido, por eso se cuenta aparte. «La otra semana» no es una fecha y no se convirtió en una.

### Cerrados desde la última revisión
Ninguno (sección omitida por regla; se deja constancia: ningún documento de entrega acompaña las notas).

### Después
- Ningún compromiso llega a 3 reprogramaciones, así que no hay decisión de comité que formular.
- Ningún compromiso cambió lo que la ficha dice; no hace falta `/pm-publish` por esto. (Sigue pendiente de confirmar lo de la cadencia del comité, del acta del 15.)
