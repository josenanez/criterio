Revisé la cadencia de PRY-205 (Sistema de gestión de seguridad): hoy no toca barrido, informe ni nada pendiente; el comité semanal es el 2026-10-19, a 4 días. Vuelvo el 2026-10-19.
