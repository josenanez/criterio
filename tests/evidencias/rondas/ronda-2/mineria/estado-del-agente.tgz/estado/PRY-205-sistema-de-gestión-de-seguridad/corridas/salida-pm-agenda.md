## Reunión de seguimiento — Sistema de gestión de seguridad (PRY-205) · 2026-10-19
5 puntos · 27 minutos · 4 personas requeridas (Rubén Cárdenas, Mauricio Pérez, Óscar Ramírez, Laura Vélez)

*Supuestos, dichos de una vez: la fecha es el próximo comité según la configuración (`committee_next` 2026-10-19; la cadencia está en duda, ver «Se decide hoy», tercera fila). No venía duración en el pedido; propuse 30 min y la suma da 27. Es la primera corrida del proyecto: no hay foto anterior, así que no puedo decir qué cambió «desde la reunión anterior», solo qué está abierto hoy.*

### Lo que no se destraba solo
Nada reprogramado tres veces: el compromiso más reprogramado lleva una (umbral: 3). Hoy la reunión es de seguimiento, no de rescate.

### Vencido sin evidencia
| Quién | Qué | Desde | Qué se necesita hoy | Min |
|---|---|---|---|---|
| Mauricio Pérez | Entregar el punto 4 | Prometido el 2026-10-12, reprogramado al 2026-10-29 (1 vez) | Que diga de qué entregable es «el punto 4» (ni el comité del 12 ni las notas del 15 lo dicen) y qué tiene hecho hoy; confirmar el 29 o corregirlo ahora, no el 29 | 7 |

Fuente: `30-reuniones/2026-10-12-comite-semanal.md` (compromiso original) y `2026-10-15-notas-reunion.txt` («no alcanzó»; sin documento de entrega).
**Si no se resuelve hoy:** el 29 llega sin que nadie sepa qué se iba a entregar, y es la segunda reprogramación.

### Se decide hoy o se atrasa
| Qué tiene que quedar resuelto | Quién decide | Si no se decide | Min |
|---|---|---|---|
| Doliente, probabilidad e impacto del riesgo «el proveedor podría no llegar con el equipo completo para la siguiente fase». Hoy nadie lo anotó ni lo atribuyó; los otros dos riesgos del RAID tampoco tienen doliente | Rubén Cárdenas, con Óscar Ramírez (lleva la revisión con el proveedor) | Sigue siendo algo que «se comentó»; sin doliente no se mueve. Fuente: `2026-10-15-notas-reunion.txt` | 8 |
| Fecha concreta para «mandar el ajuste del presupuesto» (dijo «la otra semana») | Laura Vélez | Compromiso sin fecha: no puede vencerse ni incumplirse. Fuente: `2026-10-15-notas-reunion.txt` | 4 |
| Si el comité es semanal (como dice la configuración) o cada dos semanas (como dicen las notas del 15). Puede ser que las notas hablen de otra reunión | Rubén Cárdenas | Cada cual cuenta su propia próxima reunión; afecta cuándo vence todo lo demás. Fuentes: notas del 15 vs `.criterio/proyecto/PRY-205/config.json` | 3 |

### Vence antes de la próxima
| Quién | Qué | Para cuándo |
|---|---|---|
| Óscar Ramírez | Revisión con el proveedor (5 min: confirmar que el 2026-10-25 es la fecha real, cae en domingo, y si es compromiso suyo o una reunión ya agendada) | 2026-10-25 |

Vence antes de la próxima solo si el comité sigue siendo semanal (siguiente: 2026-10-26); por eso conviene cerrar primero la cadencia (tercera fila de «Se decide hoy»).

### No es de esta reunión
| Qué | Por qué | Dónde va |
|---|---|---|
| Que la patrocinadora (María Restrepo) no figura entre los asistentes del 15 | Su doliente no está en esta sala | Comité / invitación del gerente; no lo decide esta agenda |
| Estado «verde, 26 %» sin evidencia independiente (0 fuentes de evidencia frente a 5 declaraciones) | No se resuelve hablando; requiere documentos | `/pm-report` |
| Faltan autoridad, fase y producto en la ficha | Datos de gobierno, no de seguimiento | Gerente, vía `/pm-setup` o `/pm-publish` |

### Anexo — sin cambios desde el [no calculable]
No hay foto anterior (primera corrida), así que no puedo afirmar qué «sigue igual». Con lo que hay: presupuesto aprobado COP 9.500.000.000, comprometido 65,7 %, ejecutado 57,8 %, proyección −2,7 % sobre lo aprobado (todo declarado en el informe del 2026-10-11, no verificado). Sin proveedores registrados en la ficha. Sin cambios de línea base. No se repasa en la reunión.

*Después de la reunión: `/pm-minutes` sobre las notas o la transcripción. Convocar es del gerente.*
