# Acta — Sistema de gestión de seguridad (PRY-205) · 2026-10-15

**Asistieron:** Elena Duarte, Mauricio Pérez, Rubén Cárdenas, Laura Vélez, Óscar Ramírez · **Fuente:** `2026-10-15-notas-reunion.txt` (notas de alguien, no transcripción; no dicen quién las tomó) · **Ausentes con tema en agenda:** no se puede decir, la reunión no tiene agenda escrita. Cabe notar que María Restrepo (patrocinadora según el acta de constitución) no figura entre los asistentes.

*Términos: ya vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15); no se registraron de nuevo.*

## Compromisos
| Quién | Qué | Para cuándo | |
|---|---|---|---|
| Mauricio Pérez | Entregar el punto 4 | 2026-10-29 | **Reprogramado, 1 vez.** Antes: 2026-10-12 (comité del 12, `30-reuniones/2026-10-12-comite-semanal.md`). Las notas dicen que «no alcanzó». Sin documento de entrega, el compromiso de la fecha anterior venció sin evidencia. |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-25 | Nuevo. Ver «Sin resolver»: esa fecha cae en domingo. |

### Sin fecha
| Quién | Qué |
|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto. Dijo «la otra semana», que no es una fecha y no se convirtió en una. |

## Decisiones
Ninguna. Las notas no registran ninguna decisión con quien la tomó ni con lo que se descartó.

## Quedó sin decidir
Las notas no nombran ningún tema que se haya discutido y dejado abierto, así que no se inventa uno.

## Intenciones sin doliente
Ninguna en estas notas.

## Dicho al pasar y no registrado
| Qué | Quién lo dijo | Categoría | Ya estaba en el RAID |
|---|---|---|---|
| «El proveedor podría no llegar con el equipo completo para la siguiente fase» | No consta: la nota dice «se comentó», sin atribuir | Riesgo (también apunta a una dependencia del proveedor) | No. El RAID tenía solo dos riesgos (bloqueo de la vía de acceso, ventana de parada de planta) y las notas dicen que «nadie lo anotó». La ficha ya lo trae con fuente en esta reunión, sin probabilidad, impacto ni doliente. |

## Cerrado en esta reunión
Nada. Ningún documento de entrega acompaña las notas.

## Lo que esta reunión contradice
| Campo | Dijo la reunión | Dice el expediente | Fuente y fecha de cada uno |
|---|---|---|---|
| Cadencia del comité | «Próxima reunión en dos semanas» (≈ 2026-10-29) | Comité semanal, próximo 2026-10-19 | Notas, 2026-10-15 · `.criterio/proyecto/PRY-205/config.json`, ciclo `weekly` / `committee_next` 2026-10-19 |

No es necesariamente un cambio de cadencia: las notas no dicen si hablan del comité o de esta reunión de trabajo, que quizá sea otra. Está por confirmar.

## Sin resolver de la transcripción
- «entregar el punto 4»: no queda claro de qué documento o entregable es el punto 4; el comité del 12 tampoco lo dice.
- «la otra semana» (Laura Vélez): ambiguo, sin día. Desde el jueves 2026-10-15 sería la semana del 19, pero eso lo supone el lector, no las notas.
- «queda para el 2026-10-25» (Óscar Ramírez): 2026-10-25 es domingo. No se sabe si es la fecha real o si falta corregirla. Tampoco queda claro si es un compromiso suyo o una reunión ya agendada con el proveedor.
- «se comentó que el proveedor podría no llegar…»: no consta quién lo dijo ni qué proveedor es (la ficha no tiene proveedores registrados).

## Cifras recalculadas (`portafolio.py compute`)
- 1 alerta: compromiso sin fecha (Laura Vélez).
- Compromisos vencidos: 0 (el de Mauricio ya está reprogramado). Reprogramados: 1 compromiso, 1 vez, por debajo del umbral de 3 para marcarlo.
- Estado declarado: verde, 26 % (informe del 2026-10-11, 4 días). Sin evidencia independiente en la ficha: 0 fuentes de evidencia frente a 5 declaraciones. Esta reunión no lo contradice, pero tampoco lo sustenta.

## Después
`/pm-commitments` para ver el seguimiento con estos tres compromisos. `/pm-publish` solo si confirmas el cambio de cadencia del comité. El acta es tuya: Samuel no la guarda en tu carpeta de reuniones.
