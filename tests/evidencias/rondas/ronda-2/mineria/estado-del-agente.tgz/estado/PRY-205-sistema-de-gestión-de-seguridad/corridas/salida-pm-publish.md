Publiqué la ficha en `/home/claude/banco/ronda-2/mineria/espacio/documentos/proyectos/PRY-205-sistema-de-gestión-de-seguridad/00-gobierno/ficha-pm.json`, con corte al 2026-10-15.

**Lleva:** 15 campos con dato · 4 sin decir en ninguna parte (identity.product, identity.authority, identity.phase, plan.milestones) · declara **verde** al 2026-10-11 (declaración tuya, marcada como declarada; 26 % de avance)

**Lo más viejo que va ahí:** los campos que salen del acta de constitución (código, nombre, área, patrocinador, comité, fechas, alcance y presupuesto aprobado), del 2025-08-11 — 14 meses, pasa de un año.

**Ojo:** la declaración verde no tiene ninguna fuente de evidencia detrás (0 de evidencia, 5 declaradas, 10 sin marcar). Hay un compromiso sin fecha: Laura Vélez, «Mandar el ajuste del presupuesto» («la otra semana»).
