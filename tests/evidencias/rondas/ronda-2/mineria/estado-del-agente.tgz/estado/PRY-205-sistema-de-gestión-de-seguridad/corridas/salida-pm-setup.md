## Listo — PRY-205 · Sistema de gestión de seguridad

**Lo que miré:** 5 documentos · 2 minutas (el comité del 2026-10-12 y las notas del 2026-10-15) · la última del 2026-10-15
**Formatos que no pude leer:** ninguno. El cronograma (`10-plan/2025-08-11-cronograma-v1.xlsx`) existe pero no lo leí: en esta instalación solo leí la última reunión. Por eso la ficha no trae hitos.
**Términos:** aceptados para la versión 0.3.8 (términos 1.1) por José Francisco Ñáñez, 2026-10-15 · comprobante en `.criterio/terminos/aceptacion-criterio-project-0.3.8-2026-10-15.md` y `.pdf` · SHA-256 fd18d9cd0b3d5a0f…

**Respuestas que tomé por defecto (sin interfaz):** gerente Rubén Cárdenas y proyecto PRY-205 según el acta · reunión de seguimiento semanal, lunes (el comité del 12 de octubre fue lunes; la próxima, el 2026-10-19; las notas del 15 dicen «próxima reunión en dos semanas», así que conviene confirmarlo) · estado en `estado/PRY-205-sistema-de-gestión-de-seguridad`.

### Lo que se prometió en tu última reunión (notas del 2026-10-15)
| Quién | Qué | Para cuándo | |
|---|---|---|---|
| Mauricio Pérez | Entregar el punto 4 | 2026-10-29 (antes 2026-10-12) | Abierto. Reprogramado una vez. Cita: «lo de "entregar el punto 4" no alcanzó, se compromete para el 29/10/2026» |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-25 | Abierto. Cita: «revisión con el proveedor, queda para el 2026-10-25» |

Ninguno está vencido a hoy. El compromiso del punto 4 estaba fechado el 2026-10-12 en el comité semanal y tres días después se volvió a prometer; no hay acta de recibo que muestre que se entregó.

### Sin fecha
- **Laura Vélez** — mandar el ajuste del presupuesto. Cita: «queda de mandar el ajuste del presupuesto la otra semana». «La otra semana» no es una fecha; no puede estar vencido, y por eso es el que se pierde. Hay que preguntarle la fecha en la próxima reunión.

### Otra cosa que se dijo y nadie anotó
- «El proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo.» La dejé en la ficha como riesgo sin dueño, probabilidad ni impacto. El informe de avance del 2026-10-11 (estado declarado: verde, 26%) lista otros dos riesgos y no este.

### Qué le falta a tu carpeta
- El cronograma vigente no está leído y solo hay una versión (v1, de 2025-08-11): sin hitos no se puede contrastar el 26% declarado.
- Minutas anteriores al 2026-10-12: solo hay una en `30-reuniones/`, así que no puedo ver cuántas veces se ha reprogramado cada compromiso.
- Actas de recibo de lo entregado: no hay ninguna; sin ellas un compromiso cumplido se ve igual que uno incumplido.
- El acta de constitución no dice hasta dónde puede decidir el gerente sin subir a comité, ni la fase, ni la dependencia con otros proyectos («Ninguna declarada»).
- Las notas del 2026-10-15 quedaron sueltas en la raíz del proyecto, no en `30-reuniones/`.

**Cuándo vuelvo:** el lunes 2026-10-19, según la reunión semanal.
Puedo leer ahora las minutas anteriores y el cronograma para tener el historial completo de compromisos.
