# Corrida del 2026-10-15 · portfolio-setup

3 proyectos · 74 documentos, 59 releídos y 15 sin cambio · 115 s · 13 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 4 |
| `declared_vs_evidence` | 3 |
| `commitment_overdue` | 2 |
| `progress_vs_plan` | 2 |
| `commitment_undated` | 1 |
| `pm_vs_pmo` | 1 |

0 preguntas (sesión sin interfaz; respuestas sugeridas tomadas). Unos 5 minutos hasta el primer resultado. Probó PRY-201, PRY-204, PRY-205: 13 señales, los tres en verde contradichos; hitos cerrados sin acta en PRY-204 y PRY-205; avance declarado muy por debajo del plan; 1 discrepancia pm_vs_pmo en PRY-205.

Primera corrida: no hay una anterior contra la cual comparar.

## Lo que produjo

## Listo — Portafolio de minería

**Miré:** 74 documentos en 13 proyectos (PRY-199 a PRY-211) · formatos: md 30, docx 14, pdf 14, csv 7, xlsx 7, json 1, txt 1 · más reciente: 2026-10-15
**Eres:** PMO del portafolio (se ven 13 proyectos)
**Te aviso:** dos días antes de cada comité; comité semanal (no me diste fecha, así que no hay una fecha concreta del próximo)
**En:** presentación
**Términos:** aceptados para la versión 0.3.8 (términos 1.1) por José Francisco Ñáñez, 2026-10-15 · comprobante en `.criterio/terminos/aceptacion-criterio-portfolio-0.3.8-2026-10-15.md` y `.pdf` · SHA-256 906ca52cb3296d17…

Dónde queda lo que voy encontrando: `estado/`. Informes: `reportes/`. Configuración: `.criterio/portafolio/config.json`. Ya existía `estado/PRY-205-sistema-de-gestión-de-seguridad/` con el trabajo del gerente de ese proyecto; no lo toqué.

### Probé con tres proyectos

Los de documentación más reciente (los tres con documento del 2026-10-15): PRY-201, PRY-204, PRY-205.

| Proyecto | Documentos | Qué supe | Qué no está |
|---|---|---|---|
| PRY-201 Ampliación de la relavera | 5 | Gerente Natalia Ospina, patrocinador Laura Vélez. Declara verde, 41 %. Aprobado 800 M COP, ejecutado 358,4 M, proyección 839,6 M (5,0 % sobre lo aprobado). 1 de 4 hitos cumplido, con acta de recibo del 2026-10-09 | Producto, facultad del gerente, fase |
| PRY-204 Monitoreo de taludes | 4 | Gerente Jorge Medina, patrocinador Ricardo Salas, producto «alerta de taludes». Declara verde, 30 %. Aprobado 2.400 M COP, ejecutado 493,8 M, proyección 2.505,7 M (4,4 % sobre lo aprobado). 2 de 3 hitos declarados cerrados | Facultad del gerente, fase |
| PRY-205 Sistema de gestión de seguridad | 6 | Gerente Rubén Cárdenas, patrocinadora María Restrepo. Declara verde, 26 %. Aprobado 9.500 M COP, ejecutado 5.491,6 M, proyección 9.244,1 M. Tiene ficha publicada por su gerente (`ficha-pm.json`), que guardé aparte sin mezclarla con la mía | Producto, facultad del gerente, fase |

### Hallazgos (los levantó el cálculo, 13 señales en total; los tres proyectos declaran verde y los tres tienen señales)

- **PRY-204 y PRY-205: hitos declarados cerrados sin documento que lo pruebe** (`milestone_met_without_evidence`). PRY-204: Ingeniería básica (2026-02-09, hace 248 días) e Ingeniería de detalle (2026-07-11, hace 96). PRY-205: Ingeniería básica (2026-01-15, hace 273) e Ingeniería de detalle (2026-06-11, hace 126). No hay un acta de recibo para ninguno. PRY-201 sí la tiene para su único hito cerrado.
- **PRY-204 y PRY-205: avance declarado por debajo de lo que sostiene el plan** (`progress_vs_plan`). PRY-204 declara 30 % y su cronograma, con 2 de 3 hitos cerrados, sostiene entre 67 % y 100 % (37 puntos de diferencia). PRY-205 declara 26 % contra 67–100 % (41 puntos). Con tantos hitos cerrados y tan poco avance, o el cronograma o el informe están mal.
- **Verde contradicho en los tres** (`declared_vs_evidence`). PRY-201 por un compromiso vencido; PRY-204 por compromiso vencido, hitos sin evidencia y avance; PRY-205 por hitos sin evidencia y avance.
- **PRY-201: compromiso vencido** (`commitment_overdue`). Liliana Torres, «Entregar el punto 15», para 2026-10-03, 12 días, anotado en el comité del 2026-10-15.
- **PRY-204: compromiso vencido.** Óscar Ramírez, «Entregar el punto 40», para 2026-10-14, 1 día.
- **PRY-205: compromiso sin fecha** (`commitment_undated`). Laura Vélez, «Mandar el ajuste del presupuesto», «la otra semana».
- **PRY-205: la ficha del gerente y mi lectura no coinciden** (`pm_vs_pmo`) en la fecha de cierre: 2027-01-19 en el acta de constitución, 2026-11-06 en la última fecha del cronograma. No decido quién tiene razón. Ojo: esa fecha del cronograma es la de su último hito (Licencia y permisos), que puede no ser el cierre del proyecto; conviene que el gerente lo aclare.
- Sin umbral, sin señal pero a la vista: en PRY-205 el proveedor «podría no llegar con el equipo completo» se dijo en la reunión del 2026-10-15 y nadie lo anotó como riesgo; lo dejé en la ficha como riesgo sin dueño. Además, un compromiso de Mauricio Pérez se reprogramó una vez (2026-10-12 → 2026-10-29); una sola reprogramación no levanta señal.
- Campos con más de 12 meses sin confirmar (14 meses) en PRY-204 y PRY-205: patrocinador, presupuesto aprobado, alcance, fechas. Las actas son de agosto de 2025 y nada posterior los confirma.
- Ningún proyecto tiene la facultad del gerente (hasta qué monto decide sin subir a comité) en ningún documento.

### El portafolio completo
10 proyectos más (PRY-199, 200, 202, 203 y 206 a 211), en dos lotes uno tras otro. Con lo que tardaron estos tres, estimo entre 25 y 35 minutos (es una estimación, no una medición).

### Lo que le falta a tu carpeta
- Actas de recibo de los hitos que los cronogramas dan por cerrados (PRY-204, PRY-205 y los que falten).
- Actas de constitución de 2025 que nadie ha vuelto a confirmar; y en ningún proyecto la facultad del gerente.
- PRY-205 tiene dos documentos (`ficha-pm.json` y las notas de reunión) fuera de las carpetas numeradas de siempre; funciona, pero conviene ordenarlos.
- PRY-206 solo tiene acta de constitución e informe: sin cronograma, sin reuniones.
- Ninguna fecha de próximo comité; con una, el aviso de dos días antes queda armado.

Ninguno es bloqueante.
