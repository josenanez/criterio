Fichas cargadas: 13 (PRY-199 a PRY-211), estado calculado el 2026-10-15. Términos v1.1 vigentes, aceptados por José Francisco Ñáñez el 2026-10-15 (no se registraron de nuevo).

# Comité de proyectos — 2026-10-15
6 decisiones · 4 escalamientos sin decisión · 11 de 13 proyectos con hallazgos

## Decisiones del comité anterior
No hay en el estado material de comité anterior ni acta de decisiones. No puedo cerrar el ciclo: no sé qué se decidió, qué se hizo ni qué sigue abierto. La única decisión que consta es la de PRY-208 CC-01, «autorizada por el comité» sin nombrar cuál comité ni fecha (punto 4).

## Decisiones de hoy

### [1] ¿Qué instancia tiene la facultad de aprobar cambios de alcance, tiempo y costo en este portafolio, y con qué umbrales?
**Proyecto:** todos · **Quién decide:** patrocinadores y la PMO (nadie lo tiene escrito) · **Si no se decide hoy:** los puntos 2, 3 y 4 quedan sin una instancia válida que los resuelva.

Por qué es el primer punto: en las 13 fichas el campo de autoridad está vacío. Las fichas nombran tres comités distintos: Comité de Operaciones (PRY-205, PRY-207), Comité Ambiental (PRY-206, PRY-208, PRY-211) y Comité de Inversiones (PRY-210). Ningún documento dice quién decide qué monto o cuántos días.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Cada proyecto decide en el comité que nombra su acta | Sin cambio | Cada comité con su propio ritmo | Sin límite común entre proyectos |
| B. Este comité decide los cambios de los 13 proyectos hasta fijar umbrales | Unifica el criterio | Un solo ciclo semanal | Un único tope de aprobación |
| C. Se difiere hasta definir la tabla de facultades | Los cambios pendientes quedan en espera | Los puntos 2 y 3 siguen sin resolverse | Sin efecto directo |

**Recomendación:** B, de forma provisional y con una tabla de facultades como entregable con fecha. Sin una instancia, las decisiones 2 a 4 serían cuestionables.

### [2] ¿Se aprueba el CC-01 de PRY-207 (Gemelo digital de la planta)?
**Proyecto:** PRY-207 · **Quién decide:** por definir (punto 1); el acta nombra al Comité de Operaciones · **Si no se decide hoy:** el cronograma vigente seguirá corriendo con +106 días que nadie autorizó, y la solicitud lleva sin presentarse desde 2026-10-07.

Hechos (cifras del cálculo):
- La solicitud pide ampliación de alcance, +106 días y 212.000.000 COP. Dice «pendiente de presentación al comité».
- El cronograma v2 (2026-10-06) ya movió la línea base 106 días: 32.5 % de desviación contra la original, con 0 días autorizados.
- Hito «Ingeniería de detalle aprobada» vencido hace 4 días; «Ingeniería básica aprobada» declarado cumplido sin evidencia (69 días).
- Contrato CT-517 (Equipos Pesados Andinos): 69.251.482 COP facturados, 0 entregables aceptados, «Licenciamiento del software» con 45 días de atraso.
- Contrato CT-555 (Montajes Industriales): un entregable aceptado sin evidencia de aceptación.
- El informe de avance del 2026-10-06 declara verde.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar y fijar la línea base nueva, conservando la anterior | Ampliado | +106 días | +212.000.000 COP |
| B. Rechazar y revertir al cronograma anterior | Sin ampliar | El atraso real queda a la vista | Sin costo adicional |
| C. Diferir hasta que el gerente sustente el licenciamiento y la factura de CT-517 | Sin definir | El reloj sigue corriendo | Sin definir |

**Recomendación:** C, con fecha para el próximo comité. La ampliación se apoya en un cronograma que ya incorporó el atraso sin autorización, y hay una factura pagada sin entrega. Aprobar hoy ratificaría ambas cosas sin haberlas visto. No tengo base para decir si el alcance adicional se justifica: eso es del negocio.

### [3] ¿Se aprueba el CC-01 de PRY-211 (Control de polvo en vías)?
**Proyecto:** PRY-211 · **Quién decide:** por definir (punto 1); el comité de la ficha es el Comité Ambiental · **Si no se decide hoy:** la línea base ya se movió 65 días sin autorización y el gasto proyectado sigue sobre el umbral.

Hechos:
- La solicitud pide ampliación de alcance, +65 días y 130.000.000 COP, fechada 2026-10-08, «pendiente de presentación al comité».
- La línea base ya está movida 65 días (13.3 % contra la original) con 0 autorizados.
- Costo proyectado: 2.702.499.056 COP contra 2.400.000.000 COP aprobados, 12.6 % de sobrecosto, sobre el umbral de 10 %.
- El informe del 2026-10-12 declara verde.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar y fijar la línea base nueva | Ampliado | +65 días | +130.000.000 COP (la proyección ya lo supera) |
| B. Rechazar y revertir la línea base | Sin ampliar | Atraso visible | Sobrecosto proyectado sin explicar |
| C. Diferir hasta que el gerente explique el 12.6 % | Sin definir | El reloj sigue | Sin definir |

**Recomendación:** C. Hay que saber de dónde sale el 12.6 % antes de decidir si el cambio de 130.000.000 COP lo agrava o lo absorbe. La ficha no lo explica.

### [4] ¿Se ratifica la autorización del CC-01 de PRY-208 (Trazabilidad del mineral)?
**Proyecto:** PRY-208 · **Quién decide:** por definir (punto 1) · **Si no se decide hoy:** hay +113 días y 226.000.000 COP en la línea base con una autorización que nadie puede atribuir.

Hechos: la solicitud (2026-10-11) dice «autorizada por el comité» sin decir cuál, quién ni cuándo. La línea base se movió 113 días (28.2 % contra la original) y esos días sí constan como aprobados. Los dos hitos de ingeniería se declaran cumplidos sin evidencia (278 y 145 días).

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Ratificar y exigir el acta del comité que decidió | Ampliado | +113 días | +226.000.000 COP |
| B. Tratar la autorización como no válida hasta que aparezca el acta | Sin definir | Atraso sin respaldo | Sin definir |

**Recomendación:** A, condicionada a que el gerente entregue el acta antes del próximo comité. Si no aparece, pasa a B.

### [5] ¿Cuál es la fecha de cierre vigente de PRY-205 (Sistema de gestión de seguridad)?
**Proyecto:** PRY-205 · **Quién decide:** el patrocinador, María Restrepo, con el comité · **Si no se decide hoy:** cada lado seguirá midiendo contra una fecha distinta.

Hechos: el cronograma v1 (2025-08-11) dice 2026-11-06 y el acta de constitución, con la misma fecha, dice 2027-01-19. Ningún documento posterior resuelve cuál manda. Sobre 9.500.000.000 COP aprobados, el informe declara verde y 26 % de avance; el plan sustenta entre 67 % y 100 % (41 puntos de brecha) y los dos hitos de ingeniería constan como cumplidos sin evidencia.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Vale 2026-11-06 (cronograma) | Sin cambio | La brecha de avance queda sin sustento | Sin cambio |
| B. Vale 2027-01-19 (acta) | Sin cambio | Más holgura sobre la misma brecha | Sin cambio |
| C. Se reconoce el atraso y se pide un cambio formal | Por definir | Por definir | Por definir |

**Recomendación:** que el patrocinador elija una fecha y que el gerente presente un plan de recuperación. No recomiendo A ni B por defecto: las dos son fechas de hace 14 meses y la brecha de 41 puntos no cabe en ninguna. Si C, se tramita como cambio, no como corrección de la ficha.

### [6] ¿Se retienen los pagos de PRY-210 (Programa de relacionamiento comunitario) hasta que haya aceptación?
**Proyecto:** PRY-210 · **Quién decide:** por definir (punto 1); comité de la ficha: Comité de Inversiones · **Si no se decide hoy:** los entregables siguen atrasados con la facturación al día.

Hechos:
- CT-637 (Montajes Industriales): 553.602.024 COP facturados, 0 entregables aceptados, «Licenciamiento del software» con 66 días de atraso.
- CT-414 (Ingeniería Minera del Sur): «Licenciamiento del software» con 118 días de atraso; 654.129.595 COP facturados y aceptados.
- Hitos de ingeniería declarados cumplidos sin evidencia (125 y 55 días). El informe del 2026-10-10 declara verde.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Retener pagos pendientes de CT-637 y CT-414 hasta la aceptación | Sin cambio | Presiona a los proveedores | Evita pagar lo no entregado |
| B. Seguir pagando y exigir fecha de entrega | Sin cambio | Sin presión contractual | Exposición sobre los 553.602.024 COP ya facturados |
| C. Pedir revisión de CT-637 antes de decidir | Sin cambio | Una semana más | Sin cambio |

**Recomendación:** C. La ficha no trae los términos de pago ni de aceptación de los contratos, y sin ellos no sé si retener es contractualmente posible. Es una revisión corta, no un aplazamiento.

## Escalamientos sin decisión asociada
| Proyecto | Qué | Desde cuándo | Qué se necesita |
|---|---|---|---|
| PRY-206 | Silencio de 20 días; la fecha de cierre (2026-09-22) ya pasó; declara amarillo con 77 % | Último informe 2026-09-25 | Que Liliana Torres informe y presente fecha nueva |
| PRY-202 | Declara rojo y 48 % de avance, con 0 de 5 hitos cumplidos (el plan sustenta 0–20 %); compromiso «punto 15» de María Restrepo vencido 14 días | Compromiso vencido desde 2026-10-01 | Aclarar de dónde sale el 48 % y fecha firme del compromiso |
| PRY-204 | Declara verde y 30 % contra 67–100 % que sustenta el plan (37 puntos de brecha); compromiso de Óscar Ramírez vencido 1 día | Informe del 2026-10-14 | Replanificación o explicación de la brecha |
| PRY-201 | Declara verde, pero el compromiso de Liliana Torres («punto 15») lleva 12 días vencido | Vencido desde 2026-10-03 | Fecha firme y quién responde |

No evalué «dos períodos sin movimiento» ni «mitigación vencida sin evidencia»: sin comité anterior no hay período previo contra el cual comparar.

## Para conocimiento
- PRY-199 Luminarias: sin alertas; declara verde y 20 %.
- PRY-200 Mantenimiento predictivo: declara rojo; un hito declarado cumplido sin evidencia.
- PRY-203 Despacho de flota: declara verde; dos hitos sin evidencia; la ficha tiene 16 meses de antigüedad.
- PRY-209 Electrificación: declara rojo y sin otras alertas; sobrecosto proyectado de 4.6 %; datos base de hace 12 meses.

## Anexo
**Contradicciones abiertas:** PRY-205, fecha de cierre (punto 5). Además, 8 de 13 proyectos declaran verde con señales abiertas en contra: PRY-201, 203, 204, 205, 207, 208, 210 y 211.

**Compromisos sin fecha:** Laura Vélez «mandar el ajuste del presupuesto» (PRY-205, 2026-10-15) y «punto 33» (PRY-207, 2026-10-04); María Restrepo «punto 22» (PRY-211, 2026-10-14).

**Riesgo no registrado:** las notas del 2026-10-15 de PRY-205 mencionan que el proveedor podría no llegar con el equipo completo a la siguiente fase; nadie lo anotó. Corresponde a `raid-log`.

**Vacíos de información:**
- Autoridad de aprobación: vacía en las 13 fichas. Fase: vacía en las 13.
- Evidencia: las 13 fichas tienen 0 datos marcados como evidencia. Todo viene de declaraciones del gerente o de documentos sin marcar, así que ningún dato de este paquete está verificado contra un registro independiente.
- Fichas con datos base de más de 12 meses: PRY-203, 204, 205, 206, 208 y 209.
- PRY-206 no tiene cálculo de avance contra plan.

**Totales del cálculo:** 13 proyectos, 11 con alertas, 44 alertas, 6 productos.

---
Versión de la familia 0.3.8 · términos 1.1 · fichas aplicadas: 13, estado del 2026-10-15 · campos inciertos: autoridad, fase, evidencia (ver anexo) · Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.8

Cierre sugerido: una vez el comité sesione, puedo registrar las decisiones en las fichas, y ahí es donde se cierra el ciclo.
