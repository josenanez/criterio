# Corrida del 2026-10-15 · portfolio-wake

13 proyectos · 29 s · 44 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 12 |
| `declared_vs_evidence` | 8 |
| `commitment_overdue` | 3 |
| `progress_vs_plan` | 3 |
| `commitment_undated` | 3 |
| `variance_time` | 3 |
| `vendor_deliverable_late` | 3 |
| `vendor_invoiced_without_delivery` | 2 |
| `rebaseline_unauthorized` | 2 |
| `pm_vs_pmo` | 1 |
| `silent` | 1 |
| `milestone_overdue` | 1 |
| `vendor_accepted_without_evidence` | 1 |
| `variance_cost` | 1 |

Barrido: 74 documentos, ninguno cambió. Confirmación: 5 preguntas de autoridad (PRY-200, 202, 209, 206, 207), sin respuesta en sesión sin interfaz. Sin peticiones. No se sabe quién es la autoridad de aprobación de ningún proyecto.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## 2026-10-15

**Revisé:** 74 documentos · 0 cambiaron · 0 proyectos recalculados. Peticiones en el servidor: ninguna.

### Lo que cruzó un umbral
Nada. El barrido corrió y no había noticia.

### Preguntas (confirmación mensual, 5 de 13 proyectos)
Primera confirmación (no hay corrida anterior). En los cinco, el campo «autoridad» (quién puede aprobar cambios) figura como no encontrado en la documentación; se priorizaron los proyectos en rojo y los de dato más viejo.

1. PRY-200 (rojo, informe del 2026-10-11): ¿quién es la autoridad de aprobación? Ningún documento la nombra.
2. PRY-202 (rojo, informe del 2026-10-13): ¿quién es la autoridad de aprobación? Ningún documento la nombra.
3. PRY-209 (rojo, informe del 2026-10-08): ¿quién es la autoridad de aprobación? Ningún documento la nombra.
4. PRY-206 (amarillo, informe del 2026-09-25, el más viejo): ¿quién es la autoridad de aprobación? Ningún documento la nombra.
5. PRY-207 (verde, informe del 2026-10-06): ¿quién es la autoridad de aprobación? Ningún documento la nombra.

Sesión sin interfaz: nadie respondió. Las preguntas quedan abiertas; no se escribió nada en las fichas.

**Vuelvo el 2026-10-16.**
