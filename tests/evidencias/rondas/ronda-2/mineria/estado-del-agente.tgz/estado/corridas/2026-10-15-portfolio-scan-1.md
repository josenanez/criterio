# Corrida del 2026-10-15 · portfolio-scan

13 proyectos · 74 documentos, 0 releídos y 74 sin cambio · 204 s · 44 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 12 |
| `declared_vs_evidence` | 8 |
| `commitment_overdue` | 3 |
| `progress_vs_plan` | 3 |
| `commitment_undated` | 3 |
| `variance_time` | 3 |
| `vendor_deliverable_late` | 3 |
| `vendor_invoiced_without_delivery` | 2 |
| `rebaseline_unauthorized` | 2 |
| `pm_vs_pmo` | 1 |
| `silent` | 1 |
| `milestone_overdue` | 1 |
| `vendor_accepted_without_evidence` | 1 |
| `variance_cost` | 1 |

10 fichas nuevas (PRY-199,200,202,203,206,207,208,209,210,211), 59 documentos leídos, 15 sin cambio (PRY-201,204,205). Nada movido: no hay entrada/. Sin ilegibles. Mirar: 8 hitos cerrados sin acta, cronogramas v2 sin CC aprobada (207, 211), facturas sin entregable recibido (207, 210), PRY-206 en silencio y con cierre vencido.

Contra la corrida del 2026-10-15: +31 hallazgos.

## Lo que produjo

## Barrido — 2026-10-15

**Términos:** vigentes (v1.1, familia 0.3.8), aceptados por José Francisco Ñáñez el 2026-10-15; no hizo falta registrarlos de nuevo. Nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal

**Documentos:** 74 en la carpeta · 59 leídos · 15 sin cambio desde la corrida anterior · 0 ilegibles
**Proyectos:** 13 con ficha · 10 nuevos · 0 sin carpeta propia

Plan ejecutado tal cual: 1 lote de 10 proyectos, uno tras otro en esta conversación (`workers: 1`), sin subagentes; 0 documentos diferidos. Los 15 documentos sin cambio son de PRY-201, PRY-204 y PRY-205, cuyas fichas se conservaron sin tocar. Formatos leídos: 30 md, 14 docx, 14 pdf, 7 xlsx, 7 csv (docx y xlsx se extrajeron con un script propio y los pdf con pdftotext).

### Nuevos
| Proyecto | Documentos | Campos encontrados | Campos sin dato |
|---|---|---|---|
| PRY-199 Cambio de luminarias del campamento | 6 | identidad, plan (5 hitos), presupuesto, 1 contrato (CT-199), 1 acta de recibo, riesgos, 1 compromiso | autoridad, fase |
| PRY-200 Mantenimiento predictivo de camiones | 4 | identidad, plan (3 hitos), presupuesto, riesgos, 2 compromisos | autoridad, fase |
| PRY-202 Planta de tratamiento de agua | 5 | identidad, plan (5 hitos), presupuesto, 1 contrato (CT-503), riesgos, 1 compromiso | producto (acta: «No aplica»), autoridad, fase |
| PRY-203 Despacho automático de flota | 4 | identidad, plan (3 hitos), presupuesto, riesgos, 1 compromiso | autoridad, fase |
| PRY-206 Red privada LTE en mina | 2 | identidad, presupuesto, riesgos | producto («No aplica»), autoridad, fase, hitos (no hay cronograma) |
| PRY-207 Gemelo digital de la planta | 10 | identidad, plan v1 y v2, presupuesto, 2 contratos (CT-555, CT-517), 2 facturas, CC-01, riesgos, 1 compromiso | autoridad, fase |
| PRY-208 Trazabilidad del mineral | 6 | identidad, plan v1 y v2, presupuesto, CC-01, riesgos, 1 compromiso | autoridad, fase |
| PRY-209 Electrificación de equipos | 2 | identidad, presupuesto, riesgos | producto («No aplica»), autoridad, fase, hitos (no hay cronograma) |
| PRY-210 Programa de relacionamiento comunitario | 9 | identidad, plan (5 hitos), presupuesto, 2 contratos (CT-414, CT-637), 2 facturas, 1 acta de recibo, riesgos, 1 compromiso | producto («No aplica»), autoridad, fase |
| PRY-211 Control de polvo en vías | 11 | identidad, plan v1 y v2, presupuesto, 1 contrato (CT-147), 3 actas de recibo, 1 factura, CC-01, riesgos, 1 compromiso | producto («No aplica»), autoridad, fase |

La autoridad del gerente y la fase no aparecen en ningún documento de los diez proyectos; quedan `not_found`.

### Actualizados
| Proyecto | Qué cambió | Fuente |
|---|---|---|
| — | Ninguna ficha previa se actualizó: PRY-201, PRY-204 y PRY-205 no tuvieron documentos nuevos ni cambiados. | plan de lectura |

### Lo que el barrido encontró (cálculo del script sobre las fichas nuevas: 31 señales en 8 de los 10 proyectos)

- **Declarado en verde con señales en contra, 5 proyectos** (PRY-203, 207, 208, 210, 211). Por ejemplo, PRY-208 declara verde con 68 % la línea base se movió 113 días (+28,2 %) y sus dos hitos cerrados no tienen acta; PRY-211 declara verde con proyección de costo +12,6 % sobre lo aprobado.
- **Hitos declarados cerrados sin acta de recibo, 8 hitos en 5 proyectos** (PRY-200: 1; PRY-203: 2; PRY-207: 1; PRY-208: 2; PRY-210: 2). La carpeta no trae el documento que los pruebe; puede existir y no estar archivado. Con acta sí quedaron el hito de ingeniería básica de PRY-199 y los dos de PRY-211.
- **Cronograma v2 sin aprobación documentada, 2 proyectos** (PRY-207: +106 días; PRY-211: +65 días). En ambos la solicitud CC-01 está «pendiente de presentación al comité» y el cronograma v2 ya recorrió la fecha. En PRY-208 la CC-01 (+113 días) figura autorizada por «el comité», sin nombrar cuál.
- **Contradicción entre documentos, 3 proyectos** (PRY-207, 208, 211): el último hito del cronograma v2 cae después del cierre comprometido en el acta (207: 2027-08-09 contra 2027-05-28; 208: 2027-01-25 contra 2026-12-10; 211: 2027-09-25 contra 2027-09-10). Se registran los dos valores en `plan.end_date`, como `ambiguous`.
- **Proveedores:** facturas sin ningún entregable recibido con acta en PRY-207 (CT-517, 69.251.482 COP) y PRY-210 (CT-637, 553.602.024 COP); un entregable declarado «recibido» sin acta en PRY-207 (CT-555, licenciamiento); 3 entregables con fecha vencida y sin recibo (PRY-207 CT-517; PRY-210 CT-414 y CT-637). En PRY-210, la factura FV-1414 (2026-08-28) es anterior al acta de recibo de la bolsa de horas (2026-09-12) y no dice qué entregable cubre. Las facturas dicen «Entregables del contrato» y no los nombran.
- **Compromisos:** 1 vencido sin evidencia (PRY-202, punto 15, venció 2026-10-01) y 2 sin fecha («por definir»: PRY-207 y PRY-211). Otros 6 abiertos con fecha. Varios responsables no figuran entre los asistentes de su comité; lo anoto sin concluir nada.
- **Silencio:** PRY-206 lleva 20 días sin documento nuevo (último, 2026-09-25) y su cierre comprometido, 2026-09-22, ya pasó sin cierre ni cronograma en la carpeta; declara amarillo con 77 %.
- **Avance declarado frente al plan:** PRY-202 declara 48 % y su plan, con ningún hito cerrado, sustenta entre 0 y 20 %.
- **Cifras que no cuadran dentro del mismo informe:** en PRY-200, PRY-208 y PRY-211 el ejecutado declarado supera al comprometido (por ejemplo PRY-208: 454.535.191 ejecutado contra 256.136.235 comprometido). Se guardan tal cual, como declaración.
- **Informes que mencionan equipos entregados «pendientes de aceptación»** (PRY-203, 208, 210) sin contrato ni acta en la carpeta que los identifique.
- **Dependencias:** todas las actas dicen «Ninguna declarada»; no se levantó ninguna. Tampoco aparecen proyectos que solo se mencionen en minutas de otro.

### No pude leer
| Archivo | Por qué |
|---|---|
| — | Ninguno: 0 ilegibles. |

### Movidos desde entrada/
| Archivo | A qué proyecto | Por qué |
|---|---|---|
| — | No hay carpeta `entrada/` en la documentación; no se movió nada. | |

### Pendientes de clasificar
| Archivo | Por qué no pude decidir |
|---|---|
| — | Ninguno. |

---
Criterio portfolio 0.3.8 · fichas tocadas: 10 (PRY-199, 200, 202, 203, 206, 207, 208, 209, 210, 211), todas selladas con sus hashes · campos en `not_found`: autoridad y fase en los 10; producto en 5 (PRY-202, 206, 209, 210, 211); hitos en 2 (PRY-206, 209) · Borrador de trabajo con cita a cada fuente; la verificación es suya. Términos: https://www.josenanez.com/es/agents/criterio-pmo/legal
