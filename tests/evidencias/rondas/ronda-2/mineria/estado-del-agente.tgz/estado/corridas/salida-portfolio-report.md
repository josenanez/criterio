# Portafolio — 2026-10-15
13 proyectos · 11 con hallazgos (44 señales) · 6 productos · último barrido 2026-10-15

Fichas cargadas: 13 (`estado/records/`), con corte al 2026-10-15; ninguna con más de una semana sin barrido en lo que mide el cálculo. Formato pedido: html. Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15).

## Qué cambió desde la corrida anterior
Sin cambios desde la corrida anterior (la instantánea previa es del mismo día, 2026-10-15; el diff dio 0 cambios).

## Contradicciones abiertas
El cálculo no reportó campos en conflicto entre fuentes. Lo que sí hay es una contradicción de otro tipo: **8 de 13 proyectos declaran "verde" y la evidencia lo contradice** (ver Estado general).

## Hitos vencidos sin evidencia
| Proyecto | Hito | Fecha | Días | Última mención |
|---|---|---|---|---|
| PRY-207 Gemelo digital | Ingeniería de detalle aprobada | 2026-10-11 | 4 | — |

## Hitos dados por cumplidos sin evidencia
| Proyecto | Hito | Fecha | Días |
|---|---|---|---|
| PRY-200 | Ingeniería básica aprobada | 2026-06-23 | 114 |
| PRY-203 | Ingeniería básica / de detalle aprobada | 2025-12-07 / 2026-05-13 | 312 / 155 |
| PRY-204 | Ingeniería básica / de detalle aprobada | 2026-02-09 / 2026-07-11 | 248 / 96 |
| PRY-205 | Ingeniería básica / de detalle aprobada | 2026-01-15 / 2026-06-11 | 273 / 126 |
| PRY-207 | Ingeniería básica aprobada | 2026-08-07 | 69 |
| PRY-208 | Ingeniería básica / de detalle aprobada | 2026-01-10 / 2026-05-23 | 278 / 145 |
| PRY-210 | Ingeniería básica / de detalle aprobada | 2026-06-12 / 2026-08-21 | 125 / 55 |

## Proyectos en silencio
| Proyecto | Días | Último documento |
|---|---|---|
| PRY-206 Red privada LTE en mina | 20 | 2026-09-25 (fin planificado 2026-09-22, ya pasó) |

## Dependencias en riesgo
Vacía: el cálculo no reportó dependencias en riesgo entre proyectos.

## Sin sustento
| Proyecto | Declara | Qué lo respalda |
|---|---|---|
| PRY-204 | 30 % de avance | El plan sostiene 67–100 % (2 de 3 hitos cumplidos): brecha de 37 puntos, por detrás |
| PRY-205 | 26 % de avance | El plan sostiene 67–100 %: brecha de 41 puntos, por detrás |
| PRY-202 | 48 % de avance | El plan sostiene 0–20 % (0 de 5 hitos): 28 puntos por delante de lo sustentado |
| PRY-207 | Proveedor Montajes Industriales: "Licenciamiento del software" aceptado | Sin evidencia de aceptación |
| PRY-210 | Montajes Industriales: facturado $553.602.024 | Sin entregables recibidos (2 pendientes); además 2 entregables vencidos 118 y 66 días |
| PRY-207 | Equipos Pesados Andinos: licenciamiento | Pendiente, 45 días vencido |

## Vacíos de información
- Responsable/autoridad: **ningún proyecto (13 de 13)** tiene autoridad de aprobación identificada.
- Compromisos sin fecha: PRY-205 (Laura Vélez, ajuste del presupuesto), PRY-207 (Laura Vélez, punto 33), PRY-211 (María Restrepo, punto 22).
- Compromisos vencidos: PRY-201 (Liliana Torres, punto 15, 12 días), PRY-202 (María Restrepo, punto 15, 14 días), PRY-204 (Óscar Ramírez, punto 40, 1 día).
- Proyectos sin producto asociado: PRY-201, 202, 205, 206, 209, 210, 211.
- Estructura de carpeta: existe `estado/PRY-205-sistema-de-gestión-de-seguridad/` con su propio estado, aparte del estado común; conviene revisar si es un resto de otra corrida.
- PRY-206 y PRY-209 no tienen avance declarado calculable.

## Estado general
| Proyecto | Declarado | Sustento | Desviación vs original | vs vigente | Replanificaciones |
|---|---|---|---|---|---|
| PRY-199 Luminarias | — | Sin alertas | 0 d | 0 d | 0 |
| PRY-200 Mantenimiento predictivo | — | 1 hito sin evidencia | 0 d | 0 d | 0 |
| PRY-201 Relavera | verde | Contradicho: compromiso vencido | 0 d | 0 d | 0 |
| PRY-202 Planta de agua | — | Avance adelantado sin hitos; compromiso vencido | 0 d | 0 d | 0 |
| PRY-203 Despacho de flota | verde | Contradicho: 2 hitos sin evidencia (fin 2026-10-17) | 0 d | 0 d | 0 |
| PRY-204 Taludes | verde | Contradicho: atraso de 37 pts, hitos sin evidencia, compromiso vencido | 0 d | 0 d | 0 |
| PRY-205 Seguridad | verde | Contradicho: atraso de 41 pts, hitos sin evidencia (fin 2026-11-06) | 0 d | 0 d | 0 |
| PRY-206 Red LTE | — | En silencio 20 días, fecha de fin pasada | 0 d | 0 d | 0 |
| PRY-207 Gemelo digital | — | 9 señales, incluye rebaseline no autorizado | +106 d (32,5 %) | 0 d | 1 |
| PRY-208 Trazabilidad | verde | Contradicho: +113 d (28,2 %), hitos sin evidencia | +113 d (28,2 %) | 0 d | 1 |
| PRY-209 Electrificación | — | Sin alertas | 0 d | 0 d | 0 |
| PRY-210 Comunitario | verde | Contradicho: facturado sin entrega, hitos sin evidencia | 0 d | 0 d | 0 |
| PRY-211 Polvo en vías | verde | Contradicho: +65 d (13,3 %), costo +12,6 % ($2.702.499.056 vs $2.400.000.000), rebaseline no autorizado | +65 d | 0 d | 1 |

Rebaselines sin autorización: PRY-207 y PRY-211 (la línea base se movió sin cambio aprobado).

## Necesito que confirmes
Sin pregunta de confirmación mensual en esta corrida: la sesión es de prueba y no hay quien responda. Queda pendiente para la corrida con interlocutor.

---
Informe en HTML generado en `reportes/` (23 páginas): `index.html` (por campo, con cadena de evidencia; para quien va a actuar) y `decisiones.html` (por decisión; para el patrocinador).
Pie: criterio-portfolio 0.3.8 · fichas aplicadas: 13, corte 2026-10-15 · campos inciertos: los listados en Sin sustento y Vacíos · términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.8
