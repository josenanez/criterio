# Corrida del 2026-10-15 · vendor-tracking

13 proyectos · 36 s · 44 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 12 |
| `declared_vs_evidence` | 8 |
| `commitment_overdue` | 3 |
| `progress_vs_plan` | 3 |
| `commitment_undated` | 3 |
| `variance_time` | 3 |
| `vendor_deliverable_late` | 3 |
| `vendor_invoiced_without_delivery` | 2 |
| `rebaseline_unauthorized` | 2 |
| `pm_vs_pmo` | 1 |
| `silent` | 1 |
| `milestone_overdue` | 1 |
| `vendor_accepted_without_evidence` | 1 |
| `variance_cost` | 1 |

Cruce de CT-555 y CT-517: CT-517 facturado sin entrega (licenciamiento 45 días tarde), CT-555 licenciamiento aceptado sin acta. Dijo que no sabía: vigencia, renovación y preaviso de ambos contratos (no están en los documentos) y el total facturado (compute no lo da).

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

**Sale de:** la ficha `estado/records/PRY-207.json`, la salida de `portafolio.py compute` (as_of 2026-10-15) y la lectura directa de los contratos CT-555 y CT-517 (`00-gobierno`), el comité del 2026-10-04 (`30-reuniones`) y las dos facturas (`20-seguimiento`). Términos vigentes, aceptados por José Francisco Ñáñez el 2026-10-15 (versión 0.3.8).

## Proveedores — PRY-207 Gemelo digital de la planta, al 2026-10-15

### Montajes Industriales Ltda. — contrato CT-555
**Vigencia:** firma 2026-05-21; inicio y fin no declarados · **Preaviso de no renovación:** no declarado · **Vence el:** no declarado (el último entregable está comprometido para 2027-02-27)

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento del software | 2026-08-31 · COP 102.304.427 | `accepted` (el contrato dice «recibido») | **Ninguna** | Factura 2026-08-28, COP 102.304.427 |
| Bolsa de horas de ingeniería | 2026-11-29 · COP 102.304.427 | pending (el contrato dice «en curso») | — | No |
| Calibración de sensores | 2027-02-27 · COP 102.304.427 | pending | — | No |

Fuentes: contrato `00-gobierno/2026-05-21-contrato-ct-555.docx`; factura `20-seguimiento/2026-08-28-factura-ct-555.pdf`.

### Equipos Pesados Andinos — contrato CT-517
**Vigencia:** firma 2026-05-30; inicio y fin no declarados · **Preaviso de no renovación:** no declarado · **Vence el:** no declarado (último entregable comprometido para 2027-02-27)

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento del software | 2026-08-31 · COP 69.251.482 | pending, **45 días de atraso** | Ninguna | Factura 2026-08-26, COP 69.251.482 |
| Bolsa de horas de ingeniería | 2026-11-29 · COP 69.251.482 | pending (el contrato dice «en curso») | — | No |
| Calibración de sensores | 2027-02-27 · COP 69.251.482 | pending (el contrato dice «en curso») | — | No |

Fuentes: contrato `00-gobierno/2026-05-30-contrato-ct-517.docx`; factura `20-seguimiento/2026-08-26-factura-ct-517.pdf`.

### Dónde no cuadra
| Qué | Dice el contrato | Dice la evidencia | Fuentes |
|---|---|---|---|
| CT-517 facturado sin entrega (`vendor_invoiced_without_delivery`) | Cada entregable se factura contra acta de recibo firmada por el gerente del proyecto | Facturado COP 69.251.482 con 0 de 3 entregables aceptados; el licenciamiento sigue pendiente, vencido hace 45 días. La factura es del 2026-08-26, antes incluso de la fecha comprometida (2026-08-31) | contrato CT-517; factura CT-517 |
| CT-555 licenciamiento aceptado sin acta | Facturar contra acta de recibo firmada | Se factura COP 102.304.427 el 2026-08-28; no hay acta ni correo de aceptación en la carpeta | contrato CT-555; factura CT-555 |
| Mismo entregable en dos contratos | CT-555 y CT-517 comprometen «Licenciamiento del software» con la misma fecha (2026-08-31); uno figura recibido y el otro pendiente | No hay documento que explique el reparto del alcance entre ambos proveedores | ambos contratos |
| Informe de avance en verde | — | El informe del 2026-10-06 declara verde y no da cuenta de `vendor_deliverable_late` ni de `vendor_invoiced_without_delivery` | `20-seguimiento/2026-10-06-informe-avance.pdf` |

### Sin evidencia de recibo
| Entregable | Marcado como | Desde |
|---|---|---|
| Licenciamiento del software (CT-555) | accepted / «recibido» | Vencía 2026-08-31; factura del 2026-08-28. Sin acta en la carpeta |

Por regla de `project-record`, sin evidencia el estado verificable es `unknown`, no entregado.

### Compromisos del proveedor vencidos
Ninguno. El único compromiso del comité del 2026-10-04 es de Laura Vélez («Entregar el punto 33», «por definir»). Ni siquiera está claro que sea del lado del proveedor; está sin fecha y no se puede medir su vencimiento. El comité tampoco recoge ningún compromiso de Montajes Industriales ni de Equipos Pesados Andinos.

### Sin dato
- **Vigencia, renovación automática y preaviso** de CT-555 y CT-517: los contratos de la carpeta no los traen. No se puede decir si algún preaviso vence antes del cierre del proyecto (fin vigente 2027-08-09).
- **Actas de recibo** de cualquiera de los seis entregables: ninguna en la carpeta.
- No se sumó el total facturado porque `compute` no lo entrega. Los montos por proveedor van arriba tal como salen.

## Qué sigue
Hay un entregable facturado sin entrega (CT-517) y otro facturado con aceptación sin sustento (CT-555). Conviene llevar ambos a comité y pedir las actas de recibo o detener el pago de lo que quede. Además, esta corrida lee el cambio de cronograma de 106 días como no autorizado (`rebaseline_unauthorized`); eso va en el control de cambios, no aquí.

---
**Pie de rigor:** cifras copiadas de `portafolio.py compute` y de los contratos y facturas citados. Sin evidencia de aceptación, el estado es `unknown`. Criterio produce borradores de trabajo, no decisiones ni asesoría; la verificación contra los documentos originales es de quien lo lee.
