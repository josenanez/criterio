Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15); no hubo que registrarlos de nuevo.

**De qué documentos sale:** las 13 fichas de `estado/records/` (PRY-199 a PRY-211, su sección RAID, cambios y compromisos), las 12 minutas y notas de reunión de `documentos/proyectos/` (8 en .md, 3 en .docx y las notas .txt de PRY-205) y el informe de avance de PRY-208. PRY-206 y PRY-209 no tienen ninguna minuta en la carpeta.

## RAID — portafolio de minería al 2026-10-15
**Registrado hoy:** 23 riesgos · 0 supuestos · 12 incidencias · 0 dependencias (35 ítems)
**Tras reclasificar:** 12 riesgos · 0 supuestos · 12 incidencias · 11 dependencias
35 de 35 sin doliente · 35 de 35 sin fecha · sin movimiento: no medible (ver abajo) · 1 no registrado formalmente

Los ítems no tienen identificador en las fichas; las etiquetas `199·R1` etc. son de este informe, no del registro. No hay escala de probabilidad e impacto definida por la organización y ninguno de los 35 ítems trae probabilidad ni impacto, así que no valoré ninguno.

**Lo que más pesa:** el registro es una lista de frases copiadas del informe de avance. Ningún ítem tiene doliente ni fecha, ninguna dependencia está registrada y ningún supuesto fue levantado. La carpeta tiene un solo corte (`snapshots/2026-10-15.json`), por lo que no puedo decir qué ítems llevan dos períodos sin moverse. Solo un ítem (205·R3) tiene fecha de movimiento. "Sin movimiento" aquí es "sin historial", no "estancado".

### Necesitan decisión ahora
| Id | Tipo | Qué | Doliente | Desde | Por qué sube |
|---|---|---|---|---|---|
| 203·R2 / 203·I1 | Dependencia + incidencia | El proveedor no ha confirmado la fecha de la última entrega; el equipo perdió dos semanas por rotación de un ingeniero clave | Sin doliente | Sin fecha | El proyecto cierra el 2026-10-17 (en 2 días) y reporta verde. El riesgo "concentración del conocimiento en una sola persona" (203·R1) ya se materializó en la incidencia. |
| 206·D1 / 206·I1 | Dependencia + incidencia | Proveedor sin confirmar la última entrega; hallazgo abierto en la auditoría de seguridad | Sin doliente | Sin fecha | La fecha de fin era 2026-09-22 y el último informe es del 2026-09-25: 20 días de silencio contra un umbral de 15, sin ninguna minuta. Estado amarillo declarado. |
| 205·R3 | Riesgo (no registrado formalmente) | El proveedor podría no llegar con el equipo completo para la siguiente fase | Sin doliente | 2026-10-15 | Dicho en reunión y nadie lo anotó. El proyecto declara verde con fin el 2026-11-06 (22 días). El compromiso de Óscar Ramírez "revisión con el proveedor" es para el 2026-10-25, pero la nota no lo une a este riesgo, así que no lo cuento como mitigación. |
| 200·I1, 202·I1 | Incidencia | Se reprogramó la parada de planta por la ventana de mantenimiento | Sin doliente | Sin fecha | Ambos proyectos están en rojo y su incidencia no tiene responsable ni fecha de resolución. |
| 209·I1, 209·I2 | Incidencia | Rotación de un ingeniero clave (dos semanas perdidas); lluvias detuvieron el montaje diez días | Sin doliente | Sin fecha | Proyecto en rojo con dos incidencias sin responsable. 209·R2 (concentración del conocimiento) ya ocurrió en la primera. |
| 211·I2 | Incidencia | El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite | Sin doliente | Sin fecha | El proyecto reporta verde con una solicitud de cambio pendiente (CC-01, +65 días, +130 MCOP). Un ensayo fallido no cuadra con el verde. |
| Proveedor compartido (199, 202, 210, 211) | Dependencia entre proyectos | "Ingeniería Minera del Sur S.A.S." es proveedor en CT-199, CT-503, CT-414 y CT-147. Montajes Industriales Ltda. aparece en CT-555 (207) y CT-637 (210). | Sin doliente | Sin fecha | Afecta a más de un proyecto. 202, 210 y 211 registran "el proveedor no ha confirmado la fecha de la última entrega", pero el informe no dice cuál proveedor. No puedo afirmar que sea el mismo. |

Los cinco criterios de escalamiento no se pueden comprobar casi en ninguno: la autoridad del gerente no está declarada en las fichas, no hay historial de movimiento ni mitigaciones con fecha. Lo que sube arriba sube por incidencia sin responsable en proyecto rojo o por plazo inminente, y eso es juicio mío, no un criterio cumplido.

### Detectados en reuniones, no registrados
| Qué | Tipo | Dicho en | Fecha |
|---|---|---|---|
| El proveedor podría no llegar con el equipo completo para la siguiente fase («nadie lo anotó como riesgo») | Riesgo | PRY-205, `2026-10-15-notas-reunion.txt`, línea 7 | 2026-10-15 |

Es el único. Busqué lenguaje de riesgo ("depende", "podría", "si no", "bloqueo", "retraso") en los 12 documentos de reunión y no apareció nada más. Las demás minutas (11) solo traen asistentes y una tabla de compromisos. Dos compromisos de 205 son del mismo día, pero no son riesgos: "Laura Vélez, ajuste del presupuesto, la otra semana" (sin fecha) y "Mauricio Pérez, punto 4" (movido del 2026-10-12 al 2026-10-29).

### Reclasificados
| Ítem | Antes | Ahora | Por qué |
|---|---|---|---|
| "El proveedor no ha confirmado la fecha de la última entrega" (200, 201, 202, 203, 206, 210, 211) | Riesgo | Dependencia | Depende de un tercero fuera del proyecto. No es futuro incierto sino una confirmación que falta hoy. |
| "Ventana de parada de planta definida por operaciones" (199, 200, 205, 206) | Riesgo | Dependencia | La fecha la fija Operaciones, no el proyecto. En 200 la parada ya se reprogramó (200·I1), así que lo que era dependencia ya se movió. |

No toqué las fichas; la reclasificación vive en este informe. Si usted la acepta, hay que reflejarla en el registro.

### Sin doliente o sin fecha
Los 35 ítems: ninguno tiene doliente, ninguno tiene fecha. No rellené nada y no propongo nombres en este informe.

Detalle por proyecto (ítems sin doliente ni fecha): 199 (2), 200 (3), 201 (2), 202 (2), 203 (3), 204 (1), 205 (3), 206 (3), 207 (2), 208 (3), 209 (4), 210 (3), 211 (4).

Faltan además, en las 13 fichas: supuestos (0), probabilidad e impacto (0 de 23 riesgos) y fecha de inicio de las incidencias (`since` vacío en las 12).

### Dependencias en riesgo
**El cruce entre proyectos no se pudo hacer: ninguna dependencia lleva el código del proyecto del que depende.** Las 11 dependencias son declaradas, no acordadas: ninguna tiene confirmación de la contraparte.

| Id | Depende de | Confirmada | Qué pasó |
|---|---|---|---|
| 199·D1 | Operaciones (ventana de parada) | No | Sin información. |
| 200·D1 | Operaciones (ventana de parada) | No | La parada ya se reprogramó (200·I1). |
| 200·D2, 201·D1, 202·D1, 203·D1, 206·D1, 210·D1, 211·D1 | Proveedor (sin nombrar en el informe) | No | La fecha de la última entrega sigue sin confirmar. |
| 205·D1, 206·D2 | Operaciones (ventana de parada) | No | Sin información. |

Tres proyectos movieron su línea base: PRY-207 (v2, fin 2027-08-09, antes 2027-04-25), PRY-208 (v2, fin 2027-01-25, antes 2026-10-04) y PRY-211 (v2, fin 2027-09-25, antes 2027-07-22). Ninguno de los otros 10 declara depender de ellos, y ninguno puede declararlo porque no hay dependencias con código. Si alguno depende de 207, 208 o 211, hoy nadie lo sabe. Todas las actas traen la exclusión genérica "Lo que otro proyecto cubre", sin decir cuál proyecto.

### Registro completo
Probabilidad, impacto, doliente y fecha están sin registrar en todos los ítems (—). "Último mov." es "sin registro" salvo donde se indica.

| Id | Tipo | Qué | Prob. | Impacto | Doliente | Fecha | Último mov. |
|---|---|---|---|---|---|---|---|
| 199·R1 | Riesgo | Bloqueo de la vía de acceso a la mina | — | — | — | — | sin registro |
| 199·D1 | Dependencia (antes riesgo) | Ventana de parada de planta definida por operaciones | — | — | — | — | sin registro |
| 200·D1 | Dependencia (antes riesgo) | Ventana de parada de planta definida por operaciones | — | — | — | — | sin registro |
| 200·D2 | Dependencia (antes riesgo) | El proveedor no ha confirmado la fecha de la última entrega | — | — | — | — | sin registro |
| 200·I1 | Incidencia | Se reprogramó la parada de planta por la ventana de mantenimiento | — | — | — | — | sin registro |
| 201·R1 | Riesgo | Cambio en la licencia ambiental que puede mover el alcance | — | — | — | — | sin registro |
| 201·D1 | Dependencia (antes riesgo) | El proveedor no ha confirmado la fecha de la última entrega | — | — | — | — | sin registro |
| 202·D1 | Dependencia (antes riesgo) | El proveedor no ha confirmado la fecha de la última entrega | — | — | — | — | sin registro |
| 202·I1 | Incidencia | Se reprogramó la parada de planta por la ventana de mantenimiento | — | — | — | — | sin registro |
| 203·R1 | Riesgo | Concentración del conocimiento en una sola persona (ya ocurrió: ver 203·I1) | — | — | — | — | sin registro |
| 203·D1 | Dependencia (antes riesgo) | El proveedor no ha confirmado la fecha de la última entrega | — | — | — | — | sin registro |
| 203·I1 | Incidencia | El equipo perdió dos semanas por rotación de un ingeniero clave | — | — | — | — | sin registro |
| 204·R1 | Riesgo | Bloqueo de la vía de acceso a la mina | — | — | — | — | sin registro |
| 205·R1 | Riesgo | Bloqueo de la vía de acceso a la mina | — | — | — | — | sin registro |
| 205·D1 | Dependencia (antes riesgo) | Ventana de parada de planta definida por operaciones | — | — | — | — | sin registro |
| 205·R3 | Riesgo, no registrado formalmente | El proveedor podría no llegar con el equipo completo para la siguiente fase | — | — | — | — | 2026-10-15 |
| 206·D1 | Dependencia (antes riesgo) | El proveedor no ha confirmado la fecha de la última entrega | — | — | — | — | sin registro |
| 206·D2 | Dependencia (antes riesgo) | Ventana de parada de planta definida por operaciones | — | — | — | — | sin registro |
| 206·I1 | Incidencia | Se levantó un hallazgo en la auditoría de seguridad | — | — | — | — | sin registro |
| 207·R1 | Riesgo | Concentración del conocimiento en una sola persona | — | — | — | — | sin registro |
| 207·I1 | Incidencia | Se levantó un hallazgo en la auditoría de seguridad | — | — | — | — | sin registro |
| 208·R1 | Riesgo | Cambio en la licencia ambiental que puede mover el alcance | — | — | — | — | sin registro |
| 208·I1 | Incidencia | El equipo perdió dos semanas por rotación de un ingeniero clave | — | — | — | — | sin registro |
| 208·I2 | Incidencia | Se reprogramó la parada de planta por la ventana de mantenimiento | — | — | — | — | sin registro |
| 209·R1 | Riesgo | Cambio en la licencia ambiental que puede mover el alcance | — | — | — | — | sin registro |
| 209·R2 | Riesgo | Concentración del conocimiento en una sola persona (ya ocurrió: ver 209·I1) | — | — | — | — | sin registro |
| 209·I1 | Incidencia | El equipo perdió dos semanas por rotación de un ingeniero clave | — | — | — | — | sin registro |
| 209·I2 | Incidencia | Las lluvias detuvieron el montaje durante diez días | — | — | — | — | sin registro |
| 210·R1 | Riesgo | Cambio en la licencia ambiental que puede mover el alcance | — | — | — | — | sin registro |
| 210·D1 | Dependencia (antes riesgo) | El proveedor no ha confirmado la fecha de la última entrega | — | — | — | — | sin registro |
| 210·I1 | Incidencia | Se levantó un hallazgo en la auditoría de seguridad | — | — | — | — | sin registro |
| 211·R1 | Riesgo | Concentración del conocimiento en una sola persona | — | — | — | — | sin registro |
| 211·D1 | Dependencia (antes riesgo) | El proveedor no ha confirmado la fecha de la última entrega | — | — | — | — | sin registro |
| 211·I1 | Incidencia | Las lluvias detuvieron el montaje durante diez días | — | — | — | — | sin registro |
| 211·I2 | Incidencia | El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite | — | — | — | — | sin registro |

Fuente de cada ítem: la sección "Riesgos abiertos" o "Lo que pasó en el periodo" del informe de avance del proyecto, tal como lo recogió la ficha (`estado/records/PRY-xxx.json`, campo `raid`). 205·R3 viene de `2026-10-15-notas-reunion.txt`.

## Después
- **Subir a comité:** los ítems de la tabla "Necesitan decisión ahora", con la decisión formulada: ¿quién responde por cada incidencia de los proyectos rojos (200, 202, 209) y para cuándo? ¿Se formaliza 205·R3?
- **Proponer doliente:** no lo asigno ni lo propongo por nombre. Con lo que hay, el gerente de cada proyecto es el candidato natural para los ítems internos, pero eso lo decide usted. Los ítems con tercero (proveedor, Operaciones) necesitan una contraparte que hoy no aparece en ningún documento.
- **Pregunta abierta para usted:** ¿acepta las 11 reclasificaciones? Si es así, el siguiente `/portfolio-scan` debería reflejarlas.

## Pie de rigor
- **Leí:** 13 fichas, 12 minutas y notas de reunión (3 .docx extraídos como texto) y el informe de avance de PRY-208.
- **No leí de nuevo:** los informes de avance de los otros 12 proyectos, ni los 5 informes en PDF (203, 206, 207, 209, 211). Los ítems RAID vienen de lo que la ficha recogió de ellos. Tampoco abrí las actas de constitución ni los contratos.
- **No sé:** quién es doliente de cada ítem, desde cuándo está abierto, si algo se mitigó, si hay dependencias entre proyectos que nadie escribió, cuál proveedor es el que no confirma la última entrega ni si el 203 cierra el 2026-10-17. Tampoco sé qué se habló fuera de estos documentos.
- **Ficha de PRY-205:** `00-gobierno/ficha-pm.json` ya trae 205·R3 con la nota "dicho en reunión", y la fecha de fin de ese archivo (2027-01-19) no coincide con la de la ficha de estado (2026-11-06). No lo resolví; no es un tema RAID, pero afecta al plazo de 205·R3.
- Todo lo que aparece es lo que muestran los documentos, no una conclusión de la PMO. La verificación es suya.
