**Acta previa:** sí existe, del 2025-10-14 (`PRY-209-electrificación-de-equipos/00-gobierno/2025-10-14-acta-constitucion.md`). Modo revisar. Términos vigentes (v0.3.8, aceptados por José Francisco Ñáñez el 2026-10-15); no hubo nada que registrar.

## Acta — PRY-209 Electrificación de equipos
**Estado:** existe, del 2025-10-14 (un año de antigüedad; el informe de avance del 2026-10-08 ya la contradice en el estado: rojo, 48 %).

### Qué falta
| Campo | Estado | Consecuencia |
|---|---|---|
| Autoridad del gerente | **No existe.** El acta no dice hasta qué monto ni qué cambio de alcance decide Sandra Gil sin comité. | Cualquier ajuste va al Comité de Inversiones. Hoy pesa: el proyecto está en rojo, la proyección (9.936.230.266 COP) supera lo aprobado (9.500.000.000) en 436.230.266 COP (+4,6 %) y nadie sabe si eso lo puede absorber la gerente o tiene que subir. |
| Objetivo de negocio | Es la solución repetida: «Entregar electrificación de equipos para Medio Ambiente». Sin cifra, sin beneficio, sin fecha. | No hay forma de saber si un cambio de alcance (p. ej. por la licencia ambiental) sigue sirviendo al negocio; el comité decidiría sin referencia. |
| Alcance | «Componente 1, 2, 3»: sin nombres ni contenido. | Imposible decidir qué es cambio de alcance y qué no; el riesgo de licencia ambiental «que puede mover el alcance» no se puede evaluar contra nada. |
| Exclusiones | «Lo que otro proyecto cubre»: no nombra ningún proyecto. | No es una exclusión verificable; abre la puerta a trabajo duplicado o sin dueño. Además, las dependencias dicen «ninguna declarada». |
| Patrocinador | Cumple: Laura Vélez. | — |
| Gerente | Cumple: Sandra Gil. | — |
| Comité y cadencia | Comité de Inversiones nombrado; **cadencia no declarada**. No hay minutas en la carpeta. | No se puede comprobar que el comité haya visto el rojo. |
| Supuestos y restricciones | **No existen.** | Los riesgos hoy abiertos (licencia ambiental, conocimiento concentrado en una persona) y los eventos del periodo (lluvias, rotación) no tienen supuesto de origen contra el cual contrastarse. |
| Criterio de éxito | «En producción y medido»: sin umbral ni indicador. | Nadie puede declarar el éxito ni el fracaso. |
| Quién mide el éxito | **No existe.** | Sin medidor, el cierre queda a criterio de quien reporta. |
| Hitos principales | **No existen** en el acta ni en la carpeta (no hay cronograma). | El 48 % de avance no se puede contrastar con ningún plan. |
| Producto asociado | «No aplica». | Declarado, no es un vacío. Se deja constancia. |

### Contenido
**Objetivo de negocio:** pendiente de definir (el acta solo describe la solución).
**Alcance:** Componente 1, Componente 2, Componente 3 (sin detalle) — fuente: acta, §Alcance.
**Exclusiones:** «Lo que otro proyecto cubre» (sin proyecto nombrado) — fuente: acta, §Fuera de alcance.
**Patrocinador:** Laura Vélez · **Gerente:** Sandra Gil — fuente: acta (el informe de avance 2026-10-08 confirma a la gerente).
**Autoridad del gerente:** pendiente de definir.
**Comité al que reporta:** Comité de Inversiones · **Cadencia:** pendiente de definir.
**Presupuesto aprobado:** 9.500.000.000 COP, aprobado el 2025-10-14 — fuente: acta.
**Supuestos:** pendiente de definir · **Restricciones:** pendiente de definir.
**Criterio de éxito:** «Electrificación de equipos en producción y medido» (no medible tal como está) · **Lo mide:** pendiente de definir.
**Hitos principales:** pendiente de definir. Solo constan inicio 2025-10-24 y cierre 2027-05-06 (acta).

### Después
- **Autoridad sin declarar:** ofrezco llevar esa definición al Comité de Inversiones como decisión (monto y tipo de cambio que Sandra Gil puede resolver sin subir). Es una decisión, no un trámite. *Respuesta tomada en esta prueba sin interfaz: sí, queda ofrecido; no se ha escalado nada.*
- **Supuestos que salieron de la revisión:** la dependencia de la licencia ambiental vigente y la disponibilidad del ingeniero clave. Ofrezco pasarlos al registro RAID (`/raid-log`). *Queda ofrecido; no se ejecutó.*

### Pie de rigor
Revisé el acta (2025-10-14) y el informe de avance (2026-10-08, PDF). No hay minutas de comité, cronograma ni contratos en la carpeta, así que no sé qué se habló o decidió fuera de esos dos documentos. Nada en esta revisión modifica el acta; los campos marcados «pendiente de definir» no se completaron con lo razonable. La verificación de las citas es suya.
