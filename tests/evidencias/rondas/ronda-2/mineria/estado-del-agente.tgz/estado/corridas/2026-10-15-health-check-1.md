# Corrida del 2026-10-15 · health-check

13 proyectos · 63 s · 44 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 12 |
| `declared_vs_evidence` | 8 |
| `commitment_overdue` | 3 |
| `progress_vs_plan` | 3 |
| `commitment_undated` | 3 |
| `variance_time` | 3 |
| `vendor_deliverable_late` | 3 |
| `vendor_invoiced_without_delivery` | 2 |
| `rebaseline_unauthorized` | 2 |
| `pm_vs_pmo` | 1 |
| `silent` | 1 |
| `milestone_overdue` | 1 |
| `vendor_accepted_without_evidence` | 1 |
| `variance_cost` | 1 |

Diagnóstico de PRY-204 desde cero: 3 sostenidas, 6 sin sustento, 1 contradicha. Dijo que no puede verificar hitos, ejecución, entrega de equipos ni autoridad del gerente.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15); no hubo que registrarlos de nuevo.

## Diagnóstico · PRY-204 Monitoreo de taludes · 2026-10-15

**Leí:** 4 documentos del proyecto · fechas 2025-08-31 a 2026-10-15 · formatos: docx, csv, md (2). Además busqué menciones del proyecto en los otros 12 proyectos: ningún documento ajeno cita PRY-204 ni "taludes".
**No pude leer:** nada. (El .docx lo leí extrayendo su texto; el diagnóstico no usó la ficha previa del proyecto.)

### Dictamen
**Sostenido:** 3 afirmaciones · **Sin sustento:** 6 · **Contradicho:** 1

Desde esta carpeta solo se puede afirmar quién gobierna el proyecto y cuánto dinero se aprobó. Todo lo demás —el verde, el avance, los dos hitos cerrados, la entrega de equipos, lo ejecutado— es declaración del gerente sin un solo documento de evidencia (el cómputo cuenta 0 evidencias, 5 declaraciones). La carpeta no permite diagnosticar el estado real; permite diagnosticar que no está probado.

### Gobierno
| | Qué dice el documento | Fuente |
|---|---|---|
| Patrocinador | Ricardo Salas | 00-gobierno/2025-08-31-acta-constitucion.docx; asiste al comité del 2026-10-15 |
| Gerente | Jorge Medina | acta; informe 2026-10-14; comité 2026-10-15 |
| Autoridad declarada | **No declarada.** El acta no dice qué puede aprobar el gerente | acta (ausente) |
| Comité | Comité de Tecnología (aprobó el presupuesto el 2025-08-31) | acta |

Sin autoridad declarada no hay desviación aprobada: las fechas del cronograma son fechas escritas, no compromisos autorizados. El acta tampoco declara dependencias ("Ninguna declarada") y su alcance es genérico ("Componente 1, 2, 3"), así que no hay contra qué verificar el alcance.

### Contra el plan
Hay línea base: `10-plan/2025-08-31-cronograma-v1.csv`, con 3 hitos. Original y vigente coinciden en los tres; replanificaciones: 0; atraso contra original y contra vigente: 0 días.
- Ingeniería básica aprobada: 2026-02-09, cerrado
- Ingeniería de detalle aprobada: 2026-07-11, cerrado
- Licencia y permisos obtenidos: 2026-12-10, en curso

Nota: el acta fija cierre 2027-02-24 y el último hito del cronograma es 2026-12-10; el cronograma no cubre lo que ocurre después de la licencia (instalación, puesta en producción, medición, que es el criterio de éxito). El plan cubre menos que el proyecto.

### Hitos vencidos sin evidencia
Los dos hitos figuran como cerrados, pero ninguno tiene acta de recibo ni aprobación en la carpeta.
| Hito | Fecha | Días | Qué documento se esperaría |
|---|---|---|---|
| Ingeniería básica aprobada | 2026-02-09 | 248 | Acta de recibo / aprobación de la ingeniería básica |
| Ingeniería de detalle aprobada | 2026-07-11 | 96 | Acta de recibo / aprobación de la ingeniería de detalle |

(Otros proyectos de este portafolio sí traen su "acta-recibo-ingeniería-básica-aprobada.pdf"; este no.)

### Dinero
| Aprobado | Comprometido | Ejecutado | Proyección | Disponible real |
|---|---|---|---|---|
| 2.400.000.000 COP | 1.747.958.077 COP (72.8 %) | 493.764.835 COP (20.6 %) | 2.505.660.114 COP (4.4 % sobre lo aprobado) | 652.041.923 COP |

Solo el aprobado está respaldado (acta e informe coinciden). Comprometido, ejecutado y proyección salen únicamente del informe del gerente; no hay contrato, orden, factura ni extracto en la carpeta. Una proyección sobre el aprobado sin solicitud de cambio ni aprobación del comité: 0 cambios registrados.

### Lo que se dijo y nadie registró
- **Compromiso vencido:** Óscar Ramírez, "Entregar el punto 40", para 2026-10-14 (1 día) — comité 2026-10-15. Sin evidencia de entrega.
- **Compromiso que vence hoy:** Felipe Arango, "Entregar el punto 10", para 2026-10-15. Aún no vencido.
- Los compromisos remiten a "punto 10" y "punto 40" que no están definidos en ningún documento: no se sabe qué se prometió.
- Ninguno de los dos responsables asistió al comité ni figura en el acta del proyecto; ambos aparecen en otros proyectos (Felipe Arango como gerente en PRY-207; Óscar Ramírez en PRY-205). No hay evidencia de su rol en PRY-204.
- **Riesgo:** "Bloqueo de la vía de acceso a la mina" aparece solo en el informe, sin probabilidad, impacto, dueño ni respuesta, y no hay registro RAID. Es la única mención.
- **Dependencia/incidencia posible:** equipos "entregados en el campamento, pendientes de aceptación": no hay contrato ni proveedor identificado; esa dependencia no está declarada en el acta.
- Los temas del comité ("Avance", "Compromisos") no dejan decisión alguna registrada.

### Contradicho
| Afirmación | Documento A | Documento B |
|---|---|---|
| Avance del 30 % | Informe 2026-10-14: 30 % | Cronograma: 2 de 3 hitos cerrados, lo que el plan sostiene entre 67 y 100 % (brecha de 37 puntos) |

Las dos lecturas no pueden ser verdad a la vez: o los hitos no están realmente cerrados (y el cronograma está inflado), o el avance está subreportado. Con lo que hay en la carpeta no se puede saber cuál.

### Sin sustento
1. **Estado verde.** Declarado el 2026-10-14. Lo acompañan tres señales abiertas que el informe no explica: compromiso vencido, hitos cerrados sin evidencia y la brecha de avance. Nada en la carpeta lo respalda.
2. **Hito "Ingeniería básica aprobada" cerrado** (248 días desde su fecha).
3. **Hito "Ingeniería de detalle aprobada" cerrado** (96 días desde su fecha).
4. **Equipos entregados en el campamento**, pendientes de aceptación: sin acta de entrega, contrato, guía ni confirmación del proveedor.
5. **Cifras de ejecución** (comprometido, ejecutado, proyección): solo el informe.
6. **Riesgo de bloqueo de la vía:** solo el informe.

Sostenidas (las 3): presupuesto aprobado, gerente y patrocinador, por acta y por otros documentos que coinciden.

### Lo que esta carpeta no permite saber
- **Si la ingeniería está aprobada:** sin actas no se puede decir que 2 de 3 hitos estén cumplidos; todo avance medido por hitos queda en suspenso.
- **Cuánto se gastó realmente:** sin contratos ni facturas, el "disponible real" (652.041.923 COP) es una resta de cifras declaradas.
- **Qué entregó el proveedor y a quién se le debe pagar:** no hay contrato, ni se nombra al proveedor.
- **Quién puede aprobar un cambio:** sin autoridad declarada, una eventual replanificación o sobrecosto no tiene quién la apruebe.
- **Qué hay después de la licencia:** el plan termina en 2026-12-10 y el acta cierra el 2027-02-24.
- **Qué significan los "puntos 10 y 40"** y qué papel tienen sus responsables.
- **Antigüedad del dato:** 9 campos de identidad, plan y presupuesto salen de un acta de hace 14 meses; faltan autoridad y fase.

### Siguiente paso posible
No recomiendo detener, continuar ni reestructurar: eso lo decide quien tiene la facultad. Ofrezco (1) llevar al gerente, una por una, las preguntas de las contradicciones y de los dos hitos sin acta, o (2) preparar el punto de comité con la lista de lo que falta para poder diagnosticar.

---
**Pie de rigor:** borrador de trabajo, no decisión ni asesoría. Cada dato sale de la cita indicada; las cifras derivadas se copiaron de `portafolio.py compute` (as_of 2026-10-15). La verificación es suya. No cubre lo hablado fuera de estos documentos.
