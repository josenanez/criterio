# Corrida del 2026-10-15 · product-view

13 proyectos · 20 s · 44 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 12 |
| `declared_vs_evidence` | 8 |
| `commitment_overdue` | 3 |
| `progress_vs_plan` | 3 |
| `commitment_undated` | 3 |
| `variance_time` | 3 |
| `vendor_deliverable_late` | 3 |
| `vendor_invoiced_without_delivery` | 2 |
| `rebaseline_unauthorized` | 2 |
| `pm_vs_pmo` | 1 |
| `silent` | 1 |
| `milestone_overdue` | 1 |
| `vendor_accepted_without_evidence` | 1 |
| `variance_cost` | 1 |

Producto de un solo proyecto (PRY-203): sin sección de producto. Dos hitos cumplidos sin evidencia y verde declarado contradicho. 7 proyectos sin producto declarado. No se sabe el área dueña (no sale del cálculo) ni si monitoreo de flota y despacho de flota son el mismo producto.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## Productos al 2026-10-15

Sale de las fichas en `estado/records` y del cálculo `portafolio.py compute` del 2026-10-15. Se pidió el producto «despacho de flota».

| Producto | Proyectos | Con alertas | Fecha más tardía | Aprobado | Comprometido |
|---|---|---|---|---|---|
| despacho de flota | 1 (PRY-203 Despacho automático de flota) | 1 (3 alertas) | 2026-10-17 (PRY-203) | COP 1.200.000.000 | COP 772.433.451 |

**Despacho de flota tiene un solo proyecto (PRY-203).** La vista por producto no aporta nada aquí, así que no armo sección de producto: lo que sigue es la lectura de ese proyecto.

- **Señales:** `milestone_met_without_evidence` ×2 —«Ingeniería básica aprobada» (vencía 2025-12-07, 312 días) e «Ingeniería de detalle aprobada» (vencía 2026-05-13, 155 días), ambos declarados cumplidos sin evidencia— y `declared_vs_evidence`: el informe del 2026-10-12 declara verde, pero esos dos hitos no tienen soporte.
- **Avance:** declara 73 %; el plan soporta entre 67 y 100 % (2 de 3 hitos cumplidos); brecha 0 puntos.
- **Fecha:** 2026-10-17, sin replanificaciones y sin desviación contra la línea base original ni la vigente. Faltan 2 días para esa fecha.
- **Dinero:** las cuatro cifras vienen completas (1 de 1 proyecto). Aprobado COP 1.200.000.000; comprometido 772.433.451 (64,4 %); ejecutado 514.897.208 (42,9 %); proyección 1.120.646.033 (−6,6 % frente al aprobado). Disponible real: 427.566.549.
- **Dependencias internas:** ninguna, y no hay otro proyecto del producto con el que cruzarlas. Dependencias declaradas del proyecto: ninguna.
- **Lo que no se sabe:** no hay evidencia en ninguna fuente de la ficha (0 de evidencia; 5 declaraciones y 11 sin marcar). Faltan `identity.authority` (quién aprueba) y `identity.phase`. Nueve campos de identidad, plan y dinero tienen 16 meses de antigüedad (fuente del 2025-06-24), pasado el umbral de 12.

### Proyectos sin producto declarado

Siete de los 13 proyectos del portafolio no declaran producto. Es un hallazgo de gobierno: nadie puede responder por el conjunto al que sirven.

| Proyecto | Área dueña |
|---|---|
| PRY-201 Ampliación de la relavera | no la entrega el cálculo |
| PRY-202 Planta de tratamiento de agua | no la entrega el cálculo |
| PRY-205 Sistema de gestión de seguridad | no la entrega el cálculo |
| PRY-206 Red privada LTE en mina | no la entrega el cálculo |
| PRY-209 Electrificación de equipos | no la entrega el cálculo |
| PRY-210 Programa de relacionamiento comunitario | no la entrega el cálculo |
| PRY-211 Control de polvo en vías | no la entrega el cálculo |

Nota de lectura: «monitoreo de flota» (PRY-200) es otro producto declarado, distinto de «despacho de flota». La ficha no los une y no los uní yo; si son el mismo producto con dos nombres, eso lo confirma quien lo sabe.

*Pie de rigor: borrador de trabajo con cita a las fichas; la verificación es de quien lo lee. Solo dice lo que muestran los documentos, no lo hablado fuera de ellos.*
