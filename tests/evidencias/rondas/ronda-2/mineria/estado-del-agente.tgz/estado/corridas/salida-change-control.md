Ficha de la que sale: `estado/records/PRY-202.json` (actualizada 2026-10-15; informe de avance de corte 2026-10-13). Términos vigentes: versión 0.3.8, aceptados por José Francisco Ñáñez el 2026-10-15.

## Solicitud de cambio — PRY-202 Planta de tratamiento de agua — 2026-10-15

**Qué se pide:** mover 30 días la salida a producción. · **Quién lo pide:** no consta en ningún documento (la solicitud llegó por el comando, sin solicitante). · **Por qué:** no consta; no hay motivo documentado.

**Supuesto que tomé (respuesta sugerida, nadie contestó):** la ficha no tiene un hito llamado «salida a producción». El criterio de éxito del acta es «planta en producción y medido», y lo más cercano es el hito final «Pruebas en operación» (2027-12-13, que es también el cierre de la línea base v1). Moví ese hito y el cierre 30 días. Si la salida es otro hito, hay que decirlo y recalcular.

### Impacto
| Dimensión | Hoy | Con el cambio | Diferencia |
|---|---|---|---|
| Alcance | Componentes 1, 2 y 3 (acta 2026-06-21) | Sin declarar | No hay impacto declarado. Si el alcance no cambia, la diferencia la absorbe tiempo y costo: ver abajo. |
| Tiempo | Pruebas en operación y cierre de línea base v1: 2027-12-13 | 2028-01-12 | +30 días (inicio 2026-07-01, sin cambio) |
| Costo | Aprobado 1.200.000.000 COP; proyección declarada 1.176.212.499 COP (holgura de 23.787.501 COP, 2 %) | Sin estimar | No hay estimación de costo en ningún documento. Un mes más de equipo y de proveedor no cabe sin cifra; con 2 % de holgura, lo más probable es que el costo adicional se absorba en horas no pagadas o en calidad, o que pida presupuesto nuevo. Es una inferencia, no un dato. |

Lo que contradice el acta: el acta fija el cierre en **2028-02-05**, y el cronograma v1 (misma fecha de aprobación, 2026-06-21) termina el **2027-12-13**, 54 días antes. La ficha usa el cronograma. Con el cambio, 2028-01-12 queda todavía 24 días antes del cierre del acta; contra el cronograma no hay holgura. Cuál de las dos fechas es la línea base real está sin resolver, y de eso depende si el cambio mueve el compromiso formal o solo consume holgura.

Estado actual del proyecto: declarado **rojo**, 48 % de avance, con una parada de planta ya reprogramada y un riesgo abierto (el proveedor no ha confirmado la fecha de la última entrega). El hito «Ingeniería básica aprobada» vence hoy (2026-10-15) sin evidencia de aprobación. Un compromiso de María Restrepo (punto 15, para 2026-10-01) está vencido. Pedir 30 días sobre un proyecto en rojo sin motivo escrito pide mirar primero si la causa es esta solicitud o el atraso que ya existe.

### Efecto en el portafolio
| Proyecto afectado | Cómo | Gerente |
|---|---|---|
| Ninguno alcanzado | `impact` devuelve 0 proyectos alcanzados, 0 que no puedan sostener su fecha, 0 dependencias sin confirmar | — |

Esto significa **que ninguna ficha declara dependencia con PRY-202**: el acta dice «Ninguna declarada» y ningún otro proyecto la cita. No prueba que no existan. La parada de planta reprogramada por la ventana de mantenimiento sugiere una dependencia operativa con otra área que no está escrita. Los cinco hitos del proyecto son los que pasa el cambio; cuántos días se mueve cada uno no se sabe, porque la ficha no tiene holgura por actividad.

Proveedor CT-503 (Ingeniería Minera del Sur): tres entregables (2026-11-24, 2027-04-19, 2027-09-12), todos pendientes, 88.340.049 COP cada uno. El contrato no declara fecha de vencimiento, así que no puedo decir si 30 días más lo dejan vencido. Hay que preguntarlo antes de decidir.

### Quién decide
**Autoridad requerida:** no declarada. · **Según:** el acta no define autoridad de cambios (`identity.authority`: no encontrado). Lo único documentado: el Comité de Seguridad aprobó el presupuesto el 2026-06-21, y Liliana Torres es patrocinadora. · **Va a comité:** sí, por defecto. Sin autoridad declarada no hay umbral con el que decir que Ricardo Salas pueda aprobarlo solo. Ese es el hallazgo de fondo: el proyecto no tiene a quién preguntarle qué se puede cambiar sin pedir permiso.

### Si no se aprueba
El proyecto sigue con cierre 2027-12-13 (cronograma) o 2028-02-05 (acta), en rojo, con 48 % de avance, un riesgo de proveedor sin fecha y un hito de ingeniería básica que vence hoy sin evidencia. La ficha no permite decir si ese cierre es alcanzable.

### Si se aprueba
Línea base 2 — cierre 2028-01-12 · presupuesto: sin cambio documentado (1.200.000.000 COP; sin cifra para el costo del mes adicional) · motivo: no consta, hay que escribirlo antes de registrar.
Desviación acumulada contra la línea base original (v1): tiempo **+30 días** · costo **sin dato**. La v1 no se toca; la v2 se agrega con fecha, motivo y el documento que la aprueba, que hoy no existe. Replanificaciones: de 0 a 1. No hay cambios previos registrados (`changes: []`), así que ningún día está sin autorizar hoy.

### Lo que falta para poder decidir
1. Quién pide y por qué (motivo escrito).
2. Qué hito es la «salida a producción».
3. Cuál es la fecha de cierre válida: 2027-12-13 o 2028-02-05.
4. Costo estimado del mes adicional.
5. Autoridad de cambios del proyecto.
6. Vencimiento de CT-503.

No he registrado ninguna línea base nueva: no hay aprobación.
