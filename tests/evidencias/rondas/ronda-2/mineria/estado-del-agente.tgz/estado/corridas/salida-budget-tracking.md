**Fuentes:** ficha `estado/records/PRY-211.json` y salida de `portafolio.py compute` (as_of 2026-10-15). Documentos citados: acta de constitución (2026-03-09), informe de avance (2026-10-12), cronogramas v1 (2026-03-09) y v2 (2026-10-12), solicitud CC-01 (2026-10-08).

## Presupuesto — PRY-211 Control de polvo en vías, al 2026-10-15
**Moneda:** COP (única; no hay contratos en otra moneda, no se convirtió nada)

| | Monto (COP) | % del aprobado | Fuente | Fecha |
|---|---|---|---|---|
| Aprobado | 2.400.000.000 | 100 | acta de constitución | 2026-03-09 |
| Comprometido | 984.976.055 | 41.0 | informe de avance (declaración) | 2026-10-12 |
| Ejecutado | 1.403.798.497 | 58.5 | informe de avance (declaración) | 2026-10-12 |
| Proyección al cierre | 2.702.499.056 | 112.6 (excede el aprobado en 12.6%) | informe de avance (declaración) | 2026-10-12 |

**Disponible real** (aprobado menos comprometido): 1.415.023.945 COP

Las tres cifras que no son el aprobado salen de una sola declaración del gerente; ninguna tiene documento de evidencia aparte (0 fuentes de evidencia en la ficha).

### Contra la línea base
| | Original | Vigente | Desviación |
|---|---|---|---|
| Fecha de fin | 2027-07-22 (cronograma v1, 2026-03-09) | 2027-09-25 (cronograma v2, 2026-10-12) | +65 días, 13.3% contra la original; 0 contra la vigente |
| Presupuesto | 2.400.000.000 | 2.400.000.000 (no hay una línea base de presupuesto distinta en ningún documento) | Proyección +12.6% sobre el aprobado |

Replanificaciones de presupuesto: 0 documentadas. Replanificaciones de cronograma: 1 (v2), sin aprobación documentada: la solicitud CC-01 (+65 días, impacto de costo 130000000 COP, solicitada 2026-10-08) está en estado `pending`.

### Ejecución frente a avance
Ejecutado 58.5% · Hitos cumplidos 2 de 5 · El avance declarado es 66%, pero el plan solo sustenta entre 40% y 60% (fuera del rango, `gap_points` −6.0 en el cálculo). La ejecución del dinero queda en línea con el rango del plan; lo que no se sostiene es el 66% declarado.

### Alertas
- **Proyección excede el aprobado** (variance_cost): 12.6%, por encima del umbral de 10%.
- **Desviación en tiempo** (variance_time): 13.3% contra la original, por encima del umbral de 10%.
- **Línea base movida sin autorización** (rebaseline_unauthorized): 65 días movidos, 0 autorizados.
- **Estado declarado contra evidencia**: el informe del 2026-10-12 declara "verde" y no da cuenta de las tres señales anteriores.
- **Comprometido** 41.0%: por debajo del umbral de 90%; no hay alerta por ahí.
- **Ejecutado (1.403.798.497) por encima del comprometido (984.976.055)**: lo normal es lo contrario, porque lo ejecutado suele haber estado comprometido antes. Los documentos no lo explican. Puede ser gasto sin compromiso registrado o un comprometido incompleto; el "disponible real" depende de cuál sea, y yo no puedo decidirlo.
- Compromiso sin fecha: María Restrepo, "Entregar el punto 22" (comité 2026-10-14).

### Sin dato
- Línea base de presupuesto original separada del aprobado: no declarada.
- Fecha del último movimiento de presupuesto: no declarada, así que no se puede decir si la proyección es más vieja que ese movimiento (la proyección es del 2026-10-12, de hace 3 días).
- Soporte (documento fuente distinto del informe de avance) para comprometido, ejecutado y proyección: no encontrado.
- Ficha sin producto, autoridad ni fase.

**Siguiente paso posible:** como la proyección excede el aprobado, puedo preparar la solicitud de cambio de presupuesto (`/change-control`). CC-01 ya existe y solo cubre +130000000 COP; la proyección excede el aprobado en más que eso (+12.6% sobre 2.400.000.000).

*Pie de rigor: borrador de trabajo. Cifras copiadas de la salida de `compute`, cada una con la cita del documento del que salió; la verificación es suya.*
