# Corrida del 2026-10-15 · portfolio-server

13 proyectos · 44 hallazgos

> El tiempo no se midió: faltó `corrida-inicio` al arrancar. Un tiempo escrito a mano es un recuerdo, no una medición.

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 12 |
| `declared_vs_evidence` | 8 |
| `commitment_overdue` | 3 |
| `progress_vs_plan` | 3 |
| `commitment_undated` | 3 |
| `variance_time` | 3 |
| `vendor_deliverable_late` | 3 |
| `vendor_invoiced_without_delivery` | 2 |
| `rebaseline_unauthorized` | 2 |
| `pm_vs_pmo` | 1 |
| `silent` | 1 |
| `milestone_overdue` | 1 |
| `vendor_accepted_without_evidence` | 1 |
| `variance_cost` | 1 |

puerto 8787 local, informe en reportes, modo rato

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

# Rostrum — modo «para mirarlo un rato»

**Términos:** vigentes (versión 0.3.8, aceptados por José Francisco Ñáñez el 2026-10-15). No hizo falta registrarlos de nuevo.

**Modo elegido:** «para mirarlo un rato» (lo indicó el argumento `rato`). Cero infraestructura y ninguna conversación con seguridad. Lo que se pierde: el patrocinador no tiene un enlace que funcione mañana.

**Informe:** existe en `reportes/` (13 proyectos, 6 productos, decisiones, listado). El servidor no genera el informe, lo sirve.

**Comando:**

```
python3 "/home/claude/banco/criterio/plugins/criterio-portfolio/scripts/servidor.py" --informe reportes --estado estado --config .criterio/portafolio/config.json
```

Escucha en `127.0.0.1:8787`, solo en este equipo. Se para con Ctrl-C. Si el puerto está ocupado, `--puerto 8788`. La organización que muestra es «Portafolio de minería».

| Ruta | Qué es | Para quién |
|---|---|---|
| `/` | Portada con las tres secciones y el formulario de peticiones | Todos |
| `/pmo` | Cómo va el portafolio: verdes sin sustento, silencios, patrocinios repetidos | La PMO |
| `/decisiones` | Lo que necesita decisión, con la consecuencia de no decidir | Comité y patrocinador |
| `/proyectos` | Listado ordenado por lo que más pide atención | Todos |
| `/p/<código>` | Informe de un proyecto, con enlace al producto que le dio origen | Quien gerencia |
| `/productos` | Listado de productos y proyectos sin producto declarado | Quien responde por un producto |
| `/producto/<nombre>` | Informe de un producto, con enlace a los proyectos que lo construyen | Quien responde por un producto |
| `/estado.json` | Fecha del informe y peticiones abiertas | Un mecanismo |

El enlace entre proyecto y producto va en los dos sentidos: si un producto lo construyen proyectos que reportan a comités distintos, ningún comité lo ve completo, y ese hallazgo solo aparece aquí.

**Lo que Rostrum no hace:** no calcula (sirve lo que `informe.py` ya escribió), no escribe fichas (solo la petición, en `estado/peticiones/`), no autentica y no manda nada.

**Peticiones:** el formulario de la portada deja la petición en `estado/peticiones/`; el servidor no puede correr el agente. `portafolio.py due` las cuenta y rompen el silencio de `/portfolio-wake`.

**Cierre:** en este modo el enlace es `http://127.0.0.1:8787/` y solo lo abre quien esté en este equipo; no se le pasa a nadie. El informe es del 2026-10-15 (la portada lo dice) y queda desactualizado en cuanto cambie un documento o corra otro barrido: antes de mandarle algo al patrocinador, regenera con `/portfolio-report html`. Para que el patrocinador tenga un enlace estable, la segunda forma («que quede corriendo») pide a la organización: un host y un puerto en la red, publicarlo detrás de su control de acceso (el servidor no autentica) y que el equipo siga encendido. Nada más.
