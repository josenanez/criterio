# Corrida del 2026-10-15 · document-index

13 proyectos · 5 s · 44 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 12 |
| `declared_vs_evidence` | 8 |
| `commitment_overdue` | 3 |
| `progress_vs_plan` | 3 |
| `commitment_undated` | 3 |
| `variance_time` | 3 |
| `vendor_deliverable_late` | 3 |
| `vendor_invoiced_without_delivery` | 2 |
| `rebaseline_unauthorized` | 2 |
| `pm_vs_pmo` | 1 |
| `silent` | 1 |
| `milestone_overdue` | 1 |
| `vendor_accepted_without_evidence` | 1 |
| `variance_cost` | 1 |

Índice sin cambios: 74 documentos iguales, nada que releer. No leí contenido de documentos.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

Carpeta al 2026-10-15: 74 documentos, 74 sin cambio, 0 por releer, 0 citas rotas. No hay nada que hacer.
