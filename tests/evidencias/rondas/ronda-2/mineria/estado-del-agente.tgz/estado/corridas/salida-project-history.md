## Historia · PRY-207 Gemelo digital de la planta · 2026-05-21 a 2026-10-07

**Leí:** 10 documentos entre 2026-05-21 y 2026-10-07 (acta, 2 contratos, 2 cronogramas, 2 facturas, informe de avance, solicitud de cambio, minuta del comité). Cuatro vienen en formato que el lector directo no abre (3 .docx y 1 .xlsx) y los leí extrayendo su texto; los PDF (2 facturas e informe), el .md y el .csv, directamente. Ninguno es una prueba de recibo.
**Trimestres sin un solo documento:** ninguno. Pero entre 2026-05-30 y 2026-08-26 no hay ningún documento: el proyecto estuvo en silencio documental durante el arranque.
**Fuentes:** del total de datos de la ficha, 0 son evidencia, 5 son declaración y 11 no están marcados (salida de `compute`). No hay ni un acta de recibo, ni un acta de aprobación de hito, ni un acta de comité que apruebe nada.

### En una línea
El proyecto nació el 2026-05-24 con cierre en 2027-04-25 según el cronograma v1 (el acta dice 2027-05-28; ver nota). El 2026-10-06 el gerente declaró estado verde y 34% de avance, y ese mismo día quedó fechado un cronograma v2 que mueve el cierre al 2027-08-09 (106 días, 32,5% contra el original); la solicitud de cambio que lo justifica es del día siguiente, 2026-10-07, y sigue pendiente de presentación al comité. En el medio, en agosto se facturaron dos contratos por entregables que no tienen acta de recibo, uno de ellos con el entregable aún pendiente.

### Las cuatro cifras
| Replanificaciones | Atraso acumulado vs. original | Meses declarando sin sustento | Cambios de gobierno |
|---|---|---|---|
| 1 | 106 días (32,5%) | No calculable: hay un solo estado declarado (2026-10-06); sin serie no hay meses que contar | 0 en los documentos |

### Línea de tiempo
| Fecha | Documento | Qué cambió |
|---|---|---|
| 2026-05-21 | Contrato CT-555 (Montajes Industriales Ltda.) | Tres entregables de 102.304.427 COP cada uno; se factura contra acta de recibo firmada por el gerente. El documento muestra el primer entregable como "recibido" aunque está fechado en mayo y vence el 2026-08-31 |
| 2026-05-24 | Acta de constitución | Presupuesto 1.200.000.000 COP; inicio 2026-06-03; cierre 2027-05-28; patrocinadora Diana Molina; gerente Felipe Arango; Comité de Operaciones |
| 2026-05-24 | Cronograma v1 | Línea base original: 5 hitos, el último (Pruebas en operación) el 2027-04-25 |
| 2026-05-30 | Contrato CT-517 (Equipos Pesados Andinos) | Tres entregables de 69.251.482 COP cada uno, mismas fechas y misma condición de pago |
| 2026-08-26 | Factura FV-2517 (CT-517) | 69.251.482 COP radicados en cuentas por pagar; el entregable "Licenciamiento del software" vence el 2026-08-31 y el contrato lo muestra pendiente |
| 2026-08-28 | Factura FV-1555 (CT-555) | 102.304.427 COP radicados en cuentas por pagar; el mismo entregable vence el 2026-08-31 |
| 2026-10-04 | Minuta del comité semanal | Asisten Felipe Arango y Diana Molina; temas "Avance" y "Compromisos" sin contenido; un compromiso de Laura Vélez, "Entregar el punto 33", sin fecha |
| 2026-10-06 | Informe de avance | Verde, 34%; aprobado 1.200.000.000, comprometido 897.281.144, ejecutado 325.260.789, proyección 1.122.546.554 COP; un hallazgo de auditoría de seguridad; un riesgo (concentración de conocimiento) |
| 2026-10-06 | Cronograma v2 | Marca "Ingeniería básica aprobada" como cerrado; mueve "Pruebas en operación" de 2027-04-25 a 2027-08-09 |
| 2026-10-07 | Solicitud de cambio CC-01 | Ampliación de alcance, +106 días y 212.000.000 COP; "Pendiente de presentación al comité" |

Referencia (fecha de un hito, no de un documento): "Ingeniería básica aprobada" estaba programado para 2026-08-07; ningún documento de la carpeta lo aprueba.

### Replanificaciones
| Nº | Fecha | Fecha de cierre nueva | Motivo declarado | Documento que la aprobó |
|---|---|---|---|---|
| 1 | 2026-10-06 (cronograma v2) | 2027-08-09 | Ninguno en el cronograma; la CC-01 (2026-10-07) plantea una ampliación de alcance de +106 días | Ninguno. CC-01 está pendiente; autorizado: 0 de 106 días |

El cronograma v2 es anterior en un día a la solicitud que lo justifica. Hasta que el comité decida, el cierre vigente en el cronograma no tiene una aprobación documentada.

### Gobierno
| Fecha | Qué cambió | Documento |
|---|---|---|
| — | Sin cambios de patrocinador, gerente ni comité en los documentos (Diana Molina, Felipe Arango y Comité de Operaciones aparecen igual en acta, minuta e informe) | — |

No encontré autoridad que apruebe cambios (`identity.authority`) ni fase del proyecto (`identity.phase`): ningún documento los dice.

### Compromisos que se repitieron
| Doliente | Qué | Veces | Fechas prometidas |
|---|---|---|---|
| — | Ningún compromiso se repitió: solo hay una minuta | — | — |

Abierto y sin fecha: Laura Vélez, "Entregar el punto 33", dicho el 2026-10-04, con fecha "por definir". La minuta no dice qué es el "punto 33" y Laura Vélez no figura entre los asistentes.

### Desde cuándo lo declarado no se sostiene
No se puede fijar un deslizamiento en el tiempo porque solo existe una declaración de estado: el informe del 2026-10-06 (verde, 34%). Lo que sí se puede fechar es lo declarado sin sustento:

- **2026-08-07**: fecha del primer hito, "Ingeniería básica aprobada", que el cronograma v2 da por cerrado sin acta ni aprobación en la carpeta (69 días hasta hoy).
- **2026-08-26 y 2026-08-28**: dos facturas radicadas antes de la fecha comprometida (2026-08-31) y sin acta de recibo, que los contratos exigen. En CT-555, el entregable aparece "recibido" sin acta; en CT-517 está pendiente y sigue vencido 45 días.
- **2026-10-06**: se reporta verde con 6 señales abiertas que el informe no menciona: hito cerrado sin evidencia, hito de detalle vencido (2026-10-11 según el plan; 4 días), atraso de 106 días contra el original, cambio de línea base sin autorización, entregable de proveedor vencido y proveedor facturado sin entrega.

Lo que se siguió reportando después: verde y 34%, contra un avance que el plan sustenta entre 20% y 40% (1 de 5 hitos cumplidos, sin evidencia).

### Lecciones ancladas a un hecho
1. **Una factura sin acta de recibo se paga antes de saber si hubo entrega.** Hecho: FV-2517 (2026-08-26) se radicó por 69.251.482 COP con el entregable de CT-517 pendiente y vencido desde 2026-08-31. Efecto: dinero comprometido a cuentas por pagar sin entrega verificable.
2. **El cronograma se movió antes que la solicitud que lo justifica.** Hecho: v2 (2026-10-06) con cierre 2027-08-09; CC-01 (2026-10-07) pendiente. Efecto: 106 días de atraso presentes en el plan sin decisión del comité.
3. **Un informe en verde que no menciona sus propias señales deja al comité sin la conversación que necesita.** Hecho: informe 2026-10-06, verde, junto con 6 señales abiertas. Efecto: el comité del 2026-10-04 no tiene contenido registrado en "Avance".

### Qué no sé
- **Cierre original**: el acta (2027-05-28) y el cronograma v1 (2027-04-25) no coinciden, y ningún documento explica la diferencia. El 106 sale de comparar contra v1; no calculé la cifra contra la fecha del acta.
- Si el recibo de "Licenciamiento del software" en CT-555 existió fuera de la carpeta.
- Qué es el "punto 33".
- Cuál fue el hallazgo de auditoría de seguridad: el informe solo lo menciona.
- No tengo documentos entre 2026-05-30 y 2026-08-26.

### Nota
Que el atraso apareciera en un cronograma antes que en una solicitud no dice que alguien lo ocultara. La historia sirve para tener esa conversación con datos; quién la tiene es una persona. Puedo llevar esta historia al comité, donde CC-01 espera presentación, o al cierre del proyecto si llega a haberlo.

*Pie de rigor: borrador de trabajo basado solo en los 10 documentos de la carpeta; cada dato tiene su fuente en la ficha `estado/records/PRY-207.json`. La verificación es de quien lo lea.*
