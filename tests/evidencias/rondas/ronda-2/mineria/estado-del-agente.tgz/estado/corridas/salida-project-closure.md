**Fuente:** ficha `estado/records/PRY-206.json` (actualizada 2026-10-15), acta de constitución `00-gobierno/2025-07-19-acta-constitucion.md` e informe de avance `20-seguimiento/2026-09-25-informe-avance.pdf`. Cifras derivadas: salida de `portafolio.py compute` (corte 2026-10-15). Términos vigentes (aceptados por José Francisco Ñáñez, versión 0.3.8, 2026-10-15).

## Cierre — PRY-206 Red privada LTE en mina — 2026-10-15

**Resultado en una línea: este proyecto no se puede cerrar contra lo comprometido.** No hay en la carpeta ninguna declaración de que terminó: el último documento es un informe de avance del 2026-09-25 que lo reporta en **amarillo, al 77%**, con riesgos abiertos y un hallazgo de auditoría de seguridad sin resolver. Cerrarlo hoy sería cerrarlo por decisión, no por cumplimiento; esa decisión no está en ningún documento.

### Contra lo comprometido
**Criterio de éxito:** "Red privada LTE en mina en producción y medido." (acta 2025-07-19, sección Criterio de éxito).
**Se cumplió:** **no se puede determinar.** Ningún documento dice que la red esté en producción ni hay medición alguna. El único dato de avance es una declaración de la gerente (77%), sin evidencia que la sustente (fuentes de la ficha: 0 evidencia, 5 declaración).

| Entregable comprometido | Estado | Evidencia |
|---|---|---|
| Componente 1 | Sin dato | El acta lo nombra sin describirlo; no hay cronograma ni entregables |
| Componente 2 | Sin dato | Ídem |
| Componente 3 | Sin dato | Ídem |

### Fuera de alcance final
| Qué quedó fuera | Decidido por | Cuándo |
|---|---|---|
| "Lo que otro proyecto cubre" (acta, sin precisar cuál proyecto) | Acta de constitución; sin decisión posterior registrada | 2025-07-19 |

No hay solicitudes de cambio ni recortes de alcance registrados (cambios: 0). Tampoco hay evidencia de que no hayan ocurrido: no hay minutas de comité en la carpeta.

### Números finales
| | Original | Vigente | Final | Desviación vs original |
|---|---|---|---|---|
| Fecha de cierre | 2026-09-22 | 2026-09-22 | **No hay: el proyecto no ha declarado cierre** | 0 días registrados (compute: slip vs original 0; vigente 0) |
| Presupuesto aprobado (COP) | 4.200.000.000 | 4.200.000.000 | Ejecutado a corte 2026-09-25: 823.740.094 | Proyección declarada 4.043.433.327 (−3,7 % sobre lo aprobado, según compute) |

Replanificaciones: **0**. Línea base: una sola (versión 1, acta 2025-07-19).

Lectura que hay que hacer con cuidado:
- La fecha de cierre comprometida (2026-09-22) es **anterior** a la fecha de corte del único informe (2026-09-25) y a hoy, y el proyecto sigue declarándose en curso. El 0 de desviación en fecha significa que **nadie registró un cambio de fecha**, no que se haya cumplido: sin replanificación formal, el atraso está sin reconocer.
- Ejecutado 19,6 % y comprometido 70,0 % del aprobado (compute), frente a 77 % de avance declarado. Son tres cifras que no se explican entre sí con lo que hay en la carpeta; no las concilio ni invento la causa.

### RAID al cierre
**Materializados:** ninguno confirmado. El hallazgo de la auditoría de seguridad figura como hecho ocurrido en el periodo (incidencia), sin fecha de origen ni doliente.
**No materializados:** sin dato; no hay registro RAID previo contra el cual contrastar.
**Abiertos, con doliente:** hay tres y **ninguno tiene doliente con nombre**, así que no pueden darse por cerrados:

| Tipo | Qué | Doliente | Fuente |
|---|---|---|---|
| Riesgo | El proveedor no ha confirmado la fecha de la última entrega | Sin doliente | Informe 2026-09-25 |
| Riesgo | Ventana de parada de planta definida por operaciones | Sin doliente | Informe 2026-09-25 |
| Incidencia | Hallazgo levantado en la auditoría de seguridad | Sin doliente | Informe 2026-09-25 |

El acta declara "Ninguna" dependencia, pero el informe menciona a un proveedor y a operaciones: hay dependencias reales no registradas. La ficha no tiene proveedores ni contrato.

### Lecciones
**Ninguna se puede sustentar todavía.** Una lección exige un hecho, una fecha y un efecto documentados, y la carpeta tiene dos documentos: un acta y un informe de avance. Hay un dato que merece seguimiento, no una lección: *el proyecto superó su fecha de cierre comprometida sin registrar replanificación*; el efecto aún no se conoce porque el proyecto no ha terminado.

| Qué pasó | Cuándo | Efecto | Qué haríamos distinto |
|---|---|---|---|
| Sin lecciones sustentables | — | — | — |

### Sin dato
- Declaración de terminado, acta de aceptación o evidencia de puesta en producción y medición (el criterio de éxito).
- Cronograma e hitos (la ficha no tiene ninguno), entregables por componente y qué son los Componentes 1 a 3.
- Informe posterior al 2026-09-25: el proyecto lleva **20 días en silencio** (umbral 15; señal `silent` abierta).
- Contrato y entregables del proveedor, facturación, y estado de su "última entrega".
- Respuesta al hallazgo de la auditoría de seguridad.
- Minutas del Comité Ambiental (el comité sale solo del acta), solicitudes de cambio y quién ratificó el atraso.
- Producto asociado, autoridad y fase del proyecto (campos sin dato).
- Todos los datos de identidad, plan y presupuesto aprobado vienen del acta de hace 15 meses (mayor al umbral de 12): están vencidos y conviene confirmarlos.

### Qué haría falta para cerrarlo
1. Que Liliana Torres (gerente) o Mauricio Pérez (patrocinador) declare por escrito si el proyecto terminó, y contra qué evidencia del criterio de éxito.
2. Si no terminó: una replanificación formal con nueva fecha y su motivo, o una decisión explícita de cerrar sin cumplir el criterio.
3. Un doliente con nombre para los tres abiertos.

### Después
**No muevo la carpeta a `archivo/` ni congelo la ficha:** el proyecto no está cerrado, y sacarlo del barrido diario lo dejaría sin vigilancia justo cuando está en silencio, vencido y en amarillo. Se mantiene en el barrido. (Respuesta sugerida tomada: no archivar.)

---
**Pie de rigor.** Cada dato lleva la fuente arriba. Las cifras derivadas (19,6 %; 70,0 %; −3,7 %; 20 días de silencio; 0 replanificaciones) salen de `compute`; ninguna es mía. Este documento es un borrador de trabajo: la verificación contra los documentos es suya. Lo que no sé: si el proyecto terminó, si cumplió su criterio de éxito, y por qué el avance, lo ejecutado y lo comprometido no cuadran.
