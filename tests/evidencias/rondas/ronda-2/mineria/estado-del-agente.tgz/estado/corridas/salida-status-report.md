Estado de PRY-206 a partir de la ficha `estado/records/PRY-206.json` (actualizada el 2026-10-15) y del cálculo `compute` del 2026-10-15.

## PRY-206 · Red privada LTE en mina — estado al 2026-10-15

**Declara el gerente (Liliana Torres):** amarillo · 77 % · al 2026-09-25 (20 días; la declaración no pasa de 30, no está vencida)
**Sustento documental:** sin sustento. De las fuentes de la ficha, 0 son evidencia y 5 son declaración del propio informe de avance; la otra fuente es el acta de constitución, que sólo sustenta el plan original.
**Lo que el semáforo no explica:** `silent`: 20 días sin documentos, desde el 2026-09-25 (umbral 15 días).
**Último documento:** 2026-09-25 (informe de avance) · **Última reunión:** sin dato; no hay minutas en la carpeta.

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2026-09-22 | 2026-09-22 | 0 días (el script no la mide sin hitos ni replanificaciones) |
| Presupuesto aprobado | COP 4.200.000.000 | COP 4.200.000.000 | proyección declarada COP 4.043.433.327 → -3,7 % |

Replanificaciones: 0.

Presupuesto (salida de `compute`): comprometido COP 2.939.043.394 (70,0 %), ejecutado COP 823.740.094 (19,6 %), disponible real COP 1.260.956.606. Comprometido, ejecutado y proyección son cifras declaradas en el informe del 2026-09-25, no verificadas contra facturas.

Observación mía, no calculada por el script: la fecha de cierre de la línea base (2026-09-22) es anterior a la fecha de este informe, y el proyecto sigue declarando 77 % y amarillo. El script no la marca porque no hay hitos ni una fecha vigente distinta; sin cronograma no se puede medir cuánto falta.

### Hitos
Sin dato. No hay cronograma en la carpeta (`plan.milestones` vacío), así que no hay hitos con fecha base, fecha vigente ni evidencia de cumplimiento.

### Dónde no coincide
Con el único informe y el acta no hay dos fuentes que se contradigan (conflictos abiertos: 0). Lo que sí hay es una declaración sin contraparte: el 77 % y el amarillo no se pueden contrastar con ningún documento de evidencia, y llevan 20 días sin ningún documento posterior.

### Abierto
**Riesgos e incidencias sin movimiento:** ninguno tiene fecha de último movimiento, así que no se pueden contar días sin movimiento. Registrados en el informe del 2026-09-25, sin responsable ni fecha:
- Riesgo: el proveedor no ha confirmado la fecha de la última entrega.
- Riesgo: ventana de parada de planta definida por operaciones.
- Incidencia: se levantó un hallazgo en la auditoría de seguridad.

**Compromisos vencidos:** ninguno; tampoco hay compromisos registrados (no hay minutas).
**Dependencias sin confirmar:** ninguna registrada. El riesgo de la entrega del proveedor sugiere una dependencia externa, pero la ficha no tiene proveedores ni contrato.

### Sin dato
- Producto, autoridad y fase del proyecto (`identity.product`, `identity.authority`, `identity.phase`).
- Hitos y cronograma (`plan.milestones`).
- Proveedores, contratos y entregables (la ficha no tiene ninguno).
- Fecha, responsable y probabilidad/impacto de los dos riesgos y la incidencia.
- Campos de la ficha con más de 12 meses de antigüedad (todos del acta del 2025-07-19, 15 meses): código, nombre, área, patrocinador, comité, fechas de inicio y cierre, alcance y presupuesto aprobado.

### Siguiente paso
Hay un proyecto en silencio por encima del umbral con la fecha de cierre ya pasada y una declaración sin sustento. Si quiere, preparo el punto de comité; para avanzar hace falta el cronograma y una actualización del gerente.

---
Criterio Portfolio 0.3.8 · Ficha aplicada: `estado/records/PRY-206.json`, actualizada el 2026-10-15 · Campos inciertos: ver «Sin dato» · Términos 1.1 aceptados el 2026-10-15 por José Francisco Ñáñez: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.8
