# Corrida del 2026-10-15 · product-definition

PRD-300 · 4 requerimientos · 29 s · 14 hallazgos

| Señal | Hallazgos |
|---|---:|
| `decision_without_source` | 4 |
| `requirement_untraced` | 4 |
| `evidence_stale` | 3 |
| `requirement_accepted_without_evidence` | 1 |
| `assumption_unverified` | 1 |
| `claim_vs_metric` | 1 |

La evidencia sostiene débilmente el problema (una entrevista de hace 12 meses); contradice la cifra de volumen (37,7 % por debajo); faltan criterio de éxito y autoridad

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## Definición — Monitoreo de flota (PRD-300) · contrastada al 2026-10-15
**Documento:** `00-definicion/2026-02-02-definicion-producto.docx` (con `2026-02-02-caso-de-negocio.md`) · **del** 2026-02-02 · 6 afirmaciones

### Lo que la evidencia contradice
| Afirma | Dice la evidencia | Las dos fuentes y sus fechas |
|---|---|---|
| volumen_mensual = 164.808 | Medido 102.629: el declarado está 37,7 % por encima (umbral 20 %) | Declarado: `00-definicion/2026-02-02-caso-de-negocio.md`, 2026-02-02 · Medido: `20-metricas/2026-09-28-tablero-metricas.md` (bodega de datos, tablero de producto), corte 2026-09-28 |

### El negocio y los datos
| Métrica | Declarado | Medido | Diferencia | Las dos fuentes y fechas |
|---|---|---|---|---|
| volumen_mensual | 164.808 | 102.629 | 37,7 %, declarado por encima | Caso de negocio 2026-02-02 · Tablero 2026-09-28 |

La serie tiene un solo punto (2026-09-28): no hay tendencia que mostrar, solo el contraste con ese punto.

### Afirmaciones numéricas que nadie mide
| Afirma | De qué documento | No hay serie |
|---|---|---|
| «Retorno esperado en 24 meses» | `2026-02-02-caso-de-negocio.md` | No trae cifra ni métrica, y no hay serie de retorno. Nadie mide lo que el negocio afirmó. |
| «El ahorro se sostiene sin inversión adicional» (el ahorro es una cifra implícita) | `2026-02-02-definicion-producto.docx` | Ni el caso de negocio ni el tablero traen una serie de ahorro ni de inversión. |

### No está dicho en ninguna parte
- **Criterio de éxito:** no está en ningún documento. Sin él la definición no se puede cerrar ni juzgar después.
- **Quién decide (autoridad):** no está declarada, ni en la configuración ni en los documentos.
- **La propuesta:** el documento dice solo «Propuesta principal»; no dice qué se propone.
- **Qué entiende la definición por «monitoreo de flota»** y qué parte del segmento Gerencia lo necesita: no está dicho.
- **De dónde sale 164.808:** el caso de negocio da la cifra sin método ni base de cálculo.
- **El plazo y el monto del retorno:** solo dice «24 meses»; no hay retorno en cifras.
- **Qué proyecto lo construye:** el documento dice «Ninguno declarado». Los 4 requerimientos aceptados tampoco tienen proyecto.

### Sostenida por un supuesto
| Supuesto | Días sin verificar | Qué haría falta para verificarlo |
|---|---|---|
| El ahorro se sostiene sin inversión adicional (declarado el 2026-06-06) | 131 (umbral 30) | Una cifra de ahorro con su línea base, el costo de operación y mantenimiento proyectado, y alguien que compare ambos contra lo ejecutado. Hoy no existe ninguno de los tres en la carpeta. |

Nota: el supuesto lleva fecha 2026-06-06, posterior a la fecha de la definición (2026-02-02). El documento se editó después de esa fecha sin cambiar su fecha de encabezado.

### Sostenida por evidencia
| Afirmación | Sostenida por | De cuándo | Qué tan fuerte |
|---|---|---|---|
| «El segmento Gerencia no tiene monitoreo de flota» | Entrevista: «Lo necesito y hoy no lo tengo.» — Cliente entrevistado | 2025-09-28 | Débil. Es una declaración de necesidad de una sola persona, sin nombre ni segmento; nadie pagó ni se comprometió. La entrevista no nombra el segmento Gerencia ni ningún requerimiento. |

### Evidencia que ya envejeció
| Afirmación | Lo más nuevo que la sostiene | Hace |
|---|---|---|
| El problema de Gerencia (y REQ-1000, REQ-1001, REQ-1002, que citan esa misma entrevista) | Entrevista del 2025-09-28 | 12 meses (umbral 12) |

REQ-2017 (aceptado el 2026-09-28) no tiene ninguna evidencia de demanda.

### Lo normativo que toca
| Qué toca | País | Obligación | Norma | Estado |
|---|---|---|---|---|
| Monitoreo de flota puede tratar datos de ubicación de vehículos y, por extensión, de conductores | No declarado en los documentos | — | — | No tengo la norma a la vista. Ningún documento dice el país ni qué datos recoge el producto, así que no nombro ni cito una norma. Esto no es un cumplimiento: va a revisión jurídica. |

### Lo que falta para cerrar la definición
- **Criterio de éxito:** falta.
- **Quién decide:** falta.
- Problema y para quién sí están escritos (Segmento Gerencia), pero con evidencia débil y de hace 12 meses.
- Con esto la definición **no se puede cerrar**.

### Después
- El supuesto del ahorro lleva 131 días sin verificar: se puede convertir en riesgo con doliente (raid-taxonomy).
- No se ofrece `/product-charter`: la definición no está cerrada (falta criterio de éxito y autoridad).
