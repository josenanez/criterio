## Trazabilidad — Monitoreo de flota (PRD-300) · al 2026-10-15
4 decididos · 0 con proyecto · 0 confirmados contra la ficha · 0 entregados

### Decidido y nadie lo está construyendo
| REQ | Título | Decidido el | Por quién |
|---|---|---|---|
| REQ-1000 | Requerimiento REQ-1000 | No consta (el acta del 2026-10-11 lo lista «aceptado» desde 2026-08-28 y dice «Se mantiene el plan») | No consta |
| REQ-1001 | Requerimiento REQ-1001 | No consta (misma acta) | No consta |
| REQ-1002 | Requerimiento REQ-1002 | No consta (misma acta) | No consta |
| REQ-2017 | Requerimiento REQ-2017 | No consta (misma acta) | No consta |

Los cuatro están aceptados, ninguno nombra proyecto (`traces.project` vacío) y no hay documento de decisión ni quién decidió: la cadena se rompe en el primer eslabón, antes de llegar a un proyecto. Fuente: `documentos/productos/PRD-300/30-decisiones/2026-10-11-comite-producto.docx`.

Dueños: REQ-1000 Andrés Lozano · REQ-1001 Javier Hoyos · REQ-1002 Mauricio Pérez · REQ-2017 Natalia Ospina.

### La traza no se confirma
Ninguna: no hay trazas que confirmar, porque ningún requerimiento dice qué proyecto lo ejecuta.

### Lo que un proyecto construye y el registro no tiene
Ninguno detectado. La única ficha a la vista (PRY-205, Sistema de gestión de seguridad) tiene `identity.product` vacío (no encontrado en el acta de constitución del 2025-08-11): no dice que ejecute PRD-300. Ese campo vacío es un hallazgo de su lado, no de este registro.

### La cadena completa
| REQ | Estado | Decisión | Proyecto | Confirmado | Entregables |
|---|---|---|---|---|---|
| REQ-1000 | aceptado | sin documento ni decisor | — | no | — |
| REQ-1001 | aceptado | sin documento ni decisor | — | no | — |
| REQ-1002 | aceptado | sin documento ni decisor | — | no | — |
| REQ-2017 | aceptado | sin documento ni decisor; además sin evidencia de demanda | — | no | — |

Evidencia de demanda: 3 de 4 la tienen, pero toda es de la ronda de entrevistas del 2025-09-28 (12 meses) y la entrevista no nombra los requerimientos. REQ-2017 no tiene ninguna.

### Sin fichas a la vista
Solo hay una ficha publicada de los 13 proyectos en `documentos/proyectos` (PRY-205). No hay fichas de PRY-199 a PRY-204 ni de PRY-206 a PRY-211. Entre ellas, PRY-203 (despacho automático de flota) podría tocar este producto, pero no se puede saber sin su ficha. Ninguna traza se da por confirmada.

### Fuera del alcance de este comando, pero a la vista
- Caso de negocio declara 164.808 de volumen mensual; el tablero del 2026-09-28 mide 102.629 (37,7 % por debajo, umbral 20 %).
- Supuesto «El ahorro se sostiene sin inversión adicional» sin verificar hace 131 días (umbral 30).

### Después
Hay cuatro decididos sin proyecto, pero antes de `/product-charter` falta quién los decidió y cuándo: ninguno está listo para ser proyecto. Eso es una conversación con el comité de producto.
