# Caso de negocio — Monitoreo de flota (PRD-300) · borrador del 2026-10-15
**Desde:** `00-definicion/2026-02-02-definicion-producto.docx` y `00-definicion/2026-02-02-caso-de-negocio.md`, ambos del 2026-02-02 · **Cifras con fuente:** 1 de 1 (la única cifra del caso tiene fuente, pero esa fuente es el propio caso de negocio, sin método ni base de cálculo)

> Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-15): comprobante ya registrado. Este es un borrador de trabajo: las cifras son del negocio y no se produjo ninguna.

## Qué problema resuelve, y para quién
«El segmento Gerencia no tiene monitoreo de flota.» Para el Segmento Gerencia. (`2026-02-02-definicion-producto.docx`, 2026-02-02.)
La evidencia que lo sostiene es débil y de hace 12 meses: «Lo necesito y hoy no lo tengo.», de un cliente entrevistado sin nombre ni segmento (`10-descubrimiento/2025-09-28-entrevistas.md`, 2025-09-28). La entrevista no nombra el segmento Gerencia ni ningún requerimiento.

## Qué se construye
| Requerimiento | Estado | Evidencia de demanda |
|---|---|---|
| REQ-1000 (dueño: Andrés Lozano, planteado 2026-08-28) | aceptado | El acta de comité atribuye a «Cliente entrevistado» la cita de 2025-09-28; la entrevista no nombra este requerimiento |
| REQ-1001 (dueño: Javier Hoyos, planteado 2026-03-26) | aceptado | Igual que REQ-1000 |
| REQ-1002 (dueño: Mauricio Pérez, planteado 2026-05-21) | aceptado | Igual que REQ-1000 |
| REQ-2017 (dueño: Natalia Ospina, planteado 2026-09-28) | aceptado | **Ninguna** |

Los cuatro figuran «aceptado» en el acta del 2026-10-11 (`30-decisiones/2026-10-11-comite-producto.docx`), que dice «Se mantiene el plan». No hay documento de decisión ni quién decidió, y ninguno tiene necesidad, prioridad ni proyecto asignado. El criterio de aceptación de los cuatro es «se verifica en producción». Por eso entran al caso como aceptados en el acta, no como decididos con respaldo.

## Las cifras
| Cifra | Valor | Clase | De dónde sale | De cuándo |
|---|---|---|---|---|
| volumen_mensual | 164.808 | Declarada | `00-definicion/2026-02-02-caso-de-negocio.md` (preparado por Beatriz Cuéllar). Sin método ni base de cálculo | 2026-02-02 |
| volumen_mensual | 102.629 | Medida | `20-metricas/2026-09-28-tablero-metricas.md` (bodega de datos, tablero de producto) | corte 2026-09-28 |
| Retorno esperado en 24 meses | sin cifra | Supuesta | `2026-02-02-caso-de-negocio.md` dice solo «Retorno esperado en 24 meses»: no trae monto ni métrica | 2026-02-02 |
| Ahorro | sin cifra | Supuesta | Implícita en «El ahorro se sostiene sin inversión adicional» (`2026-02-02-definicion-producto.docx`, supuesto fechado 2026-06-06) | 2026-06-06 |

La serie medida tiene un solo punto (2026-09-28): no hay tendencia.

### Donde la cifra declarada y la medida no coinciden
| Métrica | Declarada | Medida | Las dos fuentes y fechas |
|---|---|---|---|
| volumen_mensual | 164.808 | 102.629 | Declarada por encima en 37,7 % (umbral 20 %). Caso de negocio 2026-02-02 · Tablero de métricas, corte 2026-09-28 |

Esto va dentro del caso: la única cifra que sostiene el volumen está 37,7 % por encima de lo que mide la bodega de datos. Las dos fechas están separadas por ocho meses, así que no se puede decir si 164.808 fue una proyección que no se cumplió o una cifra mal calculada; eso lo responde quien la declaró.

## Los costos
| Concepto | Valor | De dónde sale |
|---|---|---|
| Costo de construir | **No está en ningún documento** | Vacío (ver abajo) |
| Costo de operación y mantenimiento | No está en ningún documento | Vacío |
| Contratos, cotizaciones, costo del equipo | No hay | Vacío |

**El costo de construir es el primer vacío.** Sin él no hay caso de negocio que evaluar: hay una propuesta.

## Supuestos sobre los que se sostiene
| Supuesto | Qué pasa si resulta falso | Quién lo verificaría |
|---|---|---|
| El ahorro se sostiene sin inversión adicional (declarado el 2026-06-06; 131 días sin verificar, umbral 30) | Si hace falta inversión adicional, el retorno en 24 meses deja de sostenerse | No hay doliente nombrado. Haría falta una cifra de ahorro con su línea base, el costo de operación y mantenimiento proyectado, y alguien que compare ambos contra lo ejecutado |
| El volumen mensual de 164.808 se alcanza (implícito en el caso) | La demanda de uso queda sobreestimada; hoy se mide 102.629 | Beatriz Cuéllar (autora del caso) con el dueño del tablero |
| Gerencia es el segmento que lo necesita (implícito) | El problema no tiene demanda sostenida | Quien conduzca el descubrimiento; la única evidencia es una entrevista anónima de 2025-09-28 |

Nota: el supuesto lleva fecha 2026-06-06, posterior a la fecha de la definición (2026-02-02), así que el documento se editó sin cambiar la fecha del encabezado.

## Vacíos
| Qué falta | Por qué importa | Quién lo produce |
|---|---|---|
| Costo de construir y de operar | Sin él no hay caso que evaluar | Finanzas / quien tenga el presupuesto; no está declarado |
| Cifra y plazo del retorno | «24 meses» sin monto no se puede verificar | Beatriz Cuéllar |
| Método de cálculo de 164.808 | No se puede saber por qué difiere de lo medido | Beatriz Cuéllar |
| Cifra de ahorro y su línea base | Es el supuesto sin verificar hace 131 días | El negocio; no hay doliente |
| Criterio de éxito | Sin él el caso no se puede cerrar ni verificar después | Beatriz Cuéllar / la autoridad |
| Quién decide (autoridad) | No está en la configuración ni en los documentos | La organización |
| Qué pasa si no se hace, y qué alternativas se consideraron | El caso no los menciona | Beatriz Cuéllar |
| Proyecto que lo construye | La definición dice «Ninguno declarado»; los 4 requerimientos aceptados tampoco tienen proyecto | La PMO / quien decida |
| País y datos que recoge (ubicación de vehículos, posiblemente de conductores) | Puede tocar obligaciones normativas. No tengo la norma a la vista y no la cito: esto va a revisión jurídica, no es un dictamen de cumplimiento | Jurídico |

## Cómo se sabrá si funcionó
**No está declarado.** Ningún documento trae criterio de éxito, métrica de éxito ni fecha de corte. La única métrica con serie es volumen_mensual (un punto, 2026-09-28), pero ningún documento la define como criterio de éxito. Sin esto el producto no se puede cerrar meses después.

## Si hay otros productos publicados
No hay ninguno publicado a la vista: la carpeta trae documentos de PRD-299 a PRD-309, pero ninguna ficha publicada. Aun así busqué la cifra 164.808 en esos documentos y no aparece en ninguno. Varios de esos productos también usan la métrica `volumen_mensual`; no es coincidencia de cifra, pero cuando se publiquen conviene correr `/product-overlap` para confirmar que no cuentan las mismas transacciones.

## Después
Los supuestos se pueden pasar al seguimiento con assumption-tracking; el del ahorro, con 131 días sin verificar, puede pasar a riesgo con doliente (raid-taxonomy). No se ofrece `/product-charter`: faltan criterio de éxito, autoridad y costo.
