Producto configurado: PRD-300 (el argumento es REQ-1000). Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15); no hizo falta registrarlos de nuevo.

## Verificación previa: REQ-1000 no cumple los cuatro requisitos

| Requisito | Estado | Detalle |
|---|---|---|
| Aceptado, no propuesto | **Cumple a medias** | Figura «aceptado» desde 2026-08-28 en el acta de comité del 2026-10-11, pero no consta quién lo aceptó ni cuándo: el acta solo dice «Se mantiene el plan». |
| Criterios de aceptación verificables | **Falta** | El único criterio es «se verifica en producción» (acta de comité). Dice dónde se verifica, no qué se mide. No sirve para juzgar el cierre. |
| Evidencia de demanda con su cita | **Débil** | «Lo necesito y hoy no lo tengo.» (entrevistas, 2025-09-28, 12 meses). La entrevista no nombra este requerimiento; el acta se la atribuye a «Cliente entrevistado». El umbral de vigencia es de 12 meses. |
| Autoridad declarada en la definición | **Falta** | La definición no la declara y la configuración trae `authority: null`. |

Nadie puede responder en esta sesión, así que tomo la respuesta sugerida: **sigo sin ellos, marcados como vacío del acta.** No relleno nada.

---

# Acta de constitución — Monitoreo de flota (REQ-1000) · borrador del 2026-10-15
**Producto:** PRD-300 · Monitoreo de flota · **Requerimientos:** REQ-1000

## Qué problema resuelve
«El segmento Gerencia no tiene monitoreo de flota.» (`00-definicion/2026-02-02-definicion-producto.docx`, 2026-02-02).
El REQ-1000 no tiene necesidad propia registrada: el campo *need* está vacío. El título tampoco es descriptivo, solo «Requerimiento REQ-1000» (acta de comité, 2026-10-11).

## Criterio de éxito
- La definición del producto **no declara criterio de éxito** (`success`: no encontrado).
- Único criterio del requerimiento: «se verifica en producción» (`30-decisiones/2026-10-11-comite-producto.docx`). **Cómo se verifica: no está dicho.** Con esto, el cierre no se podrá juzgar meses después. Es un vacío, no un criterio.

## Alcance
### Entra
| REQ | Título | Evidencia que lo sostiene |
|---|---|---|
| REQ-1000 | Requerimiento REQ-1000 | «Lo necesito y hoy no lo tengo.» — Cliente entrevistado, 2025-09-28 (`10-descubrimiento/2025-09-28-entrevistas.md`). La cita no nombra el requerimiento y tiene 12 meses. |

### No entra
| REQ | Título | Por qué no |
|---|---|---|
| REQ-1001 | Requerimiento REQ-1001 | No se pidió en este acta. Aceptado, sin proyecto, y apoyado en la misma cita genérica. Queda fuera hasta que alguien lo incluya. |
| REQ-1002 | Requerimiento REQ-1002 | Igual que REQ-1001. |
| REQ-2017 | Requerimiento REQ-2017 | No se pidió en este acta. Además está aceptado sin ninguna cita de quien lo pidió. |

Esta exclusión es de esta acta, no un descarte de los requerimientos. Quien firma puede añadirlos.

## Gobierno
- **Patrocinador:** no está dicho en ningún documento.
- **Gerente propuesto:** Beatriz Cuéllar, gerente del producto (`2026-02-02-definicion-producto.docx`). Es una propuesta; ningún documento la nombra gerente de este proyecto. Asignarla es de quien tiene la autoridad.
- **Comité:** comité de producto, mensual (configuración). El de 2026-10-11 asistió solo Beatriz Cuéllar.
- **Autoridad del gerente:** **no está dicha.** Sin ella, el proyecto arranca con un gerente que no sabe qué puede decidir.
- **Doliente del requerimiento:** Andrés Lozano (acta de comité, 2026-10-11).

## Supuestos que se llevan al proyecto
| Supuesto | Verificado | Se convierte en riesgo de |
|---|---|---|
| «El ahorro se sostiene sin inversión adicional» (declarado el 2026-06-06; `2026-02-02-definicion-producto.docx`) | No, lleva 131 días (umbral: 30) | Por asignar. Propuesta: el gerente del proyecto, con Beatriz Cuéllar como dueña del caso de negocio. |
| El volumen mensual declarado sostiene el caso: 164.808 (`2026-02-02-caso-de-negocio.md`) frente a 102.629 medido (`2026-09-28-tablero-metricas.md`), un 37,7% por encima (umbral: 20%) | No: los datos no lo sostienen | Por asignar. Es riesgo sobre el retorno esperado a 24 meses. |

El REQ-1000 no declara supuestos propios.

## Restricciones normativas sin resolver
| Qué toca | Obligación | Norma | Estado |
|---|---|---|---|
| Ningún documento lo dice | — | — | **No evaluado.** No hice el barrido normativo. La definición no menciona datos personales, ubicación ni retención. Si el monitoreo de flota recoge ubicación de conductores, habría que revisarlo. |

## Vacíos de este acta
| Qué falta | Consecuencia de firmar sin eso | Quién lo cierra |
|---|---|---|
| Documento de decisión: quién aceptó el REQ-1000 y cuándo | El proyecto nace de una aceptación que no consta; nadie respondería por ella | Quien presidió el comité de 2026-10-11 (no consta quién fue) y Beatriz Cuéllar |
| Criterio de aceptación medible | No se podrá juzgar el cierre | Andrés Lozano, doliente |
| Criterio de éxito del producto | Nada contra qué medir el proyecto | Beatriz Cuéllar |
| Evidencia de demanda propia y vigente | Se construye sobre una cita genérica de hace 12 meses | Andrés Lozano, volviendo a preguntar a quien lo pidió |
| Autoridad del gerente | Escala todo o no escala nada | Quien tenga la autoridad sobre el producto (no consta quién) |
| Patrocinador | Nadie respalda ni financia | Por definir |
| Presupuesto e hitos | Ningún documento los declara. No los invento y no hay plan en el acta | Gerente del proyecto, al planificar |
| Título y necesidad del requerimiento | El proyecto no tiene nombre ni problema propios | Andrés Lozano |

---
**Esto es un borrador.** Lo firma una persona con autoridad sobre el producto; hoy no consta quién. La ficha del proyecto se crea después de la firma.

**Sin firma, no he creado la ficha** (`portafolio.py init` no se corrió) y no he escrito el estado declarado.

## Después
Quien firme decide si cierra los vacíos antes. Con ellos abiertos, la recomendación es no firmar todavía. Una vez firmada y creada la ficha, el gerente del proyecto instala `criterio-project` y corre `/pm-setup`. Cuando publique su ficha con `/pm-publish`, `/product-trace` podrá confirmar la traza contra ella.
