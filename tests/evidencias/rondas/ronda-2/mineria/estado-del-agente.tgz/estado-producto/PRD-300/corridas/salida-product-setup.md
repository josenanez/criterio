## Listo — Monitoreo de flota (PRD-300)

Soy Alba. Trabajo antes de que haya proyecto: miro qué sostiene tu definición y qué se sostiene solo.

**Sesión sin interfaz:** no hice preguntas; tomé la respuesta sugerida en cada una. (1) Producto y gerente: PRD-300 «Monitoreo de flota», Beatriz Cuéllar, tal como dice la definición. (2) Quién decide qué se construye: ningún documento lo dice, queda sin dato. (3) Estado en `estado-producto/PRD-300`, fuera de la documentación. (4) Términos: aceptados por José Francisco Ñáñez, como indicaste.

**Lo que miré:** 5 documentos · 1 de descubrimiento (una entrevista, 2025-09-28) · la definición del 2026-02-02 · lo más reciente es el acta del comité del 2026-10-11 · los 5 se pudieron leer, ninguno quedó sin leer.
**Términos:** aceptados para la versión 1.1 (familia 0.3.8) · comprobante en `.criterio/terminos/aceptacion-criterio-product-0.3.8-2026-10-15.md` y `.pdf` · SHA-256 d532cc0636d081a9… (del .md)

Levanté la ficha del producto y los 4 requerimientos que el acta del comité nombra (REQ-1000, REQ-1001, REQ-1002, REQ-2017), solo con lo escrito.

### Lo que tu definición afirma, y qué lo sostiene
| Afirmación | Sostenida por | De cuándo |
|---|---|---|
| «El segmento Gerencia no tiene monitoreo de flota» | Una sola cita: «Lo necesito y hoy no lo tengo» (cliente sin nombre; no dice que sea de Gerencia) | 2025-09-28 |
| Volumen mensual de 164.808 | Nada que la sostenga: el tablero mide 102.629 al 2026-09-28; la diferencia es de 37,7 %, declarado por encima | 2026-02-02 (caso de negocio) vs 2026-09-28 (tablero) |
| «El ahorro se sostiene sin inversión adicional» | Es un supuesto, sin verificar desde el 2026-06-06 (131 días) | 2026-06-06 |

### Lo que no está dicho en ninguna parte
- Cómo se mide el éxito: la definición no trae criterio de éxito.
- Qué es la «Propuesta principal»: el título está y no hay texto debajo.
- De dónde sale el retorno esperado en 24 meses: no hay cifra, base ni fuente.
- De dónde sale el ahorro: ninguna cifra de ahorro en ningún documento.
- Quién decide qué se construye: ningún documento nombra la autoridad (el acta del comité solo lista a Beatriz Cuéllar como asistente).
- Quién aceptó los 4 requerimientos, y cuándo: el acta dice «aceptado» con una fecha «desde», pero no hay decisión escrita ni quién decidió; solo dice «Se mantiene el plan».
- Qué necesita cada requerimiento: los cuatro tienen solo un número y el nombre «Requerimiento REQ-xxxx»; ninguno dice el problema que resuelve.
- REQ-2017 (Natalia Ospina): nadie lo pidió según el acta. Está aceptado sin evidencia de demanda.
- Qué proyecto construye cada requerimiento: «Ninguno declarado», y las 4 casillas del acta tienen «—». Lo aceptado no tiene a nadie construyéndolo.

### Supuestos sobre los que está escrita
Uno declarado: «El ahorro se sostiene sin inversión adicional», del 2026-06-06, sin verificar. No declara ningún otro.

### Lo que dicen las cifras
- Evidencia de demanda: 3 de 4 requerimientos aceptados (75,0 %) tienen una cita; la misma, de «Cliente entrevistado», 2025-09-28, con 12 meses de antigüedad en los tres. La entrevista no nombra ningún requerimiento: el vínculo viene solo del acta.
- Criterio de aceptación: los 4 dicen «se verifica en producción», que no es un criterio medible.
- Con proyecto que los ejecute: 0 de 4 (0,0 %).
- Nadie está midiendo lo que el negocio afirmó, salvo el volumen mensual, que es la única métrica a la vista.

### Qué le falta a tu carpeta
Como hallazgo, no como requisito:
- Las transcripciones de las entrevistas: hay una sola cita de una sola persona, y no se sabe a quién.
- La serie de volumen_mensual: hay un solo punto (2026-09-28); con una serie se vería si la brecha se cierra o se abre.
- Las decisiones del comité de producto con quién decidió y por qué; sin ellas, lo descartado se ve igual que lo que nadie miró.
- Las demás métricas del caso de negocio (retorno, ahorro): no hay cifra ni medición.

Siguiente paso: `/product-discovery` sobre el material de entrevistas, para que los temas se vuelvan requerimientos con la cita de quién lo pidió.
