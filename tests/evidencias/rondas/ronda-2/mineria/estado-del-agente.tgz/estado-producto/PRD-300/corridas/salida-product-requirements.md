## Registro — Monitoreo de flota (PRD-300) · al 2026-10-15
4 requerimientos · 4 decididos · 75% con evidencia · 0% con proyecto que lo ejecuta

*(Sin carpeta de fichas de proyecto: no hay con qué confirmar trazas. Aun así, ningún requerimiento declara proyecto.)*

### Se va a construir y nadie lo pidió
| REQ | Título | Estado | Doliente |
|---|---|---|---|
| REQ-2017 | Requerimiento REQ-2017 | aceptado | Natalia Ospina |

Sin una sola cita de quien lo pidió. Dicho el 2026-09-28 (hace 17 días) y aceptado sin evidencia.

### Decidido y nadie lo está construyendo
| REQ | Título | Decidido el | |
|---|---|---|---|
| REQ-1000 | Requerimiento REQ-1000 | sin fecha | sin proyecto |
| REQ-1001 | Requerimiento REQ-1001 | sin fecha | sin proyecto |
| REQ-1002 | Requerimiento REQ-1002 | sin fecha | sin proyecto |
| REQ-2017 | Requerimiento REQ-2017 | sin fecha | sin proyecto |

Los cuatro están aceptados y ninguno tiene proyecto que lo ejecute. Se ofrece `/product-trace`.

### Sin doliente, o con un área en vez de una persona
Ninguno. Los cuatro tienen una persona: Andrés Lozano (REQ-1000), Javier Hoyos (REQ-1001), Mauricio Pérez (REQ-1002), Natalia Ospina (REQ-2017).

### Sin criterio de aceptación
Ninguno tiene el campo vacío. Los cuatro dicen «se verifica en producción», que más que un criterio medible es una declaración de dónde se verifica. Es una lectura mía, no una señal calculada.

### Decidido sin documento que lo respalde
| REQ | Quién decidió | Cuándo |
|---|---|---|
| REQ-1000 | no consta | no consta |
| REQ-1001 | no consta | no consta |
| REQ-1002 | no consta | no consta |
| REQ-2017 | no consta | no consta |

El acta de comité del 2026-10-11 lista los cuatro como «aceptado» y dice «Se mantiene el plan». No hay documento de decisión ni quién decidió.

### Lleva meses y nadie lo decide
No aplica: ninguno está `propuesto`. El problema es el contrario: están aceptados y no hay registro de quién los aceptó. Quién tiene la facultad: **no está dicho**, porque la configuración trae `authority: null`. Beatriz Cuéllar es la gerente del producto, pero no consta que tenga esa facultad. Hay que definirla.

### Evidencia vieja
| REQ | Lo más nuevo que lo sostiene | Hace |
|---|---|---|
| REQ-1000 | 2025-09-28 · «Lo necesito y hoy no lo tengo.» — Cliente entrevistado | 12 meses |
| REQ-1001 | 2025-09-28 · la misma cita | 12 meses |
| REQ-1002 | 2025-09-28 · la misma cita | 12 meses |

Los tres se sostienen en la misma cita genérica. El acta de comité se la atribuye a «Cliente entrevistado», pero la entrevista no nombra ninguno de estos requerimientos.

### Otros vacíos de la definición (no son del registro, pero lo afectan)
- **Volumen declarado frente a medido:** el caso de negocio (2026-02-02) declara 164.808 al mes y el tablero (2026-09-28) mide 102.629. Eso es un 37,7% por encima del medido, sobre un umbral del 20%.
- **Supuesto sin verificar:** «El ahorro se sostiene sin inversión adicional», 131 días sin verificar. El umbral es de 30.
- **Sin definir:** criterio de éxito y facultad de decisión.

## Por estado
| propuesto | aceptado | en construcción | entregado | descartado |
|---|---|---|---|---|
| 0 | 4 | 0 | 0 | 0 |

**Quién cierra cada vacío** (como propuesta, porque nada lo asigna):
- Evidencia de REQ-2017: Natalia Ospina, que es la doliente.
- Evidencia vieja de REQ-1000, REQ-1001 y REQ-1002: sus dolientes, que son Andrés Lozano, Javier Hoyos y Mauricio Pérez. Les corresponde volver a preguntar a quien lo pidió.
- Documento de decisión de los cuatro: quien presidió el comité del 2026-10-11 (no consta quién fue) y Beatriz Cuéllar.
- Supuesto y brecha de volumen: Beatriz Cuéllar, con quien lleve el caso de negocio.

## Después
Hay cuatro requerimientos aceptados que nadie está construyendo: corre `/product-trace`. No ofrezco `/product-charter` todavía, porque ningún requerimiento aceptado tiene a la vez evidencia vigente, criterio medible y decisión documentada.
