> **Borrador** escrito por el agente. Lo cierra Beatriz Cuéllar (gerente de producto); no consta que tenga la facultad de decidir (`authority: null`), así que quién firma también está por definir.

# Especificación — Monitoreo de flota (PRD-300) · borrador del 2026-10-15

## Qué problema resuelve
«El segmento Gerencia no tiene monitoreo de flota.» (`00-definicion/2026-02-02-definicion-producto.docx`, 2026-02-02). Es lo único que la definición dice. La propuesta aparece como «Propuesta principal», sin contenido. El criterio de éxito **no está dicho en ningún documento**.

## Alcance
### Entra
Los cuatro requerimientos aceptados, **solo como rótulos**: REQ-1000, REQ-1001, REQ-1002 y REQ-2017. Ninguno tiene su necesidad escrita y los cuatro títulos son el genérico «Requerimiento REQ-xxxx». Por eso no hay nada que describir debajo de ellos sin inventarlo.

### No entra
- Todo lo que no figura en el acta de comité del 2026-10-11. El registro no trae ningún otro requerimiento.
- Cualquier comportamiento del monitoreo (qué se monitorea, qué se muestra, con qué frecuencia, a quién se avisa). **No está en ningún documento**, así que esta especificación no lo propone.
- Diseño, estimación, costo y fechas (no son de este comando).

## Comportamiento
**Sin secciones.** Escribir comportamiento exigiría rellenar la necesidad de cada requerimiento (`need: not_found` en los cuatro), y eso lo decidiría el agente y no el producto. Los cuatro quedan en la última tabla.

## Criterios de aceptación
Los cuatro traen el mismo texto: «se verifica en producción» (acta de comité, 2026-10-11). Dice dónde se verifica, no qué se mide, y dos personas mirando lo construido no tendrían con qué coincidir.

| Criterio | Requerimiento | Cómo se verifica | ¿Se puede medir hoy? |
|---|---|---|---|
| «se verifica en producción» | REQ-1000 | No definido: falta la magnitud y el umbral | No: no hay nada que medir todavía |
| «se verifica en producción» | REQ-1001 | No definido | No |
| «se verifica en producción» | REQ-1002 | No definido | No |
| «se verifica en producción» | REQ-2017 | No definido | No |

No redacto un criterio medible en su lugar: sin la necesidad, cualquier cifra sería inventada. Dato de contexto: el único indicador medido hoy es `volumen_mensual` (102.629 al 2026-09-28, bodega de datos). Ningún criterio lo usa.

## Supuestos sobre los que está escrita
| Supuesto | Verificado | Quién lo verificaría |
|---|---|---|
| «El ahorro se sostiene sin inversión adicional» (declarado 2026-06-06; definición) | No: 131 días sin verificar, umbral de 30 | Beatriz Cuéllar (propuesta; nada lo asigna) |
| Los cuatro requerimientos responden a una necesidad real: se sostienen en una sola cita genérica de 2025-09-28 («Lo necesito y hoy no lo tengo.») que no nombra ninguno; REQ-2017 no tiene cita | No | Los dolientes: Andrés Lozano, Javier Hoyos, Mauricio Pérez y Natalia Ospina |
| El volumen del caso de negocio (164.808 al mes, 2026-02-02) | Contradicho: el tablero mide 102.629, un 37,7% menos que lo declarado, con umbral de 20% | Beatriz Cuéllar, con quien lleve el caso de negocio |

## Vacíos
| Qué falta decidir | Consecuencia de no decidirlo | Quién lo cierra |
|---|---|---|
| Necesidad de cada requerimiento (los cuatro) y título real | No hay qué especificar; cualquier texto lo pone el agente | Los dolientes: A. Lozano (REQ-1000), J. Hoyos (REQ-1001), M. Pérez (REQ-1002), N. Ospina (REQ-2017) |
| Criterio de aceptación medible (los cuatro) | «Se verifica en producción» se discute después de construir | Los mismos dolientes, con B. Cuéllar |
| Quién aceptó los requerimientos y cuándo: el acta solo dice «Se mantiene el plan» | Lo «aceptado» no tiene decisión que lo respalde | Quien presidió el comité del 2026-10-11 (no consta quién) y B. Cuéllar |
| Facultad de decisión del producto (`authority: null`) | Nadie puede cerrar este borrador con validez | Por definir; propuesta: B. Cuéllar la confirma con quien corresponda |
| Criterio de éxito del producto | No hay contra qué juzgar el producto entero | B. Cuéllar |
| Casos borde (sin conexión, datos atrasados, vehículo sin señal) | Sin comportamiento definido; los decidiría quien construya | Dolientes, una vez escrita la necesidad |
| Lo que otro equipo tiene que hacer: ningún documento menciona dependencias ni proyecto (definición: «Ninguno declarado») | Puede haber trabajo de otros equipos sin acordar; **no consta** ni que exista ni que no | B. Cuéllar |
| Obligaciones normativas: no se hizo barrido. Los documentos no dicen qué datos maneja el monitoreo; si incluyera datos personales (por ejemplo de conductores), tocaría `regulatory-sweep` | Obligación sin resolver que aparecería tarde. Es una pregunta abierta, no un hallazgo | B. Cuéllar, para decir qué datos maneja el producto |
| Evidencia vieja: la cita sostiene REQ-1000, 1001 y 1002 desde hace 12 meses; REQ-2017 no tiene | Se construiría sobre una demanda no reconfirmada | Los dolientes: volver a preguntar a quien lo pidió |

## Requerimientos aceptados que esta especificación no cubre
| ID | Título | Por qué no |
|---|---|---|
| REQ-1000 | Requerimiento REQ-1000 | Sin necesidad escrita ni criterio medible (doliente: Andrés Lozano) |
| REQ-1001 | Requerimiento REQ-1001 | Ídem (doliente: Javier Hoyos) |
| REQ-1002 | Requerimiento REQ-1002 | Ídem (doliente: Mauricio Pérez) |
| REQ-2017 | Requerimiento REQ-2017 | Ídem, y además sin evidencia de quién lo pidió (doliente: Natalia Ospina) |

**Cobertura: 0 de 4.** Es el resultado, no un fallo del borrador: el registro no trae material suficiente para especificar sin inventar.

## Después
No ofrezco `/product-charter`: los vacíos no están cerrados y ningún requerimiento tiene criterio de éxito. Antes conviene `/product-trace` (los cuatro están aceptados y sin proyecto) y volver a correr esta especificación cuando los dolientes escriban la necesidad.

---
Registro: `estado-producto/PRD-300/requirements/` (4 requerimientos: REQ-1000, REQ-1001, REQ-1002, REQ-2017), actualizado al 2026-10-15. Cubre 0 de 4. Términos v1.1 aceptados por José Francisco Ñáñez el 2026-10-15: https://www.josenanez.com/es/agents/criterio-pmo/legal
