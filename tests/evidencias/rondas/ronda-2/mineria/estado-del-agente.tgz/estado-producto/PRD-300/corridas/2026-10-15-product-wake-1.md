# Corrida del 2026-10-15 · product-wake

PRD-300 · 4 requerimientos · 30 s · 14 hallazgos

| Señal | Hallazgos |
|---|---:|
| `decision_without_source` | 4 |
| `requirement_untraced` | 4 |
| `evidence_stale` | 3 |
| `requirement_accepted_without_evidence` | 1 |
| `assumption_unverified` | 1 |
| `claim_vs_metric` | 1 |

Primera corrida del reloj, sin corte anterior: se reportó todo lo abierto. No se confirmó ninguna traza porque no se dio la carpeta de fichas. Dijo que no sabe quién tiene la facultad de decidir (authority vacío) y que la fuente de la definición (.docx) figura como no resuelta en el índice.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## Monitoreo de flota (PRD-300) · 2026-10-15

**Primera corrida del reloj: no hay corte anterior**, así que todo lo abierto cuenta como nuevo. 4 requerimientos, todos en estado aceptado. Responsable del producto: Beatriz Cuéllar.

### Cruzó un umbral sin que nadie hiciera nada
| Qué | REQ | Cuánto lleva | Qué se necesita | Quién |
|---|---|---|---|---|
| Supuesto sin verificar: «El ahorro se sostiene sin inversión adicional» | definición | 131 días (umbral 30) | Decidir qué dato lo verificaría. Pasó con mucho el punto en que conviene tratarlo como riesgo registrado. | Beatriz Cuéllar (responsable); quién verifica no está dicho |
| La evidencia de demanda envejeció: la última es del 2025-09-28 («Lo necesito y hoy no lo tengo.» — Cliente entrevistado). La entrevista no nombra estos requerimientos. | REQ-1000, REQ-1001, REQ-1002 | 12 meses (umbral 12) | Qué afirmación se queda sin sustento: que estos tres requerimientos responden a una demanda actual. Hace falta una ronda nueva de entrevistas o un dato medido. | Andrés Lozano, Javier Hoyos, Mauricio Pérez |
| Aceptado sin evidencia de demanda | REQ-2017 | 17 días desde que se planteó | Quién lo pidió. | Natalia Ospina |

### Lo que el negocio declara contra lo que los datos miden
- Volumen mensual: el caso de negocio (2026-02-02) declara 164.808; el tablero de métricas (2026-09-28) mide 102.629. **El valor declarado está 37,7 % por encima** (umbral 20 %).

### Para el comité (necesita decisión)
- **Los 4 requerimientos están aceptados, ninguno tiene fuente de la decisión y ninguno tiene proyecto.** El acta del comité del 2026-10-11 no deja quién decidió ni cuándo. Nadie los está construyendo.
- **Facultad de decisión (`authority`) vacía en la configuración:** no sé quién puede aceptar o rechazar requerimientos de este producto. Es el dato que falta para llevar cualquier decisión al comité.
- El criterio de éxito del producto tampoco está definido.

### Las trazas
No se confirmó ninguna traza: esta corrida no recibió la carpeta de fichas de proyectos. 0 de 4 requerimientos trazados, y eso se dice así, no como «sin proyecto» comprobado.

### Del descubrimiento
Los 5 documentos de la carpeta no cambiaron desde la última lectura; no hay descubrimiento nuevo que ofrecer.

### Lo que no sé
- Los campos de identidad y de definición salen de `2026-02-02-definicion-producto.docx`, y el índice de documentos los marca como fuente no resuelta (`source_missing`, 6 campos). Conviene revisar que esa cita siga resolviendo.
- Qué se habló en el comité fuera del acta.

**Vuelvo el 2026-11-14.**
