# Tablero de métricas · Despacho de flota

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-10

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 214.850 | 2026-10-10 |
