# Caso de negocio · Alerta de fatiga

**Código:** PRD-305
**Fecha:** 2025-11-01
**Preparado por:** Javier Hoyos

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 176.319 | Caso de negocio, 2025-11-01 |

## Retorno esperado

Retorno esperado en 24 meses.
