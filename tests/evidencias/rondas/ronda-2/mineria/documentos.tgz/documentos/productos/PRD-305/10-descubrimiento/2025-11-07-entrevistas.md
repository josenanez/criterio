# Entrevistas · Alerta de fatiga

**Ronda:** Ronda · 2025-11-07
**Realizadas por:** Javier Hoyos

### Cliente entrevistado · 2025-11-07

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
