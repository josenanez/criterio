# Caso de negocio · Permisos de trabajo digitales

**Código:** PRD-308
**Fecha:** 2026-01-05
**Preparado por:** Natalia Ospina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 250.086 | Caso de negocio, 2026-01-05 |

## Retorno esperado

Retorno esperado en 24 meses.
