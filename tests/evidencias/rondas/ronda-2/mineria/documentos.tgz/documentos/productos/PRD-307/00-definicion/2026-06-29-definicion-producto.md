# Definición de producto · Reporte ambiental

**Código:** PRD-307
**Gerente de producto:** Javier Hoyos
**Segmento:** Supervisores
**Fecha de la definición:** 2026-06-29

## El problema

El segmento Supervisores no tiene reporte ambiental.

## La propuesta

- Propuesta principal

## Supuestos

- **Operaciones adopta la herramienta** · declarado el 2026-06-19 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
