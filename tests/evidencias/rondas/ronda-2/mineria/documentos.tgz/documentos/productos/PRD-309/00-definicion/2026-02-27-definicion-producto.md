# Definición de producto · Inspección con drones

**Código:** PRD-309
**Gerente de producto:** Diana Molina
**Segmento:** Operadores
**Fecha de la definición:** 2026-02-27

## El problema

El segmento Operadores no tiene inspección con drones.

## La propuesta

- Propuesta principal

## Supuestos

- **El ahorro se sostiene sin inversión adicional** · declarado el 2026-07-25 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
