# Caso de negocio · Inspección con drones

**Código:** PRD-309
**Fecha:** 2026-02-27
**Preparado por:** Diana Molina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 167.550 | Caso de negocio, 2026-02-27 |

## Retorno esperado

Retorno esperado en 24 meses.
