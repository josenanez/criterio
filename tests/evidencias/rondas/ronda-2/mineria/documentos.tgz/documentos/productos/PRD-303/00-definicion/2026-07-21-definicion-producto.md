# Definición de producto · Gemelo digital

**Código:** PRD-303
**Gerente de producto:** Sandra Gil
**Segmento:** Supervisores
**Fecha de la definición:** 2026-07-21

## El problema

El segmento Supervisores no tiene gemelo digital.

## La propuesta

- Propuesta principal

## Supuestos

- **El ahorro se sostiene sin inversión adicional** · declarado el 2026-04-03 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
