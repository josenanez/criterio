# Tablero de métricas · Almacén de repuestos

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-13

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 189.134 | 2026-10-13 |
