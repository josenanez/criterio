# Definición de producto · Trazabilidad

**Código:** PRD-304
**Gerente de producto:** Carlos Peña
**Segmento:** Supervisores
**Fecha de la definición:** 2026-02-20

## El problema

El segmento Supervisores no tiene trazabilidad.

## La propuesta

- Propuesta principal

## Supuestos

- **La licencia ambiental lo permite** · declarado el 2026-05-13 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
