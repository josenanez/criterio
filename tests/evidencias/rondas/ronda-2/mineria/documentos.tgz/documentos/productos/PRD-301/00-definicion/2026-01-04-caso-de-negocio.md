# Caso de negocio · Alerta de taludes

**Código:** PRD-301
**Fecha:** 2026-01-04
**Preparado por:** Camilo Beltrán

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 191.184 | Caso de negocio, 2026-01-04 |

## Retorno esperado

Retorno esperado en 24 meses.
