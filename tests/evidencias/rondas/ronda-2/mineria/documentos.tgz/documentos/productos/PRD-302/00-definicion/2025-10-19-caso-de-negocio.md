# Caso de negocio · Despacho de flota

**Código:** PRD-302
**Fecha:** 2025-10-19
**Preparado por:** Ricardo Salas

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 252.848 | Caso de negocio, 2025-10-19 |

## Retorno esperado

Retorno esperado en 24 meses.
