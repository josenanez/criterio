# Tablero de métricas · Monitoreo de flota

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-09-28

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 102.629 | 2026-09-28 |
