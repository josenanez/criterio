# Caso de negocio · Reporte ambiental

**Código:** PRD-307
**Fecha:** 2026-06-29
**Preparado por:** Javier Hoyos

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 68.054 | Caso de negocio, 2026-06-29 |

## Retorno esperado

Retorno esperado en 24 meses.
