# Comité Ambiental · Mantenimiento predictivo de camiones

**Fecha:** 2026-10-12
**Asistentes:** Carlos Peña, Andrés Lozano

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Gustavo Neira | Entregar el punto 23 | 2026-10-27 |
| Laura Vélez | Entregar el punto 10 | 2026-10-28 |
