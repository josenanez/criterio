# Solicitud de cambio CC-01

**Proyecto:** PRY-208 · Trazabilidad del mineral
**Fecha:** 2026-10-11
**Solicitante:** Gustavo Neira

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +113 días sobre la línea base vigente |
| Costo | 226.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
