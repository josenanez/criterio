# Informe de avance · Ampliación de la relavera

**Código:** PRY-201
**Fecha de corte:** 2026-10-13
**Gerente:** Natalia Ospina

## Estado declarado

**Verde**

Avance reportado: **41%**

## Lo que pasó en el periodo

- Se reprogramó la parada de planta por la ventana de mantenimiento
- Se recibió el permiso ambiental pendiente desde el trimestre anterior
- Las lluvias detuvieron el montaje durante diez días

## Presupuesto

| | COP |
|---|---|
| Aprobado | 800.000.000 |
| Comprometido | 476.899.312 |
| Ejecutado | 358.392.016 |
| Proyección al cierre | 839.626.771 |

## Riesgos abiertos

- Cambio en la licencia ambiental que puede mover el alcance
- El proveedor no ha confirmado la fecha de la última entrega
