# Acta de constitución · Red privada LTE en mina

**Código:** PRY-206
**Área dueña:** Mina
**Patrocinador:** Mauricio Pérez
**Gerente de proyecto:** Liliana Torres
**Comité:** Comité Ambiental
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-07-19

## Objetivo del negocio

Entregar red privada lte en mina para Mina.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**4.200.000.000 COP**, aprobado por Comité Ambiental el 2025-07-19.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-07-29 |
| Cierre | 2026-09-22 |

## Criterio de éxito

Red privada LTE en mina en producción y medido.

## Dependencias declaradas

- Ninguna declarada
