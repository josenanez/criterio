# Informe de avance · Planta de tratamiento de agua

**Código:** PRY-202
**Fecha de corte:** 2026-10-13
**Gerente:** Ricardo Salas

## Estado declarado

**Rojo**

Avance reportado: **48%**

## Lo que pasó en el periodo

- Se reprogramó la parada de planta por la ventana de mantenimiento

## Presupuesto

| | COP |
|---|---|
| Aprobado | 1.200.000.000 |
| Comprometido | 586.654.716 |
| Ejecutado | 539.615.164 |
| Proyección al cierre | 1.176.212.499 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
