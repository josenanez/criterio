# Acta de constitución · Planta de tratamiento de agua

**Código:** PRY-202
**Área dueña:** Medio Ambiente
**Patrocinador:** Liliana Torres
**Gerente de proyecto:** Ricardo Salas
**Comité:** Comité de Seguridad
**Producto asociado:** No aplica
**Fecha de aprobación:** 2026-06-21

## Objetivo del negocio

Entregar planta de tratamiento de agua para Medio Ambiente.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**1.200.000.000 COP**, aprobado por Comité de Seguridad el 2026-06-21.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-07-01 |
| Cierre | 2028-02-05 |

## Criterio de éxito

Planta de tratamiento de agua en producción y medido.

## Dependencias declaradas

- Ninguna declarada
