# Acta de constitución · Trazabilidad del mineral

**Código:** PRY-208
**Área dueña:** Mina
**Patrocinador:** Natalia Ospina
**Gerente de proyecto:** Gustavo Neira
**Comité:** Comité Ambiental
**Producto asociado:** trazabilidad
**Fecha de aprobación:** 2025-08-20

## Objetivo del negocio

Entregar trazabilidad del mineral para Mina.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**800.000.000 COP**, aprobado por Comité Ambiental el 2025-08-20.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-08-30 |
| Cierre | 2026-12-10 |

## Criterio de éxito

Trazabilidad del mineral en producción y medido.

## Dependencias declaradas

- Ninguna declarada
