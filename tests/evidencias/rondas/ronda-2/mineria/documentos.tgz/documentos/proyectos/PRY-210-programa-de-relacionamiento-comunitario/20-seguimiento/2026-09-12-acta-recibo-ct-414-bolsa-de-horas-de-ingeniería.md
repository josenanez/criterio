# Acta de recibo · Bolsa de horas de ingeniería

**Proyecto:** PRY-210 · Programa de relacionamiento comunitario
**Fecha de recibo:** 2026-09-12
**Recibido por:** Javier Hoyos

Se recibe a satisfacción el entregable **Bolsa de horas de ingeniería**.

Contrato CT-414 · Ingeniería Minera del Sur S.A.S..
