# Comité de Inversiones · Programa de relacionamiento comunitario

**Fecha:** 2026-10-09
**Asistentes:** Javier Hoyos, Natalia Ospina

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Felipe Arango | Entregar el punto 26 | 2026-11-03 |
