# Comité Ambiental · Trazabilidad del mineral

**Fecha:** 2026-10-12
**Asistentes:** Gustavo Neira, Natalia Ospina

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| María Restrepo | Entregar el punto 17 | 2026-10-17 |
