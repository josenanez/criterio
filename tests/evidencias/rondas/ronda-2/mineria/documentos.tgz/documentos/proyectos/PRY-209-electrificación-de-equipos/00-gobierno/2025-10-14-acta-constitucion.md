# Acta de constitución · Electrificación de equipos

**Código:** PRY-209
**Área dueña:** Medio Ambiente
**Patrocinador:** Laura Vélez
**Gerente de proyecto:** Sandra Gil
**Comité:** Comité de Inversiones
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-10-14

## Objetivo del negocio

Entregar electrificación de equipos para Medio Ambiente.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**9.500.000.000 COP**, aprobado por Comité de Inversiones el 2025-10-14.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-10-24 |
| Cierre | 2027-05-06 |

## Criterio de éxito

Electrificación de equipos en producción y medido.

## Dependencias declaradas

- Ninguna declarada
