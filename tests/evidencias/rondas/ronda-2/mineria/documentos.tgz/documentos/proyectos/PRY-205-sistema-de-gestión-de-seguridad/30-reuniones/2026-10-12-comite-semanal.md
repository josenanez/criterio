# Comité de Operaciones · Sistema de gestión de seguridad

**Fecha:** 2026-10-12
**Asistentes:** Rubén Cárdenas, María Restrepo

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Mauricio Pérez | Entregar el punto 4 | 2026-10-12 |
