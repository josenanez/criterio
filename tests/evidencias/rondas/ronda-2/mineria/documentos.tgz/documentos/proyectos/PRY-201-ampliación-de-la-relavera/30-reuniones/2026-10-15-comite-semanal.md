# Comité de Operaciones · Ampliación de la relavera

**Fecha:** 2026-10-15
**Asistentes:** Natalia Ospina, Laura Vélez

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Liliana Torres | Entregar el punto 15 | 2026-10-03 |
| Javier Hoyos | Entregar el punto 28 | 2026-11-08 |
