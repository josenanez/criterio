# Comité de Seguridad · Planta de tratamiento de agua

**Fecha:** 2026-10-12
**Asistentes:** Ricardo Salas, Liliana Torres

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| María Restrepo | Entregar el punto 15 | 2026-10-01 |
