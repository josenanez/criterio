# Acta de constitución · Control de polvo en vías

**Código:** PRY-211
**Área dueña:** Logística
**Patrocinador:** Diana Molina
**Gerente de proyecto:** Rubén Cárdenas
**Comité:** Comité Ambiental
**Producto asociado:** No aplica
**Fecha de aprobación:** 2026-03-09

## Objetivo del negocio

Entregar control de polvo en vías para Logística.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**2.400.000.000 COP**, aprobado por Comité Ambiental el 2026-03-09.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-03-19 |
| Cierre | 2027-09-10 |

## Criterio de éxito

Control de polvo en vías en producción y medido.

## Dependencias declaradas

- Ninguna declarada
