# Informe de avance · Programa de relacionamiento comunitario

**Código:** PRY-210
**Fecha de corte:** 2026-10-10
**Gerente:** Javier Hoyos

## Estado declarado

**Verde**

Avance reportado: **56%**

## Lo que pasó en el periodo

- El proveedor entregó los equipos en el campamento, pendientes de aceptación
- Se levantó un hallazgo en la auditoría de seguridad

## Presupuesto

| | COP |
|---|---|
| Aprobado | 9.500.000.000 |
| Comprometido | 3.772.287.163 |
| Ejecutado | 2.782.173.991 |
| Proyección al cierre | 9.573.898.546 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
- Cambio en la licencia ambiental que puede mover el alcance
