# Acta de constitución · Gemelo digital de la planta

**Código:** PRY-207
**Área dueña:** Mantenimiento
**Patrocinador:** Diana Molina
**Gerente de proyecto:** Felipe Arango
**Comité:** Comité de Operaciones
**Producto asociado:** gemelo digital
**Fecha de aprobación:** 2026-05-24

## Objetivo del negocio

Entregar gemelo digital de la planta para Mantenimiento.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**1.200.000.000 COP**, aprobado por Comité de Operaciones el 2026-05-24.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-06-03 |
| Cierre | 2027-05-28 |

## Criterio de éxito

Gemelo digital de la planta en producción y medido.

## Dependencias declaradas

- Ninguna declarada
