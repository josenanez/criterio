# Informe de avance · Monitoreo de taludes

**Código:** PRY-204
**Fecha de corte:** 2026-10-14
**Gerente:** Jorge Medina

## Estado declarado

**Verde**

Avance reportado: **30%**

## Lo que pasó en el periodo

- El proveedor entregó los equipos en el campamento, pendientes de aceptación

## Presupuesto

| | COP |
|---|---|
| Aprobado | 2.400.000.000 |
| Comprometido | 1.747.958.077 |
| Ejecutado | 493.764.835 |
| Proyección al cierre | 2.505.660.114 |

## Riesgos abiertos

- Bloqueo de la vía de acceso a la mina
