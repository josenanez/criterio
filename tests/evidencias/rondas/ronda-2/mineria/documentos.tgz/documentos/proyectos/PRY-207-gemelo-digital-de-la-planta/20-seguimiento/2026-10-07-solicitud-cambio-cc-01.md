# Solicitud de cambio CC-01

**Proyecto:** PRY-207 · Gemelo digital de la planta
**Fecha:** 2026-10-07
**Solicitante:** Felipe Arango

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +106 días sobre la línea base vigente |
| Costo | 212.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
