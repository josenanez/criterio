# Informe de avance · Sistema de gestión de seguridad

**Código:** PRY-205
**Fecha de corte:** 2026-10-11
**Gerente:** Rubén Cárdenas

## Estado declarado

**Verde**

Avance reportado: **26%**

## Lo que pasó en el periodo

- Se reprogramó la parada de planta por la ventana de mantenimiento

## Presupuesto

| | COP |
|---|---|
| Aprobado | 9.500.000.000 |
| Comprometido | 6.239.682.167 |
| Ejecutado | 5.491.598.094 |
| Proyección al cierre | 9.244.059.945 |

## Riesgos abiertos

- Bloqueo de la vía de acceso a la mina
- Ventana de parada de planta definida por operaciones
