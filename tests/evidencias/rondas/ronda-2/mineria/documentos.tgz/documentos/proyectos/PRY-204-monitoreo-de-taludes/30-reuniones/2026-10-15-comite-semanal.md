# Comité de Tecnología · Monitoreo de taludes

**Fecha:** 2026-10-15
**Asistentes:** Jorge Medina, Ricardo Salas

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Felipe Arango | Entregar el punto 10 | 2026-10-15 |
| Óscar Ramírez | Entregar el punto 40 | 2026-10-14 |
