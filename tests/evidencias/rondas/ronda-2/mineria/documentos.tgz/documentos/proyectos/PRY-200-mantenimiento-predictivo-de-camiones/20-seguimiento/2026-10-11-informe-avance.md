# Informe de avance · Mantenimiento predictivo de camiones

**Código:** PRY-200
**Fecha de corte:** 2026-10-11
**Gerente:** Carlos Peña

## Estado declarado

**Rojo**

Avance reportado: **65%**

## Lo que pasó en el periodo

- Se reprogramó la parada de planta por la ventana de mantenimiento

## Presupuesto

| | COP |
|---|---|
| Aprobado | 800.000.000 |
| Comprometido | 462.114.005 |
| Ejecutado | 462.496.289 |
| Proyección al cierre | 787.391.756 |

## Riesgos abiertos

- Ventana de parada de planta definida por operaciones
- El proveedor no ha confirmado la fecha de la última entrega
