# Informe de avance · Trazabilidad del mineral

**Código:** PRY-208
**Fecha de corte:** 2026-10-13
**Gerente:** Gustavo Neira

## Estado declarado

**Verde**

Avance reportado: **68%**

## Lo que pasó en el periodo

- El equipo perdió dos semanas por rotación de un ingeniero clave
- Se reprogramó la parada de planta por la ventana de mantenimiento
- El proveedor entregó los equipos en el campamento, pendientes de aceptación

## Presupuesto

| | COP |
|---|---|
| Aprobado | 800.000.000 |
| Comprometido | 256.136.235 |
| Ejecutado | 454.535.191 |
| Proyección al cierre | 791.485.060 |

## Riesgos abiertos

- Cambio en la licencia ambiental que puede mover el alcance
