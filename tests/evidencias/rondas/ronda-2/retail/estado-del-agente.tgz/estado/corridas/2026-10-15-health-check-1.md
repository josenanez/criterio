# Corrida del 2026-10-15 · health-check

13 proyectos · 68 s · 60 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 29 |
| `progress_vs_plan` | 9 |
| `declared_vs_evidence` | 5 |
| `commitment_overdue` | 4 |
| `variance_time` | 3 |
| `variance_cost` | 2 |
| `commitment_undated` | 2 |
| `vendor_deliverable_late` | 2 |
| `rebaseline_unauthorized` | 2 |
| `change_without_baseline` | 1 |
| `vendor_accepted_without_evidence` | 1 |

Diagnóstico PRY-208 sobre 6 documentos: 3 sostenidas, 10 sin sustento, 2 contradichas. Dijo que no sabe: autoridad del gerente, motivo y aprobación de la línea base v2, si los 3 hitos cerrados lo están (sin actas de recibo), soporte del dinero y qué es el punto 21.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## Diagnóstico · PRY-208 · Domicilios en dos horas · 2026-10-15

**Leí:** 6 documentos de la carpeta del proyecto · 2025-07-30 a 2026-10-07 · formatos: docx (1), csv (2), pdf (1), md (2). Además busqué el proyecto y a su gente en las minutas de los otros proyectos y en `documentos/productos`: ninguna menciona PRY-208 (hay homónimos —Beatriz Cuéllar, Carlos Peña— con compromisos en PRY-199, PRY-204, PRY-205, PRY-211, que no son de este proyecto).
**No pude leer:** nada quedó sin leer. El PDF del informe de avance no tiene capa de texto reutilizable en el índice (`text_hash` nulo); lo leí a la vista y los números coinciden con la ficha.

Términos: vigentes (versión 0.3.8, aceptados por José Francisco Ñáñez el 2026-10-15); no hizo falta registrar de nuevo.

### Dictamen
**Sostenido:** 3 afirmaciones · **Sin sustento:** 10 · **Contradicho:** 2

Desde esta carpeta se puede afirmar quién gobierna el proyecto, cuánto se aprobó y que quien reporta lo declara en rojo. No se puede afirmar nada de lo que el informe dice haber ocurrido: no hay un solo documento de evidencia (0 de 19 datos con fuente de evidencia; 5 son declaración del propio gerente y 14 no están marcados). El rojo declarado es coherente con las señales que calculé, pero el 73 % y las fechas vigentes no lo son.

### Gobierno
| | Qué dice el documento | Fuente |
|---|---|---|
| Patrocinador | Ricardo Salas | acta de constitución 2025-07-30 |
| Gerente | Beatriz Cuéllar | acta de constitución 2025-07-30 |
| Autoridad declarada | **No declarada.** El acta no dice qué puede aprobar el gerente | acta de constitución 2025-07-30 |
| Comité | Comité de Cadena de Abastecimiento (el área dueña es Mercadeo) | acta de constitución 2025-07-30; minuta 2026-10-06 |

Consecuencia: sin autoridad declarada no hay desviación aprobada, solo fechas que alguien escribió. Además el acta tiene alcance sin contenido («Componente 1, 2, 3»), exclusión genérica y «Ninguna» dependencia declarada.

### Contra el plan
- **Línea base original (v1, 2025-07-30):** último hito 2026-08-19 (Integración con el ERP). Motivo: aprobación del acta.
- **Vigente (v2, 2026-10-04):** el mismo hito pasa a 2026-09-29. Desviación: **41 días, 10,9 %** contra la original (umbral 10 %); 0 días contra la vigente. **Motivo de la replanificación: no está en ningún documento.**
- **Autorizados: 0 días de 41.** La única solicitud de cambio (CC-01, 2026-10-07) pide «+41 días sobre la línea base vigente» y dice «Pendiente de presentación al comité». La v2 es del 2026-10-04, tres días antes de la solicitud.
- El acta fija cierre 2026-10-21; el cronograma no tiene hito de piloto, producción ni medición, que es el criterio de éxito del acta («Domicilios en dos horas en producción y medido»).

### Hitos vencidos sin evidencia
Los tres figuran «cerrado» en el cronograma y ninguno tiene acta de recibo en la carpeta.

| Hito | Fecha | Días | Qué documento se esperaría |
|---|---|---|---|
| Diseño de la experiencia aprobado | 2025-12-12 | 307 | Acta de recibo / aprobación del diseño |
| Ambiente de pruebas certificado | 2026-04-16 | 182 | Acta de recibo / certificado del ambiente |
| Integración con el ERP | 2026-09-29 | 16 | Acta de recibo de la integración |

### Dinero
Cifras de la ficha (`compute`), todas en COP. Aprobado viene del acta; el resto, solo del informe de avance (declaración).

| Aprobado | Comprometido | Ejecutado | Proyección | Disponible real |
|---|---|---|---|---|
| 6.800.000.000 | 5.324.115.797 (78,3 %) | 1.549.029.646 (22,8 %) | 6.501.902.672 (−4,4 % vs. aprobado) | 1.475.884.203 |

Ningún umbral de costo se cruza (comprometido 78,3 % < 90 %). CC-01 pide 82.000.000 COP adicionales sin decisión; no calculo cómo queda la proyección con ellos porque el script no lo da y no sé si la proyección ya los incluye. No hay libro de gastos, facturas ni contratos que respalden comprometido, ejecutado o proyección.

### Lo que se dijo y nadie registró
- **Compromiso vencido:** Carlos Peña, «Entregar el punto 21», para 2026-10-08, dicho en la minuta del 2026-10-06; 7 días vencido, sin evidencia de entrega. Carlos Peña no figura entre los asistentes de esa minuta (Beatriz Cuéllar y Ricardo Salas), y «punto 21» no se explica en ningún documento.
- **Riesgos sin dueño, probabilidad, impacto ni fecha:** disponibilidad de los jefes de tienda para el piloto; congelamiento de cambios en temporada alta. No hay registro RAID.
- **Incidencia sin dueño:** la prueba de carga de temporada no alcanzó el umbral y se repite (desde 2026-10-04). Sin informe de la prueba ni fecha de repetición.
- La minuta del 2026-10-06 lista «Avance» y «Compromisos» como temas, sin contenido: no registra ninguna decisión.
- Silencio: 8 días desde el último documento del proyecto (umbral 15); no es silencio del proyecto, pero sí hay un único autor de lo que se sabe: quien está siendo evaluada.

### Contradicho
| Afirmación | Documento A | Documento B |
|---|---|---|
| Avance 73 % | Informe 2026-10-04: «Avance reportado: 73 %» | Cronograma v2: 3 de 3 hitos cumplidos (el plan sostendría 100 %; brecha 27 puntos). Ojo: el cronograma solo tiene 3 hitos y omite piloto y producción, así que el defecto puede estar en el plan y no en el 73 % |
| La línea base vigente es la v2 (fin 2026-09-29) | Cronograma v2 2026-10-04 | CC-01 2026-10-07: +41 días «pendiente de presentación al comité», es decir, sin autorizar. Tampoco queda claro si los +41 de CC-01 son los mismos que ya movió la v2 o se suman a ellos |

### Sin sustento
1. Comprometido 5.324.115.797 COP.
2. Ejecutado 1.549.029.646 COP.
3. Proyección al cierre 6.501.902.672 COP.
4. Diseño de la experiencia aprobado, cerrado (sin acta de recibo).
5. Ambiente de pruebas certificado, cerrado (sin acta de recibo).
6. Integración con el ERP, cerrada el 2026-09-29 (sin acta de recibo).
7. La prueba de carga de temporada falló y se repite.
8. Se recibió el concepto de Jurídica sobre los términos de uso.
9. Los dos riesgos abiertos del informe.
10. Que el «punto 21» se entregó (o no) el 2026-10-08.

### Lo que esta carpeta no permite saber
- **Si los hitos cerrados lo están de verdad:** sin actas de recibo, el 100 % del plan descansa en la palabra de quien reporta.
- **Por qué se movió la línea base y quién lo autorizó:** sin motivo ni decisión, no se puede decir si 41 días son un atraso real, un cambio de alcance o ambos.
- **Qué faltaba por hacer al 73 %:** el cronograma no tiene hitos posteriores a la integración con el ERP.
- **Cuánto se gastó realmente:** sin soporte contable, la ejecución es una cifra declarada.
- **Qué puede decidir la gerente:** sin autoridad declarada en el acta, no se sabe si CC-01 (82.000.000 COP, +41 días) cabe en su facultad o exige comité.
- **Qué es el «punto 21» y quién lo espera.**

### Siguiente paso
Esto no recomienda detener, continuar ni reestructurar: es decisión de quien tiene la facultad. Ofrezco dos cosas: (a) preparar el punto de comité con la lista de lo que falta (actas de recibo, motivo y aprobación de la v2, decisión sobre CC-01, informe de la prueba de carga); (b) llevar las dos contradicciones a la gerente como preguntas, una por una.

---
**Pie de rigor:** cifras derivadas copiadas de `portafolio.py compute` (as_of 2026-10-15). Todo dato citado sale de los 6 documentos listados; lo no leído en ellos se declara arriba como ausente. Los dictámenes son del agente sobre documentos, no sobre lo hablado fuera de ellos; la verificación es de quien decide.
