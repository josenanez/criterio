*Sale de la ficha `estado/records/PRY-202.json` (corte del informe de avance: 2026-10-13). Términos vigentes: v1.1, aceptados por José Francisco Ñáñez el 2026-10-15.*

## Solicitud de cambio — PRY-202 Centro de distribución norte — 2026-10-15

**Qué se pide:** mover la salida a producción 30 días. Tomo "salida a producción" como el hito *Despliegue en la cadena* (2027-05-01 → 2027-05-31), que es también el cierre del cronograma y el criterio de éxito del acta («en producción y medido»). Es una lectura mía; no hay otro documento que defina el término.
**Quién lo pide:** no consta en los documentos. Se pidió por esta invocación; no hay solicitud escrita ni firmante.
**Por qué:** no se dio motivo. Sin motivo no se puede registrar como línea base.

### Hallazgo previo: dos fechas de cierre distintas
- El **acta de constitución** (2026-03-19) fija el cierre en **2027-06-10**.
- El **cronograma v1** (misma fecha) y la ficha dicen **2027-05-01**.

Hay 40 días de diferencia entre dos documentos del mismo día, y nadie los reconcilió. Contra el cronograma el cambio es de +30 días. Contra el acta, la fecha nueva (2027-05-31) seguiría 10 días antes de lo comprometido. Antes de aprobar hay que decidir cuál es la línea base.

### Impacto
| Dimensión | Hoy | Con el cambio | Diferencia |
|---|---|---|---|
| Alcance | Componentes 1, 2 y 3 (sin detalle en el acta) | Sin cambio declarado | No declarada |
| Tiempo | Despliegue 2027-05-01 (cronograma) / cierre 2027-06-10 (acta) | Despliegue 2027-05-31 | +30 días contra el cronograma |
| Costo | Aprobado 1.200.000.000 COP; proyección declarada 1.176.472.667 COP | No declarado | No declarada |

**Quién absorbe lo que no se declaró.** Mover 30 días sin tocar alcance ni costo significa que alguien lo absorbe en calidad o en horas no pagadas: un mes más de equipo y de gerencia, con un margen de presupuesto de 23.527.333 COP (≈2 % del aprobado). Ese margen es lo único que lo cubre hoy. El informe de avance, además, habla de «concentración del conocimiento en una sola persona» como riesgo abierto, y 30 días más sobre esa persona agravan el riesgo.

**Contrato CT-599 (Logística del Valle Ltda.):** el contrato solo lista tres fechas de entregable (2026-07-16, 2026-11-03, 2027-02-20) y no trae fecha de vencimiento. No se puede decir si el cambio lo alcanza. Hay que confirmarlo con el proveedor.

### Efecto en el portafolio
| Proyecto afectado | Cómo | Gerente |
|---|---|---|
| Ninguno detectado | El cálculo (`impact`) no encontró proyectos alcanzados, directa ni indirectamente | — |

Esto **no prueba que no haya efecto**: el acta dice «Ninguna declarada» en dependencias y la ficha no tiene ninguna. Un resultado vacío aquí es ausencia de declaración, no ausencia de dependencia. Un centro de distribución norte difícilmente no toca a otros proyectos de Logística o de tienda. Pregunta abierta para el gerente.

Hitos por los que pasa el cambio, que no se pueden decir cuántos días se mueven (falta holgura por actividad):
- Integración con el ERP (2026-11-22), a 38 días.
- Piloto en tiendas (2027-02-10), a 118 días.
- Despliegue en la cadena (2027-05-01), a 198 días.

Sin proyectos que no puedan sostener su fecha (`cannot_hold_date` = 0) y sin dependencias sin confirmar (0), por la razón de arriba.

### Quién decide
**Autoridad requerida:** no se puede determinar. El acta no declara umbrales de autoridad para cambios (el campo `authority` quedó sin encontrar).
**Según:** acta de constitución, que solo nombra al Comité de Cadena de Abastecimiento como quien aprobó el presupuesto.
**Va a comité:** sí, por defecto. Quien aprobó el presupuesto y el cierre es el comité, y mover la fecha de cierre es una decisión de ese nivel. Siguiente reunión semanal: 2026-10-22. Que no haya autoridad declarada es el hallazgo de fondo.

### Si no se aprueba
El proyecto sigue con el despliegue el 2027-05-01 (cronograma). Está en verde con 38 % de avance, pero el informe no dice si el avance contra el plan sustenta ese verde. Tampoco explica por qué se pide mover 30 días si está en verde. El motivo del pedido contradice el estado declarado, y hay que pedirlo.

### Si se aprueba
Línea base **2** — despliegue 2027-05-31 · presupuesto 1.200.000.000 COP (sin cambio, a menos que el solicitante declare otro) · motivo: **pendiente, no consta**.
Desviación acumulada contra la línea base original (v1, 2027-05-01): **+30 días** · **0 COP** declarados.
Registradas hoy: 1 línea base, 0 cambios aprobados, 0 replanificaciones. Esta sería la primera. No se crea la línea base 2 hasta que haya aprobación y documento que la sostenga.

### Lo que no sé
- Qué fecha es la vigente (acta o cronograma).
- Si «salida a producción» es el despliegue o el cierre.
- Por qué se pide, quién lo pide y si cambia el costo.
- Cuántos días se mueve cada hito intermedio, y si el contrato CT-599 y otros proyectos se ven afectados.

### Después
Hay que llevarlo al comité del 2026-10-22 con tres cosas pendientes: el motivo, la reconciliación de las dos fechas y las dependencias. No registro línea base nueva: no hay aprobación.

*Rigor: cifras de plazo y dinero salen de la ficha PRY-202 (acta, cronograma v1, informe del 2026-10-13); los 30 días de impacto salen del script `impact`. No se calculó ningún corrimiento por hito.*
