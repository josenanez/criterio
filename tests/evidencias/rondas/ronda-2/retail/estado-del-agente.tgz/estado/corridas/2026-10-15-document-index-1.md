# Corrida del 2026-10-15 · document-index

13 proyectos · 13 s · 60 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 29 |
| `progress_vs_plan` | 9 |
| `declared_vs_evidence` | 5 |
| `commitment_overdue` | 4 |
| `variance_time` | 3 |
| `variance_cost` | 2 |
| `commitment_undated` | 2 |
| `vendor_deliverable_late` | 2 |
| `rebaseline_unauthorized` | 2 |
| `change_without_baseline` | 1 |
| `vendor_accepted_without_evidence` | 1 |

74 documentos sin cambio, nada que releer; 4 citas de PRY-205 no resuelven aunque el acta existe bajo la carpeta del proyecto. No se corrigió la ficha.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## Carpeta al 2026-10-15

**Documentos:** 74 · **Sin cambio:** 74 · **Hay que releer:** 0

### Cambió el contenido
Ninguno.

### Solo se reguardó
Ninguno.

### Renombrado o movido
Ninguno.

### Ya no está
Ninguno.

### Citas que dejaron de resolver
| Proyecto | Campo | Documento citado |
|---|---|---|
| PRY-205 | pm_record.identity.code | 00-gobierno/2025-08-16-acta-constitucion.docx |
| PRY-205 | pm_record.identity.name | 00-gobierno/2025-08-16-acta-constitucion.docx |
| PRY-205 | pm_record.identity.manager | 00-gobierno/2025-08-16-acta-constitucion.docx |
| PRY-205 | pm_record.identity.sponsor | 00-gobierno/2025-08-16-acta-constitucion.docx |

Nota: el archivo sí existe en disco, en `PRY-205-pago-con-qr-en-caja/00-gobierno/2025-08-16-acta-constitucion.docx`; la cita está escrita sin la carpeta del proyecto y por eso no resuelve. No hay renombrado detectado; no se ha corregido la ficha.

### Formatos que no se pudieron leer
Ninguno (este comando no lee documentos, solo los cuenta).
