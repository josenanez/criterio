# Rostrum — modo «para mirarlo un rato»

Términos: vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-15). No hizo falta volver a registrarlos.

Elegiste «rato», así que no hay nada que pedirle a seguridad. Lo levantas, lo miras y lo apagas. El informe ya existe en `reportes/` y el servidor solo lo sirve.

Comando:

    python3 "/home/claude/banco/criterio/plugins/criterio-portfolio/scripts/servidor.py" --informe reportes --estado estado --config .criterio/portafolio/config.json

Escucha en `127.0.0.1:8787`, solo en este equipo. Se para con Ctrl-C. Si el puerto está ocupado, añade `--puerto 8788`.

| Ruta | Qué es | Para quién |
|---|---|---|
| `/` | Portada con las tres secciones y el formulario de peticiones | Todos |
| `/pmo` | Cómo va el portafolio: verdes sin sustento, silencios, patrocinadores repetidos | La PMO |
| `/decisiones` | Lo que necesita decisión, con la consecuencia de no decidir | Comité y patrocinador |
| `/proyectos` | Listado ordenado por lo que más pide atención | Todos |
| `/p/<código>` | Informe del proyecto, con enlace a su producto | Quien gerencia |
| `/productos` | Listado de productos y proyectos sin producto declarado | Dueños de producto |
| `/producto/<nombre>` | Informe del producto, con enlace a sus proyectos | Dueños de producto |
| `/estado.json` | Fecha del informe y peticiones abiertas | Un mecanismo |

Lo que no hace:
- No calcula. Sirve lo que `informe.py` ya escribió, así que dos personas ven lo mismo.
- No escribe fichas. Solo crea peticiones en `estado/peticiones/`.
- No autentica.
- No manda correos ni notificaciones.

Límite de este modo: el patrocinador no tendrá un enlace que funcione mañana. Cuando se quiera un enlace estable, se vuelve a correr con `--abierto` y se le piden a la organización un host, un puerto y el control de acceso que ya usan.

Cierre: este enlace es solo para ti, en este equipo (`http://127.0.0.1:8787/`). Al patrocinador no se le pasa nada todavía. La portada indica de cuándo es el informe; el informe queda desactualizado en cuanto cambie la documentación o corra otro barrido.
