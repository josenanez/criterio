## Carpeta al 2026-10-15

**Documentos:** 74 · **Sin cambio:** 74 · **Hay que releer:** 0

### Cambió el contenido
Ninguno.

### Solo se reguardó
Ninguno.

### Renombrado o movido
Ninguno.

### Ya no está
Ninguno.

### Citas que dejaron de resolver
| Proyecto | Campo | Documento citado |
|---|---|---|
| PRY-205 | pm_record.identity.code | 00-gobierno/2025-08-16-acta-constitucion.docx |
| PRY-205 | pm_record.identity.name | 00-gobierno/2025-08-16-acta-constitucion.docx |
| PRY-205 | pm_record.identity.manager | 00-gobierno/2025-08-16-acta-constitucion.docx |
| PRY-205 | pm_record.identity.sponsor | 00-gobierno/2025-08-16-acta-constitucion.docx |

Nota: el archivo sí existe en disco, en `PRY-205-pago-con-qr-en-caja/00-gobierno/2025-08-16-acta-constitucion.docx`; la cita está escrita sin la carpeta del proyecto y por eso no resuelve. No hay renombrado detectado; no se ha corregido la ficha.

### Formatos que no se pudieron leer
Ninguno (este comando no lee documentos, solo los cuenta).
