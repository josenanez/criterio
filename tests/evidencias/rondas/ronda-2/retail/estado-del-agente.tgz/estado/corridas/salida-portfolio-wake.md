## 2026-10-15

Términos vigentes (versión 0.3.8, aceptados por José Francisco Ñáñez el 2026-10-15); no se volvieron a pedir.

**Revisé:** 74 documentos · 0 cambiaron · 0 proyectos recalculados · 0 peticiones en el servidor

Tocaban el barrido diario y la confirmación periódica (las dos por primera vez: nunca se habían registrado). El informe de comité no toca todavía: el comité es el 2026-10-22 y el informe aterriza el 2026-10-20.

### Lo que cruzó un umbral
Nada nuevo desde el barrido de hoy: ningún documento cambió, así que no hay nada que recalcular. Un hallazgo del índice:

- **Citas que no resuelven en PRY-205** (`pm_record.identity.code`, `.name`, `.manager`, `.sponsor`): apuntan a `00-gobierno/2025-08-16-acta-constitucion.docx`, que **sí existe** en `documentos/proyectos/PRY-205-pago-con-qr-en-caja/00-gobierno/` y no cambió. El índice la busca bajo `PRY-205/` y no la encuentra; parece un desajuste del nombre de carpeta, no un documento faltante. No toqué la ficha ni la releí: lo dejo señalado para que alguien confirme.

### Peticiones atendidas
Ninguna.

### Preguntas
Cinco campos, elegidos por importancia (nadie responde en esta sesión; quedan preguntadas hoy, 2026-10-15). Sin respuesta en la próxima corrida se reportará «preguntada el 15, sin respuesta».

1. **PRY-205** — fin comprometido 2026-06-10 ya vencido con el proyecto activo y costo proyectado 8.542.694.050 contra 6.800.000.000 aprobados: ¿cuál es la fecha de cierre vigente y quién la autorizó? (fuente: acta de constitución y último informe, barrido de hoy)
2. **PRY-203** — fin comprometido 2026-06-09 vencido, y lo ejecutado (9.625.843.282) supera lo comprometido (5.942.678.419): ¿cuál de las dos cifras está mal? (fuente: informe de avance de PRY-203)
3. **PRY-209** — fin comprometido 2026-05-25 vencido y un compromiso de Jorge Medina «por definir»: ¿fecha vigente y fecha del compromiso?
4. **PRY-208** — línea base v2 publicada el 2026-10-04 sin motivo ni autorización, con CC-01 (+41 días, +82.000.000 COP) pendiente de comité: ¿quién autorizó la v2?
5. **Los 13 proyectos** — `identity.authority` está en `not_found` en todos: ¿quién define la autoridad del gerente y en qué documento?

Pregunta abierta, no se escribe en ninguna ficha: ningún agente escribe la declaración.

**Vuelvo el 2026-10-16.**
