# Corrida del 2026-10-15 · project-closure

13 proyectos · 43 s · 60 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 29 |
| `progress_vs_plan` | 9 |
| `declared_vs_evidence` | 5 |
| `commitment_overdue` | 4 |
| `variance_time` | 3 |
| `variance_cost` | 2 |
| `commitment_undated` | 2 |
| `vendor_deliverable_late` | 2 |
| `rebaseline_unauthorized` | 2 |
| `change_without_baseline` | 1 |
| `vendor_accepted_without_evidence` | 1 |

Cierre de PRY-203 no declarable por cumplimiento: criterio de éxito (en producción y medido) sin evidencia; 4 de 5 hitos cerrados sin recibo; 74% declarado contra 100% del plan; fechas de cierre del acta (2026-06-09) y del cronograma (2026-05-04) distintas; RAID abierto sin doliente; lecciones limitadas a hechos anclados; no se archivó.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

Cierre de PRY-203 · Reposición automática, con corte al 2026-10-15. Sale de la ficha `estado/records/PRY-203.json` y de estos documentos: acta de constitución (2025-05-09), cronograma v1 (2025-05-09), acta de recibo del ambiente de pruebas (2026-10-03) e informe de avance (2026-10-08). Las cifras derivadas salen de `portafolio.py compute`.

## Cierre — PRY-203 Reposición automática — 2026-10-15

**Resultado: el proyecto no se puede cerrar por cumplimiento.** La documentación no muestra que el criterio de éxito se haya cumplido. Si se cierra hoy, se cierra por decisión de alguien, y esa decisión tiene que quedar registrada.

### Contra lo comprometido
**Criterio de éxito:** "Reposición automática en producción y medido." (acta de constitución, 2025-05-09, sección Criterio de éxito.)
**Se cumplió:** no se puede determinar. Ningún documento muestra que esté en producción, y ninguno muestra una medición.

| Entregable comprometido | Estado | Evidencia |
|---|---|---|
| Componente 1, 2 y 3 (el acta no los detalla) | No se puede determinar | El acta no dice qué es cada componente. |
| Diseño de la experiencia aprobado (base 2025-07-28) | Declarado cerrado | Sin evidencia |
| Ambiente de pruebas certificado (base 2025-10-06) | Cerrado | Acta de recibo del 2026-10-03, firmada por Jorge Medina. Se recibió en una fecha posterior a la de línea base. |
| Integración con el ERP (base 2025-12-15) | Declarado cerrado | Sin evidencia. El informe del 2026-10-08 dice que el proveedor entregó el componente de integración y que está "pendiente de aceptación". Eso contradice el cierre del hito. |
| Piloto en tiendas (base 2026-02-23) | Declarado cerrado | Sin evidencia. El informe del 2026-10-08 dice que la validación con dos tiendas sigue en curso: "se extendió una semana". |
| Despliegue en la cadena (base 2026-05-04) | Declarado cerrado | Sin evidencia. El informe del 2026-10-08 dice que el proveedor no ha confirmado la fecha de la última entrega. |

Los cinco hitos del cronograma figuran como "cerrado". Solo uno tiene evidencia de recibo. Los otros cuatro (hitos vencidos hace 444, 304, 234 y 164 días) están declarados sin documento que los sustente.

**Señales que el informe del 2026-10-08 no explica:**
- El informe declara estado **verde** y avance **74%**. Con los cinco hitos cerrados, el plan respalda 100%. La diferencia es de **26.0 puntos**, y el informe no dice a qué se debe.
- Si el avance real es 74%, los hitos no están cerrados. Si lo están, el 74% no cuadra. Ninguna de las dos lecturas se puede confirmar con los documentos.

### Fuera de alcance final
| Qué quedó fuera | Decidido por | Cuándo |
|---|---|---|
| "Lo que otro proyecto cubre" (acta) | Acta de constitución, sin nombre de quién decidió | 2025-05-09 |

Sin dato: no hay registro de recortes de alcance ni solicitudes de cambio (0 cambios). El acta no nombra qué proyecto cubre lo excluido, así que no se puede verificar que otro proyecto lo cubra.

### Números finales
| | Original | Vigente | Final | Desviación vs original |
|---|---|---|---|---|
| Fecha (último hito del cronograma) | 2026-05-04 | 2026-05-04 | Sin dato: no hay entrega final | 0 días según el script. No es un dato confiable, porque los hitos "cerrados" no tienen evidencia. |
| Presupuesto aprobado | COP 18.000.000.000 | COP 18.000.000.000 | Ejecutado COP 9.625.843.282 (53.5%) | Proyección al cierre COP 17.211.297.614, un −4.4% frente al aprobado |

Replanificaciones: **0**.
Comprometido: COP 5.942.678.419 (33.0%). Disponible real: COP 12.057.321.581. Las cifras de dinero vienen del informe del 2026-10-08 (declaración del gerente), no de un documento contable.

**Inconsistencia de fechas:** el acta fija el cierre en **2026-06-09**, y el cronograma v1 termina en **2026-05-04**. No hay documento que explique la diferencia. Ninguna de las dos fechas se cumplió con evidencia.

### RAID al cierre
**Materializados:** ninguno se puede confirmar con los documentos.
**No materializados:** ninguno se puede confirmar.
**Abiertos, con doliente:** ninguno tiene doliente con nombre. Sin doliente no están cerrados.
- Riesgo: el proveedor no ha confirmado la fecha de la última entrega (informe 2026-10-08). Sin responsable, sin probabilidad, sin impacto, sin fecha.
- Incidencia: la validación con dos tiendas se extendió una semana por el conteo de inventario (desde 2026-10-08). Sin responsable.
- Pendiente: aceptación del componente de integración entregado por el proveedor (informe 2026-10-08). Sin responsable ni fecha.
- No hay ficha de proveedor ni contrato registrado, aunque el informe habla de un proveedor.

### Lecciones
No hay lecciones que se puedan sustentar, porque ninguna se puede anclar a un hecho con fecha y efecto en los documentos. Lo único anclado es esto:

| Qué pasó | Cuándo | Efecto | Qué haríamos distinto |
|---|---|---|---|
| El hito "Ambiente de pruebas certificado" estaba planeado para 2025-10-06 y el acta de recibo es del 2026-10-03. | 2025-10-06 / 2026-10-03 | El recibo quedó en una fecha posterior a la línea base, y el cronograma nunca se replanificó (0 replanificaciones). No hay documento que explique la causa. | Registrar la replanificación cuando un hito se corre, y exigir acta de recibo al cerrar cada hito. |
| Cuatro hitos se marcaron cerrados sin documento de recibo. | Desde 2025-07-28 | El estado verde y el 74% no se pueden contrastar con evidencia. | No aceptar "cerrado" en el cronograma sin acta de recibo vinculada. |

### Sin dato
- Si hay reposición automática en producción, y si se midió algo.
- Qué son los Componentes 1, 2 y 3.
- Quién decidió las exclusiones del alcance.
- La causa del desfase entre la fecha de cierre del acta (2026-06-09) y la del cronograma (2026-05-04).
- Evidencia de recibo de cuatro hitos.
- Doliente y fecha de cada riesgo, incidencia y pendiente abierto.
- Producto asociado ("No aplica" en el acta), autoridad y fase: la ficha los marca como no encontrados.
- Todos los campos de identidad y plan tienen 17 meses de antigüedad (acta del 2025-05-09). Confirmarlos con Jorge Medina o Diana Molina.

### Después
Mover la carpeta a `archivo/` y congelar la ficha: **no recomendado todavía**. Lo propuesto, sin que nadie responda en esta prueba, es dejar el proyecto activo. Para cerrarlo hace falta una de estas dos cosas: evidencia del criterio de éxito, o una decisión del Comité de Expansión que cierre por decisión y diga qué queda abierto y a cargo de quién. No se movió ninguna carpeta.

**Pie de rigor:** esto es un borrador de trabajo, no una decisión. Todo dato viene con la cita del documento de donde salió, y la verificación es de quien lo lee. Criterio solo conoce lo que está en los cuatro documentos de la carpeta.
