# Corrida del 2026-10-15 · steering-pack

13 proyectos · 95 s · 60 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 29 |
| `progress_vs_plan` | 9 |
| `declared_vs_evidence` | 5 |
| `commitment_overdue` | 4 |
| `variance_time` | 3 |
| `variance_cost` | 2 |
| `commitment_undated` | 2 |
| `vendor_deliverable_late` | 2 |
| `rebaseline_unauthorized` | 2 |
| `change_without_baseline` | 1 |
| `vendor_accepted_without_evidence` | 1 |

Paquete de 8 decisiones y 6 escalamientos para el comité del 2026-10-22. Dijo que no sabe: la autoridad de aprobación (vacía en las 13 fichas), decisiones del comité anterior (solo leí actas de PRY-201 y 208), si el hallazgo de seguridad de PRY-201 y 206 es el mismo, y el contenido de los pdf (no releídos). PRY-202 queda fuera de las decisiones: la solicitud no tiene documento.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

*Fichas cargadas: las 13 de `estado/records/` (PRY-199 a PRY-211), generadas el 2026-10-15; cifras de `portafolio.py compute` con corte 2026-10-15. Términos vigentes (v1.1, familia 0.3.8), aceptados por José Francisco Ñáñez el 2026-10-15; no se registraron de nuevo.*

# Comité de proyectos — material para el 2026-10-22
8 decisiones · 6 escalamientos sin decisión asociada · 12 de 13 proyectos con hallazgos (60 señales; 5 proyectos declarados en verde que los documentos contradicen: PRY-202, 203, 205, 206 y 211)

> Todo el portafolio es declaración: en las 13 fichas, 0 datos vienen de evidencia de recibo y 5 de cada una son declaraciones del gerente. Lo que sigue es lo que los documentos muestran, no una verificación en campo.

## Decisiones del comité anterior
| Decisión | Fecha | Qué pasó | Estado |
|---|---|---|---|
| CC-01 de PRY-201 (+91 días, 182.000.000 COP): "autorizada por el comité" | Sin fecha | La solicitud es del 2026-10-12. El acta del comité del 2026-10-15 solo trata "Avance" y "Compromisos" y no la menciona. El script la cuenta como cambio aprobado sin línea base nueva. | Abierta (ver decisión 4) |

No encontré ninguna otra decisión de comité registrada. Las actas de comité semanal que leí (PRY-201 y PRY-208; el resto no lo abrí) traen solo compromisos, no decisiones. Si el comité del 2026-10-08 decidió algo, no está en la carpeta.

## Decisiones de hoy

### [1] ¿Quién tiene la facultad de aprobar cambios de alcance, tiempo y costo en el portafolio: el Comité de Cadena de Abastecimiento o cada patrocinador hasta un umbral?
**Proyecto:** todos (las 13 fichas quedaron sin autoridad declarada) · **Quién decide:** el comité, por ser el único órgano que figura en las actas y que aprobó el presupuesto en el acta de PRY-202 · **Si no se decide hoy:** las decisiones 2 a 4 se toman sin que esté claro que quien las toma pueda hacerlo.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. El comité aprueba todo cambio | Sin efecto | Un cambio espera hasta la siguiente reunión semanal | Sin efecto |
| B. Umbral: el comité solo lo que supere los umbrales (hoy 10 % en tiempo y en costo) y el patrocinador el resto | Sin efecto | Cambios menores se resuelven sin esperar | Sin efecto, pero hay que fijar quién firma |
**Recomendación:** A hasta que el umbral esté escrito en cada acta. Con las cifras de hoy (desviaciones de 10,9 %, 28,3 % y 28,6 %) los tres cambios superan el 10 % y irían al comité en cualquier opción.

### [2] ¿Se aprueba la CC-01 de PRY-208 (+41 días, +82.000.000 COP) y se legaliza la línea base ya movida?
**Proyecto:** PRY-208 Domicilios en dos horas (rojo, 73 % declarado) · **Quién decide:** comité (punto 1) · **Si no se decide hoy:** la línea base ya se movió 41 días con 0 días autorizados (señal `rebaseline_unauthorized`) y la desviación contra el original sigue en 10,9 %. El cierre vigente, 2026-09-29, ya pasó.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar y registrar línea base 2 | Ampliación | +41 días (queda como línea base) | +82.000.000 COP |
| B. Rechazar y volver a la línea base original | Sin ampliación | Los 41 días pasan a ser atraso reconocido | Sin costo adicional |
| C. Devolver sin decisión hasta que el solicitante dé motivo y detalle del alcance | Sin decidir | La fecha ya movida sigue sin respaldo | Sin decidir |
**Recomendación:** C, con plazo del 2026-10-22. La solicitud no dice qué se amplía ni por qué, y no puedo recomendar aprobar lo que no está descrito. Si el comité exige decidir hoy, B es la opción que menos compromete.

### [3] ¿Se aprueba la CC-01 de PRY-211 (+77 días, +154.000.000 COP) cuando el proyecto la reporta en verde?
**Proyecto:** PRY-211 Pronóstico de demanda (declarado verde, 31 % de avance frente a 60–80 % que sostiene el plan) · **Quién decide:** comité · **Si no se decide hoy:** igual que PRY-208: 77 días de línea base movidos con 0 autorizados; desviación de 28,3 % contra el original. Además hay un compromiso de Beatriz Cuéllar vencido hace 15 días.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar y registrar línea base 2 | Ampliación | +77 días | +154.000.000 COP |
| B. Rechazar | Sin ampliación | Los 77 días pasan a ser atraso reconocido | Sin costo adicional |
| C. Devolver hasta corregir el estado declarado y aclarar el alcance | Sin decidir | Sin respaldo | Sin decidir |
**Recomendación:** C. Un proyecto que pide 77 días y dice estar en verde se contradice a sí mismo; primero hay que corregir el estado.

### [4] ¿El comité ratifica la CC-01 de PRY-201 (+91 días, +182.000.000 COP) con fecha, acta y línea base 2?
**Proyecto:** PRY-201 Programa de fidelización (amarillo, 59 % declarado) · **Quién decide:** comité · **Si no se decide hoy:** el cambio queda "autorizado" sin fecha, sin acta y sin línea base; la desviación de 91 días (28,6 %) se sigue leyendo como atraso.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Ratificar hoy y registrar la línea base 2 | Ampliación | +91 días | +182.000.000 COP |
| B. Anular la autorización por falta de acta | Sin ampliación | 91 días pasan a ser atraso | Sin costo adicional |
**Recomendación:** A, solo si alguien aporta el acta de la autorización; si no existe, B. No puedo confirmar que existió.

### [5] ¿Cómo se trata el sobrecosto proyectado de PRY-204 (22,4 %) y PRY-205 (25,6 %)?
**Proyecto:** PRY-204 Cajas de autopago (aprobado 9.500.000.000 COP, proyección 11.623.833.685 COP) y PRY-205 Pago con QR (aprobado 6.800.000.000 COP, proyección 8.542.694.050 COP) · **Quién decide:** comité · **Si no se decide hoy:** ambos ya superan el umbral de 10 %. PRY-204 lleva 81,5 % comprometido y 19,8 % ejecutado; el ajuste de presupuesto de PRY-205 lo prometió Laura Vélez "la otra semana" (nota del 2026-10-15) sin fecha.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Pedir solicitud de cambio formal de presupuesto por proyecto | Sin cambio | Sin cambio | El comité conoce la cifra antes de gastar |
| B. Congelar nuevos compromisos hasta decidir | Sin cambio | Puede retrasar contratación | Evita crecer sobre lo aprobado |
| C. Recortar alcance a lo aprobado | Se reduce | Sin cambio declarado | Vuelve al aprobado |
**Recomendación:** A y B juntas en PRY-204, que aún tiene margen sin comprometer; en PRY-205 A con fecha dura para la solicitud. C no la puedo valorar: ninguna ficha dice qué se recortaría.

### [6] ¿Se retiene el pago de la factura FV-1451 de PRY-206 hasta que exista el acta de recibo?
**Proyecto:** PRY-206 Precios dinámicos (verde, 78 %) · **Quién decide:** comité, con el gerente del proyecto · **Si no se decide hoy:** el único entregable facturado, 543.383.423 COP (Retail Andino, contrato CT-451), no tiene el acta que el contrato exige; otros dos entregables llevan 233 y 128 días de atraso sin declararse en riesgo.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Retener hasta el acta | Sin cambio | Puede tensar la relación con el proveedor | 543.383.423 COP sin pagar |
| B. Pagar y exigir el acta después | Sin cambio | Sin efecto | Se paga sin evidencia |
**Recomendación:** A. El propio contrato condiciona la factura al acta. Si el acta existe fuera de la carpeta, que la aporten y se libera.

### [7] ¿Quién es doliente del hallazgo de seguridad en los medios de pago, reportado en PRY-201 (2026-10-10) y PRY-206 (2026-10-15)?
**Proyecto:** PRY-201 y PRY-206 (afecta a más de un proyecto) · **Quién decide:** comité · **Si no se decide hoy:** es una incidencia ya ocurrida, sin doliente ni fecha de resolución; PRY-206 la reporta en verde. No sé si es el mismo hallazgo: el texto es idéntico y ningún documento lo aclara.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Un solo doliente para ambos, con plazo | Sin cambio | Una sola línea de resolución | No declarado |
| B. Un doliente por proyecto | Sin cambio | Pueden duplicarse esfuerzos | No declarado |
**Recomendación:** A, tras confirmar en la reunión si es el mismo hallazgo. Quién sea el doliente no lo propongo: las fichas no lo dicen.

### [8] ¿Se ordena replanificar o auditar los tres proyectos con fecha de cierre vencida y sin replanificación: PRY-209, PRY-203 y PRY-205?
**Proyecto:** PRY-209 Migración del ERP (cierre 2026-04-09, rojo, 74 %), PRY-203 Reposición automática (2026-05-04, verde, 74 %) y PRY-205 Pago con QR (2026-04-29, verde, 46 %) · **Quién decide:** comité · **Si no se decide hoy:** los tres declaran todos sus hitos cumplidos pero sin evidencia (hasta 444 días sin acta en PRY-203) y un avance entre 26 y 54 puntos por debajo de lo que el plan sostiene. 0 replanificaciones registradas.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Exigir replanificación formal con solicitud de cambio | A definir | Fecha nueva con línea base | PRY-203 y PRY-209 ya proyectan por debajo del aprobado (−4,4 % y −7,2 %); PRY-205 +25,6 % |
| B. Auditoría de evidencia de los hitos antes de replanificar | Sin cambio | Una semana más | Sin costo adicional declarado |
| C. Dejarlos como están | Sin cambio | El atraso sigue sin reconocerse | Sin cambio |
**Recomendación:** B y luego A. Hoy no se sabe cuánto atraso real hay, porque los hitos "cumplidos" no tienen acta.

## Escalamientos sin decisión asociada
| Proyecto | Qué | Desde cuándo | Qué se necesita |
|---|---|---|---|
| PRY-199, 204, 208 | La prueba de carga de temporada no alcanzó el umbral y se repite; sin doliente (PRY-199 la declara en verde) | 2026-10-13 / 10-05 / 10-04 | Un doliente y una fecha de la nueva prueba |
| PRY-201, 209 (y 200, 207, 210) | "Congelamiento de cambios" sigue como riesgo cuando ya se materializó (despliegue reprogramado) | 2026-10-10 / 10-15 | Reclasificar a incidencia y nombrar doliente |
| PRY-199, 201, 203, 205 | El proveedor no confirma la fecha de la última entrega o el equipo (PRY-205, dicho en reunión y sin registrar) | 2026-10-08 a 10-15 | Confirmación del proveedor; PRY-203 debía terminar el 2026-05-04 |
| PRY-200 | Dos semanas perdidas por la rotación de un desarrollador clave; rojo, 41 % frente a 75–100 % del plan | 2026-10-04 | Qué se hizo; la ficha no lo dice |
| PRY-202 | Se pidió mover 30 días el despliegue, pero no hay solicitud escrita, solicitante ni motivo; el acta fija el cierre en 2027-06-10 y el cronograma en 2027-05-01 | 2026-10-15 | Solicitud formal y definir cuál es la línea base. No está lista para decidir |
| PRY-204, 207, 208, 211 | Compromisos vencidos: Andrés Lozano (7 días), Laura Vélez (12), Carlos Peña (7), Beatriz Cuéllar (15) | 2026-09-30 a 10-08 | Cierre con evidencia o nueva fecha |

## Para conocimiento
- PRY-199 Iluminación LED: verde, 20 %; sin señales de desviación. Su incidencia de prueba de carga está arriba.
- PRY-202 Centro de distribución norte: verde con dos hitos cumplidos sin acta; el avance (38 %) está dentro del rango del plan.
- PRY-207 Marca propia: amarillo, 40 % frente a 75–100 % del plan; compromiso de Laura Vélez vencido 12 días.
- PRY-210 Etiquetas electrónicas: amarillo, 47 % frente a 75–100 %; dos hitos sin acta.

## Anexo
**Contradicciones abiertas (declarado vs. documentos):** PRY-202, 203, 205, 206 y 211 en verde con señales sin explicar; PRY-203 y PRY-205 son los más lejos del plan (26 y 54 puntos).
**Vacíos de información:**
- Autoridad y fase: sin dato en las 13 fichas.
- Producto: sin dato en PRY-202, 203, 206, 209, 210 y 211.
- Datos de identidad y plan con más de 12 meses en PRY-200, 203, 205, 208 y 209.
- RAID: 35 ítems sin doliente ni fecha de resolución; 0 supuestos registrados.
- PRY-206: vigencia y preaviso del contrato CT-451 sin dato. PRY-202: CT-599 sin fecha de vencimiento.
- Ninguna ficha declara dependencias entre proyectos; un cruce vacío no prueba que no existan.
- Los informes y actas en pdf no se releyeron en esta corrida; lo que sale de ellos viene de la ficha.

---
*Criterio-portfolio 0.3.8 · fichas aplicadas: 13 (PRY-199 a PRY-211, corte 2026-10-15) · campos inciertos: autoridad, fase y producto (arriba); todo lo que sale de informes es declaración sin evidencia de recibo · es un borrador de trabajo, y la verificación contra los documentos es de quien lo lee · términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal*
