Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15; no hizo falta registrarlos de nuevo).

**Acta previa:** sí existe, aprobada el 2026-03-19 (`PRY-202-centro-de-distribución-norte/00-gobierno/2026-03-19-acta-constitucion.md`).

## Acta — PRY-202 Centro de distribución norte
**Estado:** existe, del 2026-03-19. Está firmada en forma pero vacía en fondo: casi todos los campos tienen texto de relleno.

### Qué falta
| Campo | Estado | Consecuencia |
|---|---|---|
| Autoridad del gerente | **No existe** | Nadie sabe hasta qué monto ni qué cambio de alcance puede decidir Andrés Lozano solo. Con 1.200.000.000 COP aprobados y 547.888.881 ya comprometidos (46 %), cada cambio o compromiso adicional termina en el Comité de Cadena de Abastecimiento, o se decide sin facultad y es hallazgo después. |
| Objetivo de negocio | Es una solución, no un objetivo: "Entregar centro de distribución norte para Logística" | No hay resultado de negocio contra el cual decidir si vale la pena seguir, recortar o cambiar el proyecto. |
| Alcance | "Componente 1, 2, 3" sin contenido | No se puede verificar qué se entregó ni detectar un cambio de alcance: nada define qué es "dentro". Cualquier pedido nuevo es indiscutible o inatacable. |
| Exclusiones | "Lo que otro proyecto cubre", sin nombrar cuál | No evita la discusión del mes ocho: no dice qué proyecto ni qué cubre. Además, el acta declara "Ninguna" dependencia, lo que contradice que algo lo cubra otro proyecto. |
| Patrocinador | Presente: Elena Duarte | Sin vacío. |
| Supuestos y restricciones | **No existen** (la sección no está) | Los dos riesgos del informe (conocimiento concentrado, disponibilidad de jefes de tienda para el piloto) son supuestos sin declarar; si fallan, no hay línea base contra la cual medir el efecto. |
| Criterio de éxito | "En producción y medido": sin métrica, umbral ni fecha de medición | No dice qué se mide, cuánto basta, ni quién mide. El cierre no tendría contra qué compararse. |
| Quién mide el éxito | **No existe** | Nadie responde por declarar que el proyecto cumplió. |
| Comité y cadencia | Comité nombrado; **cadencia no declarada** | No hay un ritmo pactado al que el gerente deba reportar. |
| Hitos principales | No están en el acta; sí en el cronograma v1 (5 hitos) | El acta no los ancla. |
| Fechas | **Contradicción:** acta cierre 2027-06-10; cronograma v1 cierre 2027-05-01 | Hay 40 días de diferencia entre dos documentos aprobados el mismo día; no se sabe cuál es la línea base de cierre, y toda desviación futura depende de eso. |

### Contenido
**Objetivo de negocio:** pendiente de definir (el acta solo describe la solución).
**Alcance:** pendiente de definir (Componente 1, 2 y 3 sin detalle).
**Exclusiones:** pendiente de definir (el acta dice "lo que otro proyecto cubre", sin nombrar cuál).
**Patrocinador:** Elena Duarte · **Gerente:** Andrés Lozano (acta 2026-03-19).
**Autoridad del gerente:** pendiente de definir: no figura en ningún documento.
**Comité al que reporta:** Comité de Cadena de Abastecimiento · **Cadencia:** pendiente de definir.
**Supuestos:** pendiente de definir · **Restricciones:** pendiente de definir.
**Presupuesto aprobado:** 1.200.000.000 COP, aprobado el 2026-03-19 por el comité (acta).
**Criterio de éxito:** "Centro de distribución norte en producción y medido" (acta); sin métrica · **Lo mide:** pendiente de definir.
**Hitos principales** (cronograma v1, 2026-03-19): Diseño de la experiencia aprobado 2026-06-16 · Ambiente de pruebas certificado 2026-09-04 · Integración con el ERP 2026-11-22 · Piloto en tiendas 2027-02-10 · Despliegue en la cadena 2027-05-01.
**Fechas del acta:** inicio 2026-03-29, cierre 2027-06-10 (distinto del cronograma, ver arriba).

### Lo que dice el entorno y conviene saber
- El informe de avance del 2026-10-13 declara verde y 38 %. Sin objetivo, alcance ni criterio medible en el acta, ese "verde" no tiene contra qué contrastarse.
- La ficha marca como cumplidos los hitos de junio y septiembre sin documento de recibo en la carpeta (campo de evidencia vacío); esto no es del acta pero afecta cualquier revisión de cierre.
- El único compromiso abierto (Elena Duarte, "entregar el punto 19", 2026-10-25) no dice qué es el punto 19 en ningún documento leído.

### Qué no sé
- No leí el contenido del comité del 2026-10-10 (.docx) ni el contrato CT-599 para esta revisión; pueden contener restricciones o facultades que el acta no recoge.
- No sé si existe una facultad del gerente fuera de la carpeta del proyecto (política de la organización).

### Después (ofrecimientos)
1. Llevar al Comité de Cadena de Abastecimiento la definición de la **autoridad del gerente** (monto y tipo de cambio): es una decisión, no un trámite.
2. Pedir a Andrés Lozano y Elena Duarte el objetivo medible, el alcance real, el proyecto citado en exclusiones y quién mide el éxito.
3. Pasar al registro RAID los dos supuestos implícitos (conocimiento concentrado; disponibilidad de jefes de tienda) y la contradicción de fechas de cierre.

*Pie de rigor: borrador de trabajo, no decisión ni asesoría. Cada dato viene de la fuente citada; la verificación es de quien lo usa.*
