# Corrida del 2026-10-15 · portfolio-scan

13 proyectos · 74 documentos, 0 releídos y 74 sin cambio · 167 s · 60 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 29 |
| `progress_vs_plan` | 9 |
| `declared_vs_evidence` | 5 |
| `commitment_overdue` | 4 |
| `variance_time` | 3 |
| `variance_cost` | 2 |
| `commitment_undated` | 2 |
| `vendor_deliverable_late` | 2 |
| `rebaseline_unauthorized` | 2 |
| `change_without_baseline` | 1 |
| `vendor_accepted_without_evidence` | 1 |

10 fichas nuevas (PRY-199,200,202,203,204,205,207,208,209,210); 3 sin cambio (201,206,211). Nada movido: no existe entrada/. Sin ilegibles. PRY-205 trae ficha-pm.json, guardada en pm_record. A mirar: 12 de 13 proyectos con hitos cerrados sin acta, verdes contradichos (202,203,205), cierres vencidos con proyecto activo (203,205,209), CC-01 y v2 de PRY-208.

Contra la corrida del 2026-10-15: +43 hallazgos.

## Lo que produjo

## Barrido — 2026-10-15

Términos vigentes (versión 0.3.8, aceptados por José Francisco Ñáñez el 2026-10-15); no se volvieron a pedir. Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.8

**Documentos:** 74 en la carpeta · 51 leídos · 23 sin cambio desde la corrida anterior · 0 ilegibles
**Proyectos:** 13 con ficha · 10 nuevos (PRY-199, 200, 202, 203, 204, 205, 207, 208, 209, 210) · 0 sin carpeta propia

Plan ejecutado tal cual: 1 lote de 10 proyectos, uno tras otro, sin subagentes (`workers: 1`). Los otros 3 proyectos (PRY-201, 206, 211) no cambiaron y conservan su ficha. Cada ficha se escribió y se selló al terminar su proyecto.

### Nuevos
| Proyecto | Documentos | Campos encontrados | Campos sin dato |
|---|---|---|---|
| PRY-199 Iluminación LED en bodegas | 6 | identidad, plan, presupuesto, contrato CT-199 (3 entregables), riesgos, 1 compromiso | autoridad, fase, facturado |
| PRY-200 Tienda en línea | 4 | identidad, plan, presupuesto, riesgos, 1 compromiso | autoridad, fase |
| PRY-202 Centro de distribución norte | 7 | identidad, plan, presupuesto, contrato CT-599, acta de recibo, factura, 1 compromiso | autoridad, fase, producto (el acta dice «No aplica») |
| PRY-203 Reposición automática | 4 | identidad, plan, presupuesto, riesgos | autoridad, fase, producto, compromisos |
| PRY-204 Cajas de autopago | 4 | identidad, plan, presupuesto, riesgos, 1 compromiso | autoridad, fase |
| PRY-205 Pago con QR en caja | 6 | lo anterior más `ficha-pm.json` (va entera en `pm_record`), 3 compromisos y 1 riesgo dicho en reunión | autoridad, fase |
| PRY-207 Marca propia de alimentos | 5 | identidad, plan, presupuesto, riesgos, 1 compromiso | autoridad, fase |
| PRY-208 Domicilios en dos horas | 6 | identidad, plan con 2 líneas base, presupuesto, solicitud de cambio CC-01, 1 compromiso | autoridad, fase |
| PRY-209 Migración del ERP | 4 | identidad, plan, presupuesto, riesgos, 1 compromiso sin fecha | autoridad, fase, producto |
| PRY-210 Etiquetas electrónicas de precio | 5 | identidad, plan, presupuesto, riesgos, 1 compromiso | autoridad, fase, producto |

### Actualizados
| Proyecto | Qué cambió | Fuente |
|---|---|---|
| Ninguno | Los 3 proyectos con ficha previa (PRY-201, 206, 211) no tuvieron documentos nuevos ni cambiados. | plan de lectura |

### No pude leer
| Archivo | Por qué |
|---|---|
| Ninguno | Los 74 archivos se convirtieron a texto. |

### Movidos desde entrada/
| Archivo | A qué proyecto | Por qué |
|---|---|---|
| Ninguno | — | La carpeta `entrada/` no existe en este espacio. |

### Pendientes de clasificar
| Archivo | Por qué no pude decidir |
|---|---|
| Ninguno | — |

### Lo que hay que mirar (calculado por el script; 60 señales en 12 de 13 proyectos)
- **Hitos declarados cerrados sin acta que lo pruebe** (`milestone_met_without_evidence`) en 12 de los 13 proyectos (todos menos PRY-199); PRY-203 tiene 4, y PRY-200, 205, 208 y 209 tienen 3 cada uno. Solo hay acta para un hito en PRY-199, 203, 207 y 210. No piden «apúrense» sino «muéstrenme el acta».
- **Verde contradicho por la evidencia** (`declared_vs_evidence`): PRY-202, 203 y 205 declaran verde. PRY-206 y 211 también tienen la señal, de la ficha anterior. PRY-199 declara verde y no tiene señal.
- **Cierre comprometido ya vencido con proyecto activo:** PRY-203 (2026-06-09), PRY-205 (2026-06-10) y PRY-209 (2026-05-25). Cada uno tiene `progress_vs_plan`.
- **Costo:** PRY-204 proyecta 11.623.833.685 contra 9.500.000.000 aprobados, y PRY-205 proyecta 8.542.694.050 contra 6.800.000.000 (`variance_cost`). En PRY-203 lo ejecutado (9.625.843.282) supera lo comprometido (5.942.678.419), lo cual es incoherente en el informe mismo.
- **Control de cambios:** PRY-208 tiene CC-01 (+41 días, +82.000.000 COP) pendiente de comité, y la línea base v2 se publicó el 2026-10-04 sin motivo ni autorización documentados (`rebaseline_unauthorized`, `variance_time`). El script no encontró `change_without_baseline` en PRY-208, pero sí en PRY-201.
- **Compromisos:** vencidos en PRY-204 (Andrés Lozano, 2026-10-08), PRY-207 (Laura Vélez, 2026-10-03) y PRY-208 (Carlos Peña, 2026-10-08). Sin fecha en PRY-205 (Laura Vélez) y PRY-209 (Jorge Medina, «por definir»). En PRY-205, Beatriz Cuéllar ya reprogramó una vez (11-08 → 11-22). Además, PRY-205 tiene un riesgo dicho en reunión que nadie registró: el proveedor podría no llegar con el equipo completo.
- **Proveedores:** PRY-202 tiene facturado 63.749.222, igual al único entregable aceptado (Licenciamiento, recibido 2026-07-28, 12 días después de la fecha comprometida). PRY-199 (CT-199) tiene 3 entregables pendientes y ninguna factura en la carpeta. Cinco informes (PRY-203, 205, 207, 209, 210) dicen «el proveedor entregó el componente de integración, pendiente de aceptación», pero ninguno de esos proyectos tiene contrato en la carpeta.
- **Autoridad del gerente:** `not_found` en los 13 proyectos; ninguna acta la define.
- **Dependencias y alcance:** las actas de PRY-199 a PRY-210 declaran «Ninguna» dependencia. El alcance de todas es «Componente 1, 2, 3», sin detalle.

**Pie:** criterio-portfolio 0.3.8 · fichas tocadas: 10 (PRY-199, 200, 202, 203, 204, 205, 207, 208, 209, 210) · campos en `not_found`: `identity.authority` e `identity.phase` en las 10 fichas, y `identity.product` en PRY-202, 203, 209 y 210 · términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.8

**Después:** hay más de un proyecto, así que puedo generar el informe consolidado con `/criterio-portfolio:portfolio-report`.
