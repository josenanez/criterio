## Listo — Retail

Soy Vera, el agente PMO de Criterio. Leo la documentación que ya tienes y digo qué no se sostiene.

**Miré:** 74 documentos en 13 proyectos (PRY-199 a PRY-211) · formatos: .md 29, .pdf 14, .docx 13, .csv 8, .xlsx 8, .json 1, .txt 1 · más reciente: 2026-10-15
**Eres:** PMO del portafolio (13 proyectos; respuesta sugerida)
**Te aviso:** dos días antes del comité semanal; próximo comité supuesto el 2026-10-22 (los archivos se llaman «comite-semanal»; la fecha no la dice ningún documento, corrígela si no es esa)
**En:** presentación (respuesta sugerida; queda configurada como `html`, el formato del ejemplo)
**Términos:** versión 1.1 aceptada por José Francisco Ñáñez el 2026-10-15 · comprobante en `.criterio/terminos/aceptacion-criterio-portfolio-0.3.8-2026-10-15.md` y `.pdf` · SHA-256 del .md: 906ca52cb3296d17…
**Dónde queda:** configuración en `.criterio/portafolio/config.json`; lo que voy encontrando en `estado/`; informes en `reportes/`.

### Probé con tres proyectos

Tomé PRY-201, PRY-206 y PRY-211: tres de los cinco proyectos con documentos fechados el 2026-10-15 (también los tienen PRY-205 y PRY-209; el desempate fue mío).

| Proyecto | Documentos | Qué supe | Qué no está |
|---|---|---|---|
| PRY-201 Programa de fidelización | 7 | Gerente Jorge Medina, patrocinadora Beatriz Cuéllar. Presupuesto 2.400 M COP, ejecutado 56,3 %. Declara amarillo, 59 % (informe 2026-10-10). Cierre del acta: 2026-12-22 | Autoridad del gerente, fase |
| PRY-206 Precios dinámicos | 8 | Gerente Rubén Cárdenas, patrocinadora Beatriz Cuéllar. Presupuesto 6.800 M COP, ejecutado 46,6 %. Declara verde, 78 % (informe 2026-10-15). Cierre del acta: 2027-01-04 | Producto, autoridad, fase |
| PRY-211 Pronóstico de demanda | 8 | Gerente Carlos Peña, patrocinador Javier Hoyos. Presupuesto 9.500 M COP, ejecutado 59,0 %. Declara verde, 31 % (informe 2026-10-15). Cierre del acta: 2027-02-04 | Producto, autoridad, fase |

### Hallazgos (los que levantó el cálculo, 17 señales en los tres)

**PRY-211 — declara verde y cinco señales lo contradicen**
- `variance_time`: el despliegue pasó de 2027-01-07 a 2027-03-25, 77 días (28,3 %) contra la línea base original. Fuente: `10-plan/2026-10-15-cronograma-v2.csv`.
- `rebaseline_unauthorized`: esos 77 días ya están en el cronograma v2, pero la solicitud CC-01 (+77 días, +154 M COP) dice «Pendiente de presentación al comité». Se movió la fecha sin autorización.
- `progress_vs_plan`: declara 31 %; los hitos cumplidos sostienen entre 60 y 80 % (3 de 5). Diferencia de 29 puntos.
- `commitment_overdue`: Beatriz Cuéllar, «Entregar el punto 33», para el 2026-09-30, vencido hace 15 días. Está en el acta del comité del 2026-10-13, o sea que se registró ya vencido.
- `milestone_met_without_evidence`: «Ambiente de pruebas certificado» (2026-07-28) figura cerrado y no hay acta de recibo.

**PRY-206 — declara verde y dos señales lo contradicen**
- `vendor_deliverable_late`: CT-451, «Licenciamiento de la plataforma» (venció 2026-02-24, 233 días) y «Bolsa de horas de desarrollo» (venció 2026-06-09, 128 días) siguen pendientes.
- `vendor_accepted_without_evidence`: «Configuración del catálogo» figura recibido, y la factura FV-1451 (2026-09-23, 543.383.423 COP) se radicó contra él. El contrato exige acta de recibo firmada por el gerente y no hay ninguna. Los tres entregables valen lo mismo, así que cualquier otra lectura de la factura tampoco queda cubierta.
- `milestone_met_without_evidence`: «Diseño de la experiencia aprobado» (2026-01-27) e «Integración con el ERP» (2026-06-28) cerrados sin acta.
- Para el comité: el informe de hoy dice verde y a la vez reporta un hallazgo de seguridad en los medios de pago. Es un dato del informe; no levantó señal.

**PRY-201 — declara amarillo; el cálculo muestra más atraso del que el amarillo sugiere**
- `variance_time`: el piloto pasó de 2026-11-12 a 2027-02-11, 91 días (28,6 %).
- `progress_vs_plan`: declara 59 %; los hitos sostienen entre 75 y 100 % (3 de 4). Aquí el gerente declara menos de lo que el plan indica, no más.
- `change_without_baseline`: CC-01 (+91 días, +182 M COP) figura «Autorizada por el comité», pero sin fecha de autorización y sin línea base nueva. La fecha de cierre del acta sigue siendo 2026-12-22 y ningún documento la actualiza.
- `milestone_met_without_evidence`: «Diseño de la experiencia aprobado» (2026-03-18) y «Ambiente de pruebas certificado» (2026-06-06) cerrados sin acta.

**Del portafolio:** en los tres proyectos falta la autoridad del gerente; ninguna acta dice hasta qué monto puede decidir sin subir a comité. Dos de los tres reportan verde con señales en contra.

### El portafolio completo
10 proyectos más (PRY-199, 200, 202 a 205, 207 a 210), 64 documentos restantes. Con este ritmo, que fue de unos pocos documentos por proyecto y sin lotes de más de uno a la vez, calculo del orden de 30 a 45 minutos en dos lotes, uno tras otro (diez proyectos y luego tres, 13 en total; los tres de prueba ya quedaron hechos y no se releen). Es una estimación mía a partir de esta prueba, no una medida.

### Lo que le falta a tu carpeta
- Actas de recibo: en los tres proyectos hay hitos cerrados sin acta. Es lo que más señales produce.
- PRY-205 tiene `ficha-pm.json` (el gerente usa su propio agente) y `2026-10-15-notas-reunion.txt` fuera de las carpetas 00 a 30. Las leeré como un documento más cuando toque ese proyecto.
- Las actas de constitución traen alcance genérico («Componente 1, 2, 3») y «Fuera de alcance» genérico: no hay contra qué medir un cambio de alcance como los CC-01 de PRY-201 y PRY-211.
- Dependencias declaradas: «Ninguna declarada» en los tres. Con 13 proyectos que comparten ERP y plataforma de pagos, es poco probable que sea cierto.
- Fechas de autorización de cambios y fechas de comité: sin ellas no se puede decir cuándo se aprobó algo.

Ninguno de estos puntos es bloqueante.

### Preguntas que quedaron en su valor sugerido
Rol PMO · comité semanal con próxima fecha 2026-10-22 · informe en presentación · estado en `estado/` e informes en `reportes/` · términos con el sí y el nombre que traía la sesión.
