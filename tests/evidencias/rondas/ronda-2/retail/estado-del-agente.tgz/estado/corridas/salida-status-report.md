Informe sale de la ficha `estado/records/PRY-203.json` (actualizada 2026-10-15), con cifras recalculadas por `portafolio.py compute` al 2026-10-15.

## PRY-203 Reposición automática — estado al 2026-10-15

**Declara el gerente (Jorge Medina):** verde · 74% · al 2026-10-08 (7 días; declaración vigente) — fuente: `20-seguimiento/2026-10-08-informe-avance.pdf`
**Sustento documental:** contradicho (alerta `declared_vs_evidence`: reporta verde y hay evidencia que ese verde no cubre)
**Lo que el semáforo no explica:** `milestone_met_without_evidence` (4 hitos) y `progress_vs_plan` (brecha de 26.0 puntos)
**Último documento:** 2026-10-08 (7 días de silencio; umbral 15) · **Última reunión:** sin dato — no hay minuta ni transcripción en la carpeta del proyecto

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2026-05-04 | 2026-05-04 | 0 días vs. original · 0 días vs. vigente |
| Presupuesto (COP) | 18.000.000.000 | 18.000.000.000 | proyección 17.211.297.614 (−4.4% sobre lo aprobado) |

Replanificaciones: 0. Una sola línea base (v1, 2025-05-09, «Aprobación del acta de constitución»). Cambios registrados: 0.

La fecha de cierre pactada (2026-05-04) ya pasó, y el proyecto sigue declarándose en verde al 74%. Ninguna replanificación recoge ese hecho.

Dinero (declarado en el informe de avance, no sustentado por otro documento): ejecutado 9.625.843.282 (53.5%), comprometido 5.942.678.419 (33.0%), disponible real 12.057.321.581.

### Hitos
| Hito | Base | Vigente | Estado | Evidencia |
|---|---|---|---|---|
| Diseño de la experiencia aprobado | 2025-07-28 | 2025-07-28 | cumplido (declarado) | ninguna |
| Ambiente de pruebas certificado | 2025-10-06 | 2025-10-06 | cumplido | `20-seguimiento/2026-10-03-acta-recibo-ambiente-de-pruebas-certificado.md` (acta fechada 2026-10-03) |
| Integración con el ERP | 2025-12-15 | 2025-12-15 | cumplido (declarado) | ninguna |
| Piloto en tiendas | 2026-02-23 | 2026-02-23 | cumplido (declarado) | ninguna |
| Despliegue en la cadena | 2026-05-04 | 2026-05-04 | cumplido (declarado) | ninguna |

Cinco de cinco hitos cumplidos según el plan; cuatro sin ningún documento que lo sustente (444, 304, 234 y 164 días desde su fecha).

### Dónde no coincide
- **Declarado:** verde, 74% (informe de avance, 2026-10-08). **Plan:** con 5 de 5 hitos cumplidos, el plan sostiene 100%. Brecha de 26.0 puntos, en dirección «atrás»: si los hitos están cumplidos, el 74% no cuadra; si el 74% es cierto, los hitos no están cumplidos.
- **Hitos:** cuatro figuran cumplidos sin evidencia. El quinto (ambiente de pruebas) tiene un acta de recibo de 2026-10-03, casi un año después de su fecha base (2025-10-06); la fecha vigente no se movió.
- El propio informe del 2026-10-08 reconoce una validación con dos tiendas extendida una semana, y un proveedor sin fecha de la última entrega: son incompatibles con un «Despliegue en la cadena» cumplido el 2026-05-04.

### Abierto
**Riesgos e incidencias sin movimiento:**
- Riesgo: «El proveedor no ha confirmado la fecha de la última entrega» — sin dueño, sin probabilidad, impacto ni fecha; sin «último movimiento» registrado (fuente: informe 2026-10-08).
- Incidencia: «La validación con dos tiendas se extendió una semana por el conteo de inventario» — desde 2026-10-08, sin dueño.

**Compromisos vencidos:** ninguno registrado (no hay compromisos en la ficha; sin minutas no hay de dónde extraerlos).
**Dependencias sin confirmar:** ninguna registrada. Nota: el riesgo del proveedor no tiene contrato ni proveedor en la ficha (`vendors` vacío).

### Sin dato
- Producto, autoridad y fase (`identity.product`, `identity.authority`, `identity.phase`): no encontrados.
- Última reunión: sin dato.
- Evidencia independiente de la declaración: 0 fuentes de evidencia, 5 declaraciones, 14 sin marcar.
- Campos inciertos por antigüedad (17 meses, de la constitución del 2025-05-09): código, nombre, área, patrocinador, gerente, comité, fecha de inicio, fecha de fin, alcance, exclusiones y presupuesto aprobado.
- El informe de avance es un PDF sin texto extraído (`text_hash` nulo): sus cifras se tomaron de la ficha, y vale revisarlas contra el original.

### Después
Hay motivo para preparar el punto de comité (el Comité de Expansión): verde declarado contra evidencia que no lo sostiene, y fecha de cierre vencida sin replanificar. Si el atraso viene de un cambio no formalizado, ofrezco la solicitud de cambio. No lo preparo sin que me lo pidan.

---
criterio-portfolio 0.3.8 · ficha de PRY-203 del 2026-10-15 · campos inciertos: los listados arriba en «Sin dato» · términos v1.1 aceptados por José Francisco Ñáñez el 2026-10-15: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.8
