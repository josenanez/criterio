# Portafolio — 2026-10-15

Fichas cargadas: 13 (`estado/records/`, todas con fecha 2026-10-15; ninguna con más de una semana sin barrido). Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15).
13 proyectos · 12 con hallazgos · 60 señales · último barrido 2026-10-15

Nota: la carpeta de fichas es `estado/records/`, no `estado/fichas/`; se leyeron desde ahí.

## Qué cambió desde la corrida anterior
Sin cambios desde la corrida anterior. La instantánea previa (`snapshots/2026-10-15.json`) es de hoy: el diff da 0 cambios.

## Contradicciones y verdes sin sustento (5 proyectos declaran verde contra su propia evidencia)
| Proyecto | Declara | Señales que lo contradicen |
|---|---|---|
| PRY-202 Centro de distribución norte | verde (2026-10-13) | hitos cumplidos sin evidencia |
| PRY-203 Reposición automática | verde (2026-10-08) | 4 hitos cumplidos sin evidencia; avance declarado 74% frente a 100% que sostiene el plan |
| PRY-205 Pago con QR en caja | verde (2026-10-11) | 3 hitos sin evidencia; avance 46% vs 100%; sobrecosto proyectado 25,6% |
| PRY-206 Precios dinámicos | verde (2026-10-15) | hitos sin evidencia; 2 entregables de proveedor vencidos (233 y 128 días); 1 entregable sin evidencia de aceptación |
| PRY-211 Pronóstico de demanda | verde (2026-10-15) | atraso de 77 días (28,3%); replanificación no autorizada; compromiso vencido 15 días |

## Hitos cumplidos sin evidencia
Presente en 12 de 13 proyectos (todos salvo PRY-199). Los más antiguos: PRY-203 «Diseño de la experiencia aprobado» (444 días), PRY-209 (373), PRY-205 (333), PRY-208 (307), PRY-206 (261), PRY-200 (247).

## Proyectos en silencio (umbral 15 días)
Vacía. El mayor silencio es PRY-208 con 8 días.

## Desviaciones de tiempo y costo (umbral 10%)
| Proyecto | Señal |
|---|---|
| PRY-201 Programa de fidelización | +91 días (28,6%) vs original; cambio CC-01 sin línea base nueva |
| PRY-208 Domicilios en dos horas | +41 días (10,9%); replanificación no autorizada (41 días movidos, 0 autorizados) |
| PRY-211 Pronóstico de demanda | +77 días (28,3%); replanificación no autorizada |
| PRY-204 Cajas de autopago | proyección 11.623.833.685 vs 9.500.000.000 aprobado (+22,4%) |
| PRY-205 Pago con QR en caja | proyección 8.542.694.050 vs 6.800.000.000 aprobado (+25,6%) |

## Avance declarado por debajo de lo que el plan sostiene (brecha ≥ 10 puntos)
PRY-205 (54 pts), PRY-207 (35), PRY-200 (34), PRY-211 (29), PRY-210 (28), PRY-208 (27), PRY-203 (26), PRY-209 (26), PRY-201 (16). Lectura: o el avance está subdeclarado, o los hitos marcados como cumplidos no lo están; coincide con los hitos sin evidencia.

## Compromisos vencidos o sin fecha
- Vencidos: PRY-211 Beatriz Cuéllar (15 días), PRY-207 Laura Vélez (12), PRY-204 Andrés Lozano (7), PRY-208 Carlos Peña (7).
- Sin fecha: PRY-205 Laura Vélez («mandar el ajuste del presupuesto»), PRY-209 Jorge Medina.

## Proveedores
PRY-206, Retail Andino Consultores S.A.S.: «Licenciamiento de la plataforma» vencido 233 días y «Bolsa de horas de desarrollo» 128 días, ambos pendientes; «Configuración del catálogo» figura entregado sin evidencia de aceptación.

## Dependencias en riesgo
`compute` no devolvió ninguna señal de dependencia en riesgo.

## Gobierno
Los 13 proyectos figuran sin autoridad de aprobación identificada (`no_authority` = 13). 6 proyectos sin producto asociado: PRY-202, 203, 206, 209, 210, 211.

## Estado general
Ver `reportes/index.html` (por campo, con cadena de evidencia). Un solo proyecto, PRY-199 Iluminación LED en bodegas, sale sin señales.

## Necesito que confirmes
Ninguna pregunta cerrada hoy: la sesión es sin interfaz y la confirmación mensual no se aplicó en esta corrida.

## Informe generado
24 páginas en `/home/claude/banco/ronda-2/retail/espacio/reportes/`:
- `index.html` — por campo, con la cadena de evidencia completa. Para quien va a actuar (gerente de PMO, líderes de proyecto).
- `decisiones.html` — por decisión, solo lo que excede la facultad del gerente, con pregunta cerrada y consecuencia de no decidir. Para el patrocinador y el comité (próximo: 2026-10-22).
- Una página por proyecto (13).
El PDF sale de imprimir el HTML.

---
Criterio Portfolio 0.3.8 · fichas aplicadas: 13, fecha 2026-10-15 · campos inciertos: ver contradicciones arriba y la sección de cada proyecto · términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.8
