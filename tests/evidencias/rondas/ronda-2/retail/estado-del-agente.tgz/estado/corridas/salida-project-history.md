## Historia · PRY-211 Pronóstico de demanda · 2026-03-31 a 2026-10-15

**Leí:** 8 documentos entre 2026-03-31 y 2026-10-15 (acta de constitución, cronograma v1, cronograma v2, dos actas de recibo, solicitud de cambio CC-01, acta del comité del 13 de octubre e informe de avance del 15 de octubre).
**Trimestres sin un solo documento:** 2026-T2 (abril–junio) y 2026-T3 (julio–septiembre). Entre el 2026-03-31 y el 2026-10-04 la carpeta no tiene nada fechado.

### En una línea
El proyecto nació el 2026-03-31 con cierre en la línea base v1 el 2027-01-07. Después de seis meses sin documentos, el 2026-10-04 aparece el primer recibo (de un hito previsto para el 2026-06-03) y en la semana del 13 al 15 de octubre se escriben casi todos los papeles a la vez: CC-01 (pendiente de comité), el recibo del ERP, el cronograma v2 con cierre el 2027-03-25 y un informe que declara «Verde» con 31 % de avance. El plan se movió 77 días antes de que el comité autorizara nada, y el informe no menciona el atraso.

### Las cuatro cifras
| Replanificaciones | Atraso acumulado vs. original | Meses declarando sin sustento | Cambios de gobierno |
|---|---|---|---|
| 1 | 77 días (28,3 %) | No calculable: hay una sola declaración en la carpeta (2026-10-15) | 0 |

### Línea de tiempo
| Fecha | Documento | Qué cambió |
|---|---|---|
| 2026-03-31 | `00-gobierno/2026-03-31-acta-constitucion.docx` | Se aprueba el proyecto: 9.500.000.000 COP, inicio 2026-04-10, cierre 2027-02-04. Patrocinador Javier Hoyos, gerente Carlos Peña, Comité de Transformación Digital. |
| 2026-03-31 | `10-plan/2026-03-31-cronograma-v1.xlsx` | Línea base v1: 5 hitos, el último («Despliegue en la cadena») el 2027-01-07. El archivo trae los tres primeros hitos como «cerrado», algo que no pudo ser cierto en la fecha del archivo. |
| 2026-10-04 | `20-seguimiento/2026-10-04-acta-recibo-diseño-de-la-experiencia-aprobado.pdf` | Se recibe «Diseño de la experiencia aprobado», hito previsto para 2026-06-03: 123 días entre lo previsto y lo escrito. |
| 2026-10-13 | `20-seguimiento/2026-10-13-solicitud-cambio-cc-01.md` | Carlos Peña solicita ampliación de alcance: +77 días y +154.000.000 COP. Autorización: «Pendiente de presentación al comité». |
| 2026-10-13 | `30-reuniones/2026-10-13-comite-semanal.docx` | Asisten Carlos Peña y Javier Hoyos. Se anotan dos compromisos (uno vencido desde 2026-09-30). No consta que se tratara CC-01. |
| 2026-10-15 | `20-seguimiento/2026-10-15-acta-recibo-integración-con-el-erp.md` | Se recibe «Integración con el ERP», hito previsto para 2026-09-20: 25 días de distancia. |
| 2026-10-15 | `10-plan/2026-10-15-cronograma-v2.csv` | Línea base v2: «Despliegue en la cadena» pasa de 2027-01-07 a 2027-03-25. Sin motivo ni aprobación en el documento. |
| 2026-10-15 | `20-seguimiento/2026-10-15-informe-avance.pdf` | Estado declarado «Verde», avance 31 %. Dice que «se reprogramó el despliegue por el congelamiento de temporada de fin de año». |

### Replanificaciones
| Nº | Fecha | Fecha de cierre nueva | Motivo declarado | Documento que la aprobó |
|---|---|---|---|---|
| 1 | 2026-10-15 | 2027-03-25 (antes 2027-01-07; +77 días) | Solo en el informe de avance: congelamiento de temporada de fin de año. El cronograma v2 no trae motivo. | Ninguno. CC-01 pide +77 días, pero está pendiente y no menciona el congelamiento. El script marca los 77 días como movimiento de línea base sin autorización (autorizados: 0). |

Dos cosas que los documentos no resuelven y no las resuelvo yo: (a) si CC-01 y la replanificación son el mismo hecho (coinciden los 77 días, pero CC-01 los mide «sobre la línea base vigente», y la vigente ya incluye la v2); (b) el acta de constitución fija el cierre en 2027-02-04 y el cronograma v1 en 2027-01-07. El cálculo del atraso usa el cronograma v1 como original; el script no lo calcula contra la fecha del acta, así que no escribo esa cifra.

### Gobierno
| Fecha | Qué cambió | Documento |
|---|---|---|
| — | Sin cambios de patrocinador, gerente ni comité en los documentos leídos (Javier Hoyos, Carlos Peña y Comité de Transformación Digital aparecen igual en 2026-03-31 y 2026-10-13/15). | — |

Con un solo año de papeles y casi ninguno entre abril y septiembre, la ausencia de cambios no prueba que no los hubiera.

### Compromisos que se repitieron
| Doliente | Qué | Veces | Fechas prometidas |
|---|---|---|---|
| — | Ningún compromiso se repite: hay un solo acta de comité. | — | — |

Los dos de ese comité: Carlos Peña, «Entregar el punto 24», 2026-10-21 (abierto); Beatriz Cuéllar, «Entregar el punto 33», 2026-09-30 (vencido hace 15 días, sin evidencia de entrega). Se registró el 2026-10-13, ya vencido, y Beatriz Cuéllar no figura entre los asistentes.

### Desde cuándo lo declarado no se sostiene
No se puede fijar un deslizamiento: la carpeta tiene una sola declaración de estado (2026-10-15), no una serie. Lo que sí se ve:

- **Primer hito sin evidencia:** «Ambiente de pruebas certificado», previsto 2026-07-28, figura como cerrado en el cronograma v2 y no hay acta de recibo ni otro documento que lo respalde (79 días).
- **Lo declarado el 2026-10-15:** Verde y 31 % de avance. Con 3 de 5 hitos cerrados, el plan sustenta entre 60 % y 80 %: el avance declarado queda 29 puntos por debajo (el script lo marca «behind»). El 31 % tampoco cuadra con lo ejecutado en dinero (59,0 %). Los números del propio informe no concuerdan entre sí ni con el plan, y no sé cuál es el correcto.
- **Señales abiertas que el informe no recoge:** atraso de 77 días, replanificación sin autorizar, hito sin evidencia, compromiso vencido.
- El informe sí reporta la reprogramación del despliegue, pero lo hace como un hecho del periodo y no como desviación.

### Lecciones ancladas a un hecho
- **Hecho:** el hito «Diseño de la experiencia aprobado» (previsto 2026-06-03) se recibe por escrito el 2026-10-04; el de «Integración con el ERP» (previsto 2026-09-20), el 2026-10-15. **Efecto:** durante esos 123 y 25 días la carpeta no permitía comprobar que estuvieran cerrados.
- **Hecho:** el cronograma v2 mueve el cierre 77 días el 2026-10-15 mientras CC-01 sigue «pendiente de presentación al comité» desde el 2026-10-13. **Efecto:** la línea base cambió sin autorización registrada y el informe del mismo día declara Verde.
- **Hecho:** el compromiso de Beatriz Cuéllar vence el 2026-09-30 y se anota en el comité del 2026-10-13. **Efecto:** el compromiso entra al acta ya vencido y sin seguimiento previo.

### Pie de rigor
Cifras tomadas de `portafolio.py compute` (as_of 2026-10-15) y del texto de los 8 documentos. No sé qué se habló fuera de ellos. No atribuyo intención: que el plan se moviera sin autorización y que el informe diga Verde no dice quién decidió qué ni por qué; esa conversación es de personas y esta historia solo les da fechas. Dos documentos son PDF cuyo texto no pude verificar por hash de texto (`text_hash` nulo en el registro), aunque su contenido se leyó a la vista. Puedo llevar esta historia al comité o a un cierre si hay una decisión que salga de ella (por ejemplo, la suerte de CC-01 y de la línea base v2).
