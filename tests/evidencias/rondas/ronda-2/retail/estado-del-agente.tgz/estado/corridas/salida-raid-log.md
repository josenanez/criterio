**De qué documentos sale:** las 13 fichas de `estado/records/` (PRY-199 a PRY-211) con el RAID extraído de los informes de avance (md y pdf, tomados de la ficha; los pdf no los releí en esta corrida), y las actas y notas de reunión legibles: 8 md/txt y 5 docx. Escala usada: alta/media/baja; ninguna ficha trae probabilidad ni impacto.

## RAID — portafolio al 2026-10-15
16 riesgos · 0 supuestos · 15 incidencias · 4 dependencias (35 ítems; las 4 dependencias eran riesgos en la ficha; 1 incidencia la leí del informe porque la ficha la omitió)
35 sin doliente · 35 sin fecha de resolución · 1 no registrado formalmente · sin movimiento: no se puede medir (las fichas no guardan fecha de último movimiento)

### Necesitan decisión ahora
| Id | Tipo | Qué | Doliente | Desde | Por qué sube |
|---|---|---|---|---|---|
| PRY-201/I1 y PRY-206/I1 | Incidencia | Hallazgo de seguridad en los medios de pago | sin doliente | 2026-10-10 (201), 2026-10-15 (206) | Ya ocurrió y está en dos proyectos. PRY-206 lo reporta en verde. Afecta a más de un proyecto. No sé si es el mismo hallazgo: el texto es idéntico y ningún documento lo aclara. |
| PRY-199/I2, PRY-204/I1, PRY-208/I1 | Incidencia | La prueba de carga de temporada no alcanzó el umbral pactado y se repite | sin doliente | 2026-10-13 / 10-05 / 10-04 | Se repite con la temporada alta encima. PRY-199 la declara en verde con 20% de avance; PRY-208 está en rojo. |
| PRY-201/R1 + I2 y PRY-209/R1 + I2 | Riesgo materializado | "Congelamiento de cambios en temporada alta" sigue como riesgo, pero el mismo informe dice que el despliegue ya se reprogramó por el congelamiento | sin doliente | 2026-10-10 / 10-15 | El riesgo ya pasó. Hay que reclasificarlo a incidencia (también en PRY-200, 207, 210, que ya tienen la incidencia). |
| PRY-200/I1 | Incidencia | El equipo perdió dos semanas por rotación de un desarrollador clave | sin doliente | 2026-10-04 | Proyecto en rojo; ninguna ficha dice qué se hizo. |

### Detectados en reuniones, no registrados
| Qué | Tipo | Dicho en | Fecha |
|---|---|---|---|
| "El proveedor podría no llegar con el equipo completo para la siguiente fase; nadie lo anotó como riesgo" (PRY-205) | Dependencia del proveedor, sin código de proyecto (proveedor externo) | `PRY-205-pago-con-qr-en-caja/2026-10-15-notas-reunion.txt`, línea 7 | 2026-10-15 |

Las otras 12 actas solo traen compromisos; no encontré más riesgos dichos al pasar. No inventé ninguno. Las actas en pdf y los informes en pdf no se releyeron.

### Sin doliente o sin fecha
Los 35 ítems no tienen doliente. Los 16 riesgos y las 4 dependencias no tienen fecha ni probabilidad ni impacto. Las 15 incidencias tienen "desde", pero ninguna tiene fecha de resolución. Esto es un hallazgo; no relleno nada. Detalle en el registro completo.

### Dependencias en riesgo
| Id | Depende de | Confirmada | Qué pasó |
|---|---|---|---|
| PRY-199/D1 | Proveedor (última entrega) | No: declarada, no acordada | "No ha confirmado la fecha" (2026-10-13) |
| PRY-201/D1 | Proveedor (última entrega) | No | Igual (2026-10-10) |
| PRY-203/D1 | Proveedor (última entrega) | No | Igual (2026-10-08). El proyecto debía terminar el 2026-05-04 y se declara verde. |
| PRY-205/D1 | Proveedor (equipo completo para la siguiente fase) | No | Dicho en reunión 2026-10-15 |

Cruce entre proyectos: ninguna ficha declara una dependencia de otro proyecto del portafolio, así que no hay fechas movidas para cruzar. No puedo afirmar que no existan; solo que ningún documento las dice.

### Registro completo
Prob./Impacto: ninguna ficha los trae. "Último movimiento" muestra el corte del informe, porque la ficha no guarda fecha de movimiento. Doliente: sin doliente en todas las filas. Fecha: sin fecha en todas las filas.

Reclasificados: los cuatro "Dep" eran riesgos en la ficha. El proveedor es ajeno al proyecto (prueba rápida: dependencia). Los otros no se tocan salvo lo dicho arriba.

| Id | Tipo | Qué | Prob. | Impacto | Último mov. (corte) |
|---|---|---|---|---|---|
| PRY-199/R1 | Riesgo | Congelamiento de cambios en temporada alta | — | — | 2026-10-13 |
| PRY-199/D1 | Dependencia (reclasificada) | Proveedor sin confirmar fecha de la última entrega | — | — | 2026-10-13 |
| PRY-199/I1 | Incidencia | Validación con dos tiendas extendida una semana por conteo de inventario | — | — | 2026-10-13 |
| PRY-199/I2 | Incidencia | Prueba de carga de temporada no alcanzó el umbral; se repite | — | — | 2026-10-13 |
| PRY-200/R1 | Riesgo | Disponibilidad de los jefes de tienda para el piloto | — | — | 2026-10-04 |
| PRY-200/I1 | Incidencia | Dos semanas perdidas por rotación de un desarrollador clave | — | — | 2026-10-04 |
| PRY-200/I2 | Incidencia | Despliegue reprogramado por congelamiento de fin de año | — | — | 2026-10-04 |
| PRY-201/R1 | Riesgo | Congelamiento de cambios en temporada alta (materializado: ver arriba) | — | — | 2026-10-10 |
| PRY-201/D1 | Dependencia (reclasificada) | Proveedor sin confirmar fecha de la última entrega | — | — | 2026-10-10 |
| PRY-201/I1 | Incidencia | Hallazgo de seguridad en los medios de pago | — | — | 2026-10-10 |
| PRY-201/I2 | Incidencia (añadida: está en el informe 2026-10-10, no en la ficha) | Despliegue reprogramado por congelamiento de fin de año | — | — | 2026-10-10 |
| PRY-202/R1 | Riesgo | Concentración del conocimiento en una sola persona | — | — | 2026-10-13 |
| PRY-202/R2 | Riesgo | Disponibilidad de los jefes de tienda para el piloto | — | — | 2026-10-13 |
| PRY-203/D1 | Dependencia (reclasificada) | Proveedor sin confirmar fecha de la última entrega | — | — | 2026-10-08 |
| PRY-203/I1 | Incidencia | Validación con dos tiendas extendida una semana | — | — | 2026-10-08 |
| PRY-204/R1 | Riesgo | Disponibilidad de los jefes de tienda para el piloto | — | — | 2026-10-05 |
| PRY-204/I1 | Incidencia | Prueba de carga no alcanzó el umbral; se repite | — | — | 2026-10-05 |
| PRY-205/R1 | Riesgo | Disponibilidad de los jefes de tienda para el piloto | — | — | 2026-10-11 |
| PRY-205/D1 | Dependencia (no registrada formalmente) | Proveedor podría no llegar con el equipo completo | — | — | 2026-10-15 |
| PRY-205/I1 | Incidencia | Validación con dos tiendas extendida una semana | — | — | 2026-10-11 |
| PRY-206/R1 | Riesgo | Congelamiento de cambios en temporada alta | — | — | 2026-10-15 |
| PRY-206/R2 | Riesgo | Concentración del conocimiento en una sola persona | — | — | 2026-10-15 |
| PRY-206/I1 | Incidencia | Hallazgo de seguridad en los medios de pago | — | — | 2026-10-15 |
| PRY-207/R1 | Riesgo | Concentración del conocimiento en una sola persona | — | — | 2026-10-14 |
| PRY-207/I1 | Incidencia | Despliegue reprogramado por congelamiento de fin de año | — | — | 2026-10-14 |
| PRY-208/R1 | Riesgo | Disponibilidad de los jefes de tienda para el piloto | — | — | 2026-10-04 |
| PRY-208/R2 | Riesgo | Congelamiento de cambios en temporada alta | — | — | 2026-10-04 |
| PRY-208/I1 | Incidencia | Prueba de carga no alcanzó el umbral; se repite | — | — | 2026-10-04 |
| PRY-209/R1 | Riesgo | Congelamiento de cambios en temporada alta (materializado: ver arriba) | — | — | 2026-10-15 |
| PRY-209/I1 | Incidencia | Validación con dos tiendas extendida una semana | — | — | 2026-10-15 |
| PRY-209/I2 | Incidencia | Despliegue reprogramado por congelamiento de fin de año | — | — | 2026-10-15 |
| PRY-210/R1 | Riesgo | Concentración del conocimiento en una sola persona | — | — | 2026-10-14 |
| PRY-210/I1 | Incidencia | Despliegue reprogramado por congelamiento de fin de año | — | — | 2026-10-14 |
| PRY-211/R1 | Riesgo | Concentración del conocimiento en una sola persona | — | — | 2026-10-15 |
| PRY-211/R2 | Riesgo | Cambio en la regulación de datos personales que puede mover el alcance | — | — | 2026-10-15 |

### Lo que no sé
- Varias frases aparecen palabra por palabra en proyectos distintos (por ejemplo, la validación con dos tiendas en PRY-199, 203, 205 y 209). Las registro como están en cada informe. No puedo decir si son hechos distintos o texto copiado.
- No sé si algún ítem lleva dos períodos sin movimiento, porque la ficha no guarda esa fecha.
- No hay supuestos registrados en ningún proyecto. Eso no significa que no existan; nadie los levantó. Candidatos a preguntar: disponibilidad de la persona clave (PRY-202, 206, 207, 210, 211 reportan concentración de conocimiento) y que el piloto cuente con los jefes de tienda.
- Fuera del RAID, de pasada: hay compromisos vencidos sin cierre (PRY-204, 207, 208 y el de Beatriz Cuéllar en PRY-211, 2026-09-30), y las solicitudes de cambio de PRY-208 y PRY-211 siguen pendientes de comité. Eso lo cubren otros comandos.

### Siguiente paso (propuesto, nada asignado)
- Subir al comité del 2026-10-22: el hallazgo de seguridad (PRY-201 y 206), la prueba de carga (PRY-199, 204, 208) y la reclasificación de "congelamiento" a incidencia en PRY-201 y 209. Cada uno con la decisión formulada: quién será doliente y para cuándo.
- Doliente: propondría al gerente de cada proyecto (los nombres están en las fichas) para que lo confirme o lo cambie. No lo asigno.
- Formalizar o descartar la dependencia de PRY-205 con el proveedor.

*Rigor: lo que sale de los pdf viene de la ficha, no de una relectura. Los datos de las fichas son lo que cada informe declara, sin contraste con evidencia de recibo.*
