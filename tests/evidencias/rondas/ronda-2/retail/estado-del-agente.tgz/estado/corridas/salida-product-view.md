**Vista por producto: venta en línea.** Sale de las fichas en `estado/records/` y del cálculo `portafolio.py compute`, con fecha de corte 2026-10-15. Términos vigentes (v1.1), aceptados por José Francisco Ñáñez el 2026-10-15.

## Productos al 2026-10-15

| Producto | Proyectos | Con alertas | Fecha más tardía | Aprobado | Comprometido |
|---|---|---|---|---|---|
| venta en línea | 1 (PRY-200) | 1 (4 alertas) | 2027-01-19 (PRY-200) | COP 800.000.000 | COP 407.557.334 |

**Venta en línea tiene un solo proyecto (PRY-200, Tienda en línea).** La vista por producto no aporta más que la ficha del proyecto, así que no armo sección de producto. Lo que sigue es lo que hay que ver en ese proyecto:

- **Avance declarado frente al plan:** declara 41 %, y los hitos cumplidos (3 de 4) respaldan entre 75 % y 100 %. La diferencia es de 34 puntos, hacia atrás: el avance declarado está por debajo del plan.
- **Hitos dados por cumplidos sin evidencia (3):** «Diseño de la experiencia aprobado» (vencía 2026-02-10, 247 días), «Ambiente de pruebas certificado» (2026-06-04, 133 días) e «Integración con el ERP» (2026-09-27, 18 días). La ficha no tiene ninguna fuente de evidencia; solo declaraciones.
- **Estado declarado:** rojo, informe del 2026-10-04 (11 días). El informe no explica las dos señales anteriores.
- **Fecha:** 2027-01-19, sin desviación contra la línea base original ni contra la vigente y sin replanificaciones. Ojo: hay tres hitos dados por cumplidos sin sustento, así que «sin desviación» es lo que declara el plan, no algo comprobado.
- **Dinero (las cuatro cifras están, 1 de 1 proyecto):** aprobado COP 800.000.000; comprometido COP 407.557.334 (50,9 %); ejecutado COP 204.484.564 (25,6 %); proyección COP 822.388.023 (2,8 % por encima de lo aprobado, bajo el umbral de 10 %).
- **Dependencias internas:** ninguna, porque el producto tiene un solo proyecto. El cálculo tampoco registra dependencias declaradas de PRY-200 con otros proyectos.
- **Datos que faltan o están viejos:** falta la autoridad que aprueba y la fase. Los campos de identidad, plan y el monto aprobado salen de un documento del 2025-10-09, con 12 meses de antigüedad.

### Proyectos sin producto declarado
Hay 6 de 13 proyectos sin `identity.product`:

| Proyecto | Área dueña |
|---|---|
| PRY-202 Centro de distribución norte | Logística |
| PRY-203 Reposición automática | Finanzas |
| PRY-206 Precios dinámicos | Mercadeo |
| PRY-209 Migración del ERP | Tecnología |
| PRY-210 Etiquetas electrónicas de precio | Tecnología |
| PRY-211 Pronóstico de demanda | Comercio electrónico |

Consecuencia: nadie puede responder por el conjunto al que sirven. Sobre venta en línea, dos casos merecen que alguien los mire, y no los asigno yo. PRY-211 viene del área «Comercio electrónico». PRY-209 (Migración del ERP) toca el hito «Integración con el ERP» de PRY-200, que está declarado como cumplido sin evidencia. Ninguna ficha declara esa relación; es una pregunta, no un hallazgo.

**Qué no sé:** a qué producto sirve cada uno de esos 6 proyectos, y si PRY-200 depende de PRY-209 o de PRY-211. Hay que confirmarlo con quien responde por cada uno.

**Decisión que se puede llevar al comité (2026-10-22):** una sola, de gobierno: declarar el producto de los 6 proyectos sin producto, empezando por PRY-209 y PRY-211. No hay dependencias internas sin confirmar que llevar como punto de producto.

---
*Rigor:* cifras copiadas del cálculo de la corrida, sin redondear lo que el script da con decimales. Lo no calculado no se escribe. Borrador de trabajo, no decisión ni asesoría; la verificación contra los documentos citados es de quien lo lea.
