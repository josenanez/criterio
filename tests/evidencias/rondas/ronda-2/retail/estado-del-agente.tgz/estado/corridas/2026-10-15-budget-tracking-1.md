# Corrida del 2026-10-15 · budget-tracking

13 proyectos · 27 s · 60 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 29 |
| `progress_vs_plan` | 9 |
| `declared_vs_evidence` | 5 |
| `commitment_overdue` | 4 |
| `variance_time` | 3 |
| `variance_cost` | 2 |
| `commitment_undated` | 2 |
| `vendor_deliverable_late` | 2 |
| `rebaseline_unauthorized` | 2 |
| `change_without_baseline` | 1 |
| `vendor_accepted_without_evidence` | 1 |

Informe de presupuesto PRY-205: proyección excede aprobado en 25.6%; comprometido/ejecutado/proyección son declaraciones sin evidencia; 3 hitos met sin evidencia; no declaró autoridad, fase ni desviación en pesos.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

Fuentes: ficha PRY-205 (estado/records/PRY-205.json) y cifras recalculadas con `portafolio.py compute` al 2026-10-15. Documentos: acta de constitución (2025-08-16), cronograma v1 (2025-08-16), informe de avance (2026-10-11), notas de reunión (2026-10-15).

## Presupuesto — PRY-205 Pago con QR en caja al 2026-10-15
**Moneda:** COP (única)

| | Monto (COP) | % del aprobado | Fuente | Fecha |
|---|---|---|---|---|
| Aprobado | 6.800.000.000 | 100 % | Acta de constitución (documento) | 2025-08-16 |
| Comprometido | 2.821.990.996 | 41.5 % | Informe de avance (declaración) | 2026-10-11 |
| Ejecutado | 1.683.942.028 | 24.8 % | Informe de avance (declaración) | 2026-10-11 |
| Proyección al cierre | 8.542.694.050 | excede el aprobado en 25.6 % | Informe de avance (declaración) | 2026-10-11 |

**Disponible real** (aprobado menos comprometido): 3.978.009.004 COP

Comprometido, ejecutado y proyección son declaraciones del informe de avance: ninguna cifra de dinero tiene soporte en un documento de evidencia (contrato, factura, extracto). Solo el aprobado sale de un documento formal.

### Contra la línea base
| | Original | Vigente | Desviación |
|---|---|---|---|
| Presupuesto aprobado | 6.800.000.000 | 6.800.000.000 | 0 (sin cambios registrados) |
| Proyección vs. aprobado | | | +25.6 % |

Replanificaciones de presupuesto: 0. No hay solicitudes de cambio registradas. La proyección (2026-10-11, 4 días de antigüedad) no es más vieja que el último movimiento de presupuesto, porque no hay ninguno posterior al acta.

### Ejecución frente a avance
Ejecutado 24.8 % · Hitos cumplidos 3 de 3 (declarados) · Lectura: el dinero ejecutado no cuadra con un plan que da por cumplido el 100 %, y el propio informe declara 46 % de avance, 54 puntos por debajo de lo que sustentan los hitos. Los tres hitos figuran "met" sin evidencia de cumplimiento (vencidos hace 333, 251 y 169 días). La fecha final del plan (2026-04-29) ya pasó y no hay replanificación registrada. Lo más probable es que los hitos estén mal marcados, no que el proyecto esté terminado; esto no se puede confirmar con los documentos.

### Alertas
- **Proyección excede el aprobado en 25.6 %** (8.542.694.050 frente a 6.800.000.000), sobre el umbral de 10 %.
- **Avance desalineado:** 46 % declarado frente a 100 % que sustentan los hitos (54 puntos).
- **Hitos "cumplidos" sin evidencia:** Diseño de la experiencia aprobado, Ambiente de pruebas certificado, Integración con el ERP.
- **Estado declarado "verde"** (informe del 2026-10-11) sin explicar ninguna de las tres señales anteriores.
- **Compromiso sin fecha:** Laura Vélez, "Mandar el ajuste del presupuesto" (notas de reunión 2026-10-15).
- Comprometido (41.5 %) está por debajo del umbral de 90 %: no hay alerta por ese concepto.

### Sin dato
- Autoridad que aprueba y fase del proyecto: no declaradas en ningún documento.
- Cifras de comprometido, ejecutado y proyección sin documento de evidencia.
- Desviación de la proyección en pesos: el cálculo no la entrega y no se escribe.
- Detalle por proveedor: el proyecto no tiene proveedores registrados.
- Tasa de cambio: no aplica, una sola moneda.
- Datos de identidad y de aprobado con 14 meses de antigüedad (umbral: 12).

### Siguiente paso
La proyección excede el aprobado: puedo preparar la solicitud de cambio de presupuesto (`/change-control`). Hoy el compromiso de Laura Vélez de enviar el ajuste no tiene fecha.

---
Pie de rigor: borrador de trabajo, no decisión ni asesoría. Las cifras salen de los documentos citados y del cálculo del script; la verificación es de quien lee. Lo hablado fuera de los documentos no está aquí.
