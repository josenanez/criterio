## Proveedores — PRY-206 Precios dinámicos al 2026-10-15

**Sale de:** `00-gobierno/2025-11-02-contrato-ct-451.md`, `20-seguimiento/2026-09-23-factura-ct-451.md`, `20-seguimiento/2026-10-04-acta-recibo-ambiente-de-pruebas-certificado.pdf`, `20-seguimiento/2026-10-14-acta-recibo-piloto-en-tiendas.pdf`, `20-seguimiento/2026-10-15-informe-avance.pdf`, `30-reuniones/2026-10-13-comite-semanal.docx` y la salida de `portafolio.py compute`. Términos vigentes (0.3.8), aceptados por José Francisco Ñáñez el 2026-10-15.

### Retail Andino Consultores S.A.S. — contrato CT-451
**Vigencia:** sin dato · **Preaviso de no renovación:** sin dato · **Vence el:** sin dato

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento de la plataforma | 2026-02-24 | pendiente (contrato) | ninguna | no |
| Bolsa de horas de desarrollo | 2026-06-09 | pendiente (contrato) | ninguna | no |
| Configuración del catálogo | 2026-09-21 | recibido (contrato) | ninguna: sin acta de recibo | 543.383.423 COP (FV-1451, 2026-09-23) |

Cada entregable vale 543.383.423 COP según el contrato. Facturado total del proveedor: 543.383.423 COP.

### Dónde no cuadra
| Qué | Dice el contrato | Dice la evidencia | Fuentes |
|---|---|---|---|
| Configuración del catálogo facturado | Se factura "contra acta de recibo firmada por el gerente del proyecto" | No hay acta de recibo de este entregable. Las dos actas de la carpeta son de hitos del proyecto (ambiente de pruebas, piloto en tiendas), no de CT-451. | contrato CT-451; factura FV-1451; carpeta 20-seguimiento |
| Estado "recibido" | La tabla del contrato lo marca "recibido", pero el contrato está firmado el 2025-11-02 | Un contrato de esa fecha no prueba un recibo de septiembre de 2026. Es una declaración, no evidencia. | contrato CT-451 |

### Sin evidencia de recibo
| Entregable | Marcado como | Desde |
|---|---|---|
| Configuración del catálogo | delivered / "recibido" | sin fecha de recibo; la factura es del 2026-09-23 |

### Atrasados (fecha pasada, sin evidencia, sin declarar entrega)
| Entregable | Comprometido | Días de atraso |
|---|---|---|
| Licenciamiento de la plataforma | 2026-02-24 | 233 |
| Bolsa de horas de desarrollo | 2026-06-09 | 128 |

### Compromisos del proveedor vencidos
Ninguno. El único compromiso del comité del 2026-10-13 es de Laura Vélez, "Entregar el punto 24", para el 2026-11-08, abierto. El acta no dice a qué organización pertenece ni qué es el "punto 24", así que no puedo atribuirlo al proveedor.

### Contexto relevante
- El informe de avance del 2026-10-15 declara el proyecto en **verde**, con 78 % de avance. El script no lo da por explicado: quedan sin cubrir los atrasos del proveedor y dos hitos marcados como cumplidos sin evidencia ("Diseño de la experiencia aprobado", 2026-01-27, y "Integración con el ERP", 2026-06-28).
- Dos de tres entregables del proveedor están atrasados 233 y 128 días y nadie los declara en riesgo.
- El proyecto termina el 2026-11-27.

### Sin dato
- Vigencia, fecha de terminación, renovación automática y preaviso de CT-451: el contrato no los trae. No puedo decir si hay un preaviso por vencer antes del cierre del proyecto (2026-11-27). Hay que pedir el contrato completo o sus anexos.
- Acta de recibo de "Configuración del catálogo", o cualquier correo de aceptación.
- Si los dos entregables pendientes (licenciamiento y bolsa de horas) tienen alguna prórroga o renegociación: no hay ningún documento que lo diga.

### Lo que sigue
Hay un entregable facturado sin el acta que el contrato exige para pagarlo, y es el único con factura. Ofrezco llevarlo al comité del 2026-10-22 como decisión: retener el pago hasta el acta, o aportar el acta si existe fuera de la carpeta. También conviene pedir a Rubén Cárdenas (gerente) que aclare los dos entregables atrasados.

*Pie de rigor: cifras tomadas de `portafolio.py compute` y de los documentos citados. No vi ningún documento de aceptación del proveedor; lo que no está en la carpeta no lo sé. Es un borrador de trabajo, y la verificación contra los documentos es de quien lo lee.*
