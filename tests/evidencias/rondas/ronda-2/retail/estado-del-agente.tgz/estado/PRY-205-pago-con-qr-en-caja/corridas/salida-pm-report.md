# Pago con QR en caja (PRY-205) — semana al 2026-10-15

**Declara el gerente:** _sin declaración_ · _sin avance_ · _sin fecha_
**Sustento documental:** no se puede juzgar: sin declaración no hay contra qué contrastar
**Lo que el semáforo no explica:** no aplica sin semáforo declarado. Señal abierta: 1 compromiso sin fecha (Laura Vélez).

> Pregunta de declaración: ¿qué estado declara Gustavo Neira, y con qué avance? Sesión sin interfaz, nadie respondió, y este informe no propone un estado. La línea queda en blanco a propósito.

## Qué cambió esta semana
Nada que comparar. Esta es la primera corrida con snapshot (2026-10-15) y `diff` devuelve 0 cambios. No es estabilidad: es que no hay corrida anterior. El próximo informe ya tendrá contra qué comparar.

## Lo que sigue igual y sigue mal
Sin histórico no se pueden contar días. Lo que ya está mal hoy:

| Qué | Desde | Días así |
|---|---|---|
| Sin línea base registrada | no consta | sin dato |
| Riesgo dicho en reunión y no registrado: el proveedor podría no llegar con el equipo completo a la siguiente fase | 2026-10-15 | 0 |
| Compromiso de Laura Vélez sin fecha («la otra semana») | 2026-10-15 | 0 |

## Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | sin dato | sin dato | no calculable |
| Presupuesto | sin dato | sin dato | no calculable |

Replanificaciones: 0 registradas. Sin línea base, la cifra no prueba que el plan no se haya movido.

### Hitos de las próximas cuatro semanas
No hay hitos en la ficha. Sin dato.

## Las cifras
| Aprobado | Comprometido | Ejecutado | Proyectado | Disponible real |
|---|---|---|---|---|
| sin dato | sin dato | sin dato | sin dato | sin dato |

El disponible real es aprobado menos comprometido. Sin ninguna de las dos cifras no se puede calcular.

## Abierto
**Reprogramados:** Beatriz Cuéllar · «Entregar el punto 1» · 1 vez (2026-11-08 → 2026-11-22; 14 días de corrimiento en 4 días de calendario). Bajo el umbral de 3. Ningún documento define qué es «el punto 1».
**Vencidos sin evidencia:** ninguno.
**Sin fecha:** Laura Vélez · Mandar el ajuste del presupuesto · dicho el 2026-10-15.
**Próximo a vencer:** Óscar Ramírez · Revisión con el proveedor · 2026-10-25 (10 días).
**RAID sin movimiento:** 1 riesgo sin registrar (equipo del proveedor), 0 días.
**Proveedor:** sin entregables ni contrato en la ficha. El informe del 2026-10-11 dice que el proveedor entregó el componente de integración, pero no hay entregable que lo respalde.

## Lo que necesito de alguien
- **Gustavo Neira:** declarar estado y avance.
- **Gustavo Neira:** registrar el riesgo del proveedor en el RAID y decidir quién lo lleva.
- **Laura Vélez:** poner fecha al ajuste del presupuesto.
- **Beatriz Cuéllar:** aclarar qué es «el punto 1».
- Nada excede la autoridad del gerente por ahora.

## Lo que no se sabe
**Sin dato:** línea base de fechas y de presupuesto, las cuatro cifras de dinero, hitos, entregables del proveedor y declaración del gerente. Los campos de identidad vienen del acta de 2025-08-16 (14 meses).
**Silencio:** último documento hace 0 días (2026-10-15) · última reunión hace 0 días (notas del 2026-10-15; comité semanal del 2026-10-11).

---
Fuente: ficha `records/PRY-205.json`, snapshot 2026-10-15. Campos sin dato: los 4 de identidad vencidos (+ dinero, línea base e hitos ausentes). Términos vigentes (v1.1, aceptados 2026-10-15 por José Francisco Ñáñez): https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.8
