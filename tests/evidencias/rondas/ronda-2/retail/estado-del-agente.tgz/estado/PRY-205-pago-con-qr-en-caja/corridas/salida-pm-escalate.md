Términos: vigentes (aceptados por José Francisco Ñáñez el 2026-10-15, versión 0.3.8); no hubo que volver a pedirlos. Sin argumento sobre qué escalar, tomo lo ya marcado como escalable: el presupuesto, que `/pm-agenda` dejó señalado.

## Para decisión — Pago con QR en caja (PRY-205) · 2026-10-15

### Punto 0 — Primero: el acta no declara qué puede decidir el gerente

**Pregunta cerrada:** ¿El Comité de Expansión confirma por escrito, como anexo al acta del 2025-08-16, el umbral de presupuesto, fechas y alcance que Gustavo Neira decide solo y el que sube al comité? (sí / no / «umbral X»)

**Quién decide:** Camilo Beltrán, patrocinador, con el Comité de Expansión (el acta los nombra, pero no dice quién fija la autoridad del gerente) · **Si no se decide hoy:** el comité siguiente es el 2026-10-29 (configuración del proyecto); hasta entonces cada punto de abajo se sube sin saber si hacía falta. No hay en los documentos una fecha de vencimiento mayor; no la invento.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Se declara el umbral por escrito | Sin efecto | Una línea en el acta del 29-oct | Ninguno |
| B. Todo cambio de monto, fecha o alcance sube al comité | Sin efecto | Cada cambio espera comité semanal | Ninguno directo |
| C. No se declara | Sin efecto | Los puntos vuelven con un «eso lo decide usted» | No cuantificable con lo que hay |

**Recomiendo:** A — es gratis y deja de convertir cada punto en una discusión sobre quién puede decidirlo.

### Punto 1 — Presupuesto: la proyección supera lo aprobado

**Pregunta cerrada:** ¿Se aprueba subir el presupuesto de COP 6.800.000.000 a COP 8.542.694.050 (+COP 1.742.694.050, +25,6 %), o se mantiene en COP 6.800.000.000 y el gerente vuelve con el alcance recortado?

**Quién decide:** el Comité de Expansión, que aprobó el monto original el 2025-08-16; sobre si le toca al gerente, el acta no dice (ver Punto 0) · **Si no se decide hoy:** no consta en los documentos una fecha límite. Lo que sí consta: el cierre comprometido era el 2026-06-10, ya pasó hace 4 meses, y el informe del 2026-10-11 sigue en Verde.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Subir el aprobado a COP 8.542.694.050 | Se mantiene (3 componentes) | No cambia por sí misma; la fecha de cierre vigente no consta | +COP 1.742.694.050 |
| B. Mantener COP 6.800.000.000 y recortar | **No está estimado**: cuáles componentes salen no está en ningún documento | **No está estimado** | Tope en 6.800.000.000; los COP 1.683.942.028 ya ejecutados y los 2.821.990.996 comprometidos no se recuperan |

**Recomiendo:** que el comité no decida el monto hoy: pida primero el ajuste de presupuesto que Laura Vélez «queda de mandar la otra semana» (sin fecha concreta) y una fecha de cierre vigente. Decidir la opción A con la proyección sola es aprobar una cifra sin su desglose. La razón de fondo es que la opción B no se puede costear con lo que hay.

### A quién alcanza
No se calculó. El comando necesita un cambio de fecha en días (`--days`) y no se dio; este punto es de monto, no de fecha. El acta declara **«Ninguna declarada»** como dependencias, así que el cálculo, aun con días, partiría de un cuadro vacío; eso no prueba que no haya dependencias. Tampoco se sabe cuántos días se mueve algún otro proyecto.

### Mis hitos por los que pasa
No aplica a este punto. El cronograma v1 (2025-08-16) solo tiene tres hitos, todos cerrados (2025-11-16, 2026-02-06, 2026-04-29) y ninguno de cierre; la fecha de cierre 2026-06-10 está en el acta, sin hito en el plan.

### Lo que NO escala
- **Beatriz Cuéllar, «entregar el punto 1»:** reprogramado 2 veces (8-nov → 22-nov); el umbral es tres. Se vigila; si se mueve otra vez, escala.
- **Riesgo del proveedor que no llegue con el equipo completo:** se dijo el 2026-10-15 y nadie lo registró. Registrarlo lo puedes hacer tú en el RAID; no excede tu autoridad.
- **Óscar Ramírez, revisión con el proveedor para el 2026-10-25:** aún no vence.

### De dónde sale esto
- Autoridad no declarada, presupuesto aprobado, fechas, dependencias, comité y patrocinador: `00-gobierno/2025-08-16-acta-constitucion.docx` (el acta no tiene ninguna sección de autoridad del gerente).
- Proyección, comprometido, ejecutado y estado Verde: `20-seguimiento/2026-10-11-informe-avance.md`.
- Compromiso de Laura Vélez, reprogramación de Beatriz Cuéllar y riesgo del proveedor: `2026-10-15-notas-reunion.txt`; la fecha anterior (8-nov): `30-reuniones/2026-10-11-comite-semanal.md`.
- Hitos: `10-plan/2025-08-16-cronograma-v1.xlsx`.
- Próximo comité 2026-10-29: `.criterio/proyecto/PRY-205/config.json`.

### Lo que no sé
Qué umbral de autoridad tiene el gerente; cuál es la fecha de cierre vigente; cómo se compone la proyección; qué costaría recortar alcance; si hay dependencias con otros proyectos. Ningún documento lo dice.
