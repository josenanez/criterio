# Acta — Pago con QR en caja (PRY-205) · 2026-10-15
**Asistieron:** Beatriz Cuéllar, Elena Duarte, Gustavo Neira, Laura Vélez, Óscar Ramírez · **Fuente:** `2026-10-15-notas-reunion.txt` · **Ausentes con tema en agenda:** no hay agenda en el expediente; no puedo decirlo. (El patrocinador, Camilo Beltrán, no figura entre los asistentes.)

## Compromisos
| Quién | Qué | Para cuándo | |
|---|---|---|---|
| Beatriz Cuéllar | Entregar el punto 1 | 2026-11-22 | **Reprogramado, 1 vez.** Antes: 2026-11-08 (`30-reuniones/2026-10-11-comite-semanal.md`). Cita: «lo de "entregar el punto 1" no alcanzó, se compromete para el 22/11/2026» |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-25 | Cita: «revisión con el proveedor, queda para el 2026-10-25» |

### Sin fecha
| Quién | Qué |
|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto. Dijo «la otra semana», sin día; queda como `due_date: no_declarada`. Cita: «Laura Vélez queda de mandar el ajuste del presupuesto la otra semana» |

## Decisiones
Ninguna. Las notas no registran ninguna decisión con quien la tomó y lo que se descartó.

## Quedó sin decidir
Las notas no dicen nada que haya quedado explícitamente abierto. No registro nada aquí para no inventarlo.

## Intenciones sin doliente
Ninguna.

## Dicho al pasar y no registrado
| Qué | Quién lo dijo | Categoría | Ya estaba en el RAID |
|---|---|---|---|
| El proveedor podría no llegar con el equipo completo para la siguiente fase | No atribuido: las notas dicen «se comentó» | Riesgo (dependencia del proveedor) | **No.** El informe de avance del 2026-10-11 lista un solo riesgo (disponibilidad de los jefes de tienda para el piloto), y las notas dicen «nadie lo anotó como riesgo» |

## Cerrado en esta reunión
Nada. (Sección omitida: no hay documento que cierre algo.)

## Lo que esta reunión contradice
Ningún campo de la ficha. La reunión no cambió patrocinador, gerente, fechas de cierre ni comité.

## Sin resolver de la transcripción
- «la otra semana» (Laura Vélez): no se sabe a qué fecha corresponde, y no la calculo.
- «próxima reunión en dos semanas»: sin fecha ni convocante. El comité configurado tiene la próxima fecha el 2026-10-29; coincide con «dos semanas» desde el 15/10, pero las notas no lo dicen.
- Elena Duarte aparece como asistente, pero las notas no le atribuyen ninguna intervención.
- «el punto 1» no se define en las notas ni en el comité del 2026-10-11, así que no sé qué es lo que se viene corriendo.

## Recálculo (`portafolio.py compute`)
- Compromisos vencidos: 0. Sin fecha: 1 (Laura Vélez). Reprogramados señalados por el umbral (3 veces): 0; el de Beatriz va en 1.
- Sin línea base en la ficha.
- Campos de identidad con 14 meses de antigüedad (acta de constitución, 2025-08-16).

*Esta acta sale en la conversación y no se guardó en la carpeta de reuniones. Guárdala tú si la das por buena.*
