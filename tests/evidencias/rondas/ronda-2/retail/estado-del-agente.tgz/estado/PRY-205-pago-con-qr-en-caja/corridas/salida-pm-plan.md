# Plan — Pago con QR en caja (PRY-205) · borrador del 2026-10-15
**Desde:** acta de constitución del 2025-08-16 (`00-gobierno/2025-08-16-acta-constitucion.docx`) · **Criterio de éxito:** «Pago con QR en caja en producción y medido.» (acta, sección Criterio de éxito)

*Términos: vigentes, aceptados por José Francisco Ñáñez el 2026-10-15 (comprobante ya registrado; no hubo que repetirlo). Sesión sin interfaz: las preguntas se resolvieron con la respuesta sugerida.*

*Contexto que cambia la lectura de este borrador: el acta tiene más de un año y el proyecto ya está en ejecución (informe de avance del 2026-10-11: 46 %, estado declarado Verde). La fecha de cierre del acta, 2026-06-10, ya pasó. Esto es, en la práctica, una replanificación sobre un acta que quedó corta, no un plan inicial.*

## Lo que le falta al acta
| Qué | Consecuencia de planificar sin eso |
|---|---|
| **Alcance vacío.** Dice «Componente 1 / Componente 2 / Componente 3», sin nombrar ninguno. | No hay lista de entregables de la cual descomponer. Cualquier WBS completa sería inventada. Además, el compromiso de Beatriz Cuéllar «entregar el punto 1» (comité 2026-10-11) no se puede ubicar en ningún componente. |
| **Fuera de alcance vacío.** Dice «Lo que otro proyecto cubre», sin nombrar el proyecto. | No se sabe qué frontera tiene este proyecto con otros (hay 13 proyectos en la carpeta del portafolio, p. ej. PRY-204 cajas de autopago). No lo cruzo por conjetura. |
| **Objetivo genérico.** «Entregar pago con qr en caja para Abastecimiento.» | No dice en cuántas cajas/tiendas, ni qué se mide. |
| **Criterio de éxito sin umbral.** «En producción y medido», sin qué se mide ni con qué valor se da por logrado. | «Medido» no se puede aceptar ni rechazar: nadie sabe cuándo está cumplido. Es el nodo terminal más importante y el menos definido. |
| **Sin autoridad declarada.** El acta no dice qué puede decidir el gerente y qué debe subir. | No sé qué puedes decidir al planificar y qué hay que escalar (cambio de fechas, presupuesto, alcance). |
| **Sin dependencias.** «Ninguna declarada.» | Contradice los documentos: hay un proveedor que entrega componentes (informe 2026-10-11) y un concepto de Jurídica. Un plan sin dependencias declaradas esconde justo las que hoy mueven las fechas. |
| **Fechas ya vencidas.** Cierre comprometido 2026-06-10. | El proyecto sigue abierto cuatro meses después. No hay línea base vigente distinta de la original en lo que leí. |

Patrocinador (Camilo Beltrán), comité (Comité de Expansión) y presupuesto (6.800.000.000 COP) sí están. No falta el patrocinador.

## WBS
Solo hay un entregable terminal que el acta sostiene. El resto sale de otros documentos y va como **supuesto**; no lo promuevo a «del acta».

Quién acepta: el acta **no lo dice** para ningún nodo. No lo asigno (el patrocinador es Camilo Beltrán, pero que sea quien acepta cada entregable es una suposición mía y no la presento como hecho).

| # | Entregable | Quién lo acepta | De dónde sale | Duración |
|---|---|---|---|---|
| 1 | Pago con QR en caja en producción | Sin definir | **Del acta** (criterio de éxito) | vacía |
| 2 | Medición del pago con QR en producción (qué se mide y umbral) | Sin definir | **Del acta** («y medido»), contenido **sin definir** | vacía |
| 3 | Diseño de la experiencia aprobado | Sin definir | Supuesto: `10-plan/2025-08-16-cronograma-v1.xlsx` lo lista como hito, cerrado, línea base 2025-11-16 | ya cerrado (cronograma v1) |
| 4 | Ambiente de pruebas certificado | Sin definir | Supuesto: cronograma v1, hito cerrado, línea base 2026-02-06 | ya cerrado (cronograma v1) |
| 5 | Integración con el ERP | Sin definir | Supuesto: cronograma v1, hito cerrado, línea base 2026-04-29 | ya cerrado (cronograma v1) |
| 6 | Componente de integración del proveedor, aceptado | Sin definir | Supuesto: informe de avance 2026-10-11 («entregó el componente de integración, pendiente de aceptación») | vacía |
| 7 | Validación en tiendas piloto (dos tiendas mencionadas) | Sin definir | Supuesto: informe de avance 2026-10-11 («validación con dos tiendas») | vacía |
| 8 | Concepto de Jurídica sobre términos de uso | Sin definir | Supuesto: informe de avance 2026-10-11 (ya recibido) | ya recibido, según el informe |
| 9 | «Punto 1» del compromiso de Beatriz Cuéllar | Sin definir | Sin definir: no se sabe a qué entregable corresponde | vacía |
| 10 | Componentes 1, 2 y 3 del alcance | Sin definir | **Sin definir**: el acta los nombra y no los describe | vacía |

Los hitos 3–5 aparecen cerrados en el cronograma v1, pero no vi evidencia de recibo (acta de aceptación) para ninguno. Los dejo como «cerrado según el cronograma», no como aceptados.

## Orden
Qué necesita qué, sin fechas. Lo sostenido por documentos:
- 3 → 4 → 5: el cronograma v1 los lista en ese orden; no dice que uno dependa del otro. Orden de lista, no dependencia confirmada.
- 5 (integración ERP) y 6 (componente del proveedor) → 7 (validación en tiendas): supuesto, una validación en tienda necesita integración funcionando. Nadie lo escribió.
- 8 (Jurídica) → 1 (producción): supuesto, los términos de uso deberían estar resueltos antes de salir.
- 7 → 1 → 2: no se mide en producción lo que no está en producción.
- 10 (componentes 1–3): no se puede ordenar; no se sabe qué son.

## Supuestos sobre los que está construido
| Supuesto | Qué pasa si resulta falso |
|---|---|
| Los hitos del cronograma v1 (3, 4, 5) corresponden a entregables reales y están aceptados | Si no hubo aceptación, hay trabajo «cerrado» sin dueño que lo recibiera y el 46 % reportado se sostiene sobre menos de lo que parece. |
| El «componente de integración» del proveedor (6) es parte del alcance de este proyecto | Si pertenece a otro proyecto, el pendiente de aceptación no es de este plan. |
| La validación en tiendas (7) debe preceder a producción | Si el despliegue puede ser por oleadas sin validación previa, el orden cambia. |
| Jurídica (8) no tiene más condicionamientos pendientes | Si hay ajustes a los términos de uso, producción no puede salir. |
| El proveedor llega con el equipo completo a la siguiente fase | Comentado en la reunión del 2026-10-15 («podría no llegar con el equipo completo… nadie lo anotó como riesgo»). Si falla, retrasa 6 y 7. Pasa a riesgos en cuanto el plan se apruebe, con doliente. |
| Disponibilidad de los jefes de tienda para el piloto | Ya está como riesgo abierto en el informe 2026-10-11. Si falla, se frena 7. |

## Sin definir
| Qué | Quién lo define |
|---|---|
| Qué son los Componentes 1, 2 y 3 | Sin determinar por los documentos; el acta la firmó el patrocinador (Camilo Beltrán) y el comité (Comité de Expansión) |
| Qué es el «punto 1» de Beatriz Cuéllar | Beatriz Cuéllar / Gustavo Neira |
| Qué se mide en «medido» y con qué umbral | Patrocinador, Camilo Beltrán (suposición: el acta no lo dice) |
| Quién acepta cada entregable | El acta no lo dice; lo define quien tenga la autoridad (no declarada) |
| Qué cubre «otro proyecto» (fuera de alcance) | Sin determinar |
| Autoridad del gerente al planificar | Patrocinador / comité |
| Cuántas tiendas y cajas entran | Sin determinar |

## Proyectos análogos
Ninguno a la vista. La configuración de PRY-205 no apunta a una carpeta de fichas de la PMO y en `estado/` solo existe el estado de este proyecto; no encontré fichas de otros proyectos. Hay documentación de otros 12 proyectos en la carpeta, pero sin fichas no tengo qué citar, y no los leo por mi cuenta. Esa es la respuesta correcta: sin análogos no hay referencia, y no pongo una cifra de relleno.

## Preguntas para el equipo
Una por duración vacía:
1. ¿Cuánto toma que la integración del proveedor (6) quede aceptada, y quién la acepta?
2. ¿Cuánto toma la validación en tiendas (7), contando que la de dos tiendas ya se extendió una semana por el conteo de inventario?
3. ¿Cuántas tiendas entran en el despliegue a producción (1) y en qué orden?
4. ¿Cuánto toma el despliegue a producción?
5. ¿Qué se mide en (2), durante cuánto tiempo, y con qué valor se considera cumplido?
6. ¿Qué son los Componentes 1, 2 y 3 y cuánto toma cada uno?
7. ¿A qué corresponde el «punto 1» de Beatriz y por qué hay dos fechas distintas para él (2026-11-08 en el comité del 2026-10-11; 22/11/2026 en la reunión del 2026-10-15)?
8. ¿Cuánto toma el ajuste del presupuesto que Laura Vélez quedó de mandar «la otra semana» y quién lo aprueba?

## Para comprometer una fecha falta
- La disponibilidad real del equipo (nada en los documentos).
- La fecha del proveedor, incluida la confirmación de que llega con el equipo completo. Solo existe la «revisión con el proveedor» de Óscar Ramírez para el 2026-10-25.
- La ventana de producción de las cajas/tiendas.
- Una decisión sobre el presupuesto: la proyección al cierre del informe (8.542.694.050 COP) supera lo aprobado (6.800.000.000 COP) por 1.742.694.050 COP, y el informe declara Verde. Eso excede lo que este plan puede resolver; se sube al patrocinador.
- Una fecha de cierre vigente: la del acta (2026-06-10) ya venció y no leí una línea base vigente que la reemplace.

*Este borrador no compromete ninguna fecha, no crea línea base y no asigna personas.*
