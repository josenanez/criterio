Publiqué la ficha en `/home/claude/banco/ronda-2/retail/espacio/documentos/proyectos/PRY-205-pago-con-qr-en-caja/00-gobierno/ficha-pm.json`, con corte al 2026-10-15.

**Lleva:** 9 campos con dato (4 de identidad, 3 compromisos, 1 riesgo, 1 de actividad) · 0 marcados «sin decir en ninguna parte» · **no declara estado**: nadie lo ha declarado todavía (sin estado, sin avance y sin fecha de declaración)

**Lo más viejo que va ahí:** `identity.code`, `identity.name`, `identity.manager` e `identity.sponsor`, todos del acta de constitución del 2025-08-16 — 14 meses, pasa de un año.

**Qué verá la PMO de los ocho campos que contrasta:** sponsor (Camilo Beltrán) y manager (Gustavo Neira) van con cita; `plan.end_date`, `money.approved`, `identity.committee`, `identity.product`, `declared.status` y `declared.as_of` no van en la ficha, porque Samuel no los extrajo. Esa ausencia no es un «no está dicho»: el campo no existe en la ficha.

**Para tener presente:**
- El proyecto no tiene línea base (`has_baseline: false`).
- Un compromiso sin fecha: Laura Vélez, «Mandar el ajuste del presupuesto».
- Un compromiso reprogramado una vez: Beatriz Cuéllar, «Entregar el punto 1», del 2026-11-08 al 2026-11-22.
- Un riesgo que se comentó en la reunión y nadie registró (el equipo del proveedor para la siguiente fase).

La carpeta de gobierno ya existía; solo escribí `ficha-pm.json`. No toqué ningún otro archivo ni avisé a nadie: Vera la encontrará en su próximo barrido.
