## PRY-205 Pago con QR en caja · 2026-10-15

**Revisé:** 6 documentos · 6 nuevos (primer barrido, no hay corrida anterior con la que comparar) · 2 con compromisos: el comité del 2026-10-11 y las notas del 2026-10-15

### Lo que se venció solo
Nada venció. Sobre los compromisos de esas dos reuniones (coinciden con los que ya estaban en la ficha, no se duplicó nada):

- **Beatriz Cuéllar · Entregar el punto 1:** prometido para el 2026-11-08 en el comité del 11-oct y vuelto a prometer para el 2026-11-22 en las notas del 15-oct. Una reprogramación; el umbral para marcarlo es 3.
- **Óscar Ramírez · Revisión con el proveedor:** para el 2026-10-25, vigente.
- **Laura Vélez · Mandar el ajuste del presupuesto:** dijo «la otra semana», que no es una fecha. Queda sin fecha declarada y no se la inventé; hay que preguntársela en la próxima reunión.

Sin registrar: en las notas se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase y nadie lo anotó como riesgo. Queda señalado para `/pm-escalate` o el registro de riesgos; no lo registré yo.

### La reunión
Faltan 14 días para el comité del 2026-10-29: todavía no toca agenda (se ofrece cuando falte un día o menos). Las notas de hoy ya existen; no necesito pedir insumo para el acta. El informe toca el 2026-10-28.

### Tu ficha publicada
No se quedó vieja: se publicó hoy.

**Vuelvo el 2026-10-16.**

Notas de la corrida:
- Términos vigentes (versión 1.1, aceptados hoy por José Francisco Ñáñez); no hubo que volver a pedirlos.
- No le escribí a nadie y no declaré el estado.
- Fuera de lugar: `2026-10-15-notas-reunion.txt` está en la raíz de la carpeta del proyecto, no en `30-reuniones/`.
