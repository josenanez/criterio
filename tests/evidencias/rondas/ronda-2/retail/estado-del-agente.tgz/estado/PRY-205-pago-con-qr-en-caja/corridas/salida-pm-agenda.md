## Reunión de seguimiento — Pago con QR en caja (PRY-205) · 2026-10-29
5 puntos · 30 minutos · 4 personas requeridas (Gustavo Neira, Beatriz Cuéllar, Óscar Ramírez, Laura Vélez) + el patrocinador, Camilo Beltrán, para un punto

Fecha tomada de `cycle.committee_next` (2026-10-29); coincide con «próxima reunión en dos semanas» de las notas del 2026-10-15, que no dan fecha. No se pidió tope de tiempo: propongo 30 minutos y la suma cabe. Es la primera corrida sobre este proyecto (no hay snapshot anterior), así que «qué cambió» se mide contra las minutas del 2026-10-11 y 2026-10-15, no contra una corrida previa.

### Lo que no se destraba solo
Nada está reprogramado tres veces ni vencido sin evidencia. Esta reunión es de seguimiento, con un punto que sí necesita a Beatriz.

> **[1] Que se defina qué es «el punto 1» y que su fecha del 22/11 tenga un entregable verificable** · 8 min · **Beatriz Cuéllar**
> Prometido para el 2026-11-22, y antes para el 2026-11-08. Una sola reprogramación (umbral: 3), pero corrida 14 días en 4 días de calendario, y ningún documento define qué es «el punto 1».
> Fuente: `2026-10-15-notas-reunion.txt` (2026-10-15) y `30-reuniones/2026-10-11-comite-semanal.md` (2026-10-11)
> **Si no se resuelve hoy:** el compromiso sigue sin criterio de cumplimiento y, llegado el 22/11, no habrá cómo decir si venció o se cumplió.

### Vencido sin evidencia
Ninguno al 2026-10-15. Ojo con el siguiente bloque: dos compromisos pueden llegar vencidos a esta reunión.

### Se decide hoy o se atrasa
| Qué | Quién decide | Si no se decide | Min |
|---|---|---|---|
| Aceptar o no el componente de integración que el proveedor entregó (informe de avance 2026-10-11: «pendiente de aceptación»). Ningún documento dice quién acepta ni para cuándo | No consta en el expediente; Gustavo Neira debe nombrarlo | Queda entregado sin aceptación documentada, y no se puede contrastar contra lo facturado | 5 |
| Registrar como riesgo que «el proveedor podría no llegar con el equipo completo para la siguiente fase» y asignarle doliente. Nadie lo anotó (notas 2026-10-15); el informe del 2026-10-11 lista solo «disponibilidad de los jefes de tienda» | Gustavo Neira, con lo que traiga Óscar de la revisión con el proveedor | Sigue dicho en una sala y sin dueño | 5 |

### Vence antes de la próxima
| Quién | Qué | Para cuándo | Min |
|---|---|---|---|
| Óscar Ramírez | Revisión con el proveedor | 2026-10-25 (vence 4 días antes de la reunión; se pide el resultado, que además alimenta el riesgo del proveedor) | 5 |
| Laura Vélez | Mandar el ajuste del presupuesto («la otra semana», sin día: no calculo la fecha) | Sin fecha declarada. Pedir fecha concreta hoy | 3 |

Los 4 minutos restantes quedan como holgura.

### No es de esta reunión
| Qué | Por qué | Dónde va |
|---|---|---|
| Presupuesto: la proyección al cierre (COP 8.542.694.050) supera el aprobado (COP 6.800.000.000) por COP 1.742.694.050 (25,6 %), según el informe del 2026-10-11, que sin embargo declara estado Verde | Es una decisión de línea base y de monto; no consta en el expediente que el gerente tenga autoridad para decidirla. Falta además el ajuste que debe mandar Laura Vélez | Comité con el patrocinador (Camilo Beltrán, que asistió el 2026-10-11 y no el 2026-10-15). Ofrezco `/pm-escalate` para formularlo y, si hay solicitud de cambio, `/pm-commitments` |

### Anexo — sin cambios desde el 2026-10-15
No se puede construir: es la primera corrida y no hay snapshot contra el cual declarar qué siguió igual. Lo único conocido sin cambio posible es que los campos de identidad vienen del acta de 2025-08-16 (14 meses) y no hay línea base en la ficha.

### Lo que no sé
- Quién va a asistir el 2026-10-29: la lista sale de las minutas anteriores.
- Si Elena Duarte tiene algún tema: asistió el 2026-10-15 sin intervención atribuida.
- No hay agenda previa en el expediente con la cual comparar los temas pendientes de decidir; la minuta del 2026-10-15 no deja ninguno explícito.

Cada punto lleva la cita de arriba. No convoqué a nadie: citar a la reunión es del gerente. Cuando termine, `/pm-minutes` sobre las notas.
