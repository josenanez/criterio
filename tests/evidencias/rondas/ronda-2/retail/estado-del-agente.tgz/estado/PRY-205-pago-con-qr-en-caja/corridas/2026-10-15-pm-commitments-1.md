# Corrida del 2026-10-15 · pm-commitments

1 proyectos · 13 s · 1 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_undated` | 1 |

Beatriz Cuéllar reprogramada 1 vez; Laura Vélez sin fecha

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## Compromisos — Pago con QR en caja (PRY-205) · al 2026-10-15

3 compromisos abiertos. Ninguno vencido; uno reprogramado (1 vez, bajo el umbral de 3); uno sin fecha.

### Se viene reprogramando
> **Beatriz Cuéllar** · Entregar el punto 1
> Prometido para el 2026-11-22, y antes para el 2026-11-08 (`30-reuniones/2026-10-11-comite-semanal.md`).
> Cita: «lo de "entregar el punto 1" no alcanzó, se compromete para el 22/11/2026» (`2026-10-15-notas-reunion.txt`).
> Una reprogramación todavía no es un bloqueo (el umbral es 3), pero se corrió 14 días en 4 días de calendario, y ningún documento define qué es «el punto 1».

### Vencidos sin evidencia
Ninguno.

### Vencen esta semana
Ninguno. El más cercano es Óscar Ramírez · Revisión con el proveedor · 2026-10-25 (10 días).

### Sin fecha
| Quién | Qué | Dicho el |
|---|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto («la otra semana», sin día) | 2026-10-15 |

No puede estar vencido; se cuenta aparte para que no desaparezca.

### Cerrados desde la última revisión
Ninguno. El informe de avance del 2026-10-11 dice que el proveedor entregó el componente de integración, pero ninguno de los tres compromisos lo menciona; no cierro nada sin documento.

Cifras de `portafolio.py compute`: vencidos 0, sin fecha 1, reprogramados por umbral 0.
