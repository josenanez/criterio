<!-- origen: 00-definicion/2025-10-19-definicion-producto.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Definición de producto · Pago con QR

Código: PRD-303

Gerente de producto: María Restrepo

Segmento: Clientes frecuentes

Fecha de la definición: 2025-10-19

El problema

El segmento Clientes frecuentes no tiene pago con qr.

La propuesta

• Propuesta principal

Supuestos

• La demanda se sostiene sin descuento · declarado el 2026-03-17 · sin verificar

Proyectos que lo construyen

• Ninguno declarado
