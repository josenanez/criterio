<!-- origen: 10-descubrimiento/2025-09-29-entrevistas.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Entrevistas · Pago con QR

**Ronda:** Ronda · 2025-09-29
**Realizadas por:** María Restrepo

### Cliente entrevistado · 2025-09-29

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
