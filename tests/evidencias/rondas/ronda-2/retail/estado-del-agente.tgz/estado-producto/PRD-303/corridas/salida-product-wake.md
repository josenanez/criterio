## Pago con QR (PRD-303) · 2026-10-15

**Primera revisión del registro: no hay corte anterior**, así que no puedo decir qué cambió desde entonces; lo de abajo es la línea base contra la que se medirá la próxima corrida. Términos v1.1 vigentes, registrados a nombre de José Francisco Ñáñez (2026-10-15).

### Cruzó un umbral sin que nadie hiciera nada
| Qué | REQ | Cuánto lleva | Qué se necesita | Quién |
|---|---|---|---|---|
| Supuesto sin verificar: «La demanda se sostiene sin descuento» | — (definición) | 212 días (umbral: 30) | Una medición de demanda sin descuento (p. ej. volumen real de pagos con QR frente al declarado de 243.100/mes). Ya pasó el punto en que conviene tratarlo como riesgo registrado (assumption-tracking). | No consta: la autoridad del producto está sin definir en la configuración |

### Para el comité (necesita decisión)
- **Aceptados que nadie está construyendo:** los 5 requerimientos (REQ-1030, 1031, 1032, 2017, 2025) están aceptados y ninguno tiene proyecto. El más antiguo, REQ-1031, se aceptó el 2026-04-04 (~194 días).
- **Aceptados sin criterio de aceptación:** REQ-2017 (Liliana Torres) y REQ-2025 (Andrés Lozano).
- **Cifra del negocio sin contraste:** el caso de negocio declara 243.100 de volumen mensual (2025-10-19); no hay medición contra la cual compararla, así que no se puede decir si coincide o no.

### Las trazas
Sin carpeta de fichas, ninguna traza se da por confirmada (0 de 5 trazadas).

### Del descubrimiento
Un solo documento (entrevistas, 2025-09-29); no hay documentos nuevos que comparar porque es la primera revisión.

### Lo que no sé
Criterio de éxito del producto y autoridad que decide: ambos sin definir. No hay requerimientos sin decidir ni evidencia vencida en este corte.

**Vuelvo el 2026-11-14.**
