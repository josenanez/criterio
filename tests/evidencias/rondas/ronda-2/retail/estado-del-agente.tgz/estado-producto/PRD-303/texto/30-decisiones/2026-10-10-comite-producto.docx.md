<!-- origen: 30-decisiones/2026-10-10-comite-producto.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de producto · Pago con QR

Fecha: 2026-10-10

Asistentes: María Restrepo

Requerimientos revisados

ID

Requerimiento

Doliente

Criterio de aceptación

Quién lo pidió

Estado

Desde

Proyecto que lo ejecuta

REQ-1030

Requerimiento REQ-1030

Felipe Arango

se verifica en producción

Cliente entrevistado

aceptado

2026-08-13

—

REQ-1031

Requerimiento REQ-1031

Laura Vélez

se verifica en producción

Cliente entrevistado

aceptado

2026-04-04

—

REQ-1032

Requerimiento REQ-1032

Sandra Gil

se verifica en producción

Cliente entrevistado

aceptado

2026-04-15

—

REQ-2017

Requerimiento REQ-2017

Liliana Torres

—

Cliente entrevistado

aceptado

2026-09-19

—

REQ-2025

Requerimiento REQ-2025

Andrés Lozano

—

Cliente entrevistado

aceptado

2026-09-29

—

Decisiones

• Se mantiene el plan
