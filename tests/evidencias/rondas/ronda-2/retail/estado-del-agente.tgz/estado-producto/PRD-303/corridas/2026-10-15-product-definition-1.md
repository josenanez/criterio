# Corrida del 2026-10-15 · product-definition

PRD-303 · 5 requerimientos · 32 s · 8 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 5 |
| `requirement_without_acceptance` | 2 |
| `assumption_unverified` | 1 |

La evidencia sostiene solo el problema, con una entrevista de hace más de 12 meses; sin criterio de éxito, sin autoridad, sin serie para el volumen y con un supuesto de 212 días sin verificar

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## Definición — Pago con QR (PRD-303) · contrastada al 2026-10-15
**Documento:** `00-definicion/2025-10-19-definicion-producto.docx` (con `00-definicion/2025-10-19-caso-de-negocio.md`) · **del** 2025-10-19 · 6 afirmaciones

Términos vigentes (v1.1), aceptados por José Francisco Ñáñez el 2026-10-15. Gerente de producto: María Restrepo.

### Lo que la evidencia contradice
Nada. Ningún documento de la carpeta dice lo contrario de la definición. Ojo: eso no significa que esté sostenida, porque casi nada tiene con qué contrastarse (ver abajo).

### El negocio y los datos
No hay cifras que pasen del umbral (20 %), porque no hay ninguna medición con la que comparar. Ver la sección siguiente.

### Afirmaciones numéricas que nadie mide
| Afirma | De qué documento | No hay serie |
|---|---|---|
| `volumen_mensual` = 243.100 | `00-definicion/2025-10-19-caso-de-negocio.md` (2025-10-19) | Sin serie medida: nadie está midiendo lo que el caso de negocio afirmó. No es contradicción; es ausencia de dato. Hoy la cifra tiene 361 días y ningún punto que la contraste. |
| «Retorno esperado en 24 meses» | `00-definicion/2025-10-19-caso-de-negocio.md` (2025-10-19) | Ni siquiera trae cifra (monto, inversión, supuestos de cálculo), así que no hay nada que medir. |

### No está dicho en ninguna parte
- **El criterio de éxito.** Ningún documento lo dice. Sin él el producto no se puede cerrar, porque el cierre se juzga contra él.
- **Quién decide (autoridad).** `authority` está vacío en la configuración y en la definición.
- **La propuesta.** La definición solo dice «Propuesta principal», un rótulo sin contenido: no hay qué se va a construir.
- **Cuánto pagaría o usaría el cliente.** Ningún documento lo afirma ni lo niega.
- **El tamaño del segmento «Clientes frecuentes».** No se define quiénes son ni cuántos; el 243.100 mensual no dice de qué sale.
- **Qué proyecto lo construye.** La definición dice «Ninguno declarado», y los 5 requerimientos aceptados tampoco tienen proyecto.
- **Cómo se llegó a «retorno en 24 meses».** No hay cálculo ni supuestos.

### Sostenida por un supuesto
| Supuesto | Días sin verificar | Qué haría falta para verificarlo |
|---|---|---|
| «La demanda se sostiene sin descuento» (declarado el 2026-03-17) | 212 (umbral: 30) | Una medición de uso o compra de clientes frecuentes sin incentivo: un piloto sin descuento con un número de éxito fijado antes de empezar. Hoy no se puede verificar porque no hay criterio de éxito ni serie de volumen. Convendría escribir qué cifra, en qué plazo, lo daría por cumplido o por desmentido. |

Dos afirmaciones más descansan en supuestos que el documento no declara como tales: que el volumen mensual de 243.100 es alcanzable y que el segmento tiene el problema de forma generalizada. No las inventé como supuestos del autor: quedan en «no está dicho».

### Sostenida por evidencia
| Afirmación | Sostenida por | De cuándo | Qué tan fuerte |
|---|---|---|---|
| El segmento Clientes frecuentes no tiene pago con QR (el problema) | `10-descubrimiento/2025-09-29-entrevistas.md`: un cliente entrevistado dijo «Lo necesito y hoy no lo tengo.» | 2025-09-29 | **Débil.** Es una declaración de intención de un solo cliente, sin nombre ni segmento verificable; no hay compra, pago ni uso. Está en el escalón más bajo de la jerarquía de evidencia de demanda. |
| Existen cinco requerimientos aceptados (REQ-1030, 1031, 1032, 2017, 2025) | `30-decisiones/2026-10-10-comite-producto.docx`, todos con «Quién lo pidió: Cliente entrevistado» | 2026-10-10 | **No es evidencia nueva de demanda.** El acta del comité registra aceptaciones; el único origen citado es la misma entrevista de 2025. Cinco requerimientos remiten a una entrevista con un cliente. |

### Evidencia que ya envejeció
| Afirmación | Lo más nuevo que la sostiene | Hace |
|---|---|---|
| El problema (Clientes frecuentes sin pago con QR) | Entrevista del 2025-09-29 | 381 días (~12,5 meses; umbral: 12 meses) |
| `volumen_mensual` 243.100 | Caso de negocio del 2025-10-19 (es una declaración, no una medición) | 361 días |

### Lo normativo que toca
| Qué toca | País | Obligación | Norma | Estado |
|---|---|---|---|---|
| Pagos con QR (iniciación y procesamiento de pagos) | No consta en la configuración ni en los documentos | Reglas de pagos y de entidades que los procesan | — | **No tengo la norma a la vista** |
| Datos personales del cliente frecuente (identificación y hábitos de compra) | No consta | Tratamiento y autorización de datos personales | — | **No tengo la norma a la vista** |
| Consumidor financiero / protección al consumidor | No consta | Información al consumidor, reclamos, retracto | — | **No tengo la norma a la vista** |
| Retención de información de transacciones | No consta | Plazos de conservación | — | **No tengo la norma a la vista** |

No nombro normas concretas: ni la carpeta del producto ni la configuración declaran el país de operación, y no hay norma en los documentos. Esto no dice si el producto cumple ni deja de cumplir; solo señala qué materias toca y debe ir a revisión jurídica.

### Lo que falta para cerrar la definición
- **Criterio de éxito:** falta. Sin él no se cierra.
- **Quién decide:** falta (`authority` vacío).
- **Propuesta:** falta (solo el rótulo «Propuesta principal»).
- **El problema** y **para quién:** están declarados («Clientes frecuentes no tiene pago con QR»), pero sostenidos por una sola entrevista de hace más de 12 meses.
- **Proyecto que lo construye:** ninguno declarado; los 5 requerimientos aceptados siguen sin proyecto.

Otras señales del cálculo, para el contexto: 5 de 5 requerimientos aceptados sin trazar a proyecto, y 2 de 5 (REQ-2017, REQ-2025) aceptados sin criterio de aceptación.

**Después:** el supuesto de la demanda sin descuento lleva 212 días sin verificar. Puede convertirse en riesgo con doliente (raid-taxonomy). No ofrezco `/product-charter`: la definición no está cerrada, falta criterio de éxito y autoridad.
