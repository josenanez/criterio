## Registro — Pago con QR (PRD-303) · al 2026-10-15
5 requerimientos · 5 decididos · 100% con evidencia · 0% con proyecto que lo ejecuta

Nota sobre el 100%: lo calcula el script por conteo. En los tres que pude abrir (REQ-1030, REQ-2017, REQ-2025), la única evidencia es una línea del acta del comité del 2026-10-10: «Cliente entrevistado (el acta nombra la categoría; no cita quién ni qué dijo)». Hay evidencia registrada, pero ninguna cita de quien lo pidió. (REQ-1031 y REQ-1032 no los abrí; el cálculo les da 1 evidencia a cada uno.)

### Se va a construir y nadie lo pidió
Ninguno por conteo: los 5 tienen una evidencia. Ver la nota de arriba sobre su calidad.

### Decidido y nadie lo está construyendo
Los 5 (ninguno tiene proyecto; no hay fichas de proyecto en `estado/`, que está vacía).
| REQ | Título | Decidido el |
|---|---|---|
| REQ-1031 | Requerimiento REQ-1031 | 2026-04-04 (hace 194 días) |
| REQ-1032 | Requerimiento REQ-1032 | 2026-04-15 (hace 183 días) |
| REQ-1030 | Requerimiento REQ-1030 | 2026-08-13 (hace 63 días) |
| REQ-2017 | Requerimiento REQ-2017 | 2026-09-19 (hace 26 días) |
| REQ-2025 | Requerimiento REQ-2025 | 2026-09-29 (hace 16 días) |

### Sin doliente, o con un área en vez de una persona
Ninguno. Los 5 tienen persona: Felipe Arango (REQ-1030), Laura Vélez (REQ-1031), Sandra Gil (REQ-1032), Liliana Torres (REQ-2017), Andrés Lozano (REQ-2025).

### Sin criterio de aceptación
| REQ | Título | Estado | Quién lo cerraría |
|---|---|---|---|
| REQ-2017 | Requerimiento REQ-2017 | aceptado | Liliana Torres (doliente) |
| REQ-2025 | Requerimiento REQ-2025 | aceptado | Andrés Lozano (doliente) |

Además, REQ-1030 tiene un criterio, «se verifica en producción», que no dice qué se mide ni con qué umbral. Cuenta como criterio para el script, pero no es verificable tal cual.

### Decidido sin documento que lo respalde
Todos tienen como fuente el acta del comité del 2026-10-10, pero en los tres que abrí el campo «quién decidió» está vacío. Con la facultad sin definir (`product.authority: null` en la configuración), nadie figura como quien aceptó.
| REQ | Quién decidió | Cuándo |
|---|---|---|
| REQ-1030 | no consta | 2026-08-13 |
| REQ-2017 | no consta | 2026-09-19 |
| REQ-2025 | no consta | 2026-09-29 |
| REQ-1031, REQ-1032 | no verificado (no los abrí) | 2026-04-04 · 2026-04-15 |

Ojo: el acta es del 2026-10-10 y las decisiones que recoge son de abril a septiembre. Se registraron después de tomadas.

### Lleva meses y nadie lo decide
Ninguno: no hay requerimientos en estado propuesto.

### Evidencia vieja
Ninguna. Lo más nuevo que sostiene a los 5 es del 2026-10-10 (hace 5 días). Pero es el mismo acta, no evidencia de demanda independiente.

### Fuera de los requerimientos, en la definición
- **Supuesto sin verificar hace 212 días:** «La demanda se sostiene sin descuento». Umbral: 30 días. Nadie lo tiene asignado para verificarlo.
- **Cifra declarada sin medición:** el caso de negocio (2025-10-19) declara volumen_mensual = 243.100 y no hay serie medida contra la cual contrastarla (`metrics/` está vacío).
- **Sin definir:** criterio de éxito del producto y facultad de decisión (`authority`). Esto último es lo que impide decir quién puede cerrar los vacíos de decisión.

## Por estado
| propuesto | aceptado | en construcción | entregado | descartado |
|---|---|---|---|---|
| 0 | 5 | 0 | 0 | 0 |

## Lo que sigue
- Hay 5 requerimientos decididos que nadie construye: corre `/criterio-product:product-trace`.
- Ninguno está en condiciones de pasar a `/criterio-product:product-charter`: los 5 carecen de cita de quien lo pidió, y REQ-2017 y REQ-2025 no tienen criterio de aceptación. REQ-1031 y REQ-1032, los más viejos, no los verifiqué a fondo.
- Por decidir: quién es la autoridad de decisión de PRD-303 (hoy `null`).
