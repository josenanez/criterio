No publiqué la ficha de PRD-303 (Pago con QR): la configuración no define una carpeta de productos publicados (`paths` solo trae `documents` y `state`). Sin un sitio común acordado esto no sirve, y acordarlo es una conversación de la organización, no un comando. No creé ni busqué ninguna carpeta.

Lo que habría publicado (corte 2026-10-15):
- 5 requerimientos (todos aceptados, ninguno ligado a un proyecto) · 0 proyectos · 1 métrica afirmada
- Segmento declarado: Clientes frecuentes
- Métrica: volumen_mensual = 243100.0, de documentos/productos/PRD-303/00-definicion/2025-10-19-caso-de-negocio.md (2025-10-19)

Señales: 5 requerimientos sin trazar a proyecto, 2 aceptados sin criterio de aceptación (REQ-2017, REQ-2025), 1 supuesto sin verificar hace 212 días.
