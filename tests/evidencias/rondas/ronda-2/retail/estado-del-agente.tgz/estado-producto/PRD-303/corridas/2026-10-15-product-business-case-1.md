# Corrida del 2026-10-15 · product-business-case

PRD-303 · 5 requerimientos · 37 s · 8 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 5 |
| `requirement_without_acceptance` | 2 |
| `assumption_unverified` | 1 |

Caso de negocio de PRD-303: 1 cifra declarada (243.100) con fuente que se cita a sí misma; sin costos, sin serie medida, sin criterio de éxito, sin retorno cuantificado. No hay otros productos publicados para cruzar; PRY-205 sin vínculo documentado.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

# Caso de negocio — Pago con QR (PRD-303) · borrador del 2026-10-15
**Desde:** la definición del 2025-10-19 y el caso de negocio del 2025-10-19 · **Cifras con fuente:** 1 de 1 (y es una cifra declarada, no medida)

Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-15). Las cifras son del negocio: aquí no se proyecta, no se calcula retorno y no se recomienda aprobar ni rechazar.

## Qué problema resuelve, y para quién
"El segmento Clientes frecuentes no tiene pago con qr." — `00-definicion/2025-10-19-definicion-producto.docx`, 2025-10-19. Gerente de producto: María Restrepo. Autoridad de aprobación: no declarada.

Evidencia de demanda a nivel de producto: una sola cita, "Lo necesito y hoy no lo tengo." — Cliente entrevistado, 2025-09-29, `10-descubrimiento/2025-09-29-entrevistas.md`. Es anónima y tiene más de 12 meses (umbral de antigüedad: 12 meses).

## Qué se construye
La definición no declara propuesta concreta (la sección dice "Propuesta principal" sin contenido). Los requerimientos aceptados en el comité del 2026-10-10 (`30-decisiones/2026-10-10-comite-producto.docx`):

| Requerimiento | Estado | Evidencia de demanda |
|---|---|---|
| REQ-1030 (doliente Felipe Arango) | aceptado desde 2026-08-13 | "Cliente entrevistado": el acta nombra la categoría, no cita quién ni qué dijo |
| REQ-1031 (Laura Vélez) | aceptado desde 2026-04-04 | ídem |
| REQ-1032 (Sandra Gil) | aceptado desde 2026-04-15 | ídem |
| REQ-2017 (Liliana Torres) | aceptado desde 2026-09-19, sin criterio de aceptación | ídem |
| REQ-2025 (Andrés Lozano) | aceptado desde 2026-09-29, sin criterio de aceptación | ídem |

Los cinco son "Requerimiento REQ-xxxx" sin descripción de la necesidad en ningún documento. Ninguno tiene proyecto asignado.

## Las cifras
| Cifra | Valor | Clase | De dónde sale | De cuándo |
|---|---|---|---|---|
| volumen_mensual | 243.100 | Declarada | `00-definicion/2025-10-19-caso-de-negocio.md` (el documento se cita a sí mismo como fuente) | 2025-10-19 |

Qué cuenta el 243.100 (transacciones, pagos, clientes) y cómo se llegó a él: no está dicho en ningún documento.

### Donde la cifra declarada y la medida no coinciden
No hay serie medida para PRD-303 (la carpeta `metrics` está vacía). No se puede contrastar el 243.100 y no se afirma que coincida ni que difiera. El umbral de brecha configurado es 20 %.

## Los costos
| Concepto | Valor | De dónde sale |
|---|---|---|
| Costo de construir | — | No está en ningún documento |
| Costo de operar | — | No está en ningún documento |
| Contratos o cotizaciones | — | No hay ninguno vinculado al producto |

Sin el costo de construir no hay caso de negocio que evaluar: hay una propuesta.

## Supuestos sobre los que se sostiene
| Supuesto | Qué pasa si resulta falso | Quién lo verificaría |
|---|---|---|
| "La demanda se sostiene sin descuento" (declarado el 2026-03-17, sin verificar; más de 30 días sin verificar) | Si hace falta descuento para sostener la demanda, el volumen y el retorno declarados dejan de aplicar. El documento no lo dice; es consecuencia directa del enunciado | Sin responsable declarado |
| Implícito (supuesta): que 243.100 por mes es alcanzable por el segmento Clientes frecuentes | Todo el caso depende de él | Nadie lo ha afirmado con base; lo debe producir el negocio |

Se ofrece pasar ambos al seguimiento con **assumption-tracking**.

## Vacíos
| Qué falta | Por qué importa | Quién lo produce |
|---|---|---|
| Costo de construir y de operar | Sin él no hay caso, solo propuesta | Quien tenga los costos (gerente de producto / finanzas) |
| Qué mide el 243.100 y cómo se estimó | Es la única cifra del caso y se cita a sí misma | María Restrepo |
| Valor del "retorno esperado en 24 meses" | El documento dice la frase, no da cifra ni método | El negocio; el agente no lo calcula |
| Criterio de éxito (con métrica y fecha de corte) | Definición lo tiene vacío | María Restrepo |
| Qué pasa si no se hace; alternativas consideradas | No aparecen en ningún documento | María Restrepo |
| Propuesta concreta | La definición no la contiene | María Restrepo |
| Quién autoriza | La autoridad no está declarada | Patrocinador / PMO |
| Serie medida de volumen | Impide contrastar lo declarado | El sistema donde vive el producto |
| Proyecto que lo construye | La definición dice "Ninguno declarado" | Gerente de producto |

## Cómo se sabrá si funcionó
No está declarado: la definición no trae criterio de éxito, ni métrica de éxito, ni fecha de corte. Sin esto el producto no se puede cerrar meses después. El único candidato es el volumen_mensual declarado, pero ningún documento lo señala como criterio de éxito.

## Si hay otros productos publicados
Ningún otro producto afirma la cifra 243.100 ni menciona PRD-303 en los documentos a la vista. No hay fichas publicadas para cruzar, así que el cruce de `/product-overlap` no se pudo completar; solo se buscó la cifra y el código. Observación sin concluir: existe el proyecto PRY-205 "pago con QR en caja", pero ningún documento lo vincula a PRD-303; no se usaron sus costos ni sus fechas.
