> **Borrador.** Lo escribe el agente; lo cierra María Restrepo (gerente de producto). La facultad de decisión del producto está sin definir (`authority: null`), así que hoy no consta quién puede aprobarlo.

# Especificación — Pago con QR (PRD-303) · borrador del 2026-10-15

## Qué problema resuelve
«El segmento Clientes frecuentes no tiene pago con qr.» (definición de producto, 2025-10-19.) La definición no dice la propuesta ni el criterio de éxito del producto: ambos figuran como no encontrados. Un cliente entrevistado el 2025-09-29 dijo: «Lo necesito y hoy no lo tengo.» (entrevistas, 2025-09-29). Es una sola cita.

## Alcance
### Entra
Los 5 requerimientos aceptados del registro: REQ-1030, REQ-1031, REQ-1032, REQ-2017 y REQ-2025 (acta del comité, 2026-10-10). **Del contenido de ninguno se puede decir nada**: el registro no trae la necesidad (`need`) de ninguno, y los títulos son marcadores («Requerimiento REQ-10xx»). Entran por su estado y su identificador, no por lo que piden.

### No entra
Esta lista no se puede escribir desde el registro. Ningún documento dice qué queda fuera de Pago con QR, y proponerlo sería decidir el alcance. Queda como vacío (V1).

## Comportamiento
**No hay sección de comportamiento.** Describirlo exigiría saber qué pide cada requerimiento, y el registro no lo dice. Una sección «razonable» sobre cómo funciona un pago con QR sería de mi invención, sin rastro en ningún documento. No la escribí.

## Criterios de aceptación
| Criterio | Requerimiento | Cómo se verifica | ¿Se puede medir hoy? |
|---|---|---|---|
| «se verifica en producción» (acta 2026-10-10) | REQ-1030 | No dice qué se mide ni con qué umbral. Dos personas no llegarían a la misma respuesta. | No determinable: no hay métrica ni umbral |
| «se verifica en producción» | REQ-1031 | Igual | No determinable |
| «se verifica en producción» | REQ-1032 | Igual | No determinable |
| — (sin criterio) | REQ-2017 | — | — |
| — (sin criterio) | REQ-2025 | — | — |

Ninguno de los 5 pasa la prueba de verificabilidad. No redacté criterios en su lugar: un umbral inventado quedaría como si alguien lo hubiera decidido. Además, `metrics/` está vacío: la organización no tiene hoy ninguna serie medida de este producto.

## Supuestos sobre los que está escrita
| Supuesto | Verificado | Quién lo verificaría |
|---|---|---|
| «La demanda se sostiene sin descuento» (declarado el 2026-03-17; definición 2025-10-19) | No, lleva 212 días sin verificar (umbral: 30) | Sin asignar; propongo que lo asigne María Restrepo |
| Volumen mensual de 243.100 (caso de negocio, 2025-10-19) | No: no hay serie medida con qué contrastarlo | Sin asignar (es una cifra del negocio) |
| «Cliente entrevistado» respalda los 5 requerimientos | No verificable: el acta nombra la categoría, no cita quién ni qué dijo. El único material de entrevistas es una cita de 2025-09-29 | María Restrepo (realizó las entrevistas) |

## Vacíos
| # | Qué falta decidir | Consecuencia de no decidirlo | Quién lo cierra |
|---|---|---|---|
| V1 | Qué dice cada requerimiento (necesidad, título real) y qué queda fuera del alcance | No hay especificación posible; lo que se construya lo definirá quien construya | Dolientes: Felipe Arango (REQ-1030), Laura Vélez (REQ-1031), Sandra Gil (REQ-1032), Liliana Torres (REQ-2017), Andrés Lozano (REQ-2025) |
| V2 | Criterio de aceptación de REQ-2017 y REQ-2025 | No se puede saber cuándo están terminados | Liliana Torres y Andrés Lozano |
| V3 | Criterio medible de REQ-1030, REQ-1031 y REQ-1032 en lugar de «se verifica en producción» | Aprobación por discusión después de construir | Felipe Arango, Laura Vélez y Sandra Gil |
| V4 | Casos borde (sin conexión, pago duplicado, cliente que se va antes de la confirmación, QR vencido o ilegible) | Comportamiento decidido por quien construya | Sin dueño en los documentos; propongo a María Restrepo asignarlo |
| V5 | Qué debe hacer otro equipo (comercios, procesador de pagos, backend, soporte) y si está acordado | Dependencias descubiertas durante la construcción | Sin dueño. Ningún documento nombra equipos ni acuerdos; la definición dice «Proyectos que lo construyen: ninguno declarado» |
| V6 | Obligaciones normativas | Un producto de pagos con datos de clientes casi seguro toca normativa. Ningún documento del producto cita una, y no hice el barrido citado (regulatory-sweep) porque no hay una definición de comportamiento sobre la cual hacerlo | Sin dueño; falta la facultad de decisión (`authority`) y alguien de cumplimiento que no consta en ningún documento |
| V7 | Criterio de éxito y propuesta del producto | No hay contra qué medir si el producto funcionó | María Restrepo |
| V8 | Quién aceptó cada requerimiento. El campo «quién decidió» está vacío en los 5, y el acta (2026-10-10) recoge decisiones de abril a septiembre registradas después | Los requerimientos «aceptados» no tienen decisor rastreable | María Restrepo (único asistente del acta) |
| V9 | Prioridad de cada requerimiento | Sin orden de construcción | María Restrepo |

## Requerimientos aceptados que esta especificación no cubre
| REQ | Título | Por qué no |
|---|---|---|
| REQ-1030 | Requerimiento REQ-1030 | Entra al alcance pero sin comportamiento: el registro no trae la necesidad. Criterio no verificable |
| REQ-1031 | Requerimiento REQ-1031 | Igual. Aceptado desde 2026-04-04 (194 días) sin proyecto ni contenido |
| REQ-1032 | Requerimiento REQ-1032 | Igual. Aceptado desde 2026-04-15 |
| REQ-2017 | Requerimiento REQ-2017 | Sin necesidad ni criterio de aceptación |
| REQ-2025 | Requerimiento REQ-2025 | Sin necesidad ni criterio de aceptación |

Resultado: **0 de 5** quedan cubiertos por una sección con comportamiento. Esto es un hallazgo sobre el registro, no un fallo de la redacción.

## Qué sigue
No ofrezco `/criterio-product:product-charter`: con 5 requerimientos sin contenido, 2 sin criterio y ninguno con criterio medible, el acta no tendría sobre qué escribirse. Lo útil ahora es cerrar V1, V2 y V3 con los dolientes.

---
Registro: `estado-producto/PRD-303/requirements/` (5 requerimientos, actualizado el 2026-10-15), fuente de las decisiones: acta del comité de 2026-10-10. Cubre 5 requerimientos de 5 aceptados, sin comportamiento en ninguno. Términos: versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-15 — https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.8
