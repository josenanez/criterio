# Acta de constitución — Pago con QR · REQ-1030 · borrador del 2026-10-15
**Producto:** PRD-303 Pago con QR · **Requerimientos:** REQ-1030

Términos vigentes (v1.1), aceptados por José Francisco Ñáñez el 2026-10-15 (comprobante en `.criterio/terminos/`).

## Verificación previa (paso 1)
| Condición | Resultado |
|---|---|
| Aceptado, no propuesto | Sí: «aceptado», desde 2026-08-13 (`30-decisiones/2026-10-10-comite-producto.docx`). El acta no dice quién lo aceptó. |
| Criterios de aceptación | Hay uno, «se verifica en producción» (misma acta). **No es verificable**: no dice qué se mide ni con qué umbral. Cuenta como presente en forma, vacío en fondo. |
| Evidencia de demanda con cita | **Débil.** Origen «Cliente entrevistado»: la entrevista del 2025-09-29 (`10-descubrimiento/2025-09-29-entrevistas.md`), un cliente, sin nombre ni segmento: «Lo necesito y hoy no lo tengo.» Intención declarada; no hay compra, pago ni uso. Tiene 381 días (umbral 12 meses). |
| Autoridad declarada | **Falta.** `authority` está vacío en la configuración y en la definición. |

Respuesta sugerida tomada (sin interfaz): seguir sin lo que falta, marcándolo como vacío del acta. No relleno nada.

## Qué problema resuelve
«El segmento Clientes frecuentes no tiene pago con qr.» (`00-definicion/2025-10-19-definicion-producto.docx`, 2025-10-19). La necesidad propia de REQ-1030 no está escrita en ningún documento (`need`: no encontrada).

## Criterio de éxito
| Criterio | Fuente | Cómo se verifica |
|---|---|---|
| «se verifica en producción» (REQ-1030) | Acta de comité 2026-10-10 | **No está dicho.** Sin métrica, umbral ni plazo. |
| Criterio de éxito del producto | — | **No está dicho en ningún documento.** |

## Alcance
### Entra
| REQ | Título | Evidencia que lo sostiene |
|---|---|---|
| REQ-1030 | Requerimiento REQ-1030 (el acta no da más título). Doliente: Felipe Arango | «Cliente entrevistado», sin cita de quién ni qué dijo; la única entrevista del producto es la de 2025-09-29. |

### No entra
| REQ | Título | Por qué no |
|---|---|---|
| REQ-1031 | Requerimiento REQ-1031 (doliente: Laura Vélez) | No se pidió en este acta (el argumento es solo REQ-1030). Aceptado desde 2026-04-04, sin proyecto. |
| REQ-1032 | Requerimiento REQ-1032 (doliente: Sandra Gil) | Ídem. Aceptado desde 2026-04-15, sin proyecto. |
| REQ-2017 | Requerimiento REQ-2017 (doliente: Liliana Torres) | Ídem; además sin criterio de aceptación. Aceptado desde 2026-09-19. |
| REQ-2025 | Requerimiento REQ-2025 (doliente: Andrés Lozano) | Ídem; además sin criterio de aceptación. Aceptado desde 2026-09-29. |

La razón es de selección, no una decisión de exclusión de nadie: quien firma debe confirmar si deben entrar o quedarse fuera. Tampoco hay descripción de qué se construye: la «Propuesta principal» de la definición es un rótulo sin contenido.

## Gobierno
- **Patrocinador:** no está dicho.
- **Gerente propuesto:** no está dicho. María Restrepo es gerente del *producto* (definición, 2025-10-19), no consta como gerente de proyecto. Asignarlo es de quien tiene la autoridad.
- **Comité:** comité de producto, mensual (configuración); sesión del 2026-10-10 con asistente María Restrepo; decisión «Se mantiene el plan».
- **Autoridad del gerente:** no está dicho.

## Supuestos que se llevan al proyecto
| Supuesto | Verificado | Se convierte en riesgo de |
|---|---|---|
| «La demanda se sostiene sin descuento» (declarado 2026-03-17) | No; 212 días sin verificar (umbral 30) | Riesgo del proyecto (raid-taxonomy). **Doliente: sin nombrar**; lo asigna quien firma. Verificarlo requiere un piloto sin descuento con cifra de éxito fijada antes. |

Dos afirmaciones del caso de negocio descansan en supuestos no declarados (volumen mensual 243.100 alcanzable; el problema es generalizado). No los registro como supuestos del autor.

## Restricciones normativas sin resolver
| Qué toca | Obligación | Norma | Estado |
|---|---|---|---|
| Pagos con QR | Reglas de pagos y de quienes los procesan | — | No tengo la norma a la vista; el país no consta |
| Datos personales del cliente frecuente | Tratamiento y autorización | — | Ídem |
| Consumidor financiero | Información, reclamos, retracto | — | Ídem |
| Retención de transacciones | Plazos de conservación | — | Ídem |

Solo señala materias que van a revisión jurídica; no dice si se cumple.

## Vacíos de este acta
| Qué falta | Consecuencia de firmar sin eso | Quién lo cierra |
|---|---|---|
| Autoridad del gerente | El proyecto escala todo o no escala nada | Quien firma / gerente de producto |
| Patrocinador y gerente de proyecto | No hay dueño de la ficha ni a quién se la entrega | Quien tenga la autoridad |
| Criterio de éxito verificable | El cierre no se podrá juzgar | Gerente de producto con el doliente (Felipe Arango) |
| Necesidad propia de REQ-1030 | Se construye sin saber para qué | Felipe Arango |
| Evidencia de demanda sólida (una entrevista, 381 días) | El proyecto arranca sobre intención declarada de un cliente | Gerente de producto |
| Propuesta (qué se construye) | No hay alcance que planificar | Gerente de producto |
| Presupuesto e hitos | El acta no declara ninguno; no se inventan | Patrocinador |
| Doliente del riesgo «demanda sin descuento» | Riesgo sin dueño | Quien firma |
| Norma aplicable y país | Obligaciones sin revisar | Jurídico |

---
**Esto es un borrador.** Lo firma quien tenga la autoridad (hoy no declarada). **La ficha del proyecto NO se creó** (`portafolio.py init` no se corrió): se crea después de la firma, con `identity.product = PRD-303`, y `declared` queda vacío por diseño.

**Después:** cuando haya firma y gerente, ese gerente instala `criterio-project` y corre `/pm-setup`; al publicar su ficha con `/pm-publish`, `/product-trace` podrá confirmar la traza contra ella.
