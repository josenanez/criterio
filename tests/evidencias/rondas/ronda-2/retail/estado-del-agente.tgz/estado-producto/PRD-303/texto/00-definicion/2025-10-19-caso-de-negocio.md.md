<!-- origen: 00-definicion/2025-10-19-caso-de-negocio.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Caso de negocio · Pago con QR

**Código:** PRD-303
**Fecha:** 2025-10-19
**Preparado por:** María Restrepo

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 243.100 | Caso de negocio, 2025-10-19 |

## Retorno esperado

Retorno esperado en 24 meses.
