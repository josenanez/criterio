## Trazabilidad — Pago con QR (PRD-303) · al 2026-10-15
5 decididos · 0 con proyecto · 0 confirmados contra la ficha · 0 entregados

*Fichas consultadas: `estado/records` (13 fichas de proyecto). Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15).*

### Decidido y nadie lo está construyendo
Ningún requerimiento del registro nombra un proyecto. Los cinco están aceptados y ninguno tiene proyecto ni entregable.

| REQ | Título | Decidido el | Por quién | Días sin proyecto |
|---|---|---|---|---|
| REQ-1030 | Requerimiento REQ-1030 | 2026-08-13 | no consta en el acta (dueño: Felipe Arango) | 63 |
| REQ-1031 | Requerimiento REQ-1031 | 2026-04-04 | no consta en el acta (dueña: Laura Vélez) | 194 |
| REQ-1032 | Requerimiento REQ-1032 | 2026-04-15 | no consta en el acta (dueña: Sandra Gil) | 183 |
| REQ-2017 | Requerimiento REQ-2017 | 2026-09-19 | no consta en el acta (dueña: Liliana Torres) | 26 |
| REQ-2025 | Requerimiento REQ-2025 | 2026-09-29 | no consta en el acta (dueño: Andrés Lozano) | 16 |

Fuente de las cinco decisiones: `documentos/productos/PRD-303/30-decisiones/2026-10-10-comite-producto.docx`. El acta registra el estado «aceptado» y la fecha desde la que está en ese estado, pero no dice quién decidió. «Por quién» queda declarado como vacío, no rellenado.

Además, REQ-2017 y REQ-2025 están aceptados **sin criterio de aceptación** en el acta.

### La traza no se confirma
No hay trazas declaradas que confirmar: ningún REQ dice ejecutarse en un proyecto. Cobertura de lo decidido: 0 de 5 con proyecto (0 %), 0 de 5 con entregable, 0 de 5 entregados.

### Lo que un proyecto construye y el registro no tiene
| Proyecto | Su ficha dice | Ningún REQ lo nombra |
|---|---|---|
| PRY-205 · Pago con QR en caja | Producto: «pago con QR»; alcance: «Entregar pago con qr en caja para Abastecimiento» (acta de constitución del 2025-08-16, `estado/records/PRY-205.json`) | Sí: ninguno de los 5 REQ nombra PRY-205 |

Cautela: la ficha de PRY-205 nombra el producto por su nombre («pago con QR»), no por su código PRD-303. Coincide con el nombre de este producto, pero no está confirmado que sea el mismo. Lo que se puede afirmar es que el proyecto parece construir lo que este producto define y que el registro no lo sabe. Quién tiene razón no lo decide este comando; hay que ir a ver.

### La cadena completa
| REQ | Estado | Decisión | Proyecto | Confirmado | Entregables |
|---|---|---|---|---|---|
| REQ-1030 | aceptado | comité 2026-10-10 (en estado desde 2026-08-13) | — | no | — |
| REQ-1031 | aceptado | comité 2026-10-10 (en estado desde 2026-04-04) | — | no | — |
| REQ-1032 | aceptado | comité 2026-10-10 (en estado desde 2026-04-15) | — | no | — |
| REQ-2017 | aceptado | comité 2026-10-10 (en estado desde 2026-09-19) | — | no | — |
| REQ-2025 | aceptado | comité 2026-10-10 (en estado desde 2026-09-29) | — | no | — |

La cadena se rompe en el segundo eslabón: hay decisión citada, no hay proyecto.

### Sin fichas a la vista
Hay fichas para los 13 proyectos, pero ningún requerimiento apunta a uno, así que no hay nada que confirmar. Por eso ninguna traza se da por confirmada.

### Otras señales del cálculo (fuera de la trazabilidad)
- Supuesto sin verificar hace 212 días: «La demanda se sostiene sin descuento».
- Sin dato: criterio de éxito del producto y autoridad.

## Después
Hay cinco decididos sin proyecto. REQ-1030, REQ-1031 y REQ-1032 tienen criterio de aceptación y son los que podrían pasar a `/criterio-product:product-charter` si el dueño los considera listos. REQ-2017 y REQ-2025 primero necesitan su criterio de aceptación. Lo de PRY-205 es una conversación con su gerente de proyecto sobre qué producto ejecuta, no un comando.
