# Corrida · 2026-10-15-product-requirements-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-requirements (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-15T10:03:37 · **Fin:** 2026-10-15T10:04:19 · **Duración:** 42 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-requirements` | 5 | — | 26 | 8 | 5 aceptados sin proyecto que los ejecute; 2 sin criterio de aceptación; supuesto de demanda sin verificar hace 212 días; evidencia = línea de acta sin cita |

Por señal (`product-requirements`): `requirement_untraced` 5, `requirement_without_acceptance` 2, `assumption_unverified` 1

## Lo que el agente mostró

Ya terminé. La corrida quedó registrada en `estado-producto/PRD-303/corridas/2026-10-15-product-requirements-1.md`.

**Registro de PRD-303 (Pago con QR), al 2026-10-15:** hay 5 requerimientos y los 5 están aceptados. Ninguno tiene un proyecto que lo ejecute.

- **Sin proyecto:** los 5 están decididos y nadie los construye. Los más viejos, REQ-1031 y REQ-1032, llevan 194 y 183 días aceptados. No pude confirmar las trazas porque la carpeta de fichas de proyecto (`estado/`) está vacía.
- **Sin criterio de aceptación:** REQ-2017 y REQ-2025. El criterio de REQ-1030, «se verifica en producción», no dice qué se mide.
- **Evidencia débil:** el cálculo da 100% con evidencia, pero eso es solo un conteo. En los tres requerimientos que abrí (REQ-1030, REQ-2017 y REQ-2025), la evidencia es una línea del acta del comité del 2026-10-10 que dice «Cliente entrevistado». No cita quién lo pidió ni qué dijo. No abrí REQ-1031 ni REQ-1032, así que de esos dos solo sé el conteo.
- **Sin quién decidió:** en esos mismos tres, el campo «quién decidió» está vacío. La autoridad de decisión del producto (`authority`) está sin definir, así que no se puede decir a quién le toca cerrar estos vacíos.
- **Supuesto sin verificar:** «La demanda se sostiene sin descuento» lleva 212 días sin verificarse (el umbral es 30). Nadie lo tiene asignado.
- **Cifra sin contrastar:** el caso de negocio declara un volumen mensual de 243.100 y no hay medición contra la cual compararlo.

El registro no tiene requerimientos propuestos, ni evidencia vieja, ni dolientes que sean un área en vez de una persona. Como siguiente paso, `/criterio-product:product-trace` cubre lo decidido que nadie construye. Ninguno está listo para `/criterio-product:product-charter`, porque los 5 carecen de cita de quien lo pidió.

La salida completa quedó en `estado-producto/PRD-303/corridas/salida-product-requirements.md`.

Los términos ya estaban vigentes (aceptados por José Francisco Ñáñez el 2026-10-15), así que no hubo que registrarlos de nuevo.
