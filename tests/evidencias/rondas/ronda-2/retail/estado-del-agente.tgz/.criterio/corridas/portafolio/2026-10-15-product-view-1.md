# Corrida · 2026-10-15-product-view-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:product-view venta en línea

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-15T10:36:35 · **Fin:** 2026-10-15T10:37:25 · **Duración:** 51 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-view` | 13 | — | 32 | 60 | Producto con un solo proyecto (PRY-200): sin sección de producto, señales del proyecto listadas. Reporta 6 de 13 proyectos sin producto declarado. No sabe a qué producto sirven ni si PRY-200 depende de PRY-209 o PRY-211. |

Por señal (`product-view`): `milestone_met_without_evidence` 29, `progress_vs_plan` 9, `declared_vs_evidence` 5, `commitment_overdue` 4, `variance_time` 3, `variance_cost` 2, `commitment_undated` 2, `vendor_deliverable_late` 2, `rebaseline_unauthorized` 2, `change_without_baseline` 1, `vendor_accepted_without_evidence` 1

## Lo que el agente mostró

**Vista por producto: venta en línea.** Sale de las fichas en `estado/records/` y del cálculo de `portafolio.py compute`, con corte al 2026-10-15. Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15), así que no los registré de nuevo.

Venta en línea tiene un solo proyecto, PRY-200 (Tienda en línea). Por eso no armé sección de producto y dejo lo que hay que ver en ese proyecto:

| Producto | Proyectos | Con alertas | Fecha más tardía | Aprobado | Comprometido |
|---|---|---|---|---|---|
| venta en línea | 1 (PRY-200) | 1 (4 alertas) | 2027-01-19 (PRY-200) | COP 800.000.000 | COP 407.557.334 |

- **Avance:** el proyecto declara 41 %, pero sus hitos cumplidos (3 de 4) respaldan entre 75 % y 100 %. Son 34 puntos de diferencia, hacia atrás.
- **Hitos sin evidencia:** tres hitos están dados por cumplidos sin evidencia:
  - «Diseño de la experiencia aprobado», vencía el 2026-02-10.
  - «Ambiente de pruebas certificado», vencía el 2026-06-04.
  - «Integración con el ERP», vencía el 2026-09-27.
- **Estado declarado:** rojo, según el informe del 2026-10-04. El informe no explica ninguna de las dos señales anteriores.
- **Fecha:** 2027-01-19, sin desviación ni replanificaciones. Como hay tres hitos sin sustento, eso es lo que dice el plan y no está comprobado.
- **Dinero:** las cuatro cifras están presentes.
  - Ejecutado: COP 204.484.564 (25,6 %).
  - Proyección: COP 822.388.023, 2,8 % sobre lo aprobado, por debajo del umbral de 10 %.
- **Datos que faltan o están viejos:** faltan la autoridad que aprueba y la fase. La identidad, el plan y el monto aprobado vienen de un documento del 2025-10-09, con 12 meses de antigüedad.
- **Dependencias internas:** ninguna, porque es un solo proyecto.

**Proyectos sin producto declarado:** son 6 de 13, y nadie puede responder por el conjunto al que sirven.

| Proyecto | Área dueña |
|---|---|
| PRY-202 Centro de distribución norte | Logística |
| PRY-203 Reposición automática | Finanzas |
| PRY-206 Precios dinámicos | Mercadeo |
| PRY-209 Migración del ERP | Tecnología |
| PRY-210 Etiquetas electrónicas de precio | Tecnología |
| PRY-211 Pronóstico de demanda | Comercio electrónico |

Dos de ellos podrían tocar venta en línea, pero ninguna ficha lo declara, así que son preguntas y no hallazgos. PRY-211 viene del área de comercio electrónico. PRY-209 tiene relación posible con el hito «Integración con el ERP» de PRY-200, el que está sin evidencia.

Lo que no sé es a qué producto sirve cada uno de esos 6 proyectos, ni si PRY-200 depende de PRY-209 o de PRY-211. Para el comité del 2026-10-22 propongo una sola decisión de gobierno: declarar el producto de esos 6, empezando por PRY-209 y PRY-211. No hay dependencias internas sin confirmar que llevar como punto de producto.

Corrida registrada como `2026-10-15-product-view-1` (32 segundos, 13 proyectos). La salida completa está en `estado/corridas/salida-product-view.md`.
