# Corrida · 2026-10-15-vendor-tracking-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:vendor-tracking PRY-206

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-206

**Inicio:** 2026-10-15T10:27:41 · **Fin:** 2026-10-15T10:28:24 · **Duración:** 42 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `vendor-tracking` | 13 | — | 26 | 60 | Cruce de CT-451 de PRY-206: 1 entregable facturado sin acta de recibo, 2 atrasados (233 y 128 días). Dije que no sé la vigencia ni el preaviso del contrato, que no figuran en el documento. |

Por señal (`vendor-tracking`): `milestone_met_without_evidence` 29, `progress_vs_plan` 9, `declared_vs_evidence` 5, `commitment_overdue` 4, `variance_time` 3, `variance_cost` 2, `commitment_undated` 2, `vendor_deliverable_late` 2, `rebaseline_unauthorized` 2, `change_without_baseline` 1, `vendor_accepted_without_evidence` 1

## Lo que el agente mostró

El cruce de proveedores de PRY-206 (Precios dinámicos) está hecho y la corrida quedó registrada. Hay un entregable facturado sin acta de recibo y dos atrasados.

**Términos:** ya estaban vigentes (0.3.8), aceptados por José Francisco Ñáñez el 2026-10-15. No hubo que registrarlos otra vez.

**Contrato CT-451 con Retail Andino Consultores S.A.S.:**
- **Facturado sin acta:** "Configuración del catálogo" está marcado "recibido" en el contrato y facturado por 543.383.423 COP (FV-1451, 2026-09-23). No hay acta de recibo de ese entregable, y el contrato dice que se factura contra acta firmada por el gerente. Las dos actas de la carpeta son de hitos del proyecto, no del contrato.
- **Atrasados:** "Licenciamiento de la plataforma" lleva 233 días de atraso (comprometido para 2026-02-24). "Bolsa de horas de desarrollo" lleva 128 (2026-06-09). Ninguno tiene evidencia ni entrega declarada.
- **Informe en verde:** el informe de avance del 2026-10-15 declara el proyecto en verde con 78 % de avance. No menciona ninguno de estos atrasos. Tampoco menciona dos hitos marcados como cumplidos sin evidencia: "Diseño de la experiencia aprobado" e "Integración con el ERP".
- **Compromisos del proveedor:** no hay ninguno vencido. El único compromiso del comité del 2026-10-13 es de Laura Vélez, para el 2026-11-08, y el acta no dice si pertenece al proveedor.
- **Sin dato:** el contrato no trae vigencia, renovación ni preaviso. Por eso no puedo decir si hay un preaviso por vencer antes del cierre del proyecto (2026-11-27).

Dejo ofrecido llevar la factura sin acta al comité del 2026-10-22.

El informe completo está en `/home/claude/banco/ronda-2/retail/espacio/estado/corridas/salida-vendor-tracking.md`. La corrida quedó con el id `2026-10-15-vendor-tracking-1`.
