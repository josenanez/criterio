# Corrida · 2026-10-15-pm-escalate-1

**Agente:** Samuel (proyecto) · **Comando:** `/criterio-project:pm-escalate (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-15T10:15:16 · **Fin:** 2026-10-15T10:16:14 · **Duración:** 58 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `pm-escalate` | 1 | — | 39 | 1 | Paquete de decisión: autoridad del gerente no declarada en el acta, y proyección de presupuesto +25,6 % sobre lo aprobado. No calculé impacto (sin días ni dependencias declaradas); no sé el umbral de autoridad, la fecha de cierre vigente ni el costo de recortar alcance. |

Por señal (`pm-escalate`): `commitment_undated` 1

## Lo que el agente mostró

El paquete de escalamiento de PRY-205 (Pago con QR en caja) está listo y la corrida quedó registrada. Dos puntos van al comité, el primero por su orden: el acta no dice qué puede decidir el gerente y el segundo es que el presupuesto proyectado supera lo aprobado. El guion pedía mostrar los términos solo si no estaban vigentes; ya lo estaban (aceptados por José Francisco Ñáñez el 2026-10-15), así que no hubo que pedirlos de nuevo.

**Punto 0: autoridad del gerente.**
- **Pregunta cerrada:** ¿el Comité de Expansión confirma por escrito, como anexo al acta del 2025-08-16, el umbral que Gustavo Neira decide solo y el que sube al comité?
- **Quién decide:** el patrocinador, Camilo Beltrán, con el comité.
- **Si no se decide hoy:** el comité siguiente es el 2026-10-29 y hasta entonces cada punto se sube sin saber si hacía falta. Ningún documento da una fecha de vencimiento y no la inventé.
- **Recomiendo:** declararlo por escrito, porque no cuesta nada y evita el «eso lo decide usted».

**Punto 1: presupuesto.**
- **Pregunta cerrada:** ¿se sube el presupuesto de COP 6.800.000.000 a COP 8.542.694.050, es decir COP 1.742.694.050 (+25,6 %) más, o se mantiene y el gerente vuelve con el alcance recortado?
- **Opciones:** subir tiene costo claro. Mantener el tope y recortar no se puede costear, porque ningún documento dice qué componentes saldrían ni cuánto tiempo cambia.
- **Recomiendo:** que el comité no decida el monto hoy. Primero deben llegar el ajuste de presupuesto que Laura Vélez quedó de mandar «la otra semana» (sin fecha) y una fecha de cierre vigente. El cierre comprometido era el 2026-06-10 y el informe del 2026-10-11 sigue en Verde.

**Lo que no calculé ni sé:**
- **Impacto en otros proyectos:** no corrí `impact`. Es un punto de monto, no de fecha, y no se dio ningún número de días. El acta declara «Ninguna declarada» en dependencias, y eso no prueba que no las haya.
- **Lo que ningún documento dice:** el umbral de autoridad, la fecha de cierre vigente, cómo se compone la proyección y cuánto costaría recortar alcance.

**Lo que no escala:**
- **Beatriz Cuéllar, «entregar el punto 1»:** se reprogramó 2 veces (8 de noviembre al 22 de noviembre) y el umbral es tres.
- **Riesgo del proveedor sin equipo completo:** nadie lo registró, pero registrarlo está dentro de tu autoridad.
- **Revisión con el proveedor del 2026-10-25:** todavía no vence.

La corrida quedó registrada como `2026-10-15-pm-escalate-1`.

Archivos en `estado/PRY-205-pago-con-qr-en-caja/corridas/`:
- `salida-pm-escalate.md`
