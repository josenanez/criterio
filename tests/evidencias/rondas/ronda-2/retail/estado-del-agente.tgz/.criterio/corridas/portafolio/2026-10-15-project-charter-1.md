# Corrida · 2026-10-15-project-charter-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-charter PRY-202 revisar

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-202

**Inicio:** 2026-10-15T10:32:38 · **Fin:** 2026-10-15T10:33:23 · **Duración:** 45 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-charter` | 13 | — | 28 | 60 | Revisión del acta PRY-202: sin autoridad del gerente, objetivo/alcance/exclusiones/criterio de éxito de relleno, sin supuestos; contradicción de cierre acta 2027-06-10 vs cronograma 2027-05-01. No leí el comité del 2026-10-10 ni el contrato CT-599. |

Por señal (`project-charter`): `milestone_met_without_evidence` 29, `progress_vs_plan` 9, `declared_vs_evidence` 5, `commitment_overdue` 4, `variance_time` 3, `variance_cost` 2, `commitment_undated` 2, `vendor_deliverable_late` 2, `rebaseline_unauthorized` 2, `change_without_baseline` 1, `vendor_accepted_without_evidence` 1

## Lo que el agente mostró

Revisé el acta de PRY-202. Existe, es del 2026-03-19, y casi todos sus campos tienen texto de relleno. Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15), así que no los registré de nuevo.

**Qué falta y qué consecuencia tiene**
- **Autoridad del gerente:** no existe. Con 1.200.000.000 COP aprobados y 547.888.881 ya comprometidos (46 %), todo cambio o compromiso adicional de Andrés Lozano termina en el comité. Si se decide sin facultad, después es un hallazgo.
- **Objetivo de negocio:** el acta dice "Entregar centro de distribución norte", que es la solución y no un objetivo. No hay resultado de negocio contra el cual decidir si seguir, recortar o cambiar el proyecto.
- **Alcance:** solo dice "Componente 1, 2, 3". No se puede verificar qué se entregó ni detectar un cambio de alcance.
- **Exclusiones:** dice "lo que otro proyecto cubre" sin nombrar cuál. Además el acta declara cero dependencias, lo que lo contradice.
- **Supuestos y restricciones:** no existen. Los dos riesgos del informe (conocimiento concentrado en una persona, disponibilidad de los jefes de tienda para el piloto) son supuestos sin declarar.
- **Criterio de éxito:** "en producción y medido", sin métrica ni umbral, y sin nadie que lo mida. El cierre no tendría contra qué compararse.
- **Comité:** está nombrado (Comité de Cadena de Abastecimiento), pero no hay cadencia pactada.
- **Fechas:** el cierre del acta es 2027-06-10 y el del cronograma v1 es 2027-05-01, ambos aprobados el mismo día. Hay 40 días de diferencia y no se sabe cuál es la línea base de cierre.
- **Patrocinador:** sin vacío, es Elena Duarte.

**Lo que no sé**
- No leí el comité del 2026-10-10 ni el contrato CT-599. Pueden traer facultades o restricciones que el acta no recoge.
- No sé si hay una facultad del gerente fuera de la carpeta del proyecto.

**Después:** llevar la definición de la autoridad del gerente al comité, y pasar al registro RAID los dos supuestos implícitos y la contradicción de fechas de cierre. No hice ninguna de las dos cosas.

La salida completa quedó en `/home/claude/banco/ronda-2/retail/espacio/estado/corridas/salida-project-charter.md`, y la corrida se registró como `2026-10-15-project-charter-1`.
