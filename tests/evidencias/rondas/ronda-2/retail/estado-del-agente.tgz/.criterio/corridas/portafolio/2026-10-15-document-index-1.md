# Corrida · 2026-10-15-document-index-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:document-index (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-15T10:23:50 · **Fin:** 2026-10-15T10:24:17 · **Duración:** 27 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `document-index` | 13 | — | 13 | 60 | 74 documentos sin cambio, nada que releer; 4 citas de PRY-205 no resuelven aunque el acta existe bajo la carpeta del proyecto. No se corrigió la ficha. |

Por señal (`document-index`): `milestone_met_without_evidence` 29, `progress_vs_plan` 9, `declared_vs_evidence` 5, `commitment_overdue` 4, `variance_time` 3, `variance_cost` 2, `commitment_undated` 2, `vendor_deliverable_late` 2, `rebaseline_unauthorized` 2, `change_without_baseline` 1, `vendor_accepted_without_evidence` 1

## Lo que el agente mostró

## Carpeta al 2026-10-15

**Documentos:** 74 · **Sin cambio:** 74 · **Hay que releer:** 0

Ningún documento cambió, se reguardó, se renombró, se movió ni desapareció. Los términos ya estaban vigentes (aceptados por José Francisco Ñáñez el 2026-10-15), así que no se registraron de nuevo.

### Citas que dejaron de resolver
| Proyecto | Campo | Documento citado |
|---|---|---|
| PRY-205 | `identity.code` | `00-gobierno/2025-08-16-acta-constitucion.docx` |
| PRY-205 | `identity.name` | ídem |
| PRY-205 | `identity.manager` | ídem |
| PRY-205 | `identity.sponsor` | ídem |

El archivo sí existe, en `PRY-205-pago-con-qr-en-caja/00-gobierno/2025-08-16-acta-constitucion.docx`. La cita está escrita sin la carpeta del proyecto y por eso no resuelve. No hay un renombrado detectado y no toqué la ficha. Corregir esas cuatro citas es una decisión tuya, una por una.

No hay formatos ilegibles. Este comando solo cuenta y compara, no lee el contenido.

**Qué sigue:** no hace falta un `/portfolio-scan`, porque `projects_to_recompute` está vacío.

La corrida quedó registrada con 13 segundos medidos y `salida-document-index.md`. El registro también cuenta 60 hallazgos abiertos de corridas anteriores en 12 proyectos. Los más repetidos son 29 hitos cumplidos sin evidencia y 9 desvíos de avance contra el plan.
