# Corrida · 2026-10-15-budget-tracking-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:budget-tracking PRY-205

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-205

**Inicio:** 2026-10-15T10:26:52 · **Fin:** 2026-10-15T10:27:36 · **Duración:** 44 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `budget-tracking` | 13 | — | 27 | 60 | Informe de presupuesto PRY-205: proyección excede aprobado en 25.6%; comprometido/ejecutado/proyección son declaraciones sin evidencia; 3 hitos met sin evidencia; no declaró autoridad, fase ni desviación en pesos. |

Por señal (`budget-tracking`): `milestone_met_without_evidence` 29, `progress_vs_plan` 9, `declared_vs_evidence` 5, `commitment_overdue` 4, `variance_time` 3, `variance_cost` 2, `commitment_undated` 2, `vendor_deliverable_late` 2, `rebaseline_unauthorized` 2, `change_without_baseline` 1, `vendor_accepted_without_evidence` 1

## Lo que el agente mostró

Informe de presupuesto de PRY-205 (Pago con QR en caja) al 2026-10-15, en COP. Los términos ya estaban vigentes, aceptados por José Francisco Ñáñez el 2026-10-15, así que no los volví a registrar.

| | Monto (COP) | % del aprobado | Fuente |
|---|---|---|---|
| Aprobado | 6.800.000.000 | 100 % | Acta de constitución, 2025-08-16 |
| Comprometido | 2.821.990.996 | 41.5 % | Informe de avance, 2026-10-11 |
| Ejecutado | 1.683.942.028 | 24.8 % | Informe de avance, 2026-10-11 |
| Proyección al cierre | 8.542.694.050 | excede el aprobado en 25.6 % | Informe de avance, 2026-10-11 |

- **Disponible real:** 3.978.009.004 COP (aprobado menos comprometido).
- **Línea base:** no hay replanificaciones ni cambios de presupuesto, así que el aprobado original y el vigente son iguales.
- **Alerta principal:** la proyección supera el aprobado en 25.6 %, sobre el umbral de 10 %. El comprometido (41.5 %) está lejos del umbral de 90 %.
- **Avance desalineado:** el informe declara 46 % de avance, pero los 3 hitos figuran como cumplidos (100 %), sin evidencia de cumplimiento. Eso deja 54 puntos de brecha. La fecha final del plan (2026-04-29) ya pasó y no hay replanificación registrada. El informe dice "verde" sin explicar nada de esto.
- **Compromiso sin fecha:** Laura Vélez debe mandar el ajuste del presupuesto, y las notas del 2026-10-15 no le ponen fecha.
- **Sin evidencia:** solo el aprobado sale de un documento formal. Comprometido, ejecutado y proyección son declaraciones del informe.
- **Sin dato:** autoridad, fase, desviación de la proyección en pesos (el cálculo no la entrega) y proveedores (el proyecto no tiene).
- **Siguiente paso:** puedo preparar la solicitud de cambio de presupuesto con `/change-control`. No lo hice porque no lo pediste.

La corrida quedó registrada con el id `2026-10-15-budget-tracking-1`, y el informe completo está en `estado/corridas/salida-budget-tracking.md`.
