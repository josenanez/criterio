# Acta de constitución · Precios dinámicos

**Código:** PRY-206
**Área dueña:** Mercadeo
**Patrocinador:** Beatriz Cuéllar
**Gerente de proyecto:** Rubén Cárdenas
**Comité:** Comité de Transformación Digital
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-11-02

## Objetivo del negocio

Entregar precios dinámicos para Mercadeo.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**6.800.000.000 COP**, aprobado por Comité de Transformación Digital el 2025-11-02.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-11-12 |
| Cierre | 2027-01-04 |

## Criterio de éxito

Precios dinámicos en producción y medido.

## Dependencias declaradas

- Ninguna declarada
