# Solicitud de cambio CC-01

**Proyecto:** PRY-201 · Programa de fidelización
**Fecha:** 2026-10-12
**Solicitante:** Jorge Medina

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +91 días sobre la línea base vigente |
| Costo | 182.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
