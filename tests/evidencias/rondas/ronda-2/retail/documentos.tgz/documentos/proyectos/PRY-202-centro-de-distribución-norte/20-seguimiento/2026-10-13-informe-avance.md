# Informe de avance · Centro de distribución norte

**Código:** PRY-202
**Fecha de corte:** 2026-10-13
**Gerente:** Andrés Lozano

## Estado declarado

**Verde**

Avance reportado: **38%**

## Lo que pasó en el periodo

- Se ajustó el plan de pruebas con el área de seguridad

## Presupuesto

| | COP |
|---|---|
| Aprobado | 1.200.000.000 |
| Comprometido | 547.888.881 |
| Ejecutado | 363.517.461 |
| Proyección al cierre | 1.176.472.667 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
- Disponibilidad de los jefes de tienda para el piloto
