# Informe de avance · Etiquetas electrónicas de precio

**Código:** PRY-210
**Fecha de corte:** 2026-10-14
**Gerente:** Sandra Gil

## Estado declarado

**Amarillo**

Avance reportado: **47%**

## Lo que pasó en el periodo

- Se reprogramó el despliegue por el congelamiento de temporada de fin de año
- El proveedor entregó el componente de integración, pendiente de aceptación

## Presupuesto

| | COP |
|---|---|
| Aprobado | 9.500.000.000 |
| Comprometido | 6.305.380.478 |
| Ejecutado | 5.660.874.630 |
| Proyección al cierre | 8.828.711.745 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
