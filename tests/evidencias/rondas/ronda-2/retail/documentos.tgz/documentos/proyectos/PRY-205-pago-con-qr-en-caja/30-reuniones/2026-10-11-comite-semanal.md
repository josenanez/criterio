# Comité de Expansión · Pago con QR en caja

**Fecha:** 2026-10-11
**Asistentes:** Gustavo Neira, Camilo Beltrán

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Beatriz Cuéllar | Entregar el punto 1 | 2026-11-08 |
