# Acta de constitución · Cajas de autopago

**Código:** PRY-204
**Área dueña:** Tiendas
**Patrocinador:** Carlos Peña
**Gerente de proyecto:** Natalia Ospina
**Comité:** Comité de Expansión
**Producto asociado:** autopago en tienda
**Fecha de aprobación:** 2025-12-10

## Objetivo del negocio

Entregar cajas de autopago para Tiendas.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**9.500.000.000 COP**, aprobado por Comité de Expansión el 2025-12-10.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-12-20 |
| Cierre | 2027-07-14 |

## Criterio de éxito

Cajas de autopago en producción y medido.

## Dependencias declaradas

- Ninguna declarada
