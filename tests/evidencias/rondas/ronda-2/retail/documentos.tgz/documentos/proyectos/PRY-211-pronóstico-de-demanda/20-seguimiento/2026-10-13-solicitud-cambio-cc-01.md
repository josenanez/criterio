# Solicitud de cambio CC-01

**Proyecto:** PRY-211 · Pronóstico de demanda
**Fecha:** 2026-10-13
**Solicitante:** Carlos Peña

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +77 días sobre la línea base vigente |
| Costo | 154.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
