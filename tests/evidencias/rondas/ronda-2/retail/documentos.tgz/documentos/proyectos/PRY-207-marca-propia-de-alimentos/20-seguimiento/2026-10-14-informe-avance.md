# Informe de avance · Marca propia de alimentos

**Código:** PRY-207
**Fecha de corte:** 2026-10-14
**Gerente:** Rubén Cárdenas

## Estado declarado

**Amarillo**

Avance reportado: **40%**

## Lo que pasó en el periodo

- El proveedor entregó el componente de integración, pendiente de aceptación
- Se reprogramó el despliegue por el congelamiento de temporada de fin de año
- Se recibió el concepto de Jurídica sobre los términos de uso

## Presupuesto

| | COP |
|---|---|
| Aprobado | 4.200.000.000 |
| Comprometido | 2.952.958.305 |
| Ejecutado | 1.240.585.800 |
| Proyección al cierre | 4.112.177.165 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
