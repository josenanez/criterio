# Comité de Expansión · Cajas de autopago

**Fecha:** 2026-10-09
**Asistentes:** Natalia Ospina, Carlos Peña

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Andrés Lozano | Entregar el punto 28 | 2026-10-08 |
