# Acta de constitución · Marca propia de alimentos

**Código:** PRY-207
**Área dueña:** Talento humano
**Patrocinador:** Ricardo Salas
**Gerente de proyecto:** Rubén Cárdenas
**Comité:** Comité Comercial
**Producto asociado:** marca propia
**Fecha de aprobación:** 2026-04-24

## Objetivo del negocio

Entregar marca propia de alimentos para Talento humano.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**4.200.000.000 COP**, aprobado por Comité Comercial el 2026-04-24.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-05-04 |
| Cierre | 2026-12-01 |

## Criterio de éxito

Marca propia de alimentos en producción y medido.

## Dependencias declaradas

- Ninguna declarada
