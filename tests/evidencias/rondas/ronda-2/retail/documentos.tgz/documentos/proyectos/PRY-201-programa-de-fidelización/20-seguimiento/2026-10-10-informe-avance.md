# Informe de avance · Programa de fidelización

**Código:** PRY-201
**Fecha de corte:** 2026-10-10
**Gerente:** Jorge Medina

## Estado declarado

**Amarillo**

Avance reportado: **59%**

## Lo que pasó en el periodo

- Se levantó un hallazgo de seguridad en los medios de pago
- Se reprogramó el despliegue por el congelamiento de temporada de fin de año

## Presupuesto

| | COP |
|---|---|
| Aprobado | 2.400.000.000 |
| Comprometido | 1.688.589.807 |
| Ejecutado | 1.350.769.414 |
| Proyección al cierre | 2.458.984.346 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
- Congelamiento de cambios en temporada alta
