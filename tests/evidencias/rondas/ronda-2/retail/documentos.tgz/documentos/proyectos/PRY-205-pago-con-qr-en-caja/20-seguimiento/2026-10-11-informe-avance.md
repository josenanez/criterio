# Informe de avance · Pago con QR en caja

**Código:** PRY-205
**Fecha de corte:** 2026-10-11
**Gerente:** Gustavo Neira

## Estado declarado

**Verde**

Avance reportado: **46%**

## Lo que pasó en el periodo

- La validación con dos tiendas se extendió una semana por el conteo de inventario
- Se recibió el concepto de Jurídica sobre los términos de uso
- El proveedor entregó el componente de integración, pendiente de aceptación

## Presupuesto

| | COP |
|---|---|
| Aprobado | 6.800.000.000 |
| Comprometido | 2.821.990.996 |
| Ejecutado | 1.683.942.028 |
| Proyección al cierre | 8.542.694.050 |

## Riesgos abiertos

- Disponibilidad de los jefes de tienda para el piloto
