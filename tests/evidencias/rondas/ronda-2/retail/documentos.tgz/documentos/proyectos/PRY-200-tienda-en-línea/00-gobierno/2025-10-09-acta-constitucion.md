# Acta de constitución · Tienda en línea

**Código:** PRY-200
**Área dueña:** Finanzas
**Patrocinador:** Natalia Ospina
**Gerente de proyecto:** Mauricio Pérez
**Comité:** Comité Comercial
**Producto asociado:** venta en línea
**Fecha de aprobación:** 2025-10-09

## Objetivo del negocio

Entregar tienda en línea para Finanzas.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**800.000.000 COP**, aprobado por Comité Comercial el 2025-10-09.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-10-19 |
| Cierre | 2027-03-18 |

## Criterio de éxito

Tienda en línea en producción y medido.

## Dependencias declaradas

- Ninguna declarada
