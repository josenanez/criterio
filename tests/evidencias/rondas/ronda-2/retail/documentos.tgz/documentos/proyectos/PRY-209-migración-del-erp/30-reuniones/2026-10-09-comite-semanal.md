# Comité de Transformación Digital · Migración del ERP

**Fecha:** 2026-10-09
**Asistentes:** Natalia Ospina, Laura Vélez

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Jorge Medina | Entregar el punto 39 | por definir |
