# Comité Comercial · Marca propia de alimentos

**Fecha:** 2026-10-12
**Asistentes:** Rubén Cárdenas, Ricardo Salas

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Laura Vélez | Entregar el punto 36 | 2026-10-03 |
