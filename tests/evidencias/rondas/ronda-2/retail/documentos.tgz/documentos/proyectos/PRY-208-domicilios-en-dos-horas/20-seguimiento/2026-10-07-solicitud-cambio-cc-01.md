# Solicitud de cambio CC-01

**Proyecto:** PRY-208 · Domicilios en dos horas
**Fecha:** 2026-10-07
**Solicitante:** Beatriz Cuéllar

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +41 días sobre la línea base vigente |
| Costo | 82.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
