# Tablero de métricas · Marca propia

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-09-28

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 61.192 | 2026-09-28 |
