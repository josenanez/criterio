# Caso de negocio · Marca propia

**Código:** PRD-304
**Fecha:** 2025-09-13
**Preparado por:** Felipe Arango

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 85.423 | Caso de negocio, 2025-09-13 |

## Retorno esperado

Retorno esperado en 24 meses.
