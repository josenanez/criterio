# Definición de producto · Tarjeta de la tienda

**Código:** PRD-309
**Gerente de producto:** Natalia Ospina
**Segmento:** Pequeños negocios
**Fecha de la definición:** 2026-01-29

## El problema

El segmento Pequeños negocios no tiene tarjeta de la tienda.

## La propuesta

- Propuesta principal

## Supuestos

- **El proveedor cumple el tiempo pactado** · declarado el 2026-07-10 · verificado

## Proyectos que lo construyen

- Ninguno declarado
