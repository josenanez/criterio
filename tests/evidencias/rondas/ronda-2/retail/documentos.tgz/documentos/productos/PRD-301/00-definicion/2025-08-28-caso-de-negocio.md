# Caso de negocio · Puntos de fidelización

**Código:** PRD-301
**Fecha:** 2025-08-28
**Preparado por:** Diana Molina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 184.436 | Caso de negocio, 2025-08-28 |

## Retorno esperado

Retorno esperado en 24 meses.
