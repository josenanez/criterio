# Caso de negocio · Marketplace

**Código:** PRD-308
**Fecha:** 2026-07-25
**Preparado por:** Camilo Beltrán

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 81.558 | Caso de negocio, 2026-07-25 |

## Retorno esperado

Retorno esperado en 24 meses.
