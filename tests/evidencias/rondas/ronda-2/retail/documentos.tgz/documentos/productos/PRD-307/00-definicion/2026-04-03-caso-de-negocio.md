# Caso de negocio · Compra y recoge

**Código:** PRD-307
**Fecha:** 2026-04-03
**Preparado por:** Óscar Ramírez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 89.101 | Caso de negocio, 2026-04-03 |

## Retorno esperado

Retorno esperado en 24 meses.
