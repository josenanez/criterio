# Definición de producto · Puntos de fidelización

**Código:** PRD-301
**Gerente de producto:** Diana Molina
**Segmento:** Hogares
**Fecha de la definición:** 2025-08-28

## El problema

El segmento Hogares no tiene puntos de fidelización.

## La propuesta

- Propuesta principal

## Supuestos

- **El cliente paga por la entrega rápida** · declarado el 2026-08-22 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
