# Caso de negocio · Bolsas reutilizables

**Código:** PRD-299
**Fecha:** 2026-07-17
**Preparado por:** Felipe Arango

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 120.000 | Caso de negocio, 2026-07-17 |

## Retorno esperado

Retorno esperado en 24 meses.
