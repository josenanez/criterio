# Caso de negocio · Venta en línea

**Código:** PRD-300
**Fecha:** 2026-03-07
**Preparado por:** Gustavo Neira

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 191.607 | Caso de negocio, 2026-03-07 |

## Retorno esperado

Retorno esperado en 24 meses.
