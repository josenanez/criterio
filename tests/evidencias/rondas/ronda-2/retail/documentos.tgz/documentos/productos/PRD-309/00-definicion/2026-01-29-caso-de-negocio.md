# Caso de negocio · Tarjeta de la tienda

**Código:** PRD-309
**Fecha:** 2026-01-29
**Preparado por:** Natalia Ospina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 189.746 | Caso de negocio, 2026-01-29 |

## Retorno esperado

Retorno esperado en 24 meses.
