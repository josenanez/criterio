# Definición de producto · Marketplace

**Código:** PRD-308
**Gerente de producto:** Camilo Beltrán
**Segmento:** Pequeños negocios
**Fecha de la definición:** 2026-07-25

## El problema

El segmento Pequeños negocios no tiene marketplace.

## La propuesta

- Propuesta principal

## Supuestos

- **El cliente paga por la entrega rápida** · declarado el 2026-07-31 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
