# Entrevistas · Pago con QR

**Ronda:** Ronda · 2025-09-29
**Realizadas por:** María Restrepo

### Cliente entrevistado · 2025-09-29

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
