# Definición de producto · Compra y recoge

**Código:** PRD-307
**Gerente de producto:** Óscar Ramírez
**Segmento:** Empresas
**Fecha de la definición:** 2026-04-03

## El problema

El segmento Empresas no tiene compra y recoge.

## La propuesta

- Propuesta principal

## Supuestos

- **El cliente paga por la entrega rápida** · declarado el 2026-06-23 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
