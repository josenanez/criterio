# Caso de negocio · Autopago en tienda

**Código:** PRD-302
**Fecha:** 2026-04-16
**Preparado por:** Natalia Ospina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 297.088 | Caso de negocio, 2026-04-16 |

## Retorno esperado

Retorno esperado en 24 meses.
