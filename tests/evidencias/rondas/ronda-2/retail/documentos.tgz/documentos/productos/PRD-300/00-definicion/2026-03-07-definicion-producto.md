# Definición de producto · Venta en línea

**Código:** PRD-300
**Gerente de producto:** Gustavo Neira
**Segmento:** Jóvenes
**Fecha de la definición:** 2026-03-07

## El problema

El segmento Jóvenes no tiene venta en línea.

## La propuesta

- Propuesta principal

## Supuestos

- **El cliente paga por la entrega rápida** · declarado el 2026-06-06 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
