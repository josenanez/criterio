# Entrevistas · Tarjeta de la tienda

**Ronda:** Ronda · 2026-04-05
**Realizadas por:** Natalia Ospina

### Cliente entrevistado · 2026-04-05

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
