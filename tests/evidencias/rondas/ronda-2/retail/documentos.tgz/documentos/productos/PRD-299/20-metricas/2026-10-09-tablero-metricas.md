# Tablero de métricas · Bolsas reutilizables

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-09

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 120.000 | 2026-10-09 |
