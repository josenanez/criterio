# Caso de negocio · App de clientes

**Código:** PRD-306
**Fecha:** 2026-03-20
**Preparado por:** Ricardo Salas

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 61.809 | Caso de negocio, 2026-03-20 |

## Retorno esperado

Retorno esperado en 24 meses.
