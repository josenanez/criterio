# Tablero de métricas · Autopago en tienda

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-07

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 283.438 | 2026-10-07 |
