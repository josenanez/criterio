# Definición de producto · Autopago en tienda

**Código:** PRD-302
**Gerente de producto:** Natalia Ospina
**Segmento:** Pequeños negocios
**Fecha de la definición:** 2026-04-16

## El problema

El segmento Pequeños negocios no tiene autopago en tienda.

## La propuesta

- Propuesta principal

## Supuestos

- **El proveedor cumple el tiempo pactado** · declarado el 2026-05-02 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
